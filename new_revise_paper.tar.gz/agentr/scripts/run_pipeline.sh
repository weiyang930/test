#!/usr/bin/env bash
# =============================================================================
# End-to-end Agent-R pipeline for ONE dataset.
#
# Usage:  DS=Industrial_10_80_r811 NGPU=8 bash scripts/run_pipeline.sh [first_stage]
#   PY_LLM     python of the LLM environment     (requirements_llm.txt)    default: python
#   PY_RECBOLE python of the RecBole environment (requirements_recbole.txt) default: python
#   NGPU       number of GPUs on this machine (default 8)
#   EXEC_ARGS  executor hyperparameters passed to every executor stage, e.g. "--keep 40 --budget 10"
#   TRAIN_ARGS residual-ranker training hyperparameters, e.g. "--epochs 2 --alpha_train 0.2"
#
# Stages
#   1 routes      RecBole NCL / DiffRec, Qwen3-Embedding, Mem-Ret, Popularity -> combined route bank
#   2 memory      Memory Agent (LLM STM/LTM user memory)
#   3 planning    validated prior + planner contexts + Planning Agent (LLM) policies
#   4 adaptation  planner-conditioned frozen top-50 slates
#   5 ranker_data residual-ranker train/dev data
#   6 train       Residual Ranking Agent training (torchrun, NGPU GPUs)
#   7 select      score every checkpoint on ranker-dev users, select (checkpoint, prior, alpha)
#   8 test        TEST once with the selected configuration + full-test-population evaluation
# =============================================================================
set -euo pipefail
DS="${DS:?set DS, e.g. DS=Industrial_10_80_r811}"
FIRST="${1:-1}"
NGPU="${NGPU:-8}"
PY_LLM="${PY_LLM:-python}"
PY_RECBOLE="${PY_RECBOLE:-python}"
EXEC_ARGS="${EXEC_ARGS:-}"
TRAIN_ARGS="${TRAIN_ARGS:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RB=$ROOT/pipeline/route_bank/scripts
PL=$ROOT/pipeline/planning/scripts
CA=$ROOT/pipeline/candidate_adaptation/scripts
RR=$ROOT/pipeline/residual_ranker/scripts
CFG=$ROOT/configs/$(echo "$DS" | tr '[:upper:]' '[:lower:]').yaml
TAG=res_${DS}
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false
say () { echo "[$(date +%H:%M:%S)] [$DS] $*"; }
run () { [ "$1" -ge "$FIRST" ]; }

[ -f "$ROOT/data/$DS/interaction.csv" ] || tar -C "$ROOT/data" -xzf "$ROOT/data/$DS.tar.gz"

if run 1; then
  say "stage 1: route bank"
  $PY_RECBOLE $RB/build_recbole_atomic.py --ds "$DS"
  CUDA_VISIBLE_DEVICES=0 $PY_RECBOLE $RB/recbole_producer.py --ds "$DS" --model NCL --tool ncl --gpu 0 &
  CUDA_VISIBLE_DEVICES=$((1 % NGPU)) $PY_RECBOLE $RB/recbole_producer.py --ds "$DS" --model DiffRec --tool diffrec --gpu 0 &
  CUDA_VISIBLE_DEVICES=$((2 % NGPU)) $PY_LLM $RB/build_semantic_route.py --ds "$DS" --gpu 0 &
  CUDA_VISIBLE_DEVICES=$((3 % NGPU)) $PY_LLM $RB/build_aux_routes.py --ds "$DS" --gpu 0 &
  wait
  $PY_RECBOLE $RB/assemble_route_cache.py --ds "$DS"
fi

if run 2; then
  say "stage 2: Memory Agent"
  (cd "$ROOT" && $PY_LLM scripts/build_llm_user_memory.py --dataset-config "$CFG")
fi

if run 3; then
  say "stage 3: Planning Agent"
  $PY_RECBOLE $PL/run_offline.py --dataset "$DS" $EXEC_ARGS
  $PY_RECBOLE $PL/stage_planner_build.py --dataset "$DS" $EXEC_ARGS
  for ((g = 0; g < NGPU; g++)); do
    CUDA_VISIBLE_DEVICES=$g SHARD=$g NSHARDS=$NGPU $PY_LLM $PL/stage_planner_llm.py \
      --ctx "$ROOT/pipeline/planning/artifacts/planner_ctx_${DS}.pkl" \
      --out "$ROOT/pipeline/planning/artifacts/planner_delta_${DS}" --split both &
  done
  wait
fi

if run 4; then
  say "stage 4: candidate adaptation"
  $PY_RECBOLE $CA/stage1_build_planner.py --dataset "$DS" $EXEC_ARGS
fi

if run 5; then
  say "stage 5: residual-ranker data"
  $PY_RECBOLE $RR/build_splits.py --ds "$DS"
  $PY_RECBOLE $RR/build_residual_data.py --ds "$DS"
fi

if run 6; then
  say "stage 6: Residual Ranking Agent training"
  (cd "$RR" && $PY_LLM -m torch.distributed.run --standalone --nnodes=1 --nproc_per_node="$NGPU" \
     train_residual.py --ds "$DS" --tag "$TAG" $TRAIN_ARGS)
fi

if run 7; then
  say "stage 7: model selection on ranker-dev users"
  (cd "$RR" && for CK in ../checkpoints/$TAG/step_*; do
     CUDA_VISIBLE_DEVICES=0 $PY_LLM eval_residual.py --ds "$DS" --ckpt "$CK" --tag "${TAG}_s$(basename "$CK" | cut -d_ -f2)_dev" --split dev
   done)
fi

if run 8; then
  say "stage 8: TEST (pinned configuration) + full-test-population evaluation"
  read -r SEL_CK SEL_PRIOR SEL_ALPHA < <(cd "$RR" && $PY_RECBOLE select_dev.py --prefix "${TAG}_s")
  say "selected: ckpt=$SEL_CK prior=$SEL_PRIOR alpha=$SEL_ALPHA"
  (cd "$RR" && $PY_RECBOLE build_test_data.py --ds "$DS" \
     && CUDA_VISIBLE_DEVICES=0 $PY_LLM eval_residual.py --ds "$DS" --ckpt "$SEL_CK" --tag "${TAG}_test" --split test \
          --fixed_prior "$SEL_PRIOR" --fixed_alpha "$SEL_ALPHA" \
     && $PY_RECBOLE evaluate_fulltest.py --ds "$DS" --tag "${TAG}_test" --prior "$SEL_PRIOR" --alpha "$SEL_ALPHA")
fi
say "done"
