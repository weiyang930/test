#!/usr/bin/env python3
"""Planning Agent, stage 1: per-user coordination diagnostics (no held-out labels).

The Planner sees ONLY:
  - user history summary (length) and base-slate category coherence,
  - this user's retrieval outputs (per-route pool coverage, mean route inverse rank, cross-route agreement),
  - validation-level route diagnostics (single-route validation Recall@50; identical for all users).
Output: artifacts/planner_ctx_<ds>.pkl = list of {userid, split, ctx(dict)} for validation and test users.

Usage: python stage_planner_build.py --dataset Industrial_10_80_r811 [executor hyperparameters]
"""
from __future__ import annotations
import argparse, json, pickle, sys
from collections import Counter
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pcr_common import (AUX_TOOLS, load_dataset, build_pool, route_valid_recall,  # noqa: E402
                        add_executor_args, pool_kwargs)


def user_ctx(cached, uid, keep, item_meta, user_meta, tool_valid, pkw):
    gi, pool, sources, ranks = build_pool(cached, uid, keep, **pkw)
    um = user_meta.get(str(uid), {})
    hist_len = int(um.get("history_len", 0))
    ucats = um.get("categories", set())
    # per-tool coverage of this user's pool + mean route inv-rank
    tool_cov = {}
    for m in AUX_TOOLS:
        invs = [1.0 / (ranks[i][m] + 1.0) for i in pool if m in ranks.get(i, {})]
        tool_cov[m] = {"n_in_pool": len(invs),
                       "mean_inv_rank": round(float(np.mean(invs)), 4) if invs else 0.0}
    supp = [len(sources.get(i, [])) for i in pool]
    agr_ge3 = float(np.mean([s >= 3 for s in supp])) if supp else 0.0
    # base slate coherence: mean cat-jaccard of graph top-10 with history categories
    coh = []
    for i in gi[:10]:
        cats = item_meta.get(str(i), {}).get("categories", set())
        coh.append(len(cats & ucats) / max(len(cats | ucats), 1))
    base_coh = round(float(np.mean(coh)), 4) if coh else 0.0
    return {
        "history_len": hist_len,
        "pool_size": len(pool),
        "cross_path_support_ge3_frac": round(agr_ge3, 4),
        "base_slate_category_coherence": base_coh,
        "per_tool": tool_cov,
        "validation_tool_recall50": {m: round(tool_valid[m], 5) for m in AUX_TOOLS},
    }


def main():
    ap = add_executor_args(argparse.ArgumentParser())
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    ds = args.dataset
    D = load_dataset(ds); keep = args.keep
    cached, item_meta, user_meta, dataset = D["cached"], D["item_meta"], D["user_meta"], D["dataset"]
    valid_users = sorted(dataset.user_valid_items)
    test_users = sorted(dataset.user_test_items)
    vmap = {u: [str(x) for x in v] for u, v in dataset.user_valid_items.items()}
    tool_valid = route_valid_recall(cached, valid_users, vmap)
    rows = []
    for split, users in (("test", test_users), ("valid", valid_users)):
        for uid in users:
            rows.append({"userid": uid, "split": split,
                         "ctx": user_ctx(cached, uid, keep, item_meta, user_meta, tool_valid, pool_kwargs(args))})
    out = Path(args.out) if args.out else HERE.parent / "artifacts" / f"planner_ctx_{ds}.pkl"
    out.parent.mkdir(parents=True, exist_ok=True)
    pickle.dump(rows, open(out, "wb"))
    print(f"[{ds}] built {len(rows)} planner contexts -> {out}")


if __name__ == "__main__":
    main()
