#!/usr/bin/env python3
"""Offline (CPU) stage: validated prior weights of the candidate executor.

Uses the VALIDATION split only:
  (a) single-route validation strength (Recall@50 of each auxiliary route),
  (b) prior weight variants over the evidence channels:
        equal_raw  : uniform weights on raw evidence
        equal_cal  : uniform weights on calibrated evidence
        valstr_cal : route channels scaled by validation route strength, calibrated evidence
  (c) selects the variant with the highest validation Recall@50 of the composed slate.
Writes artifacts/offline_<ds>.json (consumed by the planner-context and candidate-adaptation stages).

Usage: python run_offline.py --dataset Industrial_10_80_r811 [executor hyperparameters]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pcr_common import (  # noqa: E402
    AUX_TOOLS, CHANNELS, FINAL_K, load_dataset, build_pool, evidence_matrix, fit_calibrators,
    apply_calibrators, compose_final, recall_at_k, route_valid_recall, add_executor_args, pool_kwargs,
)


def main():
    ap = add_executor_args(argparse.ArgumentParser())
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    ds = args.dataset
    D = load_dataset(ds)
    cached, item_meta, user_meta, dataset = D["cached"], D["item_meta"], D["user_meta"], D["dataset"]
    valid_users = sorted(dataset.user_valid_items)
    vmap = {u: [str(x) for x in v] for u, v in dataset.user_valid_items.items()}

    tool_valid = route_valid_recall(cached, valid_users, vmap)

    # validation pools / evidence
    states = {}
    for u in valid_users:
        gi, pool, src, rk = build_pool(cached, u, args.keep, **pool_kwargs(args))
        states[u] = (gi, pool, evidence_matrix(pool, u, gi, src, rk, item_meta, user_meta))
    E_list, y_list = [], []
    for u in valid_users:
        gi, pool, E = states[u]
        tg = set(vmap.get(u, []))
        if pool and tg:
            E_list.append(E); y_list.append(np.array([float(i in tg) for i in pool]))
    cals = fit_calibrators(E_list, y_list)

    nch = len(CHANNELS)
    w_equal = np.ones(nch)
    rvals = np.array([tool_valid[t] for t in AUX_TOOLS])
    w_valstr = np.ones(nch); w_valstr[:len(AUX_TOOLS)] = rvals / (rvals.mean() + 1e-9)
    variants = {"prior_equal_raw": (w_equal, False), "prior_equal_cal": (w_equal, True),
                "prior_valstr_cal": (w_valstr, True)}

    valid_r50 = {}
    for name, (w, calibrated) in variants.items():
        r = []
        for u in valid_users:
            tg = vmap.get(u, [])
            if not tg:
                continue
            gi, pool, E = states[u]
            ranked = []
            if pool and args.budget > 0:
                H = apply_calibrators(E, cals) if calibrated else E
                ranked = [i for i, _ in sorted(zip(pool, H @ w), key=lambda p: (-float(p[1]), p[0]))]
            r.append(recall_at_k(compose_final(gi, ranked, args.keep, args.budget, FINAL_K), tg, 50))
        valid_r50[name] = float(np.mean(r)) if r else 0.0
    best = max(valid_r50, key=valid_r50.get)
    print(f"[{ds}] selected prior variant (validation): {best}", flush=True)

    out = Path(args.out) if args.out else HERE.parent / "artifacts" / f"offline_{ds}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    json.dump({"dataset": ds, "executor": vars(args), "channels": CHANNELS,
               "tool_valid_recall50": tool_valid,
               "calibrated_prior_weights": {"equal": w_equal.tolist(), "valstr": w_valstr.tolist()},
               "prior_only_selected": best}, open(out, "w"), indent=2)
    print(f"[{ds}] wrote {out}")


if __name__ == "__main__":
    main()
