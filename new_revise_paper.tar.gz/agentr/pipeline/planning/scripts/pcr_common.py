#!/usr/bin/env python3
"""Planner-conditioned candidate executor -- shared library (offline, CPU).

The candidate executor is deterministic. For each user it
  1. keeps the head of the base route (graph slot) and builds a complementary candidate POOL from the
     auxiliary routes (items retrieved by >= `min_src` auxiliary routes within their top-`aux_k`);
  2. describes every pool item by a small set of evidence channels e_j:
       q_m(i)       route evidence for auxiliary route m = 1/(rank+1)   (0 if route m did not retrieve i)
       agr(i)       cross-route support = (#auxiliary routes retrieving i) / #auxiliary routes
       pref(i)      category Jaccard between item and user history
       pref_topcat  overlap with the user's top history categories
       graphtail(i) inverse rank of i in the base route list
       brand(i)     item brand appears in the user's history
  3. maps every channel independently to an empirical positive rate h_j(e_j) with isotonic regression
     fit on VALIDATION users (per-channel calibration);
  4. scores pool items additively, s(i) = sum_j w_{u,j} h_j(e_j), where w_u is the validated prior
     weight vector modulated by the Planning Agent's per-user policy (see candidate_adaptation);
  5. composes the final top-K slate: base head (keep) + top-`budget` rescued items + base fillers.
"""
from __future__ import annotations

import pickle
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Sequence

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.common.artifacts import ArtifactManager                # noqa: E402
from src.common.config import config_path_for, load_config      # noqa: E402
from src.data.dataset import DatasetLoader                      # noqa: E402
from src.pipelines.metrics import recall_at_k, ndcg_at_k        # noqa: E402

# ------------------------------------------------------------------ executor hyperparameters
# All of the following are hyperparameters of the candidate executor. The values below are generic
# defaults; they can be overridden from the command line and should be selected on the VALIDATION split.
AUX_TOOLS = ["semantic", "mem", "collab", "popularity"]   # auxiliary routes (base route = "graph")
KEEP = 40              # number of base-route head items always kept in the slate
BUDGET = 10            # maximum number of complementary (rescued) items admitted into the slate
AUX_K = 100            # depth of each auxiliary route list that is read
MIN_AUX_SOURCES = 2    # agreement gate: minimum number of auxiliary routes that must retrieve an item
POOL_LIMIT = 160       # maximum pool size per user
FINAL_K = 50           # slate depth
K = 50

# evidence channel names (additive executor)
CH_ROUTE = [f"q_{m}" for m in AUX_TOOLS]
CH_AGR = "agr"
CH_PREF = "pref"
CH_PREF2 = "pref_topcat"
CH_GRAPHTAIL = "graphtail"
CH_BRAND = "brand"
CHANNELS = CH_ROUTE + [CH_AGR, CH_PREF, CH_PREF2, CH_GRAPHTAIL, CH_BRAND]

# keys the Planning Agent may adjust:
#   source_trust[<aux route>]                -> scales q_<route>
#   evidence_weights.cross_path_support      -> scales agr
#   evidence_weights.user_preference_match   -> scales pref
#   (pref_topcat, graphtail and brand are fixed prior channels, not planner-controlled)
PLANNER_KEYS = AUX_TOOLS + ["cross_path_support", "user_preference_match"]


# ------------------------------------------------------------------ item / user metadata
def load_item_meta(dataset_dir: Path) -> Dict[str, Dict]:
    raw_path = Path(dataset_dir) / "item_profile_raw.csv"
    if not raw_path.exists():
        return {}
    df = pd.read_csv(raw_path)
    out: Dict[str, Dict] = {}
    for row in df.to_dict(orient="records"):
        iid = str(row.get("itemid"))
        brand = str(row.get("brand", "unknown")).strip().lower()
        cats = str(row.get("categories", "")).lower().split("|")
        cat_tokens = {c.strip() for c in cats if c.strip() and c.strip() != "unknown"}
        out[iid] = {"brand": brand, "categories": cat_tokens}
    return out


def build_user_meta(dataset, item_meta: Dict[str, Dict]) -> Dict[str, Dict]:
    out: Dict[str, Dict] = {}
    for uid, items in dataset.user_train_items.items():
        brands: Counter = Counter()
        cats: Counter = Counter()
        for iid in sorted(items, key=str):          # deterministic tie-breaking of most_common
            meta = item_meta.get(str(iid), {})
            brand = meta.get("brand", "unknown")
            if brand and brand != "unknown":
                brands[brand] += 1
            for cat in meta.get("categories", set()):
                cats[cat] += 1
        out[str(uid)] = {
            "brands": set(brands.keys()),
            "top_brands": {b for b, _ in brands.most_common(5)},
            "categories": set(cats.keys()),
            "top_categories": {c for c, _ in cats.most_common(8)},
            "history_len": len(items),
        }
    return out


# ------------------------------------------------------------------ data loading
def load_dataset(ds):
    cfg = load_config(str(config_path_for(ds, ROOT)))
    cfg.dataset.data_dir = str(ROOT / cfg.dataset.data_dir)
    art = ArtifactManager(project_root=ROOT, dataset_name=ds)
    dataset = DatasetLoader(cfg.dataset, art).load()
    cached = pickle.load(open(ROOT / f"outputs/results/{ds}/precomputed_tool_cache.pkl", "rb"))
    item_meta = load_item_meta(Path(cfg.dataset.data_dir) / ds)
    user_meta = build_user_meta(dataset, item_meta)
    return dict(cfg=cfg, dataset=dataset, cached=cached, item_meta=item_meta, user_meta=user_meta)


def route_valid_recall(cached, user_ids: Sequence[str], targets_map, k=50) -> Dict[str, float]:
    """Validation Recall@k of every single auxiliary route (users with a validation target only)."""
    out = {}
    for tool in AUX_TOOLS:
        vals = []
        for uid in user_ids:
            y = [str(t) for t in targets_map.get(uid, [])]
            if not y:
                continue
            vals.append(recall_at_k(cached.get(tool, {}).get(uid, [])[:k], y, k))
        out[tool] = round(sum(vals) / max(len(vals), 1), 6)
    return out


# ------------------------------------------------------------------ per-user candidate pool
def candidate_sources(cached, uid, graph_items, graph_keep, aux_tools, aux_k, min_aux_sources):
    base_set = set(graph_items[:graph_keep])
    sources: Dict[str, List[str]] = defaultdict(list)
    ranks: Dict[str, Dict[str, int]] = defaultdict(dict)
    for tool in aux_tools:
        for rank0, iid in enumerate(cached.get(tool, {}).get(uid, [])[:aux_k]):
            if iid in base_set:
                continue
            if tool not in sources[iid]:
                sources[iid].append(tool)
            ranks[iid][tool] = rank0
    kept = [iid for iid, srcs in sources.items() if len(srcs) >= min_aux_sources]
    return kept, sources, ranks


def build_pool(cached, uid, graph_keep, aux_k=AUX_K, min_src=MIN_AUX_SOURCES, pool_limit=POOL_LIMIT):
    """Complementary pool: aux items outside the kept base head that pass the agreement gate,
    sorted by (support desc, best route rank asc, id) and truncated to pool_limit."""
    gi = cached.get("graph", {}).get(uid, [])
    cands, sources, ranks = candidate_sources(cached, uid, gi, graph_keep, AUX_TOOLS, aux_k, min_src)
    cands = sorted(cands, key=lambda i: (-len(sources.get(i, [])),
                                         min(ranks.get(i, {}).values(), default=10**9), i))[:pool_limit]
    return gi, cands, sources, ranks


def compose_final(graph_items, rescue_ranked, graph_keep, rescue_budget, final_k):
    """base head (graph_keep) + top rescued (rescue_budget) + base fillers, de-duplicated, depth final_k."""
    final: List[str] = []
    seen = set()
    for iid in graph_items[:graph_keep]:
        if iid not in seen:
            final.append(iid); seen.add(iid)
    for iid in rescue_ranked[:rescue_budget]:
        if iid not in seen:
            final.append(iid); seen.add(iid)
        if len(final) >= final_k:
            return final[:final_k]
    for iid in graph_items:
        if iid not in seen:
            final.append(iid); seen.add(iid)
        if len(final) >= final_k:
            break
    return final[:final_k]


def evidence_matrix(pool, uid, gi, sources, ranks, item_meta, user_meta):
    """Return (n_pool, n_channels) raw evidence matrix aligned to `pool`."""
    um = user_meta.get(str(uid), {})
    ucats = um.get("categories", set()); utopcats = um.get("top_categories", set())
    ubrands = um.get("brands", set())
    graph_rank = {iid: r for r, iid in enumerate(gi)}
    na = len(AUX_TOOLS)
    E = np.zeros((len(pool), len(CHANNELS)), dtype=np.float64)
    for r, iid in enumerate(pool):
        rk = ranks.get(iid, {})
        for c, m in enumerate(AUX_TOOLS):
            if m in rk:
                E[r, c] = 1.0 / (rk[m] + 1.0)
        E[r, na] = len(sources.get(iid, [])) / na
        im = item_meta.get(str(iid), {})
        cats = im.get("categories", set())
        E[r, na + 1] = len(cats & ucats) / max(len(cats | ucats), 1)
        E[r, na + 2] = float(len(cats & utopcats))
        gr = graph_rank.get(iid)
        E[r, na + 3] = 1.0 / (gr + 1.0) if gr is not None else 0.0
        brand = im.get("brand", "unknown")
        E[r, na + 4] = float(brand in ubrands and brand != "unknown")
    return E


# ------------------------------------------------------------------ isotonic calibration
def fit_calibrators(E_list, y_list):
    """Per-channel isotonic h_j: value -> P(pos), fit on VALIDATION pooled candidates."""
    from sklearn.isotonic import IsotonicRegression
    E = np.vstack(E_list) if E_list else np.zeros((0, len(CHANNELS)))
    y = np.concatenate(y_list) if y_list else np.zeros(0)
    cals = []
    for c in range(len(CHANNELS)):
        col = E[:, c]
        if len(col) == 0 or col.max() == col.min():
            cals.append(None); continue
        ir = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        ir.fit(col, y)
        cals.append(ir)
    return cals


def apply_calibrators(E, cals):
    H = np.zeros_like(E)
    for c in range(E.shape[1]):
        H[:, c] = E[:, c] if cals[c] is None else cals[c].predict(E[:, c])
    return H


# ------------------------------------------------------------------ shared CLI for executor hyperparameters
def add_executor_args(ap):
    """Executor hyperparameters (defaults above); use the SAME values in every stage of one run."""
    ap.add_argument("--keep", type=int, default=KEEP, help="hyperparameter: base-route head items kept")
    ap.add_argument("--budget", type=int, default=BUDGET, help="hyperparameter: max rescued items admitted")
    ap.add_argument("--aux_k", type=int, default=AUX_K, help="hyperparameter: auxiliary route depth read")
    ap.add_argument("--min_src", type=int, default=MIN_AUX_SOURCES, help="hyperparameter: agreement gate")
    ap.add_argument("--pool_limit", type=int, default=POOL_LIMIT, help="hyperparameter: max pool size")
    return ap


def pool_kwargs(args):
    return dict(aux_k=args.aux_k, min_src=args.min_src, pool_limit=args.pool_limit)
