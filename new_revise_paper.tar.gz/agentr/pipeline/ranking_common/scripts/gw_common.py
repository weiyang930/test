#!/usr/bin/env python3
"""Shared ranking-stage helpers (CPU): ranker train/dev user split, rankable users, user/item text, metrics."""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
SUB = HERE.parent.parent / "substrate_common" / "scripts"
if str(SUB) not in sys.path:
    sys.path.insert(0, str(SUB))

from pv_common import ROOT, load_frozen, all_metrics  # noqa: E402

FINAL_K = 50
SPLIT_SEED_TAG = "exp14gw"      # salt of the deterministic uid hash used for the ranker train/dev split


# --------------------------------------------------------------------- targets
def load_split_targets(ds, label):
    """held-out items with interaction.csv label == `label` (1 = validation, 2 = test)."""
    df = pd.read_csv(ROOT / "data" / ds / "interaction.csv", dtype={"userid": str, "itemid": str})
    v = df[df["label"] == label]
    return {u: [str(x) for x in g["itemid"].tolist()] for u, g in v.groupby("userid")}


def load_valid_targets(ds):
    return load_split_targets(ds, 1)


# --------------------------------------------------------------------- split / population
def uid_bucket(uid, seed_tag=SPLIT_SEED_TAG):
    """Deterministic 0..99 bucket for a user id (stable across runs / machines)."""
    h = hashlib.md5(f"{seed_tag}:{uid}".encode()).hexdigest()
    return int(h, 16) % 100


def uid_split(uid, train_frac=0.8, seed_tag=SPLIT_SEED_TAG):
    return "train" if uid_bucket(uid, seed_tag) < int(round(train_frac * 100)) else "dev"


def rankable_users(frozen_split, tgt_map, final_k=FINAL_K):
    """Users whose held-out target is inside the frozen top-50 slate."""
    out = []
    for uid, fr in frozen_split.items():
        if set(tgt_map.get(uid, [])) & set(fr["slate_order"][:final_k]):
            out.append(uid)
    return out


def gt_in_pool(fr, tgt_map, final_k=FINAL_K):
    """The held-out target id that is inside the slate, else None."""
    ts = set(tgt_map.get(fr["userid"], []))
    for iid in fr["slate_order"][:final_k]:
        if iid in ts:
            return iid
    return None


# --------------------------------------------------------------------- deterministic user profile text
def _clean_set_str(s, k=5):
    if not isinstance(s, str):
        return ""
    toks = [t for t in re.findall(r"'([^']*)'", s) if t]
    return ", ".join(toks[:k])


def user_profile_text(user_meta_u):
    """Fallback profile (used only when no LLM memory exists for a user)."""
    if not user_meta_u:
        return "No profile available."
    tb = _clean_set_str(user_meta_u.get("top_brands", ""))
    tc = _clean_set_str(user_meta_u.get("top_categories", ""))
    parts = [f"history length: {user_meta_u.get('history_len', '?')}"]
    if tc:
        parts.append(f"preferred categories: {tc}")
    if tb:
        parts.append(f"preferred brands: {tb}")
    return "; ".join(parts)
