#!/usr/bin/env python3
"""Evaluation helpers of the ranking stage (per-user metrics, aggregation, slate-invariance check)."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import gw_common as gw  # noqa: E402
from gw_common import all_metrics  # noqa: E402

PRIMARY = ["NDCG@10", "Recall@10", "NDCG@5", "Recall@5", "NDCG@50", "Recall@50", "MRR"]


def per_user_metrics(uids, finals, gt_map):
    return {u: all_metrics(finals[u], [gt_map[u]]) for u in uids}


def agg(pum, uids, keys=PRIMARY):
    return {k: float(np.mean([pum[u][k] for u in uids])) for k in keys}


def assert_r50_invariant(uids, finals, frozen):
    """Number of users whose final list is NOT a permutation of the frozen slate (must be 0)."""
    return sum(set(finals[u]) != set(frozen[u]["slate_order"]) for u in uids)
