#!/usr/bin/env python3
"""Candidate adaptation: build the FROZEN planner-conditioned top-50 slate for every validation / test user.

Each user gets w_u = Normalize(w_bar (x) expand_delta(delta_u)): the validated prior weights w_bar
(planning/scripts/run_offline.py) modulated by the Planning Agent's per-user policy delta_u
(planning/scripts/stage_planner_llm.py) and L1-renormalised to the prior mass. A missing policy or a
parse failure falls back to the neutral policy (== w_bar). The deterministic executor then builds the slate.

Writes: artifacts/frozen_<ds>.pkl = {frozen: {valid|test: {uid: slate}}, meta, titles, user_meta}

Usage: python stage1_build_planner.py --dataset Industrial_10_80_r811 [executor hyperparameters]
"""
from __future__ import annotations

import argparse
import glob
import pickle
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pr_common import (  # noqa: E402
    PLANNING_DIR, CHANNELS, AUX_TOOLS,
    load_dataset, load_item_titles, load_prior_weights, fit_hard_calibrators, build_user_frozen,
)
from pcr_common import add_executor_args, pool_kwargs  # noqa: E402

# planner trust level -> channel multiplier (hyperparameter of the policy expansion)
LEVEL = {"down": 0.5, "neutral": 1.0, "up": 2.0}
CH2KEY = {f"q_{m}": m for m in AUX_TOOLS}
CH2KEY.update({"agr": "cross_path_support", "pref": "user_preference_match"})


def expand_delta(delta):
    mult = np.ones(len(CHANNELS))
    for ci, ch in enumerate(CHANNELS):
        key = CH2KEY.get(ch)
        if key is not None and key in delta:
            mult[ci] = LEVEL.get(delta[key], 1.0)
    return mult


def load_deltas(ds):
    """{(split, uid): row} from the planner_delta_<ds>.shard*.pkl files."""
    out = {}
    for f in sorted(glob.glob(str(PLANNING_DIR / "artifacts" / f"planner_delta_{ds}.shard*.pkl"))):
        for r in pickle.load(open(f, "rb")):
            out[(r["split"], r["userid"])] = r
    return out


def user_weight(w_bar, total_mass, drow):
    if drow is None or not drow.get("parse_ok"):
        return w_bar.copy(), False
    w_u = w_bar * expand_delta(drow["delta"])
    s = w_u.sum()
    if s > 0:
        w_u = w_u * (total_mass / s)   # L1-renorm to the prior mass
    return w_u, True


def main():
    ap = add_executor_args(argparse.ArgumentParser())
    ap.add_argument("--dataset", required=True)
    args = ap.parse_args()
    ds = args.dataset
    pkw = pool_kwargs(args)

    D = load_dataset(ds)
    cached, item_meta, user_meta, dataset = D["cached"], D["item_meta"], D["user_meta"], D["dataset"]
    titles = load_item_titles(Path(D["cfg"].dataset.data_dir) / ds)
    w_bar, prior_name, _ = load_prior_weights(ds)
    total_mass = float(w_bar.sum())
    vmap = {u: [str(x) for x in v] for u, v in dataset.user_valid_items.items()}
    tmap = {u: [str(x) for x in v] for u, v in dataset.user_test_items.items()}

    print(f"[{ds}] fitting calibrators on validation ...", flush=True)
    cals = fit_hard_calibrators(cached, sorted(dataset.user_valid_items), vmap, item_meta, user_meta,
                                args.keep, **pkw)
    deltas = load_deltas(ds)
    print(f"[{ds}] loaded {len(deltas)} planner policies", flush=True)

    frozen = {"valid": {}, "test": {}}
    parse_ok = {"valid": 0, "test": 0}
    for split, tgm in (("valid", vmap), ("test", tmap)):
        for u in sorted(tgm):
            if not tgm.get(u):
                continue
            w_u, ok = user_weight(w_bar, total_mass, deltas.get((split, str(u))))
            parse_ok[split] += int(ok)
            fr = build_user_frozen(cached, u, args.keep, args.budget, w_u, cals, item_meta, user_meta, **pkw)
            if fr is not None:
                frozen[split][u] = fr
        print(f"[{ds}] {split}: users={len(frozen[split])} planner_policy_used={parse_ok[split]}", flush=True)

    meta = {"dataset": ds, "executor": vars(args), "prior_name": prior_name, "w_bar": w_bar.tolist()}
    out = HERE.parent / "artifacts" / f"frozen_{ds}.pkl"
    out.parent.mkdir(parents=True, exist_ok=True)
    pickle.dump({"frozen": frozen, "meta": meta, "titles": titles, "user_meta": user_meta}, open(out, "wb"))
    print(f"[{ds}] wrote {out}", flush=True)


if __name__ == "__main__":
    main()
