#!/usr/bin/env python3
"""Candidate adaptation -- shared library (offline, CPU).

Builds the per-user frozen top-50 slate with the planner-conditioned executor (pipeline/planning) and
records, for every slate, the base/rescued partition and the evidence of each rescued item. The slate is
the candidate set of the Residual Ranking Agent:

    slate = [base_head (keep)] + [rescued (<= budget), executor score order] + [base fillers up to 50]
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PLANNING = HERE.parent.parent / "planning" / "scripts"
if str(PLANNING) not in sys.path:
    sys.path.insert(0, str(PLANNING))

from pcr_common import (  # noqa: E402
    ROOT, AUX_TOOLS, FINAL_K, CHANNELS,
    load_dataset, build_pool, evidence_matrix, fit_calibrators, apply_calibrators,
    recall_at_k, ndcg_at_k, compose_final,
)

PLANNING_DIR = HERE.parent.parent / "planning"
EVAL_KS = [5, 10, 20, 50]


# --------------------------------------------------------------------- item titles
def load_item_titles(dataset_dir: Path) -> dict:
    """itemid -> {'title':..., 'desc':...} (short), for concise LLM presentation."""
    p = Path(dataset_dir) / "item_profile_raw.csv"
    if not p.exists():
        return {}
    df = pd.read_csv(p, usecols=lambda c: c in ("itemid", "title", "description"))
    out = {}
    for row in df.to_dict(orient="records"):
        iid = str(row.get("itemid"))
        title = str(row.get("title", "") or "")[:80]
        desc = str(row.get("description", "") or "")[:160]
        out[iid] = {"title": title, "desc": desc}
    return out


# --------------------------------------------------------------------- validated prior weights
def load_prior_weights(ds):
    """Validation-selected prior weight vector w_bar (written by planning/scripts/run_offline.py)."""
    off = json.load(open(PLANNING_DIR / "artifacts" / f"offline_{ds}.json"))
    name = off["prior_only_selected"]
    key = "valstr" if "valstr" in name else "equal"
    return np.asarray(off["calibrated_prior_weights"][key], dtype=np.float64), name, off


# --------------------------------------------------------------------- calibrators
def fit_hard_calibrators(cached, valid_users, vmap, item_meta, user_meta, keep, **pkw):
    """Per-channel isotonic calibrators on the validation candidate pools."""
    E_list, y_list = [], []
    for u in valid_users:
        gi, pool, src, rk = build_pool(cached, u, keep, **pkw)
        tg = set(vmap.get(u, []))
        if not pool or not tg:
            continue
        E_list.append(evidence_matrix(pool, u, gi, src, rk, item_meta, user_meta))
        y_list.append(np.array([float(i in tg) for i in pool]))
    return fit_calibrators(E_list, y_list)


# --------------------------------------------------------------------- frozen slate
def build_user_frozen(cached, uid, keep, budget, w_u, cals, item_meta, user_meta, **pkw):
    """Frozen top-50 slate for one user + base/rescued partition and per-rescued-item evidence."""
    gi = cached.get("graph", {}).get(uid, [])
    _, pool, sources, ranks = build_pool(cached, uid, keep, **pkw)
    if pool:
        E = evidence_matrix(pool, uid, gi, sources, ranks, item_meta, user_meta)
        scores = apply_calibrators(E, cals) @ w_u
        ranked = [i for i, _ in sorted(zip(pool, scores), key=lambda p: (-float(p[1]), p[0]))]
        score_map = {i: float(s) for i, s in zip(pool, scores)}
    else:
        ranked, score_map = [], {}

    # partition exactly as compose_final builds the slate
    base_top, seen = [], set()
    for iid in gi[:keep]:
        if iid not in seen:
            base_top.append(iid); seen.add(iid)
    rescued = []
    for iid in ranked[:budget]:
        if iid not in seen:
            rescued.append(iid); seen.add(iid)
        if len(base_top) + len(rescued) >= FINAL_K:
            break
    tail = []
    for iid in gi:
        if len(base_top) + len(rescued) + len(tail) >= FINAL_K:
            break
        if iid not in seen:
            tail.append(iid); seen.add(iid)
    backbone = base_top + tail                      # base items, base order
    order = base_top + rescued + tail               # the frozen slate (executor order)
    rank_of = {iid: r for r, iid in enumerate(order)}

    um = user_meta.get(str(uid), {})
    resc_info = []
    for iid in rescued:
        rk = ranks.get(iid, {})
        srcs = sources.get(iid, [])
        im = item_meta.get(str(iid), {})
        cats = im.get("categories", set()); ucats = um.get("categories", set())
        resc_info.append({
            "item_id": iid,
            "intervention_score": score_map.get(iid, 0.0),
            "current_rank": rank_of[iid] + 1,
            "source_routes": list(srcs),
            "route_ranks": {m: int(rk[m]) + 1 for m in rk},
            "cross_path_support": len(srcs),
            "pref_jaccard": round(len(cats & ucats) / max(len(cats | ucats), 1), 3),
            "brand_match": bool(im.get("brand", "unknown") in um.get("brands", set())
                                and im.get("brand", "unknown") != "unknown"),
            "category": sorted(cats)[:3],
            "brand": im.get("brand", "unknown"),
        })
    return {
        "userid": uid,
        "backbone": backbone,           # base items, base order
        "rescued": rescued,             # admitted complementary items, executor order
        "resc_info": resc_info,
        "slate_order": order,           # the frozen slate
        "n_base": len(backbone), "n_rescued": len(rescued),
        "keep_slot": len(base_top),
    }


# --------------------------------------------------------------------- metrics
def mrr(preds, targets):
    ts = set(str(t) for t in targets)
    for r, i in enumerate(preds):
        if str(i) in ts:
            return 1.0 / (r + 1)
    return 0.0


def all_metrics(preds, targets):
    tg = [str(t) for t in targets]
    out = {}
    for k in EVAL_KS:
        out[f"Recall@{k}"] = recall_at_k(preds, tg, k)
        out[f"NDCG@{k}"] = ndcg_at_k(preds, tg, k)
    out["MRR"] = mrr(preds, tg)
    return out
