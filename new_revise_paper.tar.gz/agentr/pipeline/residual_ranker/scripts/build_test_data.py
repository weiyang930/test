#!/usr/bin/env python3
"""Build the full-50 residual-ranking records of TEST users (test target inside the frozen slate), with
exactly the same prompt construction as build_residual_data.py. Prior B is NOT refit (train-only prior).
Appends recs["test"] to data/<ds>/residual_users.pkl. Run after model selection on ranker-dev users.

Usage: python build_test_data.py --ds Industrial_10_80_r811
"""
from __future__ import annotations

import argparse
import pickle
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402


def load_test_targets(ds):
    return rr.gw.load_split_targets(ds, 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    args = ap.parse_args()

    blob = rr.gw.load_frozen(args.ds)
    frozen_t, titles, user_meta = blob["frozen"]["test"], blob["titles"], blob["user_meta"]
    tgt = load_test_targets(args.ds)
    recs_test = []
    for uid in rr.gw.rankable_users(frozen_t, tgt):
        fr = frozen_t[uid]
        gt = rr.gw.gt_in_pool(fr, tgt)
        tag = {uid: "rescued" if gt in set(fr["rescued"]) else "base"}
        rec = rr.user_record(uid, fr, user_meta.get(uid, {}), titles, {uid: gt}, tag, args.ds)
        if rec["gt_idx"] >= 0:
            recs_test.append(rec)

    pkl = rr.DATA_DIR / args.ds / "residual_users.pkl"
    recs = pickle.load(open(pkl, "rb"))
    recs["test"] = recs_test
    pickle.dump(recs, open(pkl, "wb"))
    print(f"[write] recs['test']={len(recs_test)} -> {pkl}")


if __name__ == "__main__":
    main()
