#!/usr/bin/env python3
"""Model selection on ranker-dev users: pick the (checkpoint, prior, alpha) with the highest dev NDCG@10
over all artifacts/<prefix>*/eval.json produced by `eval_residual.py --split dev`.

Usage: python select_dev.py --prefix <tag>_s  -> prints "<ckpt> <prior> <alpha>"
"""
import argparse
import glob
import json
from pathlib import Path

ART = Path(__file__).resolve().parent.parent / "artifacts"
ap = argparse.ArgumentParser()
ap.add_argument("--prefix", required=True)
a = ap.parse_args()
best = None
for f in sorted(glob.glob(str(ART / f"{a.prefix}*" / "eval.json"))):
    d = json.load(open(f))
    if d.get("split") != "dev" or not d.get("selected"):
        continue
    s = d["selected"]
    if best is None or s["agg"]["NDCG@10"] > best[3]:
        best = (d["ckpt"], s["prior"], s["alpha"], s["agg"]["NDCG@10"])
assert best, f"no dev eval.json under {ART}/{a.prefix}*"
print(best[0], best[1], best[2])
