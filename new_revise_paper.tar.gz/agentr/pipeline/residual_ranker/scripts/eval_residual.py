#!/usr/bin/env python3
"""Score one Residual Ranking Agent checkpoint.

The residual r_u(i) is prior- and alpha-independent, so the 50 cross-encoder forward passes are run once
per user and cached; priors {A, B} x alpha (rr.ALPHA_GRID) are then swept on CPU by re-sorting the SAME
frozen slate with s = prior + alpha * r (alpha = 0 reproduces the slate exactly; asserted).

  --split dev  : ranker-dev users; selects (prior, alpha) by NDCG@10 (alpha > 0) -> artifacts/<tag>/eval.json
  --split test : TEST users with the configuration pinned by --fixed_prior / --fixed_alpha (no re-selection)
Writes artifacts/<tag>/residual_cache_<split>.pkl and eval.json.

Usage:
  python eval_residual.py --ds Industrial_10_80_r811 --ckpt ../checkpoints/<tag>/step_<n> --tag <tag>_s<n>_dev --split dev
  python eval_residual.py --ds Industrial_10_80_r811 --ckpt <selected ckpt> --tag <tag>_test --split test \
         --fixed_prior <A|B> --fixed_alpha <alpha>
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402
from train_residual import Ranker  # noqa: E402

ge = rr.ge


def load_ckpt(ckpt_dir, device):
    from transformers import AutoModel, AutoTokenizer
    cfg = json.load(open(Path(ckpt_dir) / "config.json"))
    tok = AutoTokenizer.from_pretrained(cfg["base_model"], trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"
    try:
        base = AutoModel.from_pretrained(cfg["base_model"], torch_dtype=torch.bfloat16,
                                         attn_implementation="flash_attention_2", trust_remote_code=True)
    except Exception as e:
        print(f"[warn] flash_attention_2 unavailable ({e}); falling back to sdpa")
        base = AutoModel.from_pretrained(cfg["base_model"], torch_dtype=torch.bfloat16,
                                         attn_implementation="sdpa", trust_remote_code=True)
    from peft import PeftModel
    base = PeftModel.from_pretrained(base, Path(ckpt_dir) / "adapter").merge_and_unload()
    model = Ranker(base).to(device).eval()
    model.head.load_state_dict(torch.load(Path(ckpt_dir) / "head.pt", map_location=device))
    return model, tok, cfg


@torch.no_grad()
def compute_residuals(model, tok, recs, device, max_len, batch=128):
    """{uid: np.array(50)} residuals; one forward per (user, candidate)."""
    flat, index = [], []
    for rec in recs:
        for pos, p in enumerate(rec["prompts"]):
            flat.append(tok.apply_chat_template([{"role": "user", "content": p}],
                                                add_generation_prompt=True, tokenize=False))
            index.append((rec["uid"], pos))
    res = {rec["uid"]: np.zeros(len(rec["prompts"]), np.float32) for rec in recs}
    t0 = time.time()
    for i in range(0, len(flat), batch):
        enc = tok(flat[i:i + batch], return_tensors="pt", padding=True, truncation=True, max_length=max_len)
        r, _ = model(enc["input_ids"].to(device), enc["attention_mask"].to(device))
        for j, val in enumerate(r.float().cpu().numpy()):
            uid, pos = index[i + j]
            res[uid][pos] = val
        if (i // batch) % 50 == 0:
            print(f"  residuals {i}/{len(flat)} ({time.time() - t0:.0f}s)", flush=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--split", default="dev", choices=["dev", "test"])
    ap.add_argument("--priors", nargs="+", default=["A", "B"])
    ap.add_argument("--fixed_prior", default=None, choices=[None, "A", "B"])
    ap.add_argument("--fixed_alpha", type=float, default=None)
    ap.add_argument("--batch", type=int, default=128)
    args = ap.parse_args()
    if args.split == "test":
        assert args.fixed_prior and args.fixed_alpha is not None, "TEST requires --fixed_prior/--fixed_alpha"

    recs = pickle.load(open(rr.DATA_DIR / args.ds / "residual_users.pkl", "rb"))[args.split]
    uids = [r["uid"] for r in recs]
    gt_map = {r["uid"]: r["gt_id"] for r in recs}
    frozen = {r["uid"]: {"slate_order": r["cand_ids"]} for r in recs}
    priorB = rr.PriorB(json.load(open(rr.DATA_DIR / args.ds / "priorB.json"))["score_by_rank"])

    outd = HERE.parent / "artifacts" / args.tag
    outd.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda", 0)
    model, tok, cfg = load_ckpt(args.ckpt, device)
    residuals = compute_residuals(model, tok, recs, device, cfg["max_len"], args.batch)
    pickle.dump(residuals, open(outd / f"residual_cache_{args.split}.pkl", "wb"))

    def finals_for(which, alpha):
        return {r["uid"]: rr.fused_order(r["cand_ids"], rr.prior_vec(r["base_rank"], which, priorB),
                                         residuals[r["uid"]], alpha) for r in recs}

    if args.split == "test":
        configs = [(args.fixed_prior, args.fixed_alpha)]
    else:
        configs = [(p, a) for p in args.priors for a in rr.ALPHA_GRID]
    sweep, best = [], None
    for which, alpha in configs:
        finals = finals_for(which, alpha)
        if alpha == 0.0:
            assert all(finals[u] == frozen[u]["slate_order"] for u in uids), "alpha=0 must reproduce the slate"
        assert ge.assert_r50_invariant(uids, finals, frozen) == 0
        a = ge.agg(ge.per_user_metrics(uids, finals, gt_map), uids)
        sweep.append({"prior": which, "alpha": alpha, **a})
        if (args.split == "test" or alpha > 0) and (best is None or a["NDCG@10"] > best["agg"]["NDCG@10"]):
            best = {"prior": which, "alpha": alpha, "agg": a}

    json.dump({"tag": args.tag, "ckpt": args.ckpt, "split": args.split, "n_users": len(uids), "config": cfg,
               "selected": best, "sweep": sweep}, open(outd / "eval.json", "w"), indent=2)
    print(f"[{args.split}] selected prior={best['prior']} alpha={best['alpha']} -> {outd}/eval.json")


if __name__ == "__main__":
    main()
