#!/usr/bin/env python3
"""Residual Ranking Agent -- shared CPU library (model-agnostic).

Qwen2.5-7B-Instruct is used as a CROSS-ENCODER, not as a generator. For each (user, candidate) pair we
build one concise prompt, run a single forward pass, pool the last non-pad hidden state h_{u,i}, and a
trainable scalar head gives q = w.h + b and the residual r = tanh(q) in [-1, 1]. The final ranking score is

    s_u(i) = p_u(i) + alpha * r_u(i),

where p_u(i) is a frozen recommendation prior that exactly reproduces the slate order at alpha = 0. The
same frozen top-50 slate is re-sorted, so Recall@50 is invariant by construction.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
RC = HERE.parent.parent / "ranking_common" / "scripts"
if str(RC) not in sys.path:
    sys.path.insert(0, str(RC))

import gw_common as gw            # noqa: E402
import gw_eval as ge              # noqa: E402

FINAL_K = 50
REPO = HERE.parent.parent.parent
DATA_DIR = Path(os.environ.get("AGENTR_DATA_DIR") or str(HERE.parent / "data"))


# --------------------------------------------------------------------- substrate + split
def load_substrate(ds):
    """Return (frozen_valid, titles, user_meta, split) with split = data/<ds>/splits.json (build_splits.py)."""
    blob = gw.load_frozen(ds)
    split = json.load(open(DATA_DIR / ds / "splits.json"))
    return blob["frozen"]["valid"], blob["titles"], blob["user_meta"], split


# --------------------------------------------------------------------- priors
def base_ranks(fr, final_k=FINAL_K):
    """1-indexed slate rank of each candidate: {iid: rank}."""
    return {iid: k + 1 for k, iid in enumerate(fr["slate_order"][:final_k])}


def prior_A(rank, final_k=FINAL_K):
    """Normalised rank prior p = -(r-1)/(K-1) in [-1, 0]; exact monotone order."""
    return -(rank - 1) / (final_k - 1)


class PriorB:
    """Empirical calibrated rank prior: isotonic P(target | slate rank) fit on RANKER-TRAIN users only,
    converted to a clipped logit and min-max mapped to [-1, 0] (monotone, same scale as prior A)."""

    def __init__(self, score_by_rank):
        self.score_by_rank = {int(k): float(v) for k, v in score_by_rank.items()}
        self._max_rank = max(self.score_by_rank)

    @staticmethod
    def fit(train_uids, frozen_v, gt_map, final_k=FINAL_K, clip=(1e-4, 1 - 1e-4)):
        from sklearn.isotonic import IsotonicRegression
        ranks, ys = [], []
        for u in train_uids:
            for iid, r in base_ranks(frozen_v[u], final_k).items():
                ranks.append(r)
                ys.append(1.0 if iid == gt_map[u] else 0.0)
        iso = IsotonicRegression(increasing=False, out_of_bounds="clip", y_min=0.0, y_max=1.0)
        iso.fit(np.asarray(ranks, float), np.asarray(ys, float))
        grid = np.arange(1, final_k + 1, dtype=float)
        p = np.clip(iso.predict(grid), clip[0], clip[1])
        logit = np.log(p / (1 - p))
        lo, hi = logit.min(), logit.max()
        norm = (logit - lo) / (hi - lo + 1e-12) - 1.0
        return PriorB({int(r): float(s) for r, s in zip(grid, norm)})

    def score(self, rank):
        return self.score_by_rank[int(min(max(rank, 1), self._max_rank))]

    def to_json(self):
        return {"type": "isotonic_calibrated_rank_prior", "score_by_rank": self.score_by_rank}


def prior_vec(base_rank, which, priorB=None):
    if which == "A":
        return np.array([prior_A(rk) for rk in base_rank], float)
    return np.array([priorB.score(rk) for rk in base_rank], float)


# --------------------------------------------------------------------- Memory Agent profile
_LLM_MEM_CACHE = {}


def _load_llm_memory(ds, model_tag="qwen2p5_7b_instruct"):
    """STM/LTM memory built by scripts/build_llm_user_memory.py."""
    if ds not in _LLM_MEM_CACHE:
        p = REPO / "outputs" / "indexes" / ds / f"user_memory_llm_agent_{model_tag}.json"
        if not p.exists():
            raise FileNotFoundError(f"LLM user memory not found: {p} (run scripts/build_llm_user_memory.py)")
        blob = json.load(open(p))
        _LLM_MEM_CACHE[ds] = blob.get("users", blob) if isinstance(blob, dict) else blob
    return _LLM_MEM_CACHE[ds]


def llm_profile_text(st):
    """Compact render of an STM/LTM memory record into the ranker prompt's profile line."""
    if not st:
        return "No profile available."

    def j(x, n=5):
        return ", ".join(str(v) for v in x[:n]) if isinstance(x, list) else ""
    parts = []
    for key, label in (("short_term_intents", "recent intents"), ("long_term_categories", "long-term categories"),
                       ("long_term_brands", "preferred brands"), ("stable_preferences", "stable preferences")):
        v = j(st.get(key, []))
        if v:
            parts.append(f"{label}: {v}")
    return "; ".join(parts) if parts else "No profile available."


def profile_text_for(uid, um, ds):
    st = _load_llm_memory(ds).get(str(uid))
    return llm_profile_text(st) if st is not None else gw.user_profile_text(um)


# --------------------------------------------------------------------- cross-encoder prompt
def _fmt_routes(route_ranks):
    if not isinstance(route_ranks, dict) or not route_ranks:
        return ""
    return ", ".join(f"{k}#{v}" for k, v in route_ranks.items())


def candidate_prompt(iid, rank, titles, resc_map, prof_text, final_k=FINAL_K):
    """Concise cross-encoder text for ONE (user, candidate) pair: user memory profile, candidate
    title/brand/description and recommender evidence (normalised slate rank, base/rescued provenance,
    retrieval routes + ranks, cross-route support, calibrated intervention score, brand match).
    No label and no future interaction is used."""
    t = titles.get(iid, {}) or {}
    title = (t.get("title") or f"item {iid}").strip()
    desc = (t.get("desc") or "").replace("\n", " ").strip()
    if len(desc) > 120:
        desc = desc[:120].rstrip() + "..."
    ri = resc_map.get(iid)
    brand = (ri or {}).get("brand", "") or ""
    cand = f"{title}" + (f" (brand: {brand})" if brand else "") + (f" -- {desc}" if desc else "")
    nb = (rank - 1) / (final_k - 1)
    ev = [f"base rank {rank}/{final_k} (normalized {nb:.2f})"]
    if ri is not None:
        ev.append("provenance: rescued/complementary candidate")
        rr = _fmt_routes(ri.get("route_ranks"))
        if rr:
            ev.append(f"retrieval routes (rank per source): {rr}")
        ev.append(f"cross-route support: {ri.get('cross_path_support', 0)}")
        ev.append(f"calibrated intervention score: {float(ri.get('intervention_score', 0.0)):.3f}")
        ev.append("brand matches user history: " + ("yes" if ri.get("brand_match") else "no"))
    else:
        ev.append("provenance: base recommender candidate")
    return (
        "You are a recommendation ranking expert judging one candidate for a user.\n"
        f"User profile: {prof_text}\n"
        f"Candidate item: {cand}\n"
        f"Recommender evidence: {'; '.join(ev)}\n"
        "Assess how likely this candidate is the user's next interaction."
    )


def user_record(uid, fr, um, titles, gt_map, tag_map, ds, final_k=FINAL_K):
    """One user's full-50 ranking problem."""
    order = fr["slate_order"][:final_k]
    resc_map = {r["item_id"]: r for r in fr["resc_info"]}
    br = base_ranks(fr, final_k)
    prof = profile_text_for(uid, um, ds)
    gt = gt_map[uid]
    return {
        "uid": uid,
        "cand_ids": order,
        "base_rank": [br[iid] for iid in order],
        "gt_id": gt,
        "gt_idx": order.index(gt) if gt in order else -1,
        "tag": tag_map.get(uid, "base"),
        "prompts": [candidate_prompt(iid, br[iid], titles, resc_map, prof, final_k) for iid in order],
    }


# --------------------------------------------------------------------- fused scoring
def fused_order(cand_ids, prior_vec_, residual_vec, alpha):
    """Sort candidates by s = prior + alpha * residual (desc); ties keep the slate order."""
    s = prior_vec_ + alpha * np.asarray(residual_vec, float)
    idx = sorted(range(len(cand_ids)), key=lambda k: (-s[k], k))
    return [cand_ids[k] for k in idx]


# alpha grid searched on the ranker-dev users (hyperparameter)
ALPHA_GRID = [0.0, 0.01, 0.02, 0.05, 0.10, 0.20, 0.30, 0.50, 0.75, 1.0]
