#!/usr/bin/env python3
"""Full-test-population evaluation of Agent-R.

Every official TEST user (interaction.csv label == 2) is scored on the final top-50 list:
  * users whose target is in the frozen slate -> slate re-sorted by the Residual Ranking Agent
    (pinned prior / alpha; residuals from eval_residual.py --split test);
  * all other users -> the frozen planner-conditioned slate (their target is not retrieved -> 0).
Metrics NDCG@{10,50} and Recall@{10,50}, plain mean over the complete test population.
Writes pipeline/residual_ranker/artifacts/<tag>/fulltest.json (+ per-user CSV).

Usage: python evaluate_fulltest.py --ds Industrial_10_80_r811 --tag <test tag> --prior <A|B> --alpha <alpha>
"""
from __future__ import annotations

import argparse
import csv
import json
import pickle
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402
from build_test_data import load_test_targets  # noqa: E402

MAIN_KS = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--prior", required=True, choices=["A", "B"])
    ap.add_argument("--alpha", type=float, required=True)
    args = ap.parse_args()

    frozen_t = rr.gw.load_frozen(args.ds)["frozen"]["test"]
    pop = list(frozen_t.keys())
    tmap = load_test_targets(args.ds)
    recs = pickle.load(open(rr.DATA_DIR / args.ds / "residual_users.pkl", "rb"))["test"]
    outd = HERE.parent / "artifacts" / args.tag
    residuals = pickle.load(open(outd / "residual_cache_test.pkl", "rb"))
    priorB = rr.PriorB(json.load(open(rr.DATA_DIR / args.ds / "priorB.json"))["score_by_rank"])
    finals = {r["uid"]: rr.fused_order(r["cand_ids"], rr.prior_vec(r["base_rank"], args.prior, priorB),
                                       residuals[r["uid"]], args.alpha) for r in recs}

    pum = {u: rr.gw.all_metrics(finals.get(u, list(frozen_t[u]["slate_order"])), tmap.get(u, [])) for u in pop}
    agg = {k: float(np.mean([pum[u][k] for u in pop])) for k in MAIN_KS}
    json.dump({"dataset": args.ds, "tag": args.tag, "prior": args.prior, "alpha": args.alpha,
               "n_test_population": len(pop), "metrics": agg}, open(outd / "fulltest.json", "w"), indent=2)
    with open(outd / "fulltest_per_user.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["uid"] + MAIN_KS)
        for u in pop:
            w.writerow([u] + [f"{pum[u][k]:.6f}" for k in MAIN_KS])
    print(json.dumps(agg))
    print(f"[write] {outd}/fulltest.json")


if __name__ == "__main__":
    main()
