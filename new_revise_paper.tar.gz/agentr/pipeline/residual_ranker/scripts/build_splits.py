#!/usr/bin/env python3
"""Ranker train/dev split on the VALIDATION slates: rankable validation users (validation target inside
the frozen top-50 slate), split 80/20 by a deterministic uid hash. Records the target id and whether it is
a base or a rescued item. Test labels are never used. Writes data/<ds>/splits.json.

Usage: python build_splits.py --ds Industrial_10_80_r811
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--train_frac", type=float, default=0.8)
    args = ap.parse_args()

    frozen_v = rr.gw.load_frozen(args.ds)["frozen"]["valid"]
    vtgt = rr.gw.load_valid_targets(args.ds)
    splits, gt_map, tag_map = {"train": [], "dev": []}, {}, {}
    for uid in rr.gw.rankable_users(frozen_v, vtgt):
        fr = frozen_v[uid]
        gt = rr.gw.gt_in_pool(fr, vtgt)
        if gt is None:
            continue
        gt_map[uid] = gt
        tag_map[uid] = "rescued" if gt in set(fr["rescued"]) else "base"
        splits[rr.gw.uid_split(uid, args.train_frac)].append(uid)
    print(f"[split] train={len(splits['train'])} dev={len(splits['dev'])}")

    outd = rr.DATA_DIR / args.ds
    outd.mkdir(parents=True, exist_ok=True)
    json.dump({"train": splits["train"], "dev": splits["dev"], "gt": gt_map, "tag": tag_map,
               "config": {"ds": args.ds, "train_frac": args.train_frac}}, open(outd / "splits.json", "w"))
    print(f"[write] {outd}/splits.json")


if __name__ == "__main__":
    main()
