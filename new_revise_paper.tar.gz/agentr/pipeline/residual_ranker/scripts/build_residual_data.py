#!/usr/bin/env python3
"""Build the full-50 residual-ranking data for ranker-train / ranker-dev users: for every user, 50
cross-encoder prompts (one per slate candidate), the slate ranks and the target index. Fits Prior B on
ranker-train users only. Test labels are never used. Writes:
  data/<ds>/residual_users.pkl   {"train": [rec...], "dev": [rec...]}
  data/<ds>/priorB.json

Usage: python build_residual_data.py --ds Industrial_10_80_r811
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    args = ap.parse_args()

    frozen_v, titles, user_meta, split = rr.load_substrate(args.ds)
    gt_map, tag_map = split["gt"], split["tag"]
    priorB = rr.PriorB.fit(split["train"], frozen_v, gt_map)
    outd = rr.DATA_DIR / args.ds
    outd.mkdir(parents=True, exist_ok=True)
    json.dump(priorB.to_json(), open(outd / "priorB.json", "w"), indent=1)

    recs = {"train": [], "dev": []}
    for spl in ("train", "dev"):
        for uid in split[spl]:
            rec = rr.user_record(uid, frozen_v[uid], user_meta.get(uid, {}), titles, gt_map, tag_map, args.ds)
            if rec["gt_idx"] >= 0:
                recs[spl].append(rec)
    for spl in ("train", "dev"):
        for rec in recs[spl]:
            assert rec["cand_ids"][rec["gt_idx"]] == rec["gt_id"] and len(rec["cand_ids"]) == rr.FINAL_K
    pickle.dump(recs, open(outd / "residual_users.pkl", "wb"))
    print(f"[recs] train={len(recs['train'])} dev={len(recs['dev'])} -> {outd}/residual_users.pkl")


if __name__ == "__main__":
    main()
