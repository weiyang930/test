#!/usr/bin/env python3
"""Frozen candidate substrate access (CPU): the planner-conditioned top-50 slates built by
candidate_adaptation/scripts/stage1_build_planner.py."""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CAND = HERE.parent.parent / "candidate_adaptation" / "scripts"
if str(CAND) not in sys.path:
    sys.path.insert(0, str(CAND))

from pr_common import (  # noqa: E402
    ROOT, FINAL_K, EVAL_KS, load_dataset, load_item_titles, all_metrics, recall_at_k, ndcg_at_k, mrr,
)

CAND_DIR = HERE.parent.parent / "candidate_adaptation"


def load_frozen(ds):
    """frozen_<ds>.pkl -> {frozen: {split: {uid: slate}}, titles, user_meta, meta}."""
    p = CAND_DIR / "artifacts" / f"frozen_{ds}.pkl"
    if not p.exists():
        raise FileNotFoundError(f"frozen substrate not found: {p}\n"
                                f"Build it with candidate_adaptation/scripts/stage1_build_planner.py --dataset {ds}")
    return pickle.load(open(p, "rb"))
