#!/usr/bin/env python3
"""Popularity and Mem-Ret retrieval routes -> toolcache_popularity.pkl / toolcache_mem.pkl
(same schema as the RecBole routes).

* Popularity: items ranked by their number of TRAIN interactions (train-seen items masked per user).
* Mem-Ret (memory retrieval): every item gets a rule-based textual item memory (title / brand / price /
  categories parsed from item_profile.csv); every user gets a rule-based short-term memory (STM: the
  most recent train items) and long-term memory (LTM: frequent categories / brands and representative
  items). STM and LTM texts are encoded as queries, item memories as passages, with a frozen text
  encoder (default intfloat/e5-base-v2, mean pooling, L2 normalised). The user's item score is
  max(stm_weight * cos(STM, item), ltm_weight * cos(LTM, item)); train-seen items are masked.

Usage:
  python build_aux_routes.py --ds Industrial_10_80_r811 [--gpu 0]
"""
from __future__ import annotations

import argparse
import pickle
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Sequence

import numpy as np
import torch
import torch.nn.functional as F

REPO = Path(__file__).resolve().parents[3]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
from src.common.artifacts import ArtifactManager      # noqa: E402
from src.common.config import config_path_for, load_config  # noqa: E402
from src.data.dataset import DatasetLoader            # noqa: E402

DEFAULT_OUT = Path(__file__).resolve().parents[1] / "artifacts" / "route_cache"

# ---------------------------------------------------------------- Mem-Ret hyperparameters (defaults)
MAX_HISTORY_LEN = 50          # history window used to build user memories
SHORT_WINDOW = 5              # items in the short-term memory
LONG_TOP_CATEGORIES = 5
LONG_TOP_BRANDS = 5
LONG_MAX_REPR_ITEMS = 20
STM_WEIGHT = 1.0              # query weights of the two memory routes
LTM_WEIGHT = 0.8
UNKNOWN_TOKENS = {"", "unknown", "none", "nan", "null"}


# ---------------------------------------------------------------- text encoder (mean pooling, L2 norm)
class TextEncoder:
    def __init__(self, model_name, device, batch_size=512, max_length=256):
        from transformers import AutoModel, AutoTokenizer
        self.tok = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(device).eval()
        self.device, self.batch_size, self.max_length = device, batch_size, max_length

    @torch.no_grad()
    def encode(self, texts: Sequence[str]) -> np.ndarray:
        out = []
        for s in range(0, len(texts), self.batch_size):
            inp = self.tok(list(texts[s:s + self.batch_size]), padding=True, truncation=True,
                           max_length=self.max_length, return_tensors="pt").to(self.device)
            h = self.model(**inp).last_hidden_state
            m = inp["attention_mask"].unsqueeze(-1).expand(h.size()).float()
            pooled = (h * m).sum(1) / torch.clamp(m.sum(1), min=1e-9)
            out.append(F.normalize(pooled, p=2, dim=1).cpu().numpy().astype(np.float32))
        return np.concatenate(out, 0)


def e5_prefix(text, kind, model_name):
    """e5 models expect 'query: ' / 'passage: ' prefixes."""
    text = str(text or "").strip()
    if not text:
        return ""
    if "e5" not in model_name.lower():
        return text
    prefix = "query" if kind == "query" else "passage"
    return text if text.lower().startswith(f"{prefix}:") else f"{prefix}: {text}"


# ---------------------------------------------------------------- item profile parsing
def clean_value(text) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def extract_profile_field(profile: str, aliases: Sequence[str]) -> str:
    delimiter = r"(?:^|[,;\n]|\.\s+)"
    terminator = r"(?=(?:[,;\n]|\.\s+)[a-zA-Z_ ]+\s*(?:is|:)\s+|$)"
    for alias in aliases:
        patterns = [
            rf"{delimiter}\s*{re.escape(alias)}\s+is\s+(.*?){terminator}",
            rf"{delimiter}\s*{re.escape(alias)}\s*:\s*(.*?){terminator}",
        ]
        for pattern in patterns:
            match = re.search(pattern, profile, flags=re.IGNORECASE)
            if match:
                value = clean_value(match.group(1).rstrip('.'))
                if value:
                    return value
    return ""


def parse_profile_kv(profile: str) -> Dict[str, str]:
    fields: Dict[str, str] = {}
    for key in ["item_name", "brand_name", "item_price", "category_name", "first_category_name",
                "second_category_name", "third_category_name", "fourth_category_name", "description"]:
        match = re.search(rf"{key} is (.*?)(?:, [a-z_]+ is |$)", profile)
        fields[key] = clean_value(match.group(1) if match else "")
    return fields


def parse_item_fields(profile: str) -> Dict[str, str]:
    parsed = parse_profile_kv(profile)
    title = clean_value(extract_profile_field(profile, ["title", "item_name", "name"]) or parsed.get("item_name", ""))
    brand = clean_value(extract_profile_field(profile, ["brand", "brand_name", "manufacturer"]) or parsed.get("brand_name", ""))
    price = clean_value(extract_profile_field(profile, ["price", "item_price", "list_price"]) or parsed.get("item_price", ""))
    description = clean_value(extract_profile_field(profile, ["description", "desc", "item_description"])
                              or parsed.get("description", ""))
    category_path = clean_value(extract_profile_field(profile, ["categories", "category_name", "category_path"])
                                or parsed.get("category_name", ""))
    if not category_path:
        parts = [clean_value(parsed.get(k, "")) for k in
                 ("first_category_name", "second_category_name", "third_category_name", "fourth_category_name")]
        parts = [p for p in parts if p]
        if parts:
            category_path = " > ".join(parts)
    return {"title": title, "brand": brand, "price": price, "categories": category_path, "description": description}


def item_memory_text(fields: Dict[str, str]) -> str:
    lines = []
    for key in ["title", "brand", "price", "categories"]:
        value = clean_value(fields.get(key, ""))
        if value:
            lines.append(f"{key}: {value}")
    return "\n".join(lines)


# ---------------------------------------------------------------- user memories (rule-based)
def stm_text(history: Sequence[str], item_fields: Dict[str, Dict[str, str]]) -> str:
    window = [i for i in history[-SHORT_WINDOW:] if i in item_fields]
    lines = ["Recent interests:"]
    for idx, iid in enumerate(window, start=1):
        f = item_fields.get(iid, {})
        title = clean_value(f.get("title", "")) or iid
        brand = clean_value(f.get("brand", "")) or "unknown"
        cats = clean_value(f.get("categories", "")) or "unknown"
        price = clean_value(f.get("price", "")) or "unknown"
        lines.append(f"{idx}. {title} | {brand} | {cats} | ${price}")
    return "\n".join(lines) if len(lines) > 1 else "Recent interests:\nnone"


def ltm_text(history: Sequence[str], item_fields: Dict[str, Dict[str, str]]) -> str:
    cat_c, brand_c = Counter(), Counter()
    titles, seen = [], set()
    for iid in history:
        f = item_fields.get(iid, {})
        cats, brand, title = clean_value(f.get("categories", "")), clean_value(f.get("brand", "")), clean_value(f.get("title", ""))
        if cats:
            parts = [p.strip() for p in cats.split(">") if p.strip()]
            cat_c.update(parts[-2:] if len(parts) >= 2 else parts)
        if brand:
            brand_c.update([brand])
        if title and title.lower() not in seen:
            seen.add(title.lower())
            titles.append(title)
    top_c = [v for v, _ in cat_c.most_common(LONG_TOP_CATEGORIES)]
    top_b = [v for v, _ in brand_c.most_common(LONG_TOP_BRANDS)]
    reps = titles[-LONG_MAX_REPR_ITEMS:]
    return "\n".join([
        "Long-term preferences:",
        f"Frequent categories: {'; '.join(top_c) if top_c else 'none'}",
        f"Frequent brands: {'; '.join(top_b) if top_b else 'none'}",
        f"Representative items: {'; '.join(reps) if reps else 'none'}",
    ])


# ---------------------------------------------------------------- routes
def popularity_route(dataset, users, topn):
    counter = Counter([x.itemid for x in dataset.split.train])
    ranking = counter.most_common()
    out = {}
    for u in users:
        banned = dataset.user_train_items.get(u, set())
        items, scores = [], []
        for iid, c in ranking:
            if iid in banned:
                continue
            items.append(iid); scores.append(float(c))
            if len(items) >= topn:
                break
        out[u] = {"items": items, "scores": scores}
    return out


def mem_route(dataset, users, topn, encoder_name, device, batch_users=4096):
    hist = defaultdict(list)
    for x in dataset.split.train:
        hist[x.userid].append((x.timestamp, x.itemid))
    histories = {u: [i for _, i in sorted(v, key=lambda t: t[0])][-MAX_HISTORY_LEN:] for u, v in hist.items()}
    inter_items = {x.itemid for x in dataset.split.train + dataset.split.valid + dataset.split.test}
    item_ids = sorted(inter_items | set(dataset.item_profiles)) if inter_items else sorted(dataset.item_profiles)
    pos = {iid: k for k, iid in enumerate(item_ids)}
    item_fields = {iid: parse_item_fields(dataset.item_profiles.get(iid, "")) for iid in item_ids}

    enc = TextEncoder(encoder_name, device)
    print(f"[mem] encoding {len(item_ids)} item memories", flush=True)
    I = torch.as_tensor(enc.encode([e5_prefix(item_memory_text(item_fields[i]), "passage", encoder_name)
                                    for i in item_ids]), device=device)

    # user STM / LTM query texts (users without train history get no Mem-Ret candidates)
    stm = {u: stm_text(h, item_fields) for u, h in histories.items() if h}
    ltm = {u: ltm_text(h, item_fields) for u, h in histories.items() if h}
    uniq = list(dict.fromkeys([t for u in histories if u in stm for t in (stm[u], ltm[u])]))
    print(f"[mem] encoding {len(uniq)} user memory queries", flush=True)
    qemb = dict(zip(uniq, enc.encode([e5_prefix(t, "query", encoder_name) for t in uniq])))

    cand_limit = max(100, topn * 2, 50)      # candidates kept per memory route before merging
    out = {}
    for s in range(0, len(users), batch_users):
        chunk = users[s:s + batch_users]
        parts = [[] for _ in chunk]
        for texts, w in (([stm.get(u, "") for u in chunk], STM_WEIGHT), ([ltm.get(u, "") for u in chunk], LTM_WEIGHT)):
            rows = [k for k, t in enumerate(texts) if t]
            if not rows:
                continue
            Q = torch.as_tensor(np.stack([qemb[texts[k]] for k in rows]), device=device)
            sc = (Q @ I.T) * w
            v, ix = torch.topk(sc, k=min(cand_limit, sc.shape[1]), dim=1)
            v, ix = v.cpu().numpy(), ix.cpu().numpy()
            for j, k in enumerate(rows):
                parts[k].append((ix[j], v[j]))
        for k, u in enumerate(chunk):
            if not parts[k]:
                out[u] = {"items": [], "scores": []}
                continue
            idx = np.concatenate([p[0] for p in parts[k]]).astype(np.int64)
            val = np.concatenate([p[1] for p in parts[k]]).astype(np.float32)
            banned = {pos[i] for i in dataset.user_train_items.get(u, set()) if i in pos}
            items, scores, seen = [], [], set()
            for o in np.argsort(-val):
                p = int(idx[o])
                if p in seen or p in banned:
                    continue
                seen.add(p); items.append(item_ids[p]); scores.append(float(val[o]))
                if len(items) >= topn:
                    break
            out[u] = {"items": items, "scores": scores}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--topn", type=int, default=100)
    ap.add_argument("--encoder", default="intfloat/e5-base-v2")
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--out_dir", default=None)
    args = ap.parse_args()

    cfg = load_config(str(config_path_for(args.ds, REPO)))
    cfg.dataset.data_dir = str(REPO / cfg.dataset.data_dir)
    dataset = DatasetLoader(cfg.dataset, ArtifactManager(project_root=REPO, dataset_name=args.ds)).load()
    users = sorted(set(dataset.user_valid_items) | set(dataset.user_test_items))
    device = torch.device("cuda", args.gpu) if torch.cuda.is_available() else torch.device("cpu")
    out_dir = Path(args.out_dir) if args.out_dir else DEFAULT_OUT / args.ds
    out_dir.mkdir(parents=True, exist_ok=True)

    for tool, preds in (("popularity", popularity_route(dataset, users, args.topn)),
                        ("mem", mem_route(dataset, users, args.topn, args.encoder, device))):
        blob = {"schema": "recbole_cache_v2", "dataset": args.ds, "tool": tool, "model": tool,
                "topn": args.topn, "users": preds}
        pickle.dump(blob, open(out_dir / f"toolcache_{tool}.pkl", "wb"))
        print(f"[write] {out_dir / f'toolcache_{tool}.pkl'} ({len(preds)} users)", flush=True)


if __name__ == "__main__":
    main()
