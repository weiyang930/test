#!/usr/bin/env python3
"""Assemble the combined route bank consumed by the planning / candidate-adaptation stages.

Slot mapping (route name -> slot used downstream):
  graph      <- base route: the better of {NCL, DiffRec} by VALIDATION Recall@50 (NDCG@10 tie-break)
  collab     <- the other of {NCL, DiffRec}
  semantic   <- Qwen3-Embedding route
  mem        <- Mem-Ret route
  popularity <- Popularity route

Base selection uses validation only. Output:
  outputs/results/<ds>/precomputed_tool_cache.pkl   {slot: {uid(str): [iid str x depth]}}
  pipeline/route_bank/artifacts/base_selection_<ds>.json

Usage: python assemble_route_cache.py --ds Industrial_10_80_r811 [--depth 100]
"""
from __future__ import annotations

import argparse
import json
import pickle
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
ART = Path(__file__).resolve().parents[1] / "artifacts"


def load_route(route_dir: Path, tool: str):
    p = route_dir / f"toolcache_{tool}.pkl"
    if not p.exists():
        raise SystemExit(f"[assemble] missing route cache: {p}")
    return pickle.load(open(p, "rb"))


def to_lists(users: dict, depth: int):
    return {str(u): [str(x) for x in rec["items"][:depth]] for u, rec in users.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--route_dir", default=None)
    ap.add_argument("--depth", type=int, default=100)   # hyperparameter: per-route list depth kept
    args = ap.parse_args()

    route_dir = Path(args.route_dir) if args.route_dir else ART / "route_cache" / args.ds
    ncl, diff = load_route(route_dir, "ncl"), load_route(route_dir, "diffrec")
    sem, mem, pop = (load_route(route_dir, t) for t in ("semantic_qwen3", "mem", "popularity"))

    key = lambda m: (m["metrics_valid"]["recall@50"], m["metrics_valid"]["ndcg@10"])
    if key(ncl) >= key(diff):
        base_name, base, aux_name, aux = "NCL", ncl, "DiffRec", diff
    else:
        base_name, base, aux_name, aux = "DiffRec", diff, "NCL", ncl
    print(f"[base] {args.ds}: base route = {base_name} (validation selection)")

    cache = {"graph": to_lists(base["users"], args.depth),
             "collab": to_lists(aux["users"], args.depth),
             "semantic": to_lists(sem["users"], args.depth),
             "mem": to_lists(mem["users"], args.depth),
             "popularity": to_lists(pop["users"], args.depth)}
    out = REPO / "outputs" / "results" / args.ds / "precomputed_tool_cache.pkl"
    out.parent.mkdir(parents=True, exist_ok=True)
    pickle.dump(cache, open(out, "wb"))
    ART.mkdir(parents=True, exist_ok=True)
    json.dump({"ds": args.ds, "base_route_model": base_name, "collab_route_model": aux_name, "depth": args.depth},
              open(ART / f"base_selection_{args.ds}.json", "w"), indent=2)
    print(f"[write] {out}")


if __name__ == "__main__":
    main()
