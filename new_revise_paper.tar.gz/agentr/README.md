# Agent-R: Residual Agency Allocation for Multi-Route Recommendation

Code for **Agent-R**, a multi-agent recommender that coordinates heterogeneous recommendation routes and
allocates LLM reasoning as a bounded residual correction over a recommendation prior.

```
heterogeneous route bank (NCL / DiffRec / Qwen3-Embedding / Mem-Ret / Popularity)
  -> Planning Agent  (LLM, bounded per-user route / evidence trust policy; offline, cached per user)
  -> candidate adaptation executor (calibrated, deterministic) -> frozen top-50 slate
  -> Residual Ranking Agent (LLM cross-encoder):  s = p + alpha * tanh(head(h))
Memory Agent (LLM, STM/LTM user memory; offline, cached per user) -> user profile of the Residual Ranking Agent
```

## Repository layout

| Path | Content |
|---|---|
| `src/` | dataset loader, configs, metrics, LLM backend, Memory Agent |
| `scripts/build_llm_user_memory.py` | Memory Agent: builds the STM/LTM memory of every user |
| `scripts/run_pipeline.sh` | end-to-end driver for one dataset |
| `pipeline/route_bank/` | route bank: RecBole routes (`recbole_producer.py`), Qwen3-Embedding route (`build_semantic_route.py`), Mem-Ret and Popularity routes (`build_aux_routes.py`), validation base-route selection and route-bank assembly (`assemble_route_cache.py`) |
| `pipeline/planning/` | candidate executor library (`pcr_common.py`), validated prior weights (`run_offline.py`), planner contexts and the Planning Agent (`stage_planner_build.py`, `stage_planner_llm.py`) |
| `pipeline/candidate_adaptation/` | planner-conditioned frozen top-50 slate (`stage1_build_planner.py`) |
| `pipeline/residual_ranker/` | Residual Ranking Agent: data building, training (`train_residual.py`), scoring and model selection (`eval_residual.py`, `select_dev.py`), full-test-population evaluation (`evaluate_fulltest.py`) |
| `pipeline/ranking_common/`, `pipeline/substrate_common/` | shared helpers (slate access, user split, metrics) |
| `configs/` | one config per dataset |
| `data/` | datasets (`<dataset>.tar.gz`) |

## Setup

Two Python environments are used:
* **LLM environment** (`requirements_llm.txt`): Memory / Planning agents (vLLM), semantic and Mem-Ret routes, Residual Ranking Agent training / inference (PyTorch DDP + PEFT).
* **RecBole environment** (`requirements_recbole.txt`): RecBole routes and all CPU stages.

Models (Hugging Face): `Qwen/Qwen2.5-7B-Instruct` (memory, planning and ranking agents),
`Qwen/Qwen3-Embedding-4B` (semantic route), `intfloat/e5-base-v2` (Mem-Ret route).

## Data

`data/<dataset>.tar.gz` contains `<dataset>/interaction.csv` (`userid,itemid,timestamp,label`, label 0 = train,
1 = validation, 2 = test), `item_profile.csv` (`itemid,item_profile`) and `item_profile_raw.csv`
(`itemid,title,brand,price,categories,description`). Extract with `tar -C data -xzf data/<dataset>.tar.gz`
(done automatically by `scripts/run_pipeline.sh`).

Included datasets: Amazon Industrial, Software, CDs & Music and Video Games
(`*_10_80_r811`: users with 10-80 interactions, per-user chronological 8:1:1 split), KuaiRec, MicroLens,
DoubanBook and DoubanMusic (`*_dg`: leave-last-out). User and item ids are re-indexed integers.

## Running

```bash
DS=Industrial_10_80_r811 NGPU=8 PY_LLM=<llm python> PY_RECBOLE=<recbole python> bash scripts/run_pipeline.sh
```

Stages (each can be resumed with `bash scripts/run_pipeline.sh <first_stage>`):

1. **Route bank** – train NCL and DiffRec (RecBole), build the Qwen3-Embedding, Mem-Ret and Popularity
   routes, select the base route on the validation split, assemble the route bank.
2. **Memory Agent** – one LLM generation per user (STM/LTM memory).
3. **Planning Agent** – validated prior weights of the executor (validation only), per-user coordination
   diagnostics, one LLM policy per user.
4. **Candidate adaptation** – planner-conditioned, calibrated executor builds the frozen top-50 slate.
5. **Ranker data** – ranker-train / ranker-dev users are the validation users whose validation target is in
   the slate (80/20 split); one cross-encoder prompt per (user, candidate).
6. **Residual Ranking Agent** – LoRA training of the cross-encoder with the fused listwise objective.
7. **Model selection** – every checkpoint is scored on ranker-dev users; (checkpoint, prior, alpha) is
   selected by ranker-dev NDCG@10.
8. **Test** – test users are scored once with the selected configuration; full-test-population
   evaluation (every test user is scored; users whose target is not retrieved contribute 0) with
   NDCG@{10,50} and Recall@{10,50}.

The test split is used only in stage 8.

## Hyperparameters

All hyperparameters have generic defaults and should be selected on the validation split:
* candidate executor (`pipeline/planning/scripts/pcr_common.py`, passed via `EXEC_ARGS`): `--keep`
  (base-route head kept), `--budget` (rescued items admitted), `--aux_k` (auxiliary route depth),
  `--min_src` (cross-route agreement gate), `--pool_limit`;
* Planning Agent policy expansion (`LEVEL` in `stage1_build_planner.py`);
* route bank: route depth (`assemble_route_cache.py --depth`), Mem-Ret memory sizes and query weights
  (`build_aux_routes.py`), RecBole epochs;
* Residual Ranking Agent (`train_residual.py`, passed via `TRAIN_ARGS`): `--alpha_train`, `--beta`,
  `--lr`, `--epochs`, LoRA rank, `--max_len`; inference prior and alpha are selected on ranker-dev users
  over `rr_common.ALPHA_GRID` (alpha > 0).
