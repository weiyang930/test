from __future__ import annotations

from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


@dataclass
class DatasetConfig:
    dataset_name: str
    data_dir: str = "data"
    save_split_cache: bool = True
    prefer_split_cache: bool = True


@dataclass
class LLMConfig:
    backend: str = "vllm"                      # vllm | huggingface | mock
    model_name: str = "Qwen/Qwen2.5-7B-Instruct"
    max_new_tokens: int = 256
    temperature: float = 0.0
    tensor_parallel_size: int = 1
    enable_prefix_caching: bool = True
    gpu_memory_utilization: float = 0.9
    max_model_len: int = 8192


@dataclass
class RuntimeConfig:
    seed: int = 42


@dataclass
class AppConfig:
    dataset: DatasetConfig
    llm: LLMConfig
    runtime: RuntimeConfig


def _build(cls, raw: Optional[Dict[str, Any]]):
    raw = raw or {}
    known = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in raw.items() if k in known})


def load_config(path: str) -> AppConfig:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return AppConfig(
        dataset=_build(DatasetConfig, raw["dataset"]),
        llm=_build(LLMConfig, raw.get("llm")),
        runtime=_build(RuntimeConfig, raw.get("runtime")),
    )


def config_path_for(dataset_name: str, root: Path) -> Path:
    """configs/<dataset_name lower-case>.yaml"""
    return Path(root) / "configs" / f"{dataset_name.lower()}.yaml"
