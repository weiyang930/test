from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class Interaction:
    userid: str
    itemid: str
    timestamp: int
    label: int
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DatasetSplit:
    train: List[Interaction]
    valid: List[Interaction]
    test: List[Interaction]
