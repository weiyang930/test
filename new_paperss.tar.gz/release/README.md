# VMem: query-specific, source-grounded evidence construction for long-term conversational memory

This directory contains the code of the final VMem method (VMem-v2.3-clean, the version reported in the paper). It contains code only: no data, model weights, memory stores or experiment outputs.

VMem works at **query time** on top of an existing long-term memory store. It does not build, rewrite or delete memory. For each question it:

1. **Plans the query** (LLM): infers the information need and answer type, and writes 4–6 diverse search queries.
2. **Retrieves at multiple granularities**: dense + BM25 search over episodes, semantic facts and raw conversation turns, run for every planned query. Results are fused with RRF, then provenance-boosted and given local turn context.
3. **Builds evidence cards (ViewCards)** (LLM): each card has a claim, its source IDs, a verbatim quote, a resolved time and its relation to the question.
4. **Verifies sources and normalises time** (deterministic): every quote is checked against its cited source, and weekday-relative expressions are resolved against the session date.
5. **Expands retrieval when evidence is insufficient**: follow-up queries proposed in step 3 are retrieved, and step 3 is repeated on the new items.
6. **Answers** (LLM): the prompt contains the cards, then the cited raw turns, then the remaining retrieved pool. If the answer abstains, VMem retries once.

The final configuration is the set of defaults in `vmem/pipeline.py::Config`. The verbatim prompts are `PLAN_PROMPT`, `EVIDENCE_PROMPT`, `ANSWER_PROMPT` and `ABSTAIN_RETRY` in the same file.

## Layout

```
vmem/
  pipeline.py      VMem pipeline, Config (final hyper-parameters) and prompts
  store.py         read-only memory store (postgres / json backends) + dense & BM25 indexes
  llm.py           LiteLLM wrapper (retries, concurrency limit, token accounting)
  run.py           run VMem on LoCoMo -> results.json
  evaluate.py      LoCoMo scoring: LLM-judge accuracy, F1, BLEU-1
tools/
  embed_server.py  OpenAI-compatible /v1/embeddings server (Qwen3-Embedding-4B)
  export_store.py  export a Postgres memory store to the JSON format (no database needed afterwards)
scripts/
  start_embed.sh   start the embedding server on one GPU
  run_locomo.sh    run + evaluate on LoCoMo
requirements.txt
```

## Requirements

- Python 3.11.
- `pip install -r requirements.txt`. The torch / sentence-transformers / fastapi packages are only needed by the embedding server.
- One GPU for the embedding server. Qwen3-Embedding-4B in bf16 needs about 10 GB.
- LLM access through [LiteLLM](https://docs.litellm.ai/). The defaults use Claude on AWS Bedrock, so set the usual AWS credentials (`AWS_REGION`, `AWS_PROFILE` or access keys).
- **A memory store** (see below).
- **LoCoMo**: `locomo10.json` from https://github.com/snap-research/locomo (the paper uses commit `3eb6f2c`).

## Memory store

VMem reads a store with three granularities:
- **episodes**: `title`, `content`, `created_at` (the conversation time), and `source_messages`, i.e. the raw turns of the episode;
- **semantic facts**: `content`, `memory_type`, `source_episode_id`, `created_at`;
- **raw turns**: taken from `source_messages`.

Each raw turn needs `message_id`, `role` (the speaker), `content`, `timestamp` and `metadata.buffer_id` (its global order).

In the paper, the store is the one produced by NEMORI's memory construction, built once with Claude Opus 4.5 (`agent_id=locomo_opus45`) and shared by all compared methods. Memory construction is not part of this release. Build the store with NEMORI's LoCoMo `add.py`, or with any system that writes the same tables. VMem can read the store in two ways:

| backend | settings |
|---|---|
| `postgres` (default) | `VMEM_STORE=postgres`, `DATABASE_URL=postgresql://user:pass@host:port/db`; reads tables `episodes` and `semantic_memories` filtered by `--agent-id` |
| `json` | `VMEM_STORE=json`, `VMEM_STORE_JSON=memory.json`; create the file once with `python tools/export_store.py --agent-id locomo_opus45 --out memory.json` |

The JSON format is documented in `vmem/store.py`. LoCoMo conversation `i` is stored under the user id `<speaker_a>_<i>`, for example `Caroline_0`.

## Quick start

```bash
pip install -r requirements.txt

# 1) embedding server (http://127.0.0.1:18080/v1/embeddings)
GPU=0 bash scripts/start_embed.sh
export EMBEDDING_BASE_URL=http://127.0.0.1:18080/v1

# 2) memory store
export VMEM_STORE=json VMEM_STORE_JSON=/path/to/memory.json
#   or: export VMEM_STORE=postgres DATABASE_URL=postgresql://...

# 3) run + evaluate (backbone: Claude Opus 4.5 by default)
export AWS_REGION=...            # Bedrock credentials
bash scripts/run_locomo.sh /path/to/locomo10.json outputs/vmem_opus

# Claude Haiku 4.5 backbone (the judge stays Opus 4.5)
VMEM_LLM_MODEL=bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0 VMEM_PRICE_IN=1 VMEM_PRICE_OUT=5 \
  bash scripts/run_locomo.sh /path/to/locomo10.json outputs/vmem_haiku
```

To run a subset, pass conversations as the third argument (e.g. `conv-26,conv-41`), or call `python -m vmem.run ... --qids conv-26:0,conv-26:5`. Runs resume automatically: questions already present in `results.json` are skipped, unless you pass `--overwrite`.

### Ablations

Any `Config` field can be overridden from the command line:

```bash
python -m vmem.run --data locomo10.json --out outputs/no_plan/results.json --cfg plan=false
python -m vmem.run --data locomo10.json --out outputs/no_cards/results.json --cfg cards=false
```

## Environment variables

| variable | default | meaning |
|---|---|---|
| `VMEM_LLM_MODEL` | `bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0` | LiteLLM model used for planning, evidence construction and answering (and the judge, unless `--judge-model` is given) |
| `VMEM_LLM_CONCURRENCY` | 16 | max concurrent LLM requests |
| `VMEM_LLM_TIMEOUT` / `VMEM_LLM_RETRIES` | 300 / 8 | per-request timeout (s) / retries with exponential back-off |
| `VMEM_PRICE_IN` / `VMEM_PRICE_OUT` | 5 / 25 | USD per 1M tokens, used for cost reporting only |
| `EMBEDDING_BASE_URL` | `http://127.0.0.1:18080/v1` | OpenAI-compatible embedding endpoint |
| `VMEM_STORE` / `VMEM_STORE_JSON` / `DATABASE_URL` | `postgres` / – / local default | memory store backend (see above) |
| `VMEM_AGENT_ID` | `locomo_opus45` | agent id of the store (postgres backend) |
| `VMEM_CACHE` | `./cache/embeddings` | item-embedding cache |
| `VMEM_JUDGE_CACHE` | `./cache/judge` | judge-result cache |
| `EMBED_MODEL` / `EMBED_PORT` | `Qwen/Qwen3-Embedding-4B` / 18080 | embedding server |

## Final configuration (`Config` defaults)

| parameter | value |
|---|---|
| RRF k | 60 |
| dense / BM25 hits per query and granularity | 20 / 12 |
| provenance boost (semantic → episode vote, episode bonus) | 0.5 / 0.3 |
| first-round pool: episodes / semantic facts | 10 / 20 |
| turn hits / max pool turns (normal questions) | 30 / 90 |
| turn hits / max pool turns (aggregation questions, decided by the planner) | 45 / 130 |
| local turn context at retrieval | ±1 turn (same session) |
| max expansion rounds (normal / aggregation) | 1 / 2 |
| expansion round | ≤3 follow-up queries; ≤6 episodes, 10 semantic facts, 40 turns added |
| planned queries | ≤6, plus the original question |
| cited source context in the answer prompt | ±2 turns per cited turn; first 12 turns per cited episode |
| quote verification threshold | 0.8 |
| max tokens: plan / evidence / answer | 800 / 4000 / 1200 |
| deterministic time normalisation, abstention retry | on, on |
| temperature | 0 for all calls |

A typical question takes 3 LLM calls (plan, evidence, answer), and at most 6.

## Evaluation protocol

`vmem/evaluate.py` scores `results.json` on LoCoMo categories 1–4 (1540 questions; category 5 is skipped as in prior work):
- **LLM-judge accuracy**: the standard Mem0 / NEMORI `ACCURACY_PROMPT` judge, run with Claude Opus 4.5 at temperature 0. Always pass `--judge-model` explicitly when the answering backbone is not Opus.
- **F1** and **BLEU-1**: token-level scores.

No gold answer, gold evidence or question-category label is used at inference time.

## Tested

The code was tested from a clean Python 3.11 environment installed from `requirements.txt`:
- the `postgres` and `json` backends load identical memory items, and retrieval returns identical pools to the original research code;
- end-to-end runs on LoCoMo questions with both the Claude Opus 4.5 and Claude Haiku 4.5 backbones, followed by evaluation, complete without errors.
