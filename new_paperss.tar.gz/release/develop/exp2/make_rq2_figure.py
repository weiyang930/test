"""RQ2 main-text figure (Opus 4.5 only): (a) evidence coverage by category, (b) accuracy by NEMORI R status.

Plot only — reads exp2/figdata/*.csv produced by analyze.py; no numbers are recomputed except the two
headline shares in panel (b), which are derived from the same CSV (group n and n·delta = net wins).
    cd develop && /usr/bin/python3 exp2/make_rq2_figure.py
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

EXP2 = Path(__file__).resolve().parent
FIGA = EXP2 / "figdata/figA_coverage_by_category.csv"
FIGB = EXP2 / "figdata/figB_accuracy_by_nemori_coverage.csv"
OUT = EXP2 / "figures/rq2_evidence_sufficiency"
BB = "opus"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 300,
})
# one hue per method (consistent across panels); lightness/hatch encodes the coverage measure
NEM = {"R": "#8C8C8C", "V": "#D2D2D2"}
VM = {"R": "#2F6DA8", "V": "#8DB4DA", "C": "#D6E5F3"}
EDGE = "#333333"

rows = list(csv.DictReader(FIGA.open()))
ncat = {r["group"]: int(r["n"]) for r in rows if r["backbone"] == BB}
cov = {(r["method"], r["measure"], r["group"]): float(r["complete_pct"]) for r in rows if r["backbone"] == BB}
brows = [r for r in csv.DictReader(FIGB.open())
         if r["backbone"] == BB and r["grouping"] == "NEMORI in_retrieved_record"]
brows.sort(key=lambda r: ["complete", "partial", "missing"].index(r["group"]))

fig, (axa, axb) = plt.subplots(1, 2, figsize=(7.0, 2.55), gridspec_kw={"width_ratios": [2.05, 1]})

# ---- (a) coverage ---------------------------------------------------------------------------------------
cats = ["Multi-hop", "Temporal", "Open-domain", "Single-hop", "Overall"]
series = [("NEMORI", "in_retrieved_record", NEM["R"], ""), ("NEMORI", "raw_visible", NEM["V"], ""),
          ("VMem", "in_retrieved_record", VM["R"], ""), ("VMem", "raw_visible", VM["V"], ""),
          ("VMem", "card_cited", VM["C"], "////")]
w, gap = 0.155, 0.03
offs = [-2 * w - gap, -w - gap, 0 + gap / 2, w + gap / 2, 2 * w + gap / 2]
offs = [o - (offs[0] + offs[-1]) / 2 for o in offs]
for (m, meas, col, hatch), o in zip(series, offs):
    xs = [i + o for i in range(len(cats))]
    ys = [cov[(m, meas, c)] for c in cats]
    axa.bar(xs, ys, w, color=col, edgecolor=EDGE, linewidth=0.4, hatch=hatch, zorder=2)
    # value labels on the Overall group only
    axa.text(xs[-1], ys[-1] + 1.2, f"{ys[-1]:.1f}", ha="center", va="bottom", fontsize=5.8, rotation=90)
axa.axvspan(len(cats) - 1.5, len(cats) - 0.5, color="#F6F6F6", zorder=0, lw=0)
axa.set_xticks(range(len(cats)))
axa.set_xticklabels([f"{c}\n(n={ncat[c]})" for c in cats])
axa.set_xlim(-0.5, len(cats) - 0.5)
axa.set_ylim(0, 108)
axa.set_yticks(range(0, 101, 20))
axa.set_ylabel("Questions with complete\ngold evidence (%)")
axa.yaxis.grid(True, lw=0.4, color="#DDDDDD", zorder=0)
axa.set_axisbelow(True)
axa.set_title("(a) Evidence coverage by category", loc="left", fontweight="bold", pad=24)
leg = [Patch(fc=NEM["R"], ec=EDGE, lw=0.4, label="NEMORI: retrieved"), Patch(fc=NEM["V"], ec=EDGE, lw=0.4, label="NEMORI: in prompt"),
       Patch(fc=VM["R"], ec=EDGE, lw=0.4, label="Ours: retrieved"), Patch(fc=VM["V"], ec=EDGE, lw=0.4, label="Ours: in prompt"),
       Patch(fc=VM["C"], ec=EDGE, lw=0.4, hatch="////", label="Ours: cited by ViewCard")]
axa.legend(handles=leg, ncol=3, loc="lower left", bbox_to_anchor=(0, 1.0), frameon=False, borderaxespad=0.2,
           handlelength=1.3, columnspacing=0.8, handletextpad=0.4, fontsize=6.6)

# ---- (b) accuracy conditioned on NEMORI R --------------------------------------------------------------
labels = [r["group"].capitalize() for r in brows]
n = [int(r["n"]) for r in brows]
nem = [100 * float(r["nemori_acc"]) for r in brows]
vm = [100 * float(r["vmem_acc"]) for r in brows]
d = [100 * float(r["delta"]) for r in brows]
lo = [100 * float(r["ci_lo"]) for r in brows]
hi = [100 * float(r["ci_hi"]) for r in brows]
bw = 0.36
xs = range(len(labels))
axb.bar([x - bw / 2 for x in xs], nem, bw, color=NEM["R"], edgecolor=EDGE, linewidth=0.4, label="NEMORI", zorder=2)
axb.bar([x + bw / 2 for x in xs], vm, bw, color=VM["R"], edgecolor=EDGE, linewidth=0.4, label="Ours", zorder=2)
for x, a, b, dd, l, h in zip(xs, nem, vm, d, lo, hi):
    top = max(a, b) + 3
    axb.plot([x - bw / 2, x - bw / 2, x + bw / 2, x + bw / 2], [a + 1.5, top, top, b + 1.5], lw=0.6, color=EDGE)
    axb.text(x, top + 1.2, f"{dd:+.1f} pp", ha="center", va="bottom", fontsize=7, fontweight="bold",
             color="#1F4E79" if dd > 1 else "#555555")
axb.set_xticks(list(xs))
axb.set_xticklabels([f"{l}\n(n={k})" for l, k in zip(labels, n)])
axb.set_xlabel("NEMORI retrieval coverage (R)", labelpad=2)
axb.set_ylim(0, 112)
axb.set_yticks(range(0, 101, 20))
axb.set_ylabel("LLM-judge accuracy (%)")
axb.yaxis.grid(True, lw=0.4, color="#DDDDDD", zorder=0)
axb.set_axisbelow(True)
axb.set_title("(b) Accuracy by NEMORI coverage", loc="left", fontweight="bold", pad=24)
axb.legend(ncol=2, loc="lower left", bbox_to_anchor=(0, 1.0), frameon=False, borderaxespad=0.2, handlelength=1.3)

# headline shares, derived from the plotted rows: questions share and net-win share of R partial + missing
wins = [round(k * dd / 100) for k, dd in zip(n, d)]  # n·delta = wins − losses per group
q_share = 100 * (n[1] + n[2]) / sum(n)
w_share = 100 * (wins[1] + wins[2]) / sum(wins)
axb.text(1.5, 7, f"Partial + Missing:\n{q_share:.1f}% of questions,\n{w_share:.1f}% of net wins",
         ha="center", va="bottom", fontsize=6.3,
         bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#1F4E79", lw=0.6), zorder=3)

fig.tight_layout(w_pad=1.5)
for ext in ("pdf", "png"):
    fig.savefig(f"{OUT}.{ext}", bbox_inches="tight", pad_inches=0.02)
print(OUT, {"q_share": round(q_share, 1), "net_win_share": round(w_share, 1), "net_wins": wins, "delta_pp": d})
