# VMem-v2.3-clean：核心 Prompt 汇编

日期：2026-10-12　版本：VMem-v2.3-clean（最终报告版本）　来源：`develop/vmem2/pipeline.py`

> - 本文收录 VMem 查询时用到的全部 LLM prompt：查询规划、证据卡片构建、作答，以及弃答重试。
> - 每个 prompt 都**由脚本直接从代码中抽取**，与实际运行逐字一致。
>   - 代码中为了 `str.format` 写成 `{{`、`}}` 的大括号，这里已还原成实际发给模型的 `{`、`}`。
>   - 单层花括号的 `{question}` 等是运行时填入的占位符，含义见每个 prompt 后的表格。
> - 所有调用：Claude Opus 4.5 或 Haiku 4.5（Bedrock），temperature 0，只发一条 user 消息，不使用 system prompt。
> - 各 prompt 的设计考虑和算法细节见 `2026-10-11_vmem2_method_and_results.md` §13；参数汇总见 `2026-10-12_experimental_setup.md` §4。
> - 与 v2.3 相比，v2.3-clean 只改了 prompt 中的例子：改用 2031 年的虚构日期，避免与 LoCoMo 的 gold 字符串重合。`controls/check_prompt_leak.py` 检查过，重合为 0。

## 0. Prompt 在流程中的位置

| 阶段 | Prompt | 每题调用次数 | max_tokens | 输出 |
|---|---|---|---:|---|
| ① 查询规划 | `PLAN_PROMPT` | 1 | 800 | JSON：need / answer_type / aggregate / temporal / queries |
| ③⑤ 证据构建与扩展 | `EVIDENCE_PROMPT` | 1–3（首轮，加 0–2 轮扩展） | 4000 | JSON：cards / sufficient / missing / follow_up_queries |
| ⑥ 作答 | `ANSWER_PROMPT` | 1 | 1200 | `REASONING:` … `FINAL ANSWER: <answer>` |
| ⑥ 弃答重试 | `ANSWER_PROMPT` 后面追加 `ABSTAIN_RETRY` | 0–1（全集 1540 题中触发 22 次） | 1200 | 同上 |

第 ② 步检索和第 ④ 步原文核验、时间归一化都是确定性代码，不调用 LLM。它们与 prompt 的接口见 §5。

---

## 1. 查询规划：`PLAN_PROMPT`

```text
You are the query planner of a long-term conversational memory system.
The memory stores a long multi-session conversation between {speakers}. Sessions span {span}.

Question: {question}

Analyse what information is needed to answer the question and plan retrieval. Think about:
- which person(s), objects, events and attributes the question is about (resolve "he/she/they" to names when obvious),
- whether the answer needs several facts combined (multi-hop), facts aggregated over many sessions (lists, counts, "what activities/places/books..."), a date or time computation, or an inference about someone's preferences, personality or likely behaviour,
- which intermediate facts must be found first (e.g. to answer "What did X do after Y?" first find when Y happened).

Return ONLY a JSON object:
{
  "need": "<one sentence describing the information need>",
  "answer_type": "<one of: date, duration, count, list, yes_no, entity, description, reason, inference>",
  "aggregate": <true if the answer may be spread over multiple sessions, else false>,
  "temporal": <true if a date/time/order must be determined, else false>,
  "queries": ["<4-6 short, diverse search queries: sub-questions for intermediate facts, paraphrases with likely conversational wording, and key entity/keyword queries>"]
}
```

| 占位符 | 填入内容 |
|---|---|
| `{speakers}` | 两位说话人的姓名，如 `Caroline and Melanie` |
| `{span}` | 记忆库中第一条到最后一条原始 turn 的日期范围（`<日期> to <日期>`） |
| `{question}` | 原问题 |

**输出的使用方式**
- 检索 query 集合 = `[question] + queries[:6]`，原问题总是排在第一条。
- `need` 会传给证据构建阶段。
- 满足 `aggregate == true` 或 `answer_type ∈ {list, count}` 的问题走更大的预算：turn 命中 45，turn 池上限 130，扩展轮最多 2 轮。
- JSON 解析失败时，退回 `{"need": question, "queries": []}`，即只用原问题检索。

---

## 2. 证据卡片构建：`EVIDENCE_PROMPT`

```text
You are the evidence constructor of a long-term conversational memory system.
Your job is NOT to answer the question but to build compact, source-grounded evidence cards that make the facts needed to answer it explicit.

Question: {question}
Information need: {need}

Candidate memories retrieved from the memory store (each has an ID; [E*] episode summaries, [S*] semantic facts, [T*] raw conversation turns with their session date):
{pool}
{previous}
Instructions:
1. Find every memory relevant to the question. For list/count/"what activities" questions collect ALL distinct instances across sessions; for multi-hop questions collect each intermediate fact.
2. For each relevant fact write a card. Prefer raw turns [T*] as sources because they are the original words; use [E*]/[S*] when no turn is available.
3. "quote" must be copied VERBATIM from the cited source (a short span, max ~30 words) — never paraphrase inside "quote".
4. "time": when the fact happened, resolved against the session date of the source: "yesterday" -> "11 March 2031" (absolute date); "last Friday"/"last weekend" -> "the Friday/weekend before 12 March 2031" (keep weekday-relative expressions relative to the session date, do not compute the calendar day); "last week" -> "the week before 12 March 2031"; "last year" -> "2030"; no relative expression -> the session date. Use "" if not time-relevant.
5. "relation": in a few words, how this card bears on the question (e.g. "answer candidate", "intermediate fact: date of Y", "supports inference: likes outdoors", "contradicts card 2").
6. Do not invent facts. If the memories conflict, make cards for both and note it in "relation".
7. Then judge whether the cards suffice. If key information is missing, give up to 3 follow-up search queries aimed precisely at the missing facts.

Return ONLY a JSON object:
{
  "cards": [{"claim": "<fact relevant to the question, self-contained, with names>", "sources": ["T3"], "quote": "<verbatim span>", "time": "<absolute time or empty>", "relation": "<role>"}],
  "sufficient": <true/false>,
  "missing": "<what is still missing, or empty>",
  "follow_up_queries": ["..."]
}
```

| 占位符 | 填入内容 |
|---|---|
| `{question}` | 原问题 |
| `{need}` | 规划输出的 `need`；规划失败时就是原问题 |
| `{pool}` | 格式化后的候选池（格式见 §2.1）。**扩展轮只放本轮新检索到的条目** |
| `{previous}` | 首轮为空字符串；扩展轮为已有卡片的摘要（见 §2.2） |

### 2.1 候选池格式（`format_pool`，确定性）

```text
## Episodes
[E1] (<session date>) <episode title>: <episode content>
...
## Semantic facts
[S1] (learned in session of <session date>) <semantic fact>
...
## Conversation turns (grouped by session, chronological)
-- session <session date> --
[T1] <Speaker>: <原始 turn 文本>
[T2] <Speaker>: <原始 turn 文本>
-- session <session date> --
...
```

- 三类条目分别按时间排序；turn 按 (时间, 全局顺序) 排序，并按 session 分组。
- 标签 `E*` / `S*` / `T*` 在同一道题的各轮之间保持不变，卡片的 `sources` 就引用这些标签。
- semantic 的日期是其来源 episode 的会话日期，而不是 NEMORI 的入库时间。

### 2.2 扩展轮附加的 `{previous}`

```text

Evidence cards already constructed in the previous round (do not repeat them; add only new facts from the NEW memories above):
- <claim 1> [T3,E2]
- <claim 2> [S5]
...
```

**扩展逻辑**
- 若 `sufficient == false` 且给出了 `follow_up_queries`，就用前 3 条 query 再检索一轮。
- 已在池中的条目排除；新增上限为 6 个 episode、10 条 semantic、40 条 turn。
- 各轮的卡片取并集。
- JSON 解析失败时，本轮视为"无卡片且充分"。

---

## 3. 作答：`ANSWER_PROMPT`

```text
You are an intelligent memory assistant answering questions about a long-term conversation between {speakers}, using evidence retrieved from memory.

# QUESTION
{question}

# EVIDENCE CARDS (constructed for this question; each claim is grounded in a verbatim quote from the cited source; cards marked UNVERIFIED could not be matched to their source and must be treated with caution)
{cards}

# CITED SOURCE CONTEXT (original conversation turns around the cited evidence, with session dates)
{sources}

# OTHER RETRIEVED MEMORIES (background; use them if the cards miss something)
{pool}

# INSTRUCTIONS
1. Base the answer on the evidence. Prefer verified cards and original turns; use episode summaries and semantic facts to fill gaps.
2. Time. Dates shown are session dates (the day the conversation took place). Express event times the way people resolve them against the session date:
   - "yesterday", "today", "this morning", "two days ago" -> the absolute calendar date (e.g. said on 12 March 2031 "yesterday" -> 11 March 2031);
   - "last Friday", "last Sunday", "on the weekend" (a weekday-relative expression) -> "the Friday before 12 March 2031" (relative to the session date; do NOT convert it into a calendar day yourself);
   - "last week", "last month", "a few days ago" -> "the week before 4 April 2031", "the month before ..." , "a few days before ...";
   - "last year", "next month" -> the year / month (e.g. said in 2031 "last year" -> 2030).
   If the event is reported without a relative expression, its time is the session date itself.
   When a card's time is of the form "the <weekday/week/weekend> before <date>", that is the resolved time: give it in exactly that form (episode summaries may contain mis-computed calendar days).
3. Lists / "what activities", "what books", "how many": aggregate ALL distinct items found across all sessions; count carefully and de-duplicate.
4. Questions about likely preferences, personality, opinions or hypotheticals ("Would X ...", "What might X ...", "Is X likely ..."): give the most plausible answer inferred from the evidence (start with "Probably yes"/"Probably no" for yes/no questions) rather than refusing. For questions about someone's traits or attributes, answer with a few short descriptive traits.
5. Always give the answer first. If the question's details (e.g. a date or name) do not exactly match the memories, answer with the memory that best matches the rest of the question — do not start with "there is no evidence".
6. Answer exactly what is asked; do not add extra facts, dates or explanations that are not asked for.
7. The final answer must be short and direct: a phrase, name, date, list or short sentence (ideally under 15 words).

First think briefly step by step (max ~120 words) under "REASONING:", then give the answer on the last line exactly as:
FINAL ANSWER: <answer>
```

| 占位符 | 填入内容 |
|---|---|
| `{speakers}` | 两位说话人的姓名 |
| `{question}` | 原问题 |
| `{cards}` | 全部卡片，按 §3.1 的格式编号列出；没有卡片时为 `(no cards)` |
| `{sources}` | 卡片引用来源周围的原文。turn 来源取 ±2 条同 session 邻居，episode 来源取该 episode 的前 12 条 turn，按 `format_pool` 的 turn 格式列出；没有时为 `(none)` |
| `{pool}` | 其余检索池：全部 episode、全部 semantic，以及没有出现在 `{sources}` 中的 turn |

### 3.1 卡片的呈现格式

```text
[1] claim: <claim> | time: <time>
    source T3,S5: "<quote>"
    role: <relation>
[2] (UNVERIFIED) claim: <claim>
    source E4: "<quote>"
```

- 没通过原文核验的卡片（支持度 < 0.8），标签后面会加上 ` (UNVERIFIED)`。
- `time` 为空时不显示 `| time:`；`relation` 为空时不显示 `role:` 行。
- 卡片的 `time` 和 `claim` 可能已经被确定性的时间归一化改写过（§5.2）。

### 3.2 答案抽取

取 `FINAL ANSWER:` 之后的第一行作为最终答案；找不到这个标记时，取整段输出的第一行。

---

## 4. 弃答重试：`ABSTAIN_RETRY`

最终答案匹配下面的弃答正则时，把 `ABSTAIN_RETRY` **追加在同一个作答 prompt 末尾**，再调用一次。第二次答案非空时，替换第一次的答案。

```text
# NOTE
Your previous final answer was: "{prev}". A question usually refers to something that is in the conversation even when a detail in it (e.g. the year, month or a name) may be slightly wrong. Do not abstain: answer with the memory that best matches the question, as a short direct answer.
```

| 占位符 | 填入内容 |
|---|---|
| `{prev}` | 第一次的最终答案 |

弃答判定正则（`_ABSTAIN_RE`，不区分大小写）：

```python
r"^\W*(there is no|there's no|no (?:evidence|information|record|mention)|not (?:mentioned|specified|stated)|"
                         r"(?:the )?(?:memories|evidence|conversation) (?:do(?:es)? not|don't)|cannot (?:be )?determine|unknown|insufficient)"
```

---

## 5. 与 prompt 配合的确定性规则（不调用 LLM）

这些规则决定 prompt 收到的内容是什么样的，写论文描述 prompt 时需要一起交代。

### 5.1 原文核验（作用于卡片的 `quote`）

1. 把 `sources` 中的标签映射回条目原文；映射不到的标签直接忽略。
2. 规范化：小写，非字母数字字符换成空格，再合并连续空白。
3. 支持度：规范化后的 quote 是某个来源的子串时为 1.0；否则用 `difflib.SequenceMatcher` 求匹配块总长度除以 quote 长度，取所有来源中的最大值。
4. 支持度 ≥ 0.8 记为已核验；未通过的卡片保留，但在作答 prompt 中标为 `(UNVERIFIED)`。

### 5.2 确定性时间归一化（v2.3 新增）

当卡片引用了一条原始 turn、quote 规范化后的前 40 个字符出现在这条 turn 中，并且 quote 匹配下面的正则时：

```python
r"\b(?:last|this past|past)\s+(weekend|week|month|(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?)\b"
```

就做两处改写：
- `time` 改为 `the <Saturday | weekend | week | month> before <这条 turn 的 session 日期>`；
- `claim` 中出现的绝对日期（可带星期名）替换为 `(<同一表达>)`。

这样做是为了与 `EVIDENCE_PROMPT` 第 4 条、`ANSWER_PROMPT` 第 2 条的时间约定保持一致：星期类的相对时间保留成"某日之前的星期几"，不让模型自行换算日历日，因为 LLM 和 episode 摘要都常把这类日期算错。

---

## 6. 评测用 prompt（不属于方法本身）

- **准确率 judge**：上游 NEMORI / Mem0 的 `ACCURACY_PROMPT` 和 system message，原样使用（`common/evaluate.py`，来自 `nemori/evaluation/locomo/metrics/llm_judge.py` @ `d2a6dff`）。judge 是 Opus 4.5，temperature 0。
- **RQ3 消融中的无卡片作答 prompt**：`exp3/ablate.py` 中的 `NOCARD_PROMPT` 和 `POOL_PROMPT`。它们由 `ANSWER_PROMPT` 删掉与卡片有关的文字得到，其余指令逐字保留。
- **RQ4、RQ8 的审计 judge prompt**：分别在 `exp4/claim_audit.py` 和 `exp8/judge.py` 中。

以上都不是 VMem 推理时使用的 prompt，所以本文没有收录原文。

---

## 7. 重新生成本文

本文由脚本从 `vmem2/pipeline.py` 抽取 prompt 后生成。修改 prompt 后，用同样的方法重新抽取，可以保证与代码一致：

```bash
cd develop && python3 scripts/make_prompts_md.py scripts/prompts_tpl.md 2026-10-12_vmem_prompts.md
```

模板 `scripts/prompts_tpl.md` 里的说明文字可以直接修改；prompt 原文每次都从代码重新抽取。
