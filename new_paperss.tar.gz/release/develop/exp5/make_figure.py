"""Figure A: accuracy vs. query-time inference cost (one panel per backbone, Pareto frontier drawn). Plot only.
    cd develop && /usr/bin/python3 exp5/make_figure.py
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

EXP5 = Path(__file__).resolve().parent
rows = list(csv.DictReader((EXP5 / "figdata/figA_accuracy_cost.csv").open()))
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.6, "pdf.fonttype": 42, "savefig.dpi": 300})
SHORT = {"NEMORI": "NEMORI", "Matched-Budget Retrieval-Only": "Retrieval-only\n(matched context)",
         "Query-Guided Retrieval + Direct Answer": "Query-guided retrieval\n+ direct answer",
         "VMem w/o Evidence Refinement": "Ours w/o refinement", "Full VMem": "Ours (full)"}
COL = {"NEMORI": "#8C8C8C", "Matched-Budget Retrieval-Only": "#BDBDBD", "Query-Guided Retrieval + Direct Answer": "#8DB4DA",
       "VMem w/o Evidence Refinement": "#5B8FC4", "Full VMem": "#2F6DA8"}
OFF = {"haiku": {"NEMORI": (7, 0), "Matched-Budget Retrieval-Only": (7, 0), "Query-Guided Retrieval + Direct Answer": (-7, 0),
                 "VMem w/o Evidence Refinement": (0, -11), "Full VMem": (0, 9)},
       "opus": {"NEMORI": (7, 0), "Matched-Budget Retrieval-Only": (7, 0), "Query-Guided Retrieval + Direct Answer": (-7, 0),
                "VMem w/o Evidence Refinement": (-4, -11), "Full VMem": (0, 9)}}
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.35))
for ax, bb, title in zip(axs, ("haiku", "opus"), ("(a) Claude Haiku 4.5", "(b) Claude Opus 4.5")):
    rs = [r for r in rows if r["backbone"] == bb]
    fr = sorted([r for r in rs if r["pareto_within_backbone"] == "True"], key=lambda r: float(r["cost_usd_per_q"]))
    ax.plot([100 * float(r["cost_usd_per_q"]) for r in fr], [float(r["accuracy"]) for r in fr], color="#2F6DA8", lw=0.9, ls="--", zorder=1,
            label="Pareto frontier")
    for r in rs:
        x, y = 100 * float(r["cost_usd_per_q"]), float(r["accuracy"])
        on = r["pareto_within_backbone"] == "True"
        ax.scatter(x, y, s=38, color=COL[r["config"]], edgecolor="#222222", linewidth=0.6 if on else 0.4,
                   marker="o" if on else "X", zorder=3)
        o = OFF[bb][r["config"]]
        ax.annotate(SHORT[r["config"]], (x, y), textcoords="offset points", xytext=o, fontsize=6.4,
                    ha="left" if o[0] > 0 else ("right" if o[0] < 0 else "center"), va="center")
    ax.set_title(title, loc="left", fontweight="bold", fontsize=9)
    ax.set_xlabel("Inference cost per question (US cents, log scale)")
    ax.set_ylabel("LLM-judge accuracy (%)")
    ax.grid(lw=0.4, color="#E3E3E3")
    ax.set_axisbelow(True)
    xs = [100 * float(r["cost_usd_per_q"]) for r in rs]
    ax.set_xscale("log")   # log cost axis spreads the operating points horizontally
    ax.set_xlim(min(xs) / 1.35, max(xs) * 1.35)
    ticks = [t for t in (0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8, 10, 15) if min(xs) / 1.35 <= t <= max(xs) * 1.35]
    ax.set_xticks(ticks)
    ax.set_xticklabels([f"{t:g}" for t in ticks])
    ax.minorticks_off()
    ax.set_ylim(75, 93.5)
axs[0].legend(loc="lower right", frameon=False, fontsize=6.8)
axs[1].set_ylabel("")
fig.tight_layout(w_pad=2)
for ext in ("pdf", "png"):
    fig.savefig(EXP5 / f"figures/rq5_accuracy_cost.{ext}", bbox_inches="tight", pad_inches=0.02)
print("ok")
