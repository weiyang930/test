"""RQ7 figure: complete evidence coverage vs. source-turn budget (offline coverage of stored retrieval prefixes).
Panels (a) Haiku 4.5, (b) Opus 4.5. Plot only; data from exp7/figdata/fig_{turn,token}_budget.csv (written by analyze.py).
The hypothetical NEMORI episode expansion is drawn dashed with hollow markers. Lines are labelled at their right end.
    cd develop && /usr/bin/python3 exp7/make_figure.py
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.patheffects as pe  # noqa: E402

EXP7 = Path(__file__).resolve().parent
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.5,
                     "ytick.major.size": 0, "pdf.fonttype": 42, "savefig.dpi": 300})
# strategy: colour, marker, label, linestyle, hollow
# Full VMem retrieval (round 1 + refinement) is not drawn: it coincides with the round-1 curve up to B~80 and is at most
# +1.2 pp above it at B=120 (see tables); a second, overlapping blue line would only add clutter.
STY = {"qg_r1": ("#0B4F9C", "o", "Ours (query-guided,\nround-1 pool)", "-", False),
       "matched": ("#D55E00", "s", "Matched\nretrieval-only", (0, (6, 2, 1.5, 2)), False),
       "nemori_exp": ("#555555", "o", "NEMORI top-10\n(offline expansion)", (0, (4, 2)), True),
       "nemori_actual": ("#555555", "^", "NEMORI (actual)", "-", False)}
ORDER = ["nemori_actual", "nemori_exp", "matched", "qg_r1"]


def load(fn, xkey):
    d = defaultdict(lambda: ([], []))
    for r in csv.DictReader((EXP7 / "figdata" / fn).open()):
        x, y = d[(r["backbone"], r["strategy"])]
        x.append(float(r[xkey]))
        y.append(float(r["complete_pct"]))
    return d


def panel_fig(fn, xkey, xmax, marks, xlabel, out, xfmt=lambda v: f"{v:g}", ticks=None):
    d = load(fn, xkey)
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.5), sharey=True)
    for ax, bb, title in zip(axs, ("haiku", "opus"), ("(a) Claude Haiku 4.5", "(b) Claude Opus 4.5")):
        ends = {}
        for s in ORDER:
            c, mk, lab, ls, hollow = STY[s]
            x, y = d[(bb, s)]
            xs = [a for a in x if a <= xmax]
            ys = y[:len(xs)]
            ours = s == "qg_r1"
            line, = ax.plot(xs, ys, color=c, lw=2.2 if ours else 1.4, ls=ls,
                            zorder=5 if ours else 2, solid_capstyle="round", dash_capstyle="round")
            if ours:
                line.set_path_effects([pe.Stroke(linewidth=6, foreground=c, alpha=0.15), pe.Normal()])
            mx = [m for m in marks if m in xs]
            my = [ys[xs.index(m)] for m in mx]
            ax.scatter(mx, my, s=26 if ours else 20, marker=mk, facecolor="white" if hollow else c,
                       edgecolor=c if hollow else "white", linewidth=1.1 if hollow else 0.7,
                       zorder=6 if ours else 3)
            ends[s] = ys[-1]
        # direct labels at the right end, pushed apart vertically (min gap in data units)
        gap = 10
        pos, last = {}, -1e9
        for s in sorted(ends, key=lambda k: ends[k]):
            pos[s] = max(ends[s], last + gap)
            last = pos[s]
        over = last - 99
        if over > 0:
            for s in pos:
                pos[s] -= over
        for s in ORDER:
            c, _, lab, _, _ = STY[s]
            ax.annotate(lab, (xmax, ends[s]), xytext=(xmax * 1.03, pos[s]), textcoords="data", va="center", ha="left",
                        fontsize=6.4, color=c, fontweight="bold", annotation_clip=False,
                        linespacing=0.95)
        ax.set_xlim(0, xmax * 1.01)
        ax.set_ylim(0, 100)
        ax.set_yticks(range(0, 101, 20))
        ax.set_xticks(ticks or marks)
        ax.set_xticklabels([xfmt(m) for m in (ticks or marks)], fontsize=7)
        ax.grid(axis="y", lw=0.6, color="#C4C4C4", ls=(0, (4, 3)))
        ax.set_axisbelow(True)
        ax.set_title(title, loc="left", fontweight="bold", fontsize=8.5)
        ax.set_xlabel(xlabel, fontsize=7.5, labelpad=2)
    axs[0].set_ylabel("Complete evidence coverage (%)")
    fig.subplots_adjust(left=0.07, right=0.83, bottom=0.17, top=0.9, wspace=0.62)
    for ext in ("pdf", "png"):
        fig.savefig(EXP7 / f"figures/{out}.{ext}", bbox_inches="tight", pad_inches=0.03)


panel_fig("fig_turn_budget.csv", "budget_turns", 120, [10, 20, 40, 60, 80, 100, 120],
          "Budget (unique source turns shown verbatim)", "rq7_coverage_vs_turn_budget", ticks=[0, 20, 40, 60, 80, 100, 120])
panel_fig("fig_token_budget.csv", "budget_tokens", 3600, [300, 600, 1200, 1800, 2400, 3000, 3600],
          "Budget (source-turn tokens, cl100k)", "rq7_coverage_vs_token_budget", ticks=[0, 600, 1200, 1800, 2400, 3000, 3600],
          xfmt=lambda v: f"{v / 1000:g}k")
print("ok", file=sys.stderr)
