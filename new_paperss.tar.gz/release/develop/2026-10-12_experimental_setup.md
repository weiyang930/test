# VMem 论文：实验设置总表（Exp1–Exp8）

日期：2026-10-12　范围：主实验（Exp1）、基线复现，以及分析实验 RQ2–RQ8 的全部设置与参数

> 本文只汇总"怎么做的"，不重复结果。各项设置的出处：
> - 方法与主结果：`2026-10-11_vmem2_method_and_results.md`（§1、§13）
> - Haiku 换 backbone：`2026-10-11_backbone_haiku45.md`
> - 基线复现：`2026-10-11_vmem_baselines.md`、`baselines/CONTRACT.md`、`baselines/notes/<m>.md`
> - 主表：`2026-10-11_exp1_main_results.md`
> - 分析实验：`2026-10-12_exp{2..8}_*.md`
>
> 两处细节不一致时，以代码为准（`vmem2/pipeline.py` 中的 `Config()` 默认值，以及各 `exp*/` 脚本）。

---

## 1. 数据集与切分

| 项目 | 设定 |
|---|---|
| 数据集 | LoCoMo `locomo10.json`（snap-research/locomo @ `3eb6f2c`），10 段长期多 session 对话，每段两位说话人 |
| 题目 | 类别 1–4 共 **1540 题**：Multi-hop 282、Temporal 321、Open-domain 96、Single-hop 841。类别 5（adversarial）按 NEMORI / Mem0 惯例跳过 |
| 开发集（dev） | `conv-26`、`conv-41`，共 304 题。VMem 的全部开发和调参只在这里做 |
| 留出集（holdout） | 其余 8 段：`conv-30, 42, 43, 44, 47, 48, 49, 50`，共 1236 题。v2.3 配置锁定后**只跑一次** |
| gold evidence | LoCoMo 的 `evidence` 字段（dia_id，如 `D3:5`），只用于事后分析，从不进入推理 |
| 可映射分母（RQ2/6/7） | 1531 题的 gold turn 全部能精确映射到记忆库消息；4 题部分可映射，5 题完全不可映射（空 evidence 或 id 格式错误）。另有 6 个 LoCoMo turn 在 NEMORI 入库时丢失 |
| 有效 gold 题（RQ6/8） | 1535 题至少有一个有效 gold turn |

---

## 2. 模型、解码与 embedding

| 角色 | 模型 | 设置 |
|---|---|---|
| Opus backbone | `bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0` | temperature 0；记忆构建、查询阶段（Opus 组）、judge 都用它 |
| Haiku backbone | `bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0` | temperature 0；只替换查询阶段的 LLM |
| Judge | Opus 4.5 | temperature 0；上游 NEMORI / Mem0 的 `ACCURACY_PROMPT` 原样使用（`common/evaluate.py`）。换 backbone 时必须显式传 `--judge-model`，否则会默认用 `VMEM_LLM_MODEL` |
| Embedding | `Qwen/Qwen3-Embedding-4B`，2560 维，L2 归一化，本地服务 `:18080` | NEMORI、VMem 和大部分基线共用。例外见 §5 |
| 价格（成本口径） | Opus $5 / $25 每百万输入 / 输出 token；Haiku $1.1 / $5.5（官方标价 $1 / $5，此前一直沿用 1.1 / 5.5） | 基线成本按 us. 价格 $5.5 / $27.5 记账，是上限 |

- **调用方式**：VMem 和 NEMORI 通过 `litellm.acompletion` 直接调用 Bedrock，只发一条 user 消息，不用 system prompt。基线一律经过共享网关（§9）。
- **JSON 输出**：靠 prompt 要求只返回 JSON，再在客户端剥掉代码块标记并做宽松解析（`strip_json` / `parse_json`）。
- **重试**：遇到限流、超时、5xx 时指数退避（带随机抖动）。
- **限制**：Bedrock 上的 Sonnet 5.5 / Haiku 5.5 和 GPT 系列不接受 temperature=0。

---

## 3. 共享记忆库（NEMORI store）

所有"共享库"实验（NEMORI、VMem、RQ3 的各个变体）都从**同一个**由 Opus 4.5 构建、只构建一次的 NEMORI 记忆库检索。

| 项目 | 设定（`configs/nemori_opus45.json`） |
|---|---|
| 构建 | NEMORI 上游 `add.py`（nemori-ai/nemori @ `d2a6dff`，加 `patches/nemori_d2a6dff_bedrock.patch`） |
| agent_id / collection | `locomo_opus45` / `nemori_opus45` |
| 构建 LLM | Opus 4.5，`llm_max_concurrent` 16 |
| buffer / episode 大小 | `buffer_size_min` 1，`buffer_size_max` 20；`episode_min_messages` 1，`episode_max_messages` 20 |
| semantic memory | `enable_semantic_memory` true，`enable_prediction_correction` true |
| 规模 | 631 个 episode，4523 条 semantic memory，5878 条去重后的原始 turn |
| NEMORI 检索 | `search_top_k_episodes` 10，`search_top_k_semantic` 20，向量检索；作答 prompt 中**只有 top-2 episode 附带原文**（`source_messages`） |
| Haiku 组 | `configs/nemori_haiku45.json`：同一个库，只把 `llm_model` 换成 Haiku 4.5 |
| 存储 | Postgres `:15432` 加 Qdrant `:16333`（docker） |
| 备份与恢复 | `/path/to/vmem_backup/nemori_opus45_pg.dump`；JSON 快照 `exp2/data/store_snapshot.json`（只读） |

**恢复注意**：恢复后的 Postgres 在无序 SELECT 时返回的行顺序不同，会改变 VMem 的条目顺序、embedding 缓存签名和 BM25 平局次序。需要用 `exp3.ablate.OrderedStore` 加 `exp3/data/store_order.json` 还原原始顺序，并加载原始 embedding 缓存 `runs/_vmem2_cache`（只读）。10 段对话中有 9 段能逐字节复现原签名。

---

## 4. VMem-v2.3-clean：方法参数

代码在 `develop/vmem2/`（`store.py`、`pipeline.py`、`run.py`），`Config()` 的默认值就是最终配置。运行时可以用 `python -m vmem2.run --cfg key=value` 覆盖任意字段。

### 4.1 流程

1. **查询规划**：1 次 LLM 调用。输出 `need`、`answer_type`、`aggregate`、`temporal`，以及 4–6 条检索 query。
2. **多路、多粒度检索**：query 集合为原问题加至多 6 条规划 query；在 episode、semantic、原始 turn 三种粒度上，分别做 dense 检索和 BM25 检索，再用 RRF 融合，最后做出处加权。
3. **ViewCards 证据卡片**：每张卡片包含 claim、sources、逐字 quote、time、relation，并判断证据是否充分。
4. **原文核验与确定性时间归一化**。
5. **动态扩展检索**：与第 3 步交替，用后续 query 补检。
6. **作答**：作答上下文依次为卡片、卡片引用的原文、其余检索池；答案若是弃答，重试一次。

每题通常 3 次 LLM 调用，最多 6 次。

### 4.2 全部超参数

| 参数 | 值 | 说明 |
|---|---:|---|
| `rrf_k` | 60 | RRF 常数，rank 从 1 开始 |
| `dense_k` / `sparse_k` | 20 / 12 | 每条 query、每种粒度的 dense / BM25 召回数 |
| BM25 | BM25Okapi，$k_1$=1.5，$b$=0.75 | 分词：小写后取 `[a-z0-9]+`，去停用词；只保留分数 > 0 的结果 |
| 出处加权 | 0.5 / 0.3 | semantic 给来源 episode 投票的权重 / 加到 episode 分数上的系数（写死在代码中） |
| `pool_episodes` / `pool_semantic` | 10 / 20 | 首轮池的 episode / semantic 数 |
| `pool_turn_hits` / `max_pool_turns` | 30 / 90 | 普通问题：turn 命中数 / turn 池上限 |
| `agg_turn_hits` / `agg_max_pool_turns` | 45 / 130 | aggregate 问题（`plan.aggregate` 为真，或 `answer_type` 是 list / count） |
| `turn_context` | 1 | 每个 turn 命中带上 ±1 条同 session 邻居 |
| `expansion_rounds` / `agg_expansion_rounds` | 1 / 2 | 最大扩展轮数 |
| 扩展轮 | ≤ 3 条后续 query；每轮最多新增 6 个 episode、10 条 semantic、40 条 turn；排除已在池中的条目 | 写死 |
| 规划 query 数 | ≤ 6，另加原问题 | 写死 |
| 作答时的引用原文 | turn 来源取 ±2 条同 session 邻居；episode 来源取前 12 条 turn | 写死 |
| quote 核验阈值 | 0.8 | difflib 匹配比例；未通过的卡片标 `(UNVERIFIED)`，不删除 |
| 时间归一化 | quote 前 40 个字符要能在原 turn 中找到；正则匹配 `last / this past / past + 星期 / weekend / week / month` | 改写为 "the X before \<session date\>" |
| `max_tokens` | planner 800 / evidence 4000 / answer 1200 | |
| `norm_time` / `abstain_retry` | True / True | v2.3 新增的两个机制 |
| `plan` / `cards` / `include_pool_in_answer` | True / True / True | 模块开关，供消融用 |
| temperature | 0 | 所有调用 |
| 问题级并发 | 14 | `VMEM_LLM_CONCURRENCY` 默认 16 |

v2.3-clean 与 v2.3 的区别只在 prompt 示例：示例全部改用 2031 年的虚构日期，`controls/check_prompt_leak.py` 检查过，与 LoCoMo 的重合为 0。算法和 `Config` 都没变。

### 4.3 运行入口

- Opus：`runs/run_v3clean.sh`，输出到 `runs/vmem2_v3clean_{dev,holdout}`
- Haiku：`runs/run_haiku45.sh`，输出到 `runs/haiku45_vmem2_{dev,holdout}`
- NEMORI：Opus 输出到 `runs/nemori_full`；Haiku 输出到 `runs/haiku45_nemori_{dev,holdout}`（两组逐题检索结果相同）

---

## 5. 基线设置

### 5.1 统一协议（`baselines/CONTRACT.md`）

- **数据与题目**：同一份 `locomo10.json`，1540 题，不修改文件。
- **推理时不接触 gold**：答案、evidence 和类别标签都不进入推理；gold 字段只在写结果时附加（`common_io.make_record`）。
- **记忆构建**：每个方法用 Opus 4.5 构建一次，Haiku 和 Opus 两组共用。与 NEMORI / VMem 的做法一致。
- **查询阶段**：检索侧的 LLM 调用和作答各跑两遍，先 Haiku 4.5（Phase 1），再 Opus 4.5（Phase 2）。
- **作答**：使用各方法官方的 prompt 和作答流程。
- **其他超参数**：保留官方 LoCoMo 设置；temperature 0 由网关强制。
- **Embedding**：能直接替换的方法换成 Qwen3-Embedding-4B；不能替换的保留官方模型并注明。
- **预算**：每个方法上限 $250（不含 judge），超出需要用户批准。
- **客户端并发**：Opus 阶段 ≤ 8，Haiku 阶段 ≤ 16。
- **实现状态**分三类：
  - official：官方代码，只改 endpoint 和模型配置；
  - adapted：官方核心代码，加上我们的胶水代码；
  - reimplemented：重新实现（本次没有用到）。

### 5.2 各方法设置

| 方法 | 仓库 @ commit | 状态 | 关键参数 | Embedding | 主要偏离 / 修复 |
|---|---|---|---|---|---|
| NEMORI | nemori-ai/nemori @ `d2a6dff` | 参照 | episode top-10，semantic top-20，top-2 episode 附带原文 | Qwen3-4B | 加 Bedrock 补丁；与 VMem 共用同一个库 |
| Mem0 | mem0ai v0.1.94（`07ddd7c`）+ 评测脚本 `b3ede5b` | adapted | 每段对话两个 user（互换角色），每次 add 2 条消息，每位说话人 top_k=30，官方 ANSWER_PROMPT | Qwen3-4B | 用本地库和 Qdrant 代替托管 Platform；事实抽取 prompt 中的 "Today's date" 设为 session 日期 |
| A-Mem | WujiangXu/A-mem @ `0c8039f` | official | k=10 | Qwen3-4B，检索 query 加 instruction | 修复上游缺失的 `import re`；去掉推理时用 gold category 选 prompt 的做法，统一走默认分支 |
| MemoryOS | BAI-LAB/MemoryOS @ `587ed77` | official | STM=1，MTM=2000，θ=0.6，τ=5，α=β=0.8，top-m=5，top-k=10，知识 top-10（以官方 eval 代码为准） | Qwen3-4B | 两处输出解析修复；gold category / evidence 不传入 |
| LightMem | zjunlp/LightMem @ `8449d57` | official | LLMLingua-2 预压缩 (th=512, r=0.7)，话题分段，STM 抽取，离线 LTM 更新 | 官方 all-MiniLM（话题分段阈值依赖它） | 压缩率从脚本中写死的 0.6 改为论文报告过的 0.7 |
| SimpleMem | aiming-lab/SimpleMem @ `db80b6a` | adapted | 滑动窗口 40、重叠 2；检索 top-k 25/5/5（语义 / 关键词 / 元数据）；planning + 最多 2 轮 reflection；max_tokens 16384 | Qwen3-4B（官方是同系列 0.6B） | 修复多段对话共用系统对象导致记忆串到下一段对话；拆成"建库一次 + 两轮 QA" |
| MemR³ | mbzuai-ai4bio/memr3 @ `f2b656b` | official | RAG 后端；256-token 分块，top_k 5，重排前取 20 个候选（cross-encoder），最多 5 轮 | Qwen3-4B | 从 `$LOCOMO` 重建 `locomo10_rag.json`；Zep 后端未跑 |
| MemGAS | ICLR2026_MemGAS @ `c2d4e9f` | adapted | 官方 LoCoMo README 的超参；GMM 建边、熵路由、PPR 图检索 | 官方 Contriever（熵路由、GMM、PPR 依赖其打分尺度） | 绕开若干脚本 bug |
| MRAgent | Ji-shuo/MRAgent @ `7441506` | adapted | K1=80，K2=20，MAX_ROUNDS=8；max_tokens 16384 | Qwen3-4B | 官方按 gold category 切换 prompt，改为只根据问题文本做正则路由；**只跑了 Haiku**（Opus 预计 $280–350，用户决定不跑） |

每个方法完整的命令、配置和偏离说明都在 `baselines/notes/<m>.md`。

---

## 6. 评测协议

- **主指标 J**：LLM-judge 准确率。judge 用 Opus 4.5 和上游 `ACCURACY_PROMPT`，所有方法共用，有共享缓存。
- **辅指标**：F1、BLEU-1，用上游 `metrics/utils.py` 的原样逻辑在原始 response 上计算。Mem0、LightMem 另外报告只截取最终答案的版本，因为它们的官方 prompt 要求逐步推理，原始 response 很长。
- **公平性**：
  - NEMORI 和 VMem 共用同一个库、embedding、LLM 和 judge，差别只在查询时如何检索、组织证据和作答。
  - 推理时不读 gold 答案、evidence 和类别标签。原版 VMem / VERA 按 gold 类别选配置，这里按其发表时的做法评测。
- **泄漏检查**（2026-10-11）：
  - prompt 示例与 gold 的重合已修复（v2.3-clean）。
  - 闭卷对照 C2（`controls/closed_book.py`）的准确率是 21.6%。
  - 对照 C1：只换作答 prompt，在 dev 上只比 NEMORI 高 +1.0 pp，不显著。

---

## 7. 统计方法（各实验通用）

| 方法 | 用途 | 设置 |
|---|---|---|
| 配对 bootstrap | 题级配对差的 95% CI | 重采样题目；RQ8 在抽样层内重采样，2000 次 |
| 精确 McNemar | 题级配对的显著性 | 基于不一致的题对（Exp1、RQ3） |
| 对话聚类 bootstrap | 稳健性检验 | 以对话为单位重采样（RQ6、RQ7、RQ8；RQ8 为 2000 次，其余次数见各脚本） |
| 留一对话（LOCO） | 稳健性检验 | 依次去掉 1 段对话重算，报告范围或符号是否一致 |
| Wilson CI | 未加权比例（RQ4） | |
| 分层抽样加权 | RQ4、RQ8 | 设计权重 1/π，比率估计 |
| 固定随机种子 | 所有抽样 | **20261012**（RQ3 的子集、RQ4 的卡片抽样、RQ8 的题目抽样） |

---

## 8. 各实验设置

### Exp1：主结果表

- **对象**：VMem 与 9 个基线（NEMORI 加 §5 的 8 个），分 Haiku 4.5、Opus 4.5 两个 backbone。
- **指标**：J / F1 / B1，分总体和 4 个类别。
- **生成**：表格由 `scripts/make_exp1.py` 从各 `metrics.json` 直接生成。

### RQ2：证据充分性（`exp2/`，离线）

- **对象**：NEMORI 与 VMem（两个 backbone 都有完整 trace）；MemR³、MRAgent、SimpleMem 只在检索记录允许的范围内纳入。
- **gold 映射**：按 (role, json 解码后的 content) **精确**匹配到记忆库消息；文本相同的 turn 用 session 时间戳消歧；同一 VMem 去重键下的所有 message_id 都算作该 turn 的别名（`exp2/evidence_lib.py`）。
- **覆盖度量**：每个 gold turn 判断状态，再汇总成题级的 complete / partial / missing。
  - **R**：检索记录中包含该 turn，溯源精确到 turn。
  - **V**：原始 turn 在最终作答 prompt 中逐字可见。
  - **C**：被某张卡片引用（只有 VMem 有）。
  - **S**：semantic 只能追到来源 episode，只作补充，不计入 turn 级覆盖。
- **分母**：1531 题。
- **分组**：类别；gold turn 数（1 / 2 / 3+）；是否跨 session；是否跨 episode；列表 / 计数（文本规则）；Temporal 题中是否含相对时间表达。

### RQ3：组件消融（`exp3/`，有新增推理）

- **子集**：按类别分层、比例分配的 400 题，种子 20261012（`exp3/data/subset_400.json`）。各类别：Multi-hop 73、Temporal 83、Open-domain 25、Single-hop 219。
- **全量确认**：1540 题上只跑了 Reification、Matched-Budget、Refinement、ViewCards-in-answering 四项。

| 变体 | 设置 |
|---|---|
| Full VMem | 直接用原始 v2.3-clean 的预测和 trace |
| w/o Query Planning | `Config(plan=False)`：只用原问题检索，同时去掉了自适应预算 |
| w/o Source-Turn Retrieval | 复用已存的规划；每一轮检索都只返回 episode 和 semantic |
| w/o Evidence Reification | 已保存的首轮池直接作答；不做卡片、核验、扩展，也没有卡片派生的引用原文区 |
| w/o ViewCards in Answering | 冻结最终检索池和引用原文区，只删掉卡片块（呈现层消融） |
| w/o Evidence Refinement | 首轮池加首轮卡片作答；未触发扩展的题直接复用 Full 的答案 |
| Matched-Budget Retrieval-Only | 只用原问题做 dense 检索，仿 NEMORI 以 episode 为中心：每个 episode 附上全部原文，再加 top-20 semantic。逐题二分选择 episode 数，让作答 prompt 的 token 数（Bedrock CountTokens）最接近该题 Full 的作答 prompt |

- 所有变体共用的作答设置：temperature 0，max_tokens 1200，`FINAL ANSWER:` 抽取，弃答重试，同一个 judge。
- 首轮池直接取自已保存的 `pool_ids`，不重放检索（重放的 Jaccard ≈ 0.97，不够精确）。扩展题的首轮边界由重放结果估计。

### RQ4：ViewCard 溯源审计（`exp4/`，确定性核验 + 小规模 judge）

- **范围**：两个 backbone 的全部卡片，Opus 10,213 张，Haiku 10,121 张。
- **A：引文核对**（确定性）
  - 精确子串匹配；
  - 规范化后子串匹配（小写、去标点、合并空白）；
  - 按 "..." 分段匹配，每段至少 3 个词；
  - 管线自带的 `verified` 标记（≥ 0.8）单独报告。
- **B：主张–来源一致性**（LLM 判定）
  - 分层抽样：backbone × 类别 × 溯源类型（单一原始 turn / 多来源且含 turn / 仅摘要或事实），每格 12 张，共 288 张，种子 20261012。
  - judge 是 Opus 4.5，temperature 0，只看 claim、time 和被引来源。
  - 五个标签：完全支持 / 部分支持 / 不支持 / 矛盾 / 无法核验。
- **C：时间锚定**（确定性）：以会话日期为锚，按规则检查——yesterday 对应 −1 天，N days ago 对应 −N 天，last year 对应年份 −1，last week / weekday 应写成 "the … before"。

### RQ5：性能–成本（`exp5/`，离线）

- **口径**：只计查询时推理，包括规划、证据构建与扩展、作答和重试。记忆构建成本单独报告，不计 judge。
- **价格**：见 §2。
- **计量**：Full、NEMORI、Matched 都是实测；规划的输入 token 由 CountTokens 重建；扩展题上的首轮证据成本按轮数平分估计。

### RQ6：证据复杂度（`exp6/`，离线）

- **维度**（只用 gold 标注和对话元数据定义）：
  - 证据条数：1 / 2 / 3+；
  - session 分散：1 个 / 2 个及以上；
  - 时间跨度（多 turn 题）：同一天 / 1–30 天 / 31–180 天 / 180 天以上；
  - 列表 / 计数：沿用 RQ2 的规则。
- **分母**：1535 题。
- **方法**：差中差分析，加题级 bootstrap、对话聚类 bootstrap 和 LOCO。

### RQ7：有限预算下的证据恢复（`exp7/`，离线）

- **预算**：source turn 数 B ∈ {10, 20, 40, 60, 80, 100, 120}；另做一版按 token 计的预算。
- **前缀规则**：按原始检索顺序逐个取候选，暴露的 turn 去重后累计；遇到第一个会让累计超出 B 的候选就停止，不跳过。另做"跨界候选整个计入"的敏感性分析。
- **主定义（实际暴露）**：只有逐字出现在 prompt 中的原文 turn 才算；episode 摘要和 semantic 不暴露任何 turn。
- **曲线**：
  - NEMORI 实际可见（top-2 episode 的原文）；
  - NEMORI 把 10 个 episode 离线展开成原文（**假设性**，NEMORI 实际没有展示这些原文）；
  - RQ3 的 Matched 对照；
  - VMem 首轮池（`no_reify_full`）；
  - VMem 首轮加扩展。
- **指标**：complete / partial 覆盖率、gold-turn 召回率、10–120 区间内的归一化 AUC、达到 80% / 90% 覆盖所需的预算。
- **分母**：1531 题。
- **不使用**：`exp3/data/round1_*.json`，它是 replay 估计值。

### RQ8：答案层面的锚定（`exp8/`，judge 调用 $34.87）

- **抽样**：
  - 240 题，种子 20261012。
  - 分层：类别 × gold turn 数（1 / 2+）× 错误标记（四个方法在 Opus 上是否至少有一个答错）。
  - 分配：n_h ∝ √N_h × 1.8（错误层）× 1.7（Multi-hop），每格至少 min(N_h, 6)。
  - Haiku 子样本：每层取前 ⌈n_h/4⌉ 题，共 68 题。
- **证据包**（确定性，只取 LoCoMo 原文）：
  - gold turn 加同一 session 内前后各 2 个 turn；
  - 以问题为 query 的 BM25（rank_bm25 Okapi）top-8；
  - 以 8 个答案（4 方法 × 2 backbone）分别为 query 的 BM25 top-4；
  - 每个 BM25 命中带上前一个 turn；
  - 总数上限 70 个 turn；同一道题的四个方法共用同一个证据包。
- **judge**：
  - Opus 4.5，temperature 0，盲评：不给方法名、正确性标签、gold 答案和 trace。
  - 先拆出原子主张，标为 SUPPORTED / CONTRADICTED / UNSUPPORTED / UNVERIFIABLE / WORLD_KNOWLEDGE。
  - 答案层标签由主张标签确定性推出。
- **第二轮检索**：第一轮判为 UNSUPPORTED 或 UNVERIFIABLE 的主张，用主张文本在全对话上做 BM25 top-5；出现证据包外的新 turn 时重判这条主张。
- **稳定性检查**：打乱证据包中 session 的顺序后重判 40 个答案。
- **人工复核**：29 条有争议的判定。

---

## 9. 基础设施与环境

| 组件 | 位置 / 端口 | 说明 |
|---|---|---|
| 环境变量 | `source develop/env.sh` | 设定 `$DEV`、`$PY`（`/path/to/.venv_vmem/bin/python`）、`$LOCOMO`、`DATABASE_URL`、`EMBEDDING_BASE_URL`、`AWS_REGION`、`DEV_CONVS`、`HOLDOUT_CONVS` |
| Postgres | `127.0.0.1:15432` | NEMORI 库，用户、密码、库名都是 `nemori`；需要时从 dump 恢复 |
| Qdrant | `127.0.0.1:16333` | NEMORI 的向量库 |
| Embedding 服务 | `127.0.0.1:18080/v1` | Qwen3-Embedding-4B |
| 基线网关 | `baselines/gateway/gateway.py`，`:8700` | 详见下文 |
| 作图 | `/usr/bin/python3`（系统 matplotlib） | 各 `exp*/make_figure.py` |

**基线网关**
- 接口：OpenAI 兼容，地址为 `/<tag>/<haiku|opus>/v1`。
- 统一处理：强制 temperature 0；丢弃 top_p、seed、n；去掉 JSON 代码块标记；支持 tools；模拟 stream。
- 磁盘缓存：完全相同的请求不重复计费，中断后重跑即续跑。
- 全局并发：Haiku 48；Opus 分 `us.` 和 `global.` 两条路由，各 20。
- 其他：`/v1/embeddings` 转发到 `:18080`；`gateway/usage.py` 按 tag 统计成本；重启用 `gateway/start.sh`。

**操作注意**
- 不要用 `pkill -f` / `pgrep -f`：它们会匹配到 agent 自己的 shell 命令行并把它杀掉，按 PID 结束进程。
- 子 agent 不能写 `.md` 文件，报告模板需要由主 agent 写。

---

## 10. 成本汇总（只计 API 花费）

| 项目 | 花费 |
|---|---:|
| VMem-v2.3 主运行（Opus，1540 题；dev $44.3 + holdout $154.5） | $198.9（约 $0.13 / 题） |
| 8 个基线（建库 + 两组 QA + smoke，us. 价格，是上限） | $1121.0 |
| 基线 judge（19,181 次调用） | 约 $89 |
| RQ3 消融（生成 + judge） | 约 $380 + $20 |
| RQ4 claim judge | 约 $1.4 |
| RQ8 groundedness judge（1669 次调用） | $34.87 |
| RQ2、RQ5、RQ6、RQ7 | $0（离线） |

---

## 11. 文件索引

| 内容 | 路径（相对 `develop/`） |
|---|---|
| VMem 代码 | `vmem2/` |
| 公共评测 | `common/evaluate.py`、`common/bedrock_llm.py` |
| NEMORI 配置 | `configs/nemori_{opus45,haiku45}.json` |
| 主运行结果 | `runs/vmem2_v3clean_*`、`runs/haiku45_vmem2_*`、`runs/nemori_full`、`runs/haiku45_nemori_*` |
| 对照实验 | `controls/`（`closed_book.py`、`check_prompt_leak.py`）、`runs/c1_cleanprompt_dev`、`runs/c2_closed_book` |
| 基线 | `baselines/`（`CONTRACT.md`、`notes/`、`runs/<m>/{haiku,opus}/`、`gateway/`、`repos/`） |
| 主表 | `scripts/make_exp1.py` → `2026-10-11_exp1_main_results.md` |
| RQ2–RQ8 | `exp2/` … `exp8/`，报告为 `2026-10-12_exp{2..8}_*.md`；每个目录都按 `analyze.py` → `make_figure.py` → `build_report.py`（正文在 `report_template.md`）的顺序运行 |
