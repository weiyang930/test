# Exp3 / RQ3：查询特定证据构建的组件消融（Dissecting Query-Specific Evidence Construction）

日期：2026-10-12　方法：VMem-v2.3-clean（`vmem2/`，未改动）　记忆库：NEMORI Opus 4.5 构建的同一个库（`locomo_opus45`）
作答 backbone：Claude Haiku 4.5、Claude Opus 4.5　judge：Opus 4.5（`common/evaluate.py` 原样）　代码与数据：`develop/exp3/`

> **研究问题**：VMem 的证据发现（查询规划 + 多粒度检索）、源头锚定的证据实体化（ViewCards）、充分性驱动的扩展，分别对效果有多大贡献？这些贡献是否只是"检索更多 / 上下文更大"带来的？

## 0. 结论速览

1. **只把上下文加大，追不上 VMem。** 匹配预算纯检索对照与 Full VMem 用同一记忆库、同一答题指令，并且逐题把答题 prompt 的 token 数对齐到 Full VMem（97% 的题偏差 ≤10%）。全量 1540 题上它仍比 Full VMem 低 **5.9 pp（Haiku）/ 5.7 pp（Opus）**，95% CI 均远离 0，McNemar p < 1e-10。它看到的原始 turn 更多（122 / 108 条/题），但 gold 证据完整覆盖率只有 77% / 75%，Full VMem 是 92–94%。
2. **证据发现（规划 + 多粒度检索）有独立支撑，而且主要体现在证据召回上。** "w/o Evidence Reification"只保留规划后的首轮多粒度检索，不做任何卡片、核验或扩展。它的 prompt 比匹配对照还短（约 9.5k vs 11k token），准确率却高 **+4.7 pp（Haiku）/ +5.2 pp（Opus）**（全量，p < 1e-7）。单独去掉其中一个检索成分时：
   - 去掉原始 turn 检索路由：原文可见率从 92% 降到 68%，准确率 −1.7 / −2.5 pp（子集，CI 触及 0）；
   - 去掉查询规划：准确率几乎不变（−0.5 / −0.2 pp），但多跳题原文可见率下降 9–17 pp。
3. **ViewCard 证据实体化本身没有可检出的准确率收益。**
   - 首轮检索池完全相同、只差"卡片 + 核验 + 引用原文上下文"时，全量差值为 +0.7 pp [−0.5, +1.9]（Haiku）、−0.3 pp [−1.2, +0.7]（Opus）。
   - 只从最终答题 prompt 里删掉卡片块（呈现层消融）：Haiku 全量 −0.2 pp [−1.4, +1.0]；Opus 子集 +0.5 pp [−1.5, +2.5]、全量 +0.1 pp [−0.8, +1.2]。
   - Full VMem 相对"直接答首轮池"的全量差距（+1.2 / +0.5 pp）都不显著。
   - 但"直接答"的成本只有 Full 的约 40%（Haiku $0.013 vs $0.032/题，Opus $0.055 vs $0.129/题）。
4. **充分性驱动扩展：只在真正触发扩展的少数题上有作用，Opus 上显著。**
   - Opus 只有 8.5% 的题触发扩展。这些题上，扩展后比只用首轮证据高 **+9.2 pp [+3.1, +15.3]**（15 胜 / 3 负，p = 0.0075），整体 +0.8 pp [+0.3, +1.4]。
   - Haiku 有 21.5% 的题触发扩展，条件效应 +2.4 pp [−1.5, +6.3]，不显著。
   - 证据层面：扩展把这些题的 gold 原文完整可见率从 77% / 82% 提高到 89% / 93%。首轮原文不完整、扩展后补全的题，准确率从 40–47% 升到 69–73%。
5. **答题环节的 replay 可信。** 用重建的 Full VMem 答题 prompt 重新作答：Haiku 有 391/400 个答案逐字相同，judge 标签差异为 0；Opus 差值 −0.2 pp [−1.8, +1.2]。所以答题环节的随机噪声远小于本文报告的效应。

**主消融表**（LLM-judge 准确率 %，括号内为相对 Full VMem 的 Δ pp；* 表示配对 bootstrap 95% CI 不含 0）

| 变体 | Haiku 子集 (400) | Opus 子集 (400) | Haiku 全量 (1540) | Opus 全量 (1540) |
|---|---|---|---|---|
| Full VMem | **88.0** | **90.2** | **89.6** | **91.4** |
| w/o Query Planning | 87.5 (-0.5) | 90.0 (-0.2) | — | — |
| w/o Source-Turn Retrieval | 86.2 (-1.7) | 87.8 (-2.5) | — | — |
| w/o Evidence Reification | 87.5 (-0.5) | 89.0 (-1.2) | 88.4 (-1.2) | 90.9 (-0.5) |
| w/o ViewCards in Answering | 90.2 (+2.2) | 90.8 (+0.5) | 89.4 (-0.2) | 91.6 (+0.1) |
| w/o Evidence Refinement | 87.5 (-0.5) | 89.5 (-0.7) | 89.1 (-0.5) | 90.6 (-0.8*) |
| Matched-Budget Retrieval-Only | 83.8 (-4.2*) | 85.8 (-4.5*) | 83.7 (-5.9*) | 85.7 (-5.7*) |

## 1. 实验设计与控制

### 1.1 变体的精确实现（复用了哪些阶段）

所有变体的作答模型、temperature 0、max_tokens 1200、`FINAL ANSWER:` 抽取、v2.3 的弃答重试，以及 judge，都与 Full VMem 相同。无卡片变体的答题 prompt 由 `vmem2.pipeline.ANSWER_PROMPT` 删去与卡片有关的文字得到，其余指令逐字保留（见 `exp3/ablate.py` 中的 `NOCARD_PROMPT` 和 `POOL_PROMPT`）。

| 变体 | 实现 | 复用的已存阶段 | 新增 LLM 调用 |
|---|---|---|---|
| Full VMem | 原始 v2.3-clean 预测、trace、judge 标签 | 全部 | 无 |
| w/o Query Planning | `Config(plan=False)`：只用原问题检索，其后组件全部保留。由于规划器还决定"聚合题加宽预算、多一轮扩展"，这一项同时去掉了**自适应预算** | 无 | 证据构建（含扩展）+ 答题 |
| w/o Source-Turn Retrieval | 复用已存规划；每一轮检索（含扩展轮）都只返回 episode 和 semantic，去掉原始 turn 路由。卡片构建、核验、扩展、答题都重跑。卡片引用某个 episode 时，答题 prompt 中"引用原文"区仍会放入该 episode 的前 12 条 turn（原机制保留） | 规划 | 证据构建 + 答题 |
| w/o Evidence Reification | 首轮池 = 规划后的首轮多粒度检索池，**直接取自已存池**（见 §1.3）；不做卡片、核验、扩展，也没有卡片派生的引用原文区；答题 prompt 只含检索池 | 规划、首轮检索 | 答题 |
| w/o ViewCards in Answering | 冻结最终检索池和"引用原文"区（由卡片选出，逐题核对与 Full 完全一致），只删掉卡片块。**这是呈现层消融**：冻结的上下文本身就是借助卡片选出来的 | 规划、全部检索轮、证据构建、核验 | 答题 |
| w/o Evidence Refinement | 首轮池 + 首轮卡片（核验字段原样保留）+ 由首轮卡片派生的引用原文区，用 Full 的答题 prompt 作答。**未触发扩展的题输入与 Full 完全相同，直接复用 Full 的答案** | 规划、首轮检索、首轮证据构建、核验 | 只对触发扩展的题答题 |
| Matched-Budget Retrieval-Only | 同一记忆库，只用原问题做稠密检索，**仿 NEMORI 的 episode 中心检索**：情景按相似度排序，每个情景附上全部原始 turn，加 top-20 语义记忆。逐题二分选择情景数，使答题 prompt 的 token 数（Bedrock CountTokens 精确计数）最接近该题 Full VMem 答题 prompt 的 token 数。无卡片，单轮 | 无 | 答题（每题 1 次） |
| （校验）Full VMem answer re-run | 从 trace 重建 Full 的答题 prompt 并重新作答 | 全部前置阶段 | 答题 |

**归因注意：**
- w/o Query Planning 同时改变了查询多样性、自适应预算和证据构建时的 information need。
- w/o Evidence Reification 同时去掉了卡片、核验、扩展和引用原文区。
- 匹配对照与 Full 的差异包括规划、turn 路由、RRF 融合、卡片和扩展，不能归给其中任何单一组件。

所以组件层面的结论只用"单一机制差异"的对照（§4）来下。

### 1.2 子集与流程

- **子集**：按类别分层、比例分配的 400 题，固定种子 20261012，只依据题目元数据抽样，在任何消融运行之前确定（`exp3/make_subset.py` → `exp3/data/subset_400.json`）。各类别题数：Multi-hop 73、Temporal 83、Open-domain 25、Single-hop 219。
- **流程**：
  1. 冒烟测试：每个变体在 Haiku 上跑 6 题，结果在 `exp3/runs/smoke/`。
  2. Haiku 4.5 跑全部 7 个变体（子集）。
  3. Opus 4.5 跑全部 7 个变体（子集）。缓存让新增成本很低，所以规划、turn 路由两项也一起跑了。
  4. 全量 1540 题确认：两个 backbone 都跑了 Reification、Matched-Budget、Refinement（只需对触发扩展的题重答，很便宜）和 ViewCards-in-answering。
- 全量运行会先复用子集中已完成的同一配置记录，再补齐其余题。子集结果与全量结果分别报告。

### 1.3 复现基础与有效性检查（不使用 gold）

| Backbone | 范围 | 变体 | n | 首轮池来源：已保存池（无扩展，精确） | 已保存池前缀（扩展题，边界估计） | 检索 replay 与原池逐项一致 | replay Jaccard 中位数 / 最小 | 扩展题中首轮卡片可切分 |
|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | subset | w/o Evidence Refinement | 400 | 310 | 90 | 2 (0.5%) | 0.967 / 0.816 | 75/90 |
| Haiku 4.5 | subset | w/o Evidence Reification | 400 | 310 | 90 | 2 (0.5%) | 0.967 / 0.816 | — |
| Opus 4.5 | subset | w/o Evidence Refinement | 400 | 366 | 34 | 5 (1.2%) | 0.966 / 0.783 | 29/34 |
| Opus 4.5 | subset | w/o Evidence Reification | 400 | 366 | 34 | 5 (1.2%) | 0.966 / 0.783 | — |
| Haiku 4.5 | full | w/o Evidence Refinement | 1540 | 1209 | 331 | 14 (0.9%) | 0.966 / 0.794 | 260/331 |
| Haiku 4.5 | full | w/o Evidence Reification | 1540 | 1209 | 331 | 14 (0.9%) | 0.966 / 0.794 | — |
| Opus 4.5 | full | w/o Evidence Refinement | 1540 | 1409 | 131 | 10 (0.6%) | 0.968 / 0.766 | 113/131 |
| Opus 4.5 | full | w/o Evidence Reification | 1540 | 1409 | 131 | 10 (0.6%) | 0.968 / 0.766 | — |

- **记忆库**：原 Postgres 已不存在，从 `vmem_backup/nemori_opus45_pg.dump` 恢复到临时容器 `rq3_pg`（127.0.0.1:15432）。内容与原库相同，但无序 SELECT 返回的行顺序不同。这会改变 `vmem2/store.py` 的条目顺序，进而影响 embedding 缓存签名、BM25 平局次序和 turn 去重。
- **条目顺序恢复**（`exp3/store_order.py`）：用 embedding 匹配恢复原条目顺序，10 个对话中有 9 个**逐字节重现了原缓存签名**。剩下的 Audrey_5 有 42 组文本完全相同的语义记忆，组内次序无法唯一确定；其文本序列与原始一致，只有同文本条目的 id 可能互换。之后一律加载**原始**条目 embedding（`runs/_vmem2_cache`，只读）。实验中误写入 `runs/_vmem2_cache` 的 10 个新缓存文件已移到 `exp3/data/vmem2_cache_restored/`，`runs/` 下原有文件没有改动。
- **答题 prompt 重建**：Full VMem answer re-run 的结果见 §0 第 5 点，说明从 trace 重建的答题 prompt 与原 prompt 一致，答题噪声很小。
- **检索 replay 只是近似**：query embedding 在当前 GPU 上与原始运行存在微小数值差异，重放检索与原池的 Jaccard 中位数为 0.97，逐项完全一致的不到 2%。因此 **Reification 和 Refinement 的首轮池不用重放结果，而直接取自已保存的池**：
  - 未扩展的题（Opus 91.5%、Haiku 78.5%）：已存池就是首轮池，精确。
  - 扩展的题：已存池是"首轮 + 各扩展轮"的拼接。episode 边界固定为前 10 条；semantic 和 turn 的边界用重放结果定位（选最能把已存列表分成"在重放首轮池中 / 不在"的切分点），所以边界是估计值。
  - 首轮卡片取"第一张引用了首轮之后标签的卡片"之前的所有卡片；不可判定的题单独做了敏感性分析（§4.3）。

## 2. 结果：Haiku 4.5（400 题子集）

| 变体 | n | Overall | Δ vs Full [95% CI] | 胜/负 | McNemar p | Multi-hop | Temporal | Open-domain | Single-hop | F1 |
|---|---|---|---|---|---|---|---|---|---|---|
| **Full VMem** | 400 | **88.0** | — | — | — | 83.6 | 88.0 | 64.0 | 92.2 | 44.5 |
| w/o Query Planning | 400 | 87.5 | -0.5 [-3.2, +2.2] | 14/16 | 0.856 | 82.2 (-1.4) | 83.1 (-4.8) | 72.0 (+8.0) | 92.7 (+0.5) | 46.1 |
| w/o Source-Turn Retrieval | 400 | 86.2 | -1.7 [-4.5, +1.0] | 13/20 | 0.296 | 83.6 (+0.0) | 83.1 (-4.8) | 60.0 (-4.0) | 91.3 (-0.9) | 41.9 |
| w/o Evidence Reification | 400 | 87.5 | -0.5 [-3.0, +2.0] | 13/15 | 0.851 | 84.9 (+1.4) | 81.9 (-6.0) | 60.0 (-4.0) | 93.6 (+1.4) | 43.9 |
| w/o ViewCards in Answering | 400 | 90.2 | +2.2 [-0.5, +5.0] | 19/10 | 0.136 | 89.0 (+5.5) | 85.5 (-2.4) | 72.0 (+8.0) | 94.5 (+2.3) | 44.8 |
| w/o Evidence Refinement | 400 | 87.5 | -0.5 [-2.2, +1.2] | 6/8 | 0.791 | 79.5 (-4.1) | 85.5 (-2.4) | 76.0 (+12.0) | 92.2 (+0.0) | 44.5 |
| Matched-Budget Retrieval-Only | 400 | 83.8 | -4.2 [-7.5, -1.2] | 13/30 | 0.0137 | 82.2 (-1.4) | 77.1 (-10.8) | 60.0 (-4.0) | 89.5 (-2.7) | 42.0 |
| Full VMem, answer re-run (replay check) | 400 | 88.0 | +0.0 [+0.0, +0.0] | 0/0 | 1 | 83.6 (+0.0) | 88.0 (+0.0) | 64.0 (+0.0) | 92.2 (+0.0) | 44.5 |

## 3. 结果：Opus 4.5（400 题子集）

| 变体 | n | Overall | Δ vs Full [95% CI] | 胜/负 | McNemar p | Multi-hop | Temporal | Open-domain | Single-hop | F1 |
|---|---|---|---|---|---|---|---|---|---|---|
| **Full VMem** | 400 | **90.2** | — | — | — | 87.7 | 88.0 | 68.0 | 94.5 | 52.1 |
| w/o Query Planning | 400 | 90.0 | -0.2 [-2.2, +1.8] | 8/9 | 1 | 84.9 (-2.7) | 88.0 (+0.0) | 68.0 (+0.0) | 95.0 (+0.5) | 53.0 |
| w/o Source-Turn Retrieval | 400 | 87.8 | -2.5 [-5.0, +0.0] | 7/17 | 0.0639 | 78.1 (-9.6) | 84.3 (-3.6) | 72.0 (+4.0) | 94.1 (-0.5) | 49.0 |
| w/o Evidence Reification | 400 | 89.0 | -1.2 [-3.5, +1.0] | 8/13 | 0.383 | 83.6 (-4.1) | 84.3 (-3.6) | 68.0 (+0.0) | 95.0 (+0.5) | 51.7 |
| w/o ViewCards in Answering | 400 | 90.8 | +0.5 [-1.5, +2.5] | 9/7 | 0.804 | 90.4 (+2.7) | 85.5 (-2.4) | 72.0 (+4.0) | 95.0 (+0.5) | 54.7 |
| w/o Evidence Refinement | 400 | 89.5 | -0.7 [-2.0, +0.2] | 1/4 | 0.375 | 86.3 (-1.4) | 86.7 (-1.2) | 68.0 (+0.0) | 94.1 (-0.5) | 51.9 |
| Matched-Budget Retrieval-Only | 400 | 85.8 | -4.5 [-7.2, -1.8] | 8/26 | 0.00294 | 82.2 (-5.5) | 80.7 (-7.2) | 72.0 (+4.0) | 90.4 (-4.1) | 49.1 |
| Full VMem, answer re-run (replay check) | 400 | 90.0 | -0.2 [-1.8, +1.2] | 4/5 | 1 | 89.0 (+1.4) | 86.7 (-1.2) | 72.0 (+4.0) | 93.6 (-0.9) | 52.7 |

## 4. 三个科学问题

### 4.1 查询引导的多粒度发现能否提升证据召回？

证据覆盖用 RQ2 的精确 gold-turn 映射计算（只用于离线诊断），分母是可完全映射的题：
- **R**：gold turn 落在检索到的记录里；
- **V**：gold 原文逐字出现在最终答题 prompt 中；
- **C**：被卡片引用。

各类别都列出 R / V。

Haiku 子集：

| 变体 | 可映射题数 | R complete | V complete | C complete | 可见原始 turn/题 | Multi-hop R / V | Temporal R / V | Open-domain R / V | Single-hop R / V |
|---|---|---|---|---|---|---|---|---|---|
| Full VMem | 399 | 94.5 | 92.5 | 83.5 | 112.8 | 83.6 / 78.1 | 97.6 / 96.4 | 75.0 / 70.8 | 99.1 / 98.2 |
| w/o Query Planning | 399 | 92.2 | 88.5 | 80.2 | 86.5 | 74.0 / 61.6 | 95.2 / 92.8 | 66.7 / 62.5 | 100.0 / 98.6 |
| w/o Source-Turn Retrieval | 399 | 87.5 | 68.4 | 82.0 | 27.1 | 65.8 / 30.1 | 94.0 / 80.7 | 54.2 / 41.7 | 95.9 / 79.5 |
| w/o Evidence Reification | 399 | 91.5 | 84.2 | — | 92.2 | 75.3 / 61.6 | 95.2 / 88.0 | 62.5 / 45.8 | 98.6 / 94.5 |
| w/o ViewCards in Answering | 399 | 94.5 | 92.5 | — | 112.8 | 83.6 / 78.1 | 97.6 / 96.4 | 75.0 / 70.8 | 99.1 / 98.2 |
| w/o Evidence Refinement | 399 | 92.0 | 90.0 | 81.7 | 99.7 | 76.7 / 71.2 | 96.4 / 95.2 | 62.5 / 58.3 | 98.6 / 97.7 |
| Matched-Budget Retrieval-Only | 399 | 77.4 | 77.4 | — | 123.1 | 47.9 / 47.9 | 85.5 / 85.5 | 50.0 / 50.0 | 87.2 / 87.2 |

Opus 子集：

| 变体 | 可映射题数 | R complete | V complete | C complete | 可见原始 turn/题 | Multi-hop R / V | Temporal R / V | Open-domain R / V | Single-hop R / V |
|---|---|---|---|---|---|---|---|---|---|
| Full VMem | 399 | 92.5 | 91.5 | 87.5 | 95.6 | 75.3 / 72.6 | 96.4 / 96.4 | 66.7 / 62.5 | 99.5 / 99.1 |
| w/o Query Planning | 399 | 92.5 | 89.2 | 85.2 | 81.9 | 74.0 / 64.4 | 97.6 / 96.4 | 62.5 / 58.3 | 100.0 / 98.2 |
| w/o Source-Turn Retrieval | 399 | 84.5 | 68.4 | 82.7 | 24.8 | 54.8 / 27.4 | 91.6 / 79.5 | 54.2 / 50.0 | 95.0 / 79.9 |
| w/o Evidence Reification | 399 | 91.5 | 85.0 | — | 84.3 | 75.3 / 63.0 | 92.8 / 86.7 | 62.5 / 50.0 | 99.5 / 95.4 |
| w/o ViewCards in Answering | 399 | 92.5 | 91.5 | — | 95.6 | 75.3 / 72.6 | 96.4 / 96.4 | 66.7 / 62.5 | 99.5 / 99.1 |
| w/o Evidence Refinement | 399 | 92.0 | 91.0 | 87.0 | 91.5 | 75.3 / 72.6 | 94.0 / 94.0 | 66.7 / 62.5 | 99.5 / 99.1 |
| Matched-Budget Retrieval-Only | 399 | 76.4 | 76.4 | — | 107.3 | 45.2 / 45.2 | 84.3 / 84.3 | 50.0 / 50.0 | 86.8 / 86.8 |

全量（两个 backbone）：

| 变体 | 可映射题数 | R complete | V complete | C complete | 可见原始 turn/题 | Multi-hop R / V | Temporal R / V | Open-domain R / V | Single-hop R / V |
|---|---|---|---|---|---|---|---|---|---|
| Full VMem | 1531 | 93.5 | 91.6 | 83.3 | 113.0 | 78.9 / 72.8 | 97.8 / 95.9 | 70.7 / 69.6 | 99.3 / 98.7 |
| w/o Evidence Reification | 1531 | 91.0 | 82.6 | — | 92.7 | 70.6 / 52.7 | 96.6 / 87.5 | 60.9 / 47.8 | 98.9 / 94.4 |
| w/o ViewCards in Answering | 1531 | 93.5 | 91.6 | — | 113.0 | 78.9 / 72.8 | 97.8 / 95.9 | 70.7 / 69.6 | 99.3 / 98.7 |
| w/o Evidence Refinement | 1531 | 91.4 | 89.3 | 80.7 | 99.9 | 72.0 / 65.6 | 96.9 / 94.4 | 60.9 / 58.7 | 99.2 / 98.6 |
| Matched-Budget Retrieval-Only | 1531 | 77.0 | 77.0 | — | 122.2 | 47.7 / 47.7 | 84.7 / 84.7 | 55.4 / 55.4 | 86.2 / 86.2 |

| 变体 | 可映射题数 | R complete | V complete | C complete | 可见原始 turn/题 | Multi-hop R / V | Temporal R / V | Open-domain R / V | Single-hop R / V |
|---|---|---|---|---|---|---|---|---|---|
| Full VMem | 1531 | 92.8 | 91.7 | 86.6 | 97.1 | 74.9 / 72.0 | 97.8 / 96.9 | 69.6 / 66.3 | 99.4 / 99.0 |
| w/o Evidence Reification | 1531 | 91.0 | 83.1 | — | 84.8 | 71.3 / 55.6 | 95.0 / 86.9 | 63.0 / 48.9 | 99.0 / 94.5 |
| w/o ViewCards in Answering | 1531 | 92.8 | 91.7 | — | 97.1 | 74.9 / 72.0 | 97.8 / 96.9 | 69.6 / 66.3 | 99.4 / 99.0 |
| w/o Evidence Refinement | 1531 | 91.8 | 90.7 | 85.4 | 92.6 | 74.2 / 71.3 | 95.6 / 94.7 | 66.3 / 64.1 | 99.0 / 98.6 |
| Matched-Budget Retrieval-Only | 1531 | 75.0 | 75.0 | — | 107.7 | 43.0 / 43.0 | 83.1 / 83.1 | 54.3 / 54.3 | 84.9 / 84.9 |

**解读：**
- **规划 + 多粒度检索带来的召回优势，不是 token 预算能解释的。** 匹配对照每题看到的原始 turn 比 Full VMem 还多（Haiku 122 vs 113，Opus 108 vs 97），但 R/V 完整率只有 75–77%，Full VMem 是 92–94%。Multi-hop 上差距最大：43–48% vs 72–79%。只用原问题去找 episode 再把整段原文铺开，会把预算花在不相关的 episode 上。
- **原始 turn 路由是原文可见率的主要来源。** 去掉它后 V 从 92% 降到 68%（Multi-hop 从 73–78% 降到 27–30%）。虽然卡片仍能通过 episode 引用找回部分原文（C 只降 1–5 pp），准确率仍下降 1.7–2.5 pp（Opus 子集 p = 0.064，Haiku p = 0.30，两者都不显著）。
- **查询规划主要帮助多跳题的原文可见。** 去掉规划后 Multi-hop V 下降 8–17 pp，但总体准确率几乎不变（−0.5 / −0.2 pp）。在这个基准上，规划对最终准确率的独立贡献没有被检测到。

### 4.2 控制检索信息后，证据实体化能否改善作答？

两组对照的检索信息分别被固定：
- **同一首轮检索池**：w/o Reification（直接答）vs w/o Refinement（首轮卡片 + 核验 + 引用原文区）；
- **同一最终池和同一引用原文区**：w/o ViewCards in Answering vs Full（只差卡片块的呈现）。

| 对比 | 子集 Haiku | 子集 Opus | 全量 Haiku | 全量 Opus |
|---|---|---|---|---|
| 首轮池固定：卡片+核验+引用原文 − 直接答 | +0.0 [-2.2, +2.2]，11/11，p=1 | +0.5 [-1.5, +2.5]，9/7，p=0.8 | +0.7 [-0.5, +1.9]，50/39，p=0.29 | -0.3 [-1.2, +0.7]，28/32，p=0.7 |
| 冻结上下文：卡片块呈现 − 无卡片块 | -2.2 [-5.0, +0.5]，10/19，p=0.14 | -0.5 [-2.5, +1.5]，7/9，p=0.8 | +0.2 [-1.0, +1.4]，50/47，p=0.84 | -0.1 [-1.2, +0.8]，31/33，p=0.9 |
| Full − 直接答首轮池（实体化 + 扩展合计） | +0.5 [-2.0, +3.0]，15/13，p=0.85 | +1.2 [-1.0, +3.5]，13/8，p=0.38 | +1.2 [-0.1, +2.5]，63/44，p=0.081 | +0.5 [-0.5, +1.6]，37/29，p=0.39 |

**解读：**
- **控制检索信息后，实体化没有带来可检出的准确率收益。** 各组差值都在 ±1 pp 左右，CI 都包含 0。Haiku 子集上"去掉卡片块"一度高 2.2 pp，但全量上没有复现（−0.2 pp）。
- 卡片带来了可测的**证据组织**变化：
  - 引用原文区把 gold 原文可见率从 83% 提到 89–91%（首轮池固定时，比较 w/o Reification 与 w/o Refinement 的 V）；
  - 83–87% 的题，全部 gold turn 都被卡片显式引用。

  但在 Haiku / Opus 这样的强作答模型上，这些变化没有转化成准确率差异。
- 卡片的另一个作用是驱动扩展：扩展查询由卡片构建步骤给出。这部分效应在 4.3 单独评估。

### 4.3 充分性驱动的扩展能否解决首轮证据不足？

只有构建器判定证据不足、给出后续查询、且检索到了新内容的题，才会触发扩展：Opus 占 8.5%，Haiku 占 21.5%。这是由系统自身选择出来的子集（难题居多，准确率明显低于其余题），**不代表全部题**。下表同时给出条件效应和整体效应。

子集：

| Backbone | 范围 | 题数 | 占比 | w/o Refinement | Full | Δ [95% CI] | 胜/负 | p |
|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 触发扩展的题 | 90 | 22.5% | 70.0 | 72.2 | +2.2 [-5.6, +11.1] | 8/6 | 0.791 |
| Haiku 4.5 | 其中首轮卡片可切分（敏感性） | 75 | 18.8% | 70.7 | 72.0 | +1.3 [-8.0, +10.7] | 7/6 | 1 |
| Haiku 4.5 | 未触发（答案复用，Δ≡0） | 310 | 77.5% | 92.6 | 92.6 | +0.0 [+0.0, +0.0] | 0/0 | 1 |
| Haiku 4.5 | 全部 | 400 | 100.0% | 87.5 | 88.0 | +0.5 [-1.2, +2.2] | 8/6 | 0.791 |
| Opus 4.5 | 触发扩展的题 | 34 | 8.5% | 55.9 | 64.7 | +8.8 [-2.9, +20.6] | 4/1 | 0.375 |
| Opus 4.5 | 其中首轮卡片可切分（敏感性） | 29 | 7.2% | 51.7 | 65.5 | +13.8 [+3.4, +27.6] | 4/0 | 0.125 |
| Opus 4.5 | 未触发（答案复用，Δ≡0） | 366 | 91.5% | 92.6 | 92.6 | +0.0 [+0.0, +0.0] | 0/0 | 1 |
| Opus 4.5 | 全部 | 400 | 100.0% | 89.5 | 90.2 | +0.8 [-0.2, +2.0] | 4/1 | 0.375 |

全量：

| Backbone | 范围 | 题数 | 占比 | w/o Refinement | Full | Δ [95% CI] | 胜/负 | p |
|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 触发扩展的题 | 331 | 21.5% | 71.3 | 73.7 | +2.4 [-1.5, +6.3] | 26/18 | 0.291 |
| Haiku 4.5 | 其中首轮卡片可切分（敏感性） | 260 | 16.9% | 68.8 | 71.5 | +2.7 [-1.9, +7.3] | 22/15 | 0.324 |
| Haiku 4.5 | 未触发（答案复用，Δ≡0） | 1209 | 78.5% | 94.0 | 94.0 | +0.0 [+0.0, +0.0] | 0/0 | 1 |
| Haiku 4.5 | 全部 | 1540 | 100.0% | 89.1 | 89.6 | +0.5 [-0.3, +1.4] | 26/18 | 0.291 |
| Opus 4.5 | 触发扩展的题 | 131 | 8.5% | 61.8 | 71.0 | +9.2 [+3.1, +15.3] | 15/3 | 0.00754 |
| Opus 4.5 | 其中首轮卡片可切分（敏感性） | 113 | 7.3% | 60.2 | 71.7 | +11.5 [+5.3, +18.6] | 15/2 | 0.00235 |
| Opus 4.5 | 未触发（答案复用，Δ≡0） | 1409 | 91.5% | 93.3 | 93.3 | +0.0 [+0.0, +0.0] | 0/0 | 1 |
| Opus 4.5 | 全部 | 1540 | 100.0% | 90.6 | 91.4 | +0.8 [+0.3, +1.4] | 15/3 | 0.00754 |

证据层面（触发扩展的题，首轮 vs 最终）：

| Backbone | 触发扩展题（可映射） | 首轮 R complete | 最终 R complete | 首轮 V complete | 最终 V complete | 首轮 C complete | 最终 C complete | 首轮 V 不完整 → 最终完整 | 其中准确率 首轮→最终 |
|---|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 89 | 82.0 | 93.3 | 79.8 | 91.0 | 71.9 | 79.8 | 10/18 | 40.0 → 70.0 (n=10) |
| Opus 4.5 | 34 | 76.5 | 82.4 | 76.5 | 82.4 | 70.6 | 76.5 | 2/8 | 0.0 → 50.0 (n=2) |

| Backbone | 触发扩展题（可映射） | 首轮 R complete | 最终 R complete | 首轮 V complete | 最终 V complete | 首轮 C complete | 最终 C complete | 首轮 V 不完整 → 最终完整 | 其中准确率 首轮→最终 |
|---|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 326 | 84.4 | 94.2 | 81.9 | 92.9 | 66.6 | 78.8 | 36/59 | 47.2 → 69.4 (n=36) |
| Opus 4.5 | 131 | 77.9 | 89.3 | 77.1 | 88.5 | 66.4 | 80.2 | 15/30 | 40.0 → 73.3 (n=15) |

**解读：**
- **Opus 上，扩展对触发它的题有显著帮助**：+9.2 pp [+3.1, +15.3]，15 胜 / 3 负；只看首轮卡片可切分的 113 题，+11.5 pp。因为只有 8.5% 的题触发扩展，整体只提升 +0.8 pp（同样显著，p = 0.0075）。
- Haiku 的条件效应方向一致（+2.4 pp），但不显著。Haiku 触发扩展的比例是 Opus 的 2.5 倍，更像是"过度扩展"，平均收益被稀释。
- 证据层面，扩展把这些题的完整原文可见率提高了 11–12 pp。首轮原文不完整、扩展后补全的题（Opus 15 题、Haiku 36 题），准确率提升 22–33 pp。题数很少，只作描述，不作推断。

## 5. 全量 1540 题确认

### 5.1 Haiku 4.5

| 变体 | n | Overall | Δ vs Full [95% CI] | 胜/负 | McNemar p | Multi-hop | Temporal | Open-domain | Single-hop | F1 |
|---|---|---|---|---|---|---|---|---|---|---|
| **Full VMem** | 1540 | **89.6** | — | — | — | 86.9 | 89.1 | 68.8 | 93.1 | 44.5 |
| w/o Evidence Reification | 1540 | 88.4 | -1.2 [-2.5, +0.1] | 44/63 | 0.0814 | 84.4 (-2.5) | 85.0 (-4.0) | 66.7 (-2.1) | 93.5 (+0.4) | 44.9 |
| w/o ViewCards in Answering | 1540 | 89.4 | -0.2 [-1.4, +1.0] | 47/50 | 0.839 | 84.0 (-2.8) | 87.2 (-1.9) | 67.7 (-1.0) | 94.5 (+1.4) | 45.5 |
| w/o Evidence Refinement | 1540 | 89.1 | -0.5 [-1.4, +0.3] | 18/26 | 0.291 | 84.0 (-2.8) | 88.2 (-0.9) | 67.7 (-1.0) | 93.6 (+0.5) | 44.5 |
| Matched-Budget Retrieval-Only | 1540 | 83.7 | -5.9 [-7.7, -4.2] | 47/138 | 1.41e-11 | 79.1 (-7.8) | 80.4 (-8.7) | 64.6 (-4.2) | 88.7 (-4.4) | 41.9 |

### 5.2 Opus 4.5

| 变体 | n | Overall | Δ vs Full [95% CI] | 胜/负 | McNemar p | Multi-hop | Temporal | Open-domain | Single-hop | F1 |
|---|---|---|---|---|---|---|---|---|---|---|
| **Full VMem** | 1540 | **91.4** | — | — | — | 88.3 | 91.3 | 69.8 | 95.0 | 53.1 |
| w/o Evidence Reification | 1540 | 90.9 | -0.5 [-1.6, +0.5] | 29/37 | 0.389 | 86.9 (-1.4) | 89.4 (-1.9) | 71.9 (+2.1) | 95.0 (+0.0) | 53.6 |
| w/o ViewCards in Answering | 1540 | 91.6 | +0.1 [-0.8, +1.2] | 33/31 | 0.901 | 89.0 (+0.7) | 90.0 (-1.2) | 74.0 (+4.2) | 95.0 (+0.0) | 54.6 |
| w/o Evidence Refinement | 1540 | 90.6 | -0.8 [-1.4, -0.3] | 3/15 | 0.00754 | 86.9 (-1.4) | 90.0 (-1.2) | 69.8 (+0.0) | 94.5 (-0.5) | 53.0 |
| Matched-Budget Retrieval-Only | 1540 | 85.7 | -5.7 [-7.3, -4.2] | 32/120 | 3.53e-13 | 80.1 (-8.2) | 83.8 (-7.5) | 72.9 (+3.1) | 89.8 (-5.2) | 50.6 |

### 5.3 关键对照汇总（B − A，配对 bootstrap 95% CI，精确 McNemar）

Haiku 子集：

| 对比（B − A） | A | B | n | A 准确率 | B 准确率 | Δ [95% CI] | 胜/负 | p |
|---|---|---|---|---|---|---|---|---|
| 答案重跑噪声（同一 prompt 重新作答） | Full VMem | Full VMem, answer re-run (replay check) | 400 | 88.0 | 88.0 | +0.0 [+0.0, +0.0] | 0/0 | 1 |
| 证据实体化（同一首轮检索池：无卡片 → 首轮卡片+核验+引用原文） | w/o Evidence Reification | w/o Evidence Refinement | 400 | 87.5 | 87.5 | +0.0 [-2.2, +2.2] | 11/11 | 1 |
| 充分性驱动扩展（首轮 → 最终） | w/o Evidence Refinement | Full VMem | 400 | 87.5 | 88.0 | +0.5 [-1.2, +2.2] | 8/6 | 0.791 |
| ViewCard 呈现（冻结最终池与引用原文） | w/o ViewCards in Answering | Full VMem | 400 | 90.2 | 88.0 | -2.2 [-5.0, +0.5] | 10/19 | 0.136 |
| 规划多粒度检索 vs 原问题情景检索（均无卡片，后者匹配 token） | Matched-Budget Retrieval-Only | w/o Evidence Reification | 400 | 83.8 | 87.5 | +3.8 [+0.8, +7.0] | 28/13 | 0.0275 |
| 完整 VMem vs 匹配预算纯检索 | Matched-Budget Retrieval-Only | Full VMem | 400 | 83.8 | 88.0 | +4.2 [+1.2, +7.5] | 30/13 | 0.0137 |
| 查询规划 | w/o Query Planning | Full VMem | 400 | 87.5 | 88.0 | +0.5 [-2.2, +3.2] | 16/14 | 0.856 |
| 原始 turn 检索路由 | w/o Source-Turn Retrieval | Full VMem | 400 | 86.2 | 88.0 | +1.8 [-1.0, +4.5] | 20/13 | 0.296 |

Opus 子集：

| 对比（B − A） | A | B | n | A 准确率 | B 准确率 | Δ [95% CI] | 胜/负 | p |
|---|---|---|---|---|---|---|---|---|
| 答案重跑噪声（同一 prompt 重新作答） | Full VMem | Full VMem, answer re-run (replay check) | 400 | 90.2 | 90.0 | -0.2 [-1.8, +1.2] | 4/5 | 1 |
| 证据实体化（同一首轮检索池：无卡片 → 首轮卡片+核验+引用原文） | w/o Evidence Reification | w/o Evidence Refinement | 400 | 89.0 | 89.5 | +0.5 [-1.5, +2.5] | 9/7 | 0.804 |
| 充分性驱动扩展（首轮 → 最终） | w/o Evidence Refinement | Full VMem | 400 | 89.5 | 90.2 | +0.8 [-0.2, +2.0] | 4/1 | 0.375 |
| ViewCard 呈现（冻结最终池与引用原文） | w/o ViewCards in Answering | Full VMem | 400 | 90.8 | 90.2 | -0.5 [-2.5, +1.5] | 7/9 | 0.804 |
| 规划多粒度检索 vs 原问题情景检索（均无卡片，后者匹配 token） | Matched-Budget Retrieval-Only | w/o Evidence Reification | 400 | 85.8 | 89.0 | +3.2 [+0.2, +6.2] | 25/12 | 0.047 |
| 完整 VMem vs 匹配预算纯检索 | Matched-Budget Retrieval-Only | Full VMem | 400 | 85.8 | 90.2 | +4.5 [+1.8, +7.2] | 26/8 | 0.00294 |
| 查询规划 | w/o Query Planning | Full VMem | 400 | 90.0 | 90.2 | +0.2 [-1.8, +2.2] | 9/8 | 1 |
| 原始 turn 检索路由 | w/o Source-Turn Retrieval | Full VMem | 400 | 87.8 | 90.2 | +2.5 [+0.0, +5.0] | 17/7 | 0.0639 |

Haiku 全量：

| 对比（B − A） | A | B | n | A 准确率 | B 准确率 | Δ [95% CI] | 胜/负 | p |
|---|---|---|---|---|---|---|---|---|
| 证据实体化（同一首轮检索池：无卡片 → 首轮卡片+核验+引用原文） | w/o Evidence Reification | w/o Evidence Refinement | 1540 | 88.4 | 89.1 | +0.7 [-0.5, +1.9] | 50/39 | 0.289 |
| 充分性驱动扩展（首轮 → 最终） | w/o Evidence Refinement | Full VMem | 1540 | 89.1 | 89.6 | +0.5 [-0.3, +1.4] | 26/18 | 0.291 |
| ViewCard 呈现（冻结最终池与引用原文） | w/o ViewCards in Answering | Full VMem | 1540 | 89.4 | 89.6 | +0.2 [-1.0, +1.4] | 50/47 | 0.839 |
| 规划多粒度检索 vs 原问题情景检索（均无卡片，后者匹配 token） | Matched-Budget Retrieval-Only | w/o Evidence Reification | 1540 | 83.7 | 88.4 | +4.7 [+3.1, +6.3] | 116/44 | 1.13e-08 |
| 完整 VMem vs 匹配预算纯检索 | Matched-Budget Retrieval-Only | Full VMem | 1540 | 83.7 | 89.6 | +5.9 [+4.2, +7.7] | 138/47 | 1.41e-11 |

Opus 全量：

| 对比（B − A） | A | B | n | A 准确率 | B 准确率 | Δ [95% CI] | 胜/负 | p |
|---|---|---|---|---|---|---|---|---|
| 证据实体化（同一首轮检索池：无卡片 → 首轮卡片+核验+引用原文） | w/o Evidence Reification | w/o Evidence Refinement | 1540 | 90.9 | 90.6 | -0.3 [-1.2, +0.7] | 28/32 | 0.699 |
| 充分性驱动扩展（首轮 → 最终） | w/o Evidence Refinement | Full VMem | 1540 | 90.6 | 91.4 | +0.8 [+0.3, +1.4] | 15/3 | 0.00754 |
| ViewCard 呈现（冻结最终池与引用原文） | w/o ViewCards in Answering | Full VMem | 1540 | 91.6 | 91.4 | -0.1 [-1.2, +0.8] | 31/33 | 0.901 |
| 规划多粒度检索 vs 原问题情景检索（均无卡片，后者匹配 token） | Matched-Budget Retrieval-Only | w/o Evidence Reification | 1540 | 85.7 | 90.9 | +5.2 [+3.7, +6.8] | 115/35 | 3.77e-11 |
| 完整 VMem vs 匹配预算纯检索 | Matched-Budget Retrieval-Only | Full VMem | 1540 | 85.7 | 91.4 | +5.7 [+4.2, +7.3] | 120/32 | 3.53e-13 |

## 6. 成本诊断

"每题"成本把复用阶段的开销也算进来，即这个变体作为独立系统部署时的成本。复用阶段的开销按以下方式确定：
- **规划调用**：输入用 CountTokens 精确计数重建的 PLAN_PROMPT，输出按已存规划 JSON 的 token 数近似（`exp3/stage_costs.py`）；
- **Full 的答题调用**：用 answer re-run 的实测值；
- **扩展轮的证据调用**：按 Full 的证据调用总量平均分摊。

因为需要 answer re-run 的实测值，w/o ViewCards 和 w/o Refinement 只在子集上算了每题成本。价格：Opus $5 / $25、Haiku $1.1 / $5.5 每百万输入 / 输出 token，与此前的运行一致。

| 变体 | n | LLM 调用/题 | prompt tokens/题 | completion tokens/题 | 估算成本 $/题 | 本实验新增调用/题 | 本实验新增成本（合计 $） |
|---|---|---|---|---|---|---|---|
| Full VMem | 400 | 3.35 | 23,242 | 1,195 | 0.0321 | 0.00 | 0.00 |
| w/o Query Planning | 400 | 2.24 | 20,335 | 902 | 0.0273 | 2.24 | 10.93 |
| w/o Source-Turn Retrieval | 400 | 3.46 | 15,423 | 1,202 | 0.0236 | 2.46 | 9.00 |
| w/o Evidence Reification | 400 | 2.03 | 9,904 | 345 | 0.0128 | 1.03 | 4.69 |
| w/o ViewCards in Answering | 400 | 3.34 | 22,489 | 1,176 | 0.0312 | 1.01 | 5.39 |
| w/o Evidence Refinement | 400 | 3.01 | 19,498 | 967 | 0.0268 | 0.23 | 1.14 |
| Matched-Budget Retrieval-Only | 400 | 1.03 | 12,118 | 221 | 0.0145 | 1.03 | 5.82 |
| Full VMem, answer re-run (replay check) | 400 | 3.35 | 23,242 | 1,195 | 0.0321 | 1.01 | 5.76 |

| 变体 | n | LLM 调用/题 | prompt tokens/题 | completion tokens/题 | 估算成本 $/题 | 本实验新增调用/题 | 本实验新增成本（合计 $） |
|---|---|---|---|---|---|---|---|
| Full VMem | 400 | 3.11 | 20,398 | 1,052 | 0.1283 | 0.00 | 0.00 |
| w/o Query Planning | 400 | 2.11 | 19,062 | 874 | 0.1172 | 2.11 | 46.87 |
| w/o Source-Turn Retrieval | 400 | 3.21 | 13,834 | 1,061 | 0.0957 | 2.21 | 36.41 |
| w/o Evidence Reification | 400 | 2.02 | 9,491 | 332 | 0.0558 | 1.02 | 20.43 |
| w/o ViewCards in Answering | 400 | 3.11 | 19,720 | 1,034 | 0.1245 | 1.01 | 21.94 |
| w/o Evidence Refinement | 400 | 3.02 | 19,361 | 998 | 0.1217 | 0.11 | 2.19 |
| Matched-Budget Retrieval-Only | 400 | 1.02 | 10,672 | 211 | 0.0586 | 1.02 | 23.45 |
| Full VMem, answer re-run (replay check) | 400 | 3.11 | 20,398 | 1,052 | 0.1283 | 1.01 | 23.47 |

| 变体 | n | LLM 调用/题 | prompt tokens/题 | completion tokens/题 | 估算成本 $/题 | 本实验新增调用/题 | 本实验新增成本（合计 $） |
|---|---|---|---|---|---|---|---|
| Full VMem | 1540 | 3.34 | 23,003 | 1,199 | 0.0319 | 0.00 | 0.00 |
| w/o Evidence Reification | 1540 | 2.02 | 9,784 | 344 | 0.0127 | 1.02 | 17.83 |
| w/o ViewCards in Answering | 400 | 3.34 | 22,489 | 1,176 | 0.0312 | 1.01 | 5.39 |
| w/o Evidence Refinement | 1299 | 3.01 | 19,694 | 951 | 0.0269 | 0.07 | 1.14 |
| Matched-Budget Retrieval-Only | 1540 | 1.04 | 12,119 | 224 | 0.0146 | 1.04 | 22.43 |

| 变体 | n | LLM 调用/题 | prompt tokens/题 | completion tokens/题 | 估算成本 $/题 | 本实验新增调用/题 | 本实验新增成本（合计 $） |
|---|---|---|---|---|---|---|---|
| Full VMem | 1540 | 3.13 | 20,499 | 1,077 | 0.1294 | 0.00 | 0.00 |
| w/o Evidence Reification | 1540 | 2.01 | 9,422 | 332 | 0.0554 | 1.01 | 78.10 |
| w/o ViewCards in Answering | 400 | 3.11 | 19,720 | 1,034 | 0.1245 | 1.01 | 21.94 |
| w/o Evidence Refinement | 1443 | 3.01 | 19,307 | 1,006 | 0.1217 | 0.03 | 2.19 |
| Matched-Budget Retrieval-Only | 1540 | 1.03 | 10,776 | 215 | 0.0593 | 1.03 | 91.27 |

匹配预算的核对（实际答题 prompt token 数 vs 目标值，即 Full VMem 答题 prompt 的 CountTokens 计数）：

| Backbone | 范围 | n | 目标 token（Full 答题 prompt）均值 | 实际答题 prompt token 均值 | 实际/目标 中位数 | |实际−目标|/目标 ≤10% 的题 | 情景数/题 | 原始 turn/题 |
|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | subset | 400 | 11,773 | 11,764 | 0.999 | 390 (97.5%) | 14.9 | 123.3 |
| Opus 4.5 | subset | 400 | 10,426 | 10,436 | 1.001 | 385 (96.2%) | 13.3 | 107.3 |
| Haiku 4.5 | full | 1540 | 11,689 | 11,680 | 1.001 | 1503 (97.6%) | 15.0 | 122.4 |
| Opus 4.5 | full | 1540 | 10,478 | 10,469 | 0.999 | 1493 (96.9%) | 13.5 | 107.7 |

匹配的只是**答题上下文**预算。Full VMem 另外有规划和证据构建调用：总 prompt token 约是匹配对照的 1.9–2.2 倍，LLM 调用 3.1–3.3 次 vs 1 次。所以"Full 优于匹配对照"并没有控制**总**推理开销。真正把总开销控制住的对照是 w/o Reification：2 次调用、总 token 是 Full 的 43–46%，准确率与 Full 的差距在全量上不显著。

## 7. 实际 API 花费

| Backbone | 运行 | 题数 | 其中新调用 LLM 的题 | 新增调用 | 新增 prompt tokens | 新增 completion tokens | 实际花费 $ |
|---|---|---|---|---|---|---|---|
| Haiku 4.5 | full_replay | 400 | 400 | 406 | 4,778,567 | 91,100 | 5.76 |
| Haiku 4.5 | matched | 400 | 400 | 411 | 4,847,398 | 88,306 | 5.82 |
| Haiku 4.5 | matched_full | 1140 | 1140 | 1,183 | 13,816,061 | 257,357 | 16.61 |
| Haiku 4.5 | no_cards | 400 | 400 | 403 | 4,477,217 | 83,857 | 5.39 |
| Haiku 4.5 | no_cards_full | 1140 | 1140 | 1,153 | 12,719,702 | 237,595 | 15.30 |
| Haiku 4.5 | no_plan | 400 | 400 | 897 | 8,134,044 | 360,615 | 10.93 |
| Haiku 4.5 | no_refine | 400 | 90 | 92 | 925,297 | 22,119 | 1.14 |
| Haiku 4.5 | no_refine_full | 1140 | 241 | 256 | 2,616,166 | 63,662 | 3.23 |
| Haiku 4.5 | no_reify | 400 | 400 | 411 | 3,823,559 | 87,967 | 4.69 |
| Haiku 4.5 | no_reify_full | 1140 | 1140 | 1,161 | 10,710,826 | 247,149 | 13.14 |
| Haiku 4.5 | no_turn | 400 | 400 | 986 | 6,031,057 | 430,395 | 9.00 |
| Opus 4.5 | full_replay | 400 | 400 | 406 | 4,243,681 | 90,229 | 23.47 |
| Opus 4.5 | matched | 400 | 400 | 409 | 4,268,862 | 84,306 | 23.45 |
| Opus 4.5 | matched_full | 1140 | 1140 | 1,178 | 12,326,179 | 247,405 | 67.82 |
| Opus 4.5 | no_cards | 400 | 400 | 404 | 3,972,558 | 83,100 | 21.94 |
| Opus 4.5 | no_cards_full | 1140 | 1140 | 1,152 | 11,405,479 | 239,243 | 63.01 |
| Opus 4.5 | no_plan | 400 | 400 | 843 | 7,624,932 | 349,731 | 46.87 |
| Opus 4.5 | no_refine | 400 | 34 | 43 | 388,881 | 9,904 | 2.19 |
| Opus 4.5 | no_refine_full | 1140 | 97 | 114 | 1,119,214 | 27,560 | 6.29 |
| Opus 4.5 | no_reify | 400 | 400 | 407 | 3,658,134 | 85,721 | 20.43 |
| Opus 4.5 | no_reify_full | 1140 | 1140 | 1,154 | 10,319,665 | 242,838 | 57.67 |
| Opus 4.5 | no_turn | 400 | 400 | 882 | 5,395,569 | 377,237 | 36.41 |
| 合计（生成） | | | | | | | **460.55** |

新增 judge 调用（Opus 4.5，缓存未命中）：6455 次；按每次约 450 输入 / 60 输出 token 估算约 $24.21。冒烟测试（exp3/runs/smoke）另有约 $2（Haiku）。

## 8. 客观总结

**有独立证据支持的：**
1. **VMem 的增益不能用"检索更多 / 上下文更大"解释。** 答题上下文逐题匹配后，Full VMem 仍高 5.7–5.9 pp（两个 backbone、子集和全量都显著）。
2. **"规划后的多粒度检索"本身就足以超过匹配预算的 episode 检索**（+4.7 / +5.2 pp，全量显著），而且是用更短的 prompt 做到的。它的主要作用是提高 gold 证据的完整召回和原文可见。
3. **充分性驱动扩展对 Opus 触发扩展的题有显著帮助**（条件 +9.2 pp，整体 +0.8 pp）。

**倾向性的、但未达到显著的：**
- 原始 turn 检索路由：准确率 −1.7 / −2.5 pp，但对原文可见率的影响很大且一致；
- Haiku 上的扩展：+2.4 pp（条件效应）。

**没有检出效应（中性）的：**
- 查询规划对最终准确率的独立贡献；
- ViewCard 证据实体化对准确率的贡献，无论是固定首轮池，还是冻结上下文只改呈现，都没有检出。

卡片的作用主要体现在证据组织、可追溯性（83–87% 的题全部 gold turn 被引用）和驱动扩展上；作为答题时的额外呈现，没有带来准确率提升。

**对写作的提示：** 去掉证据构建、直接答规划后的首轮池，就能以约 40% 的成本保留 Full 约 98–99% 的准确率。这既是一个强消融结果，也是一个值得在论文中诚实呈现的"性价比"发现。如果要主张卡片的价值，更站得住的论点是可追溯性和扩展驱动，而不是直接提升准确率。

## 9. 局限

- 扩展题的首轮池边界是借助近似 replay 估计的；不过池的内容全部来自已存池，首轮卡片能精确切分的题上结论一致。
- Audrey_5（conv-47）有少数同文本语义记忆的 id 次序无法唯一恢复，只影响该对话中这些条目的 id 和来源日期。
- 子集上 Open-domain 只有 25 题，类别级差值噪声很大。
- 所有对比都是在已有 Full 运行的条件下做的单次重答，没有对每个变体做多次采样；answer re-run 显示单次答题的噪声很小。
- 匹配对照只模拟了一种合理的"只靠更多上下文"策略（仿 NEMORI 的 episode 展开），不代表所有纯检索策略。

## 10. 复现命令与输出路径

```bash
cd /path/to/VMem/develop && source env.sh
# 0) 基础设施：恢复记忆库 + embedding 服务
docker run -d --name rq3_pg -e POSTGRES_USER=nemori -e POSTGRES_PASSWORD=nemori -e POSTGRES_DB=nemori \
  -p 127.0.0.1:15432:5432 -v /path/to/vmem_backup:/backup:ro postgres:16-alpine postgres -c max_connections=200
docker exec rq3_pg pg_restore -U nemori -d nemori --no-owner /backup/nemori_opus45_pg.dump
(cd infra && GPU=0 bash start_embed.sh)
# 1) 子集、条目顺序恢复、replay 检查、规划成本
$PY exp3/make_subset.py
$PY exp3/store_order.py            # 需要 exp3/data/vmem2_cache_restored/*.npy（恢复库上的重新 embedding）
$PY exp3/check_replay.py
$PY exp3/stage_costs.py
# 2) 变体（可断点续跑；每个变体结束后自动 judge）
exp3/run_variants.sh haiku subset 10 full_replay no_cards matched no_turn no_plan no_refine no_reify
exp3/run_variants.sh opus  subset 8  full_replay no_cards no_refine no_reify matched no_turn no_plan
exp3/run_variants.sh haiku full 10 no_reify matched no_cards no_refine
exp3/run_variants.sh opus  full 8  no_reify matched no_refine no_cards
$PY exp3/judge.py --backbone opus --variant full; $PY exp3/judge.py --backbone haiku --variant full   # Full VMem 标签（缓存命中）
# 3) 分析、报告、图
$PY exp3/analyze.py && $PY exp3/build_report.py && /usr/bin/python3 exp3/make_figure.py
```

- **逐题记录**：`exp3/runs/<backbone>/<variant>[_full]/records.jsonl`。字段包括 response、new_usage、reused_stages、info，以及 trace 中的 pool_ids、cards、rounds。
- **judge 标签**：`exp3/runs/<backbone>/<variant>[_full]/judged.json`。新增的 judge 缓存在 `exp3/data/judge_cache.jsonl`；原缓存 `runs/_judge_cache` 只读。
- **表格**：`exp3/tables/{accuracy,coverage,cost}.csv`、`report_tables.md`。
- **作图数据**：
  - `exp3/figdata/ablation_table.csv`：论文消融表，含 overall、Δ、CI、胜负、各类别、R/V/C、成本；
  - `exp3/figdata/accuracy_cost.csv`：准确率–成本图的数据；
  - 可选图 `exp3/figures/rq3_accuracy_cost.{pdf,png}`。
- **中间缓存**：`exp3/data/`，包括 store_order.json、round1_*.json、replay_check.json、plan_cost_*.json、tokcount_*.jsonl。
- **规范**：没有修改 `vmem2/` 和 `runs/` 下的任何已有文件；推理时从未读取 gold 标注，gold 只用于 §4.1 的离线覆盖诊断。
