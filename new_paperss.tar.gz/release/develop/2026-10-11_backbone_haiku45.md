# 换 backbone 实验：Claude Haiku 4.5（2026-10-11）

> 目的：检验 VMem-v2.3-clean 相对 NEMORI 的显著提升是否依赖 Opus 4.5。做法是把查询阶段的所有 LLM 调用换成更小、更便宜的 **Claude Haiku 4.5**，其余设置全部不变，重跑两种方法。
> 主文档：`2026-10-11_vmem2_method_and_results.md`（方法见 §3/§13，Opus 4.5 的结果见 §12.4）。

**结论**：换成 Haiku 4.5 之后，提升不但还在，**还变大了**。
- LoCoMo 全集：VMem-v2.3-clean 0.8961，NEMORI 0.7649，高 **+13.1 pp**，95% CI [+11.2, +15.1]，W/L 233/31，p ≈ 2e-39。Opus 4.5 下这个差距是 +10.7 pp。
- 从未用于开发的 holdout：高 **+13.3 pp**，[+11.1, +15.5]。
- 4 个类别全部显著为正（p < 0.001）。

另外两点：
- 用 Haiku 的 VMem（0.8961）仍比用 Opus 的 NEMORI（0.8071）高 +8.9 pp，而两者的推理成本差不多。
- 把 backbone 从 Opus 换成 Haiku，NEMORI 掉了 4.2 pp，VMem 只掉了 1.8 pp。

---

## 1. 实验设置

| 项目 | 取值 |
|---|---|
| 查询阶段 LLM（新） | `bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0`，temperature 0 |
| 记忆库 | **不变**：继续用 Opus 4.5 构建的同一份 NEMORI store（agent `locomo_opus45`） |
| Judge | **不变**：Opus 4.5，上游 `ACCURACY_PROMPT`，temperature 0（显式传入 `--judge-model`） |
| Embedding / 数据 / 题目 / 指标 | 与主实验完全相同（Qwen3-Embedding-4B；LoCoMo cat 1–4，共 1540 题） |
| NEMORI | 上游 `search.py`，默认设置（10 个 episode + 20 条 semantic，vector 检索，top-2 episode 带原文）；只把 `llm_model` 换成 Haiku 4.5（`configs/nemori_haiku45.json`） |
| VMem-v2.3-clean | 代码、prompt、`Config()` 都**不做任何改动**；planner、evidence、answer、abstain-retry 全部换成 Haiku 4.5 |
| Dev / Holdout | 与主实验相同：dev = conv-26、conv-41（304 题），holdout = 其余 8 段对话（1236 题）。先跑 dev 检查无误，再跑 holdout，各只跑一次 |
| 统计 | 逐题配对：paired bootstrap 95% CI，exact McNemar |

**控制变量核查**
- NEMORI-Haiku 和 NEMORI-Opus 检索到的上下文**逐题完全相同**：在 dev 的 392 题（含 cat5）上逐条比对了检索结果 id，全部一致。所以 NEMORI 两次运行之间唯一的差别就是作答模型。
- 四组结果的 `metrics.json` 都记录了 `judge_model = claude-opus-4-5`。
- 0 个 LLM 错误，0 个空答案。

**备注**：按上游协议，NEMORI 的 response 是模型输出的全文。Haiku 和 Opus 一样会写出推理过程，judge 读取全文判分，与 Opus 那组的协议一致。所以 NEMORI 的 F1/BLEU 很低（约 0.09），这不是本次实验特有的问题，见主文档 §5。

---

## 2. 主要结果：Haiku 4.5 下 VMem-v2.3-clean vs NEMORI

表中 Δ、CI、W/L、p 都是 VMem 相对 NEMORI 的逐题配对统计（两者都用 Haiku 4.5）。F1/BLEU-1 是 VMem-Haiku 的数值。

### 2.1 Holdout（8 段对话，1236 题）
| Cat | n | NEMORI-Haiku | **VMem-Haiku** | Δ | 95% CI | W/L | p | F1 | BLEU-1 |
|---|---:|---:|---:|---:|---|---|---:|---:|---:|
| 1 multi-hop | 219 | 0.6804 | **0.8493** | **+16.9 pp** | [+11.0, +22.8] | 44/7 | 1e-7 | 0.3329 | 0.2609 |
| 2 temporal | 257 | 0.6926 | **0.8755** | **+18.3 pp** | [+13.2, +23.4] | 51/4 | 2e-11 | 0.5341 | 0.4187 |
| 3 open-domain | 75 | 0.4533 | **0.6533** | **+20.0 pp** | [+10.7, +30.7] | 16/1 | 3e-4 | 0.2505 | 0.2028 |
| 4 single-hop | 685 | 0.8336 | **0.9285** | **+9.5 pp** | [+6.9, +12.1] | 79/14 | 4e-12 | 0.4664 | 0.3505 |
| **overall** | 1236 | 0.7540 | **0.8867** | **+13.3 pp** | [+11.1, +15.5] | 190/26 | 6e-32 | 0.4437 | 0.3399 |

### 2.2 Dev（2 段对话，304 题）
| Cat | n | NEMORI-Haiku | **VMem-Haiku** | Δ | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 63 | 0.7460 | **0.9365** | +19.1 pp | [+9.5, +28.6] | 12/0 | 5e-4 |
| 2 temporal | 64 | 0.8125 | **0.9531** | +14.1 pp | [+6.2, +23.4] | 9/0 | 0.004 |
| 3 open-domain | 21 | 0.6667 | **0.8095** | +14.3 pp | [−9.5, +38.1] | 5/2 | 0.45 |
| 4 single-hop | 156 | 0.8526 | **0.9423** | +9.0 pp | [+3.9, +14.7] | 17/3 | 0.003 |
| **overall** | 304 | 0.8092 | **0.9342** | **+12.5 pp** | [+8.6, +16.8] | 43/5 | 1e-8 |

### 2.3 LoCoMo 全集（1540 题）
| Cat | n | NEMORI-Haiku | **VMem-Haiku** | Δ | 95% CI | W/L | p | F1 | BLEU-1 |
|---|---:|---:|---:|---:|---|---|---:|---:|---:|
| 1 multi-hop | 282 | 0.6950 | **0.8688** | **+17.4 pp** | [+12.4, +22.7] | 56/7 | 1e-10 | 0.3453 | 0.2646 |
| 2 temporal | 321 | 0.7165 | **0.8910** | **+17.4 pp** | [+13.1, +21.8] | 60/4 | 7e-14 | 0.5518 | 0.4213 |
| 3 open-domain | 96 | 0.5000 | **0.6875** | **+18.8 pp** | [+9.4, +28.1] | 21/3 | 3e-4 | 0.2252 | 0.1835 |
| 4 single-hop | 841 | 0.8371 | **0.9310** | **+9.4 pp** | [+7.0, +11.8] | 96/17 | 2e-14 | 0.4622 | 0.3442 |
| **overall** | 1540 | 0.7649 | **0.8961** | **+13.1 pp** | [+11.2, +15.1] | 233/31 | 2e-39 | 0.4447 | 0.3356 |

NEMORI-Haiku 在全集上的 F1 / BLEU-1 为 0.0925 / 0.0363。

---

## 3. 跨 backbone 对比（2 方法 × 2 模型）

### 3.1 总表（LLM-judge 准确率）
| | NEMORI | VMem-v2.3-clean | Δ（VMem − NEMORI） |
|---|---:|---:|---:|
| **Opus 4.5**：dev | 0.8454 | 0.9342 | +8.9 pp |
| **Opus 4.5**：holdout | 0.7977 | 0.9094 | +11.2 pp [+9.1, +13.3] |
| **Opus 4.5**：全集 | 0.8071 | 0.9143 | **+10.7 pp** [+8.9, +12.6] |
| **Haiku 4.5**：dev | 0.8092 | 0.9342 | +12.5 pp |
| **Haiku 4.5**：holdout | 0.7540 | 0.8867 | +13.3 pp [+11.1, +15.5] |
| **Haiku 4.5**：全集 | 0.7649 | 0.8961 | **+13.1 pp** [+11.2, +15.1] |

全集分类别的提升：

| Cat | Opus：Δ | Haiku：Δ |
|---|---:|---:|
| 1 multi-hop | +17.4 | +17.4 |
| 2 temporal | +13.4 | +17.4 |
| 3 open-domain | +8.3（p = 0.057） | +18.8（p = 3e-4） |
| 4 single-hop | +7.7 | +9.4 |

### 3.2 换成小模型后，各方法掉了多少（全集，Opus → Haiku，同一方法逐题配对）
| 方法 | Opus 4.5 | Haiku 4.5 | 变化 | 95% CI | W/L（Haiku 赢/输） | p |
|---|---:|---:|---:|---|---|---:|
| NEMORI | 0.8071 | 0.7649 | **−4.2 pp** | [−5.6, −2.9] | 25/90 | 8e-10 |
| VMem-v2.3-clean | 0.9143 | 0.8961 | **−1.8 pp** | [−3.0, −0.7] | 30/58 | 0.004 |

分类别看：
- **NEMORI** 在 temporal 上掉 6.2 pp（W/L 0/20），在 open-domain 上掉 11.5 pp，在 single-hop 上掉 3.6 pp。
- **VMem** 在各类别上掉 1.0–2.2 pp，其中只有 single-hop 的下降显著（−1.9 pp，p = 0.011）。
- 在 dev 上，VMem-Haiku 和 VMem-Opus 完全持平（0.9342 vs 0.9342，W/L 7/7）。

**解读**：
- NEMORI 把时间推算和信息整合都交给作答模型。模型变弱，这两类题首先受影响，例如 temporal 题 Haiku 一题都没赢。
- VMem 把这部分工作前移到了结构化的检索和证据构建：多路规划检索把证据找全，卡片附带逐字引用和解析好的时间，星期类相对时间由代码确定性换算。作答模型需要做的推理更少，所以对 backbone 的强弱不敏感。
- 这和主文档 §2 的诊断一致：主要瓶颈是证据覆盖，而不是推理能力。

### 3.3 小模型 + VMem vs 大模型 + NEMORI（全集）
| Cat | NEMORI-Opus | VMem-Haiku | Δ | 95% CI | W/L | p |
|---|---:|---:|---:|---|---|---:|
| 1 multi-hop | 0.7092 | 0.8688 | +16.0 pp | [+11.0, +20.9] | 53/8 | 3e-9 |
| 2 temporal | 0.7788 | 0.8910 | +11.2 pp | [+6.9, +15.6] | 46/10 | 1e-6 |
| 3 open-domain | 0.6146 | 0.6875 | +7.3 pp | [−1.0, +15.6] | 12/5 | 0.14 |
| 4 single-hop | 0.8728 | 0.9310 | +5.8 pp | [+3.6, +8.1] | 72/23 | 5e-7 |
| **overall** | 0.8071 | **0.8961** | **+8.9 pp** | [+7.1, +10.8] | 183/46 | 2e-20 |

用便宜约 5 倍的 Haiku 4.5 跑 VMem，推理成本和用 Opus 跑 NEMORI 相当（见 §4），但准确率高 8.9 pp。

---

## 4. 成本与运行统计

价格取 Bedrock `us.` profile：Haiku 4.5 为 $1.1 / $5.5，Opus 4.5 为 $5.5 / $27.5（每 M tokens）。

| | NEMORI-Haiku | VMem-Haiku | 参照：NEMORI-Opus | 参照：VMem-Opus |
|---|---:|---:|---:|---:|
| LLM 调用数 | 1986（含 cat5） | 5142 | — | 4813 |
| prompt / completion tokens | 10.36M / 0.42M | 35.42M / 1.85M | 7.99M / 0.25M（仅 cat1–4） | 31.57M / 1.66M |
| 平均 prompt tokens / 题（cat1–4） | 5.2k（上下文与 Opus 组相同） | 23.0k | 5.2k | 20.5k |
| 花费（按 us. 价格） | **$13.7** | **$49.1** | 约 $51 | 约 $219 |

- 本次实验总花费：Haiku 推理 $62.8，加 Opus judge 约 $13，**合计约 $76**。
- 用时：dev 约 15 分钟（NEMORI 9 分钟 + VMem 5 分钟），holdout 约 40 分钟（NEMORI 11 分钟 + VMem 18 分钟 + 评测）。

VMem-Haiku 的行为统计（全集）：
- **扩展检索触发得更多**：有 331 题（21.5%）做了至少 1 轮扩展，Opus 只有 131 题（8.5%）。Haiku 更常判定"证据不够"，于是多检索一轮，prompt tokens 也因此略多（+12%）。
- 弃答重试触发 15 次，Opus 为 22 次。
- 没有产出任何卡片的题有 8 道，Opus 为 1 道；这些题仍然可以依靠兜底的检索池作答。
- JSON 解析和输出格式没有出现任何问题。

---

## 5. 写论文时的要点

1. **鲁棒性**：换成同代的小模型，VMem 的提升从 +10.7 pp 增加到 +13.1 pp。dev、holdout、全集三个层面，4 个类别全部显著。可以写成："VMem 的增益不依赖强大的 backbone，在弱模型上增益更大。"
2. **对模型强弱不敏感**：从 Opus 换到 Haiku，NEMORI 掉 4.2 pp，VMem 只掉 1.8 pp。这说明 VMem 把推理负担转移到了检索和证据构建上。
3. **性价比**：VMem + Haiku 的推理成本约等于 NEMORI + Opus，准确率却高 8.9 pp。
4. **公平性**：记忆库、embedding、judge 都固定不变，NEMORI 两次运行的检索上下文逐题相同，VMem 的配置没有为 Haiku 做任何调整（零调参迁移）。
5. **局限**：
   - 只测了 Claude 家族内的一个小模型。Sonnet 5.5 / Haiku 5.5 在 Bedrock 上只允许 temperature = 1，无法沿用 temperature 0 的协议，所以没有纳入。
   - 记忆库仍然是 Opus 4.5 构建的。"用 Haiku 构建记忆库"属于另一个实验维度，本实验没有覆盖。
   - Judge 仍然是 Opus 4.5，同时也是另一组实验的作答模型。

---

## 6. 复现与文件

```bash
runs/run_haiku45.sh dev       # NEMORI-Haiku（上游 search.py）→ 评测；VMem-Haiku → 评测
runs/run_haiku45.sh holdout
PYTHONPATH=$DEV $PY -m controls.backbone_compare --out runs/haiku45_compare.json   # 2×2 配对统计
```

| 文件 | 内容 |
|---|---|
| `configs/nemori_haiku45.json` | 与 `nemori_opus45.json` 相同，只把 `llm_model` 换成 Haiku 4.5（agent_id 和 collection 不变，即同一个记忆库） |
| `runs/run_haiku45.sh` | 设置 `VMEM_LLM_MODEL=…haiku-4-5…`，并显式指定 `--judge-model` 为 Opus 4.5 |
| `runs/haiku45_nemori_{dev,holdout}/` | NEMORI-Haiku 的 `results.json`、`metrics.json`、`search.log`、`eval.log` |
| `runs/haiku45_vmem2_{dev,holdout}/` | VMem-Haiku 的 `results.json`（含完整 trace）、`metrics.json`、`usage.json`、`config.json` |
| `runs/haiku45_compare.json` | 由 `controls/backbone_compare.py` 生成：dev/holdout/全集 × 5 组配对的分类别统计 |

为本实验做的代码改动（都不影响已有结果）：
- `common/bedrock_llm.py`：计价单价可以通过环境变量 `VMEM_PRICE_IN/OUT` 覆盖，默认值仍是 Opus 的 $5/$25。
- 新增 `controls/backbone_compare.py`。

注意：`common.evaluate` 在不传 `--judge-model` 时，默认使用 `VMEM_LLM_MODEL`。所以凡是换 backbone 的实验，都必须显式指定 judge，`run_haiku45.sh` 已经这样做了。
