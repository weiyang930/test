# Exp4 / RQ4：源头锚定与证据可靠性（Source Grounding and Evidential Reliability）

日期：2026-10-12　对象：VMem-v2.3-clean 在 LoCoMo 全部 1540 题上已保存的 ViewCards（Haiku 4.5 与 Opus 4.5 两组 trace）　代码与数据：`develop/exp4/`

> **研究问题**：VMem 构建的证据是否可溯源、可核验、语义上被来源支持？
> 本实验没有重跑记忆构建、检索或作答。A、C 两部分是**确定性核验**（不调用 LLM）；B 部分是**小规模 LLM 判定**（288 张抽样卡片），两者分开报告。
> 本实验不讨论 ViewCard 能否提升准确率，那由 RQ3 回答，结论是"没有可检出的准确率收益"。本实验也不与基线比较：其他基线没有同等的逐条溯源表示。

## 0. 结论速览

| Metric | Haiku 4.5 | Opus 4.5 | 依据 |
|---|---|---|---|
| Provenance resolution (all cited IDs resolve) | 98.4% (n=10121) | 100.0% (n=10213) | deterministic, all cards |
| Exact quotation fidelity | 82.7% | 95.9% | deterministic, all cards |
| Normalized quotation fidelity | 85.5% | 97.7% | deterministic, all cards |
| Fully supported claims | 59.6% [49.5, 70.2] (n=144) | 67.0% [57.3, 76.5] (n=144) | LLM judge, stratified sample, population-weighted, bootstrap 95% CI |
| Unsupported / contradicted claims | 1.1% [0.1, 2.6] (n=144) | 1.3% [0.0, 3.7] (n=144) | LLM judge, as above |
| Temporal grounding validity | 93.9% [93.3, 94.5] (n=5746) | 96.1% [95.6, 96.5] (n=6060) | deterministic, mechanically checkable time fields, Wilson 95% CI |
|   of which LLM-written time fields | 93.3% [92.6, 94.0] (n=5205) | 95.7% [95.1, 96.2] (n=5525) | excludes times rewritten by the pipeline's deterministic normaliser |

1. **溯源几乎总能解析到真实记录。**
   - Opus 的 10,213 张卡片中，引用 ID 全部能解析到记忆库记录的占 100.0%；Haiku 的 10,121 张中占 98.4%。
   - Haiku 不能解析的 1.6%，主要是把"上一轮的卡片"写进了 sources 字段（136 张），例如 `"evidence from previous round"`。
   - 引用原始 turn 的卡片，100% 能精确映射回 LoCoMo 原始对话的 dia_id。
2. **引文忠实度高，Opus 尤其高。**
   - 精确子串匹配：Opus 95.9%，Haiku 82.7%。
   - 规范化匹配（大小写、标点、空白归一）：Opus 97.7%，Haiku 85.5%。
   - 再把"…"拼接的多段引文按段核对：Opus 99.1%，Haiku 90.0%。
   - 剩余的真正不符（改写、或引文出自别处）：Opus 0.2%，Haiku 3.0%。
3. **引文对得上，不等于主张被来源支持。** 抽样 LLM 审计（288 张卡片，按总体加权）的结果是：
   - 完全支持：Haiku 59.6%，Opus 67.0%；
   - 完全或部分支持：Haiku 97.2%，Opus 98.6%（未加权）；
   - 不支持或与来源矛盾：只有约 1%。

   "部分支持"主要来自日期细节：卡片把会话日期当成事件日期，而来源并没有明确说事件发生在那一天（见 §3.3）。
4. **时间锚点基本可靠，但相对时间的换算是薄弱点。**
   - 在可机械核验的 time 字段中，与确定性规则一致的比例为 Opus 96.1%、Haiku 93.9%。只看由 LLM 自己写出的 time（排除被管线确定性归一化器改写的），为 95.7% 和 93.3%。
   - 由 LLM 换算的"yesterday / last night"只有 81% / 62% 正确，"last year"只有 75% / 61%。
   - "last week / weekend / weekday / month"这类表达由管线的确定性归一化器处理，一致率 100%。
5. **追溯到摘要层的引用有局限。**
   - 引用 episode 的卡片约占 15–20%，它们的引文几乎都来自**抽象摘要文本**：只有 5 / 1498（Opus）和 5 / 1677（Haiku）在该 episode 的原始 turn 中逐字出现。
   - 这类卡片可以追溯到 episode 记录，但不能逐字追溯到原话。

## 1. 数据与方法

- **审计范围**：Full VMem（v2.3-clean）全部 trace 中的全部卡片。
  - Opus 4.5：`runs/vmem2_v3clean_{dev,holdout}`，10,213 张，每题 6.64 张。
  - Haiku 4.5：`runs/haiku45_vmem2_{dev,holdout}`，10,121 张，每题 6.61 张。
  - 两组共用同一个由 Opus 构建的记忆库。
- **来源解析**：卡片标签 `E<k>` / `S<k>` / `T<k>` 解析为 `trace.pool_ids[kind][k-1]`，即管线分配标签的方式。再按 id 取记忆库条目；记忆库从 `vmem_backup` 恢复，用 RQ3 的 `OrderedStore` 还原原始条目顺序，只读。
  - 原始 turn 进一步用 RQ2 的精确映射（`exp2/evidence_lib.py`）对到 LoCoMo dia_id。
  - episode 来源同时取出其摘要文本（检索池中展示给 LLM 的内容），以及其全部原始 source turn。
- **引文核对**（确定性）：
  - 精确匹配：去掉首尾空白后的引文是某个被引来源文本的子串。
  - 规范化匹配：使用管线自带的 `_norm`（小写、去标点、合并空白）后再判断子串。
  - 分段匹配：按 "..." / "…" 切段，每段（至少 3 个词）都在某个被引来源中出现。
  - 另外报告管线自身的 `verified` 标记（模糊匹配分 ≥0.8），但它与上面的严格指标分开。
- **LLM 主张–来源一致性判定**：
  - 分层抽样，种子 20261012：backbone × 问题类别 × 溯源类型，每格 12 张，共 288 张。溯源类型分三种：单一原始 turn、多来源且含原始 turn、仅摘要或事实。
  - 判定模型为 Opus 4.5，temperature 0，结果缓存在 `exp4/data/claim_judge_cache.jsonl`。
  - judge **只看到**卡片的 claim 和 time 字段、以及被引来源的文本和日期；看不到问题、gold 答案、引文匹配结果或正确性标签。
  - 五个标签：完全支持、部分支持、不支持、矛盾、无法核验。
  - 加权率按各层的总体卡片数加权，95% CI 用分层 bootstrap；未加权率用 Wilson CI。来源完全无法解析的卡片不进入抽样，它们已在 A 部分算作确定性的锚定失败。
- **时间核验**（确定性）：对带 time 字段的卡片，以被引原始 turn 的会话时间戳为锚点（优先选包含该引文的 turn），按引文中的相对时间表达套用确定性规则：
  - 无相对表达：time 应为会话日期；
  - yesterday / last night：会话日期 − 1 天；
  - N days ago：会话日期 − N 天；
  - last year：会话年份 − 1；
  - last week / weekend / <weekday> / month：time 应为 "the … before <会话日期>"。

  以下情况计为"需语义解读"，不计入一致率：只有摘要或事实锚点、引文含明确日期、或相对表达无法机械换算（如 recently、a few weeks ago）。

## 2. A：溯源解析与引文忠实度（确定性，全部卡片）

| Backbone | 分组 | 卡片 | 卡片/题 | 来源全部可解析 | 存在无效引用 | 引用为空 | 引文精确匹配 | 引文规范化匹配 | 规范化+省略号分段 | 管线自带核验（≥0.8 模糊） | 原始 turn 引用可追溯到 LoCoMo dia_id |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | Overall | 10121 | 6.61 | 98.4% | 1.4% | 0.2% | 82.7% | 85.5% | 90.0% | 90.6% | 100.0% (7165) |
| Haiku 4.5 | Multi-hop | 3019 | 10.74 | 98.4% | 1.6% | 0.0% | 81.2% | 83.9% | 87.8% | 89.5% | 100.0% (2044) |
| Haiku 4.5 | Temporal | 1376 | 4.35 | 97.5% | 2.3% | 0.1% | 84.0% | 86.0% | 89.7% | 90.7% | 100.0% (916) |
| Haiku 4.5 | Open-domain | 1252 | 13.32 | 96.6% | 2.0% | 1.4% | 75.6% | 78.0% | 83.5% | 85.7% | 100.0% (721) |
| Haiku 4.5 | Single-hop | 4474 | 5.32 | 99.1% | 0.8% | 0.1% | 85.2% | 88.5% | 93.5% | 92.7% | 100.0% (3484) |
| Opus 4.5 | Overall | 10213 | 6.64 | 100.0% | 0.0% | 0.0% | 95.9% | 97.7% | 99.1% | 99.2% | 100.0% (7152) |
| Opus 4.5 | Multi-hop | 2715 | 9.63 | 100.0% | 0.0% | 0.0% | 94.5% | 96.8% | 98.3% | 98.5% | 100.0% (2113) |
| Opus 4.5 | Temporal | 1530 | 4.77 | 100.0% | 0.0% | 0.0% | 97.2% | 98.4% | 99.5% | 99.7% | 100.0% (896) |
| Opus 4.5 | Open-domain | 1153 | 12.14 | 100.0% | 0.0% | 0.0% | 95.2% | 96.9% | 99.3% | 99.0% | 100.0% (759) |
| Opus 4.5 | Single-hop | 4815 | 5.73 | 100.0% | 0.0% | 0.0% | 96.4% | 98.3% | 99.3% | 99.6% | 100.0% (3384) |

来源类型分布：

| Backbone | 来源类型 | 卡片 | 占比 | 引文精确匹配 | 引文规范化匹配 | 多来源卡片 |
|---|---|---|---|---|---|---|
| Haiku 4.5 | turn | 6193 | 61.2% | 86.8% | 90.2% | 7.4% |
| Haiku 4.5 | episode | 2017 | 19.9% | 81.1% | 83.1% | 1.4% |
| Haiku 4.5 | semantic | 1237 | 12.2% | 77.4% | 79.4% | 7.5% |
| Haiku 4.5 | mixed | 508 | 5.0% | 78.5% | 80.5% | 100.0% |
| Haiku 4.5 | none | 166 | 1.6% | 0.0% | 0.0% | 0.0% |
| Opus 4.5 | turn | 6063 | 59.4% | 95.2% | 98.0% | 6.4% |
| Opus 4.5 | episode | 1570 | 15.4% | 95.0% | 95.4% | 0.1% |
| Opus 4.5 | semantic | 1832 | 17.9% | 99.1% | 99.1% | 5.6% |
| Opus 4.5 | mixed | 748 | 7.3% | 95.7% | 97.3% | 100.0% |

锚定失败分类：

| Backbone | 卡片 | 无可解析来源 | 其中：引用了上一轮卡片等非 ID 文本 | 其中：无来源 | 引文为空（有来源） | 引文与来源不符（有来源、非空） | 其中：省略号拼接（各段均匹配） | 其中：近似匹配（管线模糊分 ≥0.8） | 其中：其余（改写/错源） | episode 引用：引文出自摘要而非原始 turn |
|---|---|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 10121 | 166 (1.6%) | 136 | 24 | 230 | 1072 (10.6%) | 460 | 306 | 306 (3.0%) | 1672/1677 仅出现在摘要中 |
| Opus 4.5 | 10213 | 0 (0.0%) | 0 | 0 | 14 | 216 (2.1%) | 135 | 60 | 21 (0.2%) | 1493/1498 仅出现在摘要中 |

**说明：**
- **"引文与来源不符"中多数并不是捏造。** 其中相当一部分是用 "…" 把两条被引 turn 拼在一起的引文：Haiku 460 张、Opus 135 张，逐段都能对上。另一部分是轻微改动（如把 "myself" 改成 "herself"），管线模糊分 ≥0.8：Haiku 306 张、Opus 60 张。
- 真正对不上的（改写或错源）：Haiku 306 张（3.0%），Opus 21 张（0.2%）。
- **引文匹配只证明"这段话确实出现在被引来源里"，不证明主张成立。** 主张是否成立见 §3。

代表性失败例（引文与被引来源不符，随机抽取）：

- **haiku · conv-47** 引文：“We put together a tournament for our favorite game, CS:GO. Lots showed up and we made a bunch of money for charity! Our main goal was to raise money for a dog s” → 被引 T1, T22：“John: Nope, not a new game. We put together a tournament for our favorite game, CS:GO. Lots showed up and we made a bunch of money for charity!”（管线模糊分 0.536）
- **haiku · conv-47** 引文：“We put together a tournament for our favorite game, CS:GO. Lots showed up and we made a bunch of money for charity! Our main goal was to raise money for a dog s” → 被引 T2, T9：“John: Nope, not a new game. We put together a tournament for our favorite game, CS:GO. Lots showed up and we made a bunch of money for charity!”（管线模糊分 0.536）
- **haiku · conv-26** 引文：“I painted it because it was calming.” → 被引 T24：“Melanie: I wanted a peaceful blue streaks to show tranquility. Blue calms me, so I wanted the painting to have a serene vibe while still having lots of vibrant ”（管线模糊分 0.286）
- **opus · conv-44** 引文：“Maybe you want to take care of Toby and Buddy first.” → 被引 E7, T70：“Andrew Adopts New Dog Buddy from Shelter and Shares Hiking Adventures: On October 19, 2023 at 6:12 PM, Andrew shared exciting news with Audrey about recently ad”（管线模糊分 0.745）
- **opus · conv-43** 引文：“I attempted to write a story based on his experiences in the UK. The story didn't turn out as he had hoped” → 被引 T43：“Tim: Hey John, it's been a few days! I got a no for a summer job I wanted which wasn't great but I'm staying positive. On your NYC trip, did you have any troubl”（管线模糊分 0.352）
- **opus · conv-42** 引文：“Glad to hear you enjoyed it! It's probably the greatest trilogy of all time!” → 被引 S16, T22：“Nate's favorite movie trilogy is The Lord of the Rings”（管线模糊分 0.514）
- **haiku · 无效引用** sources = ['evidence from previous round']；claim：On May 25, 2023, Melanie told Caroline that her family is thinking about going camping next month (June 2023).
- **haiku · 无效引用** sources = ['evidence from previous round']；claim：Melanie took her family camping in the mountains around June 20, 2023.

## 3. B：主张–来源一致性（LLM 判定，分层抽样 288 张）

### 3.1 总体

| Backbone | 抽样卡片 | 完全支持 | 完全+部分支持 | 部分支持 | 不支持 | 矛盾 | 无法核验 | 完全支持（按总体加权） | 不支持+矛盾（按总体加权） |
|---|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 144 | 57.6% [49.5, 65.4] | 97.2% [93.1, 98.9] | 39.6% | 0.7% [0.1, 3.8] | 2.1% [0.7, 5.9] | 0.0% | 59.6% [49.5, 70.2] | 1.1% [0.1, 2.6] |
| Opus 4.5 | 144 | 66.0% [57.9, 73.2] | 98.6% [95.1, 99.6] | 32.6% | 0.7% [0.1, 3.8] | 0.7% [0.1, 3.8] | 0.0% | 67.0% [57.3, 76.5] | 1.3% [0.0, 3.7] |
| 合计 | 288 | 61.8% [56.1, 67.2] | 97.9% [95.5, 99.0] | 36.1% | 0.7% [0.2, 2.5] | 1.4% [0.5, 3.5] | 0.0% | — | — |

### 3.2 按溯源类型 / 问题类别

| 分组 | 抽样卡片 | 完全支持 | 完全+部分 | 不支持 | 矛盾 |
|---|---|---|---|---|---|
| 来源类型: turn_single · Haiku 4.5 | 48 | 56.2% [42.3, 69.3] | 97.9% | 0.0% | 2.1% |
| 来源类型: turn_single · Opus 4.5 | 48 | 52.1% [38.3, 65.5] | 97.9% | 0.0% | 2.1% |
| 来源类型: turn_multi · Haiku 4.5 | 48 | 41.7% [28.8, 55.7] | 93.8% | 2.1% | 4.2% |
| 来源类型: turn_multi · Opus 4.5 | 48 | 62.5% [48.4, 74.8] | 97.9% | 2.1% | 0.0% |
| 来源类型: summary · Haiku 4.5 | 48 | 75.0% [61.2, 85.1] | 100.0% | 0.0% | 0.0% |
| 来源类型: summary · Opus 4.5 | 48 | 83.3% [70.4, 91.3] | 100.0% | 0.0% | 0.0% |
| 问题类别: Multi-hop · Haiku 4.5 | 36 | 52.8% [37.0, 68.0] | 94.4% | 0.0% | 5.6% |
| 问题类别: Multi-hop · Opus 4.5 | 36 | 58.3% [42.2, 72.9] | 97.2% | 0.0% | 2.8% |
| 问题类别: Temporal · Haiku 4.5 | 36 | 61.1% [44.9, 75.2] | 97.2% | 0.0% | 2.8% |
| 问题类别: Temporal · Opus 4.5 | 36 | 58.3% [42.2, 72.9] | 97.2% | 2.8% | 0.0% |
| 问题类别: Open-domain · Haiku 4.5 | 36 | 58.3% [42.2, 72.9] | 97.2% | 2.8% | 0.0% |
| 问题类别: Open-domain · Opus 4.5 | 36 | 75.0% [58.9, 86.2] | 100.0% | 0.0% | 0.0% |
| 问题类别: Single-hop · Haiku 4.5 | 36 | 58.3% [42.2, 72.9] | 100.0% | 0.0% | 0.0% |
| 问题类别: Single-hop · Opus 4.5 | 36 | 72.2% [56.0, 84.2] | 100.0% | 0.0% | 0.0% |

引文匹配与语义支持的关系（两个 backbone 合并）：

| 引文规范化匹配 | 抽样卡片 | 完全支持 | 完全+部分 | 不支持+矛盾 |
|---|---|---|---|---|
| 是 | 250 | 63.2% | 98.4% | 1.6% |
| 否 | 38 | 52.6% | 94.7% | 5.3% |

### 3.3 不完全支持的原因

| 判定 | 原因类型（依 judge 理由关键词粗分） | 卡片 |
|---|---|---|
| CONTRADICTED | date/time | 1 |
| CONTRADICTED | other detail | 3 |
| PARTIALLY_SUPPORTED | date/time | 57 |
| PARTIALLY_SUPPORTED | inference/interpretation | 6 |
| PARTIALLY_SUPPORTED | name/entity/attribution | 9 |
| PARTIALLY_SUPPORTED | other detail | 32 |
| UNSUPPORTED | name/entity/attribution | 1 |
| UNSUPPORTED | other detail | 1 |

- "部分支持"中最大的一类与日期有关。典型情况是：卡片的 time 写成来源会话的日期，但来源只说明这件事在该会话中被提到，并没有说明事件就发生在那一天。
- 还有一类是多来源卡片把不同日期的事实合进同一个 time。
- 其余是细节越界，例如把"正在实习"写成"完成了实习"，把单次行为写成"习惯"。
- "不支持"和"矛盾"很少（288 张中共 6 张），类型包括：
  - 说话人归属错误（把 Evan 的建议记到 Sam 头上）；
  - 否定或语气错误（"missed it" 被写成 "attended"，"currently reading" 被写成 "has read"）；
  - 卡片引入了来源中没有的地点。

代表性例子：

- **FULLY_SUPPORTED**（haiku · Temporal）claim：Melanie took her family to a pottery workshop on (the Friday before 15 July 2023).（time: the Friday before 15 July 2023）
  - 来源：[T25] Melanie: Hey Caroline, it's been super busy here. So much since we talked! Last Fri I finally took my kids to a pottery workshop. We all made our own 
  - judge：The source [T25] is dated Saturday, 15 July 2023, and Melanie states 'Last Fri I finally took my kids to a pottery workshop,' which resolves to the Friday before 15 July 2023, and 'my kids' supports 'her family.'
- **FULLY_SUPPORTED**（opus · Open-domain）claim：Evan encouraged Sam to believe in themselves, take things one day at a time, and try something new even if small.（time: Sunday, 17 December 2023）
  - 来源：[T15] Evan: Yeah, I understand it can be challenging. But remember, it's important to believe in yourself and take it one day at a time, Sam. Your worth is ；[E10] Sam's Weight Struggles and Evan's Encouragement to Try New Things Including Hiking: On December 17, 2023 at 6:48 PM, Sam shared their struggles with w
  - judge：The episode summary [E10] explicitly states that Evan encouraged Sam to 'believe in themselves and take things one day at a time' and 'challenged Sam to try something new, even if it's just a small thing,' and the conversation turn [T15] confirms the 'believe in yourself and take it one day at a time' encouragement, all occurring on Sunday, 17 December 2023.
- **PARTIALLY_SUPPORTED**（opus · Single-hop）claim：Jon tells Gina he won't let anything get him down（time: 27 May 2023）
  - 来源：[T67] Jon: Thanks! Your words really mean a lot. Don't worry, I won't let anything get me down.
  - judge：The source confirms Jon said 'I won't let anything get me down' on 27 May 2023, but it does not establish that he was speaking to Gina specifically—the source only shows Jon's statement without identifying the recipient.
- **PARTIALLY_SUPPORTED**（opus · Single-hop）claim：Nate won his second video game tournament around (the week before 2 May 2022), playing Street Fighter at a local competition（time: the week before 2 May 2022）
  - 来源：[T10] Nate: Gaming has been my focus - practicing a lot and even winning a few tournaments. Last week I won my second tournament! [Image: a photo of a woman；[T40] Nate: Thanks! I usually play CS:GO, but I tried my hand at the local Street Fighter tournament this time since I play that game a lot with my friends,
  - judge：The sources support that Nate won his second tournament 'last week' (which resolves to the week before 2 May 2022) and that he played Street Fighter at a local tournament, but T40 describes the Street Fighter tournament as something he 'tried his hand at' separately, not explicitly confirming it was the same tournament where he won his second victory.
- **UNSUPPORTED**（haiku · Open-domain）claim：Joanna visited Fort Wayne, Indiana during summer 2022（time: Thursday, 12 May 2022）
  - 来源：[T99] Joanna: Yeah, I did! Loved this spot on the hike. The rush of the water was so soothing. [Image: a photo of a waterfall with a dark sky in the backgro；[T100] Nate: Wow, looks great! Where did you take this picture? I love the dark sky and green scenery.
  - judge：The cited sources discuss Joanna taking a photo at a location called Whispering Falls, but there is no mention of Fort Wayne, Indiana, and May 2022 is not summer (it is spring).
- **UNSUPPORTED**（opus · Temporal）claim：Nate's second tournament was a local Street Fighter tournament.（time: the week before Monday, 02 May 2022）
  - 来源：[T54] Nate: Thanks! I usually play CS:GO, but I tried my hand at the local Street Fighter tournament this time since I play that game a lot with my friends,；[S1] Nate won a Street Fighter tournament at a local competition
  - judge：The cited sources establish that Nate participated in a local Street Fighter tournament, but there is no information indicating this was his 'second tournament' - the sources do not mention any previous tournament or establish an ordering of tournaments.
- **CONTRADICTED**（haiku · Multi-hop）claim：Tim has read The Name of the Wind by Patrick Rothfuss（time: 07 January 2024）
  - 来源：[T77] Tim: Yeah! I think you'd love this fantasy novel by Patrick Rothfuss. It's a book that'll take you to a different world. Great for you when you're tra；[T11] Tim: I'm currently reading a fantasy novel called \"The Name of the Wind\" by Patrick Rothfuss. It's really good!
  - judge：The cited source [T11] from 07 January 2024 states Tim is 'currently reading' the book, meaning he has not finished it yet, which contradicts the claim that he 'has read' (completed reading) the book by that date.
- **CONTRADICTED**（haiku · Multi-hop）claim：In the August 13, 2023 conversation, Maria clarified she did not have another dog besides Shadow when John asked if Shadow got along with her other dog.（time: August 13, 2023）
  - 来源：[T2] John: Wow, Maria, how cute! What's her name? Do she and your other dog get along?；[T3] Maria: Her name is Shadow! She's full of energy and always puts a smile on my face. She's been a great addition to my life. They get along great. [Ima
  - judge：The claim states Maria clarified she did NOT have another dog besides Shadow, but in T3 Maria actually confirms they get along great ('They get along great'), indicating she does have another dog.
- **CONTRADICTED**（haiku · Temporal）claim：Caroline attended a pride parade the previous weekend around July 15-16, 2023 that she missed.（time: the weekend before 20 July 2023）
  - 来源：[T13] Caroline: Last weekend our city held a pride parade! So many people marched through the streets waving flags, holding signs and celebrating love and d
  - judge：The source explicitly states Caroline 'missed it' (the pride parade), meaning she did not attend, which directly contradicts the claim that she 'attended' the parade.

## 4. C：时间锚定（确定性）

| Backbone | 卡片 | 带 time 字段 | 锚点：引用了原始 turn（会话时间戳可解析） | 锚点：仅摘要/事实 | 无可解析锚点 | 可机械核验 | 机械核验一致 | 需语义解读 | 不可核验（非日历日 / 引文不在锚点 turn） |
|---|---|---|---|---|---|---|---|---|---|
| Haiku 4.5 | 10121 | 9541 | 6458 | 3017 | 66 | 5746 | 5398 (93.9% [93.3, 94.5]) | 3522 | 207 |
| Opus 4.5 | 10213 | 9598 | 6664 | 2934 | 0 | 6060 | 5822 (96.1% [95.6, 96.5]) | 3416 | 122 |

| Backbone | 机械核验：由 LLM 写出的 time | 一致 | 机械核验：被管线确定性归一化器改写的 time | 一致 |
|---|---|---|---|---|
| Haiku 4.5 | 5205 | 4857 (93.3% [92.6, 94.0]) | 541 | 541 (100.0%) |
| Opus 4.5 | 5525 | 5287 (95.7% [95.1, 96.2]) | 535 | 535 (100.0%) |

各规则的一致率：

| 规则 | 期望 time | Haiku 一致 / 适用 | Opus 一致 / 适用 |
|---|---|---|---|
| no relative expression -> session date | 会话日期 | 4661/4905 (95.0%) | 5018/5198 (96.5%) |
| yesterday | 会话日期 − 1 天（含 last night） | 121/194 (62.4%) | 176/218 (80.7%) |
| today | 会话日期 | 22/22 (100.0%) | 27/27 (100.0%) |
| n_days_ago | 会话日期 − N 天 | 14/20 (70.0%) | 17/17 (100.0%) |
| last_year | 会话年份 − 1 | 39/64 (60.9%) | 49/65 (75.4%) |
| last_week | the week before <会话日期> | 255/255 (100.0%) | 265/265 (100.0%) |
| last_weekday | the <weekday> before <会话日期> | 161/161 (100.0%) | 146/146 (100.0%) |
| last_weekend | the weekend before <会话日期> | 78/78 (100.0%) | 72/72 (100.0%) |
| last_month | the month before <会话日期> | 47/47 (100.0%) | 52/52 (100.0%) |

**说明：**
- 带 time 字段的卡片中，约 68–69% 引用了原始 turn，因此有可解析的会话时间锚点；其余约 31% 只引用摘要或事实，日期无法机械核验。
- 一致率 100% 的"the … before <日期>"类，由管线的确定性归一化器生成（v2.3 的 `norm_time`），这里只是证明归一化器按设计工作，不能算作 LLM 的时间推理能力。
- 由 LLM 自己换算的相对时间是主要失误来源，Haiku 更明显：
  - "yesterday / last night"：Haiku 62%，Opus 81%；
  - "last year"：Haiku 61%，Opus 75%。
- 上表的"不一致"是相对确定性规则而言。其中有一部分可能由上下文说得通，例如事件其实发生在另一条邻近 turn 所指的日子。所以这里报告的是"与规则不一致"，不是"一定错误"。

代表性不一致例子：

- **haiku** 规则 yesterday：会话日期 2023-07-03，卡片 time = “3 July 2023”，期望 “2023-07-02”；引文：“I just signed up for a pottery class yesterday”
- **haiku** 规则 yesterday：会话日期 2023-07-03，卡片 time = “Monday, 03 July 2023”，期望 “2023-07-02”；引文：“I just signed up for a pottery class yesterday.”
- **haiku** 规则 no relative expression -> session date：会话日期 2023-10-13，卡片 time = “October 6, 2023”；引文：“The room was electric with energy and support! The posters were amazing, so much pride and strength! It inspired me to m”
- **haiku** 规则 yesterday：会话日期 2022-10-21，卡片 time = “21 October 2022”，期望 “2022-10-20”；引文：“yesterday I tried Cyberpunk 2077. Great game, so addictive!”
- **opus** 规则 no relative expression -> session date：会话日期 2023-02-09，卡片 time = “Wednesday, 01 February 2023”；引文：“Yep! I achieved so much more than I imagined. It was a real confidence boost.”
- **opus** 规则 no relative expression -> session date：会话日期 2023-09-11，卡片 time = “September 16, 2023 (planned for next Saturday from September 11, 2023)”；引文：“Yeah, Sam - let's do it! Let's get everything ready and paint next Saturday. Can't wait!”
- **opus** 规则 yesterday：会话日期 2023-06-06，卡片 time = “the day before 6 June 2023”，期望 “2023-06-05”；引文：“Here's an example of how I spent yesterday morning, yoga on top of mount Talkeetna”
- **opus** 规则 no relative expression -> session date：会话日期 2023-08-15，卡片 time = “14 August 2023”；引文：“I marinated it with a few different ingredients and grilled it with some veggies. It turned out really flavorful!”

## 5. 局限

- **LLM 判定**：只有 288 张卡片，且只有一个 judge（Opus 4.5，与 Opus 作答模型同源），没有人工复核；"部分支持"与"完全支持"的边界本身有主观性。按总体加权的 CI 宽约 ±10 pp。
- **episode 引用**：卡片引文出自抽象摘要。这里核对的是"引文确实在摘要中"，摘要本身是否忠实于原话不在本实验范围内（NEMORI 构建记忆时的问题）。
- **时间规则**：只覆盖常见的相对表达，用正则识别，可能漏检或误判；"需语义解读"的 3,400–3,500 张卡片没有做时间正确性判断。
- **记忆库恢复**：Audrey_5 有少数同文本语义记忆的 id 次序无法唯一恢复（见 RQ3 §1.3），但它们的文本相同，不影响引文核对。
- **Haiku 的 trace**：Haiku 的卡片来自它自己那次 Full 运行；两个 backbone 的卡片总数、每题卡片数相近，但各自对应不同的检索池。

## 6. 可写进论文的发现

1. VMem 的证据是**可机械核验的**：每张卡片都带结构化的来源 id 和逐字引文。Opus 下 100% 可解析、97.7% 引文规范化匹配、99.1% 分段匹配，引用原始 turn 的卡片 100% 可追溯到原始对话行。这是检索更多上下文本身给不出的属性。
2. **确定性核验和语义支持要分开看。** 在高引文忠实度的基础上，被引来源完全蕴含主张的约占 60–67%，完全或部分支持的约 97–99%，不支持或矛盾的约 1%。主要缺口是日期细节，而不是捏造事实。
3. **时间锚定**：带 time 的卡片约 2/3 有可解析的会话锚点，其中 94–96% 与确定性规则一致。LLM 自己换算 "yesterday" 和 "last year" 的错误率明显更高（Haiku 尤甚），这说明把更多相对时间换算交给确定性归一化器是有价值的改进方向。

## 7. 复现与成本

```bash
cd /path/to/VMem/develop && source env.sh
docker run -d --name rq4_pg -e POSTGRES_USER=nemori -e POSTGRES_PASSWORD=nemori -e POSTGRES_DB=nemori \
  -p 127.0.0.1:15432:5432 -v /path/to/vmem_backup:/backup:ro postgres:16-alpine
docker exec rq4_pg pg_restore -U nemori -d nemori --no-owner /backup/nemori_opus45_pg.dump
$PY exp4/audit_offline.py      # A + C：全部卡片的确定性审计 -> exp4/data/cards_{haiku,opus}.jsonl
$PY exp4/claim_audit.py        # B：分层抽样 + LLM 判定（有缓存，重跑不产生新调用）-> exp4/data/claim_sample.jsonl
$PY exp4/analyze.py && $PY exp4/build_report.py
```

- **新增 API 花费**：只有 B 部分。Opus 4.5 judge，共 288 次调用（0 次来自最近一次运行，其余为缓存命中）；首次运行共 288 次调用，169,292 输入 / 22,719 输出 token，约 $1.41。A、C 两部分没有任何 LLM 调用。
- **输出**：
  - `exp4/data/`：cards_*.jsonl（逐卡审计结果，含已解析的来源文本）、claim_sample.jsonl、claim_judge_cache.jsonl、claim_judge_usage.json；
  - `exp4/tables/`：paper_table.csv、claim_judgments.csv、report_tables.md、examples.json。
- **规范**：没有改动 `vmem2/`、`runs/` 或 `exp2/` 下的任何文件。临时数据库容器用完已删除。
