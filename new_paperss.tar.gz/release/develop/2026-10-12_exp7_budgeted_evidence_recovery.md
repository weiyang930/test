# Exp7 / RQ7：有限检索预算下的证据恢复（Budgeted Evidence Recovery）

日期：2026-10-12　范围：LoCoMo 1540 题，主分母为 gold evidence 全部可精确映射的 1531 题　代码与数据：`develop/exp7/`

> **研究问题**：在有限的检索预算下，查询引导的证据发现能否更高效地恢复完整的支持证据？
> **性质**：纯离线分析。没有新的 LLM 推理、检索、embedding 或 judge 调用，也没有连接任何服务（gateway、embedding、Postgres、Qdrant 都没有启动）。只读取 `runs/`、`exp2/`、`exp3/` 中已保存的检索列表和记忆库快照。gold evidence 只用于事后打分。
> **重要声明**：本文的每个数字都是"**已保存检索列表的前缀**在离线条件下的证据覆盖"。把已存的列表截短，**不等于**真的用更小的预算重新运行系统：真实系统在小预算下的排序、扩展触发和卡片都可能不同。本文也不涉及任何准确率结论。

## 0. 结论速览

下文数字格式为 Haiku 4.5 / Opus 4.5。NEMORI 的检索与 backbone 无关，两边相同。

1. **相同的原文 turn 预算下，VMem 的首轮多粒度检索池恢复完整证据的效率明显更高。** 按"逐字可见的 source turn 数"计预算时：
   - 10–120 turn 区间的归一化 AUC（complete coverage 的平均值）：VMem 首轮池 **73.1 / 74.1%**；RQ3 匹配预算纯检索对照 58.6 / 58.5%；NEMORI 离线展开（假设）44.4%；NEMORI 实际可见只有 14.5%。
   - 相对匹配对照的配对差：AUC **+14.5 pp**（题级 95% CI [+12.5, +16.5]，对话聚类 CI [+11.0, +18.9]）/ **+15.7 pp**（[+13.6, +17.7]，聚类 [+12.2, +20.1]）。留一对话后的 10 个估计全部为正。
   - 每个预算点的优势都在：B = 20 时 +22.1 / +23.6 pp，B = 120 时 +8.8 / +9.9 pp。按 token 计预算时结论相同（AUC +16.1 / +17.1 pp）。
2. **相对 NEMORI 实际展示给作答模型的内容，差距最大。** NEMORI 只打印 top-2 episode 的原文，平均 22 条 turn，complete coverage 停在 16.2%。首轮池在 B = 20 时已达到 56.6 / 58.1%（配对差 +47.2 / +48.7 pp）。即使假设把 NEMORI 的 10 个 episode 全部展开成原文（**NEMORI 并没有这样做**），在相同 turn 预算下首轮池仍高 +29 / +30 pp（AUC）。
3. **在 10–120 turn 区间内，任何检索列表都达不到 90% complete。** 达到 80% 所需预算：首轮池约 78 / 73 条 turn；匹配对照、NEMORI 展开在区间内都达不到 80%，它们的完整列表也只有 77.0 / 75.0% 和 68.8%。只有 Full VMem 的最终 prompt 达到 91.6 / 91.7%，但这包含了由卡片选出的"引用原文区"，属于端点，不能当作预算曲线。
4. **扩展（refinement）的贡献小而确定，而且只出现在预算接近用尽时。** 预算不超过首轮池长度时，"R1 + 扩展"与首轮池完全相同。扩展的作用：
   - B = 120：+1.2 / +0.9 pp（CI 都不含 0）；完整列表端点：+2.9 / +1.2 pp。
   - 只看触发扩展的题（326 / 131 题，系统自选的难题）：+13.5 / +14.5 pp。
   - 卡片派生的"引用原文区"在端点处再加 +6.2 / +7.4 pp。这一项依赖 ViewCard，不属于检索预算。
5. **必须如实说明：小预算下的效率优势主要来自原始 turn 级的混合检索，而不是查询规划。** 在 RQ3 的 400 题子集上，RQ3 实际重跑过只用原问题、不做规划的变体（多粒度检索不变）。与它相比，有规划的检索列表：
   - B = 20：**−11.8 / −9.8 pp**；AUC：−3.4 / −1.9 pp。Single-hop 题上 B = 20 时 −18 / −16 pp。
   - 只有在预算较大时才反超：端点 +3.8 / +3.0 pp。收益集中在 Multi-hop（端点 +16.4 / +9.6 pp）和跨 session 题（端点 +14.9 / +10.3 pp）。

   所以，"查询引导"的规划部分在预算充足时提高了多源证据的完整性，但在预算很紧时不如直接用原问题检索。（§5.4）
6. **类别与证据条数：** 首轮池相对匹配对照的优势在 Multi-hop（AUC +15.3 / +18.1 pp）、Temporal、Single-hop，以及多 turn、跨 session 题上都显著。Open-domain（n = 92）上不显著（+4.2 / +7.9 pp，CI 含 0）。不过在多 turn、跨 session 题上，各方法的绝对 complete 都很低（120 turn 时首轮池约 50–55%）。
7. **是否单独作为 RQ：不建议。** 本实验在方法上更干净（预算对齐、保留原检索顺序），可以作为 RQ2/RQ3 的"预算对齐"补充图。但它与 RQ3 的匹配预算对照讲的是同一个结论，并且受规划消融的限制，不能把效率收益归给"查询规划"。建议并入 RQ3 §4.1（或 RQ2 §2.3 的上下文量混杂讨论），作为一张效率曲线和一张配对表。（§8）

![](exp7/figures/rq7_coverage_vs_turn_budget.png)

**图 1**：complete evidence coverage 随 source-turn 预算的变化（strict 前缀规则，1531 题）。(a) Haiku 4.5，(b) Opus 4.5。NEMORI 两条曲线在两个面板中相同。虚线加空心点 = NEMORI 检索到的 10 个 episode 的**假设性**离线原文展开，NEMORI 实际并没有展示这些原文。Full VMem（R1 + 扩展）的曲线在 B ≲ 80 时与首轮池重合，B = 120 时最多高 1.2 pp，为避免两条蓝线重叠没有画出（数值见 §3）。按 token 计预算的版本：`exp7/figures/rq7_coverage_vs_token_budget.png`。

---

## 1. Trace 可行性与重建审计

先逐一检查每个候选策略在磁盘上保存了什么，再决定哪些曲线可以重建。

| 策略 | 来源（只读） | 保存了什么 | 原始顺序是否可靠 | 结论 |
|---|---|---|---|---|
| NEMORI 实际可见 | `runs/nemori_full`、`runs/haiku45_nemori_{dev,holdout}` 的 `results.json` | 每题 10 个 episode（向量检索顺序，`search_method = vector`；score 字段为 None，但上游 `flatten_results` 保持返回顺序）+ 20 条 semantic；**只有 top-2 episode 带 `source_messages`**（与库中该 episode 的完整原文逐项相同，已断言） | 是（返回顺序即排名） | **可重建**。只有 top-2 episode 的原文是逐字可见的 |
| NEMORI 离线展开（假设） | 同上 + `exp2/data/store_snapshot.json` | 10 个 episode 的 id 与排名；其原文从记忆库快照取 | 是 | **可重建，但明确标为假设**：NEMORI 从未展示 3–10 名 episode 的原文 |
| 匹配预算纯检索（RQ3） | `exp3/runs/<bb>/matched_full/records.jsonl` | `pool_ids.episode`（原问题稠密排序的前 k 个）与 `pool_ids.turn`（按 episode 排名依次拼接每个 episode 的全部原文）。所有题都能无歧义地按 episode 切分（已断言） | 是。前 k′ < k 个 episode 正是同一排序的前缀 | **可重建**（实际可见，episode 原文确实在 prompt 中） |
| Query-guided 首轮池 | `exp3/runs/<bb>/no_reify_full/records.jsonl` | 首轮池（规划后的多粒度检索，未经 ViewCard）。turn 列表按 hit 的 RRF 融合排名排列，每个 hit 附 ±1 相邻 turn（`vmem2.pipeline.retrieve`） | 是。系统自身的 `max_pool_turns` 截断就是在这个顺序上做前缀；已断言它是 Full VMem 已存池的前缀 | **可重建**。未扩展的题与已存池逐项相同（精确）；扩展题的 round-1 边界沿用 RQ3（由近似 replay 定位） |
| Full VMem 检索（R1 + 扩展） | `runs/vmem2_v3clean_*`、`runs/haiku45_vmem2_*` 的 `trace.pool_ids.turn` | 首轮 turn 之后依次接扩展轮新增的 turn（扩展轮排除已有条目，`new_t[:40]`） | 是（按检索轮次拼接） | **可重建**。扩展轮只在首轮池用尽之后才出现；不用扩展结果去模拟更小预算 |
| Full VMem 最终 prompt | 同上 `trace.pool_ids.cited_turn` | 由卡片选出的引用原文区（被引 turn ±2、被引 episode 的前 12 条 turn） | 没有检索排名，由卡片决定 | **只报端点**，不画预算曲线 |
| VMem 的 episode / semantic 条目 | `pool_ids.episode / semantic` | 每种条目各自按排名排列，但 **episode、semantic、turn 三类之间没有统一排序** | 跨类无序 | 主定义下它们不暴露原文（见 §2）。溯源展开版**只报端点**，不画曲线：任何跨类交错顺序都是编造出来的 |
| w/o Query Planning（RQ3 子集） | `exp3/runs/<bb>/no_plan/records.jsonl` | RQ3 实际重跑的完整流水线（只用原问题检索），`pool_ids.turn` 为 R1 + 扩展 | 是。但那次重跑使用恢复后的库和 replay 的 query embedding（与原运行 Jaccard ≈ 0.97） | 只作为 400 题子集上的补充分析（§5.4） |
| `exp3/data/round1_<bb>.json` | `exp3/check_replay.py` | 基于 replay 的 round-1 尺寸 | 近似：与 `no_reify` 实际使用的池不一致（Opus 268 题的 turn 数不同） | **不使用** |

其他审计结果：

- 主分母：RQ2 协议下 gold evidence 全部可精确映射的题 **1531**（部分可映射 4，不可映射 5，合计 1540），与 RQ2 的 1531 完全一致。
- NEMORI：Haiku 与 Opus 两次运行的检索结果逐题完全相同（1531/1531 题 episode 列表与打印原文的 episode 一致），所以 NEMORI 的两条曲线在两个面板中相同。
- Query-guided round-1：Opus 131 题、Haiku 326 题触发了扩展；这些题的 round-1 turn 边界沿用 RQ3 `no_reify_full` 记录中的已存池前缀（边界由近似 replay 定位），其余题的 round-1 池就是已存池本身（逐项相同，已断言）。
- 平均每条 turn 35.6 个 cl100k token（全部 store turn 去重后的均值）。

每个策略保存的列表长度（主定义 = 逐字可见的 source turn）：

| Backbone | 策略 | 候选单元/题 | 暴露 source turn/题（均值） | 中位数 | 范围 | 暴露 token/题（cl100k） | 列表 ≥120 turn 的题 % |
|---|---|---:|---:|---:|---:|---:|---:|
| Haiku 4.5 | NEMORI (actual raw-turn exposure) | 2.0 | 22.1 | 20 | 2–67 | 751 | 0.0 |
| Haiku 4.5 | NEMORI top-10 episodes (offline expansion, hypothetical) | 10.0 | 79.5 | 73 | 17–178 | 2772 | 14.8 |
| Haiku 4.5 | Matched-budget retrieval-only (RQ3) | 14.9 | 122.2 | 111 | 48–312 | 4262 | 40.4 |
| Haiku 4.5 | Query-guided round-1 pool (before ViewCards) | 92.7 | 92.7 | 97 | 50–129 | 3077 | 3.4 |
| Haiku 4.5 | Full VMem retrieval (round 1 + refinement) | 104.5 | 104.5 | 105 | 50–206 | 3511 | 16.4 |
| Haiku 4.5 | Full VMem final prompt (+ card-cited source context) — endpoint only | — | 113.0 | 110 | 53–274 | 3843 | 32.1 |
| Opus 4.5 | NEMORI (actual raw-turn exposure) | 2.0 | 22.1 | 20 | 2–67 | 751 | 0.0 |
| Opus 4.5 | NEMORI top-10 episodes (offline expansion, hypothetical) | 10.0 | 79.5 | 73 | 17–178 | 2772 | 14.8 |
| Opus 4.5 | Matched-budget retrieval-only (RQ3) | 13.4 | 107.7 | 102 | 52–298 | 3752 | 27.7 |
| Opus 4.5 | Query-guided round-1 pool (before ViewCards) | 84.8 | 84.8 | 77 | 54–126 | 2834 | 2.2 |
| Opus 4.5 | Full VMem retrieval (round 1 + refinement) | 88.6 | 88.6 | 78 | 54–199 | 2966 | 5.7 |
| Opus 4.5 | Full VMem final prompt (+ card-cited source context) — endpoint only | — | 97.1 | 85 | 56–262 | 3294 | 19.1 |

**与先前报告的一致性检查**（端点必须精确复现 RQ2/RQ3）：

| Backbone | 检查 | 本实验 | 先前报告 | 一致 |
|---|---|---:|---:|---|
| Haiku 4.5 | NEMORI 实际暴露端点 = RQ2 V complete | 16.20 | 16.20 | ✓ |
| Haiku 4.5 | NEMORI 离线展开端点 = RQ2 R complete | 68.84 | 68.84 | ✓ |
| Haiku 4.5 | Full VMem 最终 prompt 端点 = RQ2 V complete | 91.64 | 91.64 | ✓ |
| Haiku 4.5 | Full VMem 最终 prompt 溯源展开端点 = RQ2 R complete | 93.53 | 93.53 | ✓ |
| Opus 4.5 | NEMORI 实际暴露端点 = RQ2 V complete | 16.20 | 16.20 | ✓ |
| Opus 4.5 | NEMORI 离线展开端点 = RQ2 R complete | 68.84 | 68.84 | ✓ |
| Opus 4.5 | Full VMem 最终 prompt 端点 = RQ2 V complete | 91.70 | 91.70 | ✓ |
| Opus 4.5 | Full VMem 最终 prompt 溯源展开端点 = RQ2 R complete | 92.82 | 92.82 | ✓ |
| Haiku 4.5 | Matched-budget retrieval-only (RQ3) 端点 = RQ3 V complete（matched） | 77.01 | 77.01 | ✓ |
| Haiku 4.5 | Query-guided round-1 pool (before ViewCards) 端点 = RQ3 V complete（no_reify） | 82.56 | 82.56 | ✓ |
| Opus 4.5 | Matched-budget retrieval-only (RQ3) 端点 = RQ3 V complete（matched） | 75.05 | 75.05 | ✓ |
| Opus 4.5 | Query-guided round-1 pool (before ViewCards) 端点 = RQ3 V complete（no_reify） | 83.08 | 83.08 | ✓ |

## 2. 定义

### 2.1 Source turn 与"暴露"

- **turn 身份**：记忆库中一条原始消息，按 VMem 的去重键（timestamp, role, content）识别。NEMORI 和 VMem 共用同一份库，所以两者的消息 id 在同一个空间里，按同一规则去重。
- **gold 映射**：完全沿用 RQ2 的 `exp2/evidence_lib.py`，即（role, json 解码后的 content）精确匹配，并纳入 VMem 去重别名。一个 gold turn 只要有任一别名被暴露，就算被恢复。
- **主定义：实际暴露（actual exposure）**。只有逐字出现在 prompt 里的原文 turn 才算：
  - VMem 的 raw turn 暴露它自己；
  - NEMORI 的 top-2 episode 以及匹配对照的 episode，暴露它们打印出来的全部原文；
  - episode 摘要、semantic fact **一律不暴露任何 turn**。摘要不等于原文，这与 RQ2 的"V"定义一致。
- **溯源展开（provenance-expanded）**。episode 记录暴露它的全部原文；semantic 只有 episode 级溯源，仍然不计。NEMORI 的溯源展开就是"10 个 episode 的离线展开"曲线，这是**假设性**的，NEMORI 实际没有展示这些原文。VMem 池内三类条目没有统一排序，所以溯源展开版只报端点（§3.3）。

### 2.2 预算与跨界规则（所有方法相同）

1. 按候选列表的**原始检索顺序**逐个取候选。任何地方都没有用 gold 重新排序。
2. 把每个候选映射到它暴露的 turn，与此前已暴露的 turn 去重，累计唯一 turn 数（或 token 数）。
3. **strict 前缀规则（主分析）**：候选 i 被纳入，当且仅当纳入后累计唯一 turn ≤ B。遇到第一个会超出 B 的候选就停止，不跳过它去取后面更小的候选。所以一个大 episode 可能让 episode 级方法在 B 内只用掉少于 B 条 turn；第 1 个 episode 本身就超过 B 时，覆盖为 0。
4. **inclusive 规则（敏感性分析）**：把跨界的那个候选整个纳入，实际用量会超过 B。这对 episode 级方法是上界（§5.1）。
5. 列表用完后，覆盖保持在列表末端的值不变（方法本身没有更多候选）。各预算下仍有剩余候选的题占比见 §3.2。
6. **token 预算**：同样的规则，计量换成 `f"{role}: {content}"` 的 cl100k_base token 数（本地 tiktoken BPE，不联网）。这只是 Claude tokenizer 的近似。它只统计原文 turn，**不含** episode 摘要和 semantic fact 的 token；各方法的 prompt 都带有这些背景条目，见 §7。

### 2.3 指标

- **complete coverage**：该题全部 gold turn 都被暴露的题所占比例（主指标）。
- **partial coverage**：只暴露了部分 gold turn。
- **gold-turn recall**：每题被暴露的 gold turn 所占比例，再对题取平均。
- **AUC**：在整数预算 B = 10…120 上对 complete coverage 取平均，等价于归一化曲线下面积，结果仍是百分比。token 版取 300…3600（步长 50）。
- **达到 80% / 90% complete 所需预算**：在 B = 1…300 中第一个使 complete ≥ 阈值的整数。达不到时注明列表最高值。
- 分母：1531 题全部可映射的题（部分可映射 4 题、不可映射 5 题不计入）。

## 3. 预算–覆盖结果

### 3.1 complete coverage（%，strict，按 turn 计预算）

**Haiku 4.5**

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | 全列表（端点） | 端点平均 turn |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 3.4 | 9.3 | 15.0 | 16.1 | 16.2 | 16.2 | 16.2 | 16.2 | 22.1 |
| NEMORI top-10 episodes (offline expansion, hypothetical)（假设） | 3.6 | 12.3 | 32.3 | 48.0 | 57.5 | 62.6 | 65.6 | 68.8 | 79.5 |
| Matched-budget retrieval-only (RQ3) | 17.4 | 34.5 | 52.5 | 61.1 | 67.2 | 71.5 | 73.7 | 77.0 | 122.2 |
| Query-guided round-1 pool (before ViewCards) | 44.6 | 56.6 | 67.9 | 75.2 | 80.4 | 82.0 | 82.6 | 82.6 | 92.7 |
| Full VMem retrieval (round 1 + refinement) | 44.6 | 56.6 | 67.9 | 75.2 | 80.8 | 82.6 | 83.7 | 85.4 | 104.5 |

**Opus 4.5**

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | 全列表（端点） | 端点平均 turn |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 3.4 | 9.3 | 15.0 | 16.1 | 16.2 | 16.2 | 16.2 | 16.2 | 22.1 |
| NEMORI top-10 episodes (offline expansion, hypothetical)（假设） | 3.6 | 12.3 | 32.3 | 48.0 | 57.5 | 62.6 | 65.6 | 68.8 | 79.5 |
| Matched-budget retrieval-only (RQ3) | 17.4 | 34.5 | 52.5 | 61.1 | 67.1 | 71.4 | 73.1 | 75.0 | 107.7 |
| Query-guided round-1 pool (before ViewCards) | 46.6 | 58.1 | 69.4 | 77.1 | 81.0 | 82.6 | 83.0 | 83.1 | 84.8 |
| Full VMem retrieval (round 1 + refinement) | 46.6 | 58.1 | 69.4 | 77.1 | 81.2 | 83.3 | 83.9 | 84.3 | 88.6 |

partial coverage：

Haiku 4.5

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | 全列表（端点） | 端点平均 turn |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 1.8 | 4.0 | 7.9 | 8.6 | 8.6 | 8.6 | 8.6 | 8.6 | 22.1 |
| NEMORI top-10 episodes (offline expansion, hypothetical)（假设） | 1.8 | 4.4 | 10.6 | 12.9 | 13.0 | 12.3 | 12.3 | 11.9 | 79.5 |
| Matched-budget retrieval-only (RQ3) | 4.5 | 8.3 | 11.9 | 11.8 | 12.0 | 11.7 | 11.5 | 10.5 | 122.2 |
| Query-guided round-1 pool (before ViewCards) | 10.6 | 12.5 | 12.7 | 12.3 | 11.6 | 11.0 | 10.8 | 10.8 | 92.7 |
| Full VMem retrieval (round 1 + refinement) | 10.6 | 12.5 | 12.7 | 12.3 | 11.4 | 10.8 | 10.2 | 9.1 | 104.5 |

Opus 4.5

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | 全列表（端点） | 端点平均 turn |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 1.8 | 4.0 | 7.9 | 8.6 | 8.6 | 8.6 | 8.6 | 8.6 | 22.1 |
| NEMORI top-10 episodes (offline expansion, hypothetical)（假设） | 1.8 | 4.4 | 10.6 | 12.9 | 13.0 | 12.3 | 12.3 | 11.9 | 79.5 |
| Matched-budget retrieval-only (RQ3) | 4.5 | 8.3 | 11.9 | 11.8 | 12.1 | 11.8 | 11.8 | 11.1 | 107.7 |
| Query-guided round-1 pool (before ViewCards) | 10.4 | 11.7 | 12.5 | 12.0 | 11.4 | 11.0 | 10.8 | 10.7 | 84.8 |
| Full VMem retrieval (round 1 + refinement) | 10.4 | 11.7 | 12.5 | 12.0 | 11.4 | 10.9 | 10.7 | 10.4 | 88.6 |

gold-turn recall：

Haiku 4.5

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | 全列表（端点） | 端点平均 turn |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 4.0 | 10.9 | 18.3 | 19.7 | 19.8 | 19.8 | 19.8 | 19.8 | 22.1 |
| NEMORI top-10 episodes (offline expansion, hypothetical)（假设） | 4.2 | 14.1 | 37.0 | 54.1 | 63.9 | 68.7 | 71.7 | 74.8 | 79.5 |
| Matched-budget retrieval-only (RQ3) | 19.4 | 38.1 | 57.8 | 66.5 | 73.0 | 77.3 | 79.8 | 82.8 | 122.2 |
| Query-guided round-1 pool (before ViewCards) | 49.2 | 62.1 | 74.0 | 81.3 | 86.3 | 87.7 | 88.2 | 88.2 | 92.7 |
| Full VMem retrieval (round 1 + refinement) | 49.2 | 62.1 | 74.0 | 81.3 | 86.6 | 88.2 | 89.2 | 90.3 | 104.5 |

Opus 4.5

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | 全列表（端点） | 端点平均 turn |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 4.0 | 10.9 | 18.3 | 19.7 | 19.8 | 19.8 | 19.8 | 19.8 | 22.1 |
| NEMORI top-10 episodes (offline expansion, hypothetical)（假设） | 4.2 | 14.1 | 37.0 | 54.1 | 63.9 | 68.7 | 71.7 | 74.8 | 79.5 |
| Matched-budget retrieval-only (RQ3) | 19.4 | 38.1 | 57.8 | 66.5 | 73.0 | 77.3 | 79.3 | 81.1 | 107.7 |
| Query-guided round-1 pool (before ViewCards) | 51.2 | 63.3 | 75.4 | 83.3 | 86.8 | 88.4 | 88.8 | 88.8 | 84.8 |
| Full VMem retrieval (round 1 + refinement) | 51.2 | 63.3 | 75.4 | 83.3 | 87.0 | 89.1 | 89.7 | 90.0 | 88.6 |

### 3.2 每个预算下实际用掉的 turn 数，以及列表尚未用完的题占比

格式：平均实际暴露 turn / 列表长度 ≥ B 的题 %。episode 级方法因 strict 规则，实际用量低于 B；首轮池在 B ≥ 80 后有大量题的列表已经用完，曲线随之变平。

Haiku 4.5

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 |
|---|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 3 / 77 | 9 / 50 | 19 / 13 | 22 / 1 | 22 / 0 | 22 / 0 | 22 / 0 |
| NEMORI top-10 episodes (offline expansion, hypothetical) | 4 / 100 | 12 / 100 | 33 / 89 | 50 / 66 | 63 / 44 | 71 / 28 | 76 / 15 |
| Matched-budget retrieval-only (RQ3) | 5 / 100 | 14 / 100 | 34 / 100 | 53 / 98 | 72 / 86 | 88 / 64 | 101 / 40 |
| Query-guided round-1 pool (before ViewCards) | 10 / 100 | 20 / 100 | 40 / 100 | 60 / 100 | 77 / 60 | 88 / 48 | 93 / 3 |
| Full VMem retrieval (round 1 + refinement) | 10 / 100 | 20 / 100 | 40 / 100 | 60 / 100 | 78 / 68 | 90 / 58 | 98 / 16 |

Opus 4.5

| 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 |
|---|---:|---:|---:|---:|---:|---:|---:|
| NEMORI (actual raw-turn exposure) | 3 / 77 | 9 / 50 | 19 / 13 | 22 / 1 | 22 / 0 | 22 / 0 | 22 / 0 |
| NEMORI top-10 episodes (offline expansion, hypothetical) | 4 / 100 | 12 / 100 | 33 / 89 | 50 / 66 | 63 / 44 | 71 / 28 | 76 / 15 |
| Matched-budget retrieval-only (RQ3) | 5 / 100 | 14 / 100 | 34 / 100 | 53 / 99 | 72 / 83 | 87 / 54 | 98 / 28 |
| Query-guided round-1 pool (before ViewCards) | 10 / 100 | 20 / 100 | 40 / 100 | 60 / 99 | 75 / 42 | 82 / 28 | 85 / 2 |
| Full VMem retrieval (round 1 + refinement) | 10 / 100 | 20 / 100 | 40 / 100 | 60 / 99 | 76 / 47 | 83 / 34 | 87 / 6 |

### 3.3 端点：完整列表，以及两种暴露定义

端点**不是**预算对齐的比较：各方法的列表长度不同（最后一列）。

| Backbone | 端点 | 定义 | complete % | partial % | gold-turn recall % | 暴露 turn/题 |
|---|---|---|---:|---:|---:|---:|
| Haiku 4.5 | NEMORI | 实际暴露（top-2 原文） | 16.2 | 8.6 | 19.8 | 22.1 |
| Haiku 4.5 | NEMORI | 溯源展开（10 个 episode 的全部原文，假设） | 68.8 | 11.9 | 74.8 | 79.5 |
| Haiku 4.5 | Matched retrieval-only | 实际暴露（= 溯源展开） | 77.0 | 10.5 | 82.8 | 122.2 |
| Haiku 4.5 | Query-guided round-1 | 实际暴露（turn 路由） | 82.6 | 10.8 | 88.2 | 92.7 |
| Haiku 4.5 | Query-guided round-1 | 溯源展开（+10 个 episode 的全部原文） | 91.0 | 7.1 | 95.2 | 160.2 |
| Haiku 4.5 | Full VMem 检索（R1+扩展） | 实际暴露（turn 路由） | 85.4 | 9.1 | 90.3 | 104.5 |
| Haiku 4.5 | Full VMem 检索（R1+扩展） | 溯源展开（+全部 episode 原文） | 93.2 | 5.5 | 96.5 | 179.6 |
| Haiku 4.5 | Full VMem 最终 prompt | 实际暴露（+卡片引用原文区） | 91.6 | 6.5 | 95.3 | 113.0 |
| Opus 4.5 | NEMORI | 实际暴露（top-2 原文） | 16.2 | 8.6 | 19.8 | 22.1 |
| Opus 4.5 | NEMORI | 溯源展开（10 个 episode 的全部原文，假设） | 68.8 | 11.9 | 74.8 | 79.5 |
| Opus 4.5 | Matched retrieval-only | 实际暴露（= 溯源展开） | 75.0 | 11.1 | 81.1 | 107.7 |
| Opus 4.5 | Query-guided round-1 | 实际暴露（turn 路由） | 83.1 | 10.7 | 88.8 | 84.8 |
| Opus 4.5 | Query-guided round-1 | 溯源展开（+10 个 episode 的全部原文） | 91.0 | 6.8 | 94.9 | 153.3 |
| Opus 4.5 | Full VMem 检索（R1+扩展） | 实际暴露（turn 路由） | 84.3 | 10.4 | 90.0 | 88.6 |
| Opus 4.5 | Full VMem 检索（R1+扩展） | 溯源展开（+全部 episode 原文） | 92.0 | 6.5 | 95.9 | 160.0 |
| Opus 4.5 | Full VMem 最终 prompt | 实际暴露（+卡片引用原文区） | 91.7 | 6.5 | 95.4 | 97.1 |

解读：
- 首轮池的完整列表比匹配对照**更短**（93 / 85 vs 122 / 108 turn），complete 却更高（82.6 / 83.1 vs 77.0 / 75.0%）。
- 按溯源展开，VMem 首轮池可达 91%，但需要 150+ 条 turn。而且 VMem 实际只给出 episode 摘要，所以这只能说明"证据所在的 episode 已被找到"。

### 3.4 AUC 与阈值预算

| Backbone | 策略 | AUC complete [10,120] | AUC recall [10,120] | AUC complete（token, [300,3600]） | 达到 80% complete 的预算 | 达到 90% complete 的预算 | 最高 complete（全列表） |
|---|---|---:|---:|---:|---:|---:|---:|
| Haiku 4.5 | NEMORI (actual raw-turn exposure) | 14.5 | 17.7 | 14.1 | 未达到（最高 16.2%） | 未达到（最高 16.2%） | 16.2 |
| Haiku 4.5 | NEMORI top-10 episodes (offline expansion, hypothetical) | 44.4 | 49.5 | 40.0 | 未达到（最高 68.8%） | 未达到（最高 68.8%） | 68.8 |
| Haiku 4.5 | Matched-budget retrieval-only (RQ3) | 58.6 | 63.8 | 55.2 | 未达到（最高 77.0%） | 未达到（最高 77.0%） | 77.0 |
| Haiku 4.5 | Query-guided round-1 pool (before ViewCards) | 73.1 | 78.9 | 71.3 | 78 | 未达到（最高 82.6%） | 82.6 |
| Haiku 4.5 | Full VMem retrieval (round 1 + refinement) | 73.4 | 79.1 | 71.5 | 77 | 未达到（最高 85.4%） | 85.4 |
| Opus 4.5 | NEMORI (actual raw-turn exposure) | 14.5 | 17.7 | 14.1 | 未达到（最高 16.2%） | 未达到（最高 16.2%） | 16.2 |
| Opus 4.5 | NEMORI top-10 episodes (offline expansion, hypothetical) | 44.4 | 49.5 | 40.0 | 未达到（最高 68.8%） | 未达到（最高 68.8%） | 68.8 |
| Opus 4.5 | Matched-budget retrieval-only (RQ3) | 58.5 | 63.7 | 55.2 | 未达到（最高 75.0%） | 未达到（最高 75.0%） | 75.0 |
| Opus 4.5 | Query-guided round-1 pool (before ViewCards) | 74.1 | 79.9 | 72.3 | 73 | 未达到（最高 83.1%） | 83.1 |
| Opus 4.5 | Full VMem retrieval (round 1 + refinement) | 74.4 | 80.2 | 72.5 | 73 | 未达到（最高 84.3%） | 84.3 |

## 4. 分组：类别、单/多 turn、单/跨 session

complete coverage（%，strict）。"端点"一列为完整列表，长度不对齐。

**Haiku 4.5**

| 分组 | n | 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | AUC [10,120] | 端点 |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Multi-hop | 279 | NEMORI | 0.0 | 0.4 | 1.8 | 1.8 | 1.8 | 1.8 | 1.8 | 1.5 | 1.8 |
| Multi-hop | 279 | NEMORI top-10 episodes（假设） | 0.0 | 0.7 | 6.5 | 14.3 | 20.1 | 25.4 | 28.0 | 14.9 | 31.5 |
| Multi-hop | 279 | Matched-budget retrieval-only | 0.0 | 1.8 | 10.4 | 22.6 | 29.0 | 36.2 | 40.5 | 22.0 | 47.7 |
| Multi-hop | 279 | Query-guided round-1 pool | 7.9 | 16.5 | 27.6 | 38.0 | 46.6 | 50.9 | 52.7 | 37.3 | 52.7 |
| Multi-hop | 279 | Full VMem retrieval | 7.9 | 16.5 | 27.6 | 38.0 | 47.0 | 51.3 | 55.6 | 37.6 | 60.9 |
| Temporal | 320 | NEMORI | 5.0 | 10.9 | 18.1 | 19.7 | 19.7 | 19.7 | 19.7 | 17.7 | 19.7 |
| Temporal | 320 | NEMORI top-10 episodes（假设） | 5.9 | 17.5 | 40.9 | 57.8 | 65.3 | 70.3 | 72.2 | 52.0 | 75.6 |
| Temporal | 320 | Matched-budget retrieval-only | 21.2 | 38.4 | 61.3 | 69.4 | 77.2 | 81.6 | 82.8 | 66.7 | 84.7 |
| Temporal | 320 | Query-guided round-1 pool | 52.2 | 65.6 | 76.9 | 83.1 | 87.2 | 87.2 | 87.5 | 80.2 | 87.5 |
| Temporal | 320 | Full VMem retrieval | 52.2 | 65.6 | 76.9 | 83.1 | 88.4 | 88.8 | 89.1 | 80.8 | 89.7 |
| Open-domain | 92 | NEMORI | 0.0 | 3.3 | 7.6 | 8.7 | 8.7 | 8.7 | 8.7 | 7.6 | 8.7 |
| Open-domain | 92 | NEMORI top-10 episodes（假设） | 0.0 | 4.3 | 20.7 | 27.2 | 31.5 | 33.7 | 37.0 | 24.1 | 38.0 |
| Open-domain | 92 | Matched-budget retrieval-only | 6.5 | 16.3 | 31.5 | 34.8 | 39.1 | 43.5 | 45.7 | 34.6 | 55.4 |
| Open-domain | 92 | Query-guided round-1 pool | 17.4 | 25.0 | 32.6 | 40.2 | 45.7 | 45.7 | 47.8 | 38.8 | 47.8 |
| Open-domain | 92 | Full VMem retrieval | 17.4 | 25.0 | 32.6 | 40.2 | 45.7 | 47.8 | 51.1 | 39.5 | 58.7 |
| Single-hop | 840 | NEMORI | 4.3 | 12.4 | 19.0 | 20.4 | 20.5 | 20.5 | 20.5 | 18.4 | 20.5 |
| Single-hop | 840 | NEMORI top-10 episodes（假设） | 4.3 | 15.1 | 38.9 | 57.7 | 69.8 | 75.2 | 78.8 | 53.5 | 82.0 |
| Single-hop | 840 | Matched-budget retrieval-only | 23.0 | 45.8 | 65.5 | 73.7 | 79.2 | 82.4 | 84.4 | 70.2 | 86.2 |
| Single-hop | 840 | Query-guided round-1 pool | 56.9 | 69.9 | 81.8 | 88.5 | 92.9 | 94.3 | 94.4 | 86.0 | 94.4 |
| Single-hop | 840 | Full VMem retrieval | 56.9 | 69.9 | 81.8 | 88.5 | 93.0 | 94.4 | 94.6 | 86.1 | 94.9 |
| 单 gold turn | 1122 | NEMORI | 4.4 | 12.4 | 19.5 | 21.0 | 21.1 | 21.1 | 21.1 | 19.0 | 21.1 |
| 单 gold turn | 1122 | NEMORI top-10 episodes（假设） | 4.6 | 16.1 | 39.9 | 58.1 | 68.7 | 74.1 | 76.9 | 53.3 | 80.3 |
| 单 gold turn | 1122 | Matched-budget retrieval-only | 22.9 | 43.9 | 64.8 | 73.2 | 78.7 | 82.0 | 83.9 | 69.5 | 85.7 |
| 单 gold turn | 1122 | Query-guided round-1 pool | 56.6 | 70.0 | 81.4 | 87.9 | 92.0 | 92.7 | 93.0 | 85.2 | 93.0 |
| 单 gold turn | 1122 | Full VMem retrieval | 56.6 | 70.0 | 81.4 | 87.9 | 92.2 | 93.1 | 93.6 | 85.4 | 94.1 |
| 多 gold turn（≥2） | 409 | NEMORI | 0.7 | 1.0 | 2.7 | 2.7 | 2.7 | 2.7 | 2.7 | 2.4 | 2.7 |
| 多 gold turn（≥2） | 409 | NEMORI top-10 episodes（假设） | 0.7 | 2.0 | 11.5 | 20.3 | 26.7 | 31.3 | 34.7 | 19.9 | 37.4 |
| 多 gold turn（≥2） | 409 | Matched-budget retrieval-only | 2.4 | 8.6 | 18.8 | 28.1 | 35.7 | 42.5 | 46.0 | 28.6 | 53.1 |
| 多 gold turn（≥2） | 409 | Query-guided round-1 pool | 11.7 | 19.8 | 31.1 | 40.6 | 48.7 | 52.6 | 54.0 | 39.9 | 54.0 |
| 多 gold turn（≥2） | 409 | Full VMem retrieval | 11.7 | 19.8 | 31.1 | 40.6 | 49.4 | 53.5 | 56.7 | 40.4 | 61.6 |
| 单 session | 1201 | NEMORI | 4.3 | 11.9 | 19.1 | 20.5 | 20.6 | 20.6 | 20.6 | 18.5 | 20.6 |
| 单 session | 1201 | NEMORI top-10 episodes（假设） | 4.6 | 15.7 | 39.9 | 57.5 | 67.9 | 73.2 | 76.4 | 52.8 | 79.8 |
| 单 session | 1201 | Matched-budget retrieval-only | 22.2 | 43.1 | 64.2 | 72.5 | 78.1 | 81.7 | 83.7 | 69.0 | 85.6 |
| 单 session | 1201 | Query-guided round-1 pool | 55.0 | 68.0 | 79.4 | 85.9 | 90.3 | 91.3 | 91.7 | 83.5 | 91.7 |
| 单 session | 1201 | Full VMem retrieval | 55.0 | 68.0 | 79.4 | 85.9 | 90.6 | 91.8 | 92.3 | 83.7 | 93.0 |
| 跨 session（≥2） | 330 | NEMORI | 0.0 | 0.0 | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 | 0.2 | 0.3 |
| 跨 session（≥2） | 330 | NEMORI top-10 episodes（假设） | 0.0 | 0.3 | 4.8 | 13.6 | 19.4 | 24.2 | 26.7 | 13.8 | 29.1 |
| 跨 session（≥2） | 330 | Matched-budget retrieval-only | 0.0 | 3.0 | 10.0 | 19.7 | 27.6 | 34.2 | 37.6 | 20.6 | 45.8 |
| 跨 session（≥2） | 330 | Query-guided round-1 pool | 7.0 | 14.8 | 26.1 | 36.4 | 44.2 | 47.9 | 49.4 | 35.1 | 49.4 |
| 跨 session（≥2） | 330 | Full VMem retrieval | 7.0 | 14.8 | 26.1 | 36.4 | 45.2 | 49.1 | 52.7 | 35.7 | 57.9 |

**Opus 4.5**

| 分组 | n | 策略 | B=10 | B=20 | B=40 | B=60 | B=80 | B=100 | B=120 | AUC [10,120] | 端点 |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Multi-hop | 279 | NEMORI | 0.0 | 0.4 | 1.8 | 1.8 | 1.8 | 1.8 | 1.8 | 1.5 | 1.8 |
| Multi-hop | 279 | NEMORI top-10 episodes（假设） | 0.0 | 0.7 | 6.5 | 14.3 | 20.1 | 25.4 | 28.0 | 14.9 | 31.5 |
| Multi-hop | 279 | Matched-budget retrieval-only | 0.0 | 1.8 | 10.4 | 22.6 | 29.0 | 35.8 | 39.1 | 21.8 | 43.0 |
| Multi-hop | 279 | Query-guided round-1 pool | 9.7 | 19.0 | 29.4 | 41.6 | 48.7 | 53.8 | 55.2 | 39.8 | 55.6 |
| Multi-hop | 279 | Full VMem retrieval | 9.7 | 19.0 | 29.4 | 41.6 | 48.7 | 53.8 | 55.6 | 39.9 | 56.6 |
| Temporal | 320 | NEMORI | 5.0 | 10.9 | 18.1 | 19.7 | 19.7 | 19.7 | 19.7 | 17.7 | 19.7 |
| Temporal | 320 | NEMORI top-10 episodes（假设） | 5.9 | 17.5 | 40.9 | 57.8 | 65.3 | 70.3 | 72.2 | 52.0 | 75.6 |
| Temporal | 320 | Matched-budget retrieval-only | 21.2 | 38.4 | 61.3 | 69.4 | 76.9 | 81.2 | 81.9 | 66.5 | 83.1 |
| Temporal | 320 | Query-guided round-1 pool | 57.2 | 67.5 | 77.2 | 84.4 | 85.9 | 86.6 | 86.9 | 80.7 | 86.9 |
| Temporal | 320 | Full VMem retrieval | 57.2 | 67.5 | 77.2 | 84.4 | 86.2 | 88.4 | 88.8 | 81.3 | 89.4 |
| Open-domain | 92 | NEMORI | 0.0 | 3.3 | 7.6 | 8.7 | 8.7 | 8.7 | 8.7 | 7.6 | 8.7 |
| Open-domain | 92 | NEMORI top-10 episodes（假设） | 0.0 | 4.3 | 20.7 | 27.2 | 31.5 | 33.7 | 37.0 | 24.1 | 38.0 |
| Open-domain | 92 | Matched-budget retrieval-only | 6.5 | 16.3 | 31.5 | 34.8 | 39.1 | 43.5 | 45.7 | 34.6 | 54.3 |
| Open-domain | 92 | Query-guided round-1 pool | 22.8 | 31.5 | 37.0 | 42.4 | 48.9 | 48.9 | 48.9 | 42.5 | 48.9 |
| Open-domain | 92 | Full VMem retrieval | 22.8 | 31.5 | 37.0 | 42.4 | 48.9 | 50.0 | 51.1 | 42.8 | 52.2 |
| Single-hop | 840 | NEMORI | 4.3 | 12.4 | 19.0 | 20.4 | 20.5 | 20.5 | 20.5 | 18.4 | 20.5 |
| Single-hop | 840 | NEMORI top-10 episodes（假设） | 4.3 | 15.1 | 38.9 | 57.7 | 69.8 | 75.2 | 78.8 | 53.5 | 82.0 |
| Single-hop | 840 | Matched-budget retrieval-only | 23.0 | 45.8 | 65.5 | 73.7 | 79.2 | 82.5 | 84.0 | 70.2 | 84.9 |
| Single-hop | 840 | Query-guided round-1 pool | 57.5 | 70.4 | 83.2 | 90.0 | 93.3 | 94.4 | 94.5 | 86.5 | 94.5 |
| Single-hop | 840 | Full VMem retrieval | 57.5 | 70.4 | 83.2 | 90.0 | 93.6 | 94.9 | 95.1 | 86.7 | 95.1 |
| 单 gold turn | 1122 | NEMORI | 4.4 | 12.4 | 19.5 | 21.0 | 21.1 | 21.1 | 21.1 | 19.0 | 21.1 |
| 单 gold turn | 1122 | NEMORI top-10 episodes（假设） | 4.6 | 16.1 | 39.9 | 58.1 | 68.7 | 74.1 | 76.9 | 53.3 | 80.3 |
| 单 gold turn | 1122 | Matched-budget retrieval-only | 22.9 | 43.9 | 64.8 | 73.2 | 78.7 | 82.1 | 83.4 | 69.4 | 84.5 |
| 单 gold turn | 1122 | Query-guided round-1 pool | 58.6 | 70.7 | 82.3 | 89.4 | 92.2 | 93.0 | 93.1 | 85.8 | 93.1 |
| 单 gold turn | 1122 | Full VMem retrieval | 58.6 | 70.7 | 82.3 | 89.4 | 92.5 | 93.9 | 94.2 | 86.1 | 94.3 |
| 多 gold turn（≥2） | 409 | NEMORI | 0.7 | 1.0 | 2.7 | 2.7 | 2.7 | 2.7 | 2.7 | 2.4 | 2.7 |
| 多 gold turn（≥2） | 409 | NEMORI top-10 episodes（假设） | 0.7 | 2.0 | 11.5 | 20.3 | 26.7 | 31.3 | 34.7 | 19.9 | 37.4 |
| 多 gold turn（≥2） | 409 | Matched-budget retrieval-only | 2.4 | 8.6 | 18.8 | 28.1 | 35.5 | 42.1 | 44.7 | 28.4 | 49.1 |
| 多 gold turn（≥2） | 409 | Query-guided round-1 pool | 13.7 | 23.5 | 34.0 | 43.5 | 50.1 | 54.3 | 55.3 | 42.1 | 55.5 |
| 多 gold turn（≥2） | 409 | Full VMem retrieval | 13.7 | 23.5 | 34.0 | 43.5 | 50.1 | 54.5 | 55.7 | 42.2 | 57.0 |
| 单 session | 1201 | NEMORI | 4.3 | 11.9 | 19.1 | 20.5 | 20.6 | 20.6 | 20.6 | 18.5 | 20.6 |
| 单 session | 1201 | NEMORI top-10 episodes（假设） | 4.6 | 15.7 | 39.9 | 57.5 | 67.9 | 73.2 | 76.4 | 52.8 | 79.8 |
| 单 session | 1201 | Matched-budget retrieval-only | 22.2 | 43.1 | 64.2 | 72.5 | 78.1 | 81.8 | 83.3 | 69.0 | 84.3 |
| 单 session | 1201 | Query-guided round-1 pool | 57.0 | 69.0 | 80.8 | 87.7 | 90.8 | 91.6 | 91.8 | 84.3 | 91.8 |
| 单 session | 1201 | Full VMem retrieval | 57.0 | 69.0 | 80.8 | 87.7 | 91.0 | 92.4 | 92.8 | 84.5 | 92.8 |
| 跨 session（≥2） | 330 | NEMORI | 0.0 | 0.0 | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 | 0.2 | 0.3 |
| 跨 session（≥2） | 330 | NEMORI top-10 episodes（假设） | 0.0 | 0.3 | 4.8 | 13.6 | 19.4 | 24.2 | 26.7 | 13.8 | 29.1 |
| 跨 session（≥2） | 330 | Matched-budget retrieval-only | 0.0 | 3.0 | 10.0 | 19.7 | 27.3 | 33.6 | 36.1 | 20.3 | 41.2 |
| 跨 session（≥2） | 330 | Query-guided round-1 pool | 8.8 | 18.2 | 27.9 | 38.8 | 45.5 | 50.0 | 51.2 | 37.2 | 51.5 |
| 跨 session（≥2） | 330 | Full VMem retrieval | 8.8 | 18.2 | 27.9 | 38.8 | 45.5 | 50.3 | 51.8 | 37.3 | 53.3 |

分组配对差（首轮池 − 对照，pp，题级 bootstrap 95% CI）：

Haiku 4.5

| 分组 | n | A: QG R1 − Matched，B=40 | A: B=80 | A: AUC [10,120] | B: QG R1 − NEMORI 实际，B=40 | B: AUC [10,120] |
|---|---:|---:|---:|---:|---:|---:|
| Multi-hop | 279 | +17.2 [+11.8, +22.9] | +17.6 [+11.1, +24.0] | +15.3 [+10.8, +20.1] | +25.8 [+20.8, +31.2] | +35.7 [+31.1, +40.4] |
| Temporal | 320 | +15.6 [+9.4, +21.9] | +10.0 [+4.7, +15.3] | +13.5 [+9.1, +17.9] | +58.8 [+53.1, +64.4] | +62.4 [+57.6, +67.1] |
| Open-domain | 92 | +1.1 [-7.6, +9.8] | +6.5 [-4.3, +17.4] | +4.2 [-3.8, +12.4] | +25.0 [+16.3, +34.8] | +31.2 [+22.7, +40.0] |
| Single-hop | 840 | +16.3 [+12.7, +20.0] | +13.7 [+10.6, +16.8] | +15.8 [+13.0, +18.5] | +62.7 [+58.9, +66.4] | +67.6 [+64.6, +70.6] |
| 单 gold turn | 1122 | +16.6 [+13.4, +19.8] | +13.3 [+10.6, +15.9] | +15.7 [+13.4, +18.1] | +61.9 [+58.8, +64.8] | +66.2 [+63.5, +68.8] |
| 多 gold turn（≥2） | 409 | +12.2 [+7.3, +17.1] | +13.0 [+7.6, +18.3] | +11.2 [+7.1, +15.3] | +28.4 [+24.0, +33.3] | +37.5 [+33.6, +41.6] |
| 单 session | 1201 | +15.2 [+12.1, +18.4] | +12.2 [+9.7, +14.9] | +14.5 [+12.3, +17.0] | +60.4 [+57.3, +63.3] | +65.0 [+62.5, +67.6] |
| 跨 session（≥2） | 330 | +16.1 [+11.2, +21.2] | +16.7 [+10.6, +22.4] | +14.5 [+10.3, +18.7] | +25.8 [+20.6, +30.3] | +34.9 [+30.6, +39.1] |

Opus 4.5

| 分组 | n | A: QG R1 − Matched，B=40 | A: B=80 | A: AUC [10,120] | B: QG R1 − NEMORI 实际，B=40 | B: AUC [10,120] |
|---|---:|---:|---:|---:|---:|---:|
| Multi-hop | 279 | +19.0 [+13.3, +24.7] | +19.7 [+13.6, +26.2] | +18.1 [+13.5, +22.9] | +27.6 [+22.2, +33.3] | +38.3 [+33.5, +43.0] |
| Temporal | 320 | +15.9 [+9.7, +21.9] | +9.1 [+3.8, +14.1] | +14.1 [+9.7, +18.9] | +59.1 [+53.1, +64.4] | +62.9 [+57.9, +67.5] |
| Open-domain | 92 | +5.4 [-3.3, +14.1] | +9.8 [+0.0, +20.7] | +7.9 [-0.5, +15.8] | +29.3 [+19.6, +39.1] | +34.9 [+25.5, +43.7] |
| Single-hop | 840 | +17.7 [+13.9, +21.7] | +14.2 [+11.0, +17.3] | +16.3 [+13.6, +19.1] | +64.2 [+60.5, +67.6] | +68.1 [+65.2, +71.0] |
| 单 gold turn | 1122 | +17.5 [+14.3, +20.8] | +13.5 [+10.9, +16.2] | +16.4 [+13.9, +18.7] | +62.7 [+59.7, +65.7] | +66.8 [+64.2, +69.3] |
| 多 gold turn（≥2） | 409 | +15.2 [+10.5, +20.0] | +14.7 [+9.5, +20.0] | +13.7 [+9.5, +17.7] | +31.3 [+26.7, +35.9] | +39.7 [+35.5, +43.7] |
| 单 session | 1201 | +16.6 [+13.6, +19.7] | +12.7 [+10.1, +15.3] | +15.3 [+13.0, +17.6] | +61.7 [+58.7, +64.5] | +65.8 [+63.3, +68.2] |
| 跨 session（≥2） | 330 | +17.9 [+13.0, +22.7] | +18.2 [+12.1, +24.2] | +16.9 [+12.8, +21.2] | +27.6 [+22.7, +32.7] | +37.0 [+32.6, +41.3] |

**解读：**
- Multi-hop 与跨 session 题上，所有方法在小预算下都很低：B = 20 时匹配对照只有 2–3%，首轮池 15–19%。首轮池的相对优势（AUC +15 到 +18 pp）与总体相当，但绝对水平仍低。到 120 turn 时，首轮池在这两类题上只有约 50–55% complete。
- Temporal 和 Single-hop 是首轮池效率优势最明显的类别：B = 20 时 Single-hop 已达 70%，匹配对照为 46%。
- Open-domain 的差异不显著。匹配对照在其完整列表（平均 >120 turn）的端点上甚至更高（55.4 / 54.3 vs 47.8 / 48.9%），说明这类题需要更宽的上下文，turn 级精确检索的优势在这里有限。

## 5. 配对比较与稳健性

### 5.1 关键对比（Δ complete，pp）

题级配对 bootstrap（2000 次）、按对话聚类的 bootstrap（10 段对话有放回重抽，2000 次）、留一对话（10 个估计的最小值到最大值）。"胜/负题"指首个策略覆盖完整而对照不完整的题数，以及反过来的题数。

**Haiku 4.5**

| 对比 | 预算 | Δ complete（pp）[题级 95% CI] | 对话聚类 bootstrap 95% CI | 留一对话 Δ 范围 | 胜/负题 |
|---|---|---:|---:|---:|---:|
| A: Query-guided R1 − Matched retrieval-only | B=20 | +22.1 [+19.3, +24.8] | [+16.5, +28.8] | +20.5 … +23.8 | 457/119 |
| A: Query-guided R1 − Matched retrieval-only | B=40 | +15.4 [+12.7, +18.1] | [+10.7, +21.4] | +13.8 … +16.8 | 356/120 |
| A: Query-guided R1 − Matched retrieval-only | B=80 | +13.2 [+10.9, +15.5] | [+9.6, +17.3] | +12.1 … +14.6 | 290/88 |
| A: Query-guided R1 − Matched retrieval-only | B=120 | +8.8 [+6.5, +11.1] | [+6.3, +12.1] | +8.0 … +9.7 | 230/95 |
| A: Query-guided R1 − Matched retrieval-only | AUC [10,120] | +14.5 [+12.5, +16.5] | [+11.0, +18.9] | +13.3 … +15.8 | 859/304 |
| A: Query-guided R1 − Matched retrieval-only | AUC token [300,3600] | +16.1 [+14.1, +18.1] | [+12.2, +20.8] | +14.9 … +17.3 | 905/305 |
| A: Query-guided R1 − Matched retrieval-only | 全列表端点 | +5.6 [+3.3, +7.8] | [+3.2, +8.5] | +4.7 … +6.2 | 200/115 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=20 | +47.2 [+44.5, +49.7] | [+43.6, +51.1] | +46.3 … +48.1 | 752/29 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=40 | +52.9 [+50.2, +55.5] | [+49.6, +56.4] | +51.8 … +53.6 | 842/32 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=80 | +64.2 [+61.9, +66.6] | [+60.6, +67.1] | +63.4 … +65.2 | 993/10 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=120 | +66.4 [+64.0, +68.7] | [+62.3, +69.7] | +65.3 … +67.6 | 1024/8 |
| B: Query-guided R1 − NEMORI 实际暴露 | AUC [10,120] | +58.5 [+56.3, +60.7] | [+55.2, +61.5] | +57.6 … +59.5 | 1171/62 |
| B: Query-guided R1 − NEMORI 实际暴露 | AUC token [300,3600] | +57.2 [+55.0, +59.4] | [+54.2, +60.0] | +56.3 … +58.2 | 1174/66 |
| B: Query-guided R1 − NEMORI 实际暴露 | 全列表端点 | +66.4 [+64.0, +68.7] | [+62.3, +69.7] | +65.3 … +67.6 | 1024/8 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=20 | +44.2 [+41.3, +46.9] | [+39.9, +49.1] | +43.1 … +45.6 | 720/43 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=40 | +35.6 [+32.5, +38.5] | [+29.2, +42.4] | +34.3 … +37.4 | 626/81 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=80 | +22.9 [+20.4, +25.4] | [+17.7, +28.9] | +21.5 … +24.5 | 417/66 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=120 | +16.9 [+14.6, +19.3] | [+13.9, +20.2] | +16.0 … +18.0 | 330/71 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | AUC [10,120] | +28.7 [+26.7, +30.7] | [+24.4, +33.6] | +27.6 … +30.2 | 1103/188 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | AUC token [300,3600] | +31.3 [+29.1, +33.3] | [+26.3, +36.9] | +29.8 … +33.0 | 1104/187 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | 全列表端点 | +13.7 [+11.5, +16.0] | [+10.5, +17.1] | +12.4 … +14.5 | 287/77 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=20 | +22.1 [+19.5, +24.8] | [+17.7, +26.8] | +20.2 … +23.0 | 413/74 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=40 | +20.2 [+17.5, +22.8] | [+16.5, +24.5] | +18.8 … +21.0 | 407/98 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=80 | +9.7 [+7.8, +11.8] | [+6.2, +13.5] | +8.5 … +11.1 | 199/50 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=120 | +8.1 [+6.5, +9.8] | [+5.4, +10.8] | +7.2 … +8.7 | 145/21 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | AUC [10,120] | +14.2 [+12.7, +15.7] | [+11.8, +16.5] | +13.5 … +14.9 | 812/270 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | AUC token [300,3600] | +15.2 [+13.6, +16.8] | [+12.4, +18.0] | +14.4 … +16.0 | 792/267 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | 全列表端点 | +8.2 [+6.7, +9.7] | [+4.7, +11.3] | +6.8 … +8.9 | 138/13 |
| C: Full 检索 (R1+扩展) − R1（扩展贡献） | B=120 | +1.2 [+0.7, +1.8] | [+0.7, +1.8] | +1.0 … +1.3 | 18/0 |
| C: Full 检索 (R1+扩展) − R1（扩展贡献） | B=160 | +2.8 [+2.0, +3.7] | [+1.9, +3.7] | +2.5 … +3.1 | 43/0 |
| C: Full 检索 (R1+扩展) − R1（扩展贡献） | 全列表端点 | +2.9 [+2.0, +3.8] | [+2.0, +3.7] | +2.6 … +3.1 | 44/0 |
| D: Full 最终 prompt − Full 检索（卡片引用原文区贡献） | 端点 | +6.2 [+5.1, +7.4] | [+4.4, +8.2] | +5.5 … +6.6 | 95/0 |
| E: Full 最终 prompt − R1（扩展 + 引用原文区） | 端点 | +9.1 [+7.6, +10.6] | [+7.6, +10.6] | +8.7 … +9.4 | 139/0 |

**Opus 4.5**

| 对比 | 预算 | Δ complete（pp）[题级 95% CI] | 对话聚类 bootstrap 95% CI | 留一对话 Δ 范围 | 胜/负题 |
|---|---|---:|---:|---:|---:|
| A: Query-guided R1 − Matched retrieval-only | B=20 | +23.6 [+20.8, +26.3] | [+17.8, +29.9] | +22.3 … +25.4 | 478/117 |
| A: Query-guided R1 − Matched retrieval-only | B=40 | +16.9 [+14.2, +19.5] | [+12.6, +22.4] | +15.2 … +18.1 | 370/112 |
| A: Query-guided R1 − Matched retrieval-only | B=80 | +13.8 [+11.6, +16.3] | [+10.1, +18.6] | +12.6 … +15.0 | 301/89 |
| A: Query-guided R1 − Matched retrieval-only | B=120 | +9.9 [+7.6, +12.2] | [+7.3, +13.5] | +9.0 … +10.8 | 246/94 |
| A: Query-guided R1 − Matched retrieval-only | AUC [10,120] | +15.7 [+13.6, +17.7] | [+12.2, +20.1] | +14.4 … +16.8 | 885/291 |
| A: Query-guided R1 − Matched retrieval-only | AUC token [300,3600] | +17.1 [+15.0, +19.3] | [+13.5, +21.7] | +15.9 … +18.3 | 926/290 |
| A: Query-guided R1 − Matched retrieval-only | 全列表端点 | +8.0 [+5.7, +10.3] | [+5.3, +11.4] | +7.3 … +8.7 | 228/105 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=20 | +48.7 [+46.0, +51.2] | [+45.2, +52.5] | +47.8 … +49.9 | 774/28 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=40 | +54.3 [+51.7, +56.9] | [+50.4, +58.3] | +53.0 … +55.3 | 859/27 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=80 | +64.8 [+62.3, +67.2] | [+60.8, +68.1] | +64.0 … +66.0 | 1001/9 |
| B: Query-guided R1 − NEMORI 实际暴露 | B=120 | +66.8 [+64.5, +69.2] | [+62.5, +70.2] | +66.0 … +68.2 | 1031/8 |
| B: Query-guided R1 − NEMORI 实际暴露 | AUC [10,120] | +59.6 [+57.4, +61.7] | [+56.0, +62.7] | +58.6 … +60.7 | 1185/60 |
| B: Query-guided R1 − NEMORI 实际暴露 | AUC token [300,3600] | +58.2 [+56.0, +60.4] | [+54.9, +61.2] | +57.3 … +59.3 | 1188/57 |
| B: Query-guided R1 − NEMORI 实际暴露 | 全列表端点 | +66.9 [+64.5, +69.2] | [+62.7, +70.2] | +66.1 … +68.3 | 1032/8 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=20 | +45.7 [+42.8, +48.3] | [+40.9, +50.6] | +44.5 … +47.2 | 746/46 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=40 | +37.0 [+34.3, +39.8] | [+31.1, +43.3] | +35.7 … +39.0 | 644/77 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=80 | +23.5 [+21.0, +25.9] | [+18.3, +29.8] | +22.0 … +25.1 | 426/66 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | B=120 | +17.4 [+15.0, +19.9] | [+13.8, +21.5] | +16.0 … +18.5 | 335/69 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | AUC [10,120] | +29.8 [+27.7, +31.7] | [+25.5, +34.6] | +28.6 … +31.3 | 1111/190 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | AUC token [300,3600] | +32.3 [+30.3, +34.3] | [+27.3, +37.7] | +31.0 … +34.1 | 1116/180 |
| B': Query-guided R1 − NEMORI 离线展开（假设） | 全列表端点 | +14.2 [+11.8, +16.5] | [+10.6, +18.4] | +12.5 … +15.0 | 292/74 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=20 | +22.1 [+19.5, +24.8] | [+17.7, +26.8] | +20.2 … +23.0 | 413/74 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=40 | +20.2 [+17.5, +22.8] | [+16.5, +24.5] | +18.8 … +21.0 | 407/98 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=80 | +9.7 [+7.8, +11.7] | [+6.1, +13.4] | +8.5 … +11.0 | 198/50 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | B=120 | +7.4 [+5.9, +9.1] | [+4.6, +10.2] | +6.6 … +8.2 | 136/22 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | AUC [10,120] | +14.1 [+12.7, +15.6] | [+11.7, +16.4] | +13.4 … +14.8 | 803/270 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | AUC token [300,3600] | +15.2 [+13.6, +16.7] | [+12.3, +18.0] | +14.3 … +16.0 | 788/267 |
| S: Matched − NEMORI 离线展开（假设；两者都是原问题 episode 排序） | 全列表端点 | +6.2 [+4.8, +7.7] | [+3.0, +9.1] | +5.1 … +7.0 | 114/19 |
| C: Full 检索 (R1+扩展) − R1（扩展贡献） | B=120 | +0.9 [+0.5, +1.4] | [+0.4, +1.6] | +0.6 … +1.0 | 14/0 |
| C: Full 检索 (R1+扩展) − R1（扩展贡献） | B=160 | +1.2 [+0.7, +1.8] | [+0.7, +1.8] | +0.9 … +1.3 | 18/0 |
| C: Full 检索 (R1+扩展) − R1（扩展贡献） | 全列表端点 | +1.2 [+0.7, +1.8] | [+0.7, +1.9] | +1.0 … +1.4 | 19/0 |
| D: Full 最终 prompt − Full 检索（卡片引用原文区贡献） | 端点 | +7.4 [+6.1, +8.8] | [+5.8, +9.0] | +6.8 … +7.8 | 113/0 |
| E: Full 最终 prompt − R1（扩展 + 引用原文区） | 端点 | +8.6 [+7.3, +10.1] | [+6.9, +10.4] | +8.1 … +9.1 | 132/0 |

只看触发扩展的题（这是系统自己选出的子集，不能推广到全体）：

- Haiku 4.5：触发扩展的 326 题上，R1 端点 complete 75.5% → R1+扩展 89.0% → 最终 prompt 92.9%；配对差：C +13.5 pp [+9.8, +17.5]（n=326）；E +17.5 pp [+13.5, +21.8]（n=326）。
- Opus 4.5：触发扩展的 131 题上，R1 端点 complete 65.6% → R1+扩展 80.2% → 最终 prompt 88.5%；配对差：C +14.5 pp [+8.4, +20.6]（n=131）；E +22.9 pp [+16.0, +30.5]（n=131）。

说明：
- 对比 S 是两种"原问题 episode 排序"之间的比较：VMem 索引上的稠密排序 vs NEMORI 的 Qdrant 向量排序。两者的 embedding 文本和索引不同，所以匹配对照本身就比 NEMORI 展开高 14 pp（AUC）。这提示"同一记忆库上的排序实现"本身就是一个不小的混杂因素。也正因为如此，判断查询引导是否有效的主对照是 A（同一 VMem 索引），而不是 B'。
- C、D、E 都是端点或接近端点的比较，不是小预算下的效率比较。

### 5.2 稳健性检验（对比 A：首轮池 − 匹配对照）

| Backbone | 检验 | Δ complete（pp）[95% CI] / 数值 | n |
|---|---|---:|---:|
| Haiku 4.5 | A 在 inclusive 规则下（matched 的跨界 episode 整个计入），B=20 | +8.8 [+6.0, +11.6] | 1531 |
| Haiku 4.5 | A 在 inclusive 规则下（matched 的跨界 episode 整个计入），B=40 | +9.0 [+6.4, +11.4] | 1531 |
| Haiku 4.5 | A 在 inclusive 规则下（matched 的跨界 episode 整个计入），B=80 | +9.4 [+7.2, +11.6] | 1531 |
| Haiku 4.5 | A 只看未扩展题（round-1 池精确），B=40 | +14.9 [+11.9, +17.8] | 1205 |
| Haiku 4.5 | A 只看未扩展题（round-1 池精确），B=80 | +13.8 [+11.2, +16.4] | 1205 |
| Haiku 4.5 | A 只看未扩展题，AUC [10,120] | +14.9 [+12.6, +17.2] | 1205 |
| Haiku 4.5 | A 按 token 预算，B=600 token | +24.2 [+21.6, +26.9] | 1531 |
| Haiku 4.5 | A 按 token 预算，B=1200 token | +16.9 [+14.0, +19.5] | 1531 |
| Haiku 4.5 | A 按 token 预算，B=2400 token | +14.6 [+12.1, +17.1] | 1531 |
| Opus 4.5 | A 在 inclusive 规则下（matched 的跨界 episode 整个计入），B=20 | +10.3 [+7.5, +13.0] | 1531 |
| Opus 4.5 | A 在 inclusive 规则下（matched 的跨界 episode 整个计入），B=40 | +10.5 [+7.8, +13.0] | 1531 |
| Opus 4.5 | A 在 inclusive 规则下（matched 的跨界 episode 整个计入），B=80 | +10.2 [+8.0, +12.5] | 1531 |
| Opus 4.5 | A 只看未扩展题（round-1 池精确），B=40 | +16.9 [+14.1, +19.8] | 1400 |
| Opus 4.5 | A 只看未扩展题（round-1 池精确），B=80 | +14.0 [+11.5, +16.5] | 1400 |
| Opus 4.5 | A 只看未扩展题，AUC [10,120] | +15.7 [+13.5, +17.9] | 1400 |
| Opus 4.5 | A 按 token 预算，B=600 token | +24.8 [+22.1, +27.6] | 1531 |
| Opus 4.5 | A 按 token 预算，B=1200 token | +18.0 [+15.3, +20.8] | 1531 |
| Opus 4.5 | A 按 token 预算，B=2400 token | +15.6 [+13.1, +18.2] | 1531 |
| Haiku 4.5 | R1 边界不确定可能影响的题占比（扩展题且 min(估计边界, 规则下界) < B），B=40 | 0.1% | 1531 |
| Haiku 4.5 | R1 边界不确定可能影响的题占比（扩展题且 min(估计边界, 规则下界) < B），B=80 | 9.7% | 1531 |
| Haiku 4.5 | R1 边界不确定可能影响的题占比（扩展题且 min(估计边界, 规则下界) < B），B=120 | 21.0% | 1531 |
| Opus 4.5 | R1 边界不确定可能影响的题占比（扩展题且 min(估计边界, 规则下界) < B），B=40 | 0.1% | 1531 |
| Opus 4.5 | R1 边界不确定可能影响的题占比（扩展题且 min(估计边界, 规则下界) < B），B=80 | 5.9% | 1531 |
| Opus 4.5 | R1 边界不确定可能影响的题占比（扩展题且 min(估计边界, 规则下界) < B），B=120 | 8.6% | 1531 |

- **inclusive 规则**（匹配对照跨界的那个 episode 整个计入，实际用量超过 B）：优势缩小到 +9 到 +10 pp，但在每个预算点都仍显著。
- **只看未扩展的题**（round-1 池精确，没有 replay 边界估计）：结论不变。
- **token 预算**：优势略大，说明首轮池的 turn 并不比 episode 原文更长。
- **R1 边界不确定性**：B ≤ 40 时几乎不受影响（0.1%）；B = 80 时最多影响 6–10% 的题，B = 120 时最多 9–21%。

### 5.3 单元粒度敏感性

主分析中，首轮池的每条 turn 是一个候选单元。真实检索的单元是"hit 及其 ±1 相邻 turn"。为了检验粒度的影响，把首轮列表切成"对话中相邻的连续 turn 段"。这是对 hit 窗口的近似，合并相邻窗口后段会更大，对 VMem 是保守的。然后按 strict 规则截断：

| Backbone | 单元定义 | B=20 | B=40 | B=80 | B=120 | AUC [10,120] |
|---|---|---:|---:|---:|---:|---:|
| Haiku 4.5 | 单条 turn（主分析） | 56.6 | 67.9 | 80.4 | 82.6 | 73.1 |
| Haiku 4.5 | 相邻 turn 连续段（近似 hit 窗口，平均 2.6 turn/段，strict） | 55.6 | 67.8 | 80.2 | 82.6 | 72.8 |
| Haiku 4.5 | （对照）Matched，episode 单元 | 34.5 | 52.5 | 67.2 | 73.7 | 58.6 |
| Opus 4.5 | 单条 turn（主分析） | 58.1 | 69.4 | 81.0 | 83.0 | 74.1 |
| Opus 4.5 | 相邻 turn 连续段（近似 hit 窗口，平均 2.6 turn/段，strict） | 57.2 | 69.0 | 81.0 | 83.0 | 73.8 |
| Opus 4.5 | （对照）Matched，episode 单元 | 34.5 | 52.5 | 67.1 | 73.1 | 58.5 |

AUC 只下降 0.3 pp，所以首轮池的优势不是"单条 turn 粒度可以精确卡预算"造成的人为结果。

### 5.4 查询规划本身的作用（RQ3 400 题子集，补充分析）

RQ3 的 "w/o Query Planning" 是实际重跑的流水线：只用原问题检索，多粒度检索、RRF、turn 路由和扩展都保留。`Config(plan=False)` 同时去掉了规划器决定的"聚合题加宽预算"。下面把它保存的检索列表（R1 + 自身扩展）与 Full VMem 的检索列表放在同一子集上比较：

| Backbone | 策略（RQ3 子集，可映射题） | n | B=10 | B=20 | B=40 | B=80 | B=120 | AUC [10,120] | 端点 | 端点平均 turn |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Haiku 4.5 | Full VMem 检索列表（有规划，R1+扩展） | 399 | 43.6 | 56.1 | 67.2 | 82.5 | 85.5 | 74.2 | 87.0 | 104.1 |
| Haiku 4.5 | 其中 round-1（有规划） | 399 | 43.6 | 56.1 | 67.2 | 82.0 | 84.2 | 73.9 | 84.2 | 92.2 |
| Haiku 4.5 | w/o Query Planning 检索列表（只用原问题，R1+扩展） | 399 | 54.6 | 67.9 | 75.7 | 81.7 | 83.2 | 77.6 | 83.2 | 78.3 |
| Haiku 4.5 | Matched retrieval-only | 399 | 16.8 | 34.1 | 51.9 | 68.7 | 74.4 | 59.1 | 77.4 | 123.1 |
| Opus 4.5 | Full VMem 检索列表（有规划，R1+扩展） | 399 | 47.6 | 58.1 | 69.7 | 83.0 | 85.7 | 75.7 | 85.7 | 87.8 |
| Opus 4.5 | 其中 round-1（有规划） | 399 | 47.6 | 58.1 | 69.7 | 82.7 | 85.0 | 75.5 | 85.0 | 84.3 |
| Opus 4.5 | w/o Query Planning 检索列表（只用原问题，R1+扩展） | 399 | 54.6 | 67.9 | 75.7 | 82.0 | 82.7 | 77.6 | 82.7 | 73.7 |
| Opus 4.5 | Matched retrieval-only | 399 | 16.8 | 34.1 | 51.9 | 68.7 | 74.4 | 59.1 | 76.4 | 107.3 |

配对差（有规划 − 无规划，pp，题级 95% CI）：

| Backbone | 分组 | n | Δ B=20 | Δ B=40 | Δ B=80 | Δ B=120 | Δ 端点 | Δ AUC [10,120] |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Haiku 4.5 | 全部 | 399 | -11.8 [-15.5, -7.8] | -8.5 [-12.0, -4.8] | +0.8 [-1.8, +3.3] | +2.3 [-0.3, +4.8] | +3.8 [+1.5, +6.3] | -3.4 [-5.5, -1.5] |
| Haiku 4.5 | Multi-hop | 73 | -1.4 [-9.6, +6.8] | -8.2 [-17.8, +1.4] | +9.6 [-1.4, +19.2] | +12.3 [+2.7, +21.9] | +16.4 [+8.2, +24.7] | +3.5 [-2.6, +9.7] |
| Haiku 4.5 | Single-hop | 219 | -18.3 [-23.7, -13.2] | -11.4 [-16.0, -6.8] | -1.8 [-4.6, +0.9] | -0.5 [-3.2, +2.3] | -0.5 [-3.2, +2.3] | -6.5 [-9.1, -4.0] |
| Haiku 4.5 | 多 gold turn（≥2） | 105 | -1.0 [-7.6, +5.7] | -5.7 [-13.3, +1.9] | +7.6 [+0.0, +15.2] | +9.5 [+2.9, +17.1] | +13.3 [+7.6, +20.0] | +2.6 [-2.0, +7.2] |
| Haiku 4.5 | 跨 session（≥2） | 87 | +1.1 [-6.9, +9.2] | -5.7 [-14.9, +3.4] | +9.2 [+1.1, +18.4] | +10.3 [+2.3, +19.5] | +14.9 [+8.0, +24.1] | +3.6 [-1.8, +9.0] |
| Opus 4.5 | 全部 | 399 | -9.8 [-14.0, -5.8] | -6.0 [-9.5, -2.5] | +1.0 [-1.5, +3.5] | +3.0 [+0.8, +5.3] | +3.0 [+0.8, +5.3] | -1.9 [-3.9, +0.2] |
| Opus 4.5 | Multi-hop | 73 | -2.7 [-12.3, +6.8] | -6.8 [-16.4, +2.7] | +5.5 [-4.1, +15.1] | +9.6 [+2.7, +17.8] | +9.6 [+2.7, +17.8] | +3.1 [-3.9, +9.8] |
| Opus 4.5 | Single-hop | 219 | -16.4 [-21.9, -11.4] | -7.8 [-11.9, -3.7] | -0.5 [-3.2, +2.3] | +0.9 [-1.4, +3.7] | +0.9 [-1.4, +3.7] | -4.7 [-7.0, -2.3] |
| Opus 4.5 | 多 gold turn（≥2） | 105 | -1.0 [-8.6, +6.7] | -1.9 [-10.5, +5.7] | +5.7 [-1.9, +13.3] | +8.6 [+2.9, +14.3] | +8.6 [+2.9, +15.2] | +3.6 [-1.4, +8.7] |
| Opus 4.5 | 跨 session（≥2） | 87 | +0.0 [-9.2, +9.2] | -2.3 [-11.5, +6.9] | +6.9 [-1.2, +16.1] | +10.3 [+3.4, +17.2] | +10.3 [+3.4, +17.2] | +4.5 [-1.3, +10.8] |

**这是本实验最需要如实报告的结果：**
- 在 B ≤ 40 的紧预算下，**不做规划**、只用原问题的多粒度检索覆盖更高，Single-hop 上差距达到 16–18 pp。原因是多条规划 query 经 RRF 融合后，排在最前面的 turn 被分散到各个子需求上，原问题的最佳命中被往后挤。
- 规划的收益在预算充足时才出现，并且集中在 Multi-hop 和跨 session 题（端点 +10 到 +16 pp，CI 不含 0）。
- 两个检索列表都远高于匹配对照。所以 §3 中相对匹配对照、相对 NEMORI 的效率优势，主要来自**原始 turn 级的稠密 + BM25 混合检索**（以及 RRF 和 ±1 上下文窗口），而不是查询规划。
- 限制：只有 400 题；无规划变体同时去掉了自适应预算；它的检索使用 replay 的 query embedding（与原运行 Jaccard ≈ 0.97）。

## 6. 文件与机器可读数据

| 文件 | 内容 |
|---|---|
| `exp7/analyze.py` | 全部计算（审计、曲线、AUC、分组、bootstrap、稳健性）→ `exp7/tables/` 与 `exp7/figdata/` |
| `exp7/make_figure.py` | 作图（只读 figdata） |
| `exp7/build_report.py` + `exp7/report_template.md` | 生成本文 |
| `exp7/figures/rq7_coverage_vs_turn_budget.{pdf,png}` | 图 1（turn 预算，主图） |
| `exp7/figures/rq7_coverage_vs_token_budget.{pdf,png}` | token 预算版本 |
| `exp7/figdata/fig_turn_budget.csv` | 图 1 数据：backbone × strategy × B = 1…160 的 complete / partial / recall、平均暴露 turn、列表未用完比例 |
| `exp7/figdata/fig_token_budget.csv` | token 版数据（B = 50…6000，步长 50） |
| `exp7/tables/budget_curves.csv` | 全部策略 × 两种规则 × 两种计量 × 网格预算 |
| `exp7/tables/auc_thresholds.csv` | AUC 与 80% / 90% 阈值预算 |
| `exp7/tables/breakdown.csv` | 分组曲线 |
| `exp7/tables/contrasts.csv` | 全部配对对比（题级 CI、聚类 CI、留一对话范围） |
| `exp7/tables/per_question.csv` | 逐题：各网格预算下被覆盖的 gold turn 数、端点覆盖与列表长度 |
| `exp7/tables/audit.json` | 分母、一致性检查结果、审计计数 |
| `exp7/tables/report_tables.md` | 本文所有表格 |

## 7. 局限与混杂因素

1. **截短 ≠ 真的用小预算运行。** 本文是已保存检索列表前缀的离线覆盖，不是"小预算系统"的覆盖，更不是准确率。真实系统在小预算下可能触发不同的扩展、生成不同的卡片。
2. **列表长度不同。** 首轮池平均 93 / 85 条 turn（最多约 130），匹配对照 122 / 108（最多约 310），NEMORI 实际 22、展开 79.5。B 超过某方法列表长度后，它的曲线就是平的。B ≥ 80 时首轮池已有约一半的题用完了列表，所以"B = 120 时的差距"部分反映的是匹配对照列表更长。端点比较不是预算对齐的。
3. **粒度不同。** VMem 以单条 turn（窗口）为单位检索，NEMORI 和匹配对照以 episode 为单位。这正是被比较的设计差异，但它让 strict 规则对 episode 级方法更严格。inclusive 规则给出了它们的上界（§5.2），结论不变。
4. **只计原文。** 各方法的 prompt 还包含不计入预算的背景条目：VMem 首轮池有 10 个 episode 摘要 + 20 条 semantic fact，匹配对照有 20 条 semantic，NEMORI 有 10 个摘要 + 20 条 semantic。所以按 turn 或 token 对齐**不等于**按整个 prompt 的 token 对齐。整个 prompt 的 token 对齐见 RQ3 的匹配对照，它是逐题对齐到 Full VMem 的。
5. **同一记忆库，不同排序实现。** 匹配对照与 NEMORI 都是"原问题 → episode"，但用的索引和 embedding 文本不同，两者相差 14 pp（对比 S）。所以 B′（相对 NEMORI 展开）同时包含了"排序实现"和"检索粒度/规划"两种差异。
6. **Haiku 与 Opus 的差异只来自规划器和扩展。** NEMORI 检索与 backbone 无关；匹配对照的排序也相同，只是列表长度按各自 Full VMem 的 prompt token 数决定。首轮池的不同来自规划器生成的 query 和"聚合题"判定：Haiku 更常判为聚合题，池更长。
7. **NEMORI 实际 vs 展开。** "NEMORI 离线展开"是假设性的，**NEMORI 从未把 3–10 名 episode 的原文给作答模型看**。NEMORI 的实际可见证据只有 top-2 episode 的原文。
8. **扩展题的 round-1 边界**由近似 replay 定位（沿用 RQ3）。只看未扩展题时结论不变（§5.2）。
9. **规划的作用不能从本实验的主对照中分离。** 补充分析（§5.4）只有 400 题，而且同时去掉了自适应预算。
10. **gold 标注本身的局限**（遗漏或冗余的 evidence）同 RQ2/RQ6。complete coverage 是"标注的证据全部可见"，不是"回答所需的信息全部可见"。

## 8. 是否作为独立 RQ：建议并入 RQ3（或 RQ2）

- **支持本实验结论的部分：** 在同一 VMem 索引上做预算对齐时，首轮多粒度检索池在 10–120 turn 的每个预算点都比匹配预算纯检索有更高的完整证据覆盖（AUC +14.5 / +15.7 pp）。这个结论在两个 backbone、题级与对话聚类 bootstrap、留一对话、inclusive 规则、token 预算、单元粒度敏感性下都稳定，回应了"VMem 只是给了更多上下文"的质疑。
- **不支持单独成为 RQ 的理由：**
  1. 它与 RQ3 §4.1"匹配预算对照的覆盖率只有 75–77%"、RQ2 §2.3"NEMORI 展开到 79.5 条 turn 也只有 68.8%"是同一个结论，只是从单点换成了曲线。
  2. 规划消融（§5.4）显示，紧预算下的效率主要来自 turn 级混合检索，而非"查询引导"本身；规划在紧预算下反而降低覆盖。所以"query-guided discovery 更高效"这个说法只对"多粒度 turn 路由"成立，对"规划"不成立。作为独立 RQ，标题和主张需要大幅收窄。
  3. 全部是离线前缀覆盖，没有准确率；也没有真实的小预算运行，无法回答"小预算系统表现如何"。
- **建议：** 把图 1 和 §5.1 的对比 A/B 作为 RQ3 §4.1 的"预算对齐证据召回"补充图表，脚注加上 §5.4 的规划结论。在 RQ2 §2.3 关于"上下文量混杂"的讨论中，引用 AUC 和 B = 20 / 40 的配对差。如果论文需要一个关于效率的 RQ，应该在线上真实地用多个 `max_pool_turns`（例如 10 / 20 / 40 / 80）重跑首轮检索并作答。这需要新的推理，不在本实验范围内。

## 9. 复现

```bash
cd /path/to/VMem/develop
source env.sh
$PY exp7/analyze.py                  # ~10 s；只读 runs/、exp2/data/、exp3/runs/、exp3/data/subset_400.json、exp3/tables/coverage.csv
/usr/bin/python3 exp7/make_figure.py # 系统 python（带 matplotlib）
$PY exp7/build_report.py             # 生成 2026-10-12_exp7_budgeted_evidence_recovery.md
```

不需要任何服务（Postgres、Qdrant、embedding、gateway 都不需要）。tiktoken 的 cl100k_base 从本地缓存加载。bootstrap 种子固定为 20261012。
