# VMem-v2.3：方法与 LoCoMo 实验结果（2026-10-11）

> 本文是对 `2026-10-10_vmem_optimization.md`（完整开发日志）的整理版：只保留**最终方法**与**最终结果**。
> 结论：在 Opus 4.5 统一驱动、共享同一份 NEMORI 记忆库的公平设置下，**VMem-v2.3（最终版 v2.3-clean，prompt 已去除与 gold 重合的示例，见 §12）在 LoCoMo 全集上 LLM-judge 准确率 0.9143，比 NEMORI（0.8071）高 +10.7 pp**（95% CI [+8.9, +12.6]），在从未查看过的 holdout 上为 **+11.2 pp**；四个类别全部提升。§4 中是修复前 v2.3 的数字（+10.3 pp），保留作记录。

---

## 1. 实验设置

| 项目 | 取值 |
|---|---|
| 数据 | LoCoMo `locomo10.json`（snap-research/locomo @ `3eb6f2c`），10 段对话，cat 1–4 共 **1540** 题（cat 5 按 NEMORI 惯例跳过） |
| LLM（所有角色） | `bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0`，temperature 0 |
| Judge | 上游 NEMORI/Mem0 `ACCURACY_PROMPT`（原样），Opus 4.5，temperature 0 |
| F1 / BLEU-1 | 上游 `metrics/utils.py` 原样逻辑 |
| Embedding | 本地 `Qwen/Qwen3-Embedding-4B`（2560 维，归一化），所有方法共用 |
| 记忆库 | NEMORI 上游 `add.py` + Opus 4.5 **只构建一次**（agent `locomo_opus45`）：631 episodes / 4523 semantic memories / 5878 条原始消息引用；备份在 `/path/to/vmem_backup/` |
| 代码 | `develop/vmem2/`（`pipeline.py` 中 `Config()` 默认值即锁定的 v2.3 配置） |

### 公平性协议
1. **同一记忆骨架**：NEMORI、原版 VMem、VMem-v2.3 都从同一个 NEMORI store 检索，使用相同的 embedding、LLM 和 judge。三者的差别只在**查询时如何检索和组织证据、如何作答**。
2. **推理时不用任何 gold 信息**：VMem-v2.3 不读 gold 答案，也不读 LoCoMo 的类别标签。（原版 VMem/VERA 按 gold 类别选择配置，这里按其发表时的做法评测。）
3. **Dev / Holdout 按对话切分**：
   - dev = `conv-26, conv-41`（304 题），只在这里做开发和调参；
   - holdout = 其余 8 段对话（1236 题），在 v2.3 配置锁定后**只跑了一次**。
4. **统计检验**：与基线逐题配对，报告 paired bootstrap 95% CI（重采样题目）和 exact McNemar 检验（基于不一致题对）。

---

## 2. 问题诊断：NEMORI 为什么错

用 LoCoMo 的 gold evidence turn id 映射到库中原始消息，检查它们是否进入了作答 prompt。这只用于分析，推理时不使用（`common/diagnose.py`）。

- NEMORI 只有 **68.3%** 的题，全部 gold 证据都出现在检索到的 episode 中；multi-hop（cat1）只有 **31.2%**。
- 原始对话 turn 能被直接看到的只有 **16.2%**，因为 NEMORI 只打印 top-2 episode 的原文。
- 按覆盖情况看 NEMORI 的准确率：证据全覆盖 0.933，部分覆盖 0.611，未覆盖 0.485。

→ 主要瓶颈是**证据覆盖**，不是推理能力。单条 top-k 查询只检索 episode 摘要，无法把散落在多个 session 的事实聚到一起，也会丢掉原文里的精确表述和相对时间表达。

---

## 3. 方法：VMem-v2.3

> 本节是概览；可直接复现的完整细节（公式、伪代码、全部超参数、运行时统计、完整示例、prompt 原文）见 **§13**。

核心思路是保留 VMem“查询时构建、有原文出处”的证据组织方式，但证据来源改成**规划过的、多粒度、包含原始对话层**的广覆盖检索。全流程不使用类别标签。

```
问题 ──► ① LLM 查询规划 ──► ② 多路多粒度检索(RRF) ──► ③ 证据卡片构建(LLM)
                                   ▲                         │
                                   └── ⑤ 动态扩展检索 ◄── 证据不足?
                                                             ▼
                          ⑥ 作答(LLM) ◄── ④ 原文核验 + 时间归一化
                               │
                         弃答? ──► 一次重试
```

1. **LLM 查询规划（planner）**
   输出信息需求、答案类型（实体/日期/列表/计数/…）、`aggregate`/`temporal` 标志，以及 4–6 条多样化检索 query（中间事实子问题、同义改写、关键词 query）。
2. **多路、多粒度检索**（同一个 NEMORI store）
   - 检索粒度有三层：**episode 摘要**、**semantic memory**、**原始对话 turn**（来自 `episodes.source_messages`）。
   - 每层同时做 Dense（Qwen3 向量，top-20）和 BM25（top-12），所有规划 query 的结果用 **RRF**（k=60）融合。
   - 如果某条 semantic memory 命中，就给它的来源 episode 加权（provenance boost）。
   - 每个命中的 turn 带上前后 ±1 turn 的上下文；semantic memory 通过来源 episode 回填时间。
   - 默认规模：10 个 episode + 20 条 semantic + 30 个 turn 命中，turn 池上限 90。
   - **自适应预算**：planner 标记为 aggregate 或答案类型是 list/count 时，turn 命中增至 45，turn 池上限增至 130，扩展轮数增至 2。
3. **证据卡片构建（ViewCards，LLM）**
   每张卡片包含 `{claim, sources, verbatim quote, resolved time, relation}`。LLM 同时判断证据是否充分，并给出缺失信息和后续检索 query。
4. **原文核验 + 确定性时间归一化**
   - 卡片里的 quote 会和它引用的来源做模糊匹配，支持度 ≥ 0.8 记为 verified；未通过的卡片在作答 prompt 中标注 UNVERIFIED。
   - （v2.3）如果 quote 来自原始 turn，且含有 "last/this past <weekday|weekend|week|month>"，代码直接把时间改写为 "the <X> before <session date>"，不让 LLM 自己推算星期几。
5. **动态扩展检索**
   证据不足时，执行 planner/evidence 给出的后续 query（排除已经看过的条目），再回到第 ③ 步。默认 1 轮，aggregate 类问题 2 轮。
6. **作答**
   - 作答输入包括：已核验的卡片、卡片引用的原始 turn（±2 上下文），以及剩余的检索池作为兜底。
   - 输出先给简短推理，最后一行写 `FINAL ANSWER:`，只有这一行作为 response。
   - 规则：时间按统一格式表达；优先给出最匹配的记忆，不要以“无证据”开头；不加问题没问的细节。
   - （v2.3）**弃答重试**：如果答案以 "no evidence / not mentioned / cannot determine" 开头，就带提示再答一次。全集上触发了 19 次（v2.3-clean 最终运行中为 22 次）。

### 版本演进（只在 dev 上开发）
| 版本 | 主要改动 | dev 准确率 |
|---|---|---:|
| v2.1 | 上述 ①②③④⑤⑥ 主框架 | 0.9276 |
| v2.2 | 时间表达约定、answer-first 规则、自适应预算、trait 类问题输出短答案 | 0.9342 |
| **v2.3（锁定）** | 确定性时间归一化 + 弃答重试 | **0.9342** |

v2.3 修好了 4 个针对性的错误（2 个星期几推算错误、2 个错误年份导致的弃答），但同时出现 4 个随机翻转。dev 上运行间噪声约 ±1.3 pp，继续调参只会拟合噪声，所以在 v2.3 锁定配置，然后再跑 holdout。

---

## 4. 主要结果（LLM-judge 准确率）

类别说明：cat1 = multi-hop，cat2 = temporal，cat3 = open-domain，cat4 = single-hop。
Δ、95% CI、W/L（VMem-v2.3 赢 / 输的题数）和 McNemar p 都是**相对 NEMORI** 的逐题配对统计。

### 4.1 Holdout（8 段对话，1236 题，开发中从未查看）
| Cat | n | NEMORI | VMem 原版 | **VMem-v2.3** | Δ vs NEMORI | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 219 | 0.6849 | 0.5753 | **0.8904** | **+20.6 pp** | [+14.2, +26.9] | 51/6 | 6e-10 |
| 2 temporal | 257 | 0.7626 | 0.6615 | **0.8833** | **+12.1 pp** | [+7.0, +17.1] | 39/8 | 6e-6 |
| 3 open-domain | 75 | 0.5867 | 0.5333 | **0.7067** | **+12.0 pp** | [+2.7, +21.3] | 11/2 | 0.022 |
| 4 single-hop | 685 | 0.8701 | 0.8131 | **0.9387** | **+6.9 pp** | [+4.4, +9.3] | 63/16 | 9e-8 |
| **overall** | 1236 | 0.7977 | 0.7225 | **0.9045** | **+10.7 pp** | [+8.5, +12.9] | 164/32 | 1e-22 |

### 4.2 Dev（2 段对话，304 题，用于开发）
| Cat | n | NEMORI | VMem 原版 | **VMem-v2.3** | Δ vs NEMORI | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 63 | 0.7937 | 0.5873 | **0.9048** | +11.1 pp | [+3.2, +20.6] | 8/1 | 0.039 |
| 2 temporal | 64 | 0.8438 | 0.7500 | **0.9531** | +10.9 pp | [+1.6, +20.3] | 9/2 | 0.065 |
| 3 open-domain | 21 | 0.7143 | 0.7619 | **0.7143** | ±0 | [−23.8, +23.8] | 3/3 | 1.0 |
| 4 single-hop | 156 | 0.8846 | 0.8718 | **0.9679** | +8.3 pp | [+3.2, +13.5] | 15/2 | 0.002 |
| **overall** | 304 | 0.8454 | 0.7796 | **0.9342** | **+8.9 pp** | [+4.9, +13.2] | 35/8 | 4e-5 |

### 4.3 LoCoMo 全集（1540 题 = dev + holdout）
| Cat | n | NEMORI | VMem 原版 | **VMem-v2.3** | Δ vs NEMORI | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 282 | 0.7092 | 0.5780 | **0.8936** | **+18.4 pp** | [+13.1, +23.8] | 59/7 | 2e-11 |
| 2 temporal | 321 | 0.7788 | 0.6791 | **0.8972** | **+11.8 pp** | [+7.5, +16.5] | 48/10 | 5e-7 |
| 3 open-domain | 96 | 0.6146 | 0.5833 | **0.7083** | **+9.4 pp** | [+1.0, +17.7] | 14/5 | 0.064 |
| 4 single-hop | 841 | 0.8728 | 0.8240 | **0.9441** | **+7.1 pp** | [+4.9, +9.4] | 78/18 | 4e-10 |
| **overall** | 1540 | 0.8071 | 0.7338 | **0.9104** | **+10.3 pp** | [+8.5, +12.3] | 199/40 | 1e-26 |

**相对原版 VMem（全集）**：总体 +17.7 pp [+15.4, +19.8]，W/L 309/37。分类别：cat1 +31.6，cat2 +21.8，cat3 +12.5，cat4 +12.0 pp。

要点：
- 目标（比 NEMORI 至少 +5 pp）以很大余量达成：全集 CI 下界是 +8.5 pp。
- **holdout 上的提升（+10.7）大于 dev（+8.9）**，没有过拟合 dev 的迹象。
- 提升最大的是 **multi-hop（+18.4）** 和 **temporal（+11.8）**，正好对应第 2 节诊断出的证据覆盖瓶颈。cat3 题量少（96 题），提升方向为正，但全集上没有达到 p<0.05。
- 有 1 行 NEMORI 结果的 key 对不上，所以配对比较实际匹配了 1539/1540 题，对总体准确率的影响 <0.1 pp。

---

## 5. F1 / BLEU-1（上游协议，对原始 response 计算）

| 划分 | Cat | NEMORI F1 | VMem 原版 F1 | **v2.3 F1** | NEMORI BLEU-1 | VMem 原版 BLEU-1 | **v2.3 BLEU-1** |
|---|---|---:|---:|---:|---:|---:|---:|
| 全集 | 1 | 0.0870 | 0.4098 | 0.3845 | 0.0411 | 0.3267 | 0.3043 |
| 全集 | 2 | 0.0741 | 0.0691 | **0.6673** | 0.0276 | 0.0253 | **0.5682** |
| 全集 | 3 | 0.0576 | 0.1127 | **0.2639** | 0.0267 | 0.0652 | **0.2237** |
| 全集 | 4 | 0.1072 | 0.1289 | **0.5495** | 0.0386 | 0.0622 | **0.4551** |
| 全集 | overall | 0.0935 | 0.1669 | **0.5261** | 0.0360 | 0.1031 | **0.4367** |
| holdout | overall | 0.0917 | 0.1575 | **0.5234** | 0.0359 | 0.0949 | **0.4372** |
| dev | overall | 0.1009 | 0.2049 | **0.5368** | 0.0365 | 0.1366 | **0.4346** |

注意：上游 NEMORI 的作答 prompt 要求 "think step by step"，Opus 4.5 会把推理过程写进 response，所以 NEMORI 的 F1/BLEU 被严重拉低。judge 读全文，不受这个影响。v2.3 的 response 只有 `FINAL ANSWER` 这一行，因此 **F1/BLEU 上的差距主要来自输出格式，不能当作能力差距**，主指标以 LLM-judge 为准。原版 VMem 在 cat1 上 F1 偏高，是因为它的短答案格式（含 "Insufficient evidence"）与部分 gold 有词面重合。

---

## 6. 增益来自哪里

### 6.1 证据覆盖率（题目的全部 gold evidence turn 都进入作答上下文的比例；只用于分析）
| Cat | NEMORI：全部证据在检索到的 episode 中 | NEMORI：原始 turn 可见 | **v2.3：全部证据进入上下文** | **v2.3：原始 turn 可见** |
|---|---:|---:|---:|---:|
| 1 | 31.2% | 1.8% | **73.0%** | **68.4%** |
| 2 | 74.7% | 19.7% | **97.5%** | **95.9%** |
| 3 | 38.0% | 8.7% | **67.4%** | **64.1%** |
| 4 | 81.7% | 20.6% | **99.3%** | **98.3%** |
| all | 68.3% | 16.2% | **92.2%** | **90.3%** |

（有效题 1535 题；5 题没有可映射的 gold evidence。）

v2.3 按覆盖情况的准确率：全覆盖 0.922（n=1415），部分覆盖 0.812（n=96），未覆盖 0.583（n=24）。
覆盖率从 68% 提升到 92%，原始 turn 可见率从 16% 提升到 90%，这是主要增益来源。

### 6.2 对照实验 C1：作答 prompt 本身贡献多少？（dev）
用 **NEMORI 自己检索到的上下文**，只把作答 prompt 换成 v2 的（`controls/nemori_newprompt.py`）：

| | NEMORI | C1（NEMORI 上下文 + v2 作答 prompt） | VMem-v2.2 |
|---|---:|---:|---:|
| dev overall | 0.8454 | 0.8553（+1.0 pp） | 0.9342（+8.9 pp） |

→ 作答 prompt 和输出格式只贡献约 1 pp，**绝大部分增益来自检索和证据构建**。

用 v2.3-clean 的干净 prompt 重跑 C1（`runs/c1_cleanprompt_dev/`，2026-10-11，$11.2，约 2 分钟）：

| Cat | n | NEMORI | C1（旧 prompt） | **C1-clean** | Δ vs NEMORI | 95% CI | W/L |
|---|---:|---:|---:|---:|---:|---|---|
| 1 | 63 | 0.7937 | 0.7937 | 0.8254 | +3.2 pp | [−4.8, +11.1] | 4/2 |
| 2 | 64 | 0.8438 | 0.8594 | 0.8438 | +0.0 pp | [−4.7, +4.7] | 1/1 |
| 3 | 21 | 0.7143 | 0.8095 | 0.7619 | +4.8 pp | [+0.0, +14.3] | 1/0 |
| 4 | 156 | 0.8846 | 0.8846 | 0.8846 | +0.0 pp | [−3.8, +3.8] | 5/5 |
| **overall** | 304 | 0.8454 | 0.8553 | **0.8553** | **+1.0 pp** | [−1.6, +4.0] | 11/8（p = 0.65） |

C1-clean 与旧 C1 总体完全相同（0.8553，逐题翻转 4/4）。结论不变：仅换作答 prompt 只带来约 1 pp，且不显著；v2.3-clean 相对 NEMORI 的 +8.9 pp（dev）主要来自检索和证据构建。

---

## 7. 成本

| | NEMORI | VMem-v2.3 |
|---|---:|---:|
| 平均 prompt tokens / 题（全集，含所有 LLM 调用） | 5,186 | 20,461（≈3.9×） |
| LLM 调用 / 题 | 1 | ≈3.1（plan 1 + evidence ≈1.1 + answer 1 + 少量 retry） |
| 实测成本 | – | dev $44.3 + holdout $154.5 = **$198.9**（≈ **$0.13 / 题**，Opus 4.5 list price） |

v2.3 的 token 数是 plan、evidence、answer 和 retry 四类调用之和：(7.17 M + 24.34 M) / 1540 ≈ 20.5k。旧日志里写的“约 23k、4.5×”只是 dev 上的数字（23.6k）。

---

## 8. 复现

```bash
cd /path/to/VMem/develop && source env.sh
# 需要 docker 中的 Postgres(15432) + Qdrant(16333) 和本地 embedding server；记忆库可从 vmem_backup 恢复
PYTHONPATH=$DEV $PY -m vmem2.run --out runs/vmem2_v3_dev/results.json     --conv-ids $DEV_CONVS     --concurrency 14
PYTHONPATH=$DEV $PY -m vmem2.run --out runs/vmem2_v3_holdout/results.json --conv-ids $HOLDOUT_CONVS --concurrency 14
PYTHONPATH=$DEV $PY -m common.evaluate --input runs/vmem2_v3_<split>/results.json --output runs/vmem2_v3_<split>/metrics.json
PYTHONPATH=$DEV $PY -m common.compare runs/nemori_full/metrics.json runs/vmem2_v3_<split>/metrics.json --names nemori vmem2
PYTHONPATH=$DEV $PY -m common.diagnose runs/vmem2_v3_<split>/results.json --method vmem2 --out runs/vmem2_v3_<split>/coverage.json
```

结果文件：
- `runs/vmem2_v3_{dev,holdout}/{results,metrics,usage,config,coverage}.json`
- 基线：`runs/nemori_full/`、`runs/vmem_orig_full/`
- 对照 C1：`runs/c1_newprompt_dev/`（旧 prompt），`runs/c1_cleanprompt_dev/`（干净 prompt）

## 9. 局限与后续
- 只用了一个 judge（Opus 4.5，与作答模型相同）。建议补一个非 Opus 的 cross-judge。
- 每个配置只跑了一次。dev 上运行间噪声约 ±1.3 pp，建议重复跑几次来估计方差。
- 还没做组件消融（planner / 多粒度检索 / ViewCards / 扩展检索 / v2.3 两个补丁）。
- 每题 token 约为 NEMORI 的 3.9 倍。可以考虑更便宜的版本，比如 planner 和 evidence 改用 Sonnet。
- F1/BLEU 的格式差异：可以补一个“只抽取最终答案”的 F1 作为辅助指标。

## 10. 数据泄漏检查（2026-10-11）

起因：VMem-v2.3 比 NEMORI 高 10 个点，老板建议核查是否存在数据泄漏。下面按泄漏可能进入的路径逐项检查。

| # | 检查项 | 方法 | 结论 |
|---|---|---|---|
| 1 | 推理代码是否读到 gold 答案、evidence 或类别 | 读 `vmem2/run.py` 和 `pipeline.py`：`VMem2.answer()` 只接收 `(user_id, question, speakers)`；gold 答案、evidence、category 只在推理完成后写进结果记录，供评测使用 | ✅ 无泄漏 |
| 2 | 记忆库是否混入 QA 或 LoCoMo 人工标注 | NEMORI `add.py` 只读取 `conversation`（`session_N` 和 `session_N_date_time`，包含上游自带的 image caption 和 search query），不读 `qa`、`observation`、`session_summary`、`event_summary`。扫描库内全部 episode、semantic 和 source message 文本：QA 问题原文命中 0 条，session/event summary 命中 0/941；source message 都能对回 LoCoMo 原始对话（少量带 `[Image: …]` 后缀的条目在规范化后有格式差异） | ✅ 无泄漏 |
| 3 | 是否跨对话串库 | 检索只加载 `user_id = <speaker_a>_<conv idx>` 且 `agent_id = locomo_opus45` 的数据；库中共 10 个 user、631 个 episode | ✅ 无泄漏 |
| 4 | holdout 是否被提前使用 | v2.3 锁定前的所有 VMem-v2 运行（`_smoke`、v1、v2、v3_dev、C1）只覆盖 conv idx 0 和 2（即 conv-26 和 conv-41）。holdout 在 07:14 只跑了一次。00:41 为所有对话预先计算过 embedding，但这一步不涉及任何 QA | ✅ 无泄漏 |
| 5 | Judge 是否有漏洞 | 上游 `ACCURACY_PROMPT` 原样使用；cache key 为 `(model, question, gold, answer)`，不同方法之间不会串用判分；所有方法用同一个 judge | ✅ 无泄漏（judge 偏宽松，但对所有方法一视同仁） |
| 6 | **Prompt 示例是否抄了 gold** | 将 prompt 中的示例日期与全部 gold 答案比对 | ⚠️ **发现轻微泄漏，仅影响 dev**，见下文 |
| 7 | Opus 4.5 是否背过 LoCoMo（预训练污染） | 新增闭卷对照 C2（`controls/closed_book.py`）：只给说话人名字和问题，不给任何记忆，作答和 judge 都用 Opus 4.5 | ✅ 未见污染，见下文 |

### 10.1 Prompt 示例与 dev gold 重合（轻微，仅 dev）
`ANSWER_PROMPT` 和 `EVIDENCE_PROMPT` 中讲解时间换算规则时用的例子，取自 dev 对话 conv-26 的真实 session 日期：8 May / 9 June / 15 July 2023。其中 3 个示例串与 **conv-26 中 5 道题的 gold 答案逐字相同**：
- “7 May 2023”：LGBTQ support group
- “the week before 9 June 2023”：speech at school；meet up with friends
- “the Friday before 15 July 2023”：adoption meeting；pottery workshop

影响评估：
- 这 5 题里，NEMORI 本来就答对了 4 题，只有 1 题（LGBTQ support group）是 v2.3 对、NEMORI 错。
- 去掉这 5 题后，dev 上 v2.3 = 0.9331，NEMORI = 0.8462，**Δ = +8.7 pp**（原来是 +8.9 pp）。
- holdout 中没有任何 gold 与 prompt 示例重合（holdout 的对话日期不同），**holdout 的 +10.7 pp 不受影响**。全集上最多影响 1/1540 ≈ 0.06 pp。
- **已修复，并用干净的 prompt 重跑**，见 §12。

另外需要说明，时间表达约定（“the Friday before <date>”）和“题目年份可能写错”的重试提示，是在 dev 的 gold 和错误分析里观察到 LoCoMo 的标注风格后设计的。这属于在 dev 上做的格式适配，不是答案泄漏：holdout 没有参与这一步，而且对照 C1 显示，作答 prompt 整体只贡献约 +1 pp。

### 10.2 闭卷对照 C2：模型本身记得多少答案
`runs/c2_closed_book/`（1540 题，成本 $1.3 + judge）

| Cat | n | 闭卷 C2 | NEMORI | VMem-v2.3 |
|---|---:|---:|---:|---:|
| 1 multi-hop | 282 | 0.1879 | 0.7092 | 0.8936 |
| 2 temporal | 321 | **0.0779** | 0.7788 | 0.8972 |
| 3 open-domain | 96 | 0.4062 | 0.6146 | 0.7083 |
| 4 single-hop | 841 | 0.2556 | 0.8728 | 0.9441 |
| overall | 1540 | 0.2156 | 0.8071 | 0.9104 |

- 需要具体事实的时间题（cat2），闭卷只能答对 7.8%，说明模型没有背下 LoCoMo 的具体内容。
- 闭卷答对的题，人工抽查 25 题，几乎都能从题面或常识猜到，再加上 judge 的宽松判分。例如：“Would Dave prefer a Dodge Charger or a Subaru Forester?” 是二选一题；“What book … inspired …?” 猜 The Alchemist；“Last weekend” 被判为与 “the week before 13 Oct 2022” 一致。cat3 推断题本身多为二选一，所以闭卷能到 40.6%。
- **关键检验：只看闭卷答错的 1197 题**（模型不可能靠记忆或常识答对），v2.3 = 0.8997，NEMORI = 0.7845，**Δ = +11.5 pp**（W/L 171/33），提升并没有缩小。在闭卷答对的 332 题上，Δ = +6.0 pp。说明 VMem-v2.3 的增益来自对记忆的检索和证据组织，不是来自模型的先验知识。

### 10.3 结论
**未发现会影响结论的数据泄漏。** 唯一的问题是 prompt 示例与 5 道 dev 题的 gold 逐字重合，只造成 1 题翻转，holdout 完全不受影响。主结论（holdout +10.7 pp，全集 +10.3 pp）成立。尚未覆盖的风险是 judge 与作答模型同为 Opus 4.5，建议补一个非 Opus 的 cross-judge，见 §9。

## 11. 为什么 NEMORI + Opus 4.5 只有 ~80%（与 GPT-4.1-mini 相当）

本节不重跑任何实验，只分析已有的 `runs/nemori_full/` 结果、`coverage.json` 和记忆库内容。

**1. 记忆构建本身没有问题，信息没有在建库时丢失。**
- 建库过程：0 次 LLM 错误；buffer 已全部清空；segmentation 的超时问题已修复，没有退化成不分段的 episode。
- 原始对话 5882 个 turn 中，有 5878 个作为 source message 存进了 episode（99.9%）。
- 用词面检查 gold 答案：在 gold 答案能在原始 turn 里找到的 973 题中，99.0% 的答案也出现在库内的 episode 摘要或 semantic memory 中。

**2. 瓶颈在于：哪些信息最终进入了作答 prompt。**
NEMORI 的检索方式是对 episode 摘要做单 query 向量 top-10，再加 semantic top-20，原文只展示 top-2 episode。结果只有 68.3% 的题，所有 gold 证据都进了上下文。

| gold 证据进入上下文的情况 | n | NEMORI | VMem-v2.3 |
|---|---:|---:|---:|
| 全部进入 | 1049 | **0.933** | **0.932** |
| 部分进入 | 185 | 0.611 | 0.854 |
| 完全没进入 | 301 | 0.485 | 0.867 |

- **证据都在上下文里时，NEMORI 和 VMem-v2.3 的准确率几乎完全相同（0.933 vs 0.932）。** 说明 Opus 4.5 的作答能力没有被浪费，两个系统的差别只在于把多少证据送进了 prompt。
- NEMORI 答错的 297 题中，有 227 题（76%）的 gold 证据缺失或只有一部分在上下文里。81 题里 Opus 直接回答“未提及 / 无法确定”，其中 70 题恰好是证据完全没进入的。也就是说，信息不在面前时，模型再强也答不上来；Opus 倾向于如实说“没提到”，而不是猜一个答案。
- 检索阶段（向量召回）与作答模型无关，所以把 GPT-4.1-mini 换成 Opus 4.5，上下文覆盖率不变。准确率被这一覆盖率卡在 ~80%，这和 GPT-4.1-mini 的结果接近是一致的。

**3. 证据都在上下文里却仍答错的 70 题（抽查 22 题）**，原因大致有：
- 摘要在建库时把相对时间算错了，例如 “the previous Tuesday (December 12)”，而 gold 是 “Thursday before Dec 17”；
- gold 本身有歧义或噪声；
- Opus 过于较真，例如“这件事是 James 做的，不是 John”；
- 列表题漏项。

这 70 题中，VMem-v2.3 也只答对了 29 题。另外，NEMORI 和 v2.3 都答错的题共有 98 题（6.4%），大致代表标注噪声和难题造成的上限。

**结论**：NEMORI 跑出 ~80% 是正常结果，不是我们的运行出了问题。它的上限由检索和上下文构造决定，与作答模型强弱基本无关。VMem-v2.3 的提升全部来自证据没进上下文的那部分题。

## 12. 修复 prompt 示例与 gold 重合的问题，并重跑（v2.3-clean，2026-10-11）

### 12.1 修改内容（只改 prompt 文案，算法和 `Config` 都不变）
`vmem2/pipeline.py`（修改前的版本备份在 `runs/_pipeline_v2_3_backup.py`）：

| 位置 | 修改前 | 修改后 |
|---|---|---|
| `EVIDENCE_PROMPT` 时间规则 | 7 May 2023 / 8 May 2023 / last year → 2022 | 11 March 2031 / 12 March 2031 / last year → 2030 |
| `ANSWER_PROMPT` 时间规则 | 8 May 2023 → 7 May 2023；“the Friday before 15 July 2023”；“the week before 9 June 2023”；2023 → 2022 | 12 March 2031 → 11 March 2031；“the Friday before 12 March 2031”；“the week before 4 April 2031”；2031 → 2030 |
| `ANSWER_PROMPT` 推断题 | start with "Likely yes"/"Likely no" | start with "Probably yes"/"Probably no"（避免与 gold 写法 “Likely yes/no” 相同） |
| 代码注释 | 25 May 2023 | 12 March 2031 |

所有示例日期都是虚构的，2030/2031 年在 LoCoMo 中不存在。

### 12.2 自动核查：`controls/check_prompt_leak.py`
```bash
PYTHONPATH=$DEV $PY -m controls.check_prompt_leak
```
把全部 prompt（PLAN / EVIDENCE / ANSWER / ABSTAIN_RETRY）与 LoCoMo 10 段对话做四类比对：
1. gold 答案是否原样出现在 prompt 中；
2. prompt 里的日期或年份是否出现在 gold 答案或 session 日期中；
3. prompt 中是否出现说话人姓名；
4. prompt 与任意问题或 gold 答案是否共享 6-gram。

| | 重合处 |
|---|---:|
| 修改前（v2.3） | **569** |
| 修改后（v2.3-clean） | **0** |

仅剩的“通用”匹配不计入：一类是单个 1–2 位数字（来自 “4-6 queries”、“max ~30 words” 这类指令），另一类是 “last year”（它是需要换算的输入时间表达，不是答案）。

### 12.3 重跑
```bash
runs/run_v3clean.sh     # 依次跑 dev、holdout 并评测，输出到 runs/vmem2_v3clean_{dev,holdout}/
```
配置与 v2.3 完全相同，`Config()` 默认值不变；作答、judge 都用 Opus 4.5（Bedrock），concurrency 14。

**Dev（304 题）：已完成，0 错误，$44.3**
| Cat | n | NEMORI | v2.3（旧 prompt） | **v2.3-clean** | Δ vs NEMORI | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 63 | 0.7937 | 0.9048 | **0.8889** | +9.5 pp | [+0.0, +19.1] | 8/2 | 0.11 |
| 2 temporal | 64 | 0.8438 | 0.9531 | **0.9531** | +10.9 pp | [+1.6, +20.3] | 9/2 | 0.065 |
| 3 open-domain | 21 | 0.7143 | 0.7143 | **0.8095** | +9.5 pp | [−9.5, +28.6] | 3/1 | 0.63 |
| 4 single-hop | 156 | 0.8846 | 0.9679 | **0.9615** | +7.7 pp | [+2.6, +13.5] | 15/3 | 0.008 |
| **overall** | 304 | 0.8454 | 0.9342 | **0.9342** | **+8.9 pp** | [+4.9, +13.2] | 35/8 | 4e-5 |

- 新旧 prompt 在 dev 上总体准确率完全相同（0.9342）。逐题看翻转 3/3，在运行间噪声范围内。
- 原来与 prompt 重合的 5 道 conv-26 题，换成干净的 prompt 后 **仍然全部答对**，例如 “The Friday before 15 July 2023”。说明这些题答对靠的是检索到的证据，而不是 prompt 里的示例。

**Holdout（1236 题）：已完成，0 错误，$155.0**。结果见 §12.4。

### 12.4 最终数字（v2.3-clean）
**v2.3-clean 是对外报告的最终版本。** 下面的数字取代 §4 中的 v2.3 数字。
- dev $44.3 + holdout $155.0，共 **$199.3**（≈$0.13/题）；4813 次调用，0 错误。
- 平均 20.5k prompt tokens/题。
- Δ、95% CI、W/L、p 都是相对 NEMORI 的逐题配对统计，计算方法同 §1。

#### Holdout（8 段对话，1236 题）
| Cat | n | NEMORI | VMem 原版 | **v2.3-clean** | Δ vs NEMORI | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 219 | 0.6849 | 0.5753 | **0.8813** | **+19.6 pp** | [+13.7, +26.0] | 51/8 | 9e-9 |
| 2 temporal | 257 | 0.7626 | 0.6615 | **0.9027** | **+14.0 pp** | [+9.3, +19.1] | 41/5 | 4e-8 |
| 3 open-domain | 75 | 0.5867 | 0.5333 | **0.6667** | +8.0 pp | [+0.0, +16.0] | 8/2 | 0.11 |
| 4 single-hop | 685 | 0.8701 | 0.8131 | **0.9474** | **+7.7 pp** | [+5.4, +10.2] | 64/11 | 3e-10 |
| **overall** | 1236 | 0.7977 | 0.7225 | **0.9094** | **+11.2 pp** | [+9.1, +13.3] | 164/26 | 1e-25 |

#### LoCoMo 全集（1540 题 = dev + holdout）
| Cat | n | NEMORI | VMem 原版 | **v2.3-clean** | Δ vs NEMORI | 95% CI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---|---:|
| 1 multi-hop | 282 | 0.7092 | 0.5780 | **0.8830** | **+17.4 pp** | [+12.1, +22.7] | 59/10 | 1e-9 |
| 2 temporal | 321 | 0.7788 | 0.6791 | **0.9128** | **+13.4 pp** | [+9.0, +17.8] | 50/7 | 4e-9 |
| 3 open-domain | 96 | 0.6146 | 0.5833 | **0.6979** | +8.3 pp | [+1.0, +15.6] | 11/3 | 0.057 |
| 4 single-hop | 841 | 0.8728 | 0.8240 | **0.9501** | **+7.7 pp** | [+5.6, +10.0] | 79/14 | 4e-12 |
| **overall** | 1540 | 0.8071 | 0.7338 | **0.9143** | **+10.7 pp** | [+8.9, +12.6] | 199/34 | 1e-29 |

- 相对原版 VMem（全集）：**+18.1 pp** [+15.8, +20.2]，W/L 304/26，p 3e-61。分类别：cat1 +30.5，cat2 +23.4，cat3 +11.5，cat4 +12.6 pp。
- F1 / BLEU-1（全集）：

  | Cat | F1 | BLEU-1 |
  |---|---:|---:|
  | 1 | 0.3812 | 0.3017 |
  | 2 | 0.6761 | 0.5755 |
  | 3 | 0.2761 | 0.2307 |
  | 4 | 0.5552 | 0.4579 |
  | overall | **0.5311** | **0.4396** |

- **与旧 prompt 版 v2.3 对比（全集）**：0.9104 → 0.9143，+0.4 pp [−0.5, +1.3]，W/L 28/22，p = 0.48，没有显著差异。说明去掉与 gold 重合的示例对结果没有影响。之前的结论不依赖那些示例。
- 结论不变：在 holdout 和全集上，比 NEMORI 都高 10 个百分点以上；4 个类别全部为正，其中 cat1/2/4 高度显著，cat3 题量小，处在显著性边缘。

结果文件：`runs/vmem2_v3clean_{dev,holdout}/{results,metrics,usage,config}.json`。

备注：对照 C1 已用干净 prompt 重跑（`runs/c1_cleanprompt_dev/`），dev 上仍为 0.8553（+1.0 pp vs NEMORI），与旧 prompt 结果相同，见 §6.2。


---

## 13. 方法详解（VMem-v2.3-clean，论文写作用）

本节逐步描述最终版本 **VMem-v2.3-clean** 的完整做法。§3 是概览，本节写到可以直接复现的粒度。描述以代码为准（`vmem2/store.py`、`vmem2/pipeline.py`、`vmem2/run.py`，`Config()` 默认值即最终配置）。§13.12 和 §13.13 的统计数字都来自最终运行的 trace（`runs/vmem2_v3clean_{dev,holdout}/results.json`，全集 1540 题）。

### 13.1 问题设定与记号

- 一段长期多 session 对话 $C$，两位说话人。每个 session 有一个会话日期（session date）。
- **记忆库** $\mathcal{M}$ 由 NEMORI 的记忆构建流程离线写入，**只构建一次**，所有方法共用。VMem-v2.3 只读，不写、不重建。它包含三种粒度的条目：
  - **Episode** $e \in \mathcal{E}$：NEMORI 的情节记忆。文本为 `title: content`，带时间戳。
  - **Semantic memory** $s \in \mathcal{S}$：NEMORI 抽取的语义事实，带来源 episode 指针 `source_episode_id`。
  - **原始对话 turn** $u \in \mathcal{U}$：NEMORI 保存在 episode 里的原始消息（`episodes.source_messages`），文本为 `speaker: content`，带消息时间戳和全局顺序号。
- 给定问题 $q$，系统输出一个简短答案 $a$。推理时**不使用**任何 gold 答案、gold evidence 或 LoCoMo 类别标签。
- 整个流程是**查询时（query-time）**的：所有"组织记忆"的工作都针对当前问题现场完成，不对记忆库做任何离线改写。

LoCoMo 10 段对话上的记忆库规模：631 个 episode，4523 条 semantic memory，5878 条去重后的原始 turn。

### 13.2 记忆加载与索引（`store.py`）

**加载**（`load_user_items`）。每段对话（NEMORI 中的一个 user）从 Postgres 读出 episodes 和 semantic_memories，转换成统一的条目 `Item{id, kind, text, ts, episode_id, speaker, order}`：
- **Episode**：`text = "{title}: {content}"`，`ts = created_at`。NEMORI 写入时用的是对话时间，所以这就是事件所在 session 的时间。
- **Turn**：从每个 episode 的 `source_messages` 展开，`text = "{role}: {content}"`，`ts` 取消息自身的 timestamp，`order` 取消息的 `buffer_id`（全局顺序）。同一条消息可能出现在多个 episode 里，按 `(timestamp, role, content)` 去重。每条 turn 记住所属的 episode。
- **Semantic**：`text = content`。**时间重定向**：NEMORI 给 semantic memory 打的是入库时间而不是对话时间，所以这里沿 `source_episode_id` 改用来源 episode 的时间。来源缺失时才退回 `created_at`。

**索引**（`UserIndex`）。每段对话、每种粒度分别建两套索引：
- **Dense**：`Qwen/Qwen3-Embedding-4B`，2560 维，L2 归一化，相似度取内积（即余弦）。条目向量按对话缓存到磁盘，缓存键是条目内容的 hash。查询向量在进程内缓存。
- **Sparse**：BM25Okapi（`rank_bm25`，默认参数 $k_1=1.5$，$b=0.75$）。分词规则：小写，取 `[a-z0-9]+`，再去掉一份英文停用词表。BM25 只返回分数大于 0 的条目。
- **邻接结构**：所有 turn 按 `order` 排成全局序列。`neighbors(u, w)` 返回 $u$ 前后各 $w$ 条 turn，**且只保留与 $u$ 同一天（同一 session）的 turn**，所以上下文不会跨 session。另外维护一张 episode → 所属 turn 的有序列表。

### 13.3 阶段 ①：LLM 查询规划（Planner）

输入是说话人姓名、对话时间跨度（第一条到最后一条 turn 的日期）和问题 $q$。Planner prompt 原文见附录 A.1。输出一个 JSON：

| 字段 | 含义 |
|---|---|
| `need` | 一句话描述信息需求，后面传给证据构建阶段 |
| `answer_type` | `date / duration / count / list / yes_no / entity / description / reason / inference` 之一 |
| `aggregate` | 答案是否可能分散在多个 session |
| `temporal` | 是否需要确定日期、时间或先后顺序 |
| `queries` | 4–6 条短而多样的检索 query：中间事实子问题、贴近口语的改写、关键实体/关键词 query |

- **检索 query 集合** $Q = \{q\} \cup \text{queries}_{1..6}$：原问题本身总是第一条，planner 的 query 最多取 6 条。
- **自适应预算**：判定规则为 `aggregate = plan.aggregate OR answer_type ∈ {list, count}`。判定为 aggregate 的问题使用更大的 turn 预算和更多扩展轮数（见 §13.4、§13.6）。这个判断完全由 LLM 根据问题本身做出，**不读类别标签**。
- **容错**：JSON 解析失败时，退回 `{need: q, queries: []}`，即只用原问题检索。

例子（dev，"When did Melanie run a charity race?"）：
```json
{"need": "Find the date or time period when Melanie participated in a charity race",
 "answer_type": "date", "aggregate": false, "temporal": true,
 "queries": ["Melanie charity race", "Melanie running event for charity", "Melanie participated in race fundraiser",
             "Melanie 5K marathon charity run", "when did Melanie do the charity run", "Melanie race event date"]}
```

### 13.4 阶段 ②：多路、多粒度检索与融合（`VMem2.retrieve`）

**(a) 多路召回。** 对每条 query $q_j \in Q$、每种粒度 $g \in \{\mathcal{E}, \mathcal{S}, \mathcal{U}\}$，各取两条排序列表：Dense top-$20$ 和 BM25 top-$12$。每种粒度因此得到 $2|Q|$ 条排序列表，典型情况是 $2 \times 7 = 14$ 条。

**(b) RRF 融合。** 每种粒度内部，用 Reciprocal Rank Fusion 把所有列表合成一个分数（$k=60$，rank 从 1 开始）：
$$\mathrm{RRF}_g(x) = \sum_{L \in \mathcal{L}_g} \frac{\mathbb{1}[x \in L]}{k + \mathrm{rank}_L(x)}$$
由于每条 query 都贡献列表，**被多条 query 同时命中的条目会累积更高的分数**。多路规划检索正是靠这一点，把分散在不同 session 的事实一起拉进候选池。

**(c) 出处加权（provenance boost）。** semantic memory 和 episode 的命中，会为对应 episode 投票：
$$b(e) = \mathrm{RRF}_{\mathcal{E}}(e) + 0.5 \sum_{s \in \mathcal{S}:\ \mathrm{src}(s)=e} \mathrm{RRF}_{\mathcal{S}}(s), \qquad \mathrm{score}_{\mathcal{E}}(e) \leftarrow \mathrm{RRF}_{\mathcal{E}}(e) + 0.3\, b(e)$$
效果有两点：被 semantic 事实间接支持的 episode 会被提前；本身就命中的 episode 分数相当于乘以 1.3。

**(d) 选取。** 按融合分数取：
- top-10 个 episode，top-20 条 semantic；
- turn：先取 top-$H$ 个 **turn 命中**，普通问题 $H=30$，aggregate 问题 $H=45$。再按命中排名依次把每个命中连同其 **±1 条同 session 邻居**加入 turn 池，去重。turn 池达到上限 $T_{\max}$ 后停止，普通问题 $T_{\max}=90$，aggregate 问题 $T_{\max}=130$。这个检查发生在加完一个命中之后，所以可能超出上限最多 2 条。
- 扩展轮检索时会传入一个排除集合，已在池中的条目不会再次出现。

**(e) 候选池格式化**（`format_pool`）。每个条目获得一个短标签：episode 为 `E1, E2, …`，semantic 为 `S1, …`，turn 为 `T1, …`。标签在整道题的各轮中保持不变，供 LLM 在卡片里引用。展示方式：
- `## Episodes`：按时间排序，每条形如 `[E3] (Thursday, 25 May 2023, 13:56) <title>: <content>`；
- `## Semantic facts`：按时间排序，每条形如 `[S7] (learned in session of Thursday, 25 May 2023) <fact>`；
- `## Conversation turns (grouped by session, chronological)`：按 (时间, 顺序) 排序，每个 session 前插一行 `-- session <date> --`，每条形如 `[T12] Melanie: ...`。

**原始 turn 层是关键。** 它保留了原话里的精确表述，以及 "last Saturday" 这类相对时间表达。NEMORI 原生的作答上下文只展示 top-2 episode 的原文，原始 turn 可见率只有 16%。VMem-v2.3 把可见率提升到 90%（§6.1）。

### 13.5 阶段 ③：证据卡片构建（ViewCards）

输入是问题、planner 给出的 `need`、格式化后的候选池，以及（扩展轮中）上一轮已经建好的卡片列表。prompt 原文见附录 A.2。LLM 的任务明确是**不作答**，只构建以出处为依据的证据卡片：

```json
{"cards": [{"claim": "...", "sources": ["T3"], "quote": "<从来源逐字复制的片段>", "time": "...", "relation": "..."}],
 "sufficient": true, "missing": "...", "follow_up_queries": ["..."]}
```

| 卡片字段 | 规则 |
|---|---|
| `claim` | 与问题相关的、自包含的事实陈述，写出人名 |
| `sources` | 引用的条目标签。**优先引用原始 turn `[T*]`**，没有 turn 时才用 `[E*]/[S*]` |
| `quote` | 必须从来源**逐字复制**的短片段（≤ ~30 词），禁止改写 |
| `time` | 依据来源的 session 日期解析出事件时间。绝对表达（yesterday）→ 日历日期；星期相对表达（last Friday/weekend）→ "the Friday before \<session date\>"，**不要自己推算日历日**；last week → "the week before \<date\>"；last year → 年份；没有相对表达 → session 日期；与时间无关 → 空 |
| `relation` | 这张卡片对问题的作用，例如 answer candidate、intermediate fact: date of Y、supports inference、contradicts card 2 |

其他规则：
- 列表、计数类问题要收集**所有 session 中的全部不同实例**；多跳问题要收集每个中间事实。
- 不得编造。记忆之间冲突时，为双方各建一张卡片，并在 `relation` 中注明。
- 最后判断现有卡片是否足够。不够时给出缺失信息描述和至多 3 条针对缺失事实的后续 query。

LLM 调用的 `max_tokens = 4000`。JSON 解析失败时，本轮视为"无卡片且充分"，流程继续，答案阶段依然能看到完整候选池。

### 13.6 阶段 ⑤：动态扩展检索（与阶段 ③ 交替）

伪代码：
```
R ← 2 if aggregate else 1                    # 最大扩展轮数
pool ← retrieve(Q)                           # §13.4
cards ← []
for r = 0 .. R:
    ev ← EvidenceLLM(q, need, format(new part of pool), previous_cards)
    cards ← cards ∪ ev.cards
    F ← ev.follow_up_queries[:3]
    if ev.sufficient or F = ∅ or r = R: break
    new ← retrieve(F, exclude = pool)        # 用默认（非 aggregate）预算
    new ← (new.E[:6], new.S[:10], new.T[:40])
    if new = ∅: break
    pool ← pool ∪ new
    previous_cards ← cards                   # 在 prompt 中列出，要求"不要重复，只从新记忆中补充"
```
- 扩展轮里，LLM **只看到新检索到的条目**和已有卡片的摘要（claim + 来源标签）。这样避免重复处理旧条目，也控制住 token。
- 最终证据是各轮卡片的并集。最终作答时，候选池是各轮条目的并集。
- 实际触发情况（全集）：第一轮就判定充分的占 91.5%；91 题做了 1 轮扩展，40 题做了 2 轮扩展。

### 13.7 阶段 ④：原文核验与确定性时间归一化

**(a) Quote 核验**（`verify_quote`）。对每张卡片：
1. 把 `sources` 里的标签映射回条目，取这些条目的原文。无法映射的标签直接忽略；一个都映射不到时，支持度记为 0。
2. 规范化：小写，非字母数字字符替换成空格，再合并连续空白。
3. 如果规范化后的 quote 是某个来源的子串，支持度 = 1.0。否则对每个来源用 `difflib.SequenceMatcher` 求所有匹配块的总长度，支持度 = 匹配总长度 / |quote|，取所有来源中的最大值。
4. 支持度 ≥ 0.8 时 `verified = True`。未通过核验的卡片**不删除**，但在作答 prompt 中标记 `(UNVERIFIED)`，并要求谨慎对待。

全集统计：卡片中 99.2% 通过核验，其中 99.0% 是逐字子串命中。这说明"逐字引用 + 引用出处"的约束几乎总能被满足，卡片基本没有幻觉内容。

**(b) 确定性时间归一化**（v2.3 新增，`relative_time`）。LLM 自己推算"上周六是几号"时容易出错，episode 摘要里也常有算错的日历日。因此，卡片满足以下全部条件时，由代码直接改写时间：
- 卡片的某个来源是**原始 turn**；
- quote 规范化后的前 40 个字符出现在这条 turn 中，即 quote 确实来自这条 turn；
- quote 匹配正则 `\b(last|this past|past)\s+(weekend|week|month|mon…|tue…|…|sun…)`。

改写方式：
- `time` 改为 `"the <Saturday|weekend|week|month> before <session date>"`，session date 取这条 turn 的日期，格式为 "25 May 2023"；
- `claim` 中出现的绝对日期（可带星期名，如 "Saturday, 20 May 2023"）替换为 `(the Saturday before 25 May 2023)`。

只处理第一个满足条件的 turn 来源。全集中，符合正则且引用 turn 的卡片有 558 张，分布在 405 道题中。归一化对这些卡片生效（前提是 quote 前缀也匹配）。

### 13.8 阶段 ⑥：作答与弃答重试

**作答上下文**由三部分组成，按信任度从高到低排列（prompt 原文见附录 A.3）：
1. **EVIDENCE CARDS**：所有卡片编号列出，格式为
   ```
   [n] (UNVERIFIED)? claim: <claim> | time: <time>
       source T3,S5: "<quote>"
       role: <relation>
   ```
2. **CITED SOURCE CONTEXT**：卡片引用来源周围的原始对话。来源是 turn 时，取其 ±2 条同 session 邻居；来源是 episode 时，取该 episode 的前 12 条 turn；semantic 来源不展开。按 session 分组、时间排序，并去重。
3. **OTHER RETRIEVED MEMORIES**：剩余的检索池，包括全部 episode、全部 semantic，以及没有出现在第 2 部分的 turn，作为兜底。**卡片不会遮蔽原始记忆**：卡片漏掉的信息，模型仍然能在这里找到。

**作答规则**（prompt 第 1–7 条要点）：
1. 以证据为准，优先使用已核验的卡片和原始 turn，用摘要和语义事实补缺。
2. 统一的时间表达约定，与证据阶段一致。卡片里已经写成 "the X before \<date\>" 的时间要原样使用，因为 episode 摘要可能把日历日算错。
3. 列表、计数类问题跨所有 session 汇总、去重、仔细计数。
4. 偏好、性格、假设类问题给出最合理的推断（yes/no 问题以 "Probably yes/no" 开头），不拒答。特质类问题用几个简短的形容词作答。
5. 先给答案。问题里的细节（如年份、名字）与记忆对不上时，用与问题其余部分最匹配的记忆作答，不要以"没有证据"开头。
6. 只回答所问的内容，不附加多余的事实。
7. 最终答案要简短，最好少于 15 个词。

输出格式：先在 `REASONING:` 下写简短推理（≤ ~120 词），最后一行写 `FINAL ANSWER: <answer>`。取 `FINAL ANSWER:` 之后的第一行作为 response，找不到这个标记时取整段输出的第一行。`max_tokens = 1200`。

**弃答重试**（v2.3 新增）。如果最终答案匹配弃答正则（以 there is no / no evidence|information|record|mention / not mentioned|specified|stated / the memories do not / cannot determine / unknown / insufficient 等开头），就在**同一个 prompt** 后追加一段 NOTE 再答一次（原文见附录 A.4）。NOTE 写明上一次的答案，并提示"问题中的个别细节（如年份、月份、名字）可能有误，请用最匹配的记忆简短作答"。第二次答案非空时替换第一次。全集触发 22 次（占 1.4%），重试后答对 10 次。

### 13.9 完整算法

```
Algorithm VMem-v2.3(q, store M)
 1: plan ← PlannerLLM(q, speakers, span)                       # 1 次 LLM 调用
 2: Q ← [q] + plan.queries[:6]
 3: agg ← plan.aggregate ∨ plan.answer_type ∈ {list, count}
 4: (H, Tmax, R) ← agg ? (45, 130, 2) : (30, 90, 1)
 5: P ← Retrieve(Q; H, Tmax)                                   # dense+BM25 × {E,S,U} × Q → RRF → provenance → ±1 ctx
 6: cards ← EvidenceLoop(q, plan.need, P, R)                   # 1–3 次 LLM 调用 (§13.6)
 7: for c in cards:
 8:     c.support ← VerifyQuote(c.quote, sources(c));  c.verified ← c.support ≥ 0.8
 9:     if c cites a turn u containing c.quote and c.quote has "last <weekday/weekend/week/month>":
10:         c.time ← "the <X> before date(u)";  rewrite absolute date in c.claim
11: ctx ← [cards] + [cited turns ±2 / episode turns ≤12] + [rest of P]
12: a ← AnswerLLM(q, ctx)                                      # 1 次 LLM 调用
13: if Abstains(a): a ← AnswerLLM(q, ctx + NOTE(a))            # 至多 1 次额外调用
14: return a
```
每道题通常 3 次 LLM 调用（plan + evidence + answer），最多 6 次（plan + 3 次 evidence + answer + retry）。

### 13.10 全部超参数（`Config` 默认值 = 最终配置）

| 参数 | 值 | 说明 |
|---|---:|---|
| `rrf_k` | 60 | RRF 常数 |
| `dense_k` / `sparse_k` | 20 / 12 | 每条 query、每种粒度的 dense / BM25 召回数 |
| provenance 系数 | 0.5 / 0.3 | semantic → episode 投票权重 / 加到 episode 分数上的系数（写死在代码中） |
| `pool_episodes` / `pool_semantic` | 10 / 20 | 首轮候选池中 episode / semantic 数量 |
| `pool_turn_hits` / `max_pool_turns` | 30 / 90 | 首轮 turn 命中数 / turn 池上限（普通问题） |
| `agg_turn_hits` / `agg_max_pool_turns` | 45 / 130 | aggregate 问题的 turn 命中数 / turn 池上限 |
| `turn_context` | 1 | 检索阶段每个 turn 命中带 ±1 条同 session 邻居 |
| `expansion_rounds` / `agg_expansion_rounds` | 1 / 2 | 最大扩展轮数 |
| 扩展轮 follow-up query 数 | ≤ 3 | 写死 |
| 扩展轮新增上限 | 6 E / 10 S / 40 T | 写死 |
| planner query 数 | ≤ 6（另加原问题） | 写死 |
| 作答阶段引用上下文 | turn ±2；episode 前 12 条 turn | 写死 |
| quote 核验阈值 | 0.8 | 写死 |
| 时间归一化前缀匹配长度 | 40 字符 | 写死 |
| `evidence_max_tokens` / `answer_max_tokens` | 4000 / 1200 | planner 为 800 |
| `norm_time` / `abstain_retry` | True / True | v2.3 的两个补丁 |
| `plan` / `cards` / `include_pool_in_answer` | True / True / True | 各模块开关，可用于消融 |
| temperature | 0 | 所有 LLM 调用 |

运行时可以用 `python -m vmem2.run --cfg key=value ...` 覆盖任意 `Config` 字段，方便做消融。写死的常数需要改代码。

### 13.11 LLM 调用实现细节

- 所有调用都通过 `litellm.acompletion` 访问 Bedrock 上的 `us.anthropic.claude-opus-4-5-20251101-v1:0`，temperature 0。只发一条 user 消息，**不用 system prompt**。
- "JSON 模式"不是 API 原生功能。做法是让 prompt 要求只返回 JSON，再在客户端剥掉 ``` 代码块和前置说明文字（`strip_json`），解析时容忍 JSON 后面跟着多余文字（`parse_json`）。
- 遇到限流、超时、5xx 时指数退避重试（带随机抖动）。最终运行 0 失败。
- 问题级并发 14。成本按 Opus 4.5 公开价格计算：输入 $5/M tokens，输出 $25/M tokens。

### 13.12 运行时统计（最终运行，全集 1540 题）

| 指标 | 均值 | 中位数 | P10 / P90 | 最大 |
|---|---:|---:|---:|---:|
| planner 判定为 aggregate 的比例 | 33.0% | | | |
| planner 判定为 temporal 的比例 | 37.0% | | | |
| 检索 query 总数（含原问题和扩展轮） | 6.95 | 7 | 6 / 7 | 13 |
| 最终池：episode 数 | 10.7 | 10 | 10 / 10 | 22 |
| 最终池：semantic 数 | 21.1 | 20 | 20 / 20 | 40 |
| 最终池：turn 数 | 88.6 | 78 | 68 / 116 | 199 |
| 证据卡片数 | 6.63 | 5 | 3 / 12 | 40 |
| 作答阶段 cited turn 数 | 22.3 | 14 | 7 / 51 | 146 |
| LLM 调用数 / 题 | 3.13 | 3 | 3 / 3 | 6 |
| prompt tokens / 题 | 20,499 | 19,258 | 15,316 / 26,509 | 57,799 |
| completion tokens / 题 | 1,077 | 915 | 681 / 1,723 | 4,063 |
| 单题延迟（秒，并发 14 下） | 19.4 | 17.0 | 13.8 / 28.9 | 64.0 |
| 最终答案长度（词） | 12.2 | 10 | 2 / 26 | 52 |

卡片层面的统计：
- 来源类型：引用 turn 7153 次，semantic 2538 次，episode 1864 次。62% 的引用指向原始 turn，与"优先引用原话"的指令一致。
- 94% 的卡片带有 `time` 字段，688 张卡片的时间是 "the X before \<date\>" 形式。
- 只有 1 道题没有产生任何卡片。

### 13.13 按 planner 判定切片的准确率（分析用）

| 切片 | n | LLM-judge 准确率 |
|---|---:|---:|
| aggregate = True | 508 | 0.8917 |
| aggregate = False | 1032 | 0.9254 |
| 第一轮即充分（rounds = 1） | 1409 | 0.9333 |
| 扩展 1 轮（rounds = 2） | 91 | 0.7033 |
| 扩展 2 轮（rounds = 3） | 40 | 0.7250 |
| 触发弃答重试 | 22 | 0.4545 |

| answer_type | n | 准确率 |
|---|---:|---:|
| entity | 472 | 0.9280 |
| description | 350 | 0.9257 |
| date | 266 | 0.9323 |
| list | 233 | 0.8841 |
| reason | 78 | 0.9744 |
| inference | 43 | 0.8140 |
| duration | 37 | 0.8378 |
| count | 31 | 0.7419 |
| yes_no | 30 | 0.9000 |

注意：扩展轮的准确率低是**选择效应**。触发扩展的本来就是证据难找的题，这不说明扩展有害；要回答扩展是否有用，需要做消融（`--cfg expansion_rounds=0 agg_expansion_rounds=0`）。计数（count）和列表（list）类仍是主要短板。

### 13.14 完整示例（holdout，cat1 多跳/计数）

**问题**："How many times has Jolene been to France?"　**Gold**：two times　**VMem-v2.3**：At least twice (in 2010 and around January 2022) ✅

1. **Planner**：`answer_type=count`，`aggregate=true`，所以走 aggregate 预算（45 个 turn 命中、130 条 turn 上限、最多 2 轮扩展）。规划的 query：
   "Jolene trip to France"、"Jolene visited France"、"Jolene traveling to France vacation"、"Jolene went to Paris French holiday"、"how many times Jolene been to France"、"Jolene France travel plans"。
2. **第 1 轮证据**：找到两条线索，即 2010 年在巴黎收到的吊坠，以及 "I bought it a year ago in Paris."。但判定 `sufficient=false`，理由是"不清楚这两件事是不是两次不同的旅行，可能还有别的访问"。后续 query 为 "Jolene Paris trip travel"、"Jolene France vacation visit"、"Jolene Europe travel"。
3. **第 2、3 轮扩展**：追加检索，把 semantic 记忆 "Jolene bought the video game 'Walking Dead' in Paris" 和原始 turn "This pendant reminds me of my mother, she gave it to me in 2010 in Paris." 拉进来。最终池为 22 E / 40 S / 181 T，共 13 条 query。
4. **卡片（节选，全部 support = 1.0）**：
   - `[T134]` "This pendant reminds me of my mother, she gave it to me in 2010 in Paris."，time = 2010，relation = answer candidate
   - `[T11]` "I bought it a year ago in Paris."，time ≈ January 2022，relation = answer candidate
   - `[E20]` "...she had purchased the game a year ago in Paris (around January 2022)."，relation = confirms a visit to Paris/France
   - `[S33]` "Jolene received her pendant from her mother in Paris in 2010"，relation = confirms a separate visit
5. **作答**：模型合并这些卡片，得出两次不同的访问（2010 年和约 2022 年），答案为 "At least twice (in 2010 and around January 2022)"。

这两条事实分布在不同 session 中，一条只出现在原始 turn 里，另一条只出现在 semantic memory 里。单条 top-k episode 检索（NEMORI 的做法）很难同时拿到两者。

### 13.15 与 NEMORI、原版 VMem 的区别

| | NEMORI（基线） | 原版 VMem / VERA | **VMem-v2.3-clean** |
|---|---|---|---|
| 记忆库 | NEMORI store | 同一个 NEMORI store | 同一个 NEMORI store（只读） |
| 检索 query | 原问题 1 条 | 原问题 1 条 | 原问题 + LLM 规划的 4–6 条，外加最多 3 × 2 条扩展 query |
| 检索方式 | dense top-k | 单 query 检索（沿用其发表实现） | dense + BM25，RRF 融合，provenance boost |
| 检索粒度 | episode + semantic | episode + semantic（6 + 10） | episode + semantic + **原始 turn**（10 + 20 + 约 90） |
| 原文可见 | 只有 top-2 episode 的原文 | — | 原始 turn 作为一等检索对象，带 ±1/±2 上下文 |
| 证据组织 | 无，直接作答 | 查询时构建 ViewCards | 查询时构建 ViewCards：逐字 quote + 出处 + 解析后的时间 + 作用，并做**原文核验** |
| 迭代检索 | 无 | 无 | LLM 判断充分性，后续 query 动态扩展 1–2 轮 |
| 时间处理 | 交给 LLM | 交给 LLM | 统一时间表达约定 + 代码确定性归一化星期相对表达 |
| 类别标签 | 不用 | **按 gold 类别选择配置** | 不用，aggregate 预算由 planner 判定 |
| 平均 prompt tokens / 题 | 5,186 | — | 20,461（约 3.9×） |
| LoCoMo 全集 LLM-judge | 0.8071 | 0.7338 | **0.9143** |

### 13.16 写论文时的几点提示

- **可以强调的贡献**：
  1. 证据覆盖率是长期记忆问答的主要瓶颈（§2、§6.1）；
  2. 查询规划 + 多粒度（含原始 turn）+ 混合检索 + RRF，大幅提升覆盖率（68% → 92%）；
  3. 逐字引用 + 出处 + 自动核验的证据卡片，99% 可核验；
  4. 充分性驱动的动态扩展；
  5. 把时间推算交给确定性代码而不是 LLM；
  6. 完全不用类别标签，在留出集上验证。
- **对照 C1**（§6.2）表明，只换作答 prompt 只带来约 +1 pp，所以增益主要来自检索和证据构建，可以用来反驳"只是 prompt 写得好"的质疑。
- **闭卷对照 C2**（§10.2）和 prompt 泄漏核查（§12）可以写进附录，说明没有数据泄漏。
- **还没有的实验**（审稿人可能会问，见 §9）：逐模块消融（`plan` / `cards` / 原始 turn 层 / BM25 / 扩展 / `norm_time` / `abstain_retry`）、非 Opus 的交叉 judge、多次运行的方差、更便宜的模型配置。现在不要声称各模块的单独贡献。
- **局限**：每题 token 约为 NEMORI 的 3.9 倍；依赖 NEMORI 构建好的记忆库（但方法本身只要求有 episode/semantic/原始消息三层，可以迁移到其他记忆系统）；judge 与作答模型相同。

### 13.17 代码索引

| 组件 | 位置 |
|---|---|
| 记忆加载、时间重定向、turn 去重 | `vmem2/store.py` `load_user_items` |
| Dense / BM25 / 同 session 邻居 | `vmem2/store.py` `UserIndex.dense / sparse / neighbors` |
| 超参数 | `vmem2/pipeline.py` `Config` |
| 四个 prompt | `vmem2/pipeline.py` `PLAN_PROMPT / EVIDENCE_PROMPT / ANSWER_PROMPT / ABSTAIN_RETRY` |
| RRF + provenance + turn 上下文 | `vmem2/pipeline.py` `rrf_fuse`、`VMem2.retrieve` |
| 候选池格式化与标签 | `vmem2/pipeline.py` `format_pool`、`assign_labels` |
| 主流程（规划 → 检索 → 证据循环 → 核验 → 时间归一化 → 作答 → 重试） | `vmem2/pipeline.py` `VMem2.answer` |
| quote 核验 / 时间归一化 / 弃答检测 | `vmem2/pipeline.py` `verify_quote`、`relative_time`、`_REL_RE`、`_ABSTAIN_RE` |
| LLM 调用、JSON 解析、重试、计价 | `common/bedrock_llm.py` |
| 批量运行入口 | `vmem2/run.py` |

### 附录 A：完整 prompt 原文（v2.3-clean）

花括号 `{...}` 是运行时填入的占位符。

#### A.1 PLAN_PROMPT
```text
You are the query planner of a long-term conversational memory system.
The memory stores a long multi-session conversation between {speakers}. Sessions span {span}.

Question: {question}

Analyse what information is needed to answer the question and plan retrieval. Think about:
- which person(s), objects, events and attributes the question is about (resolve "he/she/they" to names when obvious),
- whether the answer needs several facts combined (multi-hop), facts aggregated over many sessions (lists, counts, "what activities/places/books..."), a date or time computation, or an inference about someone's preferences, personality or likely behaviour,
- which intermediate facts must be found first (e.g. to answer "What did X do after Y?" first find when Y happened).

Return ONLY a JSON object:
{
  "need": "<one sentence describing the information need>",
  "answer_type": "<one of: date, duration, count, list, yes_no, entity, description, reason, inference>",
  "aggregate": <true if the answer may be spread over multiple sessions, else false>,
  "temporal": <true if a date/time/order must be determined, else false>,
  "queries": ["<4-6 short, diverse search queries: sub-questions for intermediate facts, paraphrases with likely conversational wording, and key entity/keyword queries>"]
}
```

#### A.2 EVIDENCE_PROMPT
`{previous}` 在首轮为空。扩展轮中它是：`Evidence cards already constructed in the previous round (do not repeat them; add only new facts from the NEW memories above):` 加上已有卡片的列表（`- <claim> [<sources>]`）。
```text
You are the evidence constructor of a long-term conversational memory system.
Your job is NOT to answer the question but to build compact, source-grounded evidence cards that make the facts needed to answer it explicit.

Question: {question}
Information need: {need}

Candidate memories retrieved from the memory store (each has an ID; [E*] episode summaries, [S*] semantic facts, [T*] raw conversation turns with their session date):
{pool}
{previous}
Instructions:
1. Find every memory relevant to the question. For list/count/"what activities" questions collect ALL distinct instances across sessions; for multi-hop questions collect each intermediate fact.
2. For each relevant fact write a card. Prefer raw turns [T*] as sources because they are the original words; use [E*]/[S*] when no turn is available.
3. "quote" must be copied VERBATIM from the cited source (a short span, max ~30 words) — never paraphrase inside "quote".
4. "time": when the fact happened, resolved against the session date of the source: "yesterday" -> "11 March 2031" (absolute date); "last Friday"/"last weekend" -> "the Friday/weekend before 12 March 2031" (keep weekday-relative expressions relative to the session date, do not compute the calendar day); "last week" -> "the week before 12 March 2031"; "last year" -> "2030"; no relative expression -> the session date. Use "" if not time-relevant.
5. "relation": in a few words, how this card bears on the question (e.g. "answer candidate", "intermediate fact: date of Y", "supports inference: likes outdoors", "contradicts card 2").
6. Do not invent facts. If the memories conflict, make cards for both and note it in "relation".
7. Then judge whether the cards suffice. If key information is missing, give up to 3 follow-up search queries aimed precisely at the missing facts.

Return ONLY a JSON object:
{
  "cards": [{"claim": "<fact relevant to the question, self-contained, with names>", "sources": ["T3"], "quote": "<verbatim span>", "time": "<absolute time or empty>", "relation": "<role>"}],
  "sufficient": <true/false>,
  "missing": "<what is still missing, or empty>",
  "follow_up_queries": ["..."]
}
```

#### A.3 ANSWER_PROMPT
```text
You are an intelligent memory assistant answering questions about a long-term conversation between {speakers}, using evidence retrieved from memory.

# QUESTION
{question}

# EVIDENCE CARDS (constructed for this question; each claim is grounded in a verbatim quote from the cited source; cards marked UNVERIFIED could not be matched to their source and must be treated with caution)
{cards}

# CITED SOURCE CONTEXT (original conversation turns around the cited evidence, with session dates)
{sources}

# OTHER RETRIEVED MEMORIES (background; use them if the cards miss something)
{pool}

# INSTRUCTIONS
1. Base the answer on the evidence. Prefer verified cards and original turns; use episode summaries and semantic facts to fill gaps.
2. Time. Dates shown are session dates (the day the conversation took place). Express event times the way people resolve them against the session date:
   - "yesterday", "today", "this morning", "two days ago" -> the absolute calendar date (e.g. said on 12 March 2031 "yesterday" -> 11 March 2031);
   - "last Friday", "last Sunday", "on the weekend" (a weekday-relative expression) -> "the Friday before 12 March 2031" (relative to the session date; do NOT convert it into a calendar day yourself);
   - "last week", "last month", "a few days ago" -> "the week before 4 April 2031", "the month before ..." , "a few days before ...";
   - "last year", "next month" -> the year / month (e.g. said in 2031 "last year" -> 2030).
   If the event is reported without a relative expression, its time is the session date itself.
   When a card's time is of the form "the <weekday/week/weekend> before <date>", that is the resolved time: give it in exactly that form (episode summaries may contain mis-computed calendar days).
3. Lists / "what activities", "what books", "how many": aggregate ALL distinct items found across all sessions; count carefully and de-duplicate.
4. Questions about likely preferences, personality, opinions or hypotheticals ("Would X ...", "What might X ...", "Is X likely ..."): give the most plausible answer inferred from the evidence (start with "Probably yes"/"Probably no" for yes/no questions) rather than refusing. For questions about someone's traits or attributes, answer with a few short descriptive traits.
5. Always give the answer first. If the question's details (e.g. a date or name) do not exactly match the memories, answer with the memory that best matches the rest of the question — do not start with "there is no evidence".
6. Answer exactly what is asked; do not add extra facts, dates or explanations that are not asked for.
7. The final answer must be short and direct: a phrase, name, date, list or short sentence (ideally under 15 words).

First think briefly step by step (max ~120 words) under "REASONING:", then give the answer on the last line exactly as:
FINAL ANSWER: <answer>
```

#### A.4 ABSTAIN_RETRY（重试时追加在 ANSWER_PROMPT 之后）
```text
# NOTE
Your previous final answer was: "{prev}". A question usually refers to something that is in the conversation even when a detail in it (e.g. the year, month or a name) may be slightly wrong. Do not abstain: answer with the memory that best matches the question, as a short direct answer.
```

---

## 14. 换 backbone 实验（Claude Haiku 4.5，2026-10-11）
详见 `2026-10-11_backbone_haiku45.md`。记忆库和 judge（Opus 4.5）都不变，查询阶段的 LLM 全部换成 Haiku 4.5，VMem 配置零改动：
- 全集：VMem-v2.3-clean 0.8961，NEMORI 0.7649，高 **+13.1 pp**，95% CI [+11.2, +15.1]，W/L 233/31；holdout 上高 +13.3 pp。4 个类别全部显著。
- 从 Opus 换到 Haiku，NEMORI 掉 4.2 pp，VMem 只掉 1.8 pp。VMem-Haiku 比 NEMORI-Opus 高 +8.9 pp，推理成本相当。
