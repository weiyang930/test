# Exp8 / RQ8：答案层面的证据锚定与忠实性（Answer-Level Groundedness and Faithfulness）

日期：2026-10-12　范围：LoCoMo 分层抽样 240 题（Opus 4.5 答案）+ 其中 68 题（Haiku 4.5 答案）　方法：VMem-v2.3-clean、NEMORI、SimpleMem、MemR³　代码与数据：`develop/exp8/`

> **研究问题**：为每个问题构建专门的证据集，除了提高答案准确率之外，能否让最终答案更有原文依据、更忠实？
> **性质**：只审计**已有的最终答案**，不重跑检索、建库、ViewCard 或答案生成，也不改动任何已有的预测或评测文件。唯一新增的 LLM 调用是 Opus 4.5 judge（temperature 0），全部有缓存。
> **重要声明**：本文的"锚定（grounded）"指答案中的事实主张能在 LoCoMo 原始对话中找到依据，与答案是否正确是两回事。所有锚定标签都来自 LLM judge，存在判定误差（§7）。

## 0. 结论速览

下文数字为加权估计，主比较用 Opus 4.5 的答案（n = 240 题 × 4 方法）。

1. **答案层面，VMem 的完全锚定率明显高于 NEMORI 和 MemR³，与 SimpleMem 相当或略低。**
   - 完全锚定：VMem 77.7%，NEMORI 62.2%，SimpleMem 82.3%，MemR³ 66.4%。
   - 配对差（VMem − 基线，题级 bootstrap 95% CI）：对 NEMORI **+15.5** [+7.2, +24.2]，对 MemR³ **+11.3** [+2.7, +20.1]，对 SimpleMem −4.7 [−10.5, +0.3]（不显著）。按对话聚类的 bootstrap 和留一对话检验结论相同。
   - "正确且完全锚定"：VMem 73.2%，对 NEMORI **+17.7** pp，对 MemR³ **+14.3** pp，对 SimpleMem −0.4 pp（持平）。
2. **优势主要来自"少说错的辅助事实"，而不是每条主张更可靠。**
   - 只看最终答案本身（core 主张）时，VMem 对 NEMORI 和 MemR³ 只剩 +2.7 / +3.5 pp，CI 跨 0。
   - 主张级支持率四个方法没有可分辨的差别（89.6–93.3%）。
   - NEMORI 和 MemR³ 每个答案平均有 4.9 / 5.8 条主张，VMem 只有 2.7 条。它们多出来的解释性内容里常有写错的日期和归属，含矛盾内容的答案占 14.3% / 17.7%，VMem 为 4.6%。
3. **对 SimpleMem 的结果是中性偏负。** SimpleMem 的答案最短（2.4 条主张），完全锚定率最高。只看答对的题时，VMem 的完全锚定率比它低 7.6 pp（显著）。不过 SimpleMem 的弃答率是 5.8%，其中 4.5% 的情况证据包里其实有答案；而且人工复核发现 judge 对 VMem 的开放域推断判得偏严（§6），所以这个差距应视为上界。
4. **VMem 几乎不弃答（0.7%），但没有借此"编"答案。** 它答错的题里仍有 54% 完全锚定，多为答得不全，或 gold 列表本身不全。
5. **Haiku 4.5（68 题，仅作方向参考）：** 对 NEMORI 完全锚定 **+20.4** [+8.4, +34.5]，显著；对 SimpleMem、MemR³ 的点估计分别为 +14.5 / +22.9 pp，但题级 CI 跨 0。
6. **论文定位：可以作为有保留的次要结论，不建议作为独立 RQ。** 合适的表述是："VMem 的准确率提升不是靠无依据的猜测：答案的锚定率与最好的基线相当，并且明显少于冗长基线中的错误辅助事实。"**不能**声称"证据集让每条主张更忠实"。

![](exp8/figures/rq8_groundedness_by_method.png)

**图 A**：答案层面的锚定标签分布（Opus 4.5 答案，加权）。(a) 计入全部主张，包括解释部分；(b) 只看 core 主张，即最终答案本身。斜线 = 弃答或没有可核查的主张。

![](exp8/figures/rq8_correctness_x_groundedness.png)

**图 B**：正确性 × 锚定的联合分布（Opus 4.5 答案，加权）。"Incorrect, not fully grounded / abstain"合并了答错且未完全锚定、答错且弃答两类。

---

## 1. 评测设计与抽样

### 1.1 抽样

- **总体**：1535 道有有效 gold turn 的题（排除第 5 类 adversarial，与已有评测一致）。
- **分层**：类别（Multi-hop / Temporal / Open-domain / Single-hop）× gold 证据条数（1 turn / 2+ turns）× 错误标记（四个方法在 Opus 上是否至少有一个答错）。N < 8 的格子并入同类别、同错误标记的多 turn 格子（表中带 * 的层）。
- **分配**：n_h ∝ √N_h × 1.8（错误层）× 1.7（Multi-hop），每格至少 min(N_h, 6)，不超过 N_h，最大余数取整。格内用种子 20261012 做无放回简单随机抽样。
- **Haiku 子样本**：每层取已抽样题中（按种子打乱后的顺序）前 ⌈n_h/4⌉ 题，共 68 题。原计划约 120 题，为控制成本缩减。
- **估计**：报告加权估计（设计权重 1/π，比率估计）；括号中给出未加权值。错误层和 Multi-hop 被过采样，所以未加权数字会偏低，不代表总体。

| Stratum (category / gold evidence / error flag) | N (population) | n (Opus sample) | n (Haiku subset) | π (Opus) |
|---|---:|---:|---:|---:|
| Multi-hop / 2+ turns* / allcorrect | 130 | 22 | 6 | 0.169 |
| Multi-hop / 2+ turns* / err | 152 | 38 | 10 | 0.250 |
| Open-domain / 1 turn / allcorrect | 22 | 9 | 3 | 0.409 |
| Open-domain / 1 turn / err | 20 | 12 | 3 | 0.600 |
| Open-domain / 2+ turns / allcorrect | 21 | 9 | 3 | 0.429 |
| Open-domain / 2+ turns / err | 29 | 13 | 4 | 0.448 |
| Single-hop / 1 turn / allcorrect | 590 | 27 | 7 | 0.046 |
| Single-hop / 1 turn / err | 205 | 29 | 8 | 0.141 |
| Single-hop / 2+ turns / allcorrect | 30 | 10 | 3 | 0.333 |
| Single-hop / 2+ turns / err | 16 | 11 | 3 | 0.688 |
| Temporal / 1 turn / allcorrect | 189 | 17 | 5 | 0.090 |
| Temporal / 1 turn / err | 91 | 21 | 6 | 0.231 |
| Temporal / 2+ turns / allcorrect | 17 | 9 | 3 | 0.529 |
| Temporal / 2+ turns / err | 23 | 13 | 4 | 0.565 |
| **Total** | **1535** | **240** | **68** | |

### 1.2 被评测的答案

四个方法的已有最终答案和已有的 Opus 4.5 正确性标签，与 Exp1 主表完全相同。正确性标签只在分析阶段使用，judge 看不到。

## 2. 共享原文证据包（source pack）

证据包**只从 LoCoMo 原始对话中确定性地抽取**，从不使用任何方法的记忆、检索结果或 ViewCard。同一道题的四个方法使用**同一个**证据包。

构造规则（`exp8/build_packs.py`）：
1. gold 支持 turn，加上同一 session 内前后各 2 个 turn；
2. 以问题为 query，在全对话上做 BM25（rank_bm25 Okapi）检索，取 top-8 turn；
3. 以答案为 query 做 BM25 检索：8 个最终答案（4 方法 × Opus/Haiku）各取 top-4。这一步用到了答案，但取的是所有方法答案的并集，任何方法都不会因此拿到更有利的证据；
4. 每个 BM25 命中的 turn 附带它前一个 turn，用来补全被回复的上下文；
5. 按 1 > 2 > 3 的优先级合并，答案检索部分在不同答案之间轮流取，总数上限 70 个 turn；每个 turn 带 dia_id、说话人和所在 session 的日期。

- 每个 pack 平均 35.7 个原始 turn（中位数 34，最少 15，最多 70；6 个 pack 触顶 70），覆盖平均 10.7 个 session。
- 来源构成（turn 数，全部 pack 合计）：bm25_context 3189，bm25_answer 1836，bm25_question 1547，gold_neighbour 1507，gold 491。
- 全部 gold turn 都在 pack 中（240/240）。

证据包和每个 turn 的 source ID 保存在 `exp8/data/packs/*.json`。

## 3. 判定方法

### 3.1 Judge 输入与盲评

- **模型**：Claude Opus 4.5（Bedrock `us.anthropic.claude-opus-4-5-20251101-v1:0`），temperature 0。
- **输入**：问题、**一个**方法的最终答案（原样）、共享证据包。
- **不给**：方法名、正确性标签、gold 答案、ViewCard 或任何方法自己的检索记录。每次调用相互独立，调用顺序随机。

### 3.2 输出与标签

judge 先把答案拆成实质性的事实主张，每条主张标出：
- 是否为 core 主张（属于最终答案本身，而非解释部分）；
- 标签：SUPPORTED / CONTRADICTED / UNSUPPORTED / UNVERIFIABLE / WORLD_KNOWLEDGE（常识类主张，不核查）；
- 引用的 source ID；
- 失败类型：时间错误、实体归属错误、无依据的聚合、编造细节、其他。

judge 还会标出弃答和"没有可核查主张"的答案。**证据包里找不到的主张要标 UNVERIFIABLE，不能直接判为无依据。**

### 3.3 第二轮检索（确定性）

第一轮判为 UNSUPPORTED 或 UNVERIFIABLE 的每条主张，都用主张文本作为 query，在**全对话**上做 BM25 检索（top-5）。只要返回证据包外的新 turn，就把新 turn（各带前一个 turn）加入证据包，对这条主张重判，并以第二轮的标签为准。确定性的抽取步骤与 LLM 判定始终分开进行。

- pass 1 共 4002 条主张；其中 UNSUPPORTED/UNVERIFIABLE 553 条进入第二轮检索；449 条在全对话 BM25 top-5 中找到 pack 外的新 turn 并被重判（449 条成功重判）。
- 重判前→后标签转移：UNSUPPORTED→SUPPORTED 168；UNSUPPORTED→UNSUPPORTED 115；UNVERIFIABLE→SUPPORTED 77；UNSUPPORTED→CONTRADICTED 35；UNVERIFIABLE→UNSUPPORTED 23；UNVERIFIABLE→UNVERIFIABLE 16；UNSUPPORTED→UNVERIFIABLE 8；UNVERIFIABLE→CONTRADICTED 7。
- 由主张标签确定性推出的答案标签，与 judge 自己给出的 answer_label 一致率：796/960 = 82.9%（不一致主要来自第二轮重判改变了主张标签，以及 judge 对 core/support 的整体权衡）。

第二轮有大量 UNSUPPORTED → SUPPORTED 的改判，说明**只依赖 gold 附近的证据包会系统性低估锚定率**；也说明 LoCoMo 的 gold 标注确实不完整。

### 3.4 答案层面标签（由主张标签确定性推出）

| 标签 | 规则 |
|---|---|
| 弃答 / 无主张 | 弃答，或除 WORLD_KNOWLEDGE 外没有可核查的主张，单独报告 |
| Contradicted | 任一主张为 CONTRADICTED |
| Fully grounded | 所有可核查主张都是 SUPPORTED |
| Partially grounded | 有 core 主张为 SUPPORTED，其余不是 |
| Unsupported | 没有 core 主张为 SUPPORTED，且至少一条 core 主张为 UNSUPPORTED |
| Unverifiable | 其他情况（core 主张都是 UNVERIFIABLE） |

"只看 core 主张"的变体对 core 主张套用同样的规则。judge 自己给出的整体 answer_label 只用来做一致性检查。主张级的比率（支持率等）分母**不含**弃答和无主张的答案，并且一律同时报告主张条数，避免冗长答案被不公平地惩罚，也避免空答案或极短答案拿到虚高的锚定分。

### 3.5 稳定性与 smoke test

先在前 10 题 × 4 方法上跑 smoke test，检查判定后修订过一次 rubric。之后的全量运行没有再修改 rubric。

- 随机抽 40 个（题, 方法）答案，把 pack 内 session 块顺序随机打乱后重判（只比 pass 1）：judge answer_label 一致 35/40，由主张推出的答案标签一致 35/40，主张条数一致 29/40。

### 3.6 统计方法

- 加权估计使用设计权重 1/π。
- 配对差的 95% CI：在抽样层内重抽样的题级配对 bootstrap（2000 次）。
- 稳健性：按对话的聚类 bootstrap（2000 次），以及留一对话（LOCO）的估计范围。
- 表中加粗的 Δ 表示题级 CI 不含 0。

## 4. 主要结果（Opus 4.5 答案）

### 4.1 各方法总览

240 题 × 4 方法 = 960 个答案；格式为 加权估计（未加权）；parse error 0，pass-2 error 0。

| Metric | VMem (ours) | NEMORI | SimpleMem | MemR³ | n (VMem / NEMORI / SimpleMem / MemR³) |
|---|---:|---:|---:|---:|---|
| Correct (Opus judge, existing label) | 91.1 (82.1) | 79.6 (65.8) | 81.8 (67.5) | 81.6 (69.6) | 240 / 240 / 240 / 240 |
| Fully grounded | 77.7 (68.3) | 62.2 (52.1) | 82.3 (70.4) | 66.4 (55.8) | 240 / 240 / 240 / 240 |
| Fully + partially | 90.2 (84.6) | 75.1 (65.0) | 89.7 (80.8) | 75.5 (68.8) | 240 / 240 / 240 / 240 |
| Unsupported or contradicted (answer) | 8.0 (11.2) | 17.6 (21.7) | 4.0 (6.7) | 20.0 (23.3) | 240 / 240 / 240 / 240 |
| Contradicted (answer) | 4.6 (6.2) | 14.3 (17.5) | 2.4 (3.3) | 17.7 (20.0) | 240 / 240 / 240 / 240 |
| Fully grounded (core claims only) | 79.3 (69.2) | 76.7 (67.1) | 82.3 (70.4) | 75.8 (67.5) | 240 / 240 / 240 / 240 |
| Correct AND fully grounded | 73.2 (59.2) | 55.4 (41.2) | 73.6 (55.8) | 58.9 (43.8) | 240 / 240 / 240 / 240 |
| Abstain / no claim | 0.7 (1.7) | 7.1 (12.9) | 5.8 (11.2) | 4.3 (7.5) | 240 / 240 / 240 / 240 |
| Abstention although pack has the info | 0.0 (0.0) | 4.5 (7.5) | 4.5 (8.3) | 1.9 (2.9) | 240 / 240 / 240 / 240 |
| Fully grounded | has claims | 78.2 (69.5) | 67.0 (59.8) | 87.4 (79.3) | 69.4 (60.4) | 236 / 209 / 213 / 222 |
| Fully grounded | correct | 80.4 (72.1) | 70.1 (63.9) | 90.0 (82.7) | 73.6 (65.2) | 197 / 155 / 162 / 161 |
| Supported claim rate | 89.6 (85.5) | 91.2 (88.8) | 93.3 (89.0) | 92.5 (90.5) | 236 / 209 / 213 / 222 |
| Unsupported+contradicted claim rate | 9.3 (12.2) | 8.4 (10.6) | 5.9 (9.5) | 7.4 (9.1) | 236 / 209 / 213 / 222 |
| Contradicted claim rate | 2.5 (3.7) | 4.5 (5.4) | 1.8 (2.7) | 4.3 (4.8) | 236 / 209 / 213 / 222 |
| Unverifiable claim rate | 1.1 (2.3) | 0.4 (0.5) | 0.8 (1.5) | 0.1 (0.3) | 236 / 209 / 213 / 222 |
| Claims / answer | 2.73 (3.03) | 4.90 (5.36) | 2.38 (2.71) | 5.75 (5.98) | 236 / 209 / 213 / 222 |

### 4.2 与 VMem 的配对差

| Metric | vs | Δ (VMem − baseline), weighted | 95% CI question bootstrap | 95% CI conversation cluster bootstrap | LOCO range | n pairs |
|---|---|---:|---|---|---|---:|
| Fully grounded | NEMORI | **+15.5** | [+7.2, +24.2] | [+6.9, +22.3] | [+13.5, +17.3] | 240 |
| Fully grounded | SimpleMem | -4.7 | [-10.5, +0.3] | [-10.1, +0.3] | [-6.3, -2.8] | 240 |
| Fully grounded | MemR³ | **+11.3** | [+2.7, +20.1] | [+5.9, +17.2] | [+9.7, +13.0] | 240 |
| Fully + partially | NEMORI | **+15.1** | [+9.1, +21.4] | [+9.8, +18.8] | [+14.0, +16.6] | 240 |
| Fully + partially | SimpleMem | +0.5 | [-3.6, +4.1] | [-3.6, +4.4] | [-0.9, +1.9] | 240 |
| Fully + partially | MemR³ | **+14.6** | [+7.3, +22.1] | [+9.5, +19.5] | [+12.9, +16.3] | 240 |
| Unsupported or contradicted (answer) | NEMORI | **-9.6** | [-15.9, -4.2] | [-14.0, -4.1] | [-10.9, -8.1] | 240 |
| Unsupported or contradicted (answer) | SimpleMem | **+4.0** | [+0.4, +8.0] | [+0.5, +7.7] | [+2.9, +5.2] | 240 |
| Unsupported or contradicted (answer) | MemR³ | **-12.0** | [-19.9, -4.7] | [-18.0, -5.9] | [-13.4, -9.4] | 240 |
| Fully grounded (core claims only) | NEMORI | +2.7 | [-4.6, +10.1] | [-3.5, +7.4] | [+0.5, +4.4] | 240 |
| Fully grounded (core claims only) | SimpleMem | -3.0 | [-7.9, +1.3] | [-8.3, +1.7] | [-4.4, -1.0] | 240 |
| Fully grounded (core claims only) | MemR³ | +3.5 | [-4.7, +12.0] | [-1.2, +9.5] | [+1.7, +4.9] | 240 |
| Correct AND fully grounded | NEMORI | **+17.7** | [+9.3, +26.6] | [+9.9, +24.0] | [+15.8, +20.2] | 240 |
| Correct AND fully grounded | SimpleMem | -0.4 | [-6.2, +4.5] | [-4.9, +4.3] | [-2.0, +0.8] | 240 |
| Correct AND fully grounded | MemR³ | **+14.3** | [+5.8, +23.2] | [+7.2, +22.3] | [+11.9, +16.7] | 240 |
| Fully grounded | correct | NEMORI | **+14.1** | [+4.3, +24.7] | [+3.6, +22.0] | [+12.1, +16.9] | 146 |
| Fully grounded | correct | SimpleMem | **-7.6** | [-13.9, -2.3] | [-13.2, -2.0] | [-9.2, -5.9] | 155 |
| Fully grounded | correct | MemR³ | +9.6 | [-0.8, +20.1] | [+2.0, +17.5] | [+7.6, +12.2] | 150 |
| Supported claim rate | NEMORI | -0.2 | [-4.8, +4.0] | [-4.5, +3.7] | [-1.3, +1.2] | 209 |
| Supported claim rate | SimpleMem | -2.7 | [-6.8, +0.6] | [-6.4, +0.8] | [-3.5, -1.4] | 212 |
| Supported claim rate | MemR³ | -2.3 | [-6.7, +1.5] | [-6.5, +1.9] | [-3.8, -0.6] | 221 |
| Unsupported+contradicted claim rate | NEMORI | -0.0 | [-4.2, +4.5] | [-3.9, +4.2] | [-1.5, +1.0] | 209 |
| Unsupported+contradicted claim rate | SimpleMem | +2.6 | [-0.7, +6.7] | [-0.8, +6.2] | [+1.4, +3.4] | 212 |
| Unsupported+contradicted claim rate | MemR³ | +1.5 | [-2.3, +5.9] | [-3.2, +6.1] | [-0.4, +3.3] | 221 |
| Claims / answer | NEMORI | **-2.15** | [-2.49, -1.79] | [-2.50, -1.79] | [-2.22, -2.05] | 209 |
| Claims / answer | SimpleMem | **+0.34** | [+0.20, +0.50] | [+0.21, +0.51] | [+0.26, +0.37] | 212 |
| Claims / answer | MemR³ | **-3.01** | [-3.33, -2.68] | [-3.40, -2.62] | [-3.16, -2.86] | 221 |
| Abstain / no claim | NEMORI | **-6.5** | [-9.0, -4.1] | [-9.0, -3.7] | [-7.3, -5.8] | 240 |
| Abstain / no claim | SimpleMem | **-5.2** | [-7.5, -3.0] | [-7.6, -3.2] | [-5.7, -4.4] | 240 |
| Abstain / no claim | MemR³ | **-3.7** | [-6.1, -1.6] | [-6.7, -1.6] | [-4.3, -2.8] | 240 |

### 4.3 答案层面标签分布（图 A 数据）

**全部主张（含解释部分）**

| Method | Fully grounded | Partially grounded | Unverifiable | Unsupported | Contradicted | Abstain / no claim | n |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 77.7 | 12.5 | 1.2 | 3.4 | 4.6 | 0.7 | 240 |
| NEMORI | 62.2 | 12.9 | 0.2 | 3.3 | 14.3 | 7.1 | 240 |
| SimpleMem | 82.3 | 7.4 | 0.5 | 1.6 | 2.4 | 5.8 | 240 |
| MemR³ | 66.4 | 9.2 | 0.1 | 2.3 | 17.7 | 4.3 | 240 |

**仅 core 主张（只看最终答案本身）**

| Method | Fully grounded | Partially grounded | Unverifiable | Unsupported | Contradicted | Abstain / no claim | n |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 79.3 | 11.1 | 1.2 | 3.4 | 4.4 | 0.7 | 240 |
| NEMORI | 76.7 | 4.6 | 0.2 | 3.6 | 7.9 | 7.1 | 240 |
| SimpleMem | 82.3 | 7.4 | 0.5 | 1.6 | 2.4 | 5.8 | 240 |
| MemR³ | 75.8 | 9.6 | 0.1 | 2.8 | 7.3 | 4.3 | 240 |

### 4.4 主张层面分析

- **主张级支持率没有差别。** VMem 89.6%，NEMORI 91.2%，SimpleMem 93.3%，MemR³ 92.5%，配对差的 CI 都跨 0。
- **主张条数差别很大。** NEMORI 和 MemR³ 的答案里有大量解释性主张（日期推算、背景复述），每个答案多 2–3 条主张。
- 这两点合起来就是 §0 第 2 条：在答案层面，只要有一条主张写错，整道题就不再是"完全锚定"。冗长的基线因此吃亏。这是真实存在的忠实性问题（它们确实写了与原文矛盾的内容），但它和"VMem 的每条主张更准确"是两回事。

失败类型分布（只统计非 SUPPORTED 的主张）：

| Method | non-supported claims | temporal | entity_attribution | unsupported_aggregation | invented_detail | other | world-knowledge claims (not checked) |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 91 | 18 (20%) | 14 (15%) | 4 (4%) | 45 (49%) | 10 (11%) | 7 |
| NEMORI | 122 | 39 (32%) | 23 (19%) | 5 (4%) | 41 (34%) | 14 (11%) | 14 |
| SimpleMem | 55 | 16 (29%) | 5 (9%) | 1 (2%) | 28 (51%) | 5 (9%) | 1 |
| MemR³ | 124 | 44 (35%) | 19 (15%) | 10 (8%) | 39 (31%) | 12 (10%) | 22 |

未加权；只计非弃答答案中的 UNSUPPORTED / CONTRADICTED / UNVERIFIABLE 主张。

| Method | claims (checkable) | supported | unverifiable | unsupported | contradicted | core claims | answers with claims |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 716 | 625 | 18 | 57 | 16 | 673 | 236 |
| NEMORI | 1120 | 998 | 6 | 58 | 58 | 459 | 209 |
| SimpleMem | 578 | 523 | 8 | 39 | 8 | 549 | 213 |
| MemR³ | 1328 | 1204 | 5 | 59 | 60 | 681 | 222 |

NEMORI 和 MemR³ 的非支持主张里，时间错误占 32–35%，VMem 为 20%；VMem 和 SimpleMem 的非支持主张中"编造细节"占比较高（约一半），但绝对数量少。

### 4.5 正确性 × 锚定（图 B 数据）

| Method | Correct & fully grounded | Correct & not fully grounded | Correct & abstain/no claim | Incorrect & fully grounded | Incorrect & not fully grounded | Incorrect & abstain/no claim | Fully grounded among correct | Fully grounded among incorrect |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 73.2 | 17.9 | 0.0 | 4.5 | 3.8 | 0.7 | 80.4 (n=197) | 54.2 (n=39) |
| NEMORI | 55.4 | 23.7 | 0.5 | 6.8 | 7.0 | 6.6 | 70.1 (n=155) | 49.3 (n=54) |
| SimpleMem | 73.6 | 8.2 | 0.0 | 8.7 | 3.7 | 5.8 | 90.0 (n=162) | 70.3 (n=51) |
| MemR³ | 58.9 | 21.1 | 1.6 | 7.5 | 8.1 | 2.7 | 73.6 (n=161) | 48.0 (n=61) |

未加权原始计数（题数）：

| Method | Correct: Fully / Partial / Unverif. / Unsup. / Contra. / NoClaim | Incorrect: Fully / Partial / Unverif. / Unsup. / Contra. / NoClaim |
|---|---|---|
| VMem (ours) | 142 / 32 / 5 / 8 / 10 / 0 | 22 / 7 / 1 / 4 / 5 / 4 |
| NEMORI | 99 / 23 / 1 / 9 / 23 / 3 | 26 / 8 / 0 / 1 / 19 / 28 |
| SimpleMem | 134 / 17 / 3 / 3 / 5 / 0 | 35 / 8 / 0 / 5 / 3 / 27 |
| MemR³ | 105 / 23 / 0 / 4 / 29 / 6 | 29 / 8 / 1 / 4 / 19 / 12 |

- **只看答对的题时**，VMem 的完全锚定率比 NEMORI 高 +14.1 pp（显著），比 MemR³ 高 +9.6 pp（题级 CI 刚好跨 0，聚类 CI 不跨 0），比 SimpleMem 低 −7.6 pp（显著）。所以 VMem 对 NEMORI 和 MemR³ 的锚定优势不只是因为它答对得更多。
- **答错但完全锚定**的答案在所有方法里都存在（4.5–8.7%）。人工复核（§6）显示，这些基本都是答得不全、答非所问，或者 gold 列表本身漏项，不是捏造。这说明**正确性和锚定确实是两个独立的维度**。

### 4.6 敏感性分析

| Subset | Metric | vs | Δ | 95% CI question bootstrap | 95% CI cluster bootstrap | n |
|---|---|---|---:|---|---|---:|
| all | Fully grounded | NEMORI | **+15.5** | [+7.1, +24.6] | [+7.1, +22.3] | 240 |
| all | Fully grounded | SimpleMem | -4.7 | [-10.4, +0.4] | [-10.7, +0.0] | 240 |
| all | Fully grounded | MemR³ | **+11.3** | [+2.3, +20.1] | [+5.8, +17.0] | 240 |
| all | Fully grounded, UNVERIFIABLE counted as neutral | NEMORI | **+17.6** | [+9.1, +26.8] | [+9.1, +24.6] | 240 |
| all | Fully grounded, UNVERIFIABLE counted as neutral | SimpleMem | -3.1 | [-8.9, +2.1] | [-9.3, +2.3] | 240 |
| all | Fully grounded, UNVERIFIABLE counted as neutral | MemR³ | **+13.8** | [+4.9, +23.0] | [+7.6, +20.9] | 240 |
| all | Fully grounded (core claims only) | NEMORI | +2.7 | [-4.2, +9.5] | [-3.5, +7.2] | 240 |
| all | Fully grounded (core claims only) | SimpleMem | -3.0 | [-8.2, +1.5] | [-8.6, +1.5] | 240 |
| all | Fully grounded (core claims only) | MemR³ | +3.5 | [-4.7, +11.4] | [-1.4, +9.2] | 240 |
| excluding Open-domain | Fully grounded | NEMORI | **+15.4** | [+7.3, +24.8] | [+6.5, +22.8] | 197 |
| excluding Open-domain | Fully grounded | SimpleMem | -4.9 | [-10.8, +0.5] | [-11.5, +1.1] | 197 |
| excluding Open-domain | Fully grounded | MemR³ | **+11.0** | [+2.4, +20.3] | [+4.6, +18.1] | 197 |
| excluding Open-domain | Fully grounded, UNVERIFIABLE counted as neutral | NEMORI | **+16.8** | [+8.6, +26.2] | [+7.9, +24.2] | 197 |
| excluding Open-domain | Fully grounded, UNVERIFIABLE counted as neutral | SimpleMem | -3.6 | [-9.5, +1.8] | [-9.9, +2.6] | 197 |
| excluding Open-domain | Fully grounded, UNVERIFIABLE counted as neutral | MemR³ | **+12.8** | [+4.0, +22.0] | [+6.2, +20.4] | 197 |
| excluding Open-domain | Fully grounded (core claims only) | NEMORI | +2.8 | [-4.5, +10.8] | [-3.7, +7.5] | 197 |
| excluding Open-domain | Fully grounded (core claims only) | SimpleMem | -3.1 | [-8.2, +1.5] | [-9.5, +2.3] | 197 |
| excluding Open-domain | Fully grounded (core claims only) | MemR³ | +3.6 | [-4.8, +12.3] | [-2.5, +10.4] | 197 |

把 UNVERIFIABLE 算作中性、去掉 Open-domain 类别，结论都不变。

### 4.7 分类别与分证据复杂度

| Group | n | Metric | VMem (ours) | NEMORI | SimpleMem | MemR³ | Δ vs NEMORI [95% CI] | Δ vs SimpleMem [95% CI] | Δ vs MemR³ [95% CI] |
|---|---:|---|---:|---:|---:|---:|---|---|---|
| Multi-hop | 60 | Fully grounded | 68.2 | 54.9 | 83.7 | 60.5 | +13.3 [-2.2, +29.5] | **-15.5** [-27.4, -4.9] | +7.6 [-7.8, +24.4] |
| Multi-hop | 60 | Fully + partially | 91.5 | 68.2 | 94.3 | 70.4 | **+23.2** [+12.0, +35.1] | -2.8 [-8.5, +2.8] | **+21.1** [+9.9, +33.8] |
| Multi-hop | 60 | Supported claim rate | 89.1 | 90.6 | 96.4 | 92.3 | -0.4 [-6.2, +5.3] | **-5.4** [-10.9, -0.5] | -1.7 [-7.0, +3.5] |
| Temporal | 60 | Fully grounded | 81.7 | 60.4 | 81.4 | 67.0 | **+21.3** [+4.8, +38.0] | +0.3 [-10.5, +10.0] | **+14.7** [+4.8, +26.8] |
| Temporal | 60 | Fully + partially | 92.3 | 69.0 | 85.5 | 76.8 | **+23.3** [+10.3, +37.4] | +6.8 [-0.3, +14.1] | **+15.5** [+5.6, +27.0] |
| Temporal | 60 | Supported claim rate | 88.5 | 89.5 | 87.7 | 89.8 | +1.1 [-6.2, +7.9] | +2.1 [-5.6, +9.2] | -0.6 [-6.8, +6.8] |
| Open-domain | 43 | Fully grounded | 50.5 | 34.0 | 50.9 | 34.8 | **+16.6** [+2.0, +32.6] | -0.4 [-19.0, +18.5] | +15.7 [-3.0, +36.4] |
| Open-domain | 43 | Fully + partially | 69.9 | 47.9 | 67.8 | 63.3 | **+22.0** [+7.5, +37.1] | +2.1 [-12.1, +16.2] | +6.6 [-10.2, +24.1] |
| Open-domain | 43 | Supported claim rate | 80.5 | 86.2 | 85.0 | 85.6 | -3.5 [-10.2, +3.1] | -3.1 [-12.5, +5.9] | -5.9 [-15.2, +3.5] |
| Single-hop | 77 | Fully grounded | 82.3 | 68.5 | 85.6 | 71.5 | **+13.8** [+0.5, +27.1] | -3.3 [-11.6, +3.8] | +10.7 [-3.9, +25.8] |
| Single-hop | 77 | Fully + partially | 91.2 | 82.7 | 92.1 | 78.1 | **+8.4** [+0.4, +17.6] | -0.9 [-8.1, +4.5] | **+13.1** [+1.1, +24.8] |
| Single-hop | 77 | Supported claim rate | 91.1 | 92.4 | 95.2 | 94.3 | -0.4 [-7.6, +5.7] | -3.6 [-10.5, +0.9] | -2.8 [-10.5, +3.0] |
| 1 turn | 116 | Fully grounded | 81.3 | 65.1 | 83.8 | 69.1 | **+16.2** [+5.7, +27.5] | -2.5 [-10.0, +3.5] | **+12.3** [+1.4, +23.8] |
| 1 turn | 116 | Fully + partially | 90.6 | 78.8 | 89.8 | 77.0 | **+11.8** [+4.5, +19.9] | +0.8 [-4.8, +5.7] | **+13.6** [+4.5, +23.4] |
| 1 turn | 116 | Supported claim rate | 90.2 | 91.6 | 93.0 | 92.8 | -0.1 [-6.2, +5.1] | -2.0 [-7.6, +2.1] | -2.2 [-8.2, +2.9] |
| multi-turn, 1 session | 36 | Fully grounded | 75.6 | 69.4 | 77.5 | 63.3 | +6.1 [-6.9, +20.2] | -1.9 [-12.7, +9.0] | +12.3 [-5.2, +30.7] |
| multi-turn, 1 session | 36 | Fully + partially | 91.4 | 81.9 | 87.8 | 76.0 | +9.5 [-1.8, +22.4] | +3.6 [-6.4, +13.3] | **+15.4** [+0.7, +31.3] |
| multi-turn, 1 session | 36 | Supported claim rate | 89.7 | 94.2 | 94.2 | 93.3 | -4.3 [-10.3, +1.3] | -2.4 [-8.6, +3.8] | -2.5 [-9.3, +4.2] |
| multi-turn, 2+ sessions | 88 | Fully grounded | 65.7 | 50.6 | 78.4 | 58.0 | **+15.1** [+0.7, +29.3] | **-12.7** [-23.7, -2.7] | +7.7 [-6.7, +21.8] |
| multi-turn, 2+ sessions | 88 | Fully + partially | 88.4 | 61.0 | 89.7 | 70.5 | **+27.4** [+17.2, +38.2] | -1.4 [-6.9, +3.5] | **+17.9** [+7.8, +28.4] |
| multi-turn, 2+ sessions | 88 | Supported claim rate | 87.6 | 88.9 | 94.4 | 91.4 | +0.1 [-5.3, +5.5] | **-5.1** [-10.5, -0.6] | -2.8 [-8.0, +2.0] |
| error strata (some method wrong) | 137 | Fully grounded | 58.7 | 44.9 | 58.0 | 50.6 | **+13.9** [+2.3, +26.2] | +0.7 [-8.4, +10.2] | +8.1 [-2.6, +19.4] |
| error strata (some method wrong) | 137 | Fully + partially | 78.9 | 58.5 | 72.2 | 61.8 | **+20.5** [+9.6, +31.4] | +6.8 [-1.7, +14.9] | **+17.1** [+8.4, +26.6] |
| error strata (some method wrong) | 137 | Supported claim rate | 80.9 | 86.5 | 83.7 | 90.4 | -3.3 [-9.7, +3.1] | -1.0 [-8.1, +5.7] | **-8.6** [-13.9, -2.8] |
| all-correct strata | 103 | Fully grounded | 87.8 | 71.5 | 95.4 | 74.8 | **+16.3** [+5.6, +27.6] | **-7.5** [-14.8, -1.6] | **+13.0** [+1.1, +25.3] |
| all-correct strata | 103 | Fully + partially | 96.2 | 84.1 | 99.1 | 82.9 | **+12.2** [+5.4, +20.1] | -2.9 [-7.7, +0.0] | **+13.3** [+3.8, +23.5] |
| all-correct strata | 103 | Supported claim rate | 94.2 | 93.1 | 97.6 | 93.5 | +1.0 [-4.5, +5.7] | **-3.5** [-8.6, -0.0] | +0.6 [-5.2, +5.4] |

- **Temporal**：VMem 对 NEMORI、MemR³ 的完全锚定优势最大（+21.3 / +14.7 pp），与基线时间错误多一致。
- **Multi-hop 和跨 session 题**：VMem 的"完全 + 部分锚定"远高于 NEMORI 和 MemR³（+23 到 +27 pp），但**完全锚定率显著低于 SimpleMem**（−15.5 / −12.7 pp）。VMem 在多源题上会写出更多聚合性的陈述，其中一部分得不到逐条支持。
- **各分组样本量为 36–116 题**，CI 较宽，只作为补充。

## 5. Haiku 4.5 答案（68 题子样本）

Haiku 子样本只有 68 题，分组只有 16–38 题，**结果仅作方向参考**。

68 题 × 4 方法 = 272 个答案；格式为 加权估计（未加权）；parse error 0，pass-2 error 0。

| Metric | VMem (ours) | NEMORI | SimpleMem | MemR³ | n (VMem / NEMORI / SimpleMem / MemR³) |
|---|---:|---:|---:|---:|---|
| Correct (Opus judge, existing label) | 88.5 (80.9) | 69.6 (57.4) | 83.5 (70.6) | 83.6 (76.5) | 68 / 68 / 68 / 68 |
| Fully grounded | 74.4 (63.2) | 54.0 (39.7) | 59.9 (52.9) | 51.4 (48.5) | 68 / 68 / 68 / 68 |
| Fully + partially | 82.4 (76.5) | 65.8 (50.0) | 77.4 (64.7) | 76.2 (64.7) | 68 / 68 / 68 / 68 |
| Unsupported or contradicted (answer) | 13.2 (11.8) | 21.9 (26.5) | 12.8 (14.7) | 17.0 (22.1) | 68 / 68 / 68 / 68 |
| Contradicted (answer) | 4.7 (5.9) | 14.6 (20.6) | 12.1 (11.8) | 15.6 (19.1) | 68 / 68 / 68 / 68 |
| Fully grounded (core claims only) | 74.4 (63.2) | 67.7 (57.4) | 60.9 (54.4) | 62.7 (60.3) | 68 / 68 / 68 / 68 |
| Correct AND fully grounded | 74.0 (61.8) | 44.2 (33.8) | 56.2 (48.5) | 47.7 (44.1) | 68 / 68 / 68 / 68 |
| Abstain / no claim | 3.6 (8.8) | 12.3 (23.5) | 9.3 (19.1) | 6.8 (13.2) | 68 / 68 / 68 / 68 |
| Abstention although pack has the info | 1.0 (1.5) | 10.6 (17.6) | 7.6 (13.2) | 3.1 (4.4) | 68 / 68 / 68 / 68 |
| Fully grounded | has claims | 77.2 (69.4) | 61.5 (51.9) | 66.1 (65.5) | 55.2 (55.9) | 62 / 52 / 55 / 59 |
| Fully grounded | correct | 84.0 (77.8) | 65.5 (62.2) | 67.3 (68.8) | 59.3 (63.8) | 54 / 37 / 48 / 47 |
| Supported claim rate | 85.5 (84.3) | 89.8 (86.3) | 84.7 (82.6) | 92.1 (90.6) | 62 / 52 / 55 / 59 |
| Unsupported+contradicted claim rate | 14.1 (14.3) | 10.1 (13.4) | 14.7 (15.6) | 7.9 (9.4) | 62 / 52 / 55 / 59 |
| Contradicted claim rate | 3.1 (3.5) | 3.9 (6.3) | 6.4 (6.1) | 3.0 (4.9) | 62 / 52 / 55 / 59 |
| Unverifiable claim rate | 0.4 (1.3) | 0.2 (0.3) | 0.5 (1.8) | 0.0 (0.0) | 62 / 52 / 55 / 59 |
| Claims / answer | 2.95 (3.31) | 4.73 (5.29) | 2.63 (2.76) | 6.13 (6.12) | 62 / 52 / 55 / 59 |

| Metric | vs | Δ (VMem − baseline), weighted | 95% CI question bootstrap | 95% CI conversation cluster bootstrap | LOCO range | n pairs |
|---|---|---:|---|---|---|---:|
| Fully grounded | NEMORI | **+20.4** | [+8.4, +34.5] | [+11.5, +28.1] | [+17.3, +22.9] | 68 |
| Fully grounded | SimpleMem | +14.5 | [-8.0, +36.1] | [+3.3, +28.6] | [+9.9, +17.3] | 68 |
| Fully grounded | MemR³ | +22.9 | [-0.8, +44.3] | [+9.3, +39.1] | [+19.3, +27.7] | 68 |
| Fully + partially | NEMORI | **+16.6** | [+8.8, +23.9] | [+10.6, +23.8] | [+14.8, +18.7] | 68 |
| Fully + partially | SimpleMem | +5.0 | [-12.8, +23.1] | [-8.3, +18.7] | [+0.8, +11.8] | 68 |
| Fully + partially | MemR³ | +6.1 | [-10.0, +22.4] | [+0.2, +13.3] | [+4.3, +8.1] | 68 |
| Unsupported or contradicted (answer) | NEMORI | **-8.7** | [-15.7, -1.3] | [-17.4, -2.0] | [-10.8, -6.6] | 68 |
| Unsupported or contradicted (answer) | SimpleMem | +0.4 | [-17.2, +16.3] | [-13.6, +13.4] | [-6.3, +5.5] | 68 |
| Unsupported or contradicted (answer) | MemR³ | -3.8 | [-19.5, +12.4] | [-10.0, +1.6] | [-5.3, -1.9] | 68 |
| Fully grounded (core claims only) | NEMORI | +6.6 | [-5.5, +21.0] | [-3.4, +17.6] | [+0.3, +8.2] | 68 |
| Fully grounded (core claims only) | SimpleMem | +13.5 | [-9.2, +34.9] | [+2.3, +27.5] | [+8.9, +16.1] | 68 |
| Fully grounded (core claims only) | MemR³ | +11.7 | [-10.6, +33.6] | [-7.9, +32.3] | [+6.6, +21.2] | 68 |
| Correct AND fully grounded | NEMORI | **+29.8** | [+15.6, +45.0] | [+19.3, +43.8] | [+26.7, +33.7] | 68 |
| Correct AND fully grounded | SimpleMem | +17.8 | [-5.0, +39.6] | [+5.5, +33.6] | [+13.4, +21.4] | 68 |
| Correct AND fully grounded | MemR³ | **+26.3** | [+2.1, +47.3] | [+13.9, +41.2] | [+23.0, +31.9] | 68 |
| Fully grounded | correct | NEMORI | **+19.0** | [+4.7, +37.0] | [+3.4, +32.3] | [+14.6, +23.4] | 36 |
| Fully grounded | correct | SimpleMem | +17.5 | [-10.0, +43.7] | [+4.1, +37.6] | [+12.0, +22.3] | 45 |
| Fully grounded | correct | MemR³ | +24.1 | [-6.1, +50.5] | [+8.3, +44.1] | [+19.4, +30.5] | 45 |
| Supported claim rate | NEMORI | -1.7 | [-11.5, +5.7] | [-8.9, +5.9] | [-3.3, +2.3] | 51 |
| Supported claim rate | SimpleMem | +1.7 | [-15.5, +15.9] | [-7.8, +14.8] | [-1.7, +6.7] | 55 |
| Supported claim rate | MemR³ | -6.0 | [-19.6, +4.3] | [-15.4, +2.4] | [-7.6, -0.7] | 58 |
| Unsupported+contradicted claim rate | NEMORI | +1.5 | [-5.9, +11.4] | [-5.7, +8.8] | [-2.6, +2.9] | 51 |
| Unsupported+contradicted claim rate | SimpleMem | -1.6 | [-15.8, +15.5] | [-14.8, +7.9] | [-6.5, +1.8] | 55 |
| Unsupported+contradicted claim rate | MemR³ | +5.6 | [-4.7, +19.4] | [-2.9, +15.3] | [+0.2, +7.2] | 58 |
| Claims / answer | NEMORI | **-1.75** | [-2.44, -1.04] | [-2.21, -1.13] | [-1.94, -1.61] | 51 |
| Claims / answer | SimpleMem | +0.33 | [-0.30, +1.15] | [-0.38, +1.32] | [+0.01, +0.69] | 55 |
| Claims / answer | MemR³ | **-3.18** | [-3.92, -2.43] | [-4.27, -2.17] | [-3.40, -2.56] | 58 |
| Abstain / no claim | NEMORI | **-8.7** | [-14.3, -3.3] | [-14.3, -3.5] | [-10.0, -7.1] | 68 |
| Abstain / no claim | SimpleMem | **-5.7** | [-10.3, -1.7] | [-10.4, -2.0] | [-6.8, -4.4] | 68 |
| Abstain / no claim | MemR³ | **-3.2** | [-7.2, -0.0] | [-8.4, -0.4] | [-3.7, -1.2] | 68 |

**全部主张（含解释部分）**

| Method | Fully grounded | Partially grounded | Unverifiable | Unsupported | Contradicted | Abstain / no claim | n |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 74.4 | 8.0 | 0.8 | 8.5 | 4.7 | 3.6 | 68 |
| NEMORI | 54.0 | 11.8 | 0.0 | 7.3 | 14.6 | 12.3 | 68 |
| SimpleMem | 59.9 | 17.5 | 0.5 | 0.7 | 12.1 | 9.3 | 68 |
| MemR³ | 51.4 | 24.8 | 0.0 | 1.4 | 15.6 | 6.8 | 68 |

**仅 core 主张（只看最终答案本身）**

| Method | Fully grounded | Partially grounded | Unverifiable | Unsupported | Contradicted | Abstain / no claim | n |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 74.4 | 8.0 | 0.8 | 8.5 | 4.7 | 3.6 | 68 |
| NEMORI | 67.7 | 8.7 | 0.0 | 7.3 | 4.0 | 12.3 | 68 |
| SimpleMem | 60.9 | 17.5 | 0.5 | 0.7 | 11.1 | 9.3 | 68 |
| MemR³ | 62.7 | 22.0 | 0.0 | 2.4 | 6.1 | 6.8 | 68 |

| Method | Correct & fully grounded | Correct & not fully grounded | Correct & abstain/no claim | Incorrect & fully grounded | Incorrect & not fully grounded | Incorrect & abstain/no claim | Fully grounded among correct | Fully grounded among incorrect |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 74.0 | 14.1 | 0.3 | 0.4 | 7.9 | 3.3 | 84.0 (n=54) | 4.5 (n=8) |
| NEMORI | 44.2 | 23.3 | 2.1 | 9.8 | 10.4 | 10.2 | 65.5 (n=37) | 48.5 (n=15) |
| SimpleMem | 56.2 | 27.3 | 0.0 | 3.6 | 3.5 | 9.3 | 67.3 (n=48) | 51.2 (n=7) |
| MemR³ | 47.7 | 32.7 | 3.2 | 3.8 | 9.1 | 3.6 | 59.3 (n=47) | 29.4 (n=12) |

未加权原始计数（题数）：

| Method | Correct: Fully / Partial / Unverif. / Unsup. / Contra. / NoClaim | Incorrect: Fully / Partial / Unverif. / Unsup. / Contra. / NoClaim |
|---|---|---|
| VMem (ours) | 42 / 5 / 2 / 3 / 2 / 1 | 1 / 4 / 0 / 1 / 2 / 5 |
| NEMORI | 23 / 4 / 0 / 3 / 7 / 2 | 4 / 3 / 0 / 1 / 7 / 14 |
| SimpleMem | 33 / 7 / 1 / 1 / 6 / 0 | 3 / 1 / 0 / 1 / 2 / 13 |
| MemR³ | 30 / 8 / 0 / 1 / 8 / 5 | 3 / 3 / 0 / 1 / 5 / 4 |

| Group | n | Metric | VMem (ours) | NEMORI | SimpleMem | MemR³ | Δ vs NEMORI [95% CI] | Δ vs SimpleMem [95% CI] | Δ vs MemR³ [95% CI] |
|---|---:|---|---:|---:|---:|---:|---|---|---|
| Multi-hop | 16 | Fully grounded | 76.1 | 13.1 | 60.0 | 33.8 | **+63.1** [+36.9, +84.6] | +16.2 [-13.1, +47.7] | **+42.3** [+8.5, +73.9] |
| Multi-hop | 16 | Fully + partially | 89.2 | 33.8 | 78.4 | 60.0 | **+55.4** [+29.2, +79.2] | +10.8 [+0.0, +27.0] | **+29.2** [+10.8, +50.8] |
| Multi-hop | 16 | Supported claim rate | 96.8 | 77.8 | 91.6 | 86.9 | **+19.0** [+10.5, +27.8] | +5.2 [-3.4, +13.5] | **+9.9** [+1.8, +18.3] |
| Temporal | 18 | Fully grounded | 73.9 | 73.9 | 71.5 | 70.3 | +0.0 [-19.5, +19.6] | +2.4 [-17.8, +28.4] | +3.6 [-1.8, +9.0] |
| Temporal | 18 | Fully + partially | 85.2 | 75.7 | 76.3 | 76.8 | +9.5 [-14.8, +30.3] | +8.9 [-15.3, +37.3] | **+8.4** [+0.1, +19.6] |
| Temporal | 18 | Supported claim rate | 86.3 | 92.4 | 79.6 | 92.1 | -6.0 [-20.3, +8.3] | +6.5 [-14.0, +34.1] | -1.6 [-7.4, +3.6] |
| Single-hop | 21 | Fully grounded | 75.3 | 63.5 | 57.7 | 50.8 | +11.9 [-4.2, +35.3] | +17.6 [-20.1, +54.0] | +24.6 [-15.3, +60.1] |
| Single-hop | 21 | Fully + partially | 79.6 | 76.5 | 80.8 | 83.9 | +3.0 [+0.0, +9.1] | -1.2 [-31.0, +29.5] | -4.3 [-32.0, +25.5] |
| Single-hop | 21 | Supported claim rate | 81.1 | 92.9 | 84.7 | 93.6 | -6.9 [-23.6, +3.8] | -1.8 [-30.6, +21.5] | -13.1 [-37.1, +3.9] |
| 1 turn | 32 | Fully grounded | 76.0 | 65.6 | 61.9 | 56.9 | +10.4 [-4.1, +28.4] | +14.1 [-15.6, +41.7] | +19.1 [-10.1, +46.9] |
| 1 turn | 32 | Fully + partially | 81.6 | 75.4 | 81.3 | 83.2 | +6.2 [-1.6, +13.3] | +0.3 [-23.2, +23.2] | -1.6 [-23.3, +21.1] |
| 1 turn | 32 | Supported claim rate | 82.8 | 92.8 | 83.6 | 93.5 | -6.5 [-19.2, +3.0] | +0.6 [-22.2, +19.3] | -10.0 [-28.6, +3.1] |
| multi-turn, 2+ sessions | 24 | Fully grounded | 69.0 | 15.1 | 54.2 | 31.7 | **+53.9** [+31.4, +75.6] | +14.8 [-12.6, +42.2] | **+37.3** [+10.0, +64.0] |
| multi-turn, 2+ sessions | 24 | Fully + partially | 84.6 | 37.5 | 70.6 | 52.0 | **+47.1** [+25.3, +69.0] | **+14.1** [+2.3, +28.2] | **+32.6** [+14.0, +52.5] |
| multi-turn, 2+ sessions | 24 | Supported claim rate | 94.0 | 79.2 | 89.2 | 86.3 | **+14.9** [+6.5, +23.2] | +5.0 [-3.2, +13.1] | +7.9 [-0.0, +15.6] |
| error strata (some method wrong) | 38 | Fully grounded | 51.7 | 24.9 | 49.0 | 40.7 | **+26.8** [+4.7, +48.9] | +2.7 [-18.1, +23.5] | +11.0 [-6.9, +29.3] |
| error strata (some method wrong) | 38 | Fully + partially | 68.7 | 34.9 | 63.5 | 55.3 | **+33.7** [+14.9, +52.4] | +5.2 [-14.9, +25.1] | +13.3 [-5.8, +32.9] |
| error strata (some method wrong) | 38 | Supported claim rate | 75.7 | 79.4 | 86.5 | 88.8 | +3.5 [-10.9, +17.5] | -8.5 [-24.5, +6.2] | -12.2 [-27.7, +1.5] |
| all-correct strata | 30 | Fully grounded | 86.5 | 69.6 | 65.7 | 57.2 | **+16.9** [+4.1, +35.3] | +20.8 [-12.3, +51.2] | +29.3 [-5.6, +58.9] |
| all-correct strata | 30 | Fully + partially | 89.7 | 82.4 | 84.8 | 87.4 | **+7.3** [+1.5, +13.5] | +4.9 [-19.7, +29.5] | +2.3 [-22.5, +25.8] |
| all-correct strata | 30 | Supported claim rate | 90.2 | 93.5 | 84.0 | 93.6 | -3.5 [-16.4, +4.4] | +6.0 [-18.5, +24.5] | -3.4 [-22.9, +8.3] |

| Method | non-supported claims | temporal | entity_attribution | unsupported_aggregation | invented_detail | other | world-knowledge claims (not checked) |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 22 | 6 (27%) | 3 (14%) | 2 (9%) | 9 (41%) | 2 (9%) | 2 |
| NEMORI | 41 | 11 (27%) | 8 (20%) | 5 (12%) | 16 (39%) | 1 (2%) | 3 |
| SimpleMem | 24 | 5 (21%) | 3 (12%) | 1 (4%) | 10 (42%) | 5 (21%) | 1 |
| MemR³ | 33 | 16 (48%) | 3 (9%) | 6 (18%) | 5 (15%) | 3 (9%) | 7 |

未加权；只计非弃答答案中的 UNSUPPORTED / CONTRADICTED / UNVERIFIABLE 主张。

| Method | claims (checkable) | supported | unverifiable | unsupported | contradicted | core claims | answers with claims |
|---|---:|---:|---:|---:|---:|---:|---:|
| VMem (ours) | 205 | 183 | 3 | 15 | 4 | 188 | 62 |
| NEMORI | 275 | 234 | 1 | 25 | 15 | 98 | 52 |
| SimpleMem | 152 | 128 | 2 | 14 | 8 | 140 | 55 |
| MemR³ | 361 | 328 | 0 | 17 | 16 | 176 | 59 |

| Subset | Metric | vs | Δ | 95% CI question bootstrap | 95% CI cluster bootstrap | n |
|---|---|---|---:|---|---|---:|
| all | Fully grounded | NEMORI | **+20.4** | [+8.9, +34.2] | [+11.5, +28.6] | 68 |
| all | Fully grounded | SimpleMem | +14.5 | [-7.8, +36.6] | [+3.0, +30.4] | 68 |
| all | Fully grounded | MemR³ | +22.9 | [-1.3, +43.5] | [+9.3, +39.3] | 68 |
| all | Fully grounded, UNVERIFIABLE counted as neutral | NEMORI | **+21.2** | [+9.7, +34.9] | [+12.6, +28.8] | 68 |
| all | Fully grounded, UNVERIFIABLE counted as neutral | SimpleMem | +14.9 | [-7.4, +37.0] | [+3.5, +30.7] | 68 |
| all | Fully grounded, UNVERIFIABLE counted as neutral | MemR³ | +23.8 | [-0.0, +44.3] | [+10.5, +39.5] | 68 |
| all | Fully grounded (core claims only) | NEMORI | +6.6 | [-5.6, +21.1] | [-3.4, +17.3] | 68 |
| all | Fully grounded (core claims only) | SimpleMem | +13.5 | [-8.6, +35.6] | [+2.3, +28.9] | 68 |
| all | Fully grounded (core claims only) | MemR³ | +11.7 | [-10.4, +31.6] | [-9.1, +32.7] | 68 |
| excluding Open-domain | Fully grounded | NEMORI | **+19.3** | [+6.7, +33.8] | [+11.4, +26.4] | 55 |
| excluding Open-domain | Fully grounded | SimpleMem | +14.0 | [-10.0, +37.5] | [+1.9, +31.4] | 55 |
| excluding Open-domain | Fully grounded | MemR³ | +23.4 | [-1.1, +45.8] | [+9.0, +41.5] | 55 |
| excluding Open-domain | Fully grounded, UNVERIFIABLE counted as neutral | NEMORI | **+19.6** | [+7.4, +34.1] | [+11.7, +26.6] | 55 |
| excluding Open-domain | Fully grounded, UNVERIFIABLE counted as neutral | SimpleMem | +14.4 | [-9.5, +37.9] | [+2.6, +31.6] | 55 |
| excluding Open-domain | Fully grounded, UNVERIFIABLE counted as neutral | MemR³ | +23.8 | [-0.4, +46.0] | [+9.8, +41.7] | 55 |
| excluding Open-domain | Fully grounded (core claims only) | NEMORI | +5.1 | [-7.6, +20.1] | [-4.9, +15.2] | 55 |
| excluding Open-domain | Fully grounded (core claims only) | SimpleMem | +12.9 | [-11.0, +36.6] | [+1.1, +30.4] | 55 |
| excluding Open-domain | Fully grounded (core claims only) | MemR³ | +12.4 | [-11.6, +35.1] | [-8.1, +33.9] | 55 |

- pass 1 共 1127 条主张；其中 UNSUPPORTED/UNVERIFIABLE 166 条进入第二轮检索；133 条在全对话 BM25 top-5 中找到 pack 外的新 turn 并被重判（133 条成功重判）。
- 重判前→后标签转移：UNSUPPORTED→SUPPORTED 50；UNSUPPORTED→UNSUPPORTED 42；UNVERIFIABLE→SUPPORTED 20；UNSUPPORTED→CONTRADICTED 10；UNVERIFIABLE→UNSUPPORTED 6；UNVERIFIABLE→CONTRADICTED 3；UNVERIFIABLE→UNVERIFIABLE 2。
- 由主张标签确定性推出的答案标签，与 judge 自己给出的 answer_label 一致率：224/272 = 82.4%（不一致主要来自第二轮重判改变了主张标签，以及 judge 对 core/support 的整体权衡）。

- 方向与 Opus 一致：VMem 对 NEMORI 显著更好（完全锚定 +20.4，正确且完全锚定 +29.8）。
- 对 SimpleMem、MemR³ 的点估计为正且较大，聚类 CI 不跨 0，但题级 CI 跨 0。样本太小，不足以下结论。
- 与 Opus 不同，Haiku 上 SimpleMem 的锚定率明显低于它在 Opus 上的水平（59.9% 对 82.3%），主要是矛盾标签增多。

## 6. 人工复核与典型例子

挑出三类有争议的判定：答对但未锚定、答错但完全锚定、VMem 比基线差。各类的数量：

| Kind | VMem (ours) | NEMORI | SimpleMem | MemR³ |
|---|---:|---:|---:|---:|
| correct_but_ungrounded | 18 | 32 | 8 | 33 |
| incorrect_but_fully_grounded | 22 | 26 | 35 | 29 |
| vmem_worse_than_baseline | 9 | 0 | 0 | 0 |

人工复核 29 条有争议判定（作者逐条对照 LoCoMo 原文）：judge 正确 14，judge 错误 9，部分正确 3，可辩护 3。

| # | Method | Category | Question | Judge label | Correct? | Verdict | Note |
|---|---|---|---|---|---|---|---|
| 1 | VMem (ours) | Single-hop | What kind of professional experience did Gina get accepted for on May  | CONTRADICTED | 1 | judge 错误 | 把问题前提（May 23）当成答案主张；答案本身"fashion internship"由 D12:1 支持 |
| 2 | VMem (ours) | Single-hop | What did Mel and her kids paint in their latest project in July 2023? | CONTRADICTED | 1 | 部分正确 | "blue and yellow design" 归属确实无依据（D9:13 是 Melanie 发的图，但 D9:17 才说与孩子新画完）；应为 UNSUPPORTED 而非 CONTRADICTED |
| 3 | VMem (ours) | Multi-hop | How many times did Audrey and Andew plan to hike together? | UNSUPPORTED | 1 | 可辩护 | "3 次"计划是对 D11/D12/D20/D24/D26 多次提及的计数解释，gold 本身也是解释；judge 判计数无法确证属合理 |
| 4 | NEMORI | Temporal | How many months passed between Andrew adopting Toby and Buddy? | CONTRADICTED | 1 | judge 正确 | Toby 在 7/11 已领养（D12:1），答案说"8 月初"错；core"2–3 个月"判矛盾略严 |
| 5 | NEMORI | Open-domain | Does Calvin love music tours? | CONTRADICTED | 1 | judge 错误 | 引文日期与内容都对（D14:8），只是"as a performer"改写，judge 过严 |
| 6 | NEMORI | Multi-hop | What do Melanie's kids like? | CONTRADICTED | 1 | judge 正确 | 博物馆是 7/6 会话中的"yesterday"即 7/5，答案写 7/6（小的时间错误） |
| 7 | SimpleMem | Single-hop | What did Mel and her kids paint in their latest project in July 2023? | CONTRADICTED | 1 | judge 错误 | 误读答案：答案说"类似的新画在 7/17 完成"（D9:17），judge 把日期套到 sunset 画上 |
| 8 | SimpleMem | Multi-hop | What LGBTQ+ events has Caroline participated in? | CONTRADICTED | 1 | 部分正确 | "8 月的 pride parade"确实无依据（D10:7 她错过了）；但"6 月"与"9 月艺术展"是有依据的，judge 部分过严 |
| 9 | SimpleMem | Temporal | After how many weeks did Tim reconnect with the fellow Harry Potter fa | UNSUPPORTED | 1 | judge 错误 | "约 3–4 周"与 7/16 前一周→8/9 一致，属于允许的近似，judge 过严 |
| 10 | MemR³ | Temporal | How many pets will Andrew have, as of December 2023? | CONTRADICTED | 1 | judge 正确 | "8/4 得到第一只狗 Toby"与 D12:1（7/11 已有 Toby）矛盾 |
| 11 | MemR³ | Open-domain | Was the first half of September 2022 a good month career-wise for Nate | CONTRADICTED | 1 | judge 正确 | "9/5 左右上烹饪节目"错（9/14 说 last Monday = 9/12）；core 判 UNSUPPORTED 略严 |
| 12 | MemR³ | Temporal | When did Audrey adopt Pixie? | UNSUPPORTED | 1 | 可辩护 | D2:1 只说已领养，没给领养日；答案给出精确日期属过度精确（gold 也写 around） |
| 13 | VMem (ours) | Single-hop | What is the topic of discussion between John and Tim on 11 December, 2 | FULLY | 0 | judge 正确 | 答案"追逐梦想、互相支持"空泛但不违背原文；错在不具体，属"有依据但不切题" |
| 14 | VMem (ours) | Multi-hop | What mediums does Nate use to play games? | FULLY | 0 | judge 正确 | Xbox 手柄照片、Nintendo、Catan 桌游、PC 均有原文；gold 列表不全（未列 Xbox/桌游），属 gold 标注不完整 |
| 15 | NEMORI | Single-hop | What did Gina design for her store? | FULLY | 0 | judge 正确 | "与艺术家合作的服装设计"有原文支持；gold 指店面空间设计，属答非所问 |
| 16 | NEMORI | Multi-hop | What events has Caroline participated in to help children? | FULLY | 0 | judge 正确 | 导师项目、青年中心志愿均有原文；遗漏学校演讲导致判错 |
| 17 | SimpleMem | Multi-hop | Which US cities does John mention visiting to Tim? | FULLY | 0 | judge 正确 | Seattle、NYC 均有原文；漏了 Chicago |
| 18 | SimpleMem | Open-domain | What might John's financial status be? | FULLY | 0 | judge 正确 | 失业（D28:1）与修车压力（D11:1）都有原文；推断与 gold 不同 |
| 19 | MemR³ | Multi-hop | What books has Tim read? | FULLY | 0 | judge 正确 | 城堡书（D15:1）、"小改变"书（D19:19）等均有原文；列表不完整 |
| 20 | MemR³ | Multi-hop | What kind of games has James tried to develop? | FULLY | 0 | judge 正确 | 策略游戏受 Civilization/Total War 启发（D22:5）有原文；gold 列的是别的游戏 |
| 21 | VMem (ours) | Multi-hop | How long did it take for Jon to open his studio? | CONTRADICTED | 0 | 可辩护 | D1:2（1/20）说"昨天失业，打算创业"，"1/19 决定"差一天，judge 判矛盾偏严但不算错 |
| 22 | VMem (ours) | Open-domain | Which US states might Tim be in during September 2023 based on his pla | UNVERIFIABLE | 1 | judge 错误 | "Universal + 哈利波特→加州或佛州"是合理推断（前提在 D10:9/D10:11，加上常识），rubric 应判 SUPPORTED |
| 23 | VMem (ours) | Open-domain | Would Calvin enjoy performing at the Hollywood Bowl? | UNVERIFIABLE | 1 | judge 错误 | 假设性问题，前提 D7:11（热爱大舞台和人群）在 pack 中，应判 SUPPORTED |
| 24 | VMem (ours) | Open-domain | What nickname does Nate use for Joanna? | CONTRADICTED | 0 | judge 正确 | Nate 多次称 Joanna 为"Jo"（D7:1 等），答案说"不用昵称"是真矛盾 |
| 25 | VMem (ours) | Open-domain | Which Star Wars-related locations would Tim enjoy during his visit to  | UNSUPPORTED | 0 | judge 错误 | "Tim 会喜欢 Skellig Michael"是合理推断（喜欢 Star Wars + 去爱尔兰 + 常识），judge 过严 |
| 26 | VMem (ours) | Open-domain | How often does Sam get health checkups? | UNSUPPORTED | 0 | 部分正确 | "不规律、出问题才去"确无依据；但"约 2–3 个月一次"与 5 月/8 月/10 月的记录一致 |
| 27 | VMem (ours) | Temporal | When is Andrew going to go hiking with Audrey? | CONTRADICTED | 0 | judge 正确 | 年份写成 2026，真实错误 |
| 28 | VMem (ours) | Temporal | When did the Deboran and Jolene agree to go surfing? | CONTRADICTED | 0 | judge 错误 | 问题有歧义：两人确在 9/17 的对话中商定去冲浪（D29:32–34），答案"9/17"至少是对"何时商定"的合理理解 |
| 29 | VMem (ours) | Temporal | Which pet did Jolene adopt first - Susie or Seraphim? | UNVERIFIABLE | 1 | judge 错误 | pack 中 D2:22 明确说 Seraphim 是"second snake"，judge 漏看，判 UNVERIFIABLE；同时"Seraphim 2022"被误判为支持 |

复核发现的系统性问题：
1. **开放域推断判得过严。** 问题本身要求推断时（"Tim 可能在哪个州"、"Calvin 会不会喜欢在 Hollywood Bowl 演出"），即使前提都在证据包里，judge 仍常判 UNVERIFIABLE 或 UNSUPPORTED。29 条中有 9 条判错，其中 6 条是 VMem 的答案，大多属于这一类。所以 VMem 相对 SimpleMem 的劣势应视为**上界**。
2. **问题前提被当成主张。** 例 1：judge 把问题里的日期当成答案的主张去核查。
3. **漏看证据包里的内容。** 例 29：证据包里明确有依据，judge 仍判 UNVERIFIABLE。
4. **真实的错误确实存在。** 例如 NEMORI 和 MemR³ 把 Toby 的领养日期写成 8 月（原文 7/11 之前已领养），VMem 把年份写成 2026。这些都被 judge 正确识别。

## 7. 不确定性与局限

- **judge 误差**：打乱证据包中 session 的顺序后，40 个答案里有 35 个答案层标签不变；人工复核 29 条争议判定，judge 判错 9 条。由主张推出的答案标签与 judge 自己的整体标签一致率约 83%。
- **gold 标注不完整**：第二轮检索带来大量改判，答错但完全锚定的答案多是 gold 不全或答案不全。本文**不把**证据包外的内容自动视为幻觉。
- **证据包覆盖**：证据包上限 70 个 turn，平均 36 个；第二轮检索只取全对话 BM25 top-5，仍可能漏掉同义改写的依据。
- **答案长短**：答案层面的指标会惩罚冗长答案（主张越多，越容易出现一条错误）。因此本文并列报告了主张数、主张级支持率和 core-only 指标；结论 2 正是由此得出的。
- **抽样设计**：错误层和 Multi-hop 过采样，加权估计依赖设计权重；Haiku 子样本只有 68 题。
- **rubric 修订**：smoke test 后修订过一次 rubric，之后没有再改。
- **judge 与正确性评审是同一个模型家族**（Opus 4.5），可能有相关的偏差。
- **中性和负面结果**：主张级支持率没有差别；对 SimpleMem 完全锚定率略低（只看答对的题时显著）。这些都如实报告。

## 8. 是否值得写进论文

- **建议作为次要结论或附录，不单独作为 RQ。** 支持的结论是："VMem 的准确率提升不靠无依据的猜测；它的答案锚定率与最强基线相当，并显著高于 NEMORI 和 MemR³，后两者的冗长答案中有更多与原文矛盾的辅助事实，尤其是日期。"
- **不能**声称"证据集让每条主张更忠实"：主张级支持率没有差别，对 SimpleMem 也没有优势。
- 若放进论文，建议用图 A(a)(b) 两栏一起展示，避免只放 (a) 造成误导；图 B 可以放附录。

## 9. API 调用、花费与复现

全部新调用都是 Opus 4.5 judge（$5 / 百万输入 token，$25 / 百万输出 token），全部缓存在 `exp8/data/judge_cache.jsonl`，重跑不再产生费用。

| Tag | New API calls | Input tokens | Output tokens | Cost (USD) |
|---|---:|---:|---:|---:|
| answer_judge | 1222 | 3,821,451 | 313,530 | 26.95 |
| claim_rejudge | 387 | 1,149,076 | 34,172 | 6.60 |
| stability | 60 | 191,259 | 14,855 | 1.33 |
| **Total（= 缓存文件中全部条目，含 smoke 迭代）** | **1669** | **5,161,786** | **362,557** | **34.87** |

文件：
- 脚本：`exp8/lib8.py`、`sample.py`、`build_packs.py`、`judge.py`、`analyze.py`、`make_figure.py`、`build_report.py`、`report_template.md`
- 数据：`exp8/data/sample.json`、`data/packs/*.json`、`data/judge_cache.jsonl`、`data/judgments_{opus,haiku}.jsonl`、`data/stability_opus.jsonl`、`data/manual_review.json`、`data/usage.json`
- 表格：`exp8/tables/report_tables.md`、`tables/*.csv`、`tables/disputed_opus.json`、`tables/cost.json`
- 图：`exp8/figures/rq8_groundedness_by_method.{pdf,png}`、`exp8/figures/rq8_correctness_x_groundedness.{pdf,png}`；作图数据 `exp8/figdata/figA_opus.csv`、`figB_opus.csv`

复现（正常情况下 judge 调用全部命中缓存、不产生费用；`judge.py` 会在 `data/usage.json` 记录新调用数，可据此确认）：

```bash
cd /path/to/VMem/develop && source env.sh
$PY exp8/sample.py
$PY exp8/build_packs.py
$PY exp8/judge.py --backbone opus --stability 40
$PY exp8/judge.py --backbone haiku
$PY exp8/analyze.py
/usr/bin/python3 exp8/make_figure.py
$PY exp8/build_report.py
```
