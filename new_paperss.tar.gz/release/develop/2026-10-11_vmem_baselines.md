# LoCoMo 基线复现：8 个已发表的记忆系统（2026-10-11 开始）

> 目标：在与 NEMORI / VMem 完全相同的协议下，复现 8 个已发表的记忆系统基线，backbone 分别为 Claude Haiku 4.5 和 Claude Opus 4.5。
> 相关文档：方法与主结果见 `2026-10-11_vmem2_method_and_results.md`；Haiku 换 backbone 实验见 `2026-10-11_backbone_haiku45.md`。
> 工作目录：`develop/baselines/`（下文记作 `$B`）。约定见 `$B/CONTRACT.md`，每个方法的详细记录见 `$B/notes/<method>.md`。

**状态**：✅ 已完成（2026-10-12）。8 个方法都有实测结果，notes 齐全；MRAgent 只跑了 Haiku，Opus 因成本未跑，由用户决定

---

## 1. 参照结果（已有）

| 方法 | Haiku 4.5 | Opus 4.5 |
|---|---:|---:|
| NEMORI | 76.49% | 80.71% |
| VMem-v2.3-clean | 89.61% | 91.43% |

---

## 2. 统一协议

| 项目 | 设定 |
|---|---|
| 数据 | LoCoMo `locomo10.json`（与主实验同一份文件，不修改），10 段对话，cat 1–4 共 **1540 题** |
| **记忆构建** | **每个方法用 Opus 4.5 构建一次**，Haiku 和 Opus 两个阶段共用。这与 NEMORI/VMem 的做法完全一致：两者的 Haiku 和 Opus 结果都基于同一份 Opus 构建的记忆库，只替换查询阶段的 LLM。这样既保证与主表可比，又只需构建一次（比"Haiku 构建一次 + Opus 再构建一次"更省钱） |
| 查询阶段 | 查询阶段的所有 LLM 调用（检索侧的 LLM 和作答）各跑两遍：Phase 1 用 Haiku 4.5，Phase 2 用 Opus 4.5 |
| 作答 prompt | 使用各方法**自己的官方** prompt 和作答流程 |
| Judge | 与主实验相同：Opus 4.5 + 上游 `ACCURACY_PROMPT`（`common.evaluate`，显式传入 `--judge-model`），共用 judge 缓存 |
| 指标 | LLM-judge 准确率、F1、BLEU-1，给出总体和分类别结果（`common.evaluate` 原样计算） |
| 解码 | temperature 0，由网关强制设定 |
| Embedding | 能兼容的方法统一用 Qwen3-Embedding-4B；不能兼容的保留原方法的 embedding，并逐一注明 |
| 数据完整性 | 推理时不接触 gold 答案、evidence 或类别标签；gold 字段只在写结果时附加（`baselines/common_io.make_record`） |

### 2.1 共享基础设施（为减少工程量和 API 开销）

- **Bedrock 网关**（`$B/gateway/gateway.py`，端口 :8700）：OpenAI 兼容接口，`base_url = http://127.0.0.1:8700/<tag>/<haiku|opus>/v1`。
  - 官方代码通常只需要改 base_url 就能跑。代码里写死的模型名（如 "gpt-4o-mini"）没有关系，实际使用哪个模型由 URL 决定。
  - 网关统一处理协议细节：强制 temperature 0；丢弃 top_p、seed、n（Bedrock 上的 Claude 4.5 不允许 temperature 和 top_p 同时出现）；JSON 模式下去掉 ```json 代码块标记；支持 tools；模拟 stream 输出。
  - **全局并发上限**：Haiku 48；Opus 分 `us.` 和 `global.` 两条 profile 路由（同一模型，配额相互独立），各 20，所有方法共享。原因是单个 profile 的 Opus 并发约 22 时就开始限流。
  - **磁盘缓存**：完全相同的请求不会重复付费，中断后重跑即可续跑。
  - 按 tag 记录 token 用量，`gateway/usage.py` 汇总成本。
  - `/v1/embeddings` 转发到本地的 Qwen3-Embedding-4B 服务。
- `$B/common_io.py`：统一的数据读取、题目筛选（cat 1–4）、结果格式（上游 `{conv_idx: [record]}`）和评测命令。
- 官方仓库统一 clone 在 `$B/repos/`，commit 见 §3。

---

## 3. 基线列表与实现状态

| 方法 | 组别 | 官方仓库 | commit | 实现状态 | 备注 |
|---|---|---|---|---|---|
| Mem0 | A | https://github.com/mem0ai/mem0 | 库 **v0.1.94**（`07ddd7c`）+ 评测脚本 `b3ede5b` | ✅ **adapted** | 没有使用 clone 下来的 `b7ad69a`：它的 `evaluation/` 是空的 submodule，而且 2.2.1 版的库已经换成了新算法（只做 ADD，BM25 + 实体打分）。改用论文发表前最后一个版本 mem0ai v0.1.94，它对应论文中“事实抽取 + ADD/UPDATE/DELETE/NONE 更新”的流程，代码不做修改；LoCoMo 评测脚本从官方移除该目录前的最后一个 commit 原样拷贝。官方协议都保留：每段对话两个 user（互换角色），每次 add 2 条消息，session 时间戳写进 metadata，每位说话人 top_k=30，使用官方 ANSWER_PROMPT。与官方的差异：用本地库 + 本地 Qdrant 代替托管 Platform；Platform 的 custom_instructions 原文拼接到事实抽取 prompt 里；**事实抽取 prompt 里的 “Today's date” 设为 session 日期**（否则 “last Sunday” 会被换算成 2026 年的日期）。记忆库共 4,793 条，add 失败 0 次。官方 prompt 要求逐步推理，所以 F1 偏低；只截取最终答案计算的 F1 为 41.1 / 48.8。总成本 $205.0 |
| A-Mem | A | https://github.com/WujiangXu/A-mem | `0c8039f` | ✅ **official** | 使用官方 `memory_layer.py`、`test_advanced.py`、`load_dataset.py`，官方仓库不做修改，只加了一层薄 adapter。**修了一个上游 bug**：`analyze_content` 用到 `re` 但没有 import，导致每条 note 的 keywords/context/tags 都静默变成空值，等于把 note 构建这个机制关掉了；修复后空值为 0。不使用 gold category，作答 prompt 统一走默认分支，代价主要落在 temporal（模型常答 "yesterday" 这类相对时间）。k=10，这是仓库默认值，也是论文主设置。Embedding 换成 Qwen3-4B：构建时与官方相同，检索 query 加 Qwen3 instruction；不加 instruction 时检索失效（recall@10 只有 0.21–0.26，加了是 0.66–0.69，MiniLM 是 0.66–0.68），那一轮结果作废。Opus 构建 $179.9（5882 条 note、13,257 条 link）。累计 $241；超出 $250 上限的部分（作废那一轮加上重跑）经用户批准，追加约 $55 用于跑完 Opus 问答（实际花费 $57.7）。总计 $299.1 |
| MemoryOS | A | https://github.com/BAI-LAB/MemoryOS | `587ed77` | ✅ **official** | 使用官方 `eval/` 下的 LoCoMo 脚本，官方仓库不做修改，在运行时打补丁，只改接口、模型、embedding，外加两处输出解析修复。三层存储（STM / 带 heat 分页的 MTM / LTM 画像与知识）、更新与检索模块、官方作答 prompt 都不变。参数按官方 eval 代码：STM=1，MTM=2000，θ=0.6，τ=5，α=β=0.8，top-m=5，top-k=10，知识 top-10。论文写的是 STM=7、MTM=200、α=β=γ=1，与发布的代码不一致，以代码为准。Embedding 换成 Qwen3-4B（官方 MiniLM 是对称编码，可以直接替换）。建库只做一次，每轮 QA 在库的副本上跑；检索只更新 heat 计数，QA 不读这些计数，所以与边建边答等价。解析修复：Claude 常把 multi-summary 的 JSON 包在 ``` 里，不修会被官方代码静默丢弃；仍有约 6% 的回合没有 JSON，按官方行为丢弃。官方塞进 meta_data 的 gold category/evidence 一律不传。总成本 $135.5 |
| LightMem | A | https://github.com/zjunlp/LightMem | `8449d57` | ✅ **official** | 使用官方 `experiments/locomo` 脚本和 `lightmem` 包，官方仓库一行没改，只加了一层 adapter。保留完整机制：LLMLingua-2 预压缩、话题分段、STM 抽取、离线 LTM 更新。**压缩率 0.6 → 0.7**：脚本里写死的是 0.6，但 README 和论文中 gpt-4o-mini 的配置都没有用 0.6，所以选了论文报告过的 (th=512, r=0.7)。保留官方的 all-MiniLM embedding，因为话题分段的阈值是按它调的。官方 prompt 要求逐步推理，所以 F1 偏低；只截取最终答案计算的 F1 为 47.1 / 52.3（见 `metrics_final_answer.json`）。网关重启导致 4 段对话在构建中途崩溃，已清空重建。成本 $58.5，详见 `notes/lightmem.md` |
| SimpleMem | A | https://github.com/aiming-lab/SimpleMem | `db80b6a` | ✅ **adapted** | 官方文本版 SimpleMem 代码不做修改：滑动窗口事实抽取、三路索引（语义 / 关键词 / 元数据）、planning + 最多 2 轮 reflection、官方作答 prompt。adapter 只做一件事：把官方一体化脚本拆成“Opus 建库一次（按对话 checkpoint）+ 两轮 QA 复用”。官方设置都保留：window 40、overlap 2、top-k 25/5/5。Embedding 从 Qwen3-Embedding-0.6B 换成同一系列的 4B，走同一条代码路径。**修了官方脚本的一个 bug**：10 段对话共用同一个系统对象，导致上一段对话的事实泄漏进下一段的抽取 prompt；改为每段对话新建一个。max_tokens 设为 16384，没有发生截断。官方检索的合并顺序不确定，即使 temperature 为 0，重跑结果也会有少量差异：两次 Haiku 运行有 619 条回答措辞不同，但总分差距 ≤ 0.2 pp（第一次 78.44，保留在 `haiku/attempt1/`）。建库共 3,641 条。总成本 $162.9 |
| MemR³ | B | https://github.com/mbzuai-ai4bio/memr3 | `f2b656b` | ✅ **official** | 使用官方 RAG 后端设置（`example_rag_locomo.sh`）。官方代码原样运行（router 的 retrieve / reflect / answer 循环、evidence-gap tracker、masked retrieval、cross-encoder 重排序、官方 prompt），只加了一层薄 adapter。设置：256-token 分块，top_k 5，重排前取 20 个候选，最多 5 轮迭代。Embedding 从 text-embedding-3-large 换成 Qwen3-4B（分块用的 tokenizer 不变）。mem0 的 `locomo10_rag.json` 拿不到，所以用同样的格式从 `$LOCOMO` 重建。Zep 后端是托管服务，无法使用，因此没跑。官方 prompt 要求逐步推理，回答平均 99–147 词，所以 F1 偏低。成本约 $68，详见 `notes/memr3.md` |
| MemGAS | B | https://github.com/Applied-Machine-Learning-Lab/ICLR2026_MemGAS | `c2d4e9f` | ✅ **adapted** | 直接导入官方核心函数（Contriever 编码、GMM 建边、熵路由、PPR 图检索），官方 prompt 和超参原样使用（LoCoMo README 命令），只加了一层薄胶水（`memgas_adapter/run.py`），官方仓库不做修改。**保留官方的 Contriever**：熵路由、GMM 和 PPR 都依赖 Contriever 的打分尺度，换成 Qwen3 会改变方法行为。绕开了官方脚本的几个 bug（路径、`torch.load`、无限重试）。检索 recall@3 = 0.554，论文报告 57.3%，基本一致。官方 prompt 要求写成完整的回复（平均约 70 词），所以 F1 偏低。总成本 $54.9，详见 `notes/memgas.md` |
| MRAgent | B | https://github.com/Ji-shuo/MRAgent | `7441506` | ✅ **adapted**（只跑了 Haiku；Opus 因成本未跑，用户决定） | 官方代码、全部 prompt 和超参不变（K1=80、K2=20、MAX_ROUNDS=8 等），只加了一层薄 adapter。**最大的偏离**：官方推理时按 **gold category** 切换 prompt，违反我们的协议。现改为只根据问题文本做正则路由：时间类问句走官方 cat-2 路径，would/likely/might 走 cat-3 路径，其余走默认路径；官方给 cat-1 加的提示后缀无法复现，已去掉。事后核对：321 道时间题中 254 道进了时间路径。Embedding 换成 Qwen3-4B。max_tokens 设为 16384，否则建库时的长 JSON 会被截断。2 道题因官方 `select_key_tag` 崩溃，记为 ERROR 并按错误计分。成本：建库 $57.7，Haiku QA $63.1。**Opus QA 预计 $280–350**，加上已花费会超过单方法 $250 的上限，用户决定**不跑 Opus**，主表中 Opus 一栏注明“因成本未跑”。日后如需补跑，命令见 `notes/mragent.md`（40 题 pilot 的结果已缓存） |

实现状态分三类：
- **official**：官方代码，只改了 endpoint 和模型配置；
- **adapted**：官方核心代码，加上我们的胶水代码或共享记忆库适配；
- **reimplemented**：官方集成不可行，忠实重实现论文中的核心机制。

---

## 4. 结果

只报告实测值。全部 10 个系统 × 2 个 backbone × 3 个指标（LLM-judge / F1 / BLEU-1）× 4 个类别 + overall 的完整结果见 §4.1–4.5，由 `baselines/make_tables.py` 从 `runs/*/{haiku,opus}/metrics.json` 自动生成（已核对：每个结果文件都是 1540 道不重复的题，各类别分别为 282 / 321 / 96 / 841）。

<!-- TABLES:BEGIN -->
### 4.1 汇总表（LoCoMo 1540 题，LLM-judge 准确率 / F1 / BLEU-1，单位 %）

| 方法 | 状态 | Haiku 准确率 | Opus 准确率 | Haiku F1 | Opus F1 | Haiku BLEU-1 | Opus BLEU-1 |
|---|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 参照 | 76.49 | 80.71 | 9.25 | 9.35 | 3.63 | 3.60 |
| Mem0 | adapted | 68.83 | 73.57 | 7.19 | 8.70 | 2.20 | 3.18 |
| A-Mem | official | 56.23 | 58.83 | 36.99 | 44.19 | 31.58 | 38.44 |
| MemoryOS | official | 65.71 | 66.36 | 42.07 | 52.07 | 34.56 | 45.13 |
| LightMem | official | 74.94 | 76.49 | 7.70 | 11.28 | 2.16 | 4.40 |
| SimpleMem | adapted | 78.25 | 81.17 | 43.55 | 49.12 | 34.86 | 40.36 |
| MemR³ | official | 80.45 | 83.83 | 7.19 | 9.30 | 2.40 | 3.92 |
| MemGAS | adapted | 60.71 | 62.21 | 8.30 | 8.74 | 4.52 | 4.92 |
| MRAgent | adapted（只跑了 Haiku） | 87.27 | — | 56.44 | — | 47.35 | — |
| **VMem-v2.3-clean** | **本文方法** | 89.61 | 91.43 | 44.47 | 53.11 | 33.56 | 43.96 |

“—”表示尚未完成；n ≠ 1540 的数字放在括号里，表示不完整。

### 4.2 分类别 LLM-judge 准确率（%）

**Haiku 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| NEMORI | 69.50 | 71.65 | 50.00 | 83.71 | 76.49 |
| Mem0 | 65.25 | 61.68 | 52.08 | 74.67 | 68.83 |
| A-Mem | 50.35 | 32.09 | 44.79 | 68.73 | 56.23 |
| MemoryOS | 64.18 | 47.04 | 53.12 | 74.79 | 65.71 |
| LightMem | 63.48 | 81.62 | 57.29 | 78.24 | 74.94 |
| SimpleMem | 78.72 | 79.13 | 53.12 | 80.62 | 78.25 |
| MemR³ | 58.87 | 82.87 | 61.46 | 88.94 | 80.45 |
| MemGAS | 36.88 | 52.34 | 47.92 | 73.37 | 60.71 |
| MRAgent | 79.79 | 82.87 | 63.54 | 94.17 | 87.27 |
| **VMem-v2.3-clean** | 86.88 | 89.10 | 68.75 | 93.10 | 89.61 |

**Opus 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| NEMORI | 70.92 | 77.88 | 61.46 | 87.28 | 80.71 |
| Mem0 | 62.77 | 68.85 | 62.50 | 80.26 | 73.57 |
| A-Mem | 51.77 | 29.28 | 48.96 | 73.60 | 58.83 |
| MemoryOS | 60.99 | 54.21 | 53.12 | 74.32 | 66.36 |
| LightMem | 62.41 | 84.42 | 59.38 | 80.14 | 76.49 |
| SimpleMem | 78.01 | 81.62 | 59.38 | 84.54 | 81.17 |
| MemR³ | 62.41 | 86.92 | 76.04 | 90.73 | 83.83 |
| MemGAS | 41.13 | 56.70 | 52.08 | 72.53 | 62.21 |
| MRAgent | — | — | — | — | — |
| **VMem-v2.3-clean** | 88.30 | 91.28 | 69.79 | 95.01 | 91.43 |

### 4.3 分类别 F1（%）

**Haiku 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| NEMORI | 8.02 | 6.86 | 5.20 | 11.04 | 9.25 |
| Mem0 | 7.50 | 6.01 | 5.06 | 7.79 | 7.19 |
| A-Mem | 31.78 | 22.38 | 13.35 | 47.01 | 36.99 |
| MemoryOS | 34.70 | 42.41 | 19.50 | 46.99 | 42.07 |
| LightMem | 7.39 | 7.46 | 4.88 | 8.23 | 7.70 |
| SimpleMem | 33.35 | 53.36 | 17.79 | 46.16 | 43.55 |
| MemR³ | 5.66 | 6.90 | 4.50 | 8.12 | 7.19 |
| MemGAS | 5.95 | 6.65 | 5.34 | 10.05 | 8.30 |
| MRAgent | 41.07 | 70.23 | 33.02 | 59.01 | 56.44 |
| **VMem-v2.3-clean** | 34.53 | 55.18 | 22.52 | 46.22 | 44.47 |

**Opus 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| NEMORI | 8.70 | 7.41 | 5.76 | 10.72 | 9.35 |
| Mem0 | 8.58 | 7.28 | 5.68 | 9.63 | 8.70 |
| A-Mem | 37.95 | 27.14 | 21.22 | 55.40 | 44.19 |
| MemoryOS | 44.62 | 54.93 | 29.71 | 56.02 | 52.07 |
| LightMem | 9.47 | 10.92 | 7.05 | 12.51 | 11.28 |
| SimpleMem | 38.61 | 58.05 | 20.14 | 52.55 | 49.12 |
| MemR³ | 7.12 | 9.44 | 6.15 | 10.33 | 9.30 |
| MemGAS | 6.11 | 7.48 | 5.26 | 10.50 | 8.74 |
| MRAgent | — | — | — | — | — |
| **VMem-v2.3-clean** | 38.12 | 67.61 | 27.61 | 55.52 | 53.11 |

### 4.4 分类别 BLEU-1（%）

**Haiku 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| NEMORI | 3.30 | 2.17 | 1.99 | 4.49 | 3.63 |
| Mem0 | 2.92 | 1.68 | 1.96 | 2.17 | 2.20 |
| A-Mem | 24.82 | 19.14 | 11.22 | 40.92 | 31.58 |
| MemoryOS | 27.22 | 32.91 | 14.74 | 39.91 | 34.56 |
| LightMem | 2.73 | 1.90 | 1.82 | 2.11 | 2.16 |
| SimpleMem | 26.42 | 39.00 | 13.43 | 38.56 | 34.86 |
| MemR³ | 2.42 | 2.13 | 1.81 | 2.56 | 2.40 |
| MemGAS | 4.38 | 3.48 | 2.81 | 5.16 | 4.52 |
| MRAgent | 33.37 | 56.76 | 27.37 | 50.72 | 47.35 |
| **VMem-v2.3-clean** | 26.46 | 42.13 | 18.35 | 34.42 | 33.56 |

**Opus 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| NEMORI | 4.11 | 2.76 | 2.67 | 3.86 | 3.60 |
| Mem0 | 3.96 | 2.40 | 2.59 | 3.28 | 3.18 |
| A-Mem | 28.84 | 21.40 | 20.20 | 50.25 | 38.44 |
| MemoryOS | 36.02 | 45.11 | 25.46 | 50.43 | 45.13 |
| LightMem | 4.56 | 3.58 | 3.70 | 4.74 | 4.40 |
| SimpleMem | 31.62 | 43.30 | 15.53 | 45.00 | 40.36 |
| MemR³ | 3.84 | 3.36 | 2.83 | 4.28 | 3.92 |
| MemGAS | 4.39 | 3.88 | 2.82 | 5.73 | 4.92 |
| MRAgent | — | — | — | — | — |
| **VMem-v2.3-clean** | 30.17 | 57.55 | 23.07 | 45.79 | 43.96 |

### 4.5 补充：只截取最终答案的 F1 / BLEU-1（%）

Mem0、LightMem 的官方 prompt 要求逐步推理，回复末尾会给出最终答案，这里只对截取出的最终答案计算 F1 / BLEU-1，作为参考；上表仍按上游协议对整段回复打分，论文主表以上表为准。截取规则：Mem0 取最后一个 “Answer:” 之后的文本，找不到时取最后一行（`mem0_adapter/extracted_f1.py`，Haiku 1534/1540 条有标记，Opus 429/1540 条有标记，其余多为单独一行的加粗答案）；LightMem 见 `notes/lightmem.md`。

**F1（最终答案），Haiku 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| Mem0 | 38.19 | 47.84 | 22.69 | 41.62 | 41.11 |
| LightMem | 37.82 | 60.22 | 22.75 | 47.91 | 47.06 |

**F1（最终答案），Opus 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| Mem0 | 44.67 | 55.05 | 30.37 | 49.81 | 48.75 |
| LightMem | 43.72 | 63.99 | 28.27 | 53.54 | 52.34 |

**BLEU-1（最终答案），Haiku 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| Mem0 | 29.87 | 40.89 | 17.50 | 33.39 | 33.32 |
| LightMem | 30.41 | 48.75 | 19.47 | 38.61 | 38.03 |

**BLEU-1（最终答案），Opus 4.5**

| 方法 | 1 multi-hop (282) | 2 temporal (321) | 3 open-domain (96) | 4 single-hop (841) | overall (1540) |
|---|---:|---:|---:|---:|---:|
| Mem0 | 33.54 | 44.35 | 22.43 | 43.14 | 40.34 |
| LightMem | 33.82 | 51.67 | 21.92 | 46.41 | 43.67 |

<!-- TABLES:END -->

### 4.6 结论（只依据实测值）

1. **VMem-v2.3-clean 在两个 backbone 上的总体准确率都排第一**：
   - Haiku 89.61%，比最强基线 MRAgent（87.27%）高 2.3 pp，比第三名 MemR³（80.45%）高 9.2 pp。
   - Opus 91.43%，比 Opus 下最强的 MemR³（83.83%）高 7.6 pp。
2. **分类别**：
   - VMem 在 multi-hop、temporal 两类上，两个 backbone 都是第一。
   - 有两个例外：
     - Haiku 下的 single-hop：MRAgent 94.17%，VMem 93.10%。
     - Opus 下的 open-domain（n=96）：MemR³ 76.04%，VMem 69.79%。
   - Haiku 下的 open-domain 和 Opus 下的 single-hop，仍是 VMem 第一。
   - multi-hop 上 VMem 领先最多：Haiku 下高出第二名（MRAgent 79.79%）7.1 pp，Opus 下高出第二名（SimpleMem 78.01%）10.3 pp。
3. **与 NEMORI 相比**：
   - 只有 MRAgent、MemR³、SimpleMem 三个基线在两个 backbone 上都高于 NEMORI（MRAgent 只有 Haiku 结果）。
   - LightMem 低于 NEMORI，在 Opus 下低 4.2 pp，Haiku 下略低。
   - Mem0、MemoryOS、MemGAS、A-Mem 明显低于 NEMORI。
4. **从 Haiku 换到 Opus 的提升普遍很小**，基线在 +0.6 到 +4.7 pp 之间，说明瓶颈主要不在作答模型。
5. **F1 / BLEU-1 不适合横向比较**：
   - Mem0、LightMem、MemR³、MemGAS 和 NEMORI 的官方 prompt 要求写出推理过程或完整句子，按上游协议对整段回复打分，所以 F1 都在 7–11% 左右。
   - MRAgent、SimpleMem、MemoryOS、A-Mem 和 VMem 输出短答案，F1 在 37–56% 之间。
   - 部分方法另外给出了只截取最终答案的 F1（Mem0 41.1 / 48.8，LightMem 47.1 / 52.3），分类别结果见 §4.5。
   - 论文主指标建议用 LLM-judge 准确率。

### 4.7 可比性说明（写论文时需要注明）

- **记忆构建统一用 Opus 4.5**，所有方法都一样（含 NEMORI/VMem）。Haiku 列表示“Opus 构建的记忆 + Haiku 查询和作答”。
- **两个方法原本会在推理时用 gold category**，均已按协议去掉，这可能低估了它们原论文的数字：
  - MRAgent：改为只根据问题文本做正则路由。
  - A-Mem：统一使用默认 prompt；temporal 类受影响最大（约 30%）。
- **Embedding**：
  - Mem0、A-Mem、MemoryOS、MemR³、MRAgent、SimpleMem 用 Qwen3-Embedding-4B（与 VMem 相同）。
  - LightMem 保留官方 all-MiniLM，因为话题分段阈值依赖它。
  - MemGAS 保留官方 Contriever，因为熵路由、GMM 和 PPR 依赖它的打分尺度。
  - SimpleMem 用 Qwen3-Embedding-4B（官方用的是同系列的 0.6B）。
- **修复上游 bug 的方法**：A-Mem（缺 `import re`，否则 note 构建会全部变成空值）、SimpleMem（多段对话共用同一个系统对象，导致记忆串到下一段对话）、MemGAS（若干脚本 bug）、MemoryOS 和 Mem0（输出解析问题）。修复都不改变算法，详见各方法的 notes。
- **Mem0 用的是论文对应的 v0.1.94**，不是当前 master；当前 master 的算法已经改变，评测目录也已移除。
- **未完成的实验**：MRAgent 的 Opus 问答，预计需要 $280–350，用户决定不跑。


---

## 5. 成本与进度日志

| 时间 | 事件 |
|---|---|
| 10-11 | 搭建网关、制定统一约定、clone 8 个官方仓库与 LightMem；8 个方法并行启动复现 |
| 10-11 | 多个方法同时用 Opus 构建记忆，并发上限 20 成为瓶颈（约 4.8 次 Opus 调用/秒，Bedrock 本身没有报限流）。网关新增第二条 Opus 路由 `global.anthropic.claude-opus-4-5`：同一模型、独立配额、价格 $5/$25。Opus 总并发提升到 40，吞吐约翻倍，0 错误。成本仍按 us. 价格（$5.5/$27.5）记账，所以报出的成本是上限 |
| 10-11 | 网关修复：Bedrock 不接受只有 system 消息的请求（Mem0 和 LightMem 的官方作答步骤会这样调用），现在把唯一的 system 消息改为 user 消息，内容不变 |
| 10-11 | 累计花费 $574（不含 judge）：Mem0 $98、SimpleMem $97、MRAgent $89、A-Mem $68、MemR³ $68、LightMem $58、MemGAS $55、MemoryOS $41。预计全部跑完约 $1000–1100（含 judge 约 $110），高于最初估计的 $600–1000；单个方法都在 $250 上限内 |
| 10-11 | MemGAS 完成（adapted）：Haiku 60.71 / Opus 62.21；检索 recall@3 0.554，与论文的 57.3% 一致 |
| 10-11 | MemR³ 完成（official，RAG 后端）：Haiku 80.45 / Opus 83.83 |
| 10-11 | LightMem 完成（official）：Haiku 74.94 / Opus 76.49；只截取最终答案计算的 F1 为 47.1 / 52.3，与论文的 47.75 一致 |
| 10-11 | MRAgent 的 Haiku 完成：87.27，是目前最强的基线。官方推理时会用 gold category，已改为只根据问题文本做路由。Opus QA 预计 $280–350，超出上限，**用户决定不跑** |
| 10-12 | A-Mem 的 Haiku 完成：56.23。修复了上游缺少 `import re` 的 bug（否则 note 构建会全部变成空值）；第一轮检索因 Qwen3 未加 instruction 失效，已作废重跑。Opus QA 只差约 $55，但累计会超出上限，**用户批准追加**，正在补跑 |
| 10-12 | SimpleMem 两个阶段都已评测：Haiku 78.25 / Opus 81.17 |
| 10-12 00:20 | 发现 Mem0（ALL_DONE）和 MemoryOS（10 段对话都已 finished）的建库早已完成，但两个子 agent 的等待没有被触发，空等了约 1.5 小时。已提醒它们进入问答阶段 |
| 10-12 00:20 | 累计花费 **$944**（不含 judge；按 us. 价格计，是上限）：A-Mem $241、Mem0 $168、SimpleMem $163、MRAgent $137、MemR³ $68、LightMem $59、MemGAS $55、MemoryOS $53。剩余预计：A-Mem Opus 约 $55，Mem0 QA 约 $35，MemoryOS QA 约 $40，全部 judge 约 $110。预计总计约 $1150–1200 |
| 10-12 | A-Mem 完成：Haiku 56.23 / Opus 58.83。temporal 只有 32 / 29：不用 gold category 时，官方默认 prompt 没有“Use DATE of CONVERSATION”这句，模型常答相对时间。总计 $299.1（超出部分已批准）|
| 10-12 | Mem0 完成（adapted，用论文对应的 v0.1.94 版本）：Haiku 68.83 / Opus 73.57。总成本 $205.0 |
| 10-12 | MemoryOS 完成（official）：Haiku 65.71 / Opus 66.36。总成本 $135.5。**8 个方法全部拿到实测结果**（MRAgent 只有 Haiku）。SimpleMem 的 notes 待补交 |
| 10-12 | SimpleMem 的 notes 已交（adapted）：Haiku 78.25 / Opus 81.17。**全部完成** |
| 10-12 | §4 补全为完整结果：10 个系统 × Haiku/Opus × LLM-judge/F1/BLEU-1 × 4 个类别 + overall，另加 Mem0/LightMem 只截取最终答案的分类别 F1/BLEU-1（§4.5）；后面的结论、可比性说明改为 §4.6、§4.7 |

---


### 5.1 成本汇总（不含 judge；按 us. 价格计算，是上限）

| 方法 | 建库（Opus） | Haiku QA | Opus QA | smoke 及作废的轮次 | **合计** |
|---|---:|---:|---:|---:|---:|
| Mem0 | $160.9 | $6.6 | $30.5 | $7.0 | **$205.0** |
| A-Mem | $179.9 | $11.4 | $57.7 | $50.0（作废的无 instruction 轮次 + smoke） | **$299.1** |
| MemoryOS | $52.7 | $11.9 | $70.2 | $0.7 | **$135.5** |
| LightMem | $25.3 | $5.9 | $25.6 | $1.7 | **$58.5** |
| SimpleMem | $13.4 | $16.5（第二次） | $102.3 | $30.7（smoke + 第一次 Haiku，因网关重启重跑） | **$162.9** |
| MemR³ | ≈$0（只用 embedding） | $13.5 | $54.1 | $0.4 | **$68.0** |
| MemGAS | $3.8 | $9.0 | $41.5 | $0.6 | **$54.9** |
| MRAgent | $57.7 | $63.1 | —（未跑） | $16.4（smoke + 40 题 Opus pilot） | **$137.2** |
| **合计** | | | | | **$1121.0** |

另外，judge（Opus 4.5）共 19,181 次调用，约 **$89**。**全部总计约 $1210。**

---

## 6. 复现命令

```bash
source develop/env.sh
develop/baselines/gateway/start.sh                 # 启动共享 Bedrock 网关
$PY develop/baselines/gateway/usage.py [method]    # 查看用量和成本
# 各方法的命令见 develop/baselines/notes/<method>.md
```
