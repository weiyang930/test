# Exp 2（RQ2）：从记忆相关性到证据充分性（2026-10-12）

> **研究问题**：为什么检索到“相关”的记忆，仍然不足以提供回答所需的证据？VMem 如何改善证据恢复？
> **性质**：纯离线诊断。不重建记忆、不重新生成答案、不重新调用 judge；只读取已有的预测、检索 trace 和 judge 标签（`metrics.json`）。gold evidence 只用于离线诊断，从未进入任何推理。
> **对象**：NEMORI vs. VMem-v2.3-clean（主比较，Opus 4.5 与 Haiku 4.5 两个 backbone 都有完整 trace）；MemR³、MRAgent、SimpleMem 在 provenance 允许的范围内纳入。
> **相关文档**：方法与主结果 `2026-10-11_vmem2_method_and_results.md`；基线 `2026-10-11_vmem_baselines.md`；主表 `2026-10-11_exp1_main_results.md`。
> **代码与数据**：`develop/exp2/`（脚本、CSV/JSON 表、作图数据），复现命令见 §10。本文所有表格由 `exp2/analyze.py` 生成，再由 `exp2/build_report.py` 填入本文。

---

## 0. 主要发现（只依据下文的实测表格；除特别说明外数字为 Opus 4.5，括号内为 Haiku 4.5）

1. **“检索到相关记忆”≠“证据对作答模型可见”。** NEMORI 检索到的 10 个 episode 中，包含全部 gold turn 的题占 68.8%（R complete）。但 gold 原文在作答 prompt 里逐字可见的只有 16.2%（V complete）；gold turn 级的召回率分别为 74.8% 和 19.8%。原因是 NEMORI 只打印 top-2 episode 的原文，其余 8 个 episode 只给出摘要。Multi-hop 上差距最大：R complete 31.5%，V complete 只有 1.8%。（§2）
2. **VMem 把证据覆盖从“相关”提升到“完整可见”。** VMem 的 V complete 为 91.7%（91.6%），R complete 92.8%（93.5%），卡片引用了全部 gold turn 的题占 86.6%（83.3%）。gold 证据跨 ≥2 个 session 的题上，NEMORI 的 V complete 只有 0.3%，VMem 为 68.8%（70.0%）。（§2）
3. **VMem 的收益几乎全部来自 NEMORI 检索缺证据的题。** 按 NEMORI 的 R 状态分组：
   - R complete（68.8% 的题）：VMem 相对 NEMORI 只有 +0.3 pp，95% CI [−1.0, +1.6]（Haiku 下 +2.1，[+0.7, +3.6]）。
   - R partial：+24.2 pp。R missing：+40.0 pp。
   - 这两组只占 31.2% 的题，却贡献了 98.2%（89.1%）的净胜题。
   - 只看 VMem 开发期间从未查看的 holdout，结论不变：R complete 组 +0.1 pp，净收益的 99.3% 来自 R 不完整的题。（§3.2、§3.3）
4. **NEMORI 检索记录里已有证据时，只看到摘要通常也够用。** NEMORI R complete 但原文不完整可见的 806 题上，NEMORI 准确率 92.7%，VMem 只高 +0.5 pp（不显著）。但在较弱的 Haiku 上，原文带来 +2.6 pp（p = 0.0075）。所以主要瓶颈是“证据有没有被找到”，“摘要还是原文”是次要因素，而且这个因素的大小取决于作答模型。（§3.3）
5. **证据可得性与正确率强相关（观察性）。** NEMORI 按 R 状态的准确率：complete 93.4%，partial 61.0%，missing 47.5%。VMem 按卡片引用状态（C）：complete 94.0%，partial 80.0%，missing 63.3%。这是相关关系，不是因果：覆盖状态和问题难度、问题类别是混杂的。（§3.4）
6. **证据缺口最大的是跨 session、多证据、需要聚合的问题。** 以 gold 证据跨 ≥2 个 session 的列表/计数题（n = 233）为例：
   - NEMORI R complete 28.3%，V complete 0.0%；VMem R 75.5%，V 72.1%，C 57.9%。
   - 准确率从 60.9% 升到 83.3%（+22.3 pp）。
   - 相对时间表达只出现在 gold 原文中（需要按 session 日期解析）的 Temporal 题：+15.8 pp。gold 原文没有相对时间表达的：+5.5 pp（n = 73，CI 跨 0）。（§4）
7. **VMem 之后，瓶颈从“证据可得”转向“证据使用”。** 两种方法各自的错误中，gold turn 全部可见的占比：
   - VMem：76.3%（81.8%）；其中 80%（80%）的卡片已经引用了全部 gold turn。
   - NEMORI：只有 3.7%（4.7%）。
   - 这些 VMem 错误中，NEMORI 在 74/100 题上也答错，说明有相当一部分是难题或标注有歧义。（§5）
8. **上下文量是一个不能离线排除的混杂因素。** VMem 平均每题给出 97 条原始 turn，NEMORI 只有 22 条。离线反事实：如果 NEMORI 把 10 个检索 episode 的原文全部打印（平均 79.5 条 turn），V complete 也只能到 68.8%；VMem 用 97 条 turn 达到 91.7%。可见 VMem 的覆盖率不只是“给得更多”的结果，但多给一些上下文确实有贡献。两者的贡献要靠消融实验才能分开，本实验没有做。（§2.3）
9. **强基线**：
   - MemR³ 检索到的原始 chunk 可以精确映射到 turn。gold turn 完整落在某个检索 chunk 内的题占 60.2%（multi-hop 只有 21.1%）。它最终作答的 prompt 里没有原始 turn，只有 LLM 提炼的证据要点。
   - MRAgent 引用的 supports 完整覆盖 gold 的占 76.7%（只有 Haiku），VMem 卡片为 83.3%。
   - SimpleMem 没有保存任何溯源信息，只能比较准确率。
   - 按 gold 定义的切片看，VMem 在多证据、跨 session 切片上准确率最高。但也有 VMem 不占优的切片：Opus 下 Open-domain 不如 MemR³（68.5 vs 75.0），Haiku 下 Single-hop 不如 MRAgent（93.1 vs 94.3）。（§6）
10. **VMem 没有改善、甚至变差的情况**（全部列出）：
    - NEMORI 原文已经完全可见的 248 题：Δ = −0.4 pp。
    - 其中 Single-hop：−1.2 pp。
    - 共 34 题（31 题）VMem 答错而 NEMORI 答对。其中 73.5% 的题 VMem 可见的 gold turn 也更多，说明更多证据不保证答对。（§3、§7）

---

## 1. 定义、匹配协议与数据来源

### 1.1 数据来源（全部为已有结果）

| 方法 | backbone | 预测与 trace | judge 标签 |
|---|---|---|---|
| NEMORI | Opus 4.5 | `runs/nemori_full/results.json`（每题 10 个 episode 和 20 条 semantic 的 id；top-2 episode 的 `source_messages`） | 同目录 `metrics.json` |
| NEMORI | Haiku 4.5 | `runs/haiku45_nemori_{dev,holdout}/results.json`（检索与 Opus 逐题相同，已核对） | 同目录 |
| VMem-v2.3-clean | Opus 4.5 | `runs/vmem2_v3clean_{dev,holdout}/results.json`，`trace.pool_ids`（episode / semantic / turn / cited_turn）与 `trace.cards` | 同目录 |
| VMem-v2.3-clean | Haiku 4.5 | `runs/haiku45_vmem2_{dev,holdout}/results.json` | 同目录 |
| MemR³ | 两者 | `baselines/runs/memr3/{opus,haiku}/results.json` 的 `retrieval_history`（每轮 5 个 chunk 的编号） | 同目录 |
| MRAgent | 只有 Haiku | `baselines/runs/mragent/haiku/results.json` 的 `supports`（LLM 引用的 dia_id） | 同目录 |
| SimpleMem | 两者 | 只有回答，没有检索记录 | 同目录 |
| 记忆库 | — | NEMORI store（agent `locomo_opus45`，631 个 episode），从 `/path/to/vmem_backup/nemori_opus45_pg.dump` 恢复到临时 Postgres 后导出为 `exp2/data/store_snapshot.json`（只读） | — |
| gold 证据 | — | LoCoMo `locomo10.json` 的 `evidence`（dia_id，如 `D3:5`） | — |

NEMORI 和 VMem 共用同一份 NEMORI 记忆库。所以两者的 episode id 和原始消息 id 处在同一个空间，可以用完全相同的定义比较。

### 1.2 gold turn → 记忆库消息的精确映射（不使用模糊匹配）

NEMORI 的 `add.py` 把每个 LoCoMo turn 存成一条消息，`content = text [+ " [Image: <blip_caption>]"] [+ " [Search: <query>]"]`，`role = speaker`。映射规则：
1. 按同样规则重建每个 turn 的消息文本，与 episode 的 `source_messages` 做**字符串完全相等**匹配，键为（role, content）。部分 content 以 JSON 字符串形式存储（带外层引号和 `\"`、`\n` 转义），先用 `json.loads` 精确解码。
2. 同一段对话里文本完全相同、出现多次的 turn（4 个），用 session 时间戳消歧。
3. VMem 按（timestamp, role, content）对 turn 去重，只保留第一个 message_id。为了不依赖数据库的行顺序，同一去重键下的所有 message_id 都算作该 turn 的别名。
4. 结果：5882 个 LoCoMo turn 中，5876 个精确映射；6 个在 NEMORI 记忆库中**不存在**（ingestion 时丢失）：conv-26 D14:18，conv-42 D19:20、D22:15，conv-44 D26:7，conv-48 D20:5，conv-50 D21:9。

**sanity check**（`exp2/sanity_checks.py` → `exp2/tables/sanity_checks.json`）：
- NEMORI 与 VMem trace 中所有的 episode / semantic / turn id，100% 能在记忆库中找到。
- NEMORI 每题都只在 top-2 episode 上附带原文。
- VMem 卡片的来源标签（`T<k>`）按 pool 顺序解析回 turn id 后，已验证的单来源卡片中，Opus 5664/5672（99.9%）、Haiku 5562/5599（99.3%）的引文确实出现在解析出的 turn 原文中，说明标签解析正确。

### 1.3 覆盖度量（严格区分“检索记录包含”与“作答 prompt 可见”）

对每道题的每个 gold turn 判断下列状态，再汇总为题级的 **complete**（全部 gold turn 满足）、**partial**（部分满足）、**missing**（都不满足）。

| 记号 | 名称 | NEMORI | VMem |
|---|---|---|---|
| **R** | 检索记录包含（record-level，溯源精确到 turn） | gold turn 属于 10 个检索 episode 之一（这些 episode 的摘要在 prompt 中；原文只有 top-2 才打印） | gold turn 属于检索到的 episode，或本身就在原始 turn pool / cited turn 中 |
| **V** | 原始 turn 在**最终作答 prompt** 中逐字可见 | gold turn 属于 top-2 episode（`Source Messages:` 被打印） | gold turn 在 turn pool 或 cited source turn 中。VMem 设置 `include_pool_in_answer=True`，整个 pool 都进入作答 prompt |
| **C** | 被证据卡片引用（仅 VMem） | — | 某张卡片的来源是该 turn（`T<k>`），或是包含它的 episode（`E<k>`） |
| **S**（补充） | 检索到的 semantic 记忆来自该 turn 所在的 episode | 只有 episode 级溯源，**不计入** turn 级覆盖，只作补充 | 同左 |

- R 与 V 是两个不同的概念，全文不混用：R complete 但 V 不完整，表示作答模型只看到抽象摘要，看不到原文。
- semantic 记忆没有 turn 级溯源，只能追到来源 episode，所以不计入 R/V。
- MemR³ 等基线的度量定义见 §6.1。

### 1.4 分母与不可映射的题

共 1540 题（cat 1–4）。gold evidence 全部能精确映射的题：**1531**；部分可映射：4；完全不可映射：5。主分析的分母是全部可映射的 1531 题；另外 9 题单独列出（`exp2/tables/denominators.json`），附录 A 给出把它们按已映射 turn 计入后的敏感性分析。

| 类别 | 题数 | 全部可映射 |
|---|---:|---:|
| Multi-hop | 282 | 279 |
| Temporal | 321 | 320 |
| Open-domain | 96 | 92 |
| Single-hop | 841 | 840 |

不可映射原因：

| conv | 问题 | gold | 格式错误的 id | 记忆库中不存在的 turn |
|---|---:|---:|---:|---:|
| conv-26 | Would Melanie be considered a member of the LGBTQ community? |  | — | — |
| conv-26 | Would Melanie be considered an ally to the transgender community? |  | — | — |
| conv-42 | What is one of Joanna's favorite movies? | D1:18,D,D1:20 | D | — |
| conv-42 | What things has Nate reccomended to Joanna? | D2:14,D9:12,D9:14,D10:11,D19:17,D27:23,D10:19 | D10:19 | — |
| conv-43 | What authors has Tim read books from? | D1:14,D2:7,D4:7,D5:15,D:11:26,D20:21,D26:36 | D:11:26 | — |
| conv-47 | What happened to John's job situation in 2022? | D4:36,D18:1,D18:7 | D4:36 | — |
| conv-50 | Based on the conversation, did Calvin and Dave have a meeting in Bosto |  | — | — |
| conv-50 | When did Dave buy a vintage camera? | D30:05 | D30:05 | — |
| conv-50 | Would Dave prefer working on a Dodge Charger or a Subaru Forester? |  | — | — |

### 1.5 题目分组（全部由 gold 标注或问题文本定义，与模型表现无关）

- **类别**：LoCoMo cat 1–4（Multi-hop / Temporal / Open-domain / Single-hop）。
- **gold turn 数**：1 / 2 / 3+。
- **跨 session**：gold turn 分布在 1 个或 ≥2 个 session。**跨 episode**：gold turn 属于 1 个或 ≥2 个 NEMORI episode。
- **列表/计数**：问题包含 how many / how often / number of / how much，或 gold 答案按逗号、分号、and 切分后 ≥ 2 项。这是基于文本规则的近似分组，规则见 `analyze.py: features`。
- **Temporal 相对时间**：Temporal 类中，gold turn 原文是否含相对时间表达（yesterday、last week、two days ago 等，正则见 `REL_TIME`）。含有时，答案需要按 session 日期解析，也就是需要 source 级的时间信息。

---

## 2. 证据覆盖

### 2.1 Opus 4.5（按类别）

**R：检索记录包含（episode 原文消息或原始 turn），Opus 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 31.5 / 53.0 / 15.4 | 75.6 / 4.7 / 19.7 | 38.0 / 20.6 / 41.3 | 82.0 / 0.0 / 18.0 | 68.8 / 11.9 / 19.3 | 74.84 |
| VMem | 74.9 / 24.0 / 1.1 | 97.8 / 0.9 / 1.2 | 69.6 / 20.6 / 9.8 | 99.4 / 0.0 / 0.6 | 92.8 / 5.8 / 1.4 | 96.19 |

**V：原始 turn 在作答 prompt 中逐字可见，Opus 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 1.8 / 41.6 / 56.6 | 19.7 / 2.5 / 77.8 | 8.7 / 7.6 / 83.7 | 20.5 / 0.0 / 79.5 | 16.2 / 8.6 / 75.2 | 19.77 |
| VMem | 72.0 / 26.9 / 1.1 | 96.9 / 1.6 / 1.6 | 66.3 / 20.6 / 13.0 | 99.0 / 0.0 / 0.9 | 91.7 / 6.5 / 1.8 | 95.38 |

**C：被证据卡片直接引用（仅 VMem），Opus 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| VMem | 58.4 / 39.4 / 2.1 | 94.1 / 3.4 / 2.5 | 57.6 / 20.6 / 21.7 | 96.3 / 0.6 / 3.1 | 86.6 / 9.5 / 3.9 | — |

**R+S（补充）：R，或某条检索到的 semantic 记忆来自该 turn 所在 episode，Opus 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 60.2 / 35.8 / 3.9 | 90.9 / 2.8 / 6.2 | 60.9 / 20.6 / 18.5 | 94.3 / 0.1 / 5.6 | 85.4 / 8.4 / 6.2 | — |
| VMem | 81.7 / 17.9 / 0.4 | 98.1 / 0.9 / 0.9 | 69.6 / 22.8 / 7.6 | 99.5 / 0.0 / 0.5 | 94.2 / 4.8 / 1.0 | — |

### 2.2 Haiku 4.5（按类别）

NEMORI 的检索与 backbone 无关（两次运行逐题相同），所以 NEMORI 的数字和 Opus 一样。VMem 的 planner 和证据构造用的是 Haiku，pool 会不同。

**R：检索记录包含（episode 原文消息或原始 turn），Haiku 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 31.5 / 53.0 / 15.4 | 75.6 / 4.7 / 19.7 | 38.0 / 20.6 / 41.3 | 82.0 / 0.0 / 18.0 | 68.8 / 11.9 / 19.3 | 74.84 |
| VMem | 78.8 / 20.4 / 0.7 | 97.8 / 0.9 / 1.2 | 70.7 / 21.7 / 7.6 | 99.3 / 0.0 / 0.7 | 93.5 / 5.2 / 1.2 | 96.67 |

**V：原始 turn 在作答 prompt 中逐字可见，Haiku 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 1.8 / 41.6 / 56.6 | 19.7 / 2.5 / 77.8 | 8.7 / 7.6 / 83.7 | 20.5 / 0.0 / 79.5 | 16.2 / 8.6 / 75.2 | 19.77 |
| VMem | 72.8 / 26.2 / 1.1 | 95.9 / 2.2 / 1.9 | 69.6 / 21.7 / 8.7 | 98.7 / 0.0 / 1.3 | 91.6 / 6.5 / 1.8 | 95.34 |

**C：被证据卡片直接引用（仅 VMem），Haiku 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| VMem | 49.5 / 46.6 / 3.9 | 90.9 / 3.8 / 5.3 | 59.8 / 19.6 / 20.6 | 94.2 / 1.2 / 4.6 | 83.3 / 11.1 / 5.6 | — |

**R+S（补充）：R，或某条检索到的 semantic 记忆来自该 turn 所在 episode，Haiku 4.5**（complete / partial / missing，%；turn recall = 被覆盖的 gold turn 占比）

| 方法 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M | Overall turn recall |
|---|---:|---:|---:|---:|---:|---:|
| NEMORI | 60.2 / 35.8 / 3.9 | 90.9 / 2.8 / 6.2 | 60.9 / 20.6 / 18.5 | 94.3 / 0.1 / 5.6 | 85.4 / 8.4 / 6.2 | — |
| VMem | 85.3 / 14.3 / 0.4 | 98.1 / 0.9 / 0.9 | 73.9 / 20.6 / 5.4 | 99.4 / 0.0 / 0.6 | 95.0 / 4.0 / 0.9 | — |

### 2.3 上下文量（解释覆盖率时需要考虑）

| 方法 | backbone | 平均可见原始 turn 数 / 题 | 平均 prompt tokens / 题（所有调用之和） |
|---|---:|---:|---:|
| NEMORI | opus | 22.0 | 5186 |
| VMem | opus | 97.2 | 20499 |
| NEMORI | haiku | 22.0 | 5186 |
| VMem | haiku | 113.3 | 23003 |

离线反事实（不需要推理）：假设 NEMORI 把 10 个检索 episode 的原文全部打印，可见原文的覆盖率就等于它的 R。

| 设置 | backbone | 平均原始 turn 数 / 题 | complete / partial / missing %（原始 turn 可见） |
|---|---:|---:|---:|
| NEMORI（实际：top-2 episode 原文） | opus | 22.1 | 16.2 / 8.6 / 75.2 |
| NEMORI（假设：10 个检索 episode 原文全部打印） | opus | 79.5 | 68.8 / 11.9 / 19.3 |
| VMem（实际） | opus | 97.1 | 91.7 / 6.5 / 1.8 |
| VMem（实际） | haiku | 113.0 | 91.6 / 6.5 / 1.8 |

- “所有原文都打印”的 NEMORI 平均 79.5 条 turn，V complete 68.8%；VMem 平均 97 条 turn，V complete 91.7%。所以 VMem 的覆盖率优势不只是多给了上下文：在相近的量级上，VMem 选出的 turn 覆盖了更多 gold。
- 但这个反事实没有改变 NEMORI 的检索。要真正把上下文量和检索策略的贡献分开，需要消融实验（例如限制 VMem 的 turn 预算），本实验没有做。

VMem 中 gold turn 是从哪一层进入 prompt 的（turn 级，所有可映射的 gold turn）：

| backbone | gold turn 数 | 原文可见 % | 被卡片直接以原始 turn 引用 % | 被卡片引用（turn 或其 episode）% | 只有 episode 摘要 % | 完全没检索到 % |
|---|---:|---:|---:|---:|---:|---:|
| opus | 2342 | 90.4 | 77.1 | 84.5 | 1.7 | 7.9 |
| haiku | 2342 | 91.1 | 73.1 | 82.1 | 2.3 | 6.6 |

---

## 3. 证据可得性与答案正确性

所有比较都在同一批题上进行（同一题号、同一组预测、同一 judge 标签）。Δ = VMem − NEMORI。95% CI 为 paired bootstrap（5000 次重采样），W/L/T = VMem 胜 / 负 / 平，p 为 exact McNemar。

### 3.1 按 NEMORI 的 V 状态分组

**按 NEMORI 的 V（原始 turn 可见） 分组，Opus 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| complete | 248 | 16.2 | 95.6 | 95.2 | -0.4 | [-3.2, +2.0] | 5/6/237 | 1 |
| partial | 131 | 8.6 | 68.7 | 87.0 | +18.3 | [+10.7, +26.7] | 29/5/97 | <1e-4 |
| missing | 1152 | 75.2 | 78.8 | 91.1 | +12.3 | [+10.2, +14.6] | 165/23/964 | <1e-4 |
| 合计 | 1531 | 100.0 | 80.7 | 91.4 | +10.8 | [+8.9, +12.6] | 199/34/1298 | <1e-4 |

**按 NEMORI 的 V（原始 turn 可见） 分组，Haiku 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| complete | 248 | 16.2 | 93.1 | 93.5 | +0.4 | [-2.0, +2.8] | 5/4/239 | 1 |
| partial | 131 | 8.6 | 68.7 | 86.3 | +17.6 | [+10.7, +25.2] | 25/2/104 | <1e-4 |
| missing | 1152 | 75.2 | 73.7 | 89.1 | +15.5 | [+13.1, +18.0] | 203/25/924 | <1e-4 |
| 合计 | 1531 | 100.0 | 76.4 | 89.6 | +13.2 | [+11.2, +15.2] | 233/31/1267 | <1e-4 |

- NEMORI 的 V-missing 组（75.2% 的题）准确率是 78.8%，反而比 V-partial 组（68.7%）高。原因是 V-missing 中有大量题的证据已经出现在检索到的 episode 摘要里（见 §3.3），而 V-partial 几乎全是 Multi-hop（116/131）。
- 所以只看 V 会把“完全没检索到”和“只看到摘要”混在一起，R 才是更有区分度的度量。

### 3.2 按 NEMORI 的 R 状态分组（主结果）

**按 NEMORI 的 R（检索记录包含） 分组，Opus 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| complete | 1054 | 68.8 | 93.4 | 93.6 | +0.3 | [-1.0, +1.6] | 27/24/1003 | 0.78 |
| partial | 182 | 11.9 | 61.0 | 85.2 | +24.2 | [+16.5, +31.9] | 51/7/124 | <1e-4 |
| missing | 295 | 19.3 | 47.5 | 87.5 | +40.0 | [+34.2, +45.8] | 121/3/171 | <1e-4 |
| 合计 | 1531 | 100.0 | 80.7 | 91.4 | +10.8 | [+8.9, +12.6] | 199/34/1298 | <1e-4 |

**按 NEMORI 的 R（检索记录包含） 分组，Haiku 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| complete | 1054 | 68.8 | 90.4 | 92.5 | +2.1 | [+0.7, +3.6] | 44/22/988 | 0.00921 |
| partial | 182 | 11.9 | 59.9 | 81.9 | +22.0 | [+15.4, +29.1] | 45/5/132 | <1e-4 |
| missing | 295 | 19.3 | 36.6 | 84.1 | +47.5 | [+41.4, +53.6] | 144/4/147 | <1e-4 |
| 合计 | 1531 | 100.0 | 76.4 | 89.6 | +13.2 | [+11.2, +15.2] | 233/31/1267 | <1e-4 |

**只看 holdout**（8 段对话，VMem 开发期间从未查看）：

| backbone | 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p | 占净胜题 % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| opus | NEMORI R complete | 823 | 67.0 | 93.4 | 93.6 | +0.1 | [-1.3, +1.5] | 19/18/786 | 1 | 0.7 |
| opus | NEMORI R partial | 147 | 12.0 | 59.2 | 83.0 | +23.8 | [+15.6, +32.0] | 41/6/100 | <1e-4 | 25.4 |
| opus | NEMORI R missing | 259 | 21.1 | 47.9 | 87.3 | +39.4 | [+33.2, +45.6] | 104/2/153 | <1e-4 | 73.9 |
| opus | 合计（holdout） | 1229 | 100.0 | 79.7 | 91.0 | +11.2 | [+9.1, +13.3] | 164/26/1039 | <1e-4 | 100.0 |
| haiku | NEMORI R complete | 823 | 67.0 | 90.3 | 92.2 | +1.9 | [+0.2, +3.6] | 34/18/771 | 0.0365 | 9.8 |
| haiku | NEMORI R partial | 147 | 12.0 | 59.9 | 78.2 | +18.4 | [+10.9, +25.9] | 32/5/110 | <1e-4 | 16.5 |
| haiku | NEMORI R missing | 259 | 21.1 | 36.7 | 83.4 | +46.7 | [+40.2, +52.9] | 124/3/132 | <1e-4 | 73.8 |
| haiku | 合计（holdout） | 1229 | 100.0 | 75.3 | 88.7 | +13.3 | [+11.1, +15.5] | 190/26/1013 | <1e-4 | 100.0 |

### 3.3 R×V 组合与净收益分解

**按 NEMORI 的 R×V 组合分组，Opus 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p | 占净胜题 % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| R complete · 原文可见（V complete） | 248 | 16.2 | 95.6 | 95.2 | -0.4 | [-3.2, +2.0] | 5/6/237 | 1 | -0.6 |
| R complete · 部分/全部只有摘要（V 不完整） | 806 | 52.6 | 92.7 | 93.2 | +0.5 | [-1.0, +2.1] | 22/18/766 | 0.636 | 2.4 |
| R partial | 182 | 11.9 | 61.0 | 85.2 | +24.2 | [+16.5, +31.9] | 51/7/124 | <1e-4 | 26.7 |
| R missing | 295 | 19.3 | 47.5 | 87.5 | +40.0 | [+34.2, +45.8] | 121/3/171 | <1e-4 | 71.5 |
| 合计 | 1531 | 100.0 | 80.7 | 91.4 | +10.8 | [+8.9, +12.6] | 199/34/1298 | <1e-4 | 100.0 |

**按 NEMORI 的 R×V 组合分组，Haiku 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p | 占净胜题 % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| R complete · 原文可见（V complete） | 248 | 16.2 | 93.1 | 93.5 | +0.4 | [-2.0, +2.8] | 5/4/239 | 1 | 0.5 |
| R complete · 部分/全部只有摘要（V 不完整） | 806 | 52.6 | 89.6 | 92.2 | +2.6 | [+0.9, +4.5] | 39/18/749 | 0.00751 | 10.4 |
| R partial | 182 | 11.9 | 59.9 | 81.9 | +22.0 | [+15.4, +29.1] | 45/5/132 | <1e-4 | 19.8 |
| R missing | 295 | 19.3 | 36.6 | 84.1 | +47.5 | [+41.4, +53.6] | 144/4/147 | <1e-4 | 69.3 |
| 合计 | 1531 | 100.0 | 76.4 | 89.6 | +13.2 | [+11.2, +15.2] | 233/31/1267 | <1e-4 | 100.0 |

- **R complete、原文可见**：两者几乎一样（−0.4 / +0.4 pp）。
- **R complete、只有摘要**：Opus 下 +0.5 pp，不显著；Haiku 下 +2.6 pp，p = 0.0075。原文对较弱的作答模型更重要。
- **R partial / missing**：+22 到 +48 pp，构成净收益的主体。

### 3.4 各方法按自身覆盖状态的准确率（观察性）

**各方法按自身覆盖状态的准确率，Opus 4.5**（观察性相关，非因果）

| 方法 | 度量 | 状态 | n | 准确率 % | Wilson 95% CI |
|---|---:|---:|---:|---:|---:|
| NEMORI | V | complete | 248 | 95.6 | [92.2, 97.5] |
| NEMORI | V | partial | 131 | 68.7 | [60.3, 76.0] |
| NEMORI | V | missing | 1152 | 78.8 | [76.4, 81.1] |
| NEMORI | R | complete | 1054 | 93.4 | [91.7, 94.7] |
| NEMORI | R | partial | 182 | 61.0 | [53.7, 67.8] |
| NEMORI | R | missing | 295 | 47.5 | [41.8, 53.2] |
| VMem | V | complete | 1404 | 92.9 | [91.4, 94.1] |
| VMem | V | partial | 99 | 79.8 | [70.8, 86.5] |
| VMem | V | missing | 28 | 60.7 | [42.4, 76.4] |
| VMem | R | complete | 1421 | 92.8 | [91.4, 94.1] |
| VMem | R | partial | 89 | 77.5 | [67.8, 85.0] |
| VMem | R | missing | 21 | 57.1 | [36.5, 75.5] |
| VMem | C | complete | 1326 | 94.0 | [92.6, 95.1] |
| VMem | C | partial | 145 | 80.0 | [72.8, 85.7] |
| VMem | C | missing | 60 | 63.3 | [50.7, 74.4] |

**各方法按自身覆盖状态的准确率，Haiku 4.5**（观察性相关，非因果）

| 方法 | 度量 | 状态 | n | 准确率 % | Wilson 95% CI |
|---|---:|---:|---:|---:|---:|
| NEMORI | V | complete | 248 | 93.1 | [89.3, 95.7] |
| NEMORI | V | partial | 131 | 68.7 | [60.3, 76.0] |
| NEMORI | V | missing | 1152 | 73.7 | [71.1, 76.2] |
| NEMORI | R | complete | 1054 | 90.4 | [88.5, 92.1] |
| NEMORI | R | partial | 182 | 59.9 | [52.6, 66.7] |
| NEMORI | R | missing | 295 | 36.6 | [31.3, 42.2] |
| VMem | V | complete | 1403 | 90.7 | [89.1, 92.1] |
| VMem | V | partial | 100 | 79.0 | [70.0, 85.8] |
| VMem | V | missing | 28 | 71.4 | [52.9, 84.7] |
| VMem | R | complete | 1432 | 90.5 | [88.9, 91.9] |
| VMem | R | partial | 80 | 78.8 | [68.6, 86.3] |
| VMem | R | missing | 19 | 68.4 | [46.0, 84.6] |
| VMem | C | complete | 1275 | 91.8 | [90.2, 93.2] |
| VMem | C | partial | 170 | 82.4 | [75.9, 87.3] |
| VMem | C | missing | 86 | 70.9 | [60.6, 79.5] |

### 3.5 NEMORI → VMem 的覆盖状态转移（V）

**NEMORI V 状态 → VMem V 状态的联合分布，以及两边的准确率，Opus 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| complete → complete | 247 | 16.1 | 95.5 | 95.1 | -0.4 | [-3.2, +2.0] | 5/6/236 | 1 |
| complete → missing | 1 | 0.1 | 100.0 | 100.0 | +0.0 | [+0.0, +0.0] | 0/0/1 | 1 |
| partial → complete | 97 | 6.3 | 71.1 | 89.7 | +18.6 | [+10.3, +26.8] | 20/2/75 | 0.000121 |
| partial → partial | 33 | 2.2 | 63.6 | 78.8 | +15.2 | [-3.0, +33.3] | 8/3/22 | 0.227 |
| partial → missing | 1 | 0.1 | 0.0 | 100.0 | +100.0 | [+100.0, +100.0] | 1/0/0 | 1 |
| missing → complete | 1060 | 69.2 | 79.8 | 92.6 | +12.8 | [+10.6, +15.2] | 154/18/888 | <1e-4 |
| missing → partial | 66 | 4.3 | 71.2 | 80.3 | +9.1 | [+0.0, +18.2] | 8/2/56 | 0.109 |
| missing → missing | 26 | 1.7 | 57.7 | 57.7 | +0.0 | [-19.2, +19.2] | 3/3/20 | 1 |

**NEMORI V 状态 → VMem V 状态的联合分布，以及两边的准确率，Haiku 4.5**

| 分组 | n | 占比 % | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| complete → complete | 245 | 16.0 | 93.5 | 93.5 | +0.0 | [-2.4, +2.4] | 4/4/237 | 1 |
| complete → missing | 3 | 0.2 | 66.7 | 100.0 | +33.3 | [+0.0, +100.0] | 1/0/2 | 1 |
| partial → complete | 97 | 6.3 | 71.1 | 88.7 | +17.5 | [+10.3, +25.8] | 17/0/80 | <1e-4 |
| partial → partial | 33 | 2.2 | 63.6 | 78.8 | +15.2 | [-3.0, +33.3] | 7/2/24 | 0.18 |
| partial → missing | 1 | 0.1 | 0.0 | 100.0 | +100.0 | [+100.0, +100.0] | 1/0/0 | 1 |
| missing → complete | 1061 | 69.3 | 75.1 | 90.3 | +15.2 | [+12.7, +17.6] | 184/23/854 | <1e-4 |
| missing → partial | 67 | 4.4 | 65.7 | 79.1 | +13.4 | [+3.0, +23.9] | 11/2/54 | 0.0225 |
| missing → missing | 24 | 1.6 | 33.3 | 66.7 | +33.3 | [+16.7, +50.0] | 8/0/16 | 0.00781 |

### 3.6 胜负分解（按 gold turn 可见比例的变化）

**VMem 相对 NEMORI 的逐题胜负，按 gold turn 可见比例的变化分解，Opus 4.5**（共 1531 题；胜 199，负 34，净 +165）

| 结果 | 可见性变化 | 题数 | 占该结果 % |
|---|---:|---:|---:|
| VMem 胜（NEMORI 错 → VMem 对） | VMem 可见的 gold turn 更多（证据恢复） | 190 | 95.5 |
| VMem 胜（NEMORI 错 → VMem 对） | 两者可见程度相同 | 8 | 4.0 |
| VMem 胜（NEMORI 错 → VMem 对） | VMem 可见的 gold turn 更少 | 1 | 0.5 |
| VMem 胜（NEMORI 错 → VMem 对） |   其中“相同”：两者都 complete / 都 partial / 都 missing | 5 / 0 / 3 |  |
| VMem 负（NEMORI 对 → VMem 错） | VMem 可见的 gold turn 更多（证据恢复） | 25 | 73.5 |
| VMem 负（NEMORI 对 → VMem 错） | 两者可见程度相同 | 9 | 26.5 |
| VMem 负（NEMORI 对 → VMem 错） | VMem 可见的 gold turn 更少 | 0 | 0.0 |
| VMem 负（NEMORI 对 → VMem 错） |   其中“相同”：两者都 complete / 都 partial / 都 missing | 6 / 0 / 3 |  |

净胜 165 题中，可见性提升的题贡献净 165 题（100.0%），可见性不变或下降的题贡献净 0 题。

**VMem 相对 NEMORI 的逐题胜负，按 gold turn 可见比例的变化分解，Haiku 4.5**（共 1531 题；胜 233，负 31，净 +202）

| 结果 | 可见性变化 | 题数 | 占该结果 % |
|---|---:|---:|---:|
| VMem 胜（NEMORI 错 → VMem 对） | VMem 可见的 gold turn 更多（证据恢复） | 218 | 93.6 |
| VMem 胜（NEMORI 错 → VMem 对） | 两者可见程度相同 | 13 | 5.6 |
| VMem 胜（NEMORI 错 → VMem 对） | VMem 可见的 gold turn 更少 | 2 | 0.9 |
| VMem 胜（NEMORI 错 → VMem 对） |   其中“相同”：两者都 complete / 都 partial / 都 missing | 4 / 1 / 8 |  |
| VMem 负（NEMORI 对 → VMem 错） | VMem 可见的 gold turn 更多（证据恢复） | 26 | 83.9 |
| VMem 负（NEMORI 对 → VMem 错） | 两者可见程度相同 | 5 | 16.1 |
| VMem 负（NEMORI 对 → VMem 错） | VMem 可见的 gold turn 更少 | 0 | 0.0 |
| VMem 负（NEMORI 对 → VMem 错） |   其中“相同”：两者都 complete / 都 partial / 都 missing | 4 / 1 / 0 |  |

净胜 202 题中，可见性提升的题贡献净 192 题（95.0%），可见性不变或下降的题贡献净 10 题。

**基线比例**：VMem 在绝大多数题上都看得更多，所以上面的分解要和基线比例对照着读。

| backbone | 题组 | n | VMem 可见 gold turn 更多 % | 相同 % | 更少 % |
|---|---:|---:|---:|---:|---:|
| opus | 全部题 | 1531 | 81.6 | 18.2 | 0.1 |
| opus | VMem 胜 | 199 | 95.5 | 4.0 | 0.5 |
| opus | VMem 负 | 34 | 73.5 | 26.5 | 0.0 |
| opus | 两者都对 | 1201 | 79.3 | 20.6 | 0.1 |
| opus | 两者都错 | 97 | 85.6 | 14.4 | 0.0 |
| haiku | 全部题 | 1531 | 81.6 | 18.1 | 0.3 |
| haiku | VMem 胜 | 233 | 93.6 | 5.6 | 0.9 |
| haiku | VMem 负 | 31 | 83.9 | 16.1 | 0.0 |
| haiku | 两者都对 | 1139 | 78.8 | 20.9 | 0.3 |
| haiku | 两者都错 | 128 | 83.6 | 16.4 | 0.0 |

- VMem 胜的题中，95.5% 的题 VMem 可见的 gold turn 更多；全部题的基线比例是 81.6%，负的题是 73.5%。
- “可见性提升”在胜题中显著富集，但在负题中同样普遍，所以它不足以解释胜负。§3.2、§3.3 按 NEMORI 自身检索状态分组的结果更有说服力：只要 NEMORI 已经检索到全部证据，VMem 就几乎没有收益。

### 3.7 分类别 × NEMORI V 状态

**按 NEMORI 的 V 状态 × 类别分组，Opus 4.5**

| 分组 | n | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|
| Multi-hop · complete | 5 | 100.0 | 100.0 | +0.0 | [+0.0, +0.0] | 0/0/5 | 1 |
| Multi-hop · partial | 116 | 69.0 | 87.9 | +19.0 | [+10.3, +27.6] | 26/4/86 | <1e-4 |
| Multi-hop · missing | 158 | 71.5 | 88.6 | +17.1 | [+10.1, +24.7] | 33/6/119 | <1e-4 |
| Temporal · complete | 63 | 95.2 | 96.8 | +1.6 | [-3.2, +6.3] | 2/1/60 | 1 |
| Temporal · partial | 8 | 87.5 | 87.5 | +0.0 | [+0.0, +0.0] | 0/0/8 | 1 |
| Temporal · missing | 249 | 73.1 | 90.0 | +16.9 | [+11.6, +22.5] | 48/6/195 | <1e-4 |
| Open-domain · complete | 8 | 62.5 | 62.5 | +0.0 | [+0.0, +0.0] | 0/0/8 | 1 |
| Open-domain · partial | 7 | 42.9 | 71.4 | +28.6 | [-28.6, +71.4] | 3/1/3 | 0.625 |
| Open-domain · missing | 77 | 61.0 | 68.8 | +7.8 | [+0.0, +15.6] | 8/2/67 | 0.109 |
| Single-hop · complete | 172 | 97.1 | 95.9 | -1.2 | [-4.7, +1.7] | 3/5/164 | 0.727 |
| Single-hop · partial | 0 | — | — | +nan | [+nan, +nan] | 0/0/0 | 1 |
| Single-hop · missing | 668 | 84.7 | 94.8 | +10.0 | [+7.5, +12.7] | 76/9/583 | <1e-4 |

**按 NEMORI 的 V 状态 × 类别分组，Haiku 4.5**

| 分组 | n | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|
| Multi-hop · complete | 5 | 100.0 | 100.0 | +0.0 | [+0.0, +0.0] | 0/0/5 | 1 |
| Multi-hop · partial | 116 | 72.4 | 88.8 | +16.4 | [+9.5, +24.1] | 21/2/93 | <1e-4 |
| Multi-hop · missing | 158 | 66.5 | 85.4 | +19.0 | [+12.0, +26.6] | 35/5/118 | <1e-4 |
| Temporal · complete | 63 | 90.5 | 93.7 | +3.2 | [+0.0, +7.9] | 2/0/61 | 0.5 |
| Temporal · partial | 8 | 50.0 | 75.0 | +25.0 | [+0.0, +62.5] | 2/0/6 | 0.5 |
| Temporal · missing | 249 | 67.5 | 88.4 | +20.9 | [+15.3, +26.5] | 56/4/189 | <1e-4 |
| Open-domain · complete | 8 | 62.5 | 62.5 | +0.0 | [+0.0, +0.0] | 0/0/8 | 1 |
| Open-domain · partial | 7 | 28.6 | 57.1 | +28.6 | [+0.0, +57.1] | 2/0/5 | 0.5 |
| Open-domain · missing | 77 | 48.1 | 68.8 | +20.8 | [+10.4, +31.2] | 19/3/55 | 0.000855 |
| Single-hop · complete | 172 | 95.3 | 94.8 | -0.6 | [-3.5, +2.3] | 3/4/165 | 1 |
| Single-hop · partial | 0 | — | — | +nan | [+nan, +nan] | 0/0/0 | 1 |
| Single-hop · missing | 668 | 80.7 | 92.7 | +12.0 | [+9.1, +15.0] | 93/13/562 | <1e-4 |

---

## 4. 不同问题类型的证据恢复

**按 gold 定义的问题类型：覆盖率（complete %）与准确率，Opus 4.5**

| 切片 | 组 | n | NEMORI R | NEMORI V | VMem R | VMem V | VMem C | NEMORI 准确率 | VMem 准确率 | Δ | 95% CI | W/L |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 类别 | Multi-hop | 279 | 31.5 | 1.8 | 74.9 | 72.0 | 58.4 | 71.0 | 88.5 | +17.6 | [+12.2, +22.9] | 59/10 |
| 类别 | Open-domain | 92 | 38.0 | 8.7 | 69.6 | 66.3 | 57.6 | 59.8 | 68.5 | +8.7 | [+1.1, +16.3] | 11/3 |
| 类别 | Single-hop | 840 | 82.0 | 20.5 | 99.4 | 99.0 | 96.3 | 87.3 | 95.0 | +7.7 | [+5.6, +9.9] | 79/14 |
| 类别 | Temporal | 320 | 75.6 | 19.7 | 97.8 | 96.9 | 94.1 | 77.8 | 91.2 | +13.4 | [+9.1, +17.8] | 50/7 |
| gold evidence turn 数 | 1 | 1122 | 80.3 | 21.1 | 98.8 | 98.4 | 96.3 | 84.8 | 94.0 | +9.3 | [+7.3, +11.3] | 123/19 |
| gold evidence turn 数 | 2 | 227 | 49.3 | 4.4 | 88.5 | 87.7 | 77.1 | 73.6 | 85.9 | +12.3 | [+7.0, +18.1] | 36/8 |
| gold evidence turn 数 | 3+ | 182 | 22.5 | 0.5 | 61.0 | 55.5 | 38.5 | 64.3 | 82.4 | +18.1 | [+11.5, +25.3] | 40/7 |
| gold 证据跨 session | 1 session | 1201 | 79.8 | 20.6 | 98.5 | 98.0 | 95.3 | 84.6 | 93.6 | +9.0 | [+7.1, +10.9] | 129/21 |
| gold 证据跨 session | ≥2 sessions | 330 | 29.1 | 0.3 | 72.1 | 68.8 | 55.2 | 66.4 | 83.6 | +17.3 | [+12.1, +22.4] | 70/13 |
| gold 证据跨 NEMORI episode | 1 episode | 1197 | 80.0 | 20.6 | 98.7 | 98.2 | 95.5 | 84.6 | 93.6 | +8.9 | [+7.0, +10.9] | 128/21 |
| gold 证据跨 NEMORI episode | ≥2 episodes | 334 | 28.7 | 0.3 | 71.9 | 68.6 | 54.8 | 66.5 | 83.8 | +17.4 | [+12.3, +22.5] | 71/13 |
| 列表/计数 | List/count | 666 | 63.4 | 12.8 | 91.0 | 89.5 | 83.0 | 76.0 | 90.1 | +14.1 | [+11.1, +17.3] | 110/16 |
| 列表/计数 | Single-item | 865 | 73.1 | 18.8 | 94.2 | 93.4 | 89.4 | 84.3 | 92.5 | +8.2 | [+6.0, +10.5] | 89/18 |
| 列表/计数 × 跨 session | List/count, 1 session | 433 | 82.2 | 19.6 | 99.3 | 98.8 | 96.5 | 84.1 | 93.8 | +9.7 | [+6.5, +12.9] | 49/7 |
| 列表/计数 × 跨 session | List/count, ≥2 sessions | 233 | 28.3 | 0.0 | 75.5 | 72.1 | 57.9 | 60.9 | 83.3 | +22.3 | [+15.9, +28.8] | 61/9 |
| Temporal：gold turn 是否含相对时间表达 | Temporal: no relative expression | 73 | 75.3 | 23.3 | 100.0 | 100.0 | 93.2 | 83.6 | 89.0 | +5.5 | [-4.1, +15.1] | 8/4 |
| Temporal：gold turn 是否含相对时间表达 | Temporal: relative time in gold turn | 247 | 75.7 | 18.6 | 97.2 | 96.0 | 94.3 | 76.1 | 91.9 | +15.8 | [+10.9, +20.6] | 42/3 |

**按 gold 定义的问题类型：覆盖率（complete %）与准确率，Haiku 4.5**

| 切片 | 组 | n | NEMORI R | NEMORI V | VMem R | VMem V | VMem C | NEMORI 准确率 | VMem 准确率 | Δ | 95% CI | W/L |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 类别 | Multi-hop | 279 | 31.5 | 1.8 | 78.9 | 72.8 | 49.5 | 69.5 | 87.1 | +17.6 | [+12.5, +22.9] | 56/7 |
| 类别 | Open-domain | 92 | 38.0 | 8.7 | 70.7 | 69.6 | 59.8 | 47.8 | 67.4 | +19.6 | [+9.8, +29.3] | 21/3 |
| 类别 | Single-hop | 840 | 82.0 | 20.5 | 99.3 | 98.7 | 94.2 | 83.7 | 93.1 | +9.4 | [+7.0, +11.9] | 96/17 |
| 类别 | Temporal | 320 | 75.6 | 19.7 | 97.8 | 95.9 | 90.9 | 71.6 | 89.1 | +17.5 | [+13.1, +22.2] | 60/4 |
| gold evidence turn 数 | 1 | 1122 | 80.3 | 21.1 | 98.8 | 98.1 | 94.5 | 79.9 | 92.1 | +12.1 | [+10.0, +14.4] | 157/21 |
| gold evidence turn 数 | 2 | 227 | 49.3 | 4.4 | 90.3 | 85.9 | 67.4 | 69.2 | 84.1 | +15.0 | [+9.7, +20.3] | 38/4 |
| gold evidence turn 数 | 3+ | 182 | 22.5 | 0.5 | 65.4 | 58.8 | 34.1 | 63.7 | 81.3 | +17.6 | [+11.0, +24.7] | 38/6 |
| gold 证据跨 session | 1 session | 1201 | 79.8 | 20.6 | 98.5 | 97.6 | 92.8 | 80.0 | 91.8 | +11.8 | [+9.7, +13.9] | 165/23 |
| gold 证据跨 session | ≥2 sessions | 330 | 29.1 | 0.3 | 75.5 | 70.0 | 48.5 | 63.3 | 81.5 | +18.2 | [+13.3, +23.0] | 68/8 |
| gold 证据跨 NEMORI episode | 1 episode | 1197 | 80.0 | 20.6 | 98.6 | 97.7 | 93.1 | 80.0 | 91.8 | +11.8 | [+9.7, +13.9] | 164/23 |
| gold 证据跨 NEMORI episode | ≥2 episodes | 334 | 28.7 | 0.3 | 75.4 | 69.8 | 48.2 | 63.5 | 81.7 | +18.3 | [+13.5, +23.1] | 69/8 |
| 列表/计数 | List/count | 666 | 63.4 | 12.8 | 92.2 | 89.6 | 79.3 | 73.1 | 88.6 | +15.5 | [+12.5, +18.6] | 116/13 |
| 列表/计数 | Single-item | 865 | 73.1 | 18.8 | 94.6 | 93.2 | 86.4 | 79.0 | 90.4 | +11.4 | [+8.9, +14.0] | 117/18 |
| 列表/计数 × 跨 session | List/count, 1 session | 433 | 82.2 | 19.6 | 99.5 | 98.2 | 94.5 | 80.4 | 92.8 | +12.5 | [+9.0, +16.2] | 61/7 |
| 列表/计数 × 跨 session | List/count, ≥2 sessions | 233 | 28.3 | 0.0 | 78.5 | 73.8 | 51.1 | 59.7 | 80.7 | +21.0 | [+15.0, +27.0] | 55/6 |
| Temporal：gold turn 是否含相对时间表达 | Temporal: no relative expression | 73 | 75.3 | 23.3 | 100.0 | 98.6 | 83.6 | 74.0 | 90.4 | +16.4 | [+6.8, +26.0] | 13/1 |
| Temporal：gold turn 是否含相对时间表达 | Temporal: relative time in gold turn | 247 | 75.7 | 18.6 | 97.2 | 95.1 | 93.1 | 70.9 | 88.7 | +17.8 | [+13.0, +23.1] | 47/3 |

- **多证据题**：NEMORI 的 R complete 随 gold turn 数增加急剧下降（1 个：80.3%，2 个：49.3%，3+ 个：22.5%）；V complete 降到 4.4% 和 0.5%。VMem 分别是 98.8%、88.5%、61.0%（R）。3+ 证据题仍是 VMem 覆盖最差的切片，卡片完整引用只有 38.5%（34.1%）。
- **跨 session / 跨 episode**：两种定义给出几乎相同的数字（330 vs 334 题）。NEMORI R complete 只有 29%，V complete 0.3%；VMem R 约 72%（75%），准确率 +17 pp（+18 pp）。
- **列表/计数**：跨 ≥2 个 session 的列表/计数题提升最大，+22.3 pp（+21.0 pp）。只在 1 个 session 内的列表/计数题，提升（+9.7）与单项题（+8.2）相近。所以真正的难点是跨 session 聚合，而不是“列表”这一答案形式。
- **Temporal**：gold 原文含相对时间表达的 247 题，提升 +15.8 pp（+17.8 pp）。不含的 73 题，Opus 下 +5.5 pp（CI 跨 0），Haiku 下 +16.4 pp。这和“摘要会丢失或算错相对时间，需要原文与 session 日期”的解释一致，但 n = 73 较小。

多证据题（gold ≥ 2 个）内部，按 NEMORI 的 V 状态分组：

**多证据题（gold turn ≥ 2）中，按 NEMORI V 状态分组的准确率（Opus 4.5）**

| 分组 | n | NEMORI 准确率 | VMem 准确率 | Δ (pp) | 95% CI | W/L/T | McNemar p |
|---|---:|---:|---:|---:|---:|---:|---:|
| complete | 11 | 100.0 | 100.0 | +0.0 | [+0.0, +0.0] | 0/0/11 | 1 |
| partial | 131 | 68.7 | 87.0 | +18.3 | [+10.7, +26.7] | 29/5/97 | <1e-4 |
| missing | 267 | 68.5 | 82.4 | +13.9 | [+8.6, +19.1] | 47/10/210 | <1e-4 |

---

## 5. 证据可见之后：充分性与使用

### 5.1 VMem 的证据漏斗（R → V → C）

**VMem 的证据漏斗，Opus 4.5**：R complete → V complete → C complete（卡片引用了全部 gold turn），以及各层的准确率

| 类别 | n | R complete % | V complete % | C complete % | 准确率（C complete） | 准确率（V complete 但 C 不完整） | 准确率（V 不完整） |
|---|---:|---:|---:|---:|---:|---:|---:|
| Multi-hop | 279 | 74.9 | 72.0 | 58.4 | 92.0 (n=163) | 84.6 (n=39) | 83.3 (n=78) |
| Temporal | 320 | 97.8 | 96.9 | 94.1 | 92.0 (n=301) | 90.0 (n=10) | 70.0 (n=10) |
| Open-domain | 92 | 69.6 | 66.3 | 57.6 | 75.5 (n=53) | 62.5 (n=8) | 58.1 (n=31) |
| Single-hop | 840 | 99.4 | 99.0 | 96.3 | 96.3 (n=809) | 60.0 (n=25) | 75.0 (n=8) |
| Overall | 1531 | 92.8 | 91.7 | 86.6 | 94.0 (n=1326) | 75.6 (n=82) | 75.6 (n=127) |

**VMem 的证据漏斗，Haiku 4.5**：R complete → V complete → C complete（卡片引用了全部 gold turn），以及各层的准确率

| 类别 | n | R complete % | V complete % | C complete % | 准确率（C complete） | 准确率（V complete 但 C 不完整） | 准确率（V 不完整） |
|---|---:|---:|---:|---:|---:|---:|---:|
| Multi-hop | 279 | 78.9 | 72.8 | 49.5 | 87.7 (n=138) | 88.2 (n=68) | 85.5 (n=76) |
| Temporal | 320 | 97.8 | 95.9 | 90.9 | 90.7 (n=291) | 82.4 (n=17) | 61.5 (n=13) |
| Open-domain | 92 | 70.7 | 69.6 | 59.8 | 67.3 (n=55) | 66.7 (n=9) | 67.9 (n=28) |
| Single-hop | 840 | 99.3 | 98.7 | 94.2 | 94.7 (n=791) | 70.7 (n=41) | 63.6 (n=11) |
| Overall | 1531 | 93.5 | 91.6 | 83.3 | 91.8 (n=1275) | 80.7 (n=135) | 77.3 (n=128) |

- 漏斗中损失最大的一步，是从“原文可见”（V）到“卡片完整引用”（C）：Multi-hop 上从 72.0% 降到 58.4%（Haiku 从 72.8% 降到 49.5%）。
- 卡片完整引用的题准确率 94.0%。V complete 但 C 不完整的题，准确率降到 75.6%，和 V 本身不完整时（75.6%）相同。所以“证据可见”还不够，被证据构造步骤明确挑出来才与正确率强相关（观察性）。

### 5.2 证据完全可见时仍然答错

| 方法 | backbone | 错误总数 | 其中 gold turn 全部可见仍错 | 占错误 % | 按类别 |
|---|---:|---:|---:|---:|---:|
| NEMORI | opus | 296 | 11 | 3.7 | Multi-hop 0, Temporal 3, Open-domain 3, Single-hop 5 |
| VMem | opus | 131 | 100 | 76.3 | Multi-hop 19, Temporal 25, Open-domain 16, Single-hop 40 |
| NEMORI | haiku | 361 | 17 | 4.7 | Multi-hop 0, Temporal 6, Open-domain 3, Single-hop 8 |
| VMem | haiku | 159 | 130 | 81.8 | Multi-hop 25, Temporal 30, Open-domain 21, Single-hop 54 |

VMem 在 gold turn 全部可见时仍答错的题：

| backbone | n | 其中卡片引用了全部 gold turn | 其中回答为弃答/“未提及” | 其中 NEMORI 也答错 |
|---|---:|---:|---:|---:|
| opus | 100 | 80 | 2 | 74 |
| haiku | 130 | 104 | 7 | 103 |

- NEMORI 的错误中，只有不到 5% 发生在 gold 全部可见的题上，主要失败模式是证据缺失。
- VMem 的错误中，76%（82%）发生在 gold 全部可见的题上；其中 80% 的题卡片已经引用了全部 gold。剩下的失败来自推理、作答格式、judge 判定或标注噪声，例如 §7 中的 “What pets does Melanie have?”。
- 这些 VMem 错误中，74%（79%）NEMORI 也答错，说明它们集中在难题或有歧义的题上。
- 后续改进的重点应该从“找到证据”转向“用好证据”。

---

## 6. 强基线

### 6.1 provenance 审计

| 方法 | 能否精确映射到 LoCoMo turn | 可计算的度量 | 不能计算的度量 |
|---|---|---|---|
| MemR³（RAG 后端） | **能**：从对话文本按 256 token（cl100k）切块的规则可以完全重建 chunk。`retrieval_history` 记录了每轮 5 个 chunk 的编号和前 200 字符，Opus 10,855 条、Haiku 11,390 条全部与重建的 chunk 逐字一致 | **R-strict**：gold turn 完整落在某个检索 chunk 内（任一轮）；**R-overlap**：gold turn 与某个检索 chunk 有重叠（约 18% 的 turn 跨 chunk 边界） | **V（最终作答 prompt）**：按 MemR³ 的代码，最终作答 prompt 只有 LLM 提炼的证据要点和草稿答案，没有原始 chunk；chunk 只在中间的 generation/router 步骤出现过。所以“检索记录包含”和“作答 prompt 可见原文”在 MemR³ 上是不同的东西，后者恒为 0 |
| MRAgent | **只有 LLM 引用的 turn**：`supports` 是 dia_id（1538/1540 条记录有）；检索到的事件和工具返回的事件都没有保存 | “引用覆盖”，可与 VMem 的 C 粗略对照（只有 Haiku） | R、V |
| SimpleMem | **不能**：记忆条目没有存来源 turn id，每题检索到的 context 也没有保存（只有 `num_retrieved`） | 只有准确率 | R、V、C |
| LightMem | **不能**：每题只有 `retrieved_count` | 只有准确率 | R、V、C |

所以，表格中可以和 NEMORI/VMem 并列的覆盖度量只有 MemR³ 的 R 和 MRAgent 的引用覆盖。这两个都不是 NEMORI/VMem 意义上的 V，横向比较时请注意定义不同。

### 6.2 跨方法覆盖率

**跨方法覆盖率（complete / partial / missing %），Opus 4.5**

| 度量 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M |
|---|---:|---:|---:|---:|---:|
| MemR³ R-strict（gold turn 完整落在某个检索到的 chunk 内，任一轮） | 21.1 / 61.3 / 17.6 | 69.4 / 6.6 / 24.1 | 34.8 / 26.1 / 39.1 | 72.5 / 1.4 / 26.1 | 60.2 / 14.9 / 24.9 |
| MemR³ R-overlap（gold turn 与某个检索 chunk 有重叠） | 35.5 / 54.1 / 10.4 | 90.6 / 3.8 / 5.6 | 52.2 / 22.8 / 25.0 | 94.4 / 0.6 / 5.0 | 80.3 / 12.3 / 7.3 |
| NEMORI R | 31.5 / 53.0 / 15.4 | 75.6 / 4.7 / 19.7 | 38.0 / 20.7 / 41.3 | 82.0 / 0.0 / 18.0 | 68.8 / 11.9 / 19.3 |
| NEMORI V | 1.8 / 41.6 / 56.6 | 19.7 / 2.5 / 77.8 | 8.7 / 7.6 / 83.7 | 20.5 / 0.0 / 79.5 | 16.2 / 8.6 / 75.2 |
| VMem R | 74.9 / 24.0 / 1.1 | 97.8 / 0.9 / 1.2 | 69.6 / 20.7 / 9.8 | 99.4 / 0.0 / 0.6 | 92.8 / 5.8 / 1.4 |
| VMem V | 72.0 / 26.9 / 1.1 | 96.9 / 1.6 / 1.6 | 66.3 / 20.7 / 13.0 | 99.0 / 0.0 / 1.0 | 91.7 / 6.5 / 1.8 |
| VMem C（卡片引用） | 58.4 / 39.4 / 2.2 | 94.1 / 3.4 / 2.5 | 57.6 / 20.7 / 21.7 | 96.3 / 0.6 / 3.1 | 86.6 / 9.5 / 3.9 |

**跨方法覆盖率（complete / partial / missing %），Haiku 4.5**

| 度量 | Multi-hop C/P/M | Temporal C/P/M | Open-domain C/P/M | Single-hop C/P/M | Overall C/P/M |
|---|---:|---:|---:|---:|---:|
| MemR³ R-strict（gold turn 完整落在某个检索到的 chunk 内，任一轮） | 21.1 / 58.8 / 20.1 | 67.8 / 7.2 / 25.0 | 30.4 / 27.2 / 42.4 | 72.7 / 1.5 / 25.7 | 59.8 / 14.7 / 25.5 |
| MemR³ R-overlap（gold turn 与某个检索 chunk 有重叠） | 34.4 / 54.5 / 11.1 | 88.4 / 5.0 / 6.6 | 47.8 / 22.8 / 29.3 | 94.8 / 0.4 / 4.9 | 79.6 / 12.5 / 7.8 |
| NEMORI R | 31.5 / 53.0 / 15.4 | 75.6 / 4.7 / 19.7 | 38.0 / 20.7 / 41.3 | 82.0 / 0.0 / 18.0 | 68.8 / 11.9 / 19.3 |
| NEMORI V | 1.8 / 41.6 / 56.6 | 19.7 / 2.5 / 77.8 | 8.7 / 7.6 / 83.7 | 20.5 / 0.0 / 79.5 | 16.2 / 8.6 / 75.2 |
| VMem R | 78.9 / 20.4 / 0.7 | 97.8 / 0.9 / 1.2 | 70.7 / 21.7 / 7.6 | 99.3 / 0.0 / 0.7 | 93.5 / 5.2 / 1.2 |
| VMem V | 72.8 / 26.2 / 1.1 | 95.9 / 2.2 / 1.9 | 69.6 / 21.7 / 8.7 | 98.7 / 0.0 / 1.3 | 91.6 / 6.5 / 1.8 |
| VMem C（卡片引用） | 49.5 / 46.6 / 3.9 | 90.9 / 3.8 / 5.3 | 59.8 / 19.6 / 20.7 | 94.2 / 1.2 / 4.6 | 83.3 / 11.1 / 5.6 |
| MRAgent 引用的 supports | 39.1 / 53.4 / 7.5 | 84.4 / 4.4 / 11.2 | 39.1 / 27.2 / 33.7 | 90.4 / 1.5 / 8.1 | 76.7 / 13.1 / 10.2 |

### 6.3 按基线自身覆盖状态的准确率

| backbone | 按 MemR³ 自身 R-strict 分组 | n | MemR³ 准确率 | NEMORI 准确率 | VMem 准确率 |
|---|---:|---:|---:|---:|---:|
| opus | MemR³ R-strict complete | 922 | 92.7 | 84.9 | 93.6 |
| opus | MemR³ R-strict partial | 228 | 61.0 | 62.7 | 82.9 |
| opus | MemR³ R-strict missing | 381 | 76.1 | 81.1 | 91.3 |
| opus | （MemR³ 平均检索 chunk 数 / 题） | 7.0 |  |  |  |
| haiku | MemR³ R-strict complete | 915 | 91.9 | 81.0 | 91.7 |
| haiku | MemR³ R-strict partial | 225 | 57.8 | 61.3 | 80.0 |
| haiku | MemR³ R-strict missing | 391 | 66.5 | 74.4 | 90.3 |
| haiku | （MemR³ 平均检索 chunk 数 / 题） | 7.4 |  |  |  |

- MemR³ R-strict missing 组的准确率（76.1%）高于 partial 组（61.0%），原因之一是 R-strict 不计入跨 chunk 边界的 turn。见 R-overlap，以及 `exp2/tables/baseline_coverage.csv`。

| backbone | 按 MRAgent 引用覆盖分组 | n | MRAgent 准确率 | VMem 准确率 |
|---|---:|---:|---:|---:|
| haiku | MRAgent supports complete | 1174 | 94.8 | 93.3 |
| haiku | MRAgent supports partial | 201 | 73.1 | 83.1 |
| haiku | MRAgent supports missing | 156 | 50.0 | 70.5 |

### 6.4 按 gold 定义切片的准确率（所有可比较的方法）

**按 gold 定义切片的准确率（%），Opus 4.5**

| 切片 | 组 | n | NEMORI | SimpleMem | MemR³ | VMem |
|---|---:|---:|---:|---:|---:|---:|
| 类别 | Multi-hop | 279 | 71.0 | 78.1 | 62.7 | 88.5 |
| 类别 | Open-domain | 92 | 59.8 | 57.6 | 75.0 | 68.5 |
| 类别 | Single-hop | 840 | 87.3 | 84.6 | 90.7 | 95.0 |
| 类别 | Temporal | 320 | 77.8 | 81.6 | 86.9 | 91.2 |
| gold turn 数 | 1 | 1122 | 84.8 | 83.8 | 90.1 | 94.0 |
| gold turn 数 | 2 | 227 | 73.6 | 74.0 | 71.8 | 85.9 |
| gold turn 数 | 3+ | 182 | 64.3 | 74.2 | 60.4 | 82.4 |
| 跨 session | 1 session | 1201 | 84.6 | 83.8 | 89.4 | 93.6 |
| 跨 session | ≥2 sessions | 330 | 66.4 | 71.8 | 63.6 | 83.6 |
| 列表/计数 | List/count | 666 | 76.0 | 79.9 | 79.4 | 90.1 |
| 列表/计数 | Single-item | 865 | 84.3 | 82.2 | 87.3 | 92.5 |
| 列表/计数 × 跨 session | List/count, 1 session | 433 | 84.1 | 83.6 | 91.0 | 93.8 |
| 列表/计数 × 跨 session | List/count, ≥2 sessions | 233 | 60.9 | 73.0 | 57.9 | 83.3 |
| Temporal 相对时间 | Temporal: no relative expression | 73 | 83.6 | 80.8 | 86.3 | 89.0 |
| Temporal 相对时间 | Temporal: relative time in gold turn | 247 | 76.1 | 81.8 | 87.0 | 91.9 |

**按 gold 定义切片的准确率（%），Haiku 4.5**

| 切片 | 组 | n | NEMORI | SimpleMem | MemR³ | MRAgent | VMem |
|---|---:|---:|---:|---:|---:|---:|---:|
| 类别 | Multi-hop | 279 | 69.5 | 78.5 | 58.8 | 80.3 | 87.1 |
| 类别 | Open-domain | 92 | 47.8 | 53.3 | 59.8 | 62.0 | 67.4 |
| 类别 | Single-hop | 840 | 83.7 | 80.7 | 88.9 | 94.3 | 93.1 |
| 类别 | Temporal | 320 | 71.6 | 79.1 | 82.8 | 82.8 | 89.1 |
| gold turn 数 | 1 | 1122 | 79.9 | 80.8 | 86.8 | 90.9 | 92.1 |
| gold turn 数 | 2 | 227 | 69.2 | 68.7 | 70.0 | 81.9 | 84.1 |
| gold turn 数 | 3+ | 182 | 63.7 | 74.7 | 53.8 | 72.5 | 81.3 |
| 跨 session | 1 session | 1201 | 80.0 | 80.1 | 86.3 | 90.7 | 91.8 |
| 跨 session | ≥2 sessions | 330 | 63.3 | 71.8 | 59.1 | 75.5 | 81.5 |
| 列表/计数 | List/count | 666 | 73.1 | 77.8 | 76.4 | 84.1 | 88.6 |
| 列表/计数 | Single-item | 865 | 79.0 | 78.7 | 83.5 | 89.9 | 90.4 |
| 列表/计数 × 跨 session | List/count, 1 session | 433 | 80.4 | 79.9 | 88.2 | 89.8 | 92.8 |
| 列表/计数 × 跨 session | List/count, ≥2 sessions | 233 | 59.7 | 73.8 | 54.5 | 73.4 | 80.7 |
| Temporal 相对时间 | Temporal: no relative expression | 73 | 74.0 | 76.7 | 86.3 | 83.6 | 90.4 |
| Temporal 相对时间 | Temporal: relative time in gold turn | 247 | 70.9 | 79.8 | 81.8 | 82.6 | 88.7 |

---

## 7. 代表性案例（Opus 4.5；固定种子抽样，不挑选）

候选池大小（Opus 4.5）：recovered_win = 146，summary_only_win = 20，both_complete_win = 5，vmem_complete_wrong = 80，vmem_loss = 34，vmem_missing_multihop = 75。每类用固定随机种子（42）抽样，不做挑选。

#### NEMORI 缺证据（V missing）→ VMem 原文可见且引用（C complete），VMem 对 NEMORI 错

- **[conv-41 · Multi-hop] What events for veterans has John participated in?** — gold：*Petition, march, party, visiting veterans hospital, 5K charity run*
  - gold D15:1：[7:38 pm on 20 May, 2023] Hey Maria, how's it going? Been real busy tackling a project to support military veterans. Trying to get a petition going, it's pretty rewarding but kinda stressful. How are you?
  - gold D15:11：[7:38 pm on 20 May, 2023] Awesome, Maria! I knew you'd be on board. With your help, we can make a real impact. Thank you so much! Here's a pic from last Friday with some veterans who are really excited about this. Their …
  - gold D21:22：[8:43 pm on 3 July, 2023] Yeah, Maria, keep it up! Even small things can mean a lot. I just participated in a marching event for veterans' rights and it was awesome, made me remember how much they sacrifice for us. We ne…
  - gold D24:1：[3:34 pm on 17 July, 2023] Hey Maria, last week was really eye-opening. I visited a veteran's hospital and met some amazing people. It made me appreciate what we have and the need to give back.
  - gold D29:4：[8:06 pm on 9 August, 2023] I set up a 5K charity run in our neighborhood. It was all for a good cause - to help out veterans and their families. We were able to raise some funds! Here's a pic from the day.
  - NEMORI：R=partial，V=missing，✗；回答结尾：“o a military memorial** (around July 27, 2023) - An educational visit to honor veterans.  Marching event, veterans party, hospital visit, virtual support group.”
  - VMem：V=complete，C=complete，✓；回答：“John organized a party for veterans to share stories, participated in a veterans' rights march, visited a veteran's hospital, took his kids to a military memorial, invited people to a military advocac”

- **[conv-26 · Temporal] When did Caroline go to the LGBTQ support group?** — gold：*7 May 2023*
  - gold D1:3：[1:56 pm on 8 May, 2023] I went to a LGBTQ support group yesterday and it was so powerful.
  - NEMORI：R=missing，V=missing，✗；回答结尾：“e on July 10, 2023**, where Caroline described feeling "totally accepted" and connecting with "people who had gone through similar journeys."  **July 10, 2023**”
  - VMem：V=complete，C=complete，✓；回答：“May 7, 2023”

- **[conv-44 · Single-hop] How does Audrey describe her dogs' response to snow?** — gold：*They definitely prefer nice, sunny days in the grass.*
  - gold D23:12：[4:22 pm on 13 October, 2023] Haha, that must've been hilarious! What breed is your pup again? He looks so fun! My dogs love running around the park. But one thing they hate is snow. I took them to a snowy one last winte…
  - NEMORI：R=missing，V=missing，✗；回答结尾：“ive boots and party hats  However, there is no mention of snow or how Audrey's dogs react to snow in any of the provided memories.  **No information available**”
  - VMem：V=complete，C=complete，✓；回答：“Her dogs hate snow - when she took them to a snowy park last winter, they were confused and prefer sunny days in the grass.”

#### NEMORI 只有 episode 摘要（R complete、V missing）→ VMem 原文可见，VMem 胜

- **[conv-30 · Single-hop] How does Gina describe the studio that Jon has opened?** — gold：*amazing*
  - gold D15:6：[10:04 am on 19 June, 2023] Congrats, Jon! The studio looks amazing. You've put a lot of work into this and I'm so pumped for the launch tomorrow. Don't miss a beat!
  - NEMORI：R=complete，V=missing，✗；回答结尾：“idence that Jon's studio would become a go-to spot for self-expression"  This is Gina's description of Jon's dance studio.  **A go-to spot for self-expression**”
  - VMem：V=complete，C=complete，✓；回答：“Gina described Jon's studio as "awesome," "amazing," and "a go-to spot for self-expression" that will change things for many people.”

- **[conv-26 · Single-hop] What do Melanie's family give her?** — gold：*Strength and motivation*
  - gold D18:9：[6:55 pm on 20 October, 2023] They're really amazing. Wish I was that resilient too. But they give me the strength to keep going.
  - NEMORI：R=complete，V=missing，✗；回答结尾：“d that "her family motivates her and gives her love, mentioning being lucky to have her husband and kids who keep her motivated."  **Answer: Love and motivation”
  - VMem：V=complete，C=complete，✓；回答：“Love, motivation, strength, support, and joy.”

- **[conv-41 · Single-hop] What emotions did John feel during the small party with the veterans?** — gold：*heartwarming*
  - gold D15:13：[7:38 pm on 20 May, 2023] Thanks, Maria! We had a great time throwing a small party and inviting some veterans to share their stories. It was awesome seeing them make connections and find camaraderie. All the smiles and …
  - NEMORI：R=complete，V=missing，✗；回答结尾：“so notes that John described his overall petition initiative work as "rewarding but stressful."  Based on the evidence, John felt:  **Motivated and passionate**”
  - VMem：V=complete，C=complete，✓；回答：“John felt it was awesome and heartwarming, and experienced a sense of community and togetherness.”

#### 两者 gold turn 都完全可见，VMem 胜（非证据可见性带来的收益）

- **[conv-26 · Single-hop] What are Caroline's plans for the summer?** — gold：*researching adoption agencies*
  - gold D2:8：[1:14 pm on 25 May, 2023] Researching adoption agencies — it's been a dream to have a family and give a loving home to kids who need it.
  - NEMORI：R=complete，V=complete，✗；回答结尾：“0], this is confirmed - Caroline announced she "would be attending a transgender conference later in July 2023."  **Answer:** Attending a transgender conference”
  - VMem：V=complete，C=complete，✓；回答：“Caroline's summer 2023 plans included attending a transgender conference, researching adoption agencies, pursuing counseling education, joining an LGBTQ youth mentorship program, hosting an LGBTQ art ”

- **[conv-49 · Temporal] When did Evan have his sudden heart palpitation incident that really shocked him up?** — gold：*first week of June 2023*
  - gold D3:1：[3:55 pm on 6 June, 2023] Hey Sam! Long time no talk! How're you doing? Life's been quite the rollercoaster lately. I had a health scare last week – a sudden heart palpitation incident that really shook me up. It's been …
  - NEMORI：R=complete，V=complete，✗；回答结尾：“e on June 6, 2023, and Evan mentioned the incident happened "last week," which the memory explicitly calculates as around May 30, 2023.  **Around May 30, 2023**”
  - VMem：V=complete，C=complete，✓；回答：“The week before 6 June 2023”

- **[conv-42 · Single-hop] What is Nate's favorite book series about?** — gold：*dragons*
  - gold D9:14：[7:44 pm on 21 April, 2022] I love this series. It has adventures, magic, and great characters - it's a must-read!
  - NEMORI：R=complete，V=complete，✗；回答结尾：“is The Lord of the Rings"  Based on the evidence, Nate's favorite book series is The Lord of the Rings, which is about:  **Adventures, magic, and epic battles**”
  - VMem：V=complete，C=complete，✓；回答：“Adventures, magic, and great characters (a fantasy novel series with a dragon cover)”

#### VMem 卡片引用了全部 gold turn 但仍答错（充分证据下的失败）

- **[conv-41 · Single-hop] What event did John volunteer at last weekend?** — gold：*career fair at a local school*
  - gold D10:13：[12:24 am on 7 April, 2023] What a photo! Seeing everyone come together for a shared cause must have been inspiring. Last weekend I had an experience that reminded me of the impact we can make. I got to volunteer at a ca…
  - NEMORI：R=complete，V=complete，✓；回答结尾：“at a career fair at a local school"  This refers to approximately April 1-2, 2023 (the weekend before April 7, 2023).  **Answer: Career fair at a local school**”
  - VMem：V=complete，C=complete，✗；回答：“A 5K charity run to raise money for veterans and their families”

- **[conv-26 · Single-hop] What did Melanie do after the road trip to relax?** — gold：*Went on a nature walk or hike*
  - gold D18:17：[6:55 pm on 20 October, 2023] Thanks, Caroline! Yup, we just did it yesterday! The kids loved it and it was a nice way to relax after the road trip.
  - NEMORI：R=complete，V=missing，✗；回答结尾：“23). She mentioned the kids loved the experience and it served as a nice way to relax after their eventful road trip."  The answer is:  Visited the Grand Canyon”
  - VMem：V=complete，C=complete，✗；回答：“Melanie visited the Grand Canyon with her family to relax after the road trip.”

- **[conv-44 · Single-hop] What did Andrew and Audrey plan to do on the Saturday after October 28, 2023?** — gold：*Go hiking*
  - gold D26:20：[2:36 pm on 28 October, 2023] Yay! Does Saturday sound good? We can grab some snacks and have a blast exploring. Because on Sunday I am going on a picnic date with my girlfriend.
  - NEMORI：R=complete，V=missing，✓；回答结尾：“girlfriend that weekend.  However, re-reading the October 1 memory, they had planned a "hike with the dogs next month" (November 2023).  **Hike with the dogs**”
  - VMem：V=complete，C=complete，✗；回答：“They planned to go hiking together with their dogs on October 28, 2023 (not the Saturday after).”

#### VMem 负：NEMORI 对 VMem 错

- **[conv-41 · Multi-hop] What causes has John done events for?** — gold：*Toy drive, Community food drive, veterans, domestic violence*
  - gold D3:5：[8:30 pm on 1 January, 2023] We held some events and got to meet some people. We went to a homeless shelter to give out food and supplies. Seeing the smiles on their faces, we knew we made a real difference. We also orga…
  - gold D6:12：[2:33 pm on 5 February, 2023] Seeing the effect unemployment has on our neighbors made me decide to act. I wanted to help out in these tough times by doing a community food drive. We can all make a difference!
  - gold D29:4：[8:06 pm on 9 August, 2023] I set up a 5K charity run in our neighborhood. It was all for a good cause - to help out veterans and their families. We were able to raise some funds! Here's a pic from the day.
  - gold D29:10：[8:06 pm on 9 August, 2023] Yep, we worked with a local organization that helps victims of domestic abuse. We raised awareness and funds at the event for the cause — it's unfortunate how many people suffer from it.
  - NEMORI：R=partial，V=partial，✓；回答结尾：“n raised awareness and funds for domestic abuse victims through a community event  **Answer:** Unemployment, veterans' rights, military advocacy, domestic abuse”
  - VMem：V=complete，C=complete，✗；回答：“Unemployment relief, homeless support, children in need, underprivileged youth education, veterans' rights and support, domestic abuse awareness, fire station/emergency services, and community center ”

- **[conv-26 · Single-hop] What pets does Melanie have?** — gold：*Two cats and a dog*
  - gold D13:4：[3:31 pm on 23 August, 2023] Yeah, it's normal to be both excited and nervous with a big decision. And thanks for asking, they're good- we got another cat named Bailey too. Here's a pic of Oliver. Can you show me one of …
  - NEMORI：R=complete，V=missing，✓；回答结尾：“at named Bailey (new addition) - Another cat (Oliver or the original cat)  The clearest answer combining all information:  **A dog, and cats Oliver and Bailey**”
  - VMem：V=complete，C=complete，✗；回答：“Melanie has a dog named Luna, a dog named Oliver, and a cat named Bailey.”

- **[conv-47 · Single-hop] What did John organize with his friends on May 8, 2022?** — gold：*A tournament for CS:GO*
  - gold D10:4：[12:45 am on 8 May, 2022] Nope, not a new game. We put together a tournament for our favorite game, CS:GO. Lots showed up and we made a bunch of money for charity!
  - NEMORI：R=complete，V=complete，✓；回答结尾：“aming tournament** featuring CS:GO, their favorite game. The tournament raised money for a dog shelter near his street.  **Answer: A charity gaming tournament**”
  - VMem：V=complete，C=complete，✗；回答：“A charity gaming tournament (which actually took place on May 7, 2022, the day before)”

#### Multi-hop 中 VMem 仍缺部分证据（V partial）

- **[conv-42 · Multi-hop] What mediums does Nate use to play games?** — gold：*Gamecube, PC,Playstation.*
  - gold D22:2：[11:15 am on 6 October, 2022] Hey Joanna! That tart looks yummy! Lately, I've been doing great - I won a really big video game tournament last week and it was awesome! I still can't believe I made so much money from it.
  - gold D27:21：[8:10 pm on 7 November, 2022] It really is! But it's also really important to have something like this for my career, otherwise I would never be able to beat my competition.
  - gold D27:15：[8:10 pm on 7 November, 2022] Great to hear! On another note, I just upgraded some of my equipment at home. Check it out!
  - NEMORI：R=partial，V=missing，✗；回答结尾：“From semantic memories: - "Nate owns gaming headphones and a video game controller"  Based on this evidence, Nate plays games on:  **Computer and controller**”
  - VMem：V=partial，C=partial，✗；回答：“PC, Xbox, Nintendo consoles, and board games”

- **[conv-41 · Multi-hop] What activities has Maria done with her church friends?** — gold：*Hiking, picnic, volunteer work*
  - gold D25:2：[6:21 pm on 22 July, 2023] Hey John, glad work is going well! Having a good team is so important. I had a great experience last weekend hiking with my church  friends - it was great to be surrounded by supportive people …
  - gold D24:6：[3:34 pm on 17 July, 2023] Yeah, last weekend I had a picnic with some friends from church. We chilled under the trees, played games, and ate yummy food. It was great!
  - gold D28:5：[5:19 pm on 5 August, 2023] Thanks Maria! I may have found a job at a tech company I like that needs my mechanical skills for their hardware team. It feels different, but I think it's a great opportunity to learn and con…
  - NEMORI：R=partial，V=missing，✓；回答结尾：“with her church friends"    - "Maria does community work with friends from her church"  Based on all the evidence:  **Picnics, hiking, camping, community work**”
  - VMem：V=partial，C=partial，✓；回答：“Camping, picnic (with charades and scavenger hunt), hiking, and community work.”


---

## 8. 作图数据

| 图 | 文件 | 内容 |
|---|---|---|
| **Figure A**：各类别的证据覆盖 | `exp2/figdata/figA_coverage_by_category.csv` | method × backbone × measure（R / V / C）× 类别（含 Overall）的 complete / partial / missing %，以及 turn recall。建议画堆叠条形图 |
| **Figure B**：按证据可得性分组的答案准确率 | `exp2/figdata/figB_accuracy_by_nemori_coverage.csv` | 按 NEMORI 的 R / V 状态分组的 NEMORI 与 VMem 准确率、Δ、95% CI。建议主图用 R 分组 |
| Figure B'（备选） | `exp2/figdata/figB_accuracy_by_own_coverage.csv` | 各方法按自身覆盖状态的准确率，带 Wilson CI |

其它机器可读的表在 `exp2/tables/`：`per_question.csv`（逐题的所有状态和对错）、`coverage_by_category.csv`、`accuracy_conditioned.csv`、`question_type_slices.csv`、`net_gain_by_nemori_RxV_{opus,haiku}.csv`、`win_loss_decomposition_*.csv`、`baseline_coverage.csv`、`accuracy_by_slice_all_methods.csv`、`context_volume.csv`、`denominators.json`、`examples.json`、`sanity_checks.json`。

---

## 9. 局限

1. **因果**：全部结论都是观察性的。“VMem 的收益来自恢复了 NEMORI 缺失的证据”这一解释有三点支持：收益集中在 NEMORI 检索缺证据的题上；在 NEMORI 已有全部证据的题上几乎没有收益；holdout 上结论一致。但覆盖状态与问题难度、类别相关，本实验也没有做组件消融（例如关掉原始 turn 层、关掉卡片、限制 pool 大小），所以不能把收益在因果意义上归给某个组件。
2. **上下文量**：VMem 的 prompt 约是 NEMORI 的 4 倍（20k vs 5k tokens，原始 turn 97 vs 22 条），覆盖率提升部分来自更大的预算（§2.3）。
3. **gold evidence 标注**：LoCoMo 的 evidence 有格式错误（`D`、`D:11:26`、`D30:05`、不存在的 `D10:19`、`D4:36`）、空 evidence（4 道 Open-domain 题），也可能漏标替代证据。被判为 missing 的题仍可能从别的 turn 或摘要中正确作答（NEMORI 在 R missing 时仍有 47.5% 的准确率）。所以覆盖率应理解为“gold 标注证据的覆盖率”。
4. **不可映射**：9 题被排除在主分母外，附录 A 显示把它们计入后结论不变；另外 6 个 LoCoMo turn 不在 NEMORI 记忆库中。
5. **R 的粒度**：NEMORI 的 R 以 episode 为单位。episode 摘要不一定真的写进了 gold turn 的内容，所以 R complete 是“相关记录被检索到”的上界，不代表“证据信息出现在摘要中”。
6. **基线**：MemR³ 的 R 是 chunk 级的，与 NEMORI/VMem 的 R 粒度不同（chunk 平均 256 tokens）；MRAgent 只有 LLM 引用、只有 Haiku；SimpleMem 和 LightMem 没有溯源。这些都已在 §6.1 写明，没有补造映射。
7. **只跑了一次**：所有方法每个配置都只有一次运行；VMem 在 dev 上的运行间噪声约 ±1.3 pp。
8. **问题类型规则**：列表/计数和相对时间是基于文本的规则分组，可能有误分类。

---

## 10. 复现

```bash
cd /path/to/VMem/develop && source env.sh
# 1) 恢复 NEMORI 记忆库（只读，临时容器，端口 15433，不影响原有 infra）并导出快照
docker run -d --name rq2_pg -e POSTGRES_USER=nemori -e POSTGRES_PASSWORD=nemori -e POSTGRES_DB=nemori \
    -p 127.0.0.1:15433:5432 -v /path/to/vmem_backup:/backup:ro postgres:16-alpine
docker exec rq2_pg pg_restore -U nemori -d nemori --no-owner /backup/nemori_opus45_pg.dump
$PY exp2/export_store.py                                   # -> exp2/data/store_snapshot.json（已保存，可跳过 1）
# 2) MemR³ chunk 溯源（需要 tiktoken，用 memr3 的环境）
baselines/envs/memr3/bin/python exp2/memr3_provenance.py   # -> exp2/data/memr3_retrieved_turns.json
# 3) sanity check、主分析、生成报告
$PY exp2/sanity_checks.py
$PY exp2/analyze.py                                        # -> exp2/tables/*, exp2/figdata/*
$PY exp2/build_report.py                                   # -> develop/2026-10-12_exp2_evidence_sufficiency.md
```

文件说明：
- `exp2/evidence_lib.py`：精确映射，以及每题的 R / V / C / S 状态。
- `exp2/analyze.py`：全部统计。
- `exp2/report_template.md`：本文的文字部分。
- 没有修改任何已有的实现或实验输出。

---

## 附录 A：把部分可映射的题计入后的敏感性分析

| 方法 | backbone | 度量 | 分母 | complete / partial / missing % |
|---|---:|---:|---:|---:|
| NEMORI | opus | R | 全部可映射（n=1531） | 68.8 / 11.9 / 19.3 |
| NEMORI | opus | R | +部分可映射（n=1535） | 68.8 / 12.0 / 19.2 |
| NEMORI | opus | V | 全部可映射（n=1531） | 16.2 / 8.6 / 75.2 |
| NEMORI | opus | V | +部分可映射（n=1535） | 16.2 / 8.6 / 75.2 |
| VMem | opus | R | 全部可映射（n=1531） | 92.8 / 5.8 / 1.4 |
| VMem | opus | R | +部分可映射（n=1535） | 92.7 / 5.9 / 1.4 |
| VMem | opus | V | 全部可映射（n=1531） | 91.7 / 6.5 / 1.8 |
| VMem | opus | V | +部分可映射（n=1535） | 91.6 / 6.6 / 1.8 |
| NEMORI | haiku | R | 全部可映射（n=1531） | 68.8 / 11.9 / 19.3 |
| NEMORI | haiku | R | +部分可映射（n=1535） | 68.8 / 12.0 / 19.2 |
| NEMORI | haiku | V | 全部可映射（n=1531） | 16.2 / 8.6 / 75.2 |
| NEMORI | haiku | V | +部分可映射（n=1535） | 16.2 / 8.6 / 75.2 |
| VMem | haiku | R | 全部可映射（n=1531） | 93.5 / 5.2 / 1.2 |
| VMem | haiku | R | +部分可映射（n=1535） | 93.5 / 5.3 / 1.2 |
| VMem | haiku | V | 全部可映射（n=1531） | 91.6 / 6.5 / 1.8 |
| VMem | haiku | V | +部分可映射（n=1535） | 91.5 / 6.6 / 1.8 |
