# VMem optimization log (started 2026-10-10)

Goal: make VMem significantly and reproducibly outperform NEMORI on LoCoMo (target ≥ +5 pp overall LLM-judge accuracy), with Claude Opus 4.5 (AWS Bedrock) as the model for every LLM role.

Branch: `feat/hypergraph` of VMem (per repo CLAUDE.md). Original VMem/VERA code in `evaluation/locomo/` is preserved; the only edit there is a marked `[VMem-dev patch]` that routes the answer call to Bedrock and records token usage.

---

## 0. Setup and pinned revisions

| Item | Value |
|---|---|
| VMem repo | `VMem` @ `94cfd68` (main), work on branch `feat/hypergraph` |
| NEMORI repo | `nemori-ai/nemori` @ `d2a6dff` (main; it contains merged `feat/hypergraph` + token-tracking fix), checked out at `/path/to/nemori`, local branch `feat/hypergraph` with model-swap patch `develop/patches/nemori_d2a6dff_bedrock.patch` |
| LoCoMo | `snap-research/locomo` @ `3eb6f2c`, `data/locomo10.json`; 10 conversations, 1540 questions in cat 1–4 (cat 5 skipped as in NEMORI) |
| LLM (all roles) | `bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0` via LiteLLM, temperature 0, ≤16 concurrent requests, 300 s timeout, exponential backoff on throttling (`develop/common/bedrock_llm.py`) |
| Judge | Upstream NEMORI/Mem0 `ACCURACY_PROMPT` + system message verbatim, Opus 4.5, temperature 0 (`develop/common/evaluate.py`) |
| F1 / BLEU | Upstream `metrics/utils.py` logic verbatim (set-token F1; BLEU-1 with smoothing method1) |
| Embedding (all methods) | Local `Qwen/Qwen3-Embedding-4B` (2560-d, normalized) behind an OpenAI-compatible server (`develop/infra/embed_server.py`); OpenRouter/gemini-embedding unavailable on this host |
| Stores | Postgres 16 + Qdrant v1.12.4 in docker (`develop/infra/docker-compose.yml`, ports 15432/16333) |
| Python | `/path/to/.venv_vmem` (py3.11, litellm, qdrant-client 1.19.1, asyncpg, torch 2.14) |

Model-swap patch to NEMORI (no algorithmic change):
- `nemori/llm/client.py`: `bedrock/*` models go through `common.bedrock_llm.acomplete`; `response_format=json_object` becomes JSON-fence stripping, because Bedrock Claude has no JSON mode.
- `nemori/llm/orchestrator.py`: per-request timeout 30 s → 600 s. Opus segmentation outputs exceed 30 s, and upstream would silently fall back to unsegmented episodes.
- `evaluation/locomo/search.py`: the answer call goes through Bedrock; per-question token usage is recorded; adds an optional `--conv-ids` filter.

### Fairness protocol
* **One memory backbone.** The NEMORI memory is built once with upstream `add.py` (Opus 4.5) into agent `locomo_opus45`. NEMORI, original VMem and VMem-v2 all answer from this same store, with the same embedding model, the same LLM and the same judge. NEMORI's memory construction is timing-dependent (`buffer_size_min=1`, async batch segmentation), so sharing one build removes that variance from the comparison.
* **No gold labels at inference.** No gold answers are used at inference, and VMem-v2 never reads the LoCoMo category label. Note that original VMem (VERA) *does* gate on the gold category (reviewer concern C1); it is evaluated as published.
* **Dev/holdout split** (conversation-level):
  * dev = `conv-26, conv-41` (304 questions: 63 cat1, 64 cat2, 21 cat3, 156 cat4);
  * holdout = the other 8 conversations (1236 questions), never inspected during development.

  Final numbers are reported on all 1540 questions and on the holdout alone.

## 1. Memory construction (NEMORI add.py, Opus 4.5)

Command:
```bash
source develop/env.sh
cd $NEMORI_UPSTREAM/evaluation && PYTHONPATH=$NEMORI_UPSTREAM:$DEV $PY locomo/add.py \
  --data $LOCOMO --config $DEV/configs/nemori_opus45.json --batch-size 1 --max-workers 10
```
Log: `develop/runs/memory_build/add.log`

**Result (2026-10-11 00:38)**
- 10/10 conversations processed.
- Store contents: 631 episodes (1076 generated, 446 merged), 4523 semantic memories, 5878 source-message references (buffer fully drained).
- LLM usage: 4809 calls, 5.52 M prompt + 1.33 M completion tokens ≈ **$61** at Opus 4.5 list price; average latency 5.6 s.
- Errors: 0 LLM errors. One merge-decision JSON parse failure was caught by upstream code and skipped, as upstream does.

**Backups**
- `/path/to/vmem_backup/nemori_opus45_pg.dump` (`pg_restore`).
- Qdrant snapshots `nemori_opus45_{episodes,semantic}-*.snapshot` in the same directory.

Restore these to reproduce every downstream number without rebuilding.

## 2. Baselines on full LoCoMo (1540 questions, Opus 4.5 everywhere, same store)

### 2.1 NEMORI (upstream defaults: 10 ep + 20 sem, vector, source msgs of top-2 episodes)
```bash
VMEM_LLM_CONCURRENCY=10 develop/scripts/run_nemori_baseline.sh nemori_full
```
Outputs: `develop/runs/nemori_full/{results,metrics}.json`

| Cat | n | LLM | F1 | BLEU-1 | avg prompt tok |
|---|---:|---:|---:|---:|---:|
| 1 multi-hop | 282 | 0.7092 | 0.0870 | 0.0411 | 5414 |
| 2 temporal | 321 | 0.7788 | 0.0741 | 0.0276 | 4906 |
| 3 open-domain | 96 | 0.6146 | 0.0576 | 0.0267 | 5101 |
| 4 single-hop | 841 | 0.8728 | 0.1072 | 0.0386 | 5226 |
| **overall** | 1540 | **0.8071** | 0.0935 | 0.0360 | 5186 |

Note on F1/BLEU: upstream scores the raw `response`. The upstream answer prompt says "think step by step", and Opus 4.5 writes the reasoning before a bolded answer. The judge reads the whole text, but F1/BLEU are very low. This is upstream protocol, so these are the official numbers; an extracted-answer F1 is reported later as a secondary view.

### 2.2 Original VMem/VERA (main per-category config; 6 ep + 10 sem; gated on the GOLD category)
```bash
VMEM_LLM_CONCURRENCY_PER=3 develop/scripts/run_vmem_original.sh vmem_orig_full
```
Outputs: `develop/runs/vmem_orig_full/`

| Cat | NEMORI LLM | VMem LLM | Δ | W/L | McNemar p |
|---|---:|---:|---:|---|---:|
| 1 | 0.7092 | 0.5780 | −0.131 | 11/48 | <1e-5 |
| 2 | 0.7788 | 0.6791 | −0.100 | 6/38 | <1e-5 |
| 3 | 0.6146 | 0.5833 | −0.031 | 3/6 | 0.51 |
| 4 | 0.8728 | 0.8240 | −0.049 | 18/59 | <1e-5 |
| **overall** | **0.8071** | **0.7338** | **−0.073** [−0.090, −0.057] | 38/151 | <1e-5 |

With Opus 4.5, original VMem is clearly *worse* than NEMORI. Main causes:
- The entity-profile and persona card prompts, tuned on GPT-4.1-mini, push Opus to answer "Insufficient evidence" (Cat1 −13 pp).
- The 6+10 budget drops retrieved evidence.
- Cards cover only a few questions.

## 3. Error analysis: why NEMORI fails (gold evidence used for analysis only)

`common/diagnose.py` maps LoCoMo gold evidence turn ids onto stored source messages and checks whether they reach the prompt.

| NEMORI, full LoCoMo | all gold evidence in retrieved episodes | raw gold turn printed |
|---|---:|---:|
| Cat1 | 31.2% | 1.8% |
| Cat2 | 74.7% | 19.7% |
| Cat3 | 38.0% | 8.7% |
| Cat4 | 81.7% | 20.6% |
| all | 68.3% | 16.2% |

Accuracy by evidence coverage: **covered 0.933 (n=1049)**, partial 0.611 (n=185), **missed 0.485 (n=301)**.

The dominant bottleneck is evidence coverage, not reasoning. Multi-hop questions almost never have all evidence in context, because a single top-k query over episode summaries cannot gather facts spread across sessions. Raw source turns, which carry the exact span and relative-time expressions, are shown for only the top-2 episodes.

This motivates VMem-v2: keep VMem's query-time, source-grounded evidence construction, but construct the evidence from a much wider, query-planned, multi-granularity retrieval that includes the raw source layer.

## 4. VMem-v2 design (develop/vmem2/)
No category labels are used anywhere.

1. **LLM query planner.** Produces the information need, answer type, an `aggregate`/`temporal` flag, and 4–6 diverse search queries (sub-questions for intermediate facts, paraphrases, keyword queries).
2. **Multi-route, multi-granularity retrieval over the same NEMORI store.**
   - Dense (same Qwen3 embeddings) + BM25 over episodes, semantic memories, and raw source turns (from `episodes.source_messages`), fused by RRF across all planned queries.
   - Provenance boost from semantic memory to its source episode.
   - ±1 turn local context; semantic memories re-dated through their source episode.
3. **Evidence construction (LLM).** Builds ViewCards `{claim, sources, verbatim quote, resolved time, relation}`; reports sufficiency, missing information and follow-up queries.
4. **Source verification.** Each quote is fuzzy-matched against its cited sources (support ≥ 0.8 → verified); unverified cards are flagged as UNVERIFIED in the answer prompt.
5. **Dynamic retrieval expansion.** If the evidence is insufficient, the follow-up queries are retrieved (excluding already-seen items) and step 3 is repeated on the new evidence.
6. **Answer.** Inputs: verified cards, the cited raw turns (±2 context), and the rest of the pool as fallback. Brief reasoning, then a `FINAL ANSWER:` line; only that line is the response.

### v2.1 (first version) — dev split (304 q)
```bash
cd develop && PYTHONPATH=$DEV $PY -m vmem2.run --out runs/vmem2_v1_dev/results.json --conv-ids $DEV_CONVS --concurrency 12
```
| Cat | n | NEMORI | VMem orig | **v2.1** | Δ vs NEMORI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---:|
| 1 | 63 | 0.7937 | – | 0.9206 | +0.127 | 9/1 | 0.021 |
| 2 | 64 | 0.8438 | – | 0.9062 | +0.063 | 8/4 | 0.39 |
| 3 | 21 | 0.7143 | – | 0.8095 | +0.095 | 3/1 | 0.63 |
| 4 | 156 | 0.8846 | – | 0.9551 | +0.071 | 14/3 | 0.013 |
| overall | 304 | 0.8454 | 0.7796 | **0.9276** | **+0.082** [+0.043,+0.125] | 34/9 | 0.0002 |

- Evidence coverage (all gold turns reach the context): 93.7% vs ~68% for NEMORI; raw-turn coverage 92.7%.
- Cost: 3.1 LLM calls and 21.6k prompt tokens per question ($0.135/q).

**v2.1 error analysis (22 wrong):**
- (a) 5 weekday-relative dates were mis-computed ("last Friday" said on 15 Jul 2023 → wrongly "7 July"; gold is "the Friday before 15 July 2023").
- (b) 2 questions use the wrong year in the question; the answer opened with "no evidence for Dec 2023…" and was judged wrong.
- (c) List/count aggregation was incomplete (books, bands, number of dogs).
- (d) Verbose, off-target answers for trait/inference questions.
- (e) A few mis-anchored events.

### v2.2 changes (generic, label-free)
- Time convention in the evidence and answer prompts: "yesterday" → absolute date; weekday-relative → "the <weekday> before <session date>"; "last week" → "the week before <session date>"; "last year" → year. No self-computed weekday arithmetic.
- Answer-first rule: answer the best-matching memory instead of opening with "no evidence"; do not add unrequested details.
- Adaptive budget: when the planner flags `aggregate` or answer_type ∈ {list, count}, use 45 turn hits / 130 pool turns and 2 expansion rounds.
- Trait questions get short traits; evidence `max_tokens` raised to 4000.

### v2.2 — dev split (304 q), judged 2026-10-11
```bash
cd develop && PYTHONPATH=$DEV $PY -m vmem2.run --out runs/vmem2_v2_dev/results.json --conv-ids $DEV_CONVS --concurrency 14
PYTHONPATH=$DEV $PY -m common.evaluate --input runs/vmem2_v2_dev/results.json --output runs/vmem2_v2_dev/metrics.json
```
| Cat | n | NEMORI | v2.1 | **v2.2** | C1 (NEMORI ctx + v2 answer prompt) |
|---|---:|---:|---:|---:|---:|
| 1 | 63 | 0.7937 | 0.9206 | 0.9365 | 0.7937 |
| 2 | 64 | 0.8438 | 0.9062 | 0.9375 | 0.8594 |
| 3 | 21 | 0.7143 | 0.8095 | 0.7619 | 0.8095 |
| 4 | 156 | 0.8846 | 0.9551 | 0.9551 | 0.8846 |
| overall | 304 | 0.8454 | 0.9276 | **0.9342 (+8.9 pp)** | 0.8553 (+1.0 pp) |

- v2.2 cost: 946 calls, 7.05 M prompt tokens, $43.5 on dev (~$0.143/q).
- Control C1 (`controls/nemori_newprompt.py`): NEMORI's own retrieved context answered with the v2 answer prompt gives only +1 pp. So the v2 gain comes from retrieval and evidence construction, not from the answer prompt or format.
- v2.1 → v2.2 flips: 7 wrong→right, 5 right→wrong.

**v2.2 remaining errors (20):**
- Weekday-relative dates are still computed (4). Cause: NEMORI episode summaries already contain computed days ("the previous Saturday (May 20, 2023)"), and the cards copy them, so the prompt rule is overridden.
- Wrong-year questions still abstain (2).
- Counting/coverage errors (2).
- Inference-question noise (cat3).

### v2.3 changes (generic, label-free, code-level)
- **Deterministic time normalisation.** If a card's verbatim quote comes from a raw turn and contains "last/this past <weekday|weekend|week|month>", the card time is overwritten in code with "the <X> before <session date>". Calendar dates in the claim are replaced by the same phrase. The answer prompt says to use that form.
- **Abstain retry.** If the final answer starts with "there is no evidence / not mentioned / cannot determine…", one more answer call is made with a "do not abstain; answer with the best-matching memory" note.
- Backup of the v2.2 pipeline: `runs/_pipeline_v2_2_backup.py`.

### v2.3 — dev split (304 q)
`runs/vmem2_v3_dev/`: overall **0.9342**, the same as v2.2 (cat1 0.9048, cat2 0.9531, cat3 0.7143, cat4 0.9679). $44.3.
- All 4 targeted errors were fixed: 2 weekday-relative dates and 2 wrong-year abstentions.
- 4 unrelated right→wrong flips: list items dropped and inference wording. These are run-to-run LLM noise, which is about ±4 questions (≈1.3 pp) on dev.
- Further dev tuning would fit noise, so the **config was locked at v2.3** (the `Config()` defaults in `vmem2/pipeline.py`).

## 5. Final results — VMem-v2.3, locked config (2026-10-11)
```bash
PYTHONPATH=$DEV $PY -m vmem2.run --out runs/vmem2_v3_holdout/results.json --conv-ids $HOLDOUT_CONVS --concurrency 14
PYTHONPATH=$DEV $PY -m common.evaluate --input runs/vmem2_v3_holdout/results.json --output runs/vmem2_v3_holdout/metrics.json
```
- Holdout was run once, with 0 errors. Cost: 3850 calls, 24.3 M prompt tokens, $154.5 (~$0.125/q).
- Full-set numbers = dev run (`vmem2_v3_dev`) + holdout run.
- Paired tests are against the same-question baselines: bootstrap 95% CI (5000 resamples) and exact sign test on discordant pairs (McNemar).

### Holdout (8 conversations, never inspected during development)
| Cat | n | NEMORI | VMem orig | **VMem-v2.3** | Δ vs NEMORI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---:|
| 1 multi-hop | 219 | 0.6849 | 0.5753 | **0.8904** | +0.206 | 51/6 | 6e-10 |
| 2 temporal | 257 | 0.7626 | 0.6615 | **0.8833** | +0.121 | 39/8 | 6e-6 |
| 3 open-domain | 75 | 0.5867 | 0.5333 | **0.7067** | +0.120 | 11/2 | 0.022 |
| 4 single-hop | 685 | 0.8701 | 0.8131 | **0.9387** | +0.069 | 63/16 | 9e-8 |
| **overall** | 1236 | 0.7977 | 0.7225 | **0.9045** | **+0.107** [+0.087, +0.129] | 164/32 | 1e-22 |

### All LoCoMo (1540 q)
| Cat | n | NEMORI | VMem orig | **VMem-v2.3** | Δ vs NEMORI | W/L | p |
|---|---:|---:|---:|---:|---:|---|---:|
| 1 | 282 | 0.7092 | 0.5780 | **0.8936** | +0.184 | 59/7 | 2e-11 |
| 2 | 321 | 0.7788 | 0.6791 | **0.8972** | +0.118 | 48/10 | 5e-7 |
| 3 | 96 | 0.6146 | 0.5833 | **0.7083** | +0.094 | 14/5 | 0.064 |
| 4 | 841 | 0.8728 | 0.8240 | **0.9441** | +0.071 | 78/18 | 4e-10 |
| **overall** | 1540 | 0.8071 | 0.7338 | **0.9104** | **+0.103** [+0.084, +0.122] | 199/40 | 1e-26 |

- vs original VMem: +0.177 overall [+0.153, +0.201], W/L 350/78.
- The paired comparison vs NEMORI matched 1539/1540 rows; one NEMORI row has a key mismatch, which changes overall accuracy by <0.1 pp.
- The holdout gain (+10.7 pp) is *larger* than the dev gain (+8.9 pp), so there is no sign of overfitting to dev.
- The goal (≥ +5 pp over NEMORI) is met with a wide margin: the lower bound of the CI is +8.4 pp.
- Cost: VMem-v2.3 uses ~23k prompt tokens/q vs NEMORI's ~5.2k, i.e. about 4.5× the LLM cost per question.

### Possible next steps
- Report extracted-answer F1/BLEU as a secondary view.
- Run a cross-judge (e.g. a non-Opus judge via `--judge-model`).
- Ablate the components (planner / multi-granularity retrieval / cards / expansion).
- Repeat runs to measure run-to-run variance.
- Build a cheaper variant (e.g. Sonnet for planning/evidence).
