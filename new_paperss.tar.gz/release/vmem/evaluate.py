"""LoCoMo scorer (LLM-judge accuracy, F1, BLEU-1) for VMem results files.

* LLM judge: upstream NEMORI / Mem0 ACCURACY_PROMPT and system message, verbatim
  (nemori/evaluation/locomo/metrics/llm_judge.py @d2a6dff), temperature 0.
  Judge model defaults to Claude Opus 4.5 (Bedrock); `--judge-model` allows a cross-judge.
* F1: set-based token F1 (upstream metrics/utils.py::calculate_metrics, verbatim logic).
* BLEU: BLEU-1 with smoothing method1 (upstream metrics/utils.py::calculate_bleu_scores).
* Category 5 is skipped, as upstream.

Usage:
  python -m vmem.evaluate --input outputs/x/results.json --output outputs/x/metrics.json --data locomo10.json [--conv-ids ...]
Judge calls are cached in cache/judge/ (override with VMEM_JUDGE_CACHE).
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

import nltk
from nltk.translate.bleu_score import SmoothingFunction, sentence_bleu

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from vmem.llm import DEFAULT_MODEL, acomplete, usage_summary  # noqa: E402

for _pkg in ("punkt", "punkt_tab"):
    try:
        nltk.data.find(f"tokenizers/{_pkg}")
    except LookupError:
        nltk.download(_pkg, quiet=True)

JUDGE_SYSTEM = "You are an expert grader that determines if answers to questions match a gold standard answer."
ACCURACY_PROMPT = """
Your task is to label an answer to a question as ’CORRECT’ or ’WRONG’. You will be given the following data:
    (1) a question (posed by one user to another user),
    (2) a ’gold’ (ground truth) answer,
    (3) a generated answer
which you will score as CORRECT/WRONG.

The point of the question is to ask about something one user should know about the other user based on their prior conversations.
The gold answer will usually be a concise and short answer that includes the referenced topic, for example:
Question: Do you remember what I got the last time I went to Hawaii?
Gold answer: A shell necklace
The generated answer might be much longer, but you should be generous with your grading - as long as it touches on the same topic as the gold answer, it should be counted as CORRECT.

For time related questions, the gold answer will be a specific date, month, year, etc. The generated answer might be much longer or use relative time references (like "last Tuesday" or "next month"), but you should be generous with your grading - as long as it refers to the same date or time period as the gold answer, it should be counted as CORRECT. Even if the format differs (e.g., "May 7th" vs "7 May"), consider it CORRECT if it's the same date.

Now it’s time for the real question:
Question: {question}
Gold answer: {gold_answer}
Generated answer: {generated_answer}

First, provide a short (one sentence) explanation of your reasoning, then finish with CORRECT or WRONG.
Do NOT include both CORRECT and WRONG in your response, or it will break the evaluation script.

Just return the label CORRECT or WRONG in a json format with the key as "label".
"""


def simple_tokenize(text):
    text = str(text)
    return text.lower().replace(".", " ").replace(",", " ").replace("!", " ").replace("?", " ").split()


def f1_score(prediction: str, reference: str) -> float:
    if not prediction or not reference:
        return 0.0
    p, r = set(simple_tokenize(str(prediction).strip())), set(simple_tokenize(str(reference).strip()))
    if not p or not r:
        return 0.0
    c = p & r
    prec, rec = len(c) / len(p), len(c) / len(r)
    return 2 * prec * rec / (prec + rec) if prec + rec > 0 else 0.0


def bleu1(prediction: str, reference: str) -> float:
    pred = nltk.word_tokenize(str(prediction).lower())
    ref = [nltk.word_tokenize(str(reference).lower())]
    try:
        return sentence_bleu(ref, pred, weights=(1, 0, 0, 0), smoothing_function=SmoothingFunction().method1)
    except Exception:
        return 0.0


def _parse_label(text: str) -> int:
    m = re.search(r'"label"\s*:\s*"?\s*(CORRECT|WRONG)', text or "", re.I)
    if m:
        return int(m.group(1).upper() == "CORRECT")
    has_c, has_w = "CORRECT" in (text or "").upper(), "WRONG" in (text or "").upper()
    return int(has_c and not has_w)


class JudgeCache:
    def __init__(self, path: Path):
        self.path = path
        self.data: dict[str, int] = {}
        if path.exists():
            for line in path.read_text().splitlines():
                try:
                    rec = json.loads(line)
                    self.data[rec["k"]] = rec["v"]
                except Exception:
                    pass
        self._fh = open(path, "a")

    @staticmethod
    def key(model, q, g, a):
        return hashlib.sha1(json.dumps([model, q, g, a]).encode()).hexdigest()

    def get(self, k):
        return self.data.get(k)

    def put(self, k, v):
        self.data[k] = v
        self._fh.write(json.dumps({"k": k, "v": v}) + "\n")
        self._fh.flush()


async def judge(question, gold, answer, model, cache: JudgeCache) -> int:
    k = cache.key(model, question, str(gold), str(answer))
    hit = cache.get(k)
    if hit is not None:
        return hit
    text, _ = await acomplete(
        [{"role": "user", "content": ACCURACY_PROMPT.format(question=question, gold_answer=gold, generated_answer=answer)}],
        system=JUDGE_SYSTEM, model=model, temperature=0.0, max_tokens=256, tag="judge",
    )
    v = _parse_label(text)
    cache.put(k, v)
    return v


def load_records(path: str, conv_ids: set[str] | None, data_path: str | None):
    """Results files are {conv_idx: [record, ...]} as written by upstream search.py."""
    data = json.loads(Path(path).read_text())
    sample_ids = None
    if data_path:
        sample_ids = [s["sample_id"] for s in json.loads(Path(data_path).read_text())]
    out = []
    for k, items in data.items():
        sid = sample_ids[int(k)] if sample_ids else k
        if conv_ids and sid not in conv_ids:
            continue
        for i, it in enumerate(items):
            if str(it.get("category")) == "5":
                continue
            out.append((sid, i, it))
    return out


def summarize(rows: list[dict]) -> dict:
    by = defaultdict(list)
    for r in rows:
        by[str(r["category"])].append(r)
        by["overall"].append(r)
    summ = {}
    for c, rs in sorted(by.items()):
        n = len(rs)
        summ[c] = {
            "n": n,
            "llm": round(sum(r["llm_score"] for r in rs) / n, 4),
            "f1": round(sum(r["f1_score"] for r in rs) / n, 4),
            "bleu1": round(sum(r["bleu_score"] for r in rs) / n, 4),
        }
        pt = [r["prompt_tokens"] for r in rs if r.get("prompt_tokens") is not None]
        if pt:
            summ[c]["avg_prompt_tokens"] = round(sum(pt) / len(pt), 1)
    return summ


async def main_async(args):
    model = args.judge_model or DEFAULT_MODEL
    cache_dir = Path(os.environ.get("VMEM_JUDGE_CACHE", Path(__file__).resolve().parents[1] / "cache" / "judge"))
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = JudgeCache(cache_dir / (re.sub(r"[^A-Za-z0-9]+", "_", model) + ".jsonl"))
    conv_ids = set(args.conv_ids.split(",")) if args.conv_ids else None
    recs = load_records(args.input, conv_ids, args.data)

    async def one(sid, i, it):
        resp = str(it.get("response", ""))
        gold = str(it.get("answer"))
        score = await judge(str(it["question"]), gold, resp, model, cache)
        u = it.get("usage") or {}
        return {
            "conv": sid, "idx": i, "question": it["question"], "answer": gold, "response": resp,
            "category": str(it["category"]), "llm_score": score,
            "f1_score": f1_score(resp, gold), "bleu_score": bleu1(resp, gold),
            "prompt_tokens": it.get("prompt_tokens", u.get("prompt_tokens")),
            "completion_tokens": it.get("completion_tokens", u.get("completion_tokens")),
        }

    rows = await asyncio.gather(*[one(*r) for r in recs])
    summ = summarize(rows)
    out = {"input": args.input, "judge_model": model, "summary": summ, "rows": rows}
    Path(args.output).write_text(json.dumps(out, indent=1, ensure_ascii=False))
    print(json.dumps(summ, indent=1))
    print("judge usage:", usage_summary().get("judge"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--conv-ids", default=None)
    ap.add_argument("--data", default=os.environ.get("LOCOMO"))
    ap.add_argument("--judge-model", default=None)
    asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    main()
