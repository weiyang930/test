"""LLM access layer for VMem (planning, evidence construction, answering) and the LoCoMo judge.

All calls go through `acomplete` (LiteLLM). The default model is Claude Opus 4.5 on AWS Bedrock;
set VMEM_LLM_MODEL to any LiteLLM model string to switch backbones (e.g.
bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0). Bedrock credentials are taken from the
standard AWS environment (AWS_REGION, AWS_PROFILE / AWS_ACCESS_KEY_ID ...).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import re
import threading
import time
from collections import defaultdict

import litellm

litellm.drop_params = True
litellm.suppress_debug_info = True
logging.getLogger("LiteLLM").setLevel(logging.WARNING)

DEFAULT_MODEL = os.environ.get("VMEM_LLM_MODEL", "bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0")
# Bedrock starts throttling above ~22 concurrent Opus calls per profile; stay below.
MAX_CONCURRENT = int(os.environ.get("VMEM_LLM_CONCURRENCY", "16"))
REQUEST_TIMEOUT = float(os.environ.get("VMEM_LLM_TIMEOUT", "300"))
MAX_RETRIES = int(os.environ.get("VMEM_LLM_RETRIES", "8"))

# Opus 4.5 list price (USD per 1M tokens), used only for cost reporting; override for other models
# (e.g. Haiku 4.5: VMEM_PRICE_IN=1 VMEM_PRICE_OUT=5).
PRICE_IN = float(os.environ.get("VMEM_PRICE_IN", "5.0"))
PRICE_OUT = float(os.environ.get("VMEM_PRICE_OUT", "25.0"))

_sems: dict[int, asyncio.Semaphore] = {}
_usage_lock = threading.Lock()
USAGE: dict[str, dict[str, int]] = defaultdict(lambda: {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0})


def _sem() -> asyncio.Semaphore:
    loop = asyncio.get_running_loop()
    key = id(loop)
    if key not in _sems:
        _sems[key] = asyncio.Semaphore(MAX_CONCURRENT)
    return _sems[key]


_FENCE = re.compile(r"^\s*```(?:json)?\s*(.*?)\s*```\s*$", re.S)


def strip_json(text: str) -> str:
    """Return the JSON payload of a reply: drop ``` fences / leading prose."""
    m = _FENCE.match(text or "")
    if m:
        return m.group(1)
    t = (text or "").strip()
    if t and t[0] not in "[{":
        i = min([p for p in (t.find("{"), t.find("[")) if p >= 0], default=-1)
        if i >= 0:
            t = t[i:]
    return t


def parse_json(text: str):
    t = strip_json(text)
    try:
        return json.loads(t)
    except Exception:
        # tolerate trailing prose after the JSON object
        for end in range(len(t), 0, -1):
            if t[end - 1] in "}]":
                try:
                    return json.loads(t[:end])
                except Exception:
                    continue
        raise


def _retryable(e: Exception) -> bool:
    s = f"{type(e).__name__} {e}".lower()
    return any(k in s for k in ("throttl", "rate", "429", "timeout", "timed out", "503", "500", "overload",
                                "serviceunavailable", "internalserver", "connection", "too many"))


async def acomplete(
    messages: list[dict],
    *,
    model: str | None = None,
    temperature: float = 0.0,
    max_tokens: int = 2000,
    json_mode: bool = False,
    tag: str = "default",
    system: str | None = None,
) -> tuple[str, dict[str, int]]:
    """Single chat completion. Returns (text, usage)."""
    model = model or DEFAULT_MODEL
    msgs = list(messages)
    if system:
        msgs = [{"role": "system", "content": system}] + msgs
    last = None
    for attempt in range(MAX_RETRIES):
        try:
            async with _sem():
                r = await litellm.acompletion(
                    model=model,
                    messages=msgs,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    request_timeout=REQUEST_TIMEOUT,
                    num_retries=0,
                )
            text = r.choices[0].message.content or ""
            u = {"prompt_tokens": int(r.usage.prompt_tokens or 0), "completion_tokens": int(r.usage.completion_tokens or 0)}
            with _usage_lock:
                rec = USAGE[tag]
                rec["calls"] += 1
                rec["prompt_tokens"] += u["prompt_tokens"]
                rec["completion_tokens"] += u["completion_tokens"]
            if json_mode:
                text = strip_json(text)
            return text, u
        except Exception as e:  # noqa: BLE001
            last = e
            if not _retryable(e) and attempt >= 1:
                break
            await asyncio.sleep(min(60.0, 2.0 * (2 ** attempt)) * (0.5 + random.random()))
    raise RuntimeError(f"LLM call failed after retries: {last}")


def usage_summary() -> dict:
    with _usage_lock:
        out = {k: dict(v) for k, v in USAGE.items()}
    tot_in = sum(v["prompt_tokens"] for v in out.values())
    tot_out = sum(v["completion_tokens"] for v in out.values())
    out["_total"] = {
        "calls": sum(v["calls"] for v in out.values()),
        "prompt_tokens": tot_in,
        "completion_tokens": tot_out,
        "cost_usd": round(tot_in / 1e6 * PRICE_IN + tot_out / 1e6 * PRICE_OUT, 2),
    }
    return out


def complete_sync(messages: list[dict], **kw) -> tuple[str, dict[str, int]]:
    """Blocking wrapper (used by the thread-pool based judge)."""
    return asyncio.run(acomplete(messages, **kw))
