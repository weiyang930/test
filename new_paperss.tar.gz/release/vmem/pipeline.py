"""VMem: query-conditioned, source-grounded evidence construction over the NEMORI store.

Pipeline (no benchmark category labels are used anywhere):

  1. Query planning (LLM)      – infer information need, answer type, and a set of
                                 diverse search queries (sub-questions, paraphrases, keywords).
  2. Multi-route retrieval     – dense + BM25 over three granularities of the SAME store
                                 (episodes, semantic memories, raw source turns), fused by RRF
                                 across all planned queries; provenance expansion
                                 (semantic -> source episode -> source turns) and local turn context.
  3. Evidence construction     – the LLM turns the candidate pool into ViewCards
     (LLM)                       {claim, source ids, verbatim quote, resolved time, relation}.
  4. Source verification       – every card quote is checked against the cited source text;
                                 unverifiable cards are flagged (not trusted as evidence).
  5. Dynamic expansion         – if the constructor reports missing information, its follow-up
                                 queries are retrieved and step 3 is repeated on the new evidence.
  6. Answering (LLM)           – verified ViewCards first, cited raw sources second, and the full
                                 retrieved pool as fallback context (cards never hide raw memory).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher

import numpy as np

from vmem.llm import acomplete, parse_json
from vmem.store import Item, Store, UserIndex, fmt_date, tokenize


@dataclass
class Config:
    # retrieval
    rrf_k: int = 60
    dense_k: int = 20
    sparse_k: int = 12
    pool_episodes: int = 10
    pool_semantic: int = 20
    pool_turn_hits: int = 30
    turn_context: int = 1           # +-turns of local context around each hit
    max_pool_turns: int = 90
    # evidence construction
    expansion_rounds: int = 1
    # adaptive budget for aggregation questions (decided by the LLM planner, not by category labels)
    agg_turn_hits: int = 45
    agg_max_pool_turns: int = 130
    agg_expansion_rounds: int = 2
    evidence_max_tokens: int = 4000
    # answer
    answer_max_tokens: int = 1200
    include_pool_in_answer: bool = True
    plan: bool = True
    cards: bool = True
    # v2.3: deterministic time normalisation of cards + one retry when the answer abstains
    norm_time: bool = True
    abstain_retry: bool = True


@dataclass
class Trace:
    plan: dict = field(default_factory=dict)
    queries: list = field(default_factory=list)
    cards: list = field(default_factory=list)
    rounds: int = 0
    pool_sizes: dict = field(default_factory=dict)
    usage: dict = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0, "calls": 0})
    raw: dict = field(default_factory=dict)
    pool_ids: dict = field(default_factory=dict)   # item ids shown to the LLM (diagnostics only)

    def add_usage(self, u):
        self.usage["prompt_tokens"] += u["prompt_tokens"]
        self.usage["completion_tokens"] += u["completion_tokens"]
        self.usage["calls"] += 1


# --------------------------------------------------------------------------- prompts

PLAN_PROMPT = """You are the query planner of a long-term conversational memory system.
The memory stores a long multi-session conversation between {speakers}. Sessions span {span}.

Question: {question}

Analyse what information is needed to answer the question and plan retrieval. Think about:
- which person(s), objects, events and attributes the question is about (resolve "he/she/they" to names when obvious),
- whether the answer needs several facts combined (multi-hop), facts aggregated over many sessions (lists, counts, "what activities/places/books..."), a date or time computation, or an inference about someone's preferences, personality or likely behaviour,
- which intermediate facts must be found first (e.g. to answer "What did X do after Y?" first find when Y happened).

Return ONLY a JSON object:
{{
  "need": "<one sentence describing the information need>",
  "answer_type": "<one of: date, duration, count, list, yes_no, entity, description, reason, inference>",
  "aggregate": <true if the answer may be spread over multiple sessions, else false>,
  "temporal": <true if a date/time/order must be determined, else false>,
  "queries": ["<4-6 short, diverse search queries: sub-questions for intermediate facts, paraphrases with likely conversational wording, and key entity/keyword queries>"]
}}"""

EVIDENCE_PROMPT = """You are the evidence constructor of a long-term conversational memory system.
Your job is NOT to answer the question but to build compact, source-grounded evidence cards that make the facts needed to answer it explicit.

Question: {question}
Information need: {need}

Candidate memories retrieved from the memory store (each has an ID; [E*] episode summaries, [S*] semantic facts, [T*] raw conversation turns with their session date):
{pool}
{previous}
Instructions:
1. Find every memory relevant to the question. For list/count/"what activities" questions collect ALL distinct instances across sessions; for multi-hop questions collect each intermediate fact.
2. For each relevant fact write a card. Prefer raw turns [T*] as sources because they are the original words; use [E*]/[S*] when no turn is available.
3. "quote" must be copied VERBATIM from the cited source (a short span, max ~30 words) — never paraphrase inside "quote".
4. "time": when the fact happened, resolved against the session date of the source: "yesterday" -> "11 March 2031" (absolute date); "last Friday"/"last weekend" -> "the Friday/weekend before 12 March 2031" (keep weekday-relative expressions relative to the session date, do not compute the calendar day); "last week" -> "the week before 12 March 2031"; "last year" -> "2030"; no relative expression -> the session date. Use "" if not time-relevant.
5. "relation": in a few words, how this card bears on the question (e.g. "answer candidate", "intermediate fact: date of Y", "supports inference: likes outdoors", "contradicts card 2").
6. Do not invent facts. If the memories conflict, make cards for both and note it in "relation".
7. Then judge whether the cards suffice. If key information is missing, give up to 3 follow-up search queries aimed precisely at the missing facts.

Return ONLY a JSON object:
{{
  "cards": [{{"claim": "<fact relevant to the question, self-contained, with names>", "sources": ["T3"], "quote": "<verbatim span>", "time": "<absolute time or empty>", "relation": "<role>"}}],
  "sufficient": <true/false>,
  "missing": "<what is still missing, or empty>",
  "follow_up_queries": ["..."]
}}"""

ANSWER_PROMPT = """You are an intelligent memory assistant answering questions about a long-term conversation between {speakers}, using evidence retrieved from memory.

# QUESTION
{question}

# EVIDENCE CARDS (constructed for this question; each claim is grounded in a verbatim quote from the cited source; cards marked UNVERIFIED could not be matched to their source and must be treated with caution)
{cards}

# CITED SOURCE CONTEXT (original conversation turns around the cited evidence, with session dates)
{sources}

# OTHER RETRIEVED MEMORIES (background; use them if the cards miss something)
{pool}

# INSTRUCTIONS
1. Base the answer on the evidence. Prefer verified cards and original turns; use episode summaries and semantic facts to fill gaps.
2. Time. Dates shown are session dates (the day the conversation took place). Express event times the way people resolve them against the session date:
   - "yesterday", "today", "this morning", "two days ago" -> the absolute calendar date (e.g. said on 12 March 2031 "yesterday" -> 11 March 2031);
   - "last Friday", "last Sunday", "on the weekend" (a weekday-relative expression) -> "the Friday before 12 March 2031" (relative to the session date; do NOT convert it into a calendar day yourself);
   - "last week", "last month", "a few days ago" -> "the week before 4 April 2031", "the month before ..." , "a few days before ...";
   - "last year", "next month" -> the year / month (e.g. said in 2031 "last year" -> 2030).
   If the event is reported without a relative expression, its time is the session date itself.
   When a card's time is of the form "the <weekday/week/weekend> before <date>", that is the resolved time: give it in exactly that form (episode summaries may contain mis-computed calendar days).
3. Lists / "what activities", "what books", "how many": aggregate ALL distinct items found across all sessions; count carefully and de-duplicate.
4. Questions about likely preferences, personality, opinions or hypotheticals ("Would X ...", "What might X ...", "Is X likely ..."): give the most plausible answer inferred from the evidence (start with "Probably yes"/"Probably no" for yes/no questions) rather than refusing. For questions about someone's traits or attributes, answer with a few short descriptive traits.
5. Always give the answer first. If the question's details (e.g. a date or name) do not exactly match the memories, answer with the memory that best matches the rest of the question — do not start with "there is no evidence".
6. Answer exactly what is asked; do not add extra facts, dates or explanations that are not asked for.
7. The final answer must be short and direct: a phrase, name, date, list or short sentence (ideally under 15 words).

First think briefly step by step (max ~120 words) under "REASONING:", then give the answer on the last line exactly as:
FINAL ANSWER: <answer>"""


# --------------------------------------------------------------------------- helpers

_WD = {"mon": "Monday", "tue": "Tuesday", "wed": "Wednesday", "thu": "Thursday", "fri": "Friday",
       "sat": "Saturday", "sun": "Sunday"}
_REL_RE = re.compile(r"\b(?:last|this past|past)\s+(weekend|week|month|(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?)\b", re.I)
_ABSTAIN_RE = re.compile(r"^\W*(there is no|there's no|no (?:evidence|information|record|mention)|not (?:mentioned|specified|stated)|"
                         r"(?:the )?(?:memories|evidence|conversation) (?:do(?:es)? not|don't)|cannot (?:be )?determine|unknown|insufficient)", re.I)

ABSTAIN_RETRY = """

# NOTE
Your previous final answer was: "{prev}". A question usually refers to something that is in the conversation even when a detail in it (e.g. the year, month or a name) may be slightly wrong. Do not abstain: answer with the memory that best matches the question, as a short direct answer."""


def day_str(ts) -> str:
    """ISO timestamp -> '12 March 2031'."""
    from datetime import datetime
    try:
        d = datetime.fromisoformat(ts) if isinstance(ts, str) else ts
        return f"{d.day} {d.strftime('%B %Y')}"
    except Exception:
        return ""


def relative_time(quote: str, ts) -> str | None:
    """Resolve a weekday/week-relative expression in a source quote against the session date,
    the way people state it ('last Saturday' said on 12 March 2031 -> 'the Saturday before 12 March 2031')."""
    m = _REL_RE.search(quote or "")
    day = day_str(ts)
    if not m or not day:
        return None
    w = m.group(1).lower().rstrip(".")
    if w in ("weekend", "week", "month"):
        return f"the {w} before {day}"
    full = _WD.get(w[:3])
    return f"the {full} before {day}" if full else None

def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", (s or "").lower())).strip()


def verify_quote(quote: str, sources: list[str]) -> float:
    """Return support score in [0,1]: 1.0 if the normalized quote is a substring of a cited source,
    otherwise best fuzzy partial-match ratio."""
    q = _norm(quote)
    if not q:
        return 0.0
    best = 0.0
    for s in sources:
        n = _norm(s)
        if q in n:
            return 1.0
        if not n:
            continue
        sm = SequenceMatcher(None, q, n, autojunk=False)
        m = sum(b.size for b in sm.get_matching_blocks())
        best = max(best, m / max(1, len(q)))
    return best


def rrf_fuse(lists: list[list[tuple[int, float]]], k: int) -> dict[int, float]:
    out: dict[int, float] = {}
    for lst in lists:
        for rank, (i, _) in enumerate(lst):
            out[i] = out.get(i, 0.0) + 1.0 / (k + rank + 1)
    return out


class VMem:
    def __init__(self, store: Store, cfg: Config, model: str | None = None):
        self.store = store
        self.cfg = cfg
        self.model = model

    async def _llm(self, prompt: str, trace: Trace, tag: str, max_tokens: int = 2000, json_mode=False):
        text, u = await acomplete([{"role": "user", "content": prompt}], model=self.model, temperature=0.0,
                                  max_tokens=max_tokens, json_mode=json_mode, tag=tag)
        trace.add_usage(u)
        return text

    # ------------------------------------------------------------------ retrieval
    async def retrieve(self, idx: UserIndex, queries: list[str], exclude: set[int] | None = None,
                       turn_hits: int | None = None, max_turns: int | None = None):
        cfg = self.cfg
        turn_hits = turn_hits or cfg.pool_turn_hits
        max_turns = max_turns or cfg.max_pool_turns
        exclude = exclude or set()
        per_kind: dict[str, list[list[tuple[int, float]]]] = {"episode": [], "semantic": [], "turn": []}
        for q in queries:
            qv = await self.store.qvec(q)
            for kind in per_kind:
                per_kind[kind].append(idx.dense(qv, kind, cfg.dense_k))
                per_kind[kind].append(idx.sparse(q, kind, cfg.sparse_k))
        fused = {k: rrf_fuse(v, cfg.rrf_k) for k, v in per_kind.items()}

        # provenance: semantic/episode hits vote for their source turns' episode
        ep_bonus: dict[str, float] = {}
        for i, s in fused["semantic"].items():
            e = idx.items[i].episode_id
            if e:
                ep_bonus[e] = ep_bonus.get(e, 0.0) + 0.5 * s
        for i, s in list(fused["episode"].items()):
            ep_bonus[idx.items[i].id] = ep_bonus.get(idx.items[i].id, 0.0) + s
        for e, b in ep_bonus.items():
            j = idx.by_id.get(e)
            if j is not None:
                fused["episode"][j] = fused["episode"].get(j, 0.0) + 0.3 * b

        def top(kind, n):
            return [i for i, _ in sorted(fused[kind].items(), key=lambda x: -x[1]) if i not in exclude][:n]

        episodes = top("episode", cfg.pool_episodes)
        semantic = top("semantic", cfg.pool_semantic)
        hits = top("turn", turn_hits)
        turns: list[int] = []
        seen = set()
        for h in hits:
            for j in idx.neighbors(h, cfg.turn_context):
                if j not in seen and j not in exclude:
                    seen.add(j)
                    turns.append(j)
            if len(turns) >= max_turns:
                break
        return episodes, semantic, turns

    # ------------------------------------------------------------------ formatting
    @staticmethod
    def format_pool(idx: UserIndex, episodes, semantic, turns, labels: dict[int, str]) -> str:
        lines = []
        if episodes:
            lines.append("## Episodes")
            for i in sorted(episodes, key=lambda j: idx.items[j].ts):
                it = idx.items[i]
                lines.append(f"[{labels[i]}] ({it.date()}) {it.text}")
        if semantic:
            lines.append("## Semantic facts")
            for i in sorted(semantic, key=lambda j: idx.items[j].ts):
                it = idx.items[i]
                lines.append(f"[{labels[i]}] (learned in session of {fmt_date(it.ts)[:-7]}) {it.text}")
        if turns:
            lines.append("## Conversation turns (grouped by session, chronological)")
            cur = None
            for i in sorted(turns, key=lambda j: (idx.items[j].ts, idx.items[j].order)):
                it = idx.items[i]
                d = it.date()
                if d != cur:
                    lines.append(f"-- session {d} --")
                    cur = d
                lines.append(f"[{labels[i]}] {it.text}")
        return "\n".join(lines)

    @staticmethod
    def assign_labels(idx: UserIndex, items: list[int], labels: dict[int, str], counters: dict[str, int]):
        pref = {"episode": "E", "semantic": "S", "turn": "T"}
        for i in items:
            if i in labels:
                continue
            k = idx.items[i].kind
            counters[k] = counters.get(k, 0) + 1
            labels[i] = f"{pref[k]}{counters[k]}"

    # ------------------------------------------------------------------ main entry
    async def answer(self, user_id: str, question: str, speakers: str) -> tuple[str, Trace]:
        cfg = self.cfg
        trace = Trace()
        idx = await self.store.index(user_id)
        dates = sorted(idx.items[i].ts for i in idx.by_kind.get("turn", []))
        span = f"{fmt_date(dates[0])[:-7]} to {fmt_date(dates[-1])[:-7]}" if dates else "unknown"

        # 1. plan
        plan = {"need": question, "queries": []}
        if cfg.plan:
            txt = await self._llm(PLAN_PROMPT.format(speakers=speakers, span=span, question=question),
                                  trace, "plan", 800, json_mode=True)
            try:
                plan = parse_json(txt)
            except Exception:
                plan = {"need": question, "queries": []}
        trace.plan = plan
        queries = [question] + [q for q in plan.get("queries", []) if isinstance(q, str) and q.strip()][:6]
        trace.queries = list(queries)

        # 2. retrieve (adaptive budget: aggregation questions get a wider pool and more expansion rounds)
        aggregate = bool(plan.get("aggregate")) or str(plan.get("answer_type", "")).lower() in ("list", "count")
        rounds = cfg.agg_expansion_rounds if aggregate else cfg.expansion_rounds
        episodes, semantic, turns = await self.retrieve(
            idx, queries, turn_hits=cfg.agg_turn_hits if aggregate else None,
            max_turns=cfg.agg_max_pool_turns if aggregate else None)
        labels: dict[int, str] = {}
        counters: dict[str, int] = {}
        self.assign_labels(idx, episodes + semantic + turns, labels, counters)
        pool_items = set(episodes) | set(semantic) | set(turns)

        cards: list[dict] = []
        if cfg.cards:
            # 3. evidence construction (+ 5. dynamic expansion)
            new_e, new_s, new_t = episodes, semantic, turns
            previous = ""
            for rnd in range(1 + rounds):
                pool_txt = self.format_pool(idx, new_e, new_s, new_t, labels)
                txt = await self._llm(EVIDENCE_PROMPT.format(question=question, need=plan.get("need", question),
                                                             pool=pool_txt, previous=previous),
                                      trace, "evidence", cfg.evidence_max_tokens, json_mode=True)
                try:
                    ev = parse_json(txt)
                except Exception:
                    ev = {"cards": [], "sufficient": True}
                trace.raw.setdefault("evidence", []).append({k: ev.get(k) for k in ("sufficient", "missing", "follow_up_queries")})
                cards.extend(c for c in ev.get("cards", []) if isinstance(c, dict))
                trace.rounds = rnd + 1
                fq = [q for q in ev.get("follow_up_queries", []) or [] if isinstance(q, str) and q.strip()][:3]
                if ev.get("sufficient", True) or not fq or rnd == rounds:
                    break
                trace.queries.extend(fq)
                new_e, new_s, new_t = await self.retrieve(idx, fq, exclude=pool_items)
                new_e, new_s, new_t = new_e[:6], new_s[:10], new_t[:40]
                if not (new_e or new_s or new_t):
                    break
                self.assign_labels(idx, new_e + new_s + new_t, labels, counters)
                pool_items |= set(new_e) | set(new_s) | set(new_t)
                episodes, semantic, turns = episodes + new_e, semantic + new_s, turns + new_t
                previous = ("\nEvidence cards already constructed in the previous round (do not repeat them; "
                            "add only new facts from the NEW memories above):\n" +
                            "\n".join(f"- {c.get('claim')} [{','.join(map(str, c.get('sources', [])))}]" for c in cards) + "\n")

            # 4. source verification
            inv = {v: k for k, v in labels.items()}
            for c in cards:
                srcs = [inv[s] for s in map(str, c.get("sources", []) or []) if s in inv]
                texts = [idx.items[i].text for i in srcs]
                c["support"] = round(verify_quote(str(c.get("quote", "")), texts), 3) if texts else 0.0
                c["verified"] = c["support"] >= 0.8
                c["_src"] = srcs
                if cfg.norm_time:
                    for i in srcs:
                        it = idx.items[i]
                        if it.kind == "turn" and c.get("quote") and _norm(str(c["quote"]))[:40] in _norm(it.text):
                            rt = relative_time(str(c["quote"]), it.ts)
                            if rt:
                                c["time"] = rt
                                c["claim"] = re.sub(r",? ?(?:on )?(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)?,? "
                                                    r"(?:\d{1,2} )?(?:January|February|March|April|May|June|July|August|"
                                                    r"September|October|November|December) ?\d{0,2},? \d{4}", f" ({rt})",
                                                    str(c.get("claim", "")))
                            break
        trace.cards = [{k: v for k, v in c.items() if k != "_src"} for c in cards]
        trace.pool_sizes = {"episodes": len(episodes), "semantic": len(semantic), "turns": len(turns)}
        trace.pool_ids = {"episode": [idx.items[i].id for i in episodes], "semantic": [idx.items[i].id for i in semantic],
                          "turn": [idx.items[i].id for i in turns]}

        # 6. answer
        card_lines, cited = [], []
        for n, c in enumerate(cards, 1):
            flag = "" if c.get("verified") else " (UNVERIFIED)"
            t = f" | time: {c['time']}" if c.get("time") else ""
            card_lines.append(f"[{n}]{flag} claim: {c.get('claim')}{t}\n    source {','.join(map(str, c.get('sources', [])))}: \"{c.get('quote', '')}\""
                              + (f"\n    role: {c['relation']}" if c.get("relation") else ""))
            for i in c.get("_src", []):
                if idx.items[i].kind == "turn":
                    cited.extend(idx.neighbors(i, 2))
                elif idx.items[i].kind == "episode":
                    cited.extend(idx.turns_of_episode.get(idx.items[i].id, [])[:12])
        cited = list(dict.fromkeys(cited))
        trace.pool_ids["cited_turn"] = [idx.items[i].id for i in cited]
        self.assign_labels(idx, cited, labels, counters)
        src_txt = self.format_pool(idx, [], [], cited, labels) if cited else "(none)"
        pool_txt = self.format_pool(idx, episodes, semantic, [t for t in turns if t not in set(cited)], labels) \
            if cfg.include_pool_in_answer else "(omitted)"
        prompt = ANSWER_PROMPT.format(speakers=speakers, question=question,
                                      cards="\n".join(card_lines) or "(no cards)", sources=src_txt, pool=pool_txt)
        out = await self._llm(prompt, trace, "answer", cfg.answer_max_tokens)
        m = re.search(r"FINAL ANSWER:\s*(.+)", out, re.S | re.I)
        final = (m.group(1) if m else out).strip().split("\n")[0].strip()
        trace.raw["answer_output"] = out
        if cfg.abstain_retry and _ABSTAIN_RE.search(final):
            out2 = await self._llm(prompt + ABSTAIN_RETRY.format(prev=final), trace, "answer_retry", cfg.answer_max_tokens)
            m2 = re.search(r"FINAL ANSWER:\s*(.+)", out2, re.S | re.I)
            final2 = (m2.group(1) if m2 else out2).strip().split("\n")[0].strip()
            trace.raw["answer_retry_output"] = out2
            if final2:
                trace.raw["first_final"] = final
                final = final2
        return final, trace
