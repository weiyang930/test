#!/bin/bash
# Run VMem on LoCoMo (categories 1-4) and score it.
#   bash scripts/run_locomo.sh <locomo10.json> <out_dir> [conv-ids]
# Prerequisites (see README): embedding server on $EMBEDDING_BASE_URL, a memory store
# (VMEM_STORE=postgres + DATABASE_URL, or VMEM_STORE=json + VMEM_STORE_JSON), AWS Bedrock credentials.
# Backbone: VMEM_LLM_MODEL (default Claude Opus 4.5). The judge is always pinned to Opus 4.5.
set -e
cd "$(dirname "$0")/.."
DATA=${1:?locomo10.json}; OUT=${2:?out_dir}; CONVS=${3:-}
JUDGE=${VMEM_JUDGE_MODEL:-bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0}
mkdir -p "$OUT"
python -m vmem.run --data "$DATA" --out "$OUT/results.json" ${CONVS:+--conv-ids $CONVS} --concurrency ${VMEM_QA_CONCURRENCY:-14}
python -m vmem.evaluate --input "$OUT/results.json" --output "$OUT/metrics.json" --data "$DATA" --judge-model "$JUDGE"
