#!/bin/bash
# Start the embedding server (Qwen3-Embedding-4B) on one GPU in the background.
#   GPU=0 EMBED_PORT=18080 bash scripts/start_embed.sh
cd "$(dirname "$0")/.."
mkdir -p logs
CUDA_VISIBLE_DEVICES=${GPU:-0} nohup python tools/embed_server.py > logs/embed_server.log 2>&1 &
echo "embedding server pid $!  (log: logs/embed_server.log)"
