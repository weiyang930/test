"""Plot RUN_1018 Stage 1 curves from the CSVs written by extract_stage1.py (barrier_r2 vs decoupled_eta2, RTL | Lean).

Usage: <plot-venv>/bin/python plot_stage1.py [--dir ec_results/run1018_stage1]
"""
from __future__ import annotations

import argparse
import collections
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# reference categorical palette (dataviz skill, light mode): slot 1 blue, slot 2 orange; line style is the secondary encoding
STYLE = {
    "barrier_r2": dict(color="#2a78d6", ls="--", label="barrier_r2"),
    "decoupled_eta2": dict(color="#eb6834", ls="-", label="decoupled_eta2"),
}
STEP0 = "#8a8985"
# fixed per outcome so the same status has the same color in every panel
STATUS_COL = {"pass": "#1baf7a", "fail": "#2a78d6", "mismatch": "#2a78d6", "lean_error": "#2a78d6",
              "compile_error": "#eb6834", "syntax_error": "#eda100", "parse_fail": "#eda100", "repl_error": "#eb6834",
              "timeout": "#e87ba4", "sorry": "#8a8985"}
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
DOMAINS = ["rtl", "lean"]
TITLE = {"rtl": "RTL (SALV-7B, EQY)", "lean": "Lean (DS-Prover-V1.5-SFT)"}

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "axes.titlecolor": INK, "axes.titlesize": 11,
    "axes.labelsize": 9, "xtick.color": INK2, "ytick.color": INK2, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False, "legend.fontsize": 8, "lines.linewidth": 2,
    "font.size": 9, "text.color": INK,
})


def read(path: Path) -> list[dict]:
    return list(csv.DictReader(open(path)))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return np.nan


def smooth(y, w=10):
    y = np.asarray(y, float)
    out = np.full_like(y, np.nan)
    for i in range(len(y)):
        seg = y[max(0, i - w // 2): i + w // 2 + 1]
        seg = seg[~np.isnan(seg)]
        if len(seg):
            out[i] = seg.mean()
    return out


def arms(domain):
    return [(f"{domain}_{m}", m) for m in STYLE]


def save(fig, out: Path, name: str, title: str):
    fig.suptitle(title, x=0.01, ha="left", fontsize=12, color=INK)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(out / name, dpi=150)
    plt.close(fig)
    print("  ", name)


def per_step_figure(out, steps, ycol, ylabel, name, title, x="step", w=10, raw=True, xlabel=None):
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.8))
    for ax, d in zip(axs, DOMAINS):
        for arm, m in arms(d):
            rows = sorted((r for r in steps if r["arm"] == arm), key=lambda r: int(r["step"]))
            xs = np.array([num(r[x]) for r in rows])
            ys = np.array([num(r[ycol]) for r in rows])
            if raw:
                ax.plot(xs, ys, color=STYLE[m]["color"], lw=0.8, alpha=0.25)
            ax.plot(xs, smooth(ys, w) if w else ys, **STYLE[m])
        ax.set_title(TITLE[d], loc="left")
        ax.set_xlabel(xlabel or ("training step" if x == "step" else "wall-clock (h)"))
        ax.set_ylabel(ylabel)
    axs[0].legend(loc="best")
    save(fig, out, name, title)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", type=Path, default=Path("ec_results/run1018_stage1"))
    a = ap.parse_args()
    data, out = a.dir / "data", a.dir / "plots"
    out.mkdir(exist_ok=True)
    steps = read(data / "step_events.csv")
    tm = {f"{d}_{m}": read(data / f"train_metrics_{d}_{m}.csv") for d in DOMAINS for m in STYLE}
    ev = read(data / "eval_metrics.csv")

    # --- training dynamics (event logs: every consumed group, before compaction) ---
    per_step_figure(out, steps, "reward_mean", "mean reward of consumed groups", "01_reward_vs_step.png",
                    "Training reward per step (10-step moving average; faint = raw)")
    per_step_figure(out, steps, "reward_mean", "mean reward of consumed groups", "02_reward_vs_wallclock.png",
                    "Training reward vs wall-clock", x="t_h")
    per_step_figure(out, steps, "pass_frac", "fraction of samples = pass", "03_pass_frac_vs_step.png",
                    "Training-sample pass rate per step (verifier stage == pass)")
    per_step_figure(out, steps, "informative_frac", "informative groups / consumed groups",
                    "04_informative_frac_vs_step.png", "Informative fraction (group rewards not all equal)")
    per_step_figure(out, steps, "cum_informative_groups", "cumulative informative groups",
                    "05_cum_informative_vs_wallclock.png", "Cumulative informative groups vs wall-clock (throughput)",
                    x="t_h", w=0, raw=False)
    per_step_figure(out, steps, "t_h", "wall-clock (h)", "06_wallclock_vs_step.png",
                    "Wall-clock to reach each step", w=0, raw=False)
    per_step_figure(out, steps, "step_wall_s", "seconds per step", "07_step_time_vs_step.png",
                    "Wall-clock seconds per step")
    per_step_figure(out, steps, "stale_mean", "mean staleness (steps)", "08_staleness_vs_step.png",
                    "Mean staleness of consumed samples per step")
    per_step_figure(out, steps, "samples_canceled", "samples cancelled in step", "09_cancelled_vs_step.png",
                    "Cancelled samples per step (decoupled only)", w=0)

    # staleness histogram
    hist = read(data / "staleness_hist.csv")
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.6))
    for ax, d in zip(axs, DOMAINS):
        for j, (arm, m) in enumerate(arms(d)):
            rows = [r for r in hist if r["arm"] == arm]
            tot = sum(int(r["samples"]) for r in rows)
            ks = np.array([int(r["staleness"]) for r in rows])
            fr = np.array([int(r["samples"]) / tot for r in rows])
            bars = ax.bar(ks + (j - 0.5) * 0.38, fr, width=0.36, color=STYLE[m]["color"], label=m,
                          edgecolor=SURFACE, linewidth=2)
            for b, v in zip(bars, fr):
                ax.text(b.get_x() + b.get_width() / 2, v + 0.01, f"{v:.1%}", ha="center", fontsize=7, color=INK2)
        ax.set_xticks([0, 1, 2])
        ax.set_xlabel("staleness = consume_step − sampling_start_step")
        ax.set_ylabel("share of consumed samples")
        ax.set_title(TITLE[d], loc="left")
    axs[0].legend()
    save(fig, out, "10_staleness_hist.png", "Staleness distribution over all consumed samples")

    # verifier utilization
    util = read(data / "verifier_utilization_1min.csv")
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.8))
    for ax, d in zip(axs, DOMAINS):
        for arm, m in arms(d):
            rows = [r for r in util if r["arm"] == arm]
            t = np.array([num(r["t_min"]) for r in rows]) / 60
            ax.plot(t, smooth([num(r["busy_total"]) for r in rows], 10), **STYLE[m])
            if m == "decoupled_eta2":
                ax.plot(t, smooth([num(r["busy_useful"]) for r in rows], 10), color=STYLE[m]["color"], ls=":",
                        lw=1.5, label="decoupled_eta2 (completed jobs only)")
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("wall-clock (h)")
        ax.set_ylabel("fraction of verifier workers busy")
        ax.set_title(TITLE[d], loc="left")
    axs[0].legend(loc="lower right")
    save(fig, out, "11_verifier_utilization.png",
         "Verifier utilization (10-min moving average); dotted = excluding time spent on later-cancelled jobs")

    # verification / queue-wait / generation-time CDFs
    fig, axs = plt.subplots(3, 2, figsize=(11, 9.5))
    for col, d in enumerate(DOMAINS):
        for arm, m in arms(d):
            rows = read(data / f"samples_done_{arm}.csv")
            for row, (k, lab) in enumerate([("verifier_execution_s", "verifier execution (s)"),
                                            ("reward_queue_wait_s", "verify queue wait (s)"),
                                            ("gen_duration_s", "generation time per sample (s)")]):
                x = np.sort(np.array([num(r[k]) for r in rows]))
                x = x[~np.isnan(x)]
                x = np.clip(x, 1e-3, None)
                axs[row, col].plot(x, np.arange(1, len(x) + 1) / len(x), **STYLE[m])
                axs[row, col].set_xscale("log")
                axs[row, col].set_xlabel(lab + ", log scale")
                axs[row, col].set_ylabel("CDF")
        axs[0, col].set_title(TITLE[d], loc="left")
    axs[0, 0].legend(loc="lower right")
    save(fig, out, "12_latency_cdfs.png", "Per-sample latency distributions (completed samples)")

    # --- training diagnostics from the pipeline metrics (computed on kept groups after compaction) ---
    diag = [("critic/entropy/mean", "policy entropy"), ("token/response_length/mean", "response length (tokens)"),
            ("actor_train/grad_norm", "grad norm"), ("actor/approxkl@sum", "approx KL (old→new)"),
            ("actor/clipfrac@sum", "PPO clip fraction"), ("compaction/groups_zero_variance", "zero-variance groups / 32"),
            ("actor/train_infer_diff_token_mean@sum", "train–infer logprob diff (token mean)")]
    fig, axs = plt.subplots(len(diag), 2, figsize=(11, 2.4 * len(diag)), sharex=True)
    for row, (k, lab) in enumerate(diag):
        for col, d in enumerate(DOMAINS):
            ax = axs[row, col]
            for arm, m in arms(d):
                rows = tm[arm]
                ys = np.array([num(r.get(k)) for r in rows])
                xs = np.array([int(r["step"]) for r in rows])
                ax.plot(xs, ys, color=STYLE[m]["color"], lw=0.7, alpha=0.25)
                ax.plot(xs, smooth(ys), **STYLE[m])
            ax.set_ylabel(lab, fontsize=8)
            if row == 0:
                ax.set_title(TITLE[d], loc="left")
    for ax in axs[-1]:
        ax.set_xlabel("training step")
    axs[0, 0].legend()
    save(fig, out, "13_training_diagnostics.png", "Training diagnostics per step (10-step moving average)")

    # step-time breakdown
    parts = [("time/step_generate", "generate / wait for batch"), ("time/step_train", "train"),
             ("time/step_model_update", "weight sync"), ("time/old_log_probs", "old log-probs")]
    pcol = ["#1baf7a", "#2a78d6", "#eda100", "#e87ba4"]
    fig, axs = plt.subplots(2, 2, figsize=(11, 6.5))
    for col, d in enumerate(DOMAINS):
        for row, (arm, m) in enumerate(arms(d)):
            rows = tm[arm]
            xs = np.array([int(r["step"]) for r in rows])
            ys = [smooth([num(r.get(k)) for r in rows]) for k, _ in parts]
            axs[row, col].stackplot(xs, *[np.nan_to_num(y) for y in ys], colors=pcol, labels=[l for _, l in parts],
                                    edgecolor=SURFACE, linewidth=0.5)
            axs[row, col].set_title(f"{TITLE[d]} — {m}", loc="left")
            axs[row, col].set_ylabel("seconds per step")
            axs[row, col].set_xlabel("training step")
    axs[0, 0].legend(loc="upper left", ncol=2)
    save(fig, out, "14_step_time_breakdown.png", "Where each training step's time goes (10-step moving average)")

    # --- evaluation ---
    def evseries(arm, bench, metric, x="step"):
        rows = sorted((r for r in ev if r["arm"] == arm and r["benchmark"] == bench and r["metric"] == metric),
                      key=lambda r: int(r["step"]))
        return np.array([num(r[x]) for r in rows]), np.array([num(r["value"]) for r in rows])

    panels = [("rtl", "ve2_n20", "pass@1", "VerilogEval-v2 pass@1"), ("rtl", "cvdp_cid003_n10", "pass@1", "CVDP cid003 pass@1"),
              ("rtl", "cvdp_cid002_n10", "pass@1", "CVDP cid002 pass@1"), ("rtl", "ve2_n20", "pass@20", "VerilogEval-v2 pass@20"),
              ("lean", "minif2f_test_n32", "attempt_pass_rate", "miniF2F attempt pass rate"),
              ("lean", "minif2f_test_n32", "pass@32", "miniF2F pass@32")]
    for x, name, xl in [("step", "15_eval_vs_step.png", "training step"),
                        ("train_h", "16_eval_vs_wallclock.png", "training wall-clock (h)")]:
        fig, axs = plt.subplots(2, 3, figsize=(12, 6.5))
        for ax, (d, b, mt, lab) in zip(axs.flat, panels):
            for arm, m in arms(d):
                xs, ys = evseries(arm, b, mt, x)
                ax.plot(xs, ys, marker="o", ms=5, mec=SURFACE, mew=1.5, **STYLE[m])
                ax.annotate(f"{ys[-1]:.3f}", (xs[-1], ys[-1]), xytext=(4, 0), textcoords="offset points",
                            fontsize=7, color=INK2, va="center")
            ax.set_title(lab, loc="left")
            ax.set_xlabel(xl)
        axs[0, 0].legend()
        save(fig, out, name, "Evaluation at step 0 / 100 / 200 / 299" + (" vs training wall-clock" if x == "train_h" else ""))

    # pass@k curves at final checkpoint
    bks = [("ve2_n20", [1, 5, 10, 20], "VerilogEval-v2"), ("cvdp_cid003_n10", [1, 5, 10], "CVDP cid003"),
           ("cvdp_cid002_n10", [1, 5, 10], "CVDP cid002")]
    fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
    for ax, (b, ks, lab) in zip(axs, bks):
        def pk(arm, tag):
            return [num(next(r["value"] for r in ev if r["arm"] == arm and r["ckpt"] == tag and r["benchmark"] == b
                             and r["metric"] == f"pass@{k}")) for k in ks]
        ax.plot(ks, pk("rtl_barrier_r2", "step0"), color=STEP0, ls="-.", marker="o", ms=5, label="step0")
        for arm, m in arms("rtl"):
            ax.plot(ks, pk(arm, "checkpoint-299"), marker="o", ms=5, mec=SURFACE, mew=1.5, **STYLE[m])
        ax.set_xscale("log")
        ax.set_xticks(ks, [str(k) for k in ks])
        ax.set_xlabel("k")
        ax.set_ylabel("pass@k")
        ax.set_title(lab, loc="left")
    axs[0].legend()
    save(fig, out, "17_passk_final.png", "pass@k at step 299 vs the initial model (RTL)")

    # per-problem change scatter: barrier delta vs decoupled delta
    pp = read(data / "eval_per_problem.csv")
    rate = {(r["arm"], r["ckpt"], r["benchmark"], r["problem"]): int(r["passes"]) / int(r["n"]) for r in pp}
    benches = [("rtl", "ve2_n20", "VerilogEval-v2"), ("rtl", "cvdp_cid003_n10", "CVDP cid003"),
               ("rtl", "cvdp_cid002_n10", "CVDP cid002"), ("lean", "minif2f_test_n32", "miniF2F-test")]
    fig, axs = plt.subplots(1, 4, figsize=(14, 3.9))
    for ax, (d, b, lab) in zip(axs, benches):
        probs = sorted({k[3] for k in rate if k[2] == b and k[0] == f"{d}_barrier_r2"})
        db = np.array([rate[(f"{d}_barrier_r2", "checkpoint-299", b, p)] - rate[(f"{d}_barrier_r2", "step0", b, p)] for p in probs])
        dd = np.array([rate[(f"{d}_decoupled_eta2", "checkpoint-299", b, p)] - rate[(f"{d}_decoupled_eta2", "step0", b, p)] for p in probs])
        ax.axhline(0, color=INK2, lw=0.8)
        ax.axvline(0, color=INK2, lw=0.8)
        ax.plot([-1, 1], [-1, 1], color=GRID, lw=1)
        ax.scatter(db, dd, s=22, color="#2a78d6", alpha=0.55, edgecolor=SURFACE, linewidth=0.8)
        ax.set_xlim(-1, 1)
        ax.set_ylim(-1, 1)
        ax.set_aspect("equal")
        ax.set_xlabel("barrier Δ pass rate (299 − step0)")
        ax.set_ylabel("decoupled Δ pass rate")
        ax.set_title(f"{lab} ({len(probs)} problems)", loc="left")
        ax.text(0.02, 0.98, f"barrier mean {db.mean():+.3f}\ndecoupled mean {dd.mean():+.3f}\n"
                f"improved: {(db > 0).sum()} / {(dd > 0).sum()}\nworse: {(db < 0).sum()} / {(dd < 0).sum()}",
                transform=ax.transAxes, va="top", fontsize=7, color=INK2)
    save(fig, out, "18_per_problem_delta.png", "Per-problem pass-rate change after 300 steps: barrier (x) vs decoupled (y)")

    # eval status composition
    sc = read(data / "eval_status_counts.csv")
    fig, axs = plt.subplots(1, 4, figsize=(14, 4.6))
    for ax, (d, b, lab) in zip(axs, benches):
        rows = [r for r in sc if r["benchmark"] == b]
        order = ["pass", "fail", "mismatch", "lean_error", "compile_error", "syntax_error", "parse_fail",
                 "repl_error", "timeout", "sorry"]
        present = {r["status"] for r in rows}
        statuses = [x for x in order if x in present] + sorted(present - set(order))
        cols = ["step0"] + [f"{m[0].upper()}{c}" for m in STYLE for c in ("100", "200", "299")]
        keys = [(f"{d}_barrier_r2", "step0")] + [(f"{d}_{m}", t) for m in STYLE for t in ("checkpoint-100", "checkpoint-200", "checkpoint-299")]
        bottom = np.zeros(len(keys))
        for i, s in enumerate(statuses):
            v = []
            for arm, t in keys:
                tot = sum(int(r["count"]) for r in rows if r["arm"] == arm and r["ckpt"] == t)
                v.append(sum(int(r["count"]) for r in rows if r["arm"] == arm and r["ckpt"] == t and r["status"] == s) / tot)
            ax.bar(range(len(keys)), v, bottom=bottom, color=STATUS_COL.get(s, "#8a8985"), label=s, edgecolor=SURFACE, linewidth=1)
            bottom += v
        ax.set_xticks(range(len(keys)), cols, fontsize=7)
        ax.set_title(lab, loc="left")
        ax.set_ylabel("share of attempts")
        ax.legend(fontsize=6, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=3)
    save(fig, out, "19_eval_status_mix.png", "Eval outcome mix per checkpoint (B = barrier_r2, D = decoupled_eta2; number = step)")


if __name__ == "__main__":
    main()
