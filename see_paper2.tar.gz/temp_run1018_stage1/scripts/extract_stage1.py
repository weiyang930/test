"""Extract every plottable result of RUN_1018 Stage 1 into flat CSV/JSON (stdlib only, no GPU).

Usage: python extract_stage1.py [--root $ROOT] [--out ec_results/run1018_stage1]
Writes <out>/data/*.csv and copies eval summaries / manifests into <out>/raw/.
"""
from __future__ import annotations

import argparse
import bisect
import collections
import csv
import json
import os
import shutil
from pathlib import Path

ARMS = {  # arm -> (training run dir, eval/ckpt run dir)
    "rtl_barrier_r2": ("ec_barrier_r2", "h100_rtl_barrier_r2"),
    "rtl_decoupled_eta2": ("ec_decoupled_eta2", "h100_rtl_decoupled_eta2"),
    "lean_barrier_r2": ("lean_barrier_r2", "h100_lean_barrier_r2"),
    "lean_decoupled_eta2": ("lean_decoupled_eta2", "h100_lean_decoupled_eta2"),
}
CKPT_STEP = {"step0": 0, "checkpoint-100": 100, "checkpoint-200": 200, "checkpoint-299": 299}


def load(path: Path):
    if not path.exists():
        return
    for line in open(path, errors="ignore"):
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    if not rows:
        return
    if fields is None:
        fields = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    print(f"  {path.name}: {len(rows)} rows")


def train_metrics(run: Path, step_t: dict, t0: float) -> list[dict]:
    """Per-step pipeline metrics dict printed by rlvr_pipeline.py (~235 keys)."""
    rows = {}
    for line in open(run / "stdout.log", errors="ignore"):
        if '"time/step_total"' not in line or "rlvr_pipeline.py" not in line:
            continue
        d = json.loads(line[line.index("{"):])
        step = int(d.get("system/global_step", len(rows)))
        rows[step] = d
    out = []
    for step in sorted(rows):
        r = {"step": step}
        if step in step_t:
            r["t_h"] = (step_t[step] - t0) / 3600
        r.update(rows[step])
        out.append(r)
    return out


def step_events(out_dir: Path, workers: int) -> tuple[list[dict], dict, float, dict]:
    sched = list(load(out_dir / "scheduler_events.jsonl"))
    events = list(load(out_dir / "events.jsonl"))
    step_t = {e["step"]: e["ts"] for e in sched if e.get("event") == "step_begin"}
    t0 = step_t[min(step_t)]
    commits = {e["prompt_id"]: e for e in events if e.get("event") == "prompt_commit"}
    steps = sorted(step_t)
    starts = [step_t[s] for s in steps]

    def step_of(ts):
        i = bisect.bisect_right(starts, ts) - 1
        return steps[max(i, 0)]

    cancels = collections.Counter(step_of(e["ts"]) for e in events if e.get("event") == "sample_canceled")
    done = collections.Counter(step_of(e["ts"]) for e in events if e.get("event") == "sample_done")
    rows, cum_inf, cum_groups = [], 0, 0
    for e in sched:
        if e.get("event") != "consume_batch":
            continue
        s = e["consume_step"]
        pids = list(dict.fromkeys(i["prompt_id"] for i in e.get("consumed_items", [])))
        stale = [s - i.get("sampling_start_step", s) for i in e.get("consumed_items", [])]
        inf, rew, pass_frac = 0, [], []
        for pid in pids:
            r = (commits.get(pid) or {}).get("rewards") or []
            if len({round(float(x), 3) for x in r}) > 1:
                inf += 1
            rew += [float(x) for x in r]
            st = (commits.get(pid) or {}).get("stages") or []
            pass_frac += [x == "pass" for x in st]
        cum_inf += inf
        cum_groups += len(pids)
        nxt = step_t.get(s + 1)
        rows.append({
            "step": s, "t_h": (step_t[s] - t0) / 3600 if s in step_t else None,
            "step_wall_s": (nxt - step_t[s]) if (nxt and s in step_t) else None,
            "groups": len(pids), "informative_groups": inf,
            "informative_frac": inf / len(pids) if pids else None,
            "cum_informative_groups": cum_inf, "cum_groups": cum_groups,
            "reward_mean": sum(rew) / len(rew) if rew else None,
            "pass_frac": sum(pass_frac) / len(pass_frac) if pass_frac else None,
            "stale_mean": sum(stale) / len(stale) if stale else None, "stale_max": max(stale) if stale else None,
            **{f"stale_eq{k}": sum(x == k for x in stale) for k in range(4)},
            "samples_done": done.get(s, 0), "samples_canceled": cancels.get(s, 0),
        })
    # staleness histogram over all consumed samples
    hist = collections.Counter()
    for e in sched:
        if e.get("event") == "consume_batch":
            for i in e.get("consumed_items", []):
                hist[e["consume_step"] - i.get("sampling_start_step", e["consume_step"])] += 1
    return rows, step_t, t0, {"events": events, "hist": hist}


def samples(events: list, t0: float, arm: str) -> tuple[list[dict], list[dict]]:
    keys = ["prompt_id", "member_index", "sampling_start_step", "gen_duration_s", "reward_queue_wait_s",
            "verifier_execution_s", "verifier_cpu_core_seconds", "response_tokens", "reward", "reward_valid",
            "verifier_stage", "verify_worker"]
    done, canc = [], []
    for e in events:
        if e.get("event") == "sample_done":
            r = {"arm": arm, "t_s": e["ts"] - t0}
            r.update({k: e.get(k) for k in keys})
            done.append(r)
        elif e.get("event") == "sample_canceled":
            canc.append({"arm": arm, "t_s": e["ts"] - t0, "prompt_id": e.get("prompt_id"),
                         "member_index": e.get("member_index"), "sampling_start_step": e.get("sampling_start_step"),
                         "phase": e.get("phase"), "elapsed_s": e.get("elapsed_s"), "reason": e.get("reason")})
    return done, canc


def utilization(events: list, vq_path: Path, t0: float, t_end: float, workers: int, arm: str, bin_s: int = 60):
    """Fraction of verifier workers busy per minute; split into useful (completed) and wasted (cancelled while running)."""
    n = int((t_end - t0) // bin_s) + 1
    useful, wasted = [0.0] * n, [0.0] * n

    def add(arr, a, b):
        a, b = max(a, t0), min(b, t_end)
        while a < b:
            i = int((a - t0) // bin_s)
            edge = t0 + (i + 1) * bin_s
            arr[i] += min(b, edge) - a
            a = edge

    for e in events:
        if e.get("event") == "sample_done" and e.get("t_worker_start") and e.get("t_worker_end"):
            add(useful, e["t_worker_start"], e["t_worker_end"])
    for e in load(vq_path):
        if e.get("event") == "cancel" and e.get("state") == "running" and e.get("running_s"):
            add(wasted, e["ts"] - float(e["running_s"]), e["ts"])
    cap = bin_s * workers
    return [{"arm": arm, "t_min": i * bin_s / 60, "busy_useful": useful[i] / cap, "busy_wasted": wasted[i] / cap,
             "busy_total": (useful[i] + wasted[i]) / cap} for i in range(n)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(os.environ.get("ROOT", ".")))
    ap.add_argument("--out", type=Path, default=Path("ec_results/run1018_stage1"))
    a = ap.parse_args()
    data, raw = a.out / "data", a.out / "raw"
    data.mkdir(parents=True, exist_ok=True)
    raw.mkdir(parents=True, exist_ok=True)

    eval_rows, prob_rows, status_rows, all_steps, all_util, stale_rows = [], [], [], [], [], []
    for arm, (train_run, ev_run) in ARMS.items():
        print(arm)
        tr, er = a.root / "runs" / train_run, a.root / "runs" / ev_run
        manifest = json.load(open(tr / "manifest.json"))
        workers = int(manifest["verify_workers"])
        steps, step_t, t0, extra = step_events(tr / "output", workers)
        events = extra["events"]
        for r in steps:
            r["arm"] = arm
        all_steps += steps
        stale_rows += [{"arm": arm, "staleness": k, "samples": v} for k, v in sorted(extra["hist"].items())]
        write_csv(data / f"train_metrics_{arm}.csv", train_metrics(tr, step_t, t0))
        done, canc = samples(events, t0, arm)
        write_csv(data / f"samples_done_{arm}.csv", done)
        write_csv(data / f"samples_canceled_{arm}.csv", canc)
        t_end = max(e.get("ts", 0) for e in events)
        all_util += utilization(events, tr / "output" / "verify_queue_events.jsonl", t0, t_end, workers, arm)

        # eval
        for e in json.load(open(er / "eval" / "eval_curve.json")):
            tag = e["tag"]
            for bench, m in e.items():
                if bench == "tag":
                    continue
                for k, v in m.items():
                    eval_rows.append({"arm": arm, "ckpt": tag, "step": CKPT_STEP.get(tag), "train_h": None,
                                      "benchmark": bench, "metric": k, "value": v})
        for tag in CKPT_STEP:
            for bench_dir in sorted((er / "eval" / tag).glob("*/")):
                s = json.load(open(bench_dir / "summary.json"))
                probs = s.get("per_problem") or dict(s.get("problems") or {})
                for pid, p in probs.items():
                    prob_rows.append({"arm": arm, "ckpt": tag, "step": CKPT_STEP[tag], "benchmark": bench_dir.name,
                                      "problem": pid, "n": p.get("n"), "passes": p.get("passes")})
                for st, c in (s.get("status_counts") or {}).items():
                    status_rows.append({"arm": arm, "ckpt": tag, "step": CKPT_STEP[tag], "benchmark": bench_dir.name,
                                        "status": st, "count": c})
                for k in ("mean_response_tokens", "finish_length_share", "informative_share_G4", "informative_share_G8",
                          "mixed_at_probe", "all_fail", "all_pass"):
                    if k in s:
                        eval_rows.append({"arm": arm, "ckpt": tag, "step": CKPT_STEP[tag], "benchmark": bench_dir.name,
                                          "metric": k, "value": s[k]})
                dst = raw / "eval" / arm / tag / bench_dir.name
                dst.mkdir(parents=True, exist_ok=True)
                for fn in ("summary.json", "attempts.jsonl", "generation_meta.json"):
                    if (bench_dir / fn).exists():
                        shutil.copy2(bench_dir / fn, dst / fn)
        # training-hours at which each checkpoint was taken
        ck_h = {0: 0.0, **{s: (step_t[s + 1] - t0) / 3600 for s in (100, 200) if s + 1 in step_t},
                299: (t_end - t0) / 3600}
        for r in eval_rows:
            if r["arm"] == arm and r.get("step") in ck_h:
                r["train_h"] = ck_h[r["step"]]
        shutil.copy2(er / "eval" / "eval_curve.json", raw / f"eval_curve_{arm}.json")
        for fn in ("manifest.json", "launch_env.txt"):
            shutil.copy2(tr / fn, raw / f"{fn.split('.')[0]}_{arm}.{fn.split('.')[1]}")

    write_csv(data / "step_events.csv", all_steps)
    write_csv(data / "verifier_utilization_1min.csv", all_util)
    write_csv(data / "staleness_hist.csv", stale_rows)
    write_csv(data / "eval_metrics.csv", eval_rows)
    write_csv(data / "eval_per_problem.csv", prob_rows)
    write_csv(data / "eval_status_counts.csv", status_rows)


if __name__ == "__main__":
    main()
