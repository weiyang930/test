# Human annotation — evolved airline & retail tasks

This folder contains a set of *evolved* τ²-bench tasks (multi-step, difficulty-increased
variants of the base airline and retail tasks) to be audited by human annotators.

## Files in this folder

| File | What it is |
|---|---|
| `airline_tasks_no_comm.json` | 32 evolved **airline** tasks. Each task has an `id` (`airline_evolved_1 … airline_evolved_32`), a `description` (purpose / relevant policies / notes), a `user_scenario` (the customer's persona and turn-by-turn instructions), an `initial_state`, and `evaluation_criteria` (the **oracle action sequence** the task expects). |
| `retail_tasks_evolved_no_comm.json` | 26 evolved **retail** tasks (`retail_evolved_1 … retail_evolved_26`), same schema as above. |
| `airline_policy.md` / `retail_policy.md` | The agent **policy (system prompt)** for each domain — the rules a compliant assistant must follow. |
| `airline_tool_schema.json` / `retail_tool_schema.json` | The **tools** available to the agent in each domain (OpenAI-style function schemas: names, parameters, descriptions). |
| `annotation_sheet.csv` | The blank sheet you fill in — one row per task, in fixed order (all airline tasks, then all retail tasks). |
| `id_mapping.json` | Bookkeeping only (maps the simple ids back to the original evolved-task ids). You do **not** need this. |

## What to do (per annotator)

1. **Read the policy and tool schema for the domain.** Before annotating airline tasks,
   read `airline_policy.md` and skim `airline_tool_schema.json`; do the same with the
   retail files before the retail tasks. These define what a policy-compliant assistant
   is allowed and required to do, and which tools exist.
2. **Read 1–2 example tasks end to end** to get familiar with the schema — open the JSON
   and read one task's `description`, `user_scenario.instructions`, `initial_state`, and
   `evaluation_criteria` together (see the walked example below).
3. **Read the annotation guideline** — the three questions in the next section.
4. **Answer the three questions for every task** in `annotation_sheet.csv`: put your answer
   for each question in the `question-1` / `question-2` / `question-3` column of that task's
   row. Use the exact option strings listed for each question. Do not reorder or rename rows.

## Annotation guideline (three questions)

For each task, given its instruction, the initial state, the domain policy and the tool
schema:

1. **Q1 — Correctness.** Are the task and its oracle actions correct, i.e. is the oracle
   outcome what a competent, policy-compliant assistant would produce?
   Options: `Yes` / `No` / `Cannot tell`
2. **Q2 — Realism.** Would a real customer plausibly make this request, in this situation
   and in this way?
   Options: `Natural` / `Plausible but unusual` / `Contrived`
3. **Q3 — Oracle strictness.** Does the oracle action sequence require steps, parameter
   values or an ordering that a policy-compliant assistant could legitimately do
   differently while reaching the same outcome (e.g. optional reads, interchangeable order
   of independent writes, an equivalent editing tool)?
   Options: `No, every step and its order is required` / `Partly, some steps or their order are optional` / `Yes, materially over-specified`

## A walked example

Open `airline_tasks_no_comm.json` and read `airline_evolved_1`:
- `description.purpose` — plain-English summary of what the task checks.
- `description.relevant_policies` / `description.notes` — which policy sections apply and
  the expected numbers/derivations.
- `user_scenario.instructions.task_instructions` — the turn-by-turn behaviour of the
  simulated customer (what they ask, when, and what they will/won't reveal).
- `initial_state` — the reservations/orders and DB state the task starts from.
- `evaluation_criteria` — the **oracle** actions the assistant is graded against.

To answer Q1, check the oracle in `evaluation_criteria` against the policy and initial
state. For Q2, judge whether the customer's request and phrasing are plausible. For Q3,
ask whether a compliant assistant could reach the same end state via a different but
legitimate sequence/parameters than the oracle.

## Filling in the sheet

`annotation_sheet.csv` looks like this (task ids are pre-filled, in order; leave them
exactly as they are and just fill your three answers):

```
task, question-1, question-2, question-3
airline_evolved_1, , ,
...
airline_evolved_32, , ,
retail_evolved_1, , ,
...
retail_evolved_26, , ,
```

## Two annotators (for agreement)

We need **two** completed copies of `annotation_sheet.csv`, one from **each of two
independent annotators**, so that inter-annotator agreement can be computed on all three
questions. Annotate independently — do not confer while annotating. Save your copy with
your name/id in the filename, e.g. `annotation_sheet_annotator1.csv` and
`annotation_sheet_annotator2.csv`.
