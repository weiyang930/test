"""VMem: query-specific, source-grounded evidence construction for long-term conversational memory.

Modules: `pipeline` (method, Config, prompts), `store` (read-only memory store + indexes),
`llm` (LiteLLM access layer), `run` (LoCoMo runner), `evaluate` (LoCoMo scorer).
"""

__version__ = "2.3.0"
