"""Read-only access to the memory store for VMem.

VMem does not build or modify memory. It reads an existing long-term memory store with three
granularities and builds query-time indexes (dense + BM25) over them:

  * episode    – episodic memory (title + narrative), timestamped with the conversation time
  * semantic   – semantic facts with a pointer to their source episode; re-timestamped through
                 provenance (source_episode_id -> episode time)
  * turn       – raw conversation turns stored inside episodes (the "source" layer)

In the paper the store is the one written by NEMORI's memory construction (tables `episodes` and
`semantic_memories`). Two read-only backends are supported:

  * postgres – read the tables directly        (VMEM_STORE=postgres, DATABASE_URL=postgresql://...)
  * json     – a JSON export of the same tables (VMEM_STORE=json,     VMEM_STORE_JSON=memory.json)
               produced by tools/export_store.py; format:
               {user_id: {"episodes": [{id, title, content, source_messages, created_at}],
                          "semantic": [{id, content, memory_type, source_episode_id, created_at}]}}

Item embeddings are cached on disk per user (derived data only, VMEM_CACHE, default ./cache/embeddings).
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import httpx
import numpy as np
from rank_bm25 import BM25Okapi

CACHE_DIR = Path(os.environ.get("VMEM_CACHE", Path(__file__).resolve().parents[1] / "cache" / "embeddings"))
EMBED_URL = os.environ.get("EMBEDDING_BASE_URL", "http://127.0.0.1:18080/v1").rstrip("/") + "/embeddings"
DSN = os.environ.get("DATABASE_URL", "postgresql://nemori:nemori@127.0.0.1:15432/nemori")

_STOP = set("""a an the and or but if of to in on at for with from by about as is are was were be been being
do does did done have has had having i you he she it we they me him her them my your his its our their this that
these those what which who whom whose when where why how would could should will can may might must not no yes
so than then there here just also very too any some all each every more most other into over under again
s t d ll re ve m o y ever""".split())


def tokenize(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", (text or "").lower()) if w not in _STOP]


def fmt_date(ts) -> str:
    """'2023-05-08T13:56:00+00:00' -> '1:56 pm on 8 May, 2023' style used by LoCoMo, plus weekday."""
    from datetime import datetime
    if ts is None:
        return ""
    if isinstance(ts, str):
        try:
            ts = datetime.fromisoformat(ts)
        except Exception:
            return ts
    return ts.strftime("%A, %d %B %Y, %H:%M")


@dataclass
class Item:
    id: str
    kind: str                     # episode | semantic | turn
    text: str                     # text used for indexing/display
    ts: str                       # ISO timestamp (conversation time)
    episode_id: str | None = None
    speaker: str | None = None
    order: int = 0                # global order (buffer id for turns)
    meta: dict = field(default_factory=dict)

    def date(self) -> str:
        return fmt_date(self.ts)


class EmbedClient:
    def __init__(self):
        self._client = httpx.AsyncClient(timeout=120)

    async def embed(self, texts: list[str], batch: int = 64) -> np.ndarray:
        out = []
        for i in range(0, len(texts), batch):
            for attempt in range(5):
                try:
                    r = await self._client.post(EMBED_URL, json={"input": texts[i:i + batch]})
                    r.raise_for_status()
                    out.extend(d["embedding"] for d in r.json()["data"])
                    break
                except Exception:
                    if attempt == 4:
                        raise
                    await asyncio.sleep(2 * (attempt + 1))
        return np.asarray(out, dtype=np.float32)


class UserIndex:
    """All memory items of one LoCoMo conversation, with dense + BM25 indexes."""

    def __init__(self, user_id: str, items: list[Item], vecs: np.ndarray):
        self.user_id = user_id
        self.items = items
        self.vecs = vecs
        self.by_kind: dict[str, list[int]] = {}
        for i, it in enumerate(items):
            self.by_kind.setdefault(it.kind, []).append(i)
        self.bm25 = {k: BM25Okapi([tokenize(items[i].text) or ["_"] for i in idx]) for k, idx in self.by_kind.items()}
        self.by_id = {it.id: i for i, it in enumerate(items)}
        # episode -> its turns (ordered)
        self.turns_of_episode: dict[str, list[int]] = {}
        for i in self.by_kind.get("turn", []):
            self.turns_of_episode.setdefault(items[i].episode_id, []).append(i)
        for k in self.turns_of_episode:
            self.turns_of_episode[k].sort(key=lambda j: items[j].order)
        self.turn_order = sorted(self.by_kind.get("turn", []), key=lambda j: items[j].order)
        self.turn_pos = {j: p for p, j in enumerate(self.turn_order)}

    def dense(self, qvec: np.ndarray, kind: str, k: int) -> list[tuple[int, float]]:
        idx = self.by_kind.get(kind, [])
        if not idx:
            return []
        sims = self.vecs[idx] @ qvec
        top = np.argsort(-sims)[:k]
        return [(idx[t], float(sims[t])) for t in top]

    def sparse(self, query: str, kind: str, k: int) -> list[tuple[int, float]]:
        idx = self.by_kind.get(kind, [])
        toks = tokenize(query)
        if not idx or not toks:
            return []
        sc = self.bm25[kind].get_scores(toks)
        top = np.argsort(-sc)[:k]
        return [(idx[t], float(sc[t])) for t in top if sc[t] > 0]

    def neighbors(self, turn_i: int, w: int) -> list[int]:
        p = self.turn_pos.get(turn_i)
        if p is None:
            return [turn_i]
        lo, hi = max(0, p - w), min(len(self.turn_order), p + w + 1)
        same = [j for j in self.turn_order[lo:hi] if self.items[j].ts[:10] == self.items[turn_i].ts[:10]]
        return same or [turn_i]


def _iso(ts) -> str:
    return ts if isinstance(ts, str) else ts.isoformat()


def items_from_rows(eps, sems) -> list[Item]:
    """Turn episode / semantic rows (dicts or asyncpg records with the NEMORI column names) into Items."""
    items: list[Item] = []
    ep_time = {}
    seen_turns = set()
    for e in eps:
        eid = str(e["id"])
        ts = _iso(e["created_at"])
        ep_time[eid] = ts
        items.append(Item(id=eid, kind="episode", text=f"{e['title']}: {e['content']}", ts=ts, episode_id=eid))
        msgs = e["source_messages"]
        if isinstance(msgs, str):
            msgs = json.loads(msgs)
        for m in msgs or []:
            content = str(m.get("content", "")).strip().strip('"')
            key = (m.get("timestamp"), m.get("role"), content)
            if key in seen_turns:
                continue
            seen_turns.add(key)
            bid = (m.get("metadata") or {}).get("buffer_id", 0) or 0
            items.append(Item(id=m.get("message_id") or f"{eid}:{bid}", kind="turn",
                              text=f"{m.get('role')}: {content}", ts=m.get("timestamp") or ts,
                              episode_id=eid, speaker=m.get("role"), order=int(bid)))
    for s in sems:
        sid = str(s["id"])
        src = str(s["source_episode_id"]) if s["source_episode_id"] else None
        ts = ep_time.get(src) or _iso(s["created_at"])
        items.append(Item(id=sid, kind="semantic", text=s["content"], ts=ts, episode_id=src,
                          meta={"type": s["memory_type"]}))
    return items


EP_SQL = "select id, title, content, source_messages, created_at from episodes where user_id=$1 and agent_id=$2"
SEM_SQL = ("select id, content, memory_type, source_episode_id, created_at from semantic_memories "
           "where user_id=$1 and agent_id=$2")


async def load_user_items(conn, user_id: str, agent_id: str) -> list[Item]:
    return items_from_rows(await conn.fetch(EP_SQL, user_id, agent_id), await conn.fetch(SEM_SQL, user_id, agent_id))


class Store:
    def __init__(self, agent_id: str, backend: str | None = None, json_path: str | None = None):
        self.agent_id = agent_id
        self.backend = backend or os.environ.get("VMEM_STORE", "postgres")
        self.json_path = json_path or os.environ.get("VMEM_STORE_JSON")
        self.embedder = EmbedClient()
        self._pool = None
        self._json = None
        self._indexes: dict[str, UserIndex] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._qcache: dict[str, np.ndarray] = {}

    async def __aenter__(self):
        if self.backend == "postgres":
            import asyncpg
            self._pool = await asyncpg.create_pool(DSN, min_size=1, max_size=8)
        elif self.backend == "json":
            if not self.json_path:
                raise ValueError("json backend needs VMEM_STORE_JSON / --store-json")
            self._json = json.loads(Path(self.json_path).read_text())
        else:
            raise ValueError(f"unknown store backend {self.backend!r}")
        return self

    async def __aexit__(self, *a):
        if self._pool is not None:
            await self._pool.close()

    async def load_items(self, user_id: str) -> list[Item]:
        if self._json is not None:
            u = self._json.get(user_id)
            if u is None:
                raise KeyError(f"user {user_id!r} not in {self.json_path}")
            return items_from_rows(u["episodes"], u["semantic"])
        async with self._pool.acquire() as conn:
            return await load_user_items(conn, user_id, self.agent_id)

    async def index(self, user_id: str) -> UserIndex:
        if user_id in self._indexes:
            return self._indexes[user_id]
        lock = self._locks.setdefault(user_id, asyncio.Lock())
        async with lock:
            if user_id in self._indexes:
                return self._indexes[user_id]
            items = await self.load_items(user_id)
            sig = hashlib.sha1("\n".join(f"{i.id}|{i.text}" for i in items).encode()).hexdigest()[:16]
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            f = CACHE_DIR / f"{self.agent_id}_{user_id}_{sig}.npy"
            if f.exists():
                vecs = np.load(f)
            else:
                vecs = await self.embedder.embed([i.text for i in items])
                np.save(f, vecs)
            self._indexes[user_id] = UserIndex(user_id, items, vecs)
            return self._indexes[user_id]

    async def qvec(self, text: str) -> np.ndarray:
        if text not in self._qcache:
            self._qcache[text] = (await self.embedder.embed([text]))[0]
        return self._qcache[text]
