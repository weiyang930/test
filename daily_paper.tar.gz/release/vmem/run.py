"""Run VMem on LoCoMo and write results in the upstream {conv_idx: [record]} format.

  python -m vmem.run --data locomo10.json --out outputs/<name>/results.json [--conv-ids conv-26,conv-41]
      [--store postgres|json] [--store-json memory.json] [--cfg key=value ...]

Config() defaults are the final VMem configuration; --cfg overrides individual fields (for ablations).
"""
from __future__ import annotations

import argparse
import asyncio
import dataclasses
import json
import os
import time
from pathlib import Path

from tqdm.asyncio import tqdm

from vmem.llm import usage_summary
from vmem.pipeline import Config, VMem
from vmem.store import Store


def parse_cfg(pairs):
    cfg = Config()
    names = {f.name for f in dataclasses.fields(Config)}
    for p in pairs or []:
        k, v = p.split("=", 1)
        if k not in names:
            raise SystemExit(f"unknown Config field {k!r}; valid fields: {', '.join(sorted(names))}")
        cur = getattr(cfg, k)
        if isinstance(cur, bool):
            v = v.lower() in ("1", "true", "yes")
        else:
            v = type(cur)(v)
        setattr(cfg, k, v)
    return cfg


async def main_async(args):
    cfg = parse_cfg(args.cfg)
    data = json.loads(Path(args.data).read_text())
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    conv_ids = set(args.conv_ids.split(",")) if args.conv_ids else None
    qids = set(args.qids.split(",")) if args.qids else None
    done: dict[str, dict] = {}
    if out.exists() and not args.overwrite:
        for k, recs in json.loads(out.read_text()).items():
            for r in recs:
                done[f"{k}|{r['qa_index']}"] = r
    (out.parent / "config.json").write_text(json.dumps({"args": vars(args), "cfg": dataclasses.asdict(cfg)}, indent=1))

    jobs = []
    for ci, conv in enumerate(data):
        if conv_ids and conv["sample_id"] not in conv_ids:
            continue
        c = conv["conversation"]
        speakers = f"{c['speaker_a']} and {c['speaker_b']}"
        user_id = f"{c['speaker_a']}_{ci}"
        for qi, qa in enumerate(conv["qa"]):
            if str(qa.get("category")) == "5":
                continue
            if qids and f"{conv['sample_id']}:{qi}" not in qids:
                continue
            if f"{ci}|{qi}" in done:
                continue
            jobs.append((ci, qi, user_id, speakers, qa))

    sem = asyncio.Semaphore(args.concurrency)
    results = dict(done)
    lock = asyncio.Lock()
    last_save = [time.time()]

    def save():
        by = {}
        for key, r in results.items():
            by.setdefault(key.split("|")[0], []).append(r)
        for k in by:
            by[k].sort(key=lambda r: r["qa_index"])
        out.write_text(json.dumps(dict(sorted(by.items(), key=lambda x: int(x[0]))), indent=1, ensure_ascii=False))

    async with Store(args.agent_id, args.store, args.store_json) as store:
        vm = VMem(store, cfg)

        async def job(ci, qi, user_id, speakers, qa):
            async with sem:
                t0 = time.time()
                try:
                    ans, tr = await vm.answer(user_id, qa["question"], speakers)
                    err = None
                except Exception as e:  # noqa: BLE001
                    ans, tr, err = "", None, f"{type(e).__name__}: {e}"
                rec = {
                    "qa_index": qi, "question": qa["question"], "answer": qa.get("answer", qa.get("adversarial_answer")),
                    "category": qa["category"], "evidence": qa.get("evidence", []), "response": ans,
                    "usage": tr.usage if tr else None,
                    "prompt_tokens": tr.usage["prompt_tokens"] if tr else None,
                    "completion_tokens": tr.usage["completion_tokens"] if tr else None,
                    "latency_s": round(time.time() - t0, 1), "error": err,
                    "trace": dataclasses.asdict(tr) if tr else None,
                }
                async with lock:
                    if err is None:
                        results[f"{ci}|{qi}"] = rec
                    if time.time() - last_save[0] > 30:
                        save()
                        last_save[0] = time.time()
                if err:
                    print("ERROR", ci, qi, err)

        await tqdm.gather(*[job(*j) for j in jobs], desc="vmem")
    save()
    (out.parent / "usage.json").write_text(json.dumps(usage_summary(), indent=1))
    print(json.dumps(usage_summary()["_total"]))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=os.environ.get("LOCOMO"), help="locomo10.json (default: $LOCOMO)")
    ap.add_argument("--out", required=True, help="results.json to write (config.json and usage.json go next to it)")
    ap.add_argument("--conv-ids", default=None, help="comma-separated sample_ids, e.g. conv-26,conv-41")
    ap.add_argument("--qids", default=None, help="comma-separated sample_id:qa_index")
    ap.add_argument("--agent-id", default=os.environ.get("VMEM_AGENT_ID", "locomo_opus45"),
                    help="agent_id of the memory store (postgres backend)")
    ap.add_argument("--store", default=None, help="postgres | json (default: $VMEM_STORE or postgres)")
    ap.add_argument("--store-json", default=None, help="JSON memory export (default: $VMEM_STORE_JSON)")
    ap.add_argument("--concurrency", type=int, default=12, help="questions answered in parallel")
    ap.add_argument("--overwrite", action="store_true", help="ignore existing results instead of resuming")
    ap.add_argument("--cfg", nargs="*", help="Config overrides key=value")
    asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    main()
