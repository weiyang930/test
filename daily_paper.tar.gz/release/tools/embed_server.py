"""OpenAI-compatible /v1/embeddings server backed by a local SentenceTransformer model.

VMem uses it for all dense retrieval (memory items and queries). Default model:
Qwen/Qwen3-Embedding-4B (2560-d, L2-normalised), bf16 on one GPU.
    CUDA_VISIBLE_DEVICES=0 python tools/embed_server.py        # serves http://127.0.0.1:18080/v1/embeddings
"""
import asyncio
import os

import torch
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer

# cuDNN is not needed for embedding inference; disabling it avoids cuDNN loading issues on some setups.
torch.backends.cudnn.enabled = False
torch.backends.cuda.enable_cudnn_sdp(False)
MODEL = os.environ.get("EMBED_MODEL", "Qwen/Qwen3-Embedding-4B")
model = SentenceTransformer(MODEL, device="cuda", model_kwargs={"torch_dtype": torch.bfloat16})
lock = asyncio.Lock()
app = FastAPI()


class Req(BaseModel):
    input: str | list[str]
    model: str | None = None


@app.post("/v1/embeddings")
async def embed(req: Req):
    texts = [req.input] if isinstance(req.input, str) else req.input
    texts = [t if t.strip() else " " for t in texts]
    async with lock:
        vecs = await asyncio.to_thread(
            model.encode, texts, batch_size=64, normalize_embeddings=True, convert_to_numpy=True
        )
    return {
        "object": "list",
        "model": MODEL,
        "data": [{"object": "embedding", "index": i, "embedding": v.tolist()} for i, v in enumerate(vecs)],
        "usage": {"prompt_tokens": 0, "total_tokens": 0},
    }


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=int(os.environ.get("EMBED_PORT", "18080")), log_level="warning")
