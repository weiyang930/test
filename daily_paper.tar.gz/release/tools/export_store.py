"""Export a memory store from Postgres (NEMORI tables `episodes`, `semantic_memories`) to the JSON
format read by VMem's json backend, so VMem can run without a database.

    DATABASE_URL=postgresql://user:pass@host:port/db python tools/export_store.py --agent-id locomo_opus45 --out memory.json

Output: {user_id: {"episodes": [{id, title, content, source_messages, created_at}],
                   "semantic": [{id, content, memory_type, source_episode_id, created_at}]}}
Rows are written in the order the database returns them (VMem's item order follows this order).
"""
import argparse
import asyncio
import json
import os

import asyncpg


async def main(args):
    conn = await asyncpg.connect(os.environ.get("DATABASE_URL", "postgresql://nemori:nemori@127.0.0.1:15432/nemori"))
    users = [r["user_id"] for r in await conn.fetch(
        "select distinct user_id from episodes where agent_id=$1 order by user_id", args.agent_id)]
    out = {}
    for u in users:
        eps = await conn.fetch("select id, title, content, source_messages, created_at from episodes "
                               "where user_id=$1 and agent_id=$2", u, args.agent_id)
        sems = await conn.fetch("select id, content, memory_type, source_episode_id, created_at from semantic_memories "
                                "where user_id=$1 and agent_id=$2", u, args.agent_id)
        out[u] = {
            "episodes": [{"id": str(e["id"]), "title": e["title"], "content": e["content"],
                          "source_messages": json.loads(e["source_messages"]) if isinstance(e["source_messages"], str)
                          else e["source_messages"], "created_at": e["created_at"].isoformat()} for e in eps],
            "semantic": [{"id": str(s["id"]), "content": s["content"], "memory_type": s["memory_type"],
                          "source_episode_id": str(s["source_episode_id"]) if s["source_episode_id"] else None,
                          "created_at": s["created_at"].isoformat()} for s in sems],
        }
    await conn.close()
    with open(args.out, "w") as f:
        json.dump(out, f, ensure_ascii=False)
    print({u: (len(v["episodes"]), len(v["semantic"])) for u, v in out.items()})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--agent-id", default="locomo_opus45")
    ap.add_argument("--out", required=True)
    asyncio.run(main(ap.parse_args()))
