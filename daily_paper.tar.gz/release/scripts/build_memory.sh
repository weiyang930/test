#!/bin/bash
# Build the LoCoMo memory store with NEMORI memory construction (Claude Opus 4.5, agent locomo_opus45).
#   bash scripts/build_memory.sh <locomo10.json> [config.json]
# Prerequisites (see README): `docker compose up -d`, embedding server on $EMBEDDING_BASE_URL,
# AWS Bedrock credentials. The store is written to Postgres (DATABASE_URL) and Qdrant.
set -euo pipefail
cd "$(dirname "$0")/.."
DATA=${1:?locomo10.json}; CONFIG=${2:-configs/nemori_opus45.json}
export DATABASE_URL=${DATABASE_URL:-postgresql://nemori:nemori@127.0.0.1:15432/nemori}
export QDRANT_URL=${QDRANT_URL:-127.0.0.1} QDRANT_PORT=${QDRANT_PORT:-16333}
export EMBEDDING_BASE_URL=${EMBEDDING_BASE_URL:-http://127.0.0.1:18080/v1} EMBEDDING_API_KEY=${EMBEDDING_API_KEY:-local}
export LLM_API_KEY=${LLM_API_KEY:-unused}   # LLM calls go to Bedrock through vmem/llm.py
mkdir -p logs
python tools/build_memory.py --data "$DATA" --config "$CONFIG" --batch-size 1 --max-workers ${BUILD_WORKERS:-10} \
  2>&1 | tee logs/build_memory.log
