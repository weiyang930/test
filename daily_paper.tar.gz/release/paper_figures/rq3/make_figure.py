"""Optional RQ3 accuracy–cost figure from figdata/accuracy_cost.csv (subset, both backbones). Plot only.
    python paper_figures/rq3/make_figure.py
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

EXP3 = Path(__file__).resolve().parent
rows = [r for r in csv.DictReader((EXP3 / "figdata/accuracy_cost.csv").open()) if r["scope"] == "subset"
        and "re-run" not in r["variant"]]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "pdf.fonttype": 42, "savefig.dpi": 300})
SHORT = {"Full VMem": "Full", "w/o Query Planning": "−Plan", "w/o Source-Turn Retrieval": "−Turn route",
         "w/o Evidence Reification": "−Reification", "w/o ViewCards in Answering": "−Cards (answer)",
         "w/o Evidence Refinement": "−Refinement", "Matched-Budget Retrieval-Only": "Matched retrieval-only"}
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6))
for ax, bb, title in zip(axs, ("haiku", "opus"), ("Claude Haiku 4.5", "Claude Opus 4.5")):
    rs = [r for r in rows if r["backbone"] == bb]
    for r in rs:
        x, y = float(r["cost_usd_per_q"]) * 100, float(r["overall"])
        full = r["variant"] == "Full VMem"
        ax.scatter(x, y, s=34 if full else 22, color="#2F6DA8" if full else ("#8C8C8C" if "Matched" in r["variant"] else "#8DB4DA"),
                   edgecolor="#333333", linewidth=0.5, zorder=3)
        ax.annotate(SHORT[r["variant"]], (x, y), textcoords="offset points", xytext=(4, 3), fontsize=6.5)
    ax.set_title(title, loc="left", fontweight="bold", fontsize=9)
    ax.set_xlabel("Estimated cost per question (US cents)")
    ax.set_ylabel("LLM-judge accuracy (%)")
    ax.grid(lw=0.4, color="#DDDDDD")
    ax.set_axisbelow(True)
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(EXP3 / f"figures/rq3_accuracy_cost.{ext}", bbox_inches="tight", pad_inches=0.02)
print("ok")
