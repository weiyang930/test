"""Exp8 figures (plot only; numbers come from figdata/*.csv exported from the paper's experiment runs). Opus 4.5 answers, n=240,
design-weighted.
  Figure A: answer-level groundedness distribution per method, (a) all claims incl. explanation, (b) core claims only.
  Figure B: correctness x groundedness joint distribution (grouped bars, method colours).
    python paper_figures/rq8/make_figure.py
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

EXP8 = Path(__file__).resolve().parent
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
                     "pdf.fonttype": 42, "savefig.dpi": 320})
M = ["VMem", "NEMORI", "SimpleMem", "MemR3"]
MLAB = {"VMem": "Ours", "NEMORI": "NEMORI", "SimpleMem": "SimpleMem", "MemR3": "MemR³"}
MCOL = {"VMem": "#0B4F9C", "NEMORI": "#555555", "SimpleMem": "#D55E00", "MemR3": "#009E73"}

# ---------------------------------------------------------------- Figure A
A = {r["method"]: r for r in csv.DictReader((EXP8 / "figdata/figA_opus.csv").open())}
SEG = [("FULLY", "Fully grounded", "#1F5FA8"), ("PARTIAL", "Partially grounded", "#9DC3E6"),
       ("UNVERIFIABLE", "Unverifiable", "#D9D9D9"), ("UNSUPPORTED", "Unsupported", "#F2B07A"),
       ("CONTRADICTED", "Contradicted", "#C0392B"), ("NO_CLAIM", "Abstain / no claim", "#FFFFFF")]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 1.95), sharey=True)
for ax, pre, title in zip(axs, ("", "core_"), ("(a) All claims (answer + explanation)", "(b) Core claims only (final answer)")):
    for yi, m in enumerate(M[::-1]):
        left = 0.0
        for key, lab, c in SEG:
            v = 100 * float(A[m][pre + key])
            ax.barh(yi, v, left=left, height=0.62, color=c, edgecolor="white" if key != "NO_CLAIM" else "#8C8C8C",
                    linewidth=0.8 if key != "NO_CLAIM" else 0.5, hatch="////" if key == "NO_CLAIM" else None,
                    label=lab if (yi == 0 and pre == "") else None)
            if key in ("FULLY",) or (key == "CONTRADICTED" and v >= 6):
                ax.text(left + v / 2, yi, f"{v:.0f}", ha="center", va="center", fontsize=6.8,
                        color="white", fontweight="bold")
            left += v
    ax.set_yticks(range(len(M)))
    ax.set_yticklabels([MLAB[m] for m in M[::-1]])
    for t, m in zip(ax.get_yticklabels(), M[::-1]):
        t.set_color(MCOL[m])
        t.set_fontweight("bold")
    ax.set_xlim(0, 100)
    ax.set_xticks(range(0, 101, 20))
    ax.set_xlabel("Share of answers (%)", fontsize=7.5, labelpad=2)
    ax.grid(axis="x", lw=0.6, color="#C4C4C4", ls=(0, (4, 3)))
    ax.set_axisbelow(True)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.set_title(title, loc="left", fontweight="bold", fontsize=8.2)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=6, frameon=False, fontsize=7, bbox_to_anchor=(0.5, -0.1), handlelength=1.4, columnspacing=1.2)
fig.tight_layout(w_pad=1.5)
for ext in ("pdf", "png"):
    fig.savefig(EXP8 / f"figures/rq8_groundedness_by_method.{ext}", bbox_inches="tight", pad_inches=0.02)

# ---------------------------------------------------------------- Figure B
B = {r["method"]: r for r in csv.DictReader((EXP8 / "figdata/figB_opus.csv").open())}
G = [("Correct &\nfully grounded", ["Correct & fully grounded"]),
     ("Correct, not\nfully grounded", ["Correct & not fully grounded", "Correct & abstain/no claim"]),
     ("Incorrect &\nfully grounded", ["Incorrect & fully grounded"]),
     ("Incorrect, not fully\ngrounded / abstain", ["Incorrect & not fully grounded", "Incorrect & abstain/no claim"])]
fig, ax = plt.subplots(figsize=(4.6, 2.1))
w = 0.19
for j, m in enumerate(M):
    xs = [i + (j - 1.5) * w for i in range(len(G))]
    ys = [100 * sum(float(B[m][k]) for k in ks) for _, ks in G]
    ax.bar(xs, ys, width=w * 0.92, color=MCOL[m], label=MLAB[m], edgecolor="white", linewidth=0.4, zorder=3)
    for x, y in zip(xs, ys):
        ax.text(x, y + 1.2, f"{y:.0f}", ha="center", va="bottom", fontsize=5.6, color="#333333")
ax.set_xticks(range(len(G)))
ax.set_xticklabels([g for g, _ in G], fontsize=7)
ax.tick_params(axis="x", length=0)
ax.set_ylabel("Share of answers (%)")
ax.set_ylim(0, 85)
ax.grid(axis="y", lw=0.6, color="#C4C4C4", ls=(0, (4, 3)))
ax.set_axisbelow(True)
leg = ax.legend(frameon=False, fontsize=7, ncol=4, loc="upper right", handlelength=1.0, columnspacing=1.0)
for t, m in zip(leg.get_texts(), M):
    t.set_color(MCOL[m])
    t.set_fontweight("bold")
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(EXP8 / f"figures/rq8_correctness_x_groundedness.{ext}", bbox_inches="tight", pad_inches=0.02)
print("ok")
