"""Figure A: accuracy vs. number of annotated supporting turns (1 / 2 / 3+), one panel per backbone. Plot only.
MRAgent is omitted (Haiku-only baseline). Lines are labelled directly at their right end.
    python paper_figures/rq6/make_figure.py
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.patheffects as pe  # noqa: E402

EXP6 = Path(__file__).resolve().parent
rows = [r for r in csv.DictReader((EXP6 / "figdata/figA_accuracy_by_complexity.csv").open()) if r["grouping"] == "card"]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 0,
                     "pdf.fonttype": 42, "savefig.dpi": 300})
# high-contrast, colour-blind-safe palette (Okabe–Ito based); each baseline also has its own dash pattern + marker
STY = {"NEMORI": ("#555555", "o", "NEMORI", (0, (4, 2))),
       "SimpleMem": ("#D55E00", "s", "SimpleMem", (0, (6, 2, 1.5, 2))),
       "MemR3": ("#009E73", "^", "MemR³", (0, (1.2, 1.8))),
       "VMem": ("#0B4F9C", "o", "Ours", "-")}
G = ["1 turn", "2 turns", "3+ turns"]
XL = ["1", "2", "3+"]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.3), sharey=True)
for ax, bb, title in zip(axs, ("haiku", "opus"), ("(a) Claude Haiku 4.5", "(b) Claude Opus 4.5")):
    rs = {r["group"]: r for r in rows if r["backbone"] == bb}
    ys = {m: [float(rs[g][f"acc_{m}"]) for g in G] for m in STY}
    best = [max(ys[m][i] for m in STY if m != "VMem") for i in range(3)]
    # shaded margin between Ours and the best baseline at each level
    ax.fill_between(range(3), best, ys["VMem"], color="#0B4F9C", alpha=0.07, lw=0, zorder=1)
    for m, (c, mk, lab, ls) in STY.items():
        ours = m == "VMem"
        line, = ax.plot(range(3), ys[m], color=c, lw=2.6 if ours else 1.5, ls=ls, zorder=4 if ours else 2,
                        solid_capstyle="round", dash_capstyle="round")
        if ours:   # soft halo under the main line
            line.set_path_effects([pe.Stroke(linewidth=7, foreground=c, alpha=0.18), pe.Normal()])
        ax.scatter(range(3), ys[m], s=46 if ours else 30, marker=mk, facecolor=c if ours else "white", edgecolor=c if not ours else "white",
                   linewidth=1.3 if not ours else 1.2, zorder=5 if ours else 3)
    # direct labels at the right end, nudged apart vertically
    ends = sorted(((ys[m][-1], m) for m in STY), key=lambda t: t[0])
    pos, last = {}, -1e9
    for y, m in ends:
        pos[m] = max(y, last + 3.4)
        last = pos[m]
    for m, (c, _, lab, _) in STY.items():
        ax.annotate(lab, (2, ys[m][-1]), xytext=(2.12, pos[m]), textcoords="data", va="center", ha="left", fontsize=7,
                    color=c, fontweight="bold")
    gap = ys["VMem"][-1] - best[-1]
    ax.annotate(f"+{gap:.1f}", xy=(2, (ys['VMem'][-1] + best[-1]) / 2), xytext=(-9, 0), textcoords="offset points",
                ha="right", va="center", fontsize=6.8, color="#0B4F9C", fontweight="bold")
    ax.set_xticks(range(3))
    ax.set_xticklabels([f"{x}\n(n={rs[g]['n']})" for x, g in zip(XL, G)], fontsize=7.2)
    ax.set_xlim(-0.12, 2.85)
    ax.set_ylim(50, 97)
    ax.set_yticks(range(50, 101, 10))
    ax.grid(axis="y", lw=0.6, color="#C4C4C4", ls=(0, (4, 3)))
    ax.set_axisbelow(True)
    ax.set_title(title, loc="left", fontweight="bold", fontsize=8.5)
    ax.set_xlabel("Annotated supporting turns", fontsize=7.5, labelpad=2)
axs[0].set_ylabel("Accuracy (%)")
fig.tight_layout(w_pad=2.2)
for ext in ("pdf", "png"):
    fig.savefig(EXP6 / f"figures/rq6_accuracy_by_cardinality.{ext}", bbox_inches="tight", pad_inches=0.02)
print("ok")
