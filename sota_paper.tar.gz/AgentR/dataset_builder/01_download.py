"""Step 1: download raw Amazon-Reviews-2023 review + meta files for a category.

Downloads (resumable, into the HF cache and symlinked into raw_dir):
  raw/review_categories/{CATEGORY}.jsonl
  raw/meta_categories/meta_{CATEGORY}.jsonl

Usage:
  python 01_download.py --category Software --raw-dir data/amazon_raw
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

from huggingface_hub import hf_hub_download

from amazon_common import HF_REPO, meta_file, review_file


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--category", required=True, help="e.g. Software, Baby_Products")
    ap.add_argument("--raw-dir", default="data/amazon_raw")
    args = ap.parse_args()

    os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "60")
    raw_dir = Path(args.raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    for fn in (review_file(args.category), meta_file(args.category)):
        print(f"[download] {fn}")
        local = hf_hub_download(
            repo_id=HF_REPO,
            filename=fn,
            repo_type="dataset",
            local_dir=str(raw_dir),
        )
        size_mb = os.path.getsize(local) / 1e6
        print(f"[download]   -> {local} ({size_mb:.1f} MB)")

    print("[download] done.")


if __name__ == "__main__":
    main()
