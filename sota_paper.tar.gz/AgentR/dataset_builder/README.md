# dataset_builder — Amazon-Reviews-2023 → demo-schema datasets

Self-contained pipeline that turns **Amazon-Reviews-2023** categories into
datasets that are **schema-identical** to `data/public_demo_data` (the rednote
demo). Goal: evaluate the MAS-Rec method on multiple public datasets without
touching pipeline code — just point `dataset.root_dir` at a built folder.

Source: HF `McAuley-Lab/Amazon-Reviews-2023`
(https://huggingface.co/datasets/McAuley-Lab/Amazon-Reviews-2023).

---

## 1. Output schema (matches demo exactly — verified)

Three files (+ parquet mirrors), one dataset per `data/amazon/<Category>/`:

| file | fields |
|---|---|
| `users.{jsonl,parquet}` | `user_id`, `profile_fields{8 demo demographic keys}`, `llm_output` (LLM persona) |
| `items.{jsonl,parquet}` | `note_id`, `title`, `content`, `label`, `good_attr_raw`, `parsed_attr{brand_name, category_l1, category_l2, price, product_name}` |
| `interactions.{jsonl,parquet}` | `user_id`, `note_id`, `conv_time`, `date_partition` (positives only, chronological) |

All three parquet schemas were confirmed byte-for-byte identical to the demo
(`struct` field names + order included), and the built dataset loads cleanly
through the project's own `reflective_mas_rec.data.dataset.Dataset` loader and
`build_item_compact_card`.

### Amazon → demo field mapping (`amazon_common.map_meta_to_item`)
| demo field | Amazon source |
|---|---|
| `note_id` | `parent_asin` |
| `title` / `parsed_attr.product_name` | meta `title` |
| `content` | meta `description[]` (joined) |
| `label` | meta `categories[]` (comma-joined) or `main_category` |
| `parsed_attr.category_l1 / l2` | `categories[0] / [1]` (fallback `main_category`) |
| `parsed_attr.brand_name` | meta `store` |
| `parsed_attr.price` | meta `price` (→ `UNKNOWN` if missing/non-numeric) |
| `conv_time` / `date_partition` | review `timestamp` (ms epoch) → epoch str / `YYYYMMDD` |

Amazon has **no user demographics**, so `profile_fields` is emitted as the demo's
8-key struct with empty strings (schema parity; `use_profile_fields` is a config
toggle in the pipeline anyway). The rich user signal lives in `llm_output`.

---

## 2. Design decisions (agreed with owner)

- **Persona LLM** = `Qwen3-30B-A3B-Instruct-2507`
  (a local Qwen3-30B-A3B-Instruct HF dir). MoE with ~3B active
  params → 8B-class throughput at much higher quality; non-thinking instruct →
  clean structured prose in one pass (no `<think>` to strip). Generates
  `llm_output` from each user's profiling-window reviews. Swap with
  `--persona-model` (14B / 32B / an API model are drop-in).
  - *Why not Opus/Bedrock*: cost + external dependency for a reproducible
    benchmark artifact. Held in reserve — flip one flag to regenerate if needed.

- **History split** = **per-user timeline, fixed profiling window** (default
  `--profiling-mode fixed --profiling-k 5`). Each user's reviews are sorted by
  time; the earliest **k=5** → **profiling window** (persona input); the rest →
  **experiment window** (train/valid/test via leave-one-out downstream). The
  profiling window is an INDEPENDENT slice, never used as train/valid/test, so
  the persona is built strictly from a user's earliest history and never sees
  experiment items → **no leakage**. (Independent profiling window is a hard
  requirement: building the persona from train samples would leak train answers
  into the rank agent at training time.)
  - *Why fixed k, not fractional (`--profiling-mode frac`)*: Amazon's long tail is
    sparse — after 10-core the median user has ~12 interactions. A 50/50 split
    takes half of that, pushing the experiment window below 10-core and
    **collapsing large categories to zero users** (CDs_and_Vinyl, Video_Games both
    → 0 under 50/50). A constant small profiling window keeps the experiment
    window intact → clean k-core, demo-scale sizes. Verified: k=5 personas are
    high-quality and grounded (2444–3025 chars vs demo ≈2274).
  - *Why per-user, not a global calendar cutoff*: both are leakage-free, but a
    global date drops most users (narrow, non-overlapping activity windows) and
    diverges from the project's per-user LOO protocol.

- **Filtering / size** = **clean 10-core on the experiment window** (user count in
  `[--min-user, --max-user]` = `[10, 100]`, item ≥ `--min-item` = 10), iterated to
  a fixed point; if > `--target-users` (15000), seed-42 downsample then re-prune.
  Mirrors the demo's ~10-core / ≤~15k-user distribution.

---

## 3. Files & steps

```
amazon_common.py    shared: HF paths, field mapping, persona prompt, jsonl iter
01_download.py      pull raw/review_categories/<CAT>.jsonl + raw/meta_categories/meta_<CAT>.jsonl
02_build.py         meta→items; reviews→(u,i) edges (dedup earliest ts);
                    per-user time split; iterative core prune on experiment window;
                    seed42 downsample+re-prune → items/interactions
                    (+ profiling.jsonl for persona input, build_stats.json)
03_gen_personas.py  vLLM persona generation from profiling.jsonl → personas.jsonl
04_finalize.py      merge personas → users.{jsonl,parquet} + stats.json + readme.md
run_build.sh        orchestrates all four for one or many categories
```

Intermediate artifacts left in each dataset dir for auditing: `profiling.jsonl`
(per-user reviews fed to the persona LLM), `personas.jsonl` (raw generations),
`build_stats.json` (per-iteration prune log + distributions).

---

## 4. How to run

Whole pipeline for one or more categories:
```bash
cd project/dataset_builder
bash run_build.sh CDs_and_Vinyl
bash run_build.sh Baby_Products CDs_and_Vinyl Musical_Instruments Software Video_Games
# the three finalized datasets, detached (used for the 2026-07-16 build):
nohup bash run_all_three.sh > ../logs_run/amazon_all_three.log 2>&1 &
```
A **new category = change the name only**; no code changes.

`run_build.sh` prepends `.venv_mas/bin` to PATH so vLLM finds `ninja`.
Env overrides: `PY RAW_DIR OUT_ROOT TP TARGET_USERS PERSONA_MODEL`.

Run a single step by hand (remember PATH for the vLLM step):
```bash
PY=/path/to/venv_mas/bin/python
export PATH="$(dirname $PY):/usr/local/cuda-12.9/bin:$PATH"
$PY 02_build.py --category Software --raw-dir ../data/amazon_raw --out-dir ../data/amazon/Software --target-users 15000
CUDA_VISIBLE_DEVICES=0,1,2,3 $PY 03_gen_personas.py --profiling ../data/amazon/Software/profiling.jsonl \
    --out ../data/amazon/Software/personas.jsonl --tp 4 --batch-size 256
$PY 04_finalize.py --out-dir ../data/amazon/Software --category Software
```

### Key CLI knobs
- `02_build.py`: `--profiling-fraction 0.5 --min-profiling 3 --min-user 10 --max-user 100 --min-item 10 --target-users 15000 --seed 42 --max-profiling-reviews 60`
- `03_gen_personas.py`: `--persona-model ... --tp 4 --batch-size 256 --max-tokens 900 --max-reviews 40 --temperature 0.7 --limit N(debug)`

---

## 5. Verified result (2026-07-16, recipe: fixed k=5, clean 10-core)

Schema parity verified (users/items/interactions parquet **identical to demo**),
loads via the project's `Dataset.load`, and k=5 personas are high-quality
(grounded, 2444–3025 chars vs demo ≈2274; e.g. inferred "classic-rock physical-
media loyalist who sees lazy compilations as a betrayal of legacy" from 5 reviews
and predicted the next purchase).

Sizes under the finalized recipe:

| category | users | items | interactions |
|---|---|---|---|
| CDs_and_Vinyl | ~9,198 | ~8,669 | ~183,878 |
| Software | ~11,910 | ~3,978 | — |
| Video_Games | ~3,790 | ~2,412 | — (small = mini-demo, OK) |

For reference, **pure 10-core with no profiling split** yields Software 29.6k /
Video_Games 11.3k / CDs_and_Vinyl 16.5k users — Amazon is not small; reserving a
fixed 5-review profiling window per user is what brings it to these sizes.
Want bigger? `Kindle_Store` (already downloaded), `Books`, `Movies_and_TV` have
longer per-user histories.

---

## 6. Gotchas

- **`ninja` must be on PATH** for vLLM to compile kernels on this Blackwell env
  (`.venv_mas/bin/ninja`). `run_build.sh` sets it; set it manually if you invoke
  `03_gen_personas.py` directly. (Same note as the B200 env setup.)
- Persona gen holds `tp` GPUs (4 by default). Kill stray workers before
  relaunching, or a new run collides mid-load:
  `nvidia-smi --query-compute-apps=pid --format=csv,noheader | xargs -r kill -9`
- Raw HF files cache in `data/amazon_raw/`; built datasets in `data/amazon/<Category>/`.
- `Qwen3-30B-A3B-Instruct-2507` on A100/40GB logs a "default MoE config /
  performance sub-optimal" warning — harmless, just no tuned kernel config for
  this GPU.
