"""Step 4: assemble the final users file + dataset stats, matching demo schema.

Merges personas.jsonl into demo-schema users (user_id, profile_fields, llm_output),
writes users.{jsonl,parquet}, a demo-style stats.json, and a readme.md.

Every user in interactions must appear in users; users without a generated
persona get an empty llm_output (should be ~0 if step 3 covered everyone).

Usage:
  python 04_finalize.py --out-dir data/amazon/Software --category Software
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

from amazon_common import empty_profile_fields, iter_jsonl


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--category", required=True)
    args = ap.parse_args()

    out = Path(args.out_dir)

    # users present in interactions (the ground truth user set)
    inter = pd.read_parquet(out / "interactions.parquet")
    user_ids = sorted(inter["user_id"].unique().tolist())

    personas: Dict[str, str] = {}
    ppath = out / "personas.jsonl"
    if ppath.exists():
        for row in iter_jsonl(str(ppath)):
            personas[row["user_id"]] = row.get("llm_output", "")
    n_missing = sum(1 for u in user_ids if not personas.get(u))
    print(f"[finalize] users={len(user_ids):,} personas={len(personas):,} "
          f"missing_persona={n_missing:,}")

    user_rows: List[Dict[str, Any]] = [
        {
            "user_id": uid,
            "profile_fields": empty_profile_fields(),
            "llm_output": personas.get(uid, ""),
        }
        for uid in user_ids
    ]
    with open(out / "users.jsonl", "w", encoding="utf-8") as f:
        for row in user_rows:
            f.write(json.dumps(row, ensure_ascii=False))
            f.write("\n")
    pd.DataFrame(user_rows).to_parquet(out / "users.parquet", index=False)
    print(f"[finalize] wrote users.{{jsonl,parquet}} ({len(user_rows):,} rows)")

    # merge build_stats into a demo-style stats.json
    build_stats: Dict[str, Any] = {}
    bs_path = out / "build_stats.json"
    if bs_path.exists():
        build_stats = json.loads(bs_path.read_text(encoding="utf-8"))
    n_items = pd.read_parquet(out / "items.parquet").shape[0]
    stats = {
        "category": args.category,
        "source_repo": "McAuley-Lab/Amazon-Reviews-2023",
        "schema": "demo-compatible (users/items/interactions)",
        "num_users": len(user_ids),
        "num_items": int(n_items),
        "num_interactions": int(inter.shape[0]),
        "num_missing_persona": n_missing,
        "build_params": build_stats.get("params", {}),
        "final_distribution": build_stats.get("final", {}),
    }
    with open(out / "stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

    readme = _readme(args.category, stats)
    (out / "readme.md").write_text(readme, encoding="utf-8")
    print(f"[finalize] wrote stats.json + readme.md")
    print(f"[finalize] DONE. dataset root: {out}")
    print(f"[finalize]   users={stats['num_users']:,} items={stats['num_items']:,} "
          f"interactions={stats['num_interactions']:,}")


def _readme(category: str, stats: Dict[str, Any]) -> str:
    return f"""# Amazon-Reviews-2023 · {category} (demo-schema build)

Built to be schema-identical to `data/public_demo_data` so the reflective_mas_rec
and recbole pipelines run unmodified (just point `dataset.root_dir` here).

## Source
- Repo: `McAuley-Lab/Amazon-Reviews-2023`
- Files: `raw/review_categories/{category}.jsonl`, `raw/meta_categories/meta_{category}.jsonl`

## Files
- `users.{{jsonl,parquet}}`  — user_id, profile_fields (8 empty demo keys), llm_output (LLM persona)
- `items.{{jsonl,parquet}}`  — note_id, title, content, label, good_attr_raw, parsed_attr
- `interactions.{{jsonl,parquet}}` — user_id, note_id, conv_time, date_partition (positives, chronological)
- `profiling.jsonl` — per-user earliest reviews used to generate the persona (NOT in experiment window)
- `personas.jsonl`  — raw persona generations
- `stats.json`, `build_stats.json`

## Method
1. Amazon meta -> demo item schema; keep only items with meta.
2. Reviews -> (user,item) edges, dedup keeping earliest timestamp.
3. Per-user time split: earliest ~{stats.get('build_params', {}).get('profiling_fraction', 0.5)} of a
   user's reviews -> **profiling window** (persona input); the rest ->
   **experiment window** (train/valid/test via leave-one-out downstream).
   The split is frozen per user, so the persona never sees experiment items (no leakage).
4. Iterative {stats.get('build_params', {}).get('min_item', 10)}-core pruning on the
   experiment window (user in [{stats.get('build_params', {}).get('min_user', 10)},
   {stats.get('build_params', {}).get('max_user', 100)}], item >= {stats.get('build_params', {}).get('min_item', 10)}).
5. seed={stats.get('build_params', {}).get('seed', 42)} downsample to <=
   {stats.get('build_params', {}).get('target_users', 15000)} users, then re-prune.
6. Persona (llm_output) generated by a local LLM from the profiling window.

## Resulting stats
```json
{json.dumps(stats, ensure_ascii=False, indent=2)}
```
"""


if __name__ == "__main__":
    main()
