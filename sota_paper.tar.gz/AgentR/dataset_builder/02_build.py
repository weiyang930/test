"""Step 2: build demo-schema items + interactions from raw Amazon files.

Pipeline (per-user time split, then 10-core on the experiment window):
  1. Load meta -> item records (demo schema). Only items with meta survive.
  2. Stream reviews; keep compact edges (user, asin, ts, rating) for known items;
     dedup (user,item) keeping the earliest timestamp.
  3. Per user, sort by time. FREEZE a split: earliest floor(n*frac) reviews
     (>= min_profiling) -> profiling window; the rest -> experiment window.
  4. Iterative core pruning on the EXPERIMENT window only:
       drop items with < min_item interactions; drop users whose experiment
       count is outside [min_user, max_user]; repeat to a fixed point.
  5. If users > target, seed42 downsample then re-prune to a fixed point.
  6. Second pass over reviews: collect profiling-window review text for the
     surviving users (input to persona generation).
  7. Write items/interactions (jsonl + parquet), profiling.jsonl, build_stats.json.

The profiling window is frozen in step 3 and never re-pruned — it is only LLM
persona input and must stay strictly earlier than the experiment window (no
leakage into train/valid/test, which are LOO'd from the experiment window).

Usage:
  python 02_build.py --category Software \
    --raw-dir data/amazon_raw --out-dir data/amazon/Software \
    --profiling-fraction 0.5 --min-user 10 --max-user 100 --min-item 10 \
    --min-profiling 3 --target-users 15000 --seed 42
"""
from __future__ import annotations

import argparse
import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pandas as pd

from amazon_common import (
    iter_jsonl,
    map_meta_to_item,
    meta_file,
    ms_to_date_partition,
    review_file,
)


def load_items(meta_path: str) -> Dict[str, Dict[str, Any]]:
    """parent_asin -> demo-schema item record (dedup on parent_asin)."""
    items: Dict[str, Dict[str, Any]] = {}
    n = 0
    for meta in iter_jsonl(meta_path):
        n += 1
        pa = str(meta.get("parent_asin") or "").strip()
        if not pa or pa in items:
            continue
        items[pa] = map_meta_to_item(pa, meta)
    print(f"[build] meta rows={n} unique items={len(items)}")
    return items


def load_edges(
    review_path: str, known_items: set
) -> Dict[str, List[Tuple[str, float, Any]]]:
    """user_id -> list of (asin, ts_ms, rating), deduped per (user,item) keeping
    the earliest timestamp. Only reviews on known (has-meta) items are kept."""
    # (user,item) -> (ts, rating); keep earliest ts
    best: Dict[Tuple[str, str], Tuple[float, Any]] = {}
    n = kept = 0
    for r in iter_jsonl(review_path):
        n += 1
        if n % 2_000_000 == 0:
            print(f"[build]   scanned {n:,} reviews, kept {kept:,} edges")
        pa = str(r.get("parent_asin") or "").strip()
        if not pa or pa not in known_items:
            continue
        uid = str(r.get("user_id") or "").strip()
        if not uid:
            continue
        try:
            ts = float(r.get("timestamp") or 0)
        except (TypeError, ValueError):
            ts = 0.0
        key = (uid, pa)
        prev = best.get(key)
        if prev is None or ts < prev[0]:
            best[key] = (ts, r.get("rating"))
            if prev is None:
                kept += 1
    edges: Dict[str, List[Tuple[str, float, Any]]] = defaultdict(list)
    for (uid, pa), (ts, rating) in best.items():
        edges[uid].append((pa, ts, rating))
    for uid in edges:
        edges[uid].sort(key=lambda t: (t[1], t[0]))  # by ts, then asin (stable)
    print(f"[build] reviews={n:,} users={len(edges):,} unique (u,i) edges={kept:,}")
    return edges


def split_windows(
    edges: Dict[str, List[Tuple[str, float, Any]]],
    mode: str,
    frac: float,
    profiling_k: int,
    min_profiling: int,
) -> Tuple[Dict[str, List[Tuple[str, float, Any]]], Dict[str, List[Tuple[str, float, Any]]]]:
    """Freeze the per-user profiling/experiment split by time.

    The profiling window is the earliest N edges; the experiment window is the
    remainder (strictly later in time). N is:
      mode="fixed": N = profiling_k                 (constant per user)
      mode="frac" : N = max(min_profiling, floor(n*frac))

    The profiling window is a SEPARATE slice, never re-pruned and never used as
    train/valid/test — so the persona built from it cannot leak experiment items.
    Users without both windows non-empty are dropped here.

    `fixed` is the default: on Amazon's long tail a fractional split takes ~half
    of already-short histories, pushing the experiment window below the k-core
    threshold and collapsing large categories to zero. A small constant profiling
    window keeps the experiment window intact -> clean k-core, demo-scale sizes.
    """
    prof: Dict[str, List[Tuple[str, float, Any]]] = {}
    exp: Dict[str, List[Tuple[str, float, Any]]] = {}
    for uid, evs in edges.items():
        n = len(evs)
        if mode == "fixed":
            n_prof = profiling_k
        else:
            n_prof = max(min_profiling, int(n * frac))
        if n_prof >= n:  # no room for an experiment window
            continue
        p, e = evs[:n_prof], evs[n_prof:]
        if len(p) < min_profiling or len(e) < 1:
            continue
        prof[uid] = p
        exp[uid] = e
    print(f"[build] after time-split (mode={mode}): users with both windows={len(exp):,}")
    return prof, exp


def prune_core(
    exp: Dict[str, List[Tuple[str, float, Any]]],
    min_user: int,
    max_user: int,
    min_item: int,
) -> Tuple[Dict[str, List[Tuple[str, float, Any]]], List[Dict[str, Any]]]:
    """Iterative core pruning on experiment edges to a fixed point.

    Returns the surviving experiment map and a per-iteration stats log.
    """
    exp = {u: list(evs) for u, evs in exp.items()}
    log: List[Dict[str, Any]] = []
    it = 0
    while True:
        it += 1
        item_count: Counter = Counter()
        for evs in exp.values():
            for (pa, _ts, _r) in evs:
                item_count[pa] += 1
        low_items = {pa for pa, c in item_count.items() if c < min_item}

        before_users = len(exp)
        before_rows = sum(len(v) for v in exp.values())
        before_items = len(item_count)

        removed_users = 0
        new_exp: Dict[str, List[Tuple[str, float, Any]]] = {}
        for uid, evs in exp.items():
            kept = [e for e in evs if e[0] not in low_items] if low_items else evs
            c = len(kept)
            if c < min_user or c > max_user:
                removed_users += 1
                continue
            new_exp[uid] = kept
        exp = new_exp

        after_rows = sum(len(v) for v in exp.values())
        after_items = len({e[0] for evs in exp.values() for e in evs})
        log.append(
            {
                "iteration": it,
                "before_users": before_users,
                "before_items": before_items,
                "before_rows": before_rows,
                "removed_low_items": len(low_items),
                "removed_users_outside_range": removed_users,
                "after_users": len(exp),
                "after_items": after_items,
                "after_rows": after_rows,
            }
        )
        if len(low_items) == 0 and removed_users == 0:
            break
        if it > 50:
            print("[build] WARN prune did not converge in 50 iters")
            break
    print(f"[build] after core prune: users={len(exp):,} in {it} iters")
    return exp, log


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--category", required=True)
    ap.add_argument("--raw-dir", default="data/amazon_raw")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--profiling-mode", choices=["fixed", "frac"], default="fixed",
                    help="fixed: profiling window = earliest --profiling-k edges "
                         "(default, keeps experiment window intact for clean k-core); "
                         "frac: earliest --profiling-fraction of each user's history")
    ap.add_argument("--profiling-k", type=int, default=5,
                    help="[fixed mode] number of earliest edges reserved for the persona")
    ap.add_argument("--profiling-fraction", type=float, default=0.5,
                    help="[frac mode] fraction of earliest history reserved for the persona")
    ap.add_argument("--min-profiling", type=int, default=3)
    ap.add_argument("--min-user", type=int, default=10)
    ap.add_argument("--max-user", type=int, default=100)
    ap.add_argument("--min-item", type=int, default=10)
    ap.add_argument("--target-users", type=int, default=15000)
    ap.add_argument("--max-profiling-reviews", type=int, default=60,
                    help="cap profiling reviews captured per user (persona input)")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    raw = Path(args.raw_dir)
    meta_path = str(raw / meta_file(args.category))
    review_path = str(raw / review_file(args.category))
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    items = load_items(meta_path)
    edges = load_edges(review_path, set(items.keys()))
    prof, exp = split_windows(
        edges, args.profiling_mode, args.profiling_fraction,
        args.profiling_k, args.min_profiling,
    )
    del edges

    exp, prune_log = prune_core(exp, args.min_user, args.max_user, args.min_item)

    # seed42 downsample. NOTE: we deliberately DO NOT re-prune after downsampling.
    # Each surviving user already carries a >=min_user experiment window from the
    # main core-prune, and we never touch their edges here -> the user-side core
    # property is preserved exactly. Re-pruning would re-count item support on the
    # (much smaller) sampled user set, pushing most items below min_item and
    # spiralling the whole graph to zero -- this silently destroyed large dense
    # categories (e.g. Kindle_Store: a healthy 167k-user 10-core collapsed to 0).
    # A little item-side sub-core impurity after sampling is harmless for SASRec /
    # MAS. Small categories (CD/SW/VG/Baby) never reach this branch (all < target).
    resample_log: List[Dict[str, Any]] = []
    if len(exp) > args.target_users:
        rng = random.Random(args.seed)
        keep = set(rng.sample(list(exp.keys()), args.target_users))
        exp = {u: v for u, v in exp.items() if u in keep}
        print(f"[build] downsampled to {len(exp):,} users (no re-prune; "
              "user-side core preserved)")

    final_users = set(exp.keys())
    prof = {u: prof[u] for u in final_users}
    final_items = {e[0] for evs in exp.values() for e in evs}
    print(f"[build] FINAL users={len(final_users):,} items={len(final_items):,} "
          f"interactions={sum(len(v) for v in exp.values()):,}")

    # ---- write items (only items in final experiment interactions) ----
    item_rows = [items[pa] for pa in final_items if pa in items]
    _write_jsonl_parquet(out, "items", item_rows)

    # ---- write interactions (experiment window, chronological) ----
    inter_rows: List[Dict[str, Any]] = []
    for uid, evs in exp.items():
        for (pa, ts, _r) in evs:
            inter_rows.append(
                {
                    "user_id": uid,
                    "note_id": pa,
                    "conv_time": str(int(ts)) if ts and ts > 0 else "",
                    "date_partition": ms_to_date_partition(ts),
                }
            )
    _write_jsonl_parquet(out, "interactions", inter_rows)

    # ---- second pass: capture profiling review text for surviving users ----
    _collect_profiling(
        review_path, items, prof, args.max_profiling_reviews, out
    )

    # ---- build stats ----
    inter_per_user = sorted(len(v) for v in exp.values())
    item_pop = Counter(r["note_id"] for r in inter_rows)
    stats = {
        "category": args.category,
        "source_repo": "McAuley-Lab/Amazon-Reviews-2023",
        "params": {
            "profiling_mode": args.profiling_mode,
            "profiling_k": args.profiling_k,
            "profiling_fraction": args.profiling_fraction,
            "min_profiling": args.min_profiling,
            "min_user": args.min_user,
            "max_user": args.max_user,
            "min_item": args.min_item,
            "target_users": args.target_users,
            "seed": args.seed,
        },
        "final": {
            "num_users": len(final_users),
            "num_items": len(final_items),
            "num_interactions": len(inter_rows),
            "user_interaction_distribution": _dist(inter_per_user),
            "item_interaction_distribution": _dist(sorted(item_pop.values())),
        },
        "prune_log": prune_log,
        "resample_prune_log": resample_log,
    }
    with open(out / "build_stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)
    print(f"[build] wrote {out}/build_stats.json")
    print("[build] done.")


def _collect_profiling(
    review_path: str,
    items: Dict[str, Dict[str, Any]],
    prof: Dict[str, List[Tuple[str, float, Any]]],
    max_reviews: int,
    out: Path,
) -> None:
    """Stream reviews again; for each surviving user's profiling (user,item)
    edges, capture review title/text + item title/category. Writes profiling.jsonl."""
    # set of (user,item) we need text for
    want: Dict[Tuple[str, str], float] = {}
    for uid, evs in prof.items():
        for (pa, ts, _r) in evs:
            want[(uid, pa)] = ts
    captured: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    seen_keys: set = set()  # dedup: raw Amazon has occasional duplicate review rows
    n = 0
    for r in iter_jsonl(review_path):
        n += 1
        if n % 2_000_000 == 0:
            print(f"[build]   (pass2) scanned {n:,} reviews")
        uid = str(r.get("user_id") or "").strip()
        pa = str(r.get("parent_asin") or "").strip()
        if not uid or not pa:
            continue
        key = (uid, pa)
        if key not in want or key in seen_keys:
            continue
        try:
            ts = float(r.get("timestamp") or 0)
        except (TypeError, ValueError):
            ts = 0.0
        # only the earliest occurrence matches the frozen edge timestamp
        if ts != want[key]:
            continue
        seen_keys.add(key)
        item = items.get(pa, {})
        pa_attr = item.get("parsed_attr", {})
        captured[uid].append(
            {
                "item_title": item.get("title", ""),
                "item_category": pa_attr.get("category_l1", ""),
                "rating": r.get("rating"),
                "review_title": r.get("title", ""),
                "review_text": r.get("text", ""),
                "timestamp": ts,
            }
        )
    # order each user's profiling reviews by time, cap length
    rows: List[Dict[str, Any]] = []
    for uid, evs in prof.items():
        revs = sorted(captured.get(uid, []), key=lambda d: d["timestamp"])
        if len(revs) > max_reviews:
            revs = revs[:max_reviews]
        rows.append({"user_id": uid, "n_profiling": len(evs), "reviews": revs})
    with open(out / "profiling.jsonl", "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False))
            f.write("\n")
    print(f"[build] wrote {out}/profiling.jsonl ({len(rows):,} users)")


def _write_jsonl_parquet(out: Path, name: str, rows: List[Dict[str, Any]]) -> None:
    with open(out / f"{name}.jsonl", "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False))
            f.write("\n")
    pd.DataFrame(rows).to_parquet(out / f"{name}.parquet", index=False)
    print(f"[build] wrote {out}/{name}.{{jsonl,parquet}} ({len(rows):,} rows)")


def _dist(sorted_vals: List[int]) -> Dict[str, float]:
    if not sorted_vals:
        return {}
    import statistics

    def pct(p: float) -> float:
        k = int(round((len(sorted_vals) - 1) * p))
        return float(sorted_vals[k])

    return {
        "min": float(sorted_vals[0]),
        "p25": pct(0.25),
        "median": pct(0.5),
        "p75": pct(0.75),
        "p90": pct(0.90),
        "p95": pct(0.95),
        "max": float(sorted_vals[-1]),
        "mean": float(statistics.mean(sorted_vals)),
    }


if __name__ == "__main__":
    main()
