"""Step 3: generate user personas (llm_output) from profiling-window reviews.

Reads profiling.jsonl (from 02_build.py), renders a persona prompt per user,
batches through a local vLLM model, and writes personas.jsonl:
  {"user_id": ..., "llm_output": "<persona text>"}

Default model = Qwen3-30B-A3B-Instruct-2507 (MoE, ~3B active, non-thinking
instruct -> clean structured prose in one pass). Swap via --persona-model.

Usage:
  python 03_gen_personas.py \
    --profiling data/amazon/Software/profiling.jsonl \
    --out data/amazon/Software/personas.jsonl \
    --persona-model /path/to/Qwen3-8B \
    --tp 4 --max-tokens 900 --batch-size 256
"""
from __future__ import annotations

import argparse
import os
import json
import re
from pathlib import Path
from typing import Any, Dict, List

from amazon_common import PERSONA_SYSTEM, build_persona_prompt, iter_jsonl

DEFAULT_MODEL = os.environ.get("BASE_MODEL", "./models/Qwen/Qwen3-8B")

_THINK = re.compile(r"<think>.*?</think>", re.DOTALL)


def _strip_think(text: str) -> str:
    return _THINK.sub("", text or "").strip()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profiling", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--persona-model", default=DEFAULT_MODEL)
    ap.add_argument("--tp", type=int, default=4)
    ap.add_argument("--max-tokens", type=int, default=900)
    ap.add_argument("--max-reviews", type=int, default=40,
                    help="max profiling reviews rendered into the prompt")
    ap.add_argument("--max-model-len", type=int, default=8192)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--batch-size", type=int, default=256)
    ap.add_argument("--gpu-mem-util", type=float, default=0.90)
    ap.add_argument("--limit", type=int, default=0, help="debug: only N users")
    ap.add_argument("--offset", type=int, default=0,
                    help="skip the first N users (for sharding across GPUs)")
    args = ap.parse_args()

    users = list(iter_jsonl(args.profiling))
    if args.offset:
        users = users[args.offset:]
    if args.limit:
        users = users[: args.limit]
    print(f"[persona] users to generate={len(users):,} (offset={args.offset} limit={args.limit})")

    prompts = [
        build_persona_prompt(u.get("reviews", []), max_reviews=args.max_reviews)
        for u in users
    ]

    from vllm import LLM, SamplingParams

    llm = LLM(
        model=args.persona_model,
        tensor_parallel_size=args.tp,
        gpu_memory_utilization=args.gpu_mem_util,
        max_model_len=args.max_model_len,
        trust_remote_code=True,
        dtype="auto",
        enforce_eager=True,  # B200 + vLLM 0.25: CUDA-graph capture hangs post-load; eager is safe
    )
    sp = SamplingParams(temperature=args.temperature, top_p=0.8, max_tokens=args.max_tokens, seed=42)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    n_written = 0
    with open(out_path, "w", encoding="utf-8") as fout:
        bs = max(1, args.batch_size)
        for start in range(0, len(prompts), bs):
            chunk_users = users[start : start + bs]
            chunk_prompts = prompts[start : start + bs]
            convs = [
                [
                    {"role": "system", "content": PERSONA_SYSTEM},
                    {"role": "user", "content": p},
                ]
                for p in chunk_prompts
            ]
            outputs = llm.chat(convs, sampling_params=sp, use_tqdm=False)
            for u, o in zip(chunk_users, outputs):
                text = _strip_think(o.outputs[0].text)
                fout.write(
                    json.dumps(
                        {"user_id": u["user_id"], "llm_output": text},
                        ensure_ascii=False,
                    )
                )
                fout.write("\n")
                n_written += 1
            fout.flush()
            print(f"[persona] {min(start + bs, len(prompts)):,}/{len(prompts):,}")

    print(f"[persona] wrote {n_written:,} personas -> {out_path}")


if __name__ == "__main__":
    main()
