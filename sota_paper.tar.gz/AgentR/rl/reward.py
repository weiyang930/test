"""verl custom reward for the AgentR listwise ranker (GRPO).

Additive RL module: imported only by verl via
`reward.custom_reward_function.path=<this file>` (name=compute_score). It does not
import or modify any MAS / AgentR code.

Output contract (same as SFT/eval): a JSON object whose "ranking" is a full
permutation of the candidate ids. Parsing is STRICT for RL — no repair/fallback —
so the policy is never rewarded for text the eval would have had to repair.

ground_truth (JSON string, built by build_rl_data.py):
  {"positive": "G", "candidate_ids": ["A",...,"J"], "source_order": ["F","I",...]}

Reward (all terms configurable through reward_kwargs):
  score = w_hr1 * 1[rank==1] + w_ndcg * 1/log2(rank+1)
          - fd_penalty * 1[source_top1 == positive and model_top1 != positive]
  invalid output -> invalid_score
"""
from __future__ import annotations

import json
import math
import re

_THINK_RE = re.compile(r"<think>.*?</think>", re.S)
_RANK_RE = re.compile(r'"ranking"\s*:\s*\[(.*?)\]', re.S)
_ID_RE = re.compile(r"""["']([^"']+)["']""")


def parse_ranking(text: str):
    """Return the ranking list or None. Strict: JSON first, then the ranking array only."""
    if text is None:
        return None
    t = _THINK_RE.sub("", text).strip()
    # 1) whole JSON object
    s, e = t.find("{"), t.rfind("}")
    if s != -1 and e > s:
        try:
            obj = json.loads(t[s:e + 1])
            r = obj.get("ranking") if isinstance(obj, dict) else None
            if isinstance(r, list):
                return [str(x).strip() for x in r]
        except Exception:
            pass
    # 2) just the "ranking": [...] array (tolerates trailing junk after the array)
    m = _RANK_RE.search(t)
    if m:
        return [x.strip() for x in _ID_RE.findall(m.group(1))]
    return None


def score_ranking(ranking, gt, w_hr1=1.0, w_ndcg=0.5, fd_penalty=0.0, invalid_score=-1.0):
    pos = gt["positive"]
    cands = gt["candidate_ids"]
    src = gt.get("source_order") or []
    src_top1_correct = bool(src) and src[0] == pos

    valid = (ranking is not None and len(ranking) == len(cands)
             and set(ranking) == set(cands))
    if not valid:
        return {
            "score": float(invalid_score), "valid": 0.0, "hr1": 0.0, "ndcg": 0.0,
            "pos_rank": float(len(cands) + 1), "false_damage": 0.0, "rescue": 0.0,
            "moved_top1": 0.0,
        }
    rank = ranking.index(pos) + 1
    hr1 = 1.0 if rank == 1 else 0.0
    ndcg = 1.0 / math.log2(rank + 1)
    false_damage = 1.0 if (src_top1_correct and rank != 1) else 0.0
    rescue = 1.0 if (src and not src_top1_correct and rank == 1) else 0.0
    moved = 1.0 if (src and ranking[0] != src[0]) else 0.0
    score = w_hr1 * hr1 + w_ndcg * ndcg - fd_penalty * false_damage
    return {
        "score": float(score), "valid": 1.0, "hr1": hr1, "ndcg": ndcg,
        "pos_rank": float(rank), "false_damage": false_damage, "rescue": rescue,
        "moved_top1": moved,
    }


def compute_score(data_source, solution_str, ground_truth, extra_info=None,
                  w_hr1=1.0, w_ndcg=0.5, fd_penalty=0.0, invalid_score=-1.0, **_):
    gt = json.loads(ground_truth) if isinstance(ground_truth, str) else ground_truth
    return score_ranking(parse_ranking(solution_str), gt, w_hr1=float(w_hr1),
                         w_ndcg=float(w_ndcg), fd_penalty=float(fd_penalty),
                         invalid_score=float(invalid_score))


if __name__ == "__main__":  # self-test
    gt = {"positive": "G", "candidate_ids": list("ABCDEFGHIJ"),
          "source_order": list("FICHGAEBDJ")}
    ok = '{"sample_id": "x", "ranking": ["G","F","I","C","H","A","E","B","D","J"]}'
    keep = '{"sample_id": "x", "ranking": ["F","I","C","H","G","A","E","B","D","J"]}'
    bad = '{"ranking": ["G","F","I"]}'
    trunc = '{"sample_id": "x", "ranking": ["G","F","I","C","H","A","E","B","D","J"], "top_reason": "abc'
    for name, s in [("rescue", ok), ("keep", keep), ("bad", bad), ("trunc", trunc)]:
        print(name, compute_score("t", s, json.dumps(gt), fd_penalty=0.5))
    gt2 = dict(gt, positive="F")
    print("false_damage", compute_score("t", ok, json.dumps(gt2), fd_penalty=0.5))
    print("preserve", compute_score("t", keep, json.dumps(gt2), fd_penalty=0.5))
