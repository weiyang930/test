#!/usr/bin/env python
"""Paired comparison of two per-sample eval outputs (RL vs SFT, or vs SASRec source).

Accepts either schema:
  rr : evaluate_ranker.py `*.per_sample.jsonl`  {user_id, sasrec_rank, mas_rank}
  cf : eval_trained_rank   `eval_s*.per_sample.jsonl` {sample_id, positive_rank}  (glob ok)
Reports R@1/3/5, NDCG@1/3/5, MRR, McNemar on HR@1 and paired bootstrap 95% CI + p.

  python compare.py --a <rl files> --b <sft files> [--a_name RL --b_name SFT] [--b_source]
  --b_source : for rr files, use b's `sasrec_rank` (SASRec source) as the baseline.
"""
import argparse
import glob
import json
import math
import random


def load(pattern, use_source=False):
    out = {}
    for f in sorted(glob.glob(pattern)):
        for line in open(f):
            r = json.loads(line)
            key = r.get("user_id") or r["sample_id"].split("__")[0]
            if "mas_rank" in r:
                out[key] = r["sasrec_rank"] if use_source else r["mas_rank"]
            else:
                out[key] = r["positive_rank"]
    return out


def metrics(rank):
    return {"R@1": float(rank <= 1), "R@3": float(rank <= 3), "R@5": float(rank <= 5),
            "N@3": 1 / math.log2(rank + 1) if rank <= 3 else 0.0,
            "N@5": 1 / math.log2(rank + 1) if rank <= 5 else 0.0, "MRR": 1 / rank}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True)
    ap.add_argument("--b", required=True)
    ap.add_argument("--a_name", default="A")
    ap.add_argument("--b_name", default="B")
    ap.add_argument("--b_source", action="store_true")
    ap.add_argument("--B", type=int, default=10000)
    args = ap.parse_args()
    A, Bm = load(args.a), load(args.b, args.b_source)
    keys = sorted(set(A) & set(Bm))
    n = len(keys)
    print(f"n={n} (a={len(A)}, b={len(Bm)})")
    ma = [metrics(A[k]) for k in keys]
    mb = [metrics(Bm[k]) for k in keys]
    rng = random.Random(0)
    idx_sets = [[rng.randrange(n) for _ in range(n)] for _ in range(args.B)]
    print(f"{'metric':<5} {args.a_name:>8} {args.b_name:>8} {'delta':>8}  95%CI              p(two-sided)")
    for m in ["R@1", "R@3", "R@5", "N@3", "N@5", "MRR"]:
        da = [x[m] for x in ma]
        db = [x[m] for x in mb]
        d = [x - y for x, y in zip(da, db)]
        mean = sum(d) / n
        boots = sorted(sum(d[i] for i in ix) / n for ix in idx_sets)
        lo, hi = boots[int(0.025 * args.B)], boots[int(0.975 * args.B)]
        p = 2 * min(sum(b <= 0 for b in boots), sum(b >= 0 for b in boots)) / args.B
        print(f"{m:<5} {sum(da)/n:8.4f} {sum(db)/n:8.4f} {mean:+8.4f}  [{lo:+.4f},{hi:+.4f}]  {min(p,1.0):.4f}")
    b_ = sum(1 for x, y in zip(ma, mb) if x["R@1"] > y["R@1"])
    c_ = sum(1 for x, y in zip(ma, mb) if x["R@1"] < y["R@1"])
    z = (b_ - c_) / math.sqrt(b_ + c_) if b_ + c_ else 0.0
    print(f"McNemar HR@1: {args.a_name}-only={b_} {args.b_name}-only={c_} net={b_-c_} z={z:.2f}")


if __name__ == "__main__":
    main()
