#!/usr/bin/env python3
"""verl GRPO launcher for the AgentR ranker (additive RL module).

Stock verl legacy PPO/GRPO trainer (`main_ppo_v0.TaskRunner` logic) with ONE
compat change applied inside the Ray TaskRunner process: the driver-side sdpa
padding patch in rl/compat/verl_padding_patch.py (flash-attn is
unbuildable for torch 2.11/cu130 on our test nodes). Nothing in verl is modified.
Run with the verl env ($VERL_PY) and rl/ on PYTHONPATH (rl/run_grpo.sh does both).

  python launch_grpo.py --config-path <verl>/verl/trainer/config --config-name ppo_trainer <hydra overrides>
"""
from __future__ import annotations

import os
import socket
import sys


def _build_task_runner():
    import ray
    from omegaconf import OmegaConf
    from verl.trainer.main_ppo_v0 import BaseTaskRunner
    from verl.trainer.ppo.ray_trainer import RayPPOTrainer
    from verl.trainer.ppo.utils import (create_rl_dataset, create_rl_sampler,
                                        need_critic, need_reference_policy)
    from verl.utils.config import omega_conf_to_dataclass, validate_config
    from verl.utils.dataset.rl_dataset import collate_fn
    from verl.workers.config import HFModelConfig

    class RankerTaskRunner(BaseTaskRunner):
        def run(self, config):
            from compat.verl_padding_patch import force_padding_free_forward_off
            force_padding_free_forward_off()
            print(f"[rl_ranker] TaskRunner {socket.gethostname()} pid={os.getpid()} (sdpa patch on)", flush=True)

            OmegaConf.resolve(config)
            actor_rollout_cls, ray_worker_group_cls = self.add_actor_rollout_worker(config)
            self.add_critic_worker(config)
            self.add_reward_model_resource_pool(config)
            self.add_teacher_model_resource_pool(config)
            self.add_ref_policy_worker(config, actor_rollout_cls)
            validate_config(config=config, use_reference_policy=need_reference_policy(config),
                            use_critic=need_critic(config))
            model_config: HFModelConfig = omega_conf_to_dataclass(config.actor_rollout_ref.model)
            tokenizer, processor = model_config.tokenizer, model_config.processor
            resource_pool_manager = self.init_resource_pool_mgr(config)
            train_dataset = create_rl_dataset(config.data.train_files, config.data, tokenizer, processor,
                                              is_train=True, max_samples=config.data.get("train_max_samples", -1))
            val_dataset = create_rl_dataset(config.data.val_files, config.data, tokenizer, processor,
                                            is_train=False, max_samples=config.data.get("val_max_samples", -1))
            train_sampler = create_rl_sampler(config.data, train_dataset)
            trainer = RayPPOTrainer(
                config=config, tokenizer=tokenizer, processor=processor,
                role_worker_mapping=self.role_worker_mapping,
                resource_pool_manager=resource_pool_manager,
                ray_worker_group_cls=ray_worker_group_cls,
                train_dataset=train_dataset, val_dataset=val_dataset,
                collate_fn=collate_fn, train_sampler=train_sampler,
            )
            trainer.init_workers()
            trainer.fit()

    return ray.remote(RankerTaskRunner)


def main() -> int:
    import hydra
    from omegaconf import DictConfig
    from verl.trainer.main_ppo import run_ppo
    from verl.utils.device import auto_set_device

    @hydra.main(config_path=None, config_name=None, version_base=None)
    def _entry(config: DictConfig):
        try:
            auto_set_device(config)
        except Exception:
            pass
        run_ppo(config, _build_task_runner())

    _entry()
    return 0


if __name__ == "__main__":
    sys.exit(main())
