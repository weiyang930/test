"""Source-relative (preserve / rescue / damage) reward for the AgentR ranker GRPO.

Additive: a sibling of reward.py (which stays the `hr_only` baseline and is untouched).
verl entry: reward.custom_reward_function.path=<this file>, name=compute_score,
reward_kwargs.reward_type in {hr_only, source_relative, source_relative_ndcg}.

Notation: K candidates, s = source (SASRec) rank of the positive, m = model rank of the
positive, g(r) = 1/log2(r+1) (single-relevant-item NDCG at rank r).

  hr_only              : w_hr1 * 1[m==1] + w_ndcg * g(m)                (== reward.py)
  source_relative      : alpha * preserve + beta * rescue - gamma * false_damage
      preserve     = 1[s==1 and m==1]
      false_damage = 1[s==1 and m!=1]
      rescue       = 1[s>1] * (g(m) - g(s)) / (1 - g(s))
                     -> 1 when the positive is lifted to rank 1, a fraction for a partial lift,
                        0 if left where the source put it, negative if pushed down.
  source_relative_ndcg : source_relative + lam * (g(m) - g(s))           (NDCG gain vs source)
  invalid output       : invalid_score (all modes)

GRPO caveats (see develop/2026-10-01_rl_preserve_correct_reward.md):
  * any per-prompt constant (e.g. the -g(s) of NDCG gain) cancels against the group mean;
  * with norm_adv_by_std_in_grpo=True, preserve/damage on s==1 prompts are an affine map of
    hr1 and give the SAME advantages as hr_only. The weights alpha/beta/gamma only change the
    gradient mass between preserve- and rescue-type prompts when std-normalisation is OFF.
"""
from __future__ import annotations

import json
import math

from reward import parse_ranking  # same strict parser as the baseline

REWARD_TYPES = ("hr_only", "source_relative", "source_relative_ndcg")


def _g(r: int) -> float:
    return 1.0 / math.log2(r + 1)


def score_ranking_sr(ranking, gt, reward_type="source_relative", alpha=1.0, beta=2.0, gamma=1.0,
                     lam=0.5, w_hr1=1.0, w_ndcg=0.5, invalid_score=-1.0):
    if reward_type not in REWARD_TYPES:
        raise ValueError(f"reward_type must be one of {REWARD_TYPES}, got {reward_type!r}")
    pos, cands = gt["positive"], gt["candidate_ids"]
    src = gt.get("source_order") or []
    valid = (ranking is not None and len(ranking) == len(cands) and set(ranking) == set(cands))
    base = {"valid": 0.0, "hr1": 0.0, "ndcg": 0.0, "pos_rank": float(len(cands) + 1),
            "preserve": 0.0, "false_damage": 0.0, "rescue": 0.0, "rescue_score": 0.0,
            "moved_top1": 0.0, "ndcg_gain": 0.0, "src_correct": 0.0}
    if not valid:
        return {"score": float(invalid_score), **base}
    m = ranking.index(pos) + 1
    hr1 = 1.0 if m == 1 else 0.0
    out = dict(base, valid=1.0, hr1=hr1, ndcg=_g(m), pos_rank=float(m))
    if src:
        s = src.index(pos) + 1
        out["src_correct"] = 1.0 if s == 1 else 0.0
        out["moved_top1"] = 1.0 if ranking[0] != src[0] else 0.0
        out["ndcg_gain"] = _g(m) - _g(s)
        if s == 1:
            out["preserve"], out["false_damage"] = hr1, 1.0 - hr1
        else:
            out["rescue"] = hr1                                   # binary, for logging
            out["rescue_score"] = (_g(m) - _g(s)) / (1.0 - _g(s))  # graded
    if reward_type == "hr_only" or not src:
        # no source order (e.g. cf_hard): source-relative terms are undefined -> fall back
        score = w_hr1 * hr1 + w_ndcg * out["ndcg"]
        if reward_type == "source_relative_ndcg" and not src:
            score = w_hr1 * hr1 + lam * out["ndcg"]
    else:
        score = alpha * out["preserve"] + beta * out["rescue_score"] - gamma * out["false_damage"]
        if reward_type == "source_relative_ndcg":
            score += lam * out["ndcg_gain"]
    out["score"] = float(score)
    return out


def compute_score(data_source, solution_str, ground_truth, extra_info=None,
                  reward_type="source_relative", alpha=1.0, beta=2.0, gamma=1.0, lam=0.5,
                  w_hr1=1.0, w_ndcg=0.5, invalid_score=-1.0, **_):
    gt = json.loads(ground_truth) if isinstance(ground_truth, str) else ground_truth
    return score_ranking_sr(parse_ranking(solution_str), gt, reward_type=str(reward_type),
                            alpha=float(alpha), beta=float(beta), gamma=float(gamma), lam=float(lam),
                            w_hr1=float(w_hr1), w_ndcg=float(w_ndcg), invalid_score=float(invalid_score))


if __name__ == "__main__":  # self-test
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from reward import compute_score as base_score

    C = list("ABCDEFGHIJ")
    src = list("FICHGAEBDJ")
    J = lambda r: json.dumps({"sample_id": "x", "ranking": r})
    cases = {
        "preserve":        ("F", src),
        "false_damage":    ("F", ["I", "F"] + src[2:]),
        "full_rescue":     ("H", ["H"] + [c for c in src if c != "H"]),
        "partial_rescue":  ("H", ["F", "H", "I", "C", "G", "A", "E", "B", "D", "J"]),
        "stay_src_wrong":  ("H", src),
        "push_down":       ("H", ["I", "F", "C", "G", "H", "A", "E", "B", "D", "J"]),
        "invalid":         ("F", ["F", "I"]),
    }
    for name, (pos, r) in cases.items():
        gt = json.dumps({"positive": pos, "candidate_ids": C, "source_order": src})
        row = {t: round(compute_score("t", J(r), gt, reward_type=t)["score"], 4) for t in REWARD_TYPES}
        b = base_score("t", J(r), gt)["score"]
        assert abs(row["hr_only"] - round(b, 4)) < 1e-9, (row, b)
        print(f"{name:<15} {row}")
    gt_cf = json.dumps({"positive": "E", "candidate_ids": C, "source_order": []})
    print("cf_hard(no src) ", {t: round(compute_score("t", J(C), gt_cf, reward_type=t)["score"], 4) for t in REWARD_TYPES})
