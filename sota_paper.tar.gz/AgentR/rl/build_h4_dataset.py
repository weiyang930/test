#!/usr/bin/env python
"""Write recbole_baselines/dataset/<rb>_h4/<rb>_h4.inter = train_items[:-2] per user.

Usage: python rl/build_h4_dataset.py <recbole_name>

Same construction as cds_h4 (verified: cds_h4 == cds train_items[:-2] for all 9198 users).
RecBole LS(valid_and_test) then trains SASRec on train_items[:-4], so the last 4 train
items are out-of-sample targets for oos_recall.py --windows holdout --H 4.
"""
import json
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
ds = sys.argv[1]
out = PROJ / f"recbole_baselines/dataset/{ds}_h4/{ds}_h4.inter"
out.parent.mkdir(parents=True, exist_ok=True)
n = 0
with open(out, "w") as f:
    f.write("user_id:token\titem_id:token\ttimestamp:float\n")
    for line in open(PROJ / f"recbole_baselines/dataset/{ds}_splits.jsonl"):
        u = json.loads(line)
        for t, it in enumerate(u["train_items"][:-2]):
            f.write(f"{u['user_id']}\t{it}\t{float(t)}\n")
            n += 1
print(ds, "rows", n, "->", out)
