#!/usr/bin/env python
"""Compact per-run training summary from verl's tensorboard logs (run with the verl env, needs tensorboard).

  python rl/tb_summary.py outputs/cd/rl/runs/srA2 [more run dirs] [--every 5]
(rl/run_grpo.sh writes each run's tensorboard events to <run dir>/tb)
"""
import argparse
from pathlib import Path

from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

KEYS = [("critic/score/mean", "rew"), ("actor/entropy", "ent"), ("actor/kl_loss", "kl"),
        ("actor/grad_norm", "gn"), ("response_length/mean", "rlen"), ("timing_s/step", "s/step")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+", help="run dirs (containing tb/)")
    ap.add_argument("--every", type=int, default=5)
    a = ap.parse_args()
    for run in a.runs:
        ea = EventAccumulator(str(Path(run) / "tb"), size_guidance={"scalars": 0})
        ea.Reload()
        tags = set(ea.Tags()["scalars"])
        series = {short: {e.step: e.value for e in ea.Scalars(k)} for k, short in KEYS if k in tags}
        steps = sorted(series.get("rew", {}))
        print(f"== {run}: {len(steps)} steps")
        # moving average of training reward over windows of `every`
        for i in range(0, len(steps), a.every):
            w = steps[i:i + a.every]
            row = " ".join(f"{s}={sum(series[s][x] for x in w)/len(w):.4f}" for s in series if all(x in series[s] for x in w))
            print(f"  steps {w[0]:>3}-{w[-1]:<3} {row}")
        for t in sorted(x for x in tags if x.startswith("val-")):
            if any(k in t for k in ("reward/mean", "hr1", "false_damage", "rescue", "moved_top1", "valid")):
                print(f"  {t.split('/',2)[-1]:<30} " + " ".join(f"{e.step}:{e.value:.4f}" for e in ea.Scalars(t)))


if __name__ == "__main__":
    main()
