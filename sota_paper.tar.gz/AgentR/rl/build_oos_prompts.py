#!/usr/bin/env python
"""OOS RL prompts for real_retrieved (run in the MAS env; read-only imports of eval code).

Mirrors how the TEST prompts are made, so RL trains on the test distribution:
  recall rows  : oos_recall.py output (out-of-sample SASRec top-10, hit-only)
  memory       : cf_hard trace of the SAME window (test uses cf_hard test-trace memory,
                 see recbole_baselines/scripts/build_recall_intersect.py)
  memory field : user_memory_before of the cf_hard trace (leak-free there: one window per
                 user per split, no later window of the same user in the batch)
  rows         : recall_eval_input.jsonl schema -> evaluate_ranker.build_contexts
  prompt       : source_prompt.build_source_conditioned_prompt (identical to eval)

Writes <out_dir>/{train,val}.parquet (verl) + recall_input.jsonl (eval-format rows).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
import sys
from pathlib import Path

import pandas as pd

PROJ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJ))
sys.path.insert(0, str(PROJ / "source_conditioned"))

from reflective_mas_rec.config import load_config  # noqa: E402
from reflective_mas_rec.data.dataset import Dataset  # noqa: E402
from common import dataset as ds_paths, load_items  # noqa: E402
from evaluate_ranker import build_contexts  # noqa: E402
from source_prompt import build_source_conditioned_prompt  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cd")
    ap.add_argument("--config", required=True, help="outputs/<ds>/configs/recall_eval.yaml")
    ap.add_argument("--recall", required=True, help="oos_recall.py output")
    ap.add_argument("--trace", required=True, help="cf_hard trace with memory for these windows")
    ap.add_argument("--window_tag", default="valid")
    ap.add_argument("--data_source", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--val_frac", type=float, default=0.12)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    # memory keyed by (user, target item): one cf_hard trace per window.
    # Only windows we need (recall hits) are parsed; trace files can be 10+ GB.
    need = set()
    for line in open(args.recall, encoding="utf-8"):
        r = json.loads(line)
        if r["pos_rank"] > 0:
            need.add((r["user_id"], r["target"]))
    need_users = {u for u, _ in need}
    uid_re = re.compile(r'"user_id":\s*"([^"]+)"')
    mem = {}
    for tp in args.trace.split(","):
        for line in open(tp, encoding="utf-8"):
            mu = uid_re.search(line, 0, 4096)
            if mu is None or mu.group(1) not in need_users:
                continue
            t = json.loads(line)
            if (t["user_id"], t["positive_item"]) not in need:
                continue
            m = t.get("user_memory_before") or t.get("user_memory_after") or {}
            mem[(t["user_id"], t["positive_item"])] = m

    rows = []
    for line in open(args.recall, encoding="utf-8"):
        r = json.loads(line)
        key = (r["user_id"], r["target"])
        if r["pos_rank"] <= 0 or key not in mem:
            continue
        rows.append({
            "user_id": r["user_id"], "sample_id": f"{r['user_id']}__recall__{r.get('window', args.window_tag)}",
            "positive_item": r["target"], "candidate_note_ids": r["topn_items"],
            "user_memory": mem[key], "history_items": r["history_items"],
            "sasrec_positive_rank": r["pos_rank"],
        })
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "recall_input.jsonl", "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    cfg = load_config(args.config)
    dataset = Dataset.load(cfg)
    items_meta = load_items(ds_paths(args.dataset).items_parquet)
    ctxs = build_contexts(rows, dataset, cfg.item.max_content_chars, items_meta)

    recs = []
    for ctx in ctxs:
        system, prompt = build_source_conditioned_prompt(
            sample_id=ctx["sample_id"], user_memory=ctx["user_memory"], candidates=ctx["candidates"],
            history_titles=ctx["hist_titles"], history_brands=ctx["hist_brands"], history_cats=ctx["hist_cats"],
        )
        cands = [c["candidate_id"] for c in ctx["candidates"]]
        src = [c["candidate_id"] for c in sorted(ctx["candidates"], key=lambda c: c["sasrec_rank"])]
        pos = ctx["positive_cid"]
        gt = {"positive": pos, "candidate_ids": cands, "source_order": src}
        recs.append({
            "data_source": args.data_source,
            "prompt": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            "ability": "rec_rank",
            "reward_model": {"style": "rule", "ground_truth": json.dumps(gt)},
            "extra_info": {"index": len(recs), "sample_id": ctx["sample_id"], "user_id": ctx["user_id"],
                           "kind": "preserve" if src[0] == pos else "correct"},
        })

    def is_val(u):
        return int(hashlib.md5(f"oosval{args.seed}::{u}".encode()).hexdigest()[:8], 16) / 0xFFFFFFFF < args.val_frac
    tr = [r for r in recs if not is_val(r["extra_info"]["user_id"])]
    va = [r for r in recs if is_val(r["extra_info"]["user_id"])]
    random.Random(args.seed).shuffle(tr)
    pd.DataFrame(tr).to_parquet(out / "train.parquet", index=False)
    pd.DataFrame(va).to_parquet(out / "val.parquet", index=False)
    from collections import Counter
    stats = {"n_rows": len(rows), "n_train": len(tr), "n_val": len(va),
             "train_kinds": dict(Counter(r["extra_info"]["kind"] for r in tr)),
             "val_kinds": dict(Counter(r["extra_info"]["kind"] for r in va))}
    (out / "stats.json").write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
