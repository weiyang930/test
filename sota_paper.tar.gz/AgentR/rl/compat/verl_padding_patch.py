"""Force verl's legacy trainer onto the padded (sdpa) forward path.

Background
----------
verl v0.9.0's ``RayPPOTrainer`` always rewrites each batch to a padding-free
layout with ``left_right_2_no_padding`` and then calls ``compute_log_prob`` /
``update_actor``. Inside the FSDP engine the forward reads a per-batch
non-tensor flag ``use_remove_padding`` (defaulting to ``True``). When it is
``True`` the engine feeds a single packed sequence with ``attention_mask=None``
and relies on flash-attention *varlen* CUDA kernels to keep sequences from
attending across each other.

flash-attn is unbuildable on this box, so we cannot take the varlen path. verl
*does* implement a fully-correct alternative: when ``use_remove_padding`` is
``False`` the engine re-pads the nested batch and builds a block-diagonal
``attention_mask`` (``build_attention_mask_from_nested``), which sdpa honours
exactly. That branch needs no flash kernels.

The flag is never written into the batch by verl, so the engine always sees the
default ``True``. This module stamps ``use_remove_padding=False`` onto every
batch right after ``left_right_2_no_padding`` runs, selecting the correct
sdpa branch. It is a *driver-side* monkey-patch (the trainer process only); it
does not modify any verl source file. The non-tensor flag rides along the
existing ``compute_log_prob`` RPC to the workers.

This is a fidelity-neutral change: block-diagonal sdpa and flash varlen compute
the same attention; only kernel/perf differ.
"""

from __future__ import annotations

import functools

_PATCHED = False


def force_padding_free_forward_off() -> bool:
    """Patch ``ray_trainer.left_right_2_no_padding`` to tag batches sdpa-safe.

    Returns True if the patch was applied (or already active). Raises loudly if
    the expected verl seam is missing, so drift fails fast instead of silently
    running the flash-only path.
    """
    global _PATCHED
    if _PATCHED:
        return True

    from verl.trainer.ppo import ray_trainer
    from verl.utils import tensordict_utils as tu

    if not hasattr(ray_trainer, "left_right_2_no_padding"):
        raise RuntimeError(
            "verl.trainer.ppo.ray_trainer.left_right_2_no_padding not found — verl "
            "layout changed. The sdpa-forcing patch cannot be applied; "
            "refusing to run on the flash-only path. Re-verify against the pinned SHA."
        )

    original = ray_trainer.left_right_2_no_padding

    @functools.wraps(original)
    def _patched(batch_td):
        out = original(batch_td)
        # Select verl's padded + block-diagonal-mask forward (sdpa-correct, no
        # flash varlen kernel). Flag propagates to workers via the RPC payload.
        tu.assign_non_tensor(out, use_remove_padding=False)
        return out

    _patched.__agentr_sdpa_patch__ = True  # type: ignore[attr-defined]
    ray_trainer.left_right_2_no_padding = _patched
    _PATCHED = True
    return True
