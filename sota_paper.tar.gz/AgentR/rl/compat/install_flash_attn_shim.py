#!/usr/bin/env python3
"""Install compatibility shims required to run verl on this box.

Why this exists
---------------
verl v0.9.0's legacy trainer (``RayPPOTrainer``) unconditionally converts every
training batch to a padding-free layout via
``verl.workers.utils.padding.left_right_2_no_padding``, which imports
``flash_attn.bert_padding`` (``unpad_input`` / ``index_first_axis`` / ...).

flash-attn cannot be built on this machine: the CUDA *toolkit* is 12.9 while
torch was compiled against CUDA 13.0, so ``pip install flash-attn`` fails the
``_check_cuda_version`` guard, and there is no prebuilt wheel for
torch 2.11 + cu130.

However, the functions verl actually imports from ``flash_attn.bert_padding``
(``unpad_input``, ``pad_input``, ``index_first_axis``, ``rearrange``) are
**pure-PyTorch padding utilities** — they contain no CUDA attention kernels.
This installer writes a small ``flash_attn`` package into site-packages that
provides *exactly* those genuine implementations and nothing else.

Honesty / safety guarantees
---------------------------
* We do NOT fake the flash-attention CUDA kernels. Any attempt to import a
  kernel symbol (``flash_attn_func``, ``flash_attn_varlen_func``, ...) raises a
  loud ``ImportError`` pointing back here.
* ``__version__`` is deliberately set to ``"1.0.0"`` (< 2.1.0) so that
  HuggingFace's ``is_flash_attn_2_available()`` returns False and transformers
  never selects a flash-attention-2 code path by accident. Our launches force
  ``attn_implementation=sdpa`` anyway.
* If a real, importable ``flash_attn`` is already present, this script refuses
  to overwrite it and exits 0.

Run once per verl env:  python rl/compat/install_flash_attn_shim.py
"""

from __future__ import annotations

import importlib.util
import site
import sys
from pathlib import Path

_BERT_PADDING_SRC = '''\
"""Pure-PyTorch re-implementations of flash_attn.bert_padding utilities.

These are the standard padding<->unpadding helpers (no CUDA kernels). Installed
by rl/compat/install_flash_attn_shim.py because flash-attn cannot be
built on this box (CUDA toolkit 12.9 vs torch cu130). Semantics match
flash_attn.bert_padding exactly for the entry points verl imports.
"""

import torch
import torch.nn.functional as F
from einops import rearrange, repeat


class IndexFirstAxis(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input, indices):
        ctx.save_for_backward(indices)
        assert input.ndim >= 2
        ctx.first_axis_dim, other_shape = input.shape[0], input.shape[1:]
        second_dim = other_shape.numel()
        return torch.gather(
            rearrange(input, "b ... -> b (...)"),
            0,
            repeat(indices, "z -> z d", d=second_dim),
        ).reshape(-1, *other_shape)

    @staticmethod
    def backward(ctx, grad_output):
        (indices,) = ctx.saved_tensors
        assert grad_output.ndim >= 2
        other_shape = grad_output.shape[1:]
        grad_output = rearrange(grad_output, "b ... -> b (...)")
        grad_input = torch.zeros(
            [ctx.first_axis_dim, grad_output.shape[1]],
            device=grad_output.device,
            dtype=grad_output.dtype,
        )
        grad_input.scatter_(
            0, repeat(indices, "z -> z d", d=grad_output.shape[1]), grad_output
        )
        return grad_input.reshape(ctx.first_axis_dim, *other_shape), None


index_first_axis = IndexFirstAxis.apply


class IndexPutFirstAxis(torch.autograd.Function):
    @staticmethod
    def forward(ctx, values, indices, first_axis_dim):
        ctx.save_for_backward(indices)
        assert indices.ndim == 1
        assert values.ndim >= 2
        output = torch.zeros(
            first_axis_dim, *values.shape[1:], device=values.device, dtype=values.dtype
        )
        output[indices] = values
        return output

    @staticmethod
    def backward(ctx, grad_output):
        (indices,) = ctx.saved_tensors
        grad_values = grad_output[indices]
        return grad_values, None, None


index_put_first_axis = IndexPutFirstAxis.apply


def unpad_input(hidden_states, attention_mask, unused_mask=None):
    """Remove padding, returning (unpadded, indices, cu_seqlens, max_seqlen, used_seqlens)."""
    all_masks = (attention_mask + unused_mask) if unused_mask is not None else attention_mask
    seqlens_in_batch = all_masks.sum(dim=-1, dtype=torch.int32)
    used_seqlens_in_batch = attention_mask.sum(dim=-1, dtype=torch.int32)
    indices = torch.nonzero(all_masks.flatten(), as_tuple=False).flatten()
    max_seqlen_in_batch = seqlens_in_batch.max().item()
    cu_seqlens = F.pad(torch.cumsum(seqlens_in_batch, dim=0, dtype=torch.int32), (1, 0))
    return (
        index_first_axis(rearrange(hidden_states, "b s ... -> (b s) ..."), indices),
        indices,
        cu_seqlens,
        max_seqlen_in_batch,
        used_seqlens_in_batch,
    )


def pad_input(hidden_states, indices, batch, seqlen):
    """Inverse of unpad_input: scatter unpadded rows back into a (batch, seqlen, ...) tensor."""
    output = index_put_first_axis(hidden_states, indices, batch * seqlen)
    return rearrange(output, "(b s) ... -> b s ...", b=batch)


__all__ = ["index_first_axis", "pad_input", "rearrange", "unpad_input"]
'''

_INIT_SRC = '''\
"""compatibility shim for flash_attn (pure-PyTorch bert_padding only).

This is NOT the real flash-attention package. flash-attn cannot be built on this
box (CUDA toolkit 12.9 vs torch cu130). Only the pure-PyTorch padding utilities
that verl imports from flash_attn.bert_padding are provided here.

__version__ is intentionally < 2.1.0 so transformers.is_flash_attn_2_available()
returns False and no flash-attention-2 CUDA code path is ever selected.
"""

__version__ = "1.0.0"
__agentr_shim__ = True

_KERNEL_SYMBOLS = {
    "flash_attn_func",
    "flash_attn_varlen_func",
    "flash_attn_qkvpacked_func",
    "flash_attn_kvpacked_func",
    "flash_attn_varlen_qkvpacked_func",
    "flash_attn_varlen_kvpacked_func",
    "flash_attn_with_kvcache",
}


def __getattr__(name):
    if name in _KERNEL_SYMBOLS:
        raise ImportError(
            f"flash_attn.{name} is a CUDA kernel that is NOT provided by the "
            "pure-PyTorch shim. flash-attn is unbuildable on this box (CUDA toolkit "
            "12.9 vs torch cu130). Use attn_implementation=sdpa. See "
            "rl/compat/install_flash_attn_shim.py."
        )
    raise AttributeError(f"module 'flash_attn' has no attribute {name!r} (shim)")
'''


def _real_flash_attn_present() -> bool:
    spec = importlib.util.find_spec("flash_attn")
    if spec is None:
        return False
    # A shim we previously wrote is not "real".
    origin = getattr(spec, "origin", "") or ""
    try:
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
        return not getattr(mod, "__agentr_shim__", False)
    except Exception:
        # If it imports at all as a non-shim, treat as real; otherwise not.
        return "site-packages/flash_attn" in origin and "__agentr_shim__" not in origin


def main() -> int:
    if _real_flash_attn_present():
        print("[shim] a real flash_attn is importable — leaving it untouched.")
        return 0

    site_pkgs = Path(site.getsitepackages()[0])
    pkg_dir = site_pkgs / "flash_attn"
    pkg_dir.mkdir(parents=True, exist_ok=True)
    (pkg_dir / "__init__.py").write_text(_INIT_SRC)
    (pkg_dir / "bert_padding.py").write_text(_BERT_PADDING_SRC)
    print(f"[shim] wrote pure-PyTorch flash_attn.bert_padding shim to {pkg_dir}")

    # Sanity check: import and exercise the round-trip.
    import torch  # noqa: PLC0415

    sys.path.insert(0, str(site_pkgs))
    from flash_attn.bert_padding import pad_input, unpad_input  # noqa: PLC0415

    x = torch.arange(2 * 3, dtype=torch.float32).reshape(2, 3, 1)
    mask = torch.tensor([[1, 1, 0], [1, 0, 0]])
    unpadded, indices, cu, *_ = unpad_input(x, mask)
    assert unpadded.shape[0] == 3, unpadded.shape
    repadded = pad_input(unpadded, indices, 2, 3)
    assert torch.equal(repadded[mask.bool()], x[mask.bool()])
    print("[shim] round-trip pad/unpad verified OK.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
