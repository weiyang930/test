"""Per-run isolation of verl's colocated weight-sync socket (additive; nothing in verl edited).

verl names the actor->vLLM weight-transfer socket
  /tmp/rl-colocate-zmq-{ray job id}-replica-{r}-rank-{k}.sock
on both sides (vllm_rollout.py sender, vllm_rollout/utils.py receiver via VERL_RAY_JOB_ID).
Each run starts its own local Ray cluster, whose first driver always gets job id 01000000,
so two runs on one node share the socket and one dies in rebuild_ipc
("TypeError: 'str' object is not callable", srA2 2026-10-01).

Installed as a Ray `worker_process_setup_hook` (runs in every Ray worker process) by
run_grpo_sr.sh: suffixes RuntimeContext.get_job_id() with $RL_RANKER_RUN_TAG.
"""
import os


def patch_job_id():
    tag = os.environ.get("RL_RANKER_RUN_TAG")
    if not tag:
        return
    import ray.runtime_context as rc
    if getattr(rc.RuntimeContext.get_job_id, "_rl_ranker_tagged", False):
        return
    orig = rc.RuntimeContext.get_job_id

    def get_job_id(self):
        return f"{orig(self)}-{tag}"

    get_job_id._rl_ranker_tagged = True
    rc.RuntimeContext.get_job_id = get_job_id
