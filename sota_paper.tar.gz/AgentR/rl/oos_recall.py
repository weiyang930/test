#!/usr/bin/env python
"""Out-of-sample (OOS) SASRec recall for RL windows (run in the RecBole env).

Mirrors recbole_baselines/scripts/export_sasrec_topn_recall.py exactly (same
checkpoint loading, same full_sort_predict, mask = history items), but for windows
whose TARGET the SASRec checkpoint never trained on:

  --windows holdout: with a SASRec trained on train_items[:-H] (cds_h4), windows whose
                    target is one of the last H train items (prefix = items before it).
  --windows valid : prefix = train_items, target = valid_item. With RecBole
                    LS(valid_and_test), the main checkpoint trains on train_items
                    only, so the valid item is out-of-sample (like test).

Output jsonl: {user_id, window, history_items, target, topn_items[:top_n], pos_rank}
"""
from __future__ import annotations

import argparse
import glob
import json

import numpy as np
import torch
from recbole.data import create_dataset
from recbole.data.interaction import Interaction
from recbole.utils import get_model, init_seed


def load(ckpt_path, device):
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    config = ckpt["config"]
    config["device"] = device
    init_seed(config["seed"], config["reproducibility"])
    ds = create_dataset(config)
    model = get_model(config["model"])(config, ds).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.load_other_parameter(ckpt.get("other_parameter"))
    model.eval()
    return model, ds, config


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--windows", default="valid", choices=["valid", "holdout"])
    ap.add_argument("--H", type=int, default=4, help="holdout: last H train items are out-of-sample targets")
    ap.add_argument("--top_n", type=int, default=10)
    ap.add_argument("--out", required=True)
    ap.add_argument("--batch_size", type=int, default=512)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, ds, config = load(sorted(glob.glob(args.checkpoint))[-1], device)
    iid = config["ITEM_ID_FIELD"]
    seq_f, len_f = getattr(model, "ITEM_SEQ"), getattr(model, "ITEM_SEQ_LEN")
    max_len = int(config["MAX_ITEM_LIST_LENGTH"])
    id2tok = ds.field2id_token[iid]
    tok2id = {t: i for i, t in enumerate(id2tok)}

    windows = []
    for line in open(args.splits, encoding="utf-8"):
        if not line.strip():
            continue
        u = json.loads(line)
        tr = list(u["train_items"])
        if args.windows == "valid":
            windows.append((u["user_id"], "valid", tr, u["valid_item"]))
        elif len(tr) >= args.H + 3:   # same filter as the cds_h4 dataset build
            for j in range(len(tr) - args.H, len(tr)):
                windows.append((u["user_id"], f"h{j}", tr[:j], tr[j]))

    out = open(args.out, "w", encoding="utf-8")
    n = hit = 0
    for s in range(0, len(windows), args.batch_size):
        chunk = windows[s:s + args.batch_size]
        seqs, lens, forb = [], [], []
        for _, _, hist, _ in chunk:
            ids = [tok2id[t] for t in hist if t in tok2id][-max_len:]
            seqs.append(ids + [0] * (max_len - len(ids)))
            lens.append(max(len(ids), 1))
            forb.append(set(ids))
        inter = Interaction({seq_f: torch.tensor(seqs, device=device), len_f: torch.tensor(lens, device=device)})
        scores = model.full_sort_predict(inter.to(device)).view(len(chunk), -1).cpu().numpy()
        for row, (uid, win, hist, tgt) in enumerate(chunk):
            top = []
            for i in np.argsort(-scores[row]):
                if i == 0 or i in forb[row]:
                    continue
                top.append(int(i))
                if len(top) >= args.top_n:
                    break
            toks = [id2tok[i] for i in top]
            pr = toks.index(tgt) + 1 if tgt in toks else -1
            hit += pr > 0
            n += 1
            out.write(json.dumps({"user_id": uid, "window": win, "history_items": hist, "target": tgt,
                                  "topn_items": toks, "pos_rank": pr}) + "\n")
    out.close()
    print(f"wrote {n} windows, recall@{args.top_n} hit={hit} ({hit / max(n, 1):.4f}) -> {args.out}")


if __name__ == "__main__":
    main()
