#!/usr/bin/env bash
# GRPO for the source-conditioned ranker (verl 0.9, single node).
# Defaults = the "srA2" recipe that beat SFT on CD (+3.6pt R@1) / Kindle / Grocery:
#   reward source_relative_ndcg (alpha1 beta2 gamma1 lam0.5), norm_adv_by_std_in_grpo=false,
#   BS64 x G8, T0.7, lr 5e-7, low_var_kl 0.05 to the SFT ref, clip_ratio_high 0.28,
#   200 steps, val every 10, save every 20; pre-registered checkpoint = step 100.
#
#   NAME=srA2 DATA=outputs/cd/rl/data/oosall MODEL=outputs/cd/sc/model/merged_model \
#     OUT=outputs/cd/rl/runs/srA2 GPUS=0,1,2,3 bash rl/run_grpo.sh [extra hydra overrides...]
#
# Knobs (env): REWARD_TYPE (hr_only|source_relative|source_relative_ndcg), STD_NORM (true|false),
#   ALPHA BETA GAMMA LAM W_HR1 W_NDCG, NGPU STEPS BS N LR KL TEMP CLIP_HIGH MAX_PROMPT MAX_RESP
#   GPU_MEM PPO_MICRO LOGP_MICRO MINI SAVE_FREQ TEST_FREQ OFFLOAD (true|false).
#   On 8xH100 (80GB) use: GPU_MEM=0.35 LOGP_MICRO=4 PPO_MICRO=2.
set -euo pipefail
RL=$(cd "$(dirname "$0")" && pwd)
ROOT=$(dirname "$RL")
source "$ROOT/env.sh"
cd "$ROOT"

NAME=${NAME:?set NAME}
DATA=${DATA:?set DATA dir with train/val.parquet}
MODEL=${MODEL:?set MODEL (HF dir of the SFT ranker)}
OUT=${OUT:?set OUT run dir}
REWARD_TYPE=${REWARD_TYPE:-source_relative_ndcg}
STD_NORM=${STD_NORM:-false}
case "$REWARD_TYPE" in hr_only|source_relative|source_relative_ndcg) ;; *) echo "bad REWARD_TYPE $REWARD_TYPE" >&2; exit 2;; esac

export PATH="$(dirname "$VERL_PY"):$PATH"     # vLLM torch.compile needs ninja on PATH
export PYTHONPATH="$RL:${PYTHONPATH:-}"        # compat.verl_padding_patch, zmq_iso, reward imports
unset ROCR_VISIBLE_DEVICES HIP_VISIBLE_DEVICES 2>/dev/null || true   # some container runtimes set these and confuse ray
export TOKENIZERS_PARALLELISM=false VLLM_LOGGING_LEVEL=WARNING
[ -n "${GPUS:-}" ] && export CUDA_VISIBLE_DEVICES=$GPUS
NGPU=${NGPU:-$(echo "${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}" | tr ',' '\n' | wc -l)}
# checkpoint saves (~90 GB) can trip Ray's gRPC keepalive -> ActorUnavailableError; relax it
export RAY_grpc_client_keepalive_time_ms=${RAY_grpc_client_keepalive_time_ms:-600000}
export RAY_grpc_client_keepalive_timeout_ms=${RAY_grpc_client_keepalive_timeout_ms:-600000}
export RAY_health_check_timeout_ms=${RAY_health_check_timeout_ms:-120000}
export RAY_health_check_failure_threshold=${RAY_health_check_failure_threshold:-20}
# per-run weight-sync socket (zmq_iso.py) so several runs can share one node
export RL_RANKER_RUN_TAG=$NAME

mkdir -p "$OUT"
OUT=$(cd "$OUT" && pwd)
export TENSORBOARD_DIR="$OUT/tb"
export RAY_TMPDIR="$RAY_TMP_ROOT/$(echo "$NAME" | md5sum | cut -c1-8)"   # ray adds ~64 chars of socket path
[ ${#RAY_TMPDIR} -le 40 ] || { echo "RAY_TMP_ROOT too long for AF_UNIX sockets: $RAY_TMPDIR" >&2; exit 2; }
mkdir -p "$RAY_TMPDIR"

"$VERL_PY" "$RL/compat/install_flash_attn_shim.py" >/dev/null 2>&1 || true
VERL_CFG=$("$VERL_PY" -c "import os, verl; print(os.path.join(os.path.dirname(verl.__file__), 'trainer', 'config'))")
K=reward.custom_reward_function.reward_kwargs

"$VERL_PY" "$RL/launch_grpo.py" \
  --config-path "$VERL_CFG" --config-name ppo_trainer \
  data.train_files="$DATA/train.parquet" \
  data.val_files="$DATA/val.parquet" \
  data.train_batch_size=${BS:-64} \
  data.max_prompt_length=${MAX_PROMPT:-4096} \
  data.max_response_length=${MAX_RESP:-128} \
  data.filter_overlong_prompts=true \
  data.truncation=error \
  +data.apply_chat_template_kwargs.enable_thinking=false \
  actor_rollout_ref.model.path="$MODEL" \
  +actor_rollout_ref.model.override_config.attn_implementation=sdpa \
  actor_rollout_ref.model.use_remove_padding=false \
  actor_rollout_ref.model.enable_gradient_checkpointing=true \
  actor_rollout_ref.actor.optim.lr=${LR:-5e-7} \
  actor_rollout_ref.actor.ppo_mini_batch_size=${MINI:-32} \
  actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=${PPO_MICRO:-4} \
  actor_rollout_ref.actor.use_kl_loss=true \
  actor_rollout_ref.actor.kl_loss_coef=${KL:-0.05} \
  actor_rollout_ref.actor.kl_loss_type=low_var_kl \
  actor_rollout_ref.actor.entropy_coeff=0 \
  actor_rollout_ref.actor.clip_ratio_high=${CLIP_HIGH:-0.28} \
  actor_rollout_ref.actor.fsdp_config.param_offload=${OFFLOAD:-false} \
  actor_rollout_ref.actor.fsdp_config.optimizer_offload=${OFFLOAD:-false} \
  actor_rollout_ref.ref.fsdp_config.param_offload=true \
  actor_rollout_ref.rollout.name=vllm \
  actor_rollout_ref.rollout.n=${N:-8} \
  actor_rollout_ref.rollout.temperature=${TEMP:-0.7} \
  actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
  actor_rollout_ref.rollout.gpu_memory_utilization=${GPU_MEM:-0.45} \
  actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=${LOGP_MICRO:-8} \
  actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=${LOGP_MICRO:-8} \
  algorithm.adv_estimator=grpo \
  algorithm.norm_adv_by_std_in_grpo=$STD_NORM \
  algorithm.use_kl_in_reward=false \
  algorithm.filter_groups.enable=false \
  reward.custom_reward_function.path="$RL/reward_sr.py" \
  reward.custom_reward_function.name=compute_score \
  +$K.reward_type=$REWARD_TYPE \
  +$K.alpha=${ALPHA:-1.0} +$K.beta=${BETA:-2.0} +$K.gamma=${GAMMA:-1.0} +$K.lam=${LAM:-0.5} \
  +$K.w_hr1=${W_HR1:-1.0} +$K.w_ndcg=${W_NDCG:-0.5} \
  trainer.total_training_steps=${STEPS:-200} \
  trainer.save_freq=${SAVE_FREQ:-20} \
  trainer.test_freq=${TEST_FREQ:-10} \
  trainer.val_before_train=true \
  trainer.n_gpus_per_node=$NGPU \
  trainer.nnodes=1 \
  trainer.logger='[console,tensorboard]' \
  trainer.default_local_dir="$OUT/checkpoints" \
  trainer.project_name=agentr_rl \
  trainer.experiment_name=$NAME \
  +ray_kwargs.ray_init._temp_dir="$RAY_TMPDIR" \
  hydra.run.dir="$OUT/hydra" \
  +ray_kwargs.ray_init.runtime_env.worker_process_setup_hook=zmq_iso.patch_job_id \
  +ray_kwargs.ray_init.runtime_env.env_vars.RL_RANKER_RUN_TAG=$NAME \
  "$@"
