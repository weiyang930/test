"""Build recall-rerank eval inputs for the INTERSECTION of:
  (a) SASRec top-10 recall-hit users, and
  (b) users already evaluated in shared_eval_2000_cfhard (have memory in trace).

For each such user we emit one record containing:
  - user_id, positive_item
  - candidate_items = SASRec top-10 recall list (positive included, SASRec order)
  - user_memory = reused from the cf_hard trace (user-level, candidate-independent)
  - sasrec_positive_rank = baseline (positive's rank in SASRec top-10)

Output: outputs/eval_recall_intersect/recall_eval_input.jsonl
Plus prints SASRec baseline metrics on this exact user set.
"""
from __future__ import annotations
import argparse, json, os

RECALL = "recbole_baselines/outputs/recall_topn/sasrec_top50_recall.jsonl"
TRACE = "outputs/shared_eval_2000_cfhard/traces/test_traces.jsonl"
OUT_DIR = "outputs/eval_recall_intersect"
TOP_K = 10


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--recall", default=RECALL)
    ap.add_argument("--trace", default=TRACE)
    ap.add_argument("--out_dir", default=OUT_DIR)
    ap.add_argument("--top_k", type=int, default=TOP_K)
    args = ap.parse_args()
    recall_path, trace_path, out_dir, top_k = args.recall, args.trace, args.out_dir, args.top_k

    recall = {}
    with open(recall_path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            r = d["positive_rank_in_topn"]
            if 0 < r <= top_k:
                recall[d["user_id"]] = {
                    "topn": d["topn_items"][:top_k],
                    "pos": d["test_item"],
                    "sas_rank": r,
                    "history": d["history_items"],
                }
    trace = {}
    with open(trace_path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            trace[d["user_id"]] = d

    inter = sorted(set(recall) & set(trace))
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "recall_eval_input.jsonl")
    sas_ranks = []
    with open(out, "w", encoding="utf-8") as fo:
        for uid in inter:
            rc = recall[uid]
            tr = trace[uid]
            mem = tr.get("user_memory_before") or tr.get("user_memory_after") or {}
            rec = {
                "user_id": uid,
                "sample_id": f"{uid}__recall__test",
                "positive_item": rc["pos"],
                "candidate_note_ids": rc["topn"],   # SASRec top-10 order
                "user_memory": mem,
                "history_items": rc["history"],
                "sasrec_positive_rank": rc["sas_rank"],
            }
            fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
            sas_ranks.append(rc["sas_rank"])

    n = len(sas_ranks)
    hr1 = sum(1 for r in sas_ranks if r == 1) / n
    hr5 = sum(1 for r in sas_ranks if r <= 5) / n
    mrr = sum(1.0 / r for r in sas_ranks) / n
    print(f"intersection users: {n} -> {out}")
    print(f"SASRec baseline: HR@1={hr1:.4f} HR@5={hr5:.4f} MRR={mrr:.4f} avg_rank={sum(sas_ranks)/n:.2f}")


if __name__ == "__main__":
    main()
