"""Export SASRec top-N RECALL list per user (for realistic recall->rerank eval).

Difference vs export_cf_hard_negatives.py:
  - We KEEP the test positive item if it falls in SASRec's top-N (we do NOT
    remove it). This lets us measure realistic recall: is the user's true
    next-item actually retrieved by SASRec, and at what rank?
  - We exclude only history + valid (already-known interactions), NOT the test
    positive.
  - We record, for each user, SASRec's ranked top-N list (= SASRec's own ranking,
    which serves as the recall AND the SASRec-rerank baseline) and the rank of
    the test positive within it (-1 if not in top-N = recall miss).

This does NOT touch any existing files (new script, new output path).

Output jsonl, one line per user:
  {
    "user_id": "...",
    "topn_items": ["tok", ...],         # SASRec top-N, ranked best-first
    "test_item": "tok",
    "positive_rank_in_topn": int,        # 1-indexed rank of test item, -1 if miss
    "history_items": ["tok", ...]        # user history (for MAS context)
  }

Usage:
  python recbole_baselines/scripts/export_sasrec_topn_recall.py \
      --checkpoint "recbole_baselines/outputs/checkpoints/SASRec-*.pth" \
      --splits recbole_baselines/dataset/rednote_splits.jsonl \
      --top_n 50 \
      --out recbole_baselines/outputs/recall_topn/sasrec_top50_recall.jsonl
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from typing import Any, Dict, List

import numpy as np
import torch

from recbole.config import Config
from recbole.data import create_dataset
from recbole.data.interaction import Interaction
from recbole.utils import get_model, init_seed


def load_model_and_dataset(checkpoint_path: str, device: str):
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    config: Config = ckpt["config"]
    config["device"] = device
    init_seed(config["seed"], config["reproducibility"])
    dataset = create_dataset(config)
    model = get_model(config["model"])(config, dataset).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.load_other_parameter(ckpt.get("other_parameter"))
    model.eval()
    return model, dataset, config


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--top_n", type=int, default=50)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    matches = sorted(glob.glob(args.checkpoint))
    if not matches:
        raise FileNotFoundError(f"No checkpoint matched: {args.checkpoint}")
    checkpoint_path = matches[-1]
    device = args.device if torch.cuda.is_available() else "cpu"
    model, dataset, config = load_model_and_dataset(checkpoint_path, device)

    iid_field = config["ITEM_ID_FIELD"]
    item_seq_field = getattr(model, "ITEM_SEQ")
    item_seq_len_field = getattr(model, "ITEM_SEQ_LEN")
    max_len = int(config["MAX_ITEM_LIST_LENGTH"])

    id2tok = dataset.field2id_token[iid_field]
    tok2id = {t: i for i, t in enumerate(id2tok)}

    users: List[Dict[str, Any]] = []
    with open(args.splits, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if args.limit is not None and i >= args.limit:
                break
            line = line.strip()
            if line:
                users.append(json.loads(line))

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    out_f = open(args.out, "w", encoding="utf-8")

    n_written = 0
    n_hit = 0
    buf_seqs, buf_lens, buf_meta = [], [], []

    def flush():
        nonlocal n_written, n_hit
        if not buf_seqs:
            return
        item_seq = torch.tensor(buf_seqs, dtype=torch.long, device=device)
        item_len = torch.tensor(buf_lens, dtype=torch.long, device=device)
        inter = Interaction({item_seq_field: item_seq, item_seq_len_field: item_len})
        scores = model.full_sort_predict(inter.to(device))
        scores = scores.view(len(buf_seqs), -1).detach().cpu().numpy()
        for row, meta in enumerate(buf_meta):
            s = scores[row]
            # forbidden = history + valid (NOT the test positive)
            forbidden = meta["forbidden_ids"]
            test_id = meta["test_id"]
            order = np.argsort(-s)
            topn = []
            for iid in order:
                if iid == 0:
                    continue
                if iid in forbidden:
                    continue
                topn.append(int(iid))
                if len(topn) >= args.top_n:
                    break
            topn_toks = [id2tok[i] for i in topn]
            # rank of the test positive within top-N (1-indexed, -1 if miss)
            pos_rank = -1
            if test_id is not None and test_id in topn:
                pos_rank = topn.index(test_id) + 1
                n_hit += 1
            out_f.write(json.dumps({
                "user_id": meta["user_id"],
                "topn_items": topn_toks,
                "test_item": meta["test_tok"],
                "positive_rank_in_topn": pos_rank,
                "history_items": meta["history_toks"],
            }, ensure_ascii=False) + "\n")
            n_written += 1
        buf_seqs.clear(); buf_lens.clear(); buf_meta.clear()

    for u in users:
        uid = u["user_id"]
        hist_toks = list(u["train_items"]) + [u["valid_item"]]
        hist_ids = [tok2id[t] for t in hist_toks if t in tok2id]
        hist_ids = hist_ids[-max_len:]
        seq_len = len(hist_ids)
        padded = hist_ids + [0] * (max_len - seq_len)
        # forbidden = history + valid only (KEEP test positive in candidates)
        forbidden = set(hist_ids)
        if u["valid_item"] in tok2id:
            forbidden.add(tok2id[u["valid_item"]])
        test_tok = u["test_item"]
        test_id = tok2id.get(test_tok)
        buf_seqs.append(padded)
        buf_lens.append(max(seq_len, 1))
        buf_meta.append({
            "user_id": uid,
            "forbidden_ids": forbidden,
            "test_id": test_id,
            "test_tok": test_tok,
            "history_toks": list(u["train_items"]) + [u["valid_item"]],
        })
        if len(buf_seqs) >= args.batch_size:
            flush()
    flush()
    out_f.close()
    print(f"wrote {n_written} users -> {args.out} (top_n={args.top_n})")
    print(f"recall@{args.top_n}: {n_hit}/{n_written} = {n_hit/max(n_written,1):.4f}")


if __name__ == "__main__":
    main()
