"""Convert the rednote sampled dataset into RecBole atomic files.

Decoupled from the MAS package, but reuses the SAME chronological ordering and
leave-one-out logic so that RecBole baselines and the MAS pipeline evaluate on
an identical train/valid/test split.

Output (RecBole inter atomic file):
  <out_dir>/<name>/<name>.inter
    user_id:token  item_id:token  timestamp:float

The timestamp is a monotonic per-user position index (0,1,2,...) that encodes our
chronological order. With RecBole eval_args order=TO + split=LS (leave-one-out),
RecBole's last/second-last items per user then match our test/valid items exactly.

We also export a splits.jsonl identical in spirit to the MAS splits, so the
sampled-candidate evaluator can cross-check.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from typing import Any, Dict, List, Optional

import pandas as pd


# ---- chronological ordering (mirrors reflective_mas_rec/data/dataset.py) ---- #


def _parse_conv_time(value: Any) -> Optional[float]:
    if value is None:
        return None
    s = str(value).strip()
    if not s or s == "0":
        return None
    try:
        num = float(s)
        return num if num > 0 else None
    except ValueError:
        pass
    try:
        ts = pd.to_datetime(s, errors="coerce")
        if ts is not None and not pd.isna(ts):
            return float(ts.value)
    except Exception:
        pass
    return None


def _parse_date_partition(value: Any) -> Optional[float]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def order_user_histories(interactions: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in interactions:
        grouped[row["user_id"]].append(row)
    histories: Dict[str, List[str]] = {}
    for uid, rows in grouped.items():
        def sort_key(r):
            ct = _parse_conv_time(r.get("conv_time"))
            dp = _parse_date_partition(r.get("date_partition"))
            ri = int(r.get("_row_idx", 0))
            return (
                0 if ct is not None else 1, ct if ct is not None else 0.0,
                0 if dp is not None else 1, dp if dp is not None else 0.0, ri,
            )
        ordered = sorted(rows, key=sort_key)
        seen, seq = set(), []
        for r in ordered:
            nid = r["note_id"]
            if nid not in seen:
                seen.add(nid)
                seq.append(nid)
        histories[uid] = seq
    return histories


def load_interactions(path: str) -> List[Dict[str, Any]]:
    df = pd.read_parquet(path)
    out = []
    for idx, row in enumerate(df.to_dict(orient="records")):
        uid = str(row.get("user_id") or "")
        nid = str(row.get("note_id") or "")
        if not uid or not nid:
            continue
        out.append({
            "user_id": uid, "note_id": nid,
            "conv_time": str(row.get("conv_time") or ""),
            "date_partition": str(row.get("date_partition") or ""),
            "_row_idx": idx,
        })
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", default="./data/rednote/subset_20000users_u10_100_i10_seed42")
    ap.add_argument("--out_dir", default="./recbole_baselines/dataset")
    ap.add_argument("--name", default="rednote")
    ap.add_argument("--min_seq_len", type=int, default=10)
    args = ap.parse_args()

    inter_path = os.path.join(args.data_root, "interactions.parquet")
    interactions = load_interactions(inter_path)
    histories = order_user_histories(interactions)

    # Keep only users with T >= min_seq_len (same as MAS leave-one-out).
    kept = {u: seq for u, seq in histories.items() if len(seq) >= args.min_seq_len}
    print(f"users total={len(histories)} kept(T>={args.min_seq_len})={len(kept)}")

    ds_dir = os.path.join(args.out_dir, args.name)
    os.makedirs(ds_dir, exist_ok=True)

    # Write .inter with monotonic per-user timestamp encoding our order.
    inter_file = os.path.join(ds_dir, f"{args.name}.inter")
    n_rows = 0
    with open(inter_file, "w", encoding="utf-8") as f:
        f.write("user_id:token\titem_id:token\ttimestamp:float\n")
        for uid in sorted(kept.keys()):
            for pos, nid in enumerate(kept[uid]):
                f.write(f"{uid}\t{nid}\t{float(pos)}\n")
                n_rows += 1
    print(f"wrote {n_rows} rows -> {inter_file}")

    # Export splits.jsonl (train=all but last2, valid=-2, test=-1) for cross-check.
    splits_path = os.path.join(args.out_dir, f"{args.name}_splits.jsonl")
    with open(splits_path, "w", encoding="utf-8") as f:
        for uid in sorted(kept.keys()):
            seq = kept[uid]
            rec = {
                "user_id": uid,
                "train_items": seq[:-2],
                "valid_item": seq[-2],
                "test_item": seq[-1],
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"wrote splits -> {splits_path}")


if __name__ == "__main__":
    main()
