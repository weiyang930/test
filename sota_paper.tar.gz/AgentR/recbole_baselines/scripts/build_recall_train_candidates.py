"""Generate REAL-RECALL candidates for existing train samples (for retraining).

For each existing train rank sample (prefix history -> positive), we run SASRec
on that prefix history, take top-9 retrieved items as negatives, and force-add
the positive (replacing the 9th if positive not already retrieved). This makes
the candidate distribution match the real recall->rerank task while keeping the
sample monitorable (positive always present).

Reads the existing samples to keep the SAME users/prefixes (so we can reuse their
memory/evidence trace later). Writes new rank_samples with real-recall candidates.

Does NOT touch any existing file (new output path).

Output: <out>/samples/train_rank_samples.jsonl  (MAS RankSample format)
"""
from __future__ import annotations
import argparse, glob, json, os
import numpy as np
import torch
from recbole.config import Config
from recbole.data import create_dataset
from recbole.data.interaction import Interaction
from recbole.utils import get_model, init_seed


def load_model(ckpt_path, device):
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    config = ckpt["config"]; config["device"] = device
    init_seed(config["seed"], config["reproducibility"])
    ds = create_dataset(config)
    model = get_model(config["model"])(config, ds).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.load_other_parameter(ckpt.get("other_parameter"))
    model.eval()
    return model, ds, config


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default="recbole_baselines/outputs/checkpoints/SASRec-*.pth")
    ap.add_argument("--in_samples", default="outputs/shared_eval_2000_cfhard/samples/train_rank_samples.jsonl")
    ap.add_argument("--out", default="outputs/recall_train_2000/samples/train_rank_samples.jsonl")
    ap.add_argument("--k", type=int, default=10, help="candidate list size (1 pos + k-1 recall negs)")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--batch_size", type=int, default=512)
    args = ap.parse_args()

    ckpt = sorted(glob.glob(args.checkpoint))[-1]
    device = args.device if torch.cuda.is_available() else "cpu"
    model, ds, config = load_model(ckpt, device)
    iid_field = config["ITEM_ID_FIELD"]
    item_seq_field = getattr(model, "ITEM_SEQ")
    item_seq_len_field = getattr(model, "ITEM_SEQ_LEN")
    max_len = int(config["MAX_ITEM_LIST_LENGTH"])
    id2tok = ds.field2id_token[iid_field]
    tok2id = {t: i for i, t in enumerate(id2tok)}

    rows = []
    with open(args.in_samples, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    print(f"loaded {len(rows)} train samples", flush=True)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    out_f = open(args.out, "w", encoding="utf-8")

    n_written = 0
    n_pos_in_recall = 0
    buf, buf_meta = [], []

    def flush():
        nonlocal n_written, n_pos_in_recall
        if not buf:
            return
        item_seq = torch.tensor([b[0] for b in buf], dtype=torch.long, device=device)
        item_len = torch.tensor([b[1] for b in buf], dtype=torch.long, device=device)
        inter = Interaction({item_seq_field: item_seq, item_seq_len_field: item_len})
        scores = model.full_sort_predict(inter.to(device)).view(len(buf), -1).detach().cpu().numpy()
        for row, meta in enumerate(buf_meta):
            s = scores[row]
            forbidden = meta["forbidden_ids"]   # prefix history ids
            pos_tok = meta["positive"]
            order = np.argsort(-s)
            recall = []
            for iid in order:
                if iid == 0 or iid in forbidden:
                    continue
                recall.append(int(iid))
                if len(recall) >= args.k:   # take a bit extra; we trim below
                    break
            recall_toks = [id2tok[i] for i in recall]
            # build candidates: top (k-1) recall as negatives + force positive
            negs = [t for t in recall_toks if t != pos_tok][: args.k - 1]
            pos_in_recall = pos_tok in recall_toks[: args.k]
            if pos_in_recall:
                n_pos_in_recall += 1
            candidates = negs + [pos_tok]
            # SASRec rank for EACH final candidate = its relative order by SASRec
            # score within this candidate set (1 = SASRec most confident). The
            # force-added positive (if not recalled) naturally gets a high (worse)
            # rank because its SASRec score is low. This is exactly the prior the
            # ranker should see: "how SASRec would order these 10".
            cand_score = {t: float(s[tok2id[t]]) for t in candidates if t in tok2id}
            ranked = sorted(candidates, key=lambda t: -cand_score.get(t, -1e30))
            sasrec_rank_map = {t: i + 1 for i, t in enumerate(ranked)}
            # keep deterministic shuffle (防 position bias); rank carried separately
            import random as _r
            _r.Random(hash(meta["sample_id"]) & 0xffffffff).shuffle(candidates)
            out_f.write(json.dumps({
                "sample_id": meta["sample_id"],
                "user_id": meta["user_id"],
                "history_items": meta["history_items"],
                "positive_item": pos_tok,
                "negative_items": [c for c in candidates if c != pos_tok],
                "candidate_items": candidates,
                "sasrec_rank_map": sasrec_rank_map,   # note_id -> SASRec rank (1-based)
                "pos_in_recall": pos_in_recall,       # True = positive naturally recalled (clean hit sample)
                "split": "train",
            }, ensure_ascii=False) + "\n")
            n_written += 1
        buf.clear(); buf_meta.clear()

    for d in rows:
        hist = d["history_items"]
        hist_ids = [tok2id[t] for t in hist if t in tok2id][-max_len:]
        seq_len = len(hist_ids)
        if seq_len == 0:
            continue
        padded = hist_ids + [0] * (max_len - seq_len)
        forbidden = set(hist_ids)
        buf.append((padded, max(seq_len, 1)))
        buf_meta.append({
            "sample_id": d["sample_id"], "user_id": d["user_id"],
            "history_items": hist, "positive": d["positive_item"],
            "forbidden_ids": forbidden,
        })
        if len(buf) >= args.batch_size:
            flush()
    flush()
    out_f.close()
    print(f"wrote {n_written} -> {args.out}", flush=True)
    print(f"positive naturally in SASRec top-{args.k}: {n_pos_in_recall}/{n_written} "
          f"= {n_pos_in_recall/max(n_written,1):.3f} (rest were force-added)", flush=True)


if __name__ == "__main__":
    main()
