"""Train a RecBole baseline on the rednote dataset.

Usage:
  python recbole_baselines/scripts/train_recbole.py --model SASRec
  python recbole_baselines/scripts/train_recbole.py --model BPR --gpu 0

Saves the best checkpoint under outputs/checkpoints and writes the full-catalog
evaluation metrics to outputs/results/<model>_fullrank.json. The saved checkpoint
path is recorded so the sampled-candidate evaluator can reload the exact model.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import torch

# torch>=2.6 flips torch.load(weights_only) default to True, which breaks
# RecBole 1.2.1's internal checkpoint reload during evaluate() (it calls
# torch.load without weights_only). This env has torch 2.11, so force the old
# behavior. Trusted local checkpoints only.
_orig_torch_load = torch.load
def _torch_load_compat(*a, **k):
    k.setdefault("weights_only", False)
    return _orig_torch_load(*a, **k)
torch.load = _torch_load_compat

from recbole.quick_start import run_recbole


MODEL_CONFIG = {
    "BPR": "BPR.yaml",
    "LightGCN": "LightGCN.yaml",
    "Pop": "Pop.yaml",
    "SASRec": "SASRec.yaml",
    "GRU4Rec": "GRU4Rec.yaml",
    "BERT4Rec": "BERT4Rec.yaml",
    "NeuMF": "NeuMF.yaml",
    "RecVAE": "RecVAE.yaml",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=list(MODEL_CONFIG.keys()))
    ap.add_argument("--gpu", default="0", help="CUDA_VISIBLE_DEVICES value")
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--config_dir", default="./recbole_baselines/configs")
    ap.add_argument("--results_dir", default="./recbole_baselines/outputs/results")
    ap.add_argument("--dataset", default="rednote", help="RecBole dataset name (dir under dataset/)")
    ap.add_argument("--checkpoint_dir", default=None,
                    help="Override base.yaml checkpoint_dir (isolate CF baselines from line-B SASRec ckpts)")
    args = ap.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    os.makedirs(args.results_dir, exist_ok=True)

    base_cfg = os.path.join(args.config_dir, "base.yaml")
    model_cfg = os.path.join(args.config_dir, MODEL_CONFIG[args.model])
    config_file_list = [base_cfg, model_cfg]

    config_dict = {"dataset": args.dataset}
    if args.epochs is not None:
        config_dict["epochs"] = args.epochs
    if args.checkpoint_dir is not None:
        os.makedirs(args.checkpoint_dir, exist_ok=True)
        config_dict["checkpoint_dir"] = args.checkpoint_dir

    result = run_recbole(
        model=args.model,
        dataset=args.dataset,
        config_file_list=config_file_list,
        config_dict=config_dict,
    )

    # result: {best_valid_score, valid_score_bigger, best_valid_result, test_result}
    out = {
        "model": args.model,
        "dataset": args.dataset,
        "best_valid_score": float(result.get("best_valid_score", 0.0)),
        "best_valid_result": _to_jsonable(result.get("best_valid_result")),
        "test_result": _to_jsonable(result.get("test_result")),
    }
    tag = args.model if args.dataset == "rednote" else f"{args.model}_{args.dataset}"
    out_path = os.path.join(args.results_dir, f"{tag}_fullrank.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n[full-rank eval] {args.model}")
    print(json.dumps(out["test_result"], ensure_ascii=False, indent=2))
    print(f"saved -> {out_path}")


def _to_jsonable(obj):
    if obj is None:
        return None
    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    try:
        return float(obj)
    except (TypeError, ValueError):
        return str(obj)


if __name__ == "__main__":
    main()
