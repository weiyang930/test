"""Export per-user CF (SASRec) hard negatives for MAS candidate construction.

For each user we run the trained sequential CF model on the user's FULL ordered
history (train + valid, i.e. everything before the test item) and take the
top-N highest-scoring catalog items. We then remove all of the user's positive
interactions (full history + valid + test) so the remaining items are genuine
hard negatives: items the CF model thinks the user would like but never engaged.

Leakage safety:
  - The CF model was trained on the train split only (RecBole leave-one-out).
  - Scoring uses the user's historical sequence; the test item is never fed in
    and is explicitly excluded from the negative pool.
  - One shared hard-negative pool per user; the MAS sampler later picks K-1 from
    it per sample, excluding that sample's own positive.

Output jsonl, one line per user:
  {"user_id": "...", "hard_negatives": ["item_tok", ...]}  # ranked, best first

Usage:
  python recbole_baselines/scripts/export_cf_hard_negatives.py \
      --checkpoint "recbole_baselines/outputs/checkpoints/SASRec-*.pth" \
      --splits recbole_baselines/dataset/rednote_splits.jsonl \
      --top_n 200 \
      --out recbole_baselines/outputs/cf_hard/sasrec_hard_negatives.jsonl
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from typing import Any, Dict, List

import numpy as np
import torch

from recbole.config import Config
from recbole.data import create_dataset
from recbole.data.interaction import Interaction
from recbole.utils import get_model, init_seed


def load_model_and_dataset(checkpoint_path: str, device: str):
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    config: Config = ckpt["config"]
    config["device"] = device
    init_seed(config["seed"], config["reproducibility"])
    dataset = create_dataset(config)
    model = get_model(config["model"])(config, dataset).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.load_other_parameter(ckpt.get("other_parameter"))
    model.eval()
    return model, dataset, config


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--top_n", type=int, default=200,
                    help="how many hard negatives to keep per user")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--batch_size", type=int, default=512)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    matches = sorted(glob.glob(args.checkpoint))
    if not matches:
        raise FileNotFoundError(f"No checkpoint matched: {args.checkpoint}")
    checkpoint_path = matches[-1]
    device = args.device if torch.cuda.is_available() else "cpu"
    model, dataset, config = load_model_and_dataset(checkpoint_path, device)

    model_type = str(config["MODEL_TYPE"]).upper()
    is_seq = "SEQUENTIAL" in model_type
    if not is_seq:
        raise ValueError("This exporter targets sequential models (e.g. SASRec).")

    iid_field = config["ITEM_ID_FIELD"]
    item_seq_field = getattr(model, "ITEM_SEQ")
    item_seq_len_field = getattr(model, "ITEM_SEQ_LEN")
    max_len = int(config["MAX_ITEM_LIST_LENGTH"])

    id2tok = dataset.field2id_token[iid_field]      # internal id -> token
    tok2id = {t: i for i, t in enumerate(id2tok)}
    n_items = len(id2tok)

    # Load splits.
    users: List[Dict[str, Any]] = []
    with open(args.splits, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if args.limit is not None and i >= args.limit:
                break
            line = line.strip()
            if line:
                users.append(json.loads(line))

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    out_f = open(args.out, "w", encoding="utf-8")

    n_written = 0
    buf_seqs, buf_lens, buf_meta = [], [], []

    def flush():
        nonlocal n_written
        if not buf_seqs:
            return
        item_seq = torch.tensor(buf_seqs, dtype=torch.long, device=device)
        item_len = torch.tensor(buf_lens, dtype=torch.long, device=device)
        inter = Interaction({item_seq_field: item_seq, item_seq_len_field: item_len})
        # full_sort_predict returns scores over all items: [B, n_items]
        scores = model.full_sort_predict(inter.to(device))
        scores = scores.view(len(buf_seqs), -1).detach().cpu().numpy()
        for row, meta in enumerate(buf_meta):
            s = scores[row]
            forbidden = meta["forbidden_ids"]
            # rank items by score desc, skip PAD(0) and forbidden, take top_n
            order = np.argsort(-s)
            hard = []
            for iid in order:
                if iid == 0:
                    continue
                if iid in forbidden:
                    continue
                hard.append(id2tok[iid])
                if len(hard) >= args.top_n:
                    break
            out_f.write(json.dumps(
                {"user_id": meta["user_id"], "hard_negatives": hard},
                ensure_ascii=False) + "\n")
            n_written += 1
        buf_seqs.clear(); buf_lens.clear(); buf_meta.clear()

    for u in users:
        uid = u["user_id"]
        # Full history before test = train_items + valid_item.
        hist_toks = list(u["train_items"]) + [u["valid_item"]]
        hist_ids = [tok2id[t] for t in hist_toks if t in tok2id]
        hist_ids = hist_ids[-max_len:]
        seq_len = len(hist_ids)
        padded = hist_ids + [0] * (max_len - seq_len)
        # forbidden = all positives of this user (history + valid + test).
        forbidden = set(hist_ids)
        for t in (u["valid_item"], u["test_item"]):
            if t in tok2id:
                forbidden.add(tok2id[t])
        buf_seqs.append(padded)
        buf_lens.append(max(seq_len, 1))
        buf_meta.append({"user_id": uid, "forbidden_ids": forbidden})
        if len(buf_seqs) >= args.batch_size:
            flush()
    flush()
    out_f.close()
    print(f"wrote {n_written} users -> {args.out} (top_n={args.top_n})")


if __name__ == "__main__":
    main()
