#!/usr/bin/env bash
# Link the artifacts of the original research tree (where the paper runs were done) into
# this repo's layout, so any stage can be (re)run or evaluated without recomputing the
# upstream stages. Links are LEAF-level (files / model dirs); every directory the drivers
# write into stays a real directory here, and all drivers skip existing outputs, so the
# legacy tree is never written to.
#
#   bash tools/link_legacy_outputs.sh /path/to/original/project cd kindle_store rednote
# Also links data/ and recbole_baselines/dataset/<name>* (read-only inputs).
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
L=${1:?legacy project root}; shift
[ $# -gt 0 ] || set -- cd kindle_store rednote
cd "$ROOT"

lnk() {  # lnk <legacy relative path> <new path>
  local src="$L/$1" dst="$2"
  if [ ! -e "$src" ]; then echo "  [miss] $1"; return 0; fi
  mkdir -p "$(dirname "$dst")"
  if [ -e "$dst" ] && [ ! -L "$dst" ]; then echo "  [keep] $dst (real file/dir exists)"; return 0; fi
  ln -sfn "$src" "$dst"; echo "  [link] $dst -> $1"
}

for ds in "$@"; do
  eval "$(python3 agentr_paths.py "$ds" --shell)"
  echo "== $ds"
  # inputs
  lnk "$DATA_DIR" "$DATA_DIR"
  lnk "recbole_baselines/dataset/$RECBOLE_NAME" "recbole_baselines/dataset/$RECBOLE_NAME"
  lnk "recbole_baselines/dataset/${RECBOLE_NAME}_splits.jsonl" "$RECBOLE_SPLITS"
  lnk "recbole_baselines/dataset/${RECBOLE_NAME}_h4" "recbole_baselines/dataset/${RECBOLE_NAME}_h4"
  case $ds in
    cd)      CK=recbole_baselines/outputs/checkpoints/SASRec-Jul-16-2026_19-46-41.pth; TOPN=recall_topn_cds; CFN=cf_hard_cds
             CF=shared_eval_full_cfhard_cd_8b; CFM=rank_sft_8b_cfhard_cd; RT=recall_train_cd_v2/traces/train_traces.jsonl
             RI=eval_recall_intersect_cd; OOSV=rl_ranker/oos/cd_valid_top10.jsonl; OOSH=rl_ranker/oos/cd_h4_top10.jsonl
             OOSS=rl_ranker/oos/sasrec_h4/ckpt; RUNS="srA2:100,200";;
    kindle_store) CK=$(cat "$L/recbole_baselines/outputs/checkpoints_kindle_store/PINNED_CKPT.txt"); TOPN=recall_topn_kindle_store; CFN=cf_hard_kindle_store
             CF=shared_eval_full_cfhard_kindle_store_8b; CFM=rank_sft_8b_cfhard_kindle_store; RT=recall_train_kindle_store/traces/train_traces.jsonl
             RI=eval_recall_intersect_kindle_store; OOSV=rl_ranker/oos/kindle_store/valid_top10.jsonl; OOSH=rl_ranker/oos/kindle_store/h4_top10.jsonl
             OOSS=rl_ranker/oos/kindle_store/sasrec_h4/ckpt; RUNS="srK2:100";;
    rednote) CK=recbole_baselines/outputs/checkpoints/SASRec-Jul-12-2026_22-26-00.pth; TOPN=recall_topn; CFN=cf_hard
             CF=shared_eval_full_cfhard_8b; CFM=rank_sft_8b_cfhard_full; RT=recall_train_full16/traces_merged/train_traces.jsonl
             RI=eval_recall_intersect_full; OOSV=rl_ranker/oos/rednote/valid_top10.jsonl; OOSH=rl_ranker/oos/rednote/h4_top10.jsonl
             OOSS=rl_ranker/oos/rednote/sasrec_h4/ckpt; RUNS="srR2:100";;
    *) echo "  no legacy mapping for $ds"; continue;;
  esac
  # stage 1
  lnk "$CK" "$SASREC_DIR/$(basename "$CK")"
  lnk "recbole_baselines/outputs/$TOPN/sasrec_top50_recall.jsonl" "$TOP50"
  lnk "recbole_baselines/outputs/$CFN/sasrec_hard_negatives.jsonl" "$CF_NEG"
  # stage 2 (line A)
  for s in train valid test; do
    lnk "outputs/$CF/samples/${s}_rank_samples.jsonl" "$CF_DIR/samples/${s}_rank_samples.jsonl"
    lnk "outputs/$CF/traces/${s}_traces.jsonl" "$CF_DIR/traces/${s}_traces.jsonl"
  done
  lnk "outputs/$CF/sft/rank_agent_sft.jsonl" "$CF_DIR/sft/rank_agent_sft.jsonl"
  lnk "outputs/$CFM/merged_model" "$CF_DIR/model/merged_model"
  # stage 3 (line B + source-conditioned SFT)
  lnk "outputs/$RT" "$RECALL_TRAIN_TRACES"
  lnk "outputs/$RI/recall_eval_input.jsonl" "$RECALL_INPUT"
  lnk "outputs/agentr_real_retrieved_experiments/sft_data/${ds}_sc_exp1_noev.jsonl" "$SC_DIR/sft_data.jsonl"
  lnk "outputs/agentr_real_retrieved_experiments/checkpoints/${ds}_sc_exp1/merged_model" "$SC_DIR/model/merged_model"
  # stage 4 (RL)
  lnk "outputs/$OOSV" "$RL_DIR/oos/valid_top10.jsonl"
  lnk "outputs/$OOSH" "$RL_DIR/oos/h4_top10.jsonl"
  lnk "outputs/$OOSS" "$RL_DIR/oos/sasrec_h4/ckpt"
  for s in train val; do lnk "outputs/rl_ranker/data/rr_${ds}_oosall/$s.parquet" "$RL_DIR/data/oosall/$s.parquet"; done
  for spec in $RUNS; do
    run=${spec%%:*}
    for st in ${spec#*:}; do
      st=${st//,/ }
      for x in $st; do lnk "outputs/rl_ranker/runs/$run/hf/step$x" "$RL_DIR/runs/legacy_$run/hf/step$x"; done
    done
  done
done
mkdir -p models/Qwen
echo "note: point BASE_MODEL (env.sh) at a Qwen3-8B HF dir, or link it to models/Qwen/Qwen3-8B"
