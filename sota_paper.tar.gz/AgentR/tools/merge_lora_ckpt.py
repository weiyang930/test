#!/usr/bin/env python3
"""Merge a LoRA adapter checkpoint into the base model for vLLM serving.

Used to probe an intermediate checkpoint before the full run finishes (the
training script only auto-merges at the very end).

Usage:
  python scripts_dev/merge_lora_ckpt.py <adapter_dir> <base_model> <out_dir>
"""
import sys
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel


def main():
    adapter_dir, base_model, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    print(f"[merge] base={base_model}")
    print(f"[merge] adapter={adapter_dir}")
    tok = AutoTokenizer.from_pretrained(adapter_dir, trust_remote_code=True)
    base = AutoModelForCausalLM.from_pretrained(
        base_model, torch_dtype=torch.bfloat16, trust_remote_code=True)
    model = PeftModel.from_pretrained(base, adapter_dir)
    merged = model.merge_and_unload()
    merged.save_pretrained(out_dir, safe_serialization=True)
    tok.save_pretrained(out_dir)
    print(f"[merge] -> {out_dir}")


if __name__ == "__main__":
    main()
