#!/usr/bin/env python
"""Dataset registry + output layout for the whole pipeline (single source of truth).

Every driver script and every python entry point resolves dataset paths through
this module, so a dataset only has to be registered once (DATASETS below).

Layout (all relative to the repo root):

  data/<...>/{users,items,interactions}.parquet        DATA_DIR (demo schema)
  recbole_baselines/dataset/<recbole_name>/             RecBole atomic files (+ _splits.jsonl)
  outputs/<ds>/
    configs/{cfhard_rollout,recall_gen,recall_eval}.yaml   rendered from configs/templates
    sasrec/ckpt/SASRec-*.pth                               main SASRec (candidate source)
    sasrec/top50_recall.jsonl                              real recall list (line B)
    sasrec/cf_hard_negatives.jsonl                         top-200 hard negatives (line A)
    cfhard/samples|shards|traces|sft|model|eval            line A: MAS rollout -> SFT -> eval
    recall/samples|shards|traces|eval_input                line B: recall traces + hit-user eval set
    sc/sft_data.jsonl, sc/model, sc/eval                   source-conditioned preserve-correct SFT
    rl/oos, rl/data, rl/runs/<name>                        GRPO (source-relative reward)

AGENTR_OUT_ROOT (env, default "outputs") relocates the whole outputs/ tree, e.g. for a smoke run.

CLI:
  python agentr_paths.py <ds> --shell          # `eval "$(...)"` -> exports DS, DATA_DIR, ...
  python agentr_paths.py <ds> --make-configs   # render outputs/<ds>/configs/*.yaml
  python agentr_paths.py --list
"""
from __future__ import annotations

import argparse
import os
import shlex
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# key -> (data dir relative to ROOT, RecBole dataset name)
# recbole_name is baked into SASRec checkpoints (they reload their dataset by name),
# which is why CD keeps its historical name "cds".
DATASETS = {
    "cd":                       ("data/amazon/CDs_and_Vinyl", "cds"),
    "kindle_store":             ("data/amazon/Kindle_Store", "kindle_store"),
    "rednote":                  ("data/rednote/subset_20000users_u10_100_i10_seed42", "rednote"),
    "software":                 ("data/amazon/Software", "software"),
    "videogames":               ("data/amazon/Video_Games", "videogames"),
    "baby_products":            ("data/amazon/Baby_Products", "baby_products"),
    "sports_and_outdoors":      ("data/amazon/Sports_and_Outdoors", "sports_and_outdoors"),
    "grocery_and_gourmet_food": ("data/amazon/Grocery_and_Gourmet_Food", "grocery_and_gourmet_food"),
    "movies_and_tv":            ("data/amazon/Movies_and_TV", "movies_and_tv"),
    "home_and_kitchen":         ("data/amazon/Home_and_Kitchen", "home_and_kitchen"),
}


def paths(ds: str) -> dict:
    if ds not in DATASETS:
        raise KeyError(f"unknown dataset {ds!r}; known: {list(DATASETS)}")
    data_dir, rb = DATASETS[ds]
    out = f"{os.environ.get('AGENTR_OUT_ROOT', 'outputs')}/{ds}"
    return {
        "DS": ds,
        "DATA_DIR": data_dir,
        "ITEMS_PARQUET": f"{data_dir}/items.parquet",
        "RECBOLE_NAME": rb,
        "RECBOLE_SPLITS": f"recbole_baselines/dataset/{rb}_splits.jsonl",
        "OUT": out,
        "CFG_DIR": f"{out}/configs",
        "SASREC_DIR": f"{out}/sasrec/ckpt",
        "TOP50": f"{out}/sasrec/top50_recall.jsonl",
        "CF_NEG": f"{out}/sasrec/cf_hard_negatives.jsonl",
        "CF_DIR": f"{out}/cfhard",
        "RECALL_DIR": f"{out}/recall",
        "RECALL_TRAIN_TRACES": f"{out}/recall/traces/train_traces.jsonl",
        "RECALL_INPUT": f"{out}/recall/eval_input/recall_eval_input.jsonl",
        "SC_DIR": f"{out}/sc",
        "RL_DIR": f"{out}/rl",
    }


def abspath(ds: str, key: str) -> Path:
    return ROOT / paths(ds)[key]


def make_configs(ds: str, base_model: str, provider: str = "vllm") -> list:
    p = paths(ds)
    subst = dict(p, BASE_MODEL=base_model, PROVIDER=provider)
    out_dir = ROOT / p["CFG_DIR"]
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for tmpl in sorted((ROOT / "configs/templates").glob("*.yaml")):
        text = tmpl.read_text(encoding="utf-8")
        for k, v in subst.items():
            text = text.replace("{{" + k + "}}", v)
        if "{{" in text:
            raise ValueError(f"unfilled placeholder in {tmpl}")
        dst = out_dir / tmpl.name
        tmp = dst.with_name(f".{dst.name}.{os.getpid()}")
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, dst)  # atomic: concurrent drivers may render the same configs
        written.append(str(dst))
    return written


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ds", nargs="?")
    ap.add_argument("--shell", action="store_true")
    ap.add_argument("--make-configs", action="store_true")
    ap.add_argument("--base-model", default=os.environ.get("BASE_MODEL", "./models/Qwen/Qwen3-8B"))
    ap.add_argument("--provider", default=os.environ.get("LLM_PROVIDER", "vllm"))
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()
    if args.list or not args.ds:
        for k, (d, rb) in DATASETS.items():
            print(f"{k:<26} {d}  (recbole: {rb})")
        return
    if args.make_configs:
        for f in make_configs(args.ds, args.base_model, args.provider):
            print(f"[make_configs] {f}", file=sys.stderr)
    if args.shell:
        for k, v in paths(args.ds).items():
            print(f"export {k}={shlex.quote(v)}")


if __name__ == "__main__":
    main()
