"""Deterministic hashing for cache keys."""
from __future__ import annotations

import hashlib
import json
from typing import Any


def stable_hash(obj: Any, length: int = 12) -> str:
    """Return a short, stable hash for any JSON-serializable object.

    Used for cache keys, e.g. ``user_id + sample_id + memory_config_hash``.
    """
    payload = json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str)
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return digest[:length]


def config_hash(config: Any, keys: Any = None, length: int = 12) -> str:
    """Hash a config dict, optionally restricted to a subset of keys."""
    if keys is not None and isinstance(config, dict):
        config = {k: config.get(k) for k in keys}
    return stable_hash(config, length=length)
