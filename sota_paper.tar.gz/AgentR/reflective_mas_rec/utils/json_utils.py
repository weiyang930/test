"""Robust JSON parsing and serialization helpers.

The LLM agents in this framework are required to output valid JSON. Real models
do not always comply, so we need defensive parsing that can recover JSON from
noisy text (markdown fences, leading prose, trailing commentary, etc.).
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional


_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


def dumps(obj: Any, indent: Optional[int] = None) -> str:
    """Serialize an object to JSON, keeping unicode (e.g. Chinese) readable."""
    return json.dumps(obj, ensure_ascii=False, indent=indent, default=str)


def _strip_fences(text: str) -> str:
    match = _FENCE_RE.search(text)
    if match:
        return match.group(1).strip()
    return text.strip()


def _balanced_slice(text: str, open_ch: str, close_ch: str) -> Optional[str]:
    """Extract the first balanced ``open_ch ... close_ch`` block from text."""
    start = text.find(open_ch)
    if start < 0:
        return None
    depth = 0
    in_str = False
    escape = False
    for idx in range(start, len(text)):
        ch = text[idx]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                return text[start : idx + 1]
    return None


def safe_json_loads(text: Any, fallback: Optional[Any] = None) -> Any:
    """Parse JSON from arbitrary LLM text.

    Strategy:
      1. If already a dict/list, return as-is.
      2. Try a direct ``json.loads``.
      3. Strip markdown code fences and retry.
      4. Extract the first balanced ``{...}`` (then ``[...]``) block and retry.
      5. Return ``fallback`` if everything fails.
    """
    if isinstance(text, (dict, list)):
        return text
    if text is None:
        return fallback
    if not isinstance(text, str):
        text = str(text)

    candidates = [text, _strip_fences(text)]
    for cand in candidates:
        cand = cand.strip()
        if not cand:
            continue
        try:
            return json.loads(cand)
        except Exception:
            pass

    stripped = _strip_fences(text)
    for open_ch, close_ch in (("{", "}"), ("[", "]")):
        block = _balanced_slice(stripped, open_ch, close_ch)
        if block:
            try:
                return json.loads(block)
            except Exception:
                continue
    return fallback


def is_parse_success(value: Any, fallback: Any) -> bool:
    """Whether ``value`` is a genuinely parsed object (not the fallback)."""
    return value is not None and value is not fallback
