"""File IO helpers: JSONL streaming, parquet/jsonl loading, directory helpers."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Union

PathLike = Union[str, Path]


def ensure_dir(path: PathLike) -> Path:
    """Create directory ``path`` (and parents) if missing; return it as Path."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def ensure_parent(path: PathLike) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def read_jsonl(path: PathLike, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as handle:
        for i, line in enumerate(handle):
            if limit is not None and i >= limit:
                break
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def iter_jsonl(path: PathLike, limit: Optional[int] = None) -> Iterator[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as handle:
        count = 0
        for line in handle:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)
            count += 1
            if limit is not None and count >= limit:
                break


def write_jsonl(path: PathLike, rows: Iterable[Dict[str, Any]]) -> int:
    ensure_parent(path)
    n = 0
    with open(path, "w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, default=str))
            handle.write("\n")
            n += 1
    return n


class JsonlWriter:
    """Incremental JSONL writer (append-friendly, flushes each line)."""

    def __init__(self, path: PathLike, mode: str = "w") -> None:
        ensure_parent(path)
        self.path = str(path)
        self._handle = open(self.path, mode, encoding="utf-8")
        self.count = 0

    def write(self, row: Dict[str, Any]) -> None:
        self._handle.write(json.dumps(row, ensure_ascii=False, default=str))
        self._handle.write("\n")
        self._handle.flush()
        self.count += 1

    def close(self) -> None:
        try:
            self._handle.close()
        except Exception:
            pass

    def __enter__(self) -> "JsonlWriter":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


def read_json(path: PathLike) -> Any:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: PathLike, obj: Any, indent: int = 2) -> None:
    ensure_parent(path)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=indent, default=str)


def load_table(path: PathLike) -> List[Dict[str, Any]]:
    """Load a parquet or jsonl file into a list of dict rows.

    Prefers parquet when the extension is ``.parquet``; falls back to jsonl.
    """
    p = Path(path)
    if p.suffix == ".parquet":
        import pandas as pd

        df = pd.read_parquet(p)
        return df.to_dict(orient="records")
    if p.suffix in (".jsonl", ".json"):
        return read_jsonl(p)
    raise ValueError(f"Unsupported table format: {path}")
