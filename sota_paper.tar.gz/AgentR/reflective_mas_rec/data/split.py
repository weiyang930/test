"""Chronological leave-one-out splits and sliding-window sample construction."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..utils.io import write_jsonl
from ..utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class UserSplit:
    user_id: str
    train_items: List[str]
    valid_item: str
    test_item: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "user_id": self.user_id,
            "train_items": self.train_items,
            "valid_item": self.valid_item,
            "test_item": self.test_item,
        }


def build_leave_one_out_splits(
    histories: Dict[str, List[str]],
    min_seq_len: int = 10,
    max_users: Optional[int] = None,
    user_offset: int = 0,
) -> List[UserSplit]:
    """For each user with T >= min_seq_len, build leave-one-out split.

        train_items = [i1, ..., i(T-2)]
        valid_item  = i(T-1)
        test_item   = iT

    `user_offset` skips the first N users (in the deterministic user_id order)
    BEFORE applying `max_users`. This lets us carve out a held-out user set that
    is strictly disjoint from a previously-used prefix, e.g. offset=2000 +
    max_users=300 -> splits[2000:2300], the 300 users right after the trained
    2000. Offset is applied on the same sorted order, so distribution matches.
    """
    splits: List[UserSplit] = []
    for uid, seq in histories.items():
        if len(seq) < min_seq_len:
            continue
        train_items = seq[:-2]
        valid_item = seq[-2]
        test_item = seq[-1]
        splits.append(
            UserSplit(
                user_id=uid,
                train_items=train_items,
                valid_item=valid_item,
                test_item=test_item,
            )
        )
    # Deterministic ordering by user_id for reproducibility.
    splits.sort(key=lambda s: s.user_id)
    total_eligible = len(splits)
    if user_offset:
        splits = splits[user_offset:]
    if max_users is not None:
        splits = splits[:max_users]
    logger.info(
        "Built %d leave-one-out splits (min_seq_len=%d, user_offset=%d, "
        "total_eligible=%d)",
        len(splits), min_seq_len, user_offset, total_eligible,
    )
    return splits


def save_splits(splits: List[UserSplit], path: str) -> int:
    return write_jsonl(path, (s.to_dict() for s in splits))


def load_splits(path: str) -> List[UserSplit]:
    from ..utils.io import read_jsonl

    rows = read_jsonl(path)
    return [
        UserSplit(
            user_id=r["user_id"],
            train_items=r["train_items"],
            valid_item=r["valid_item"],
            test_item=r["test_item"],
        )
        for r in rows
    ]


# --------------------------------------------------------------------------- #
# Sliding-window next-item prediction samples
# --------------------------------------------------------------------------- #


@dataclass
class Sample:
    sample_id: str
    user_id: str
    history_items: List[str]
    positive_item: str
    split: str  # train | valid | test

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sample_id": self.sample_id,
            "user_id": self.user_id,
            "history_items": self.history_items,
            "positive_item": self.positive_item,
            "split": self.split,
        }


def _truncate_history(history: List[str], max_len: int) -> List[str]:
    if max_len is not None and len(history) > max_len:
        return history[-max_len:]
    return history


def build_train_samples(
    splits: List[UserSplit],
    min_history_len: int = 5,
    max_history_len: int = 20,
) -> List[Sample]:
    """Sliding-window samples from train_items.

    For train_items = [i1..iM], for each k from min_history_len..M-1:
        history = i1..ik  (truncated to max_history_len for the prompt)
        positive_item = i(k+1)
    """
    samples: List[Sample] = []
    for sp in splits:
        items = sp.train_items
        M = len(items)
        for k in range(min_history_len, M):
            history = _truncate_history(items[:k], max_history_len)
            positive = items[k]
            sid = f"{sp.user_id}__train__{k}"
            samples.append(
                Sample(
                    sample_id=sid,
                    user_id=sp.user_id,
                    history_items=history,
                    positive_item=positive,
                    split="train",
                )
            )
    logger.info("Built %d train samples", len(samples))
    return samples


def build_valid_samples(
    splits: List[UserSplit], max_history_len: int = 20
) -> List[Sample]:
    samples: List[Sample] = []
    for sp in splits:
        history = _truncate_history(sp.train_items, max_history_len)
        samples.append(
            Sample(
                sample_id=f"{sp.user_id}__valid",
                user_id=sp.user_id,
                history_items=history,
                positive_item=sp.valid_item,
                split="valid",
            )
        )
    logger.info("Built %d valid samples", len(samples))
    return samples


def build_test_samples(
    splits: List[UserSplit], max_history_len: int = 20
) -> List[Sample]:
    samples: List[Sample] = []
    for sp in splits:
        full_history = sp.train_items + [sp.valid_item]
        history = _truncate_history(full_history, max_history_len)
        samples.append(
            Sample(
                sample_id=f"{sp.user_id}__test",
                user_id=sp.user_id,
                history_items=history,
                positive_item=sp.test_item,
                split="test",
            )
        )
    logger.info("Built %d test samples", len(samples))
    return samples
