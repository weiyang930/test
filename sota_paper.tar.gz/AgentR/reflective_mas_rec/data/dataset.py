"""Dataset loading and chronological ordering.

Loads users / items / interactions from the processed sampled dataset and
exposes typed records plus per-user chronologically ordered histories.

Field reference (rednote sampled dataset):
  users:        user_id, profile_fields(dict), llm_output(str)
  items:        note_id, title, content, label, good_attr_raw, parsed_attr(dict)
  interactions: user_id, note_id, conv_time, date_partition  (positive only)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..utils.io import load_table
from ..utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class UserRecord:
    user_id: str
    profile_fields: Dict[str, Any] = field(default_factory=dict)
    llm_output: str = ""


@dataclass
class ItemRecord:
    note_id: str
    title: str = ""
    content: str = ""
    label: str = ""
    good_attr_raw: str = ""
    parsed_attr: Dict[str, Any] = field(default_factory=dict)


def _to_str(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _as_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if value is None:
        return {}
    # parquet may store dict as a string; try a best-effort parse
    if isinstance(value, str):
        from ..utils.json_utils import safe_json_loads

        parsed = safe_json_loads(value, {})
        return parsed if isinstance(parsed, dict) else {}
    return {}


def load_users(path: str) -> Dict[str, UserRecord]:
    rows = load_table(path)
    users: Dict[str, UserRecord] = {}
    for row in rows:
        uid = _to_str(row.get("user_id"))
        if not uid:
            continue
        users[uid] = UserRecord(
            user_id=uid,
            profile_fields=_as_dict(row.get("profile_fields")),
            llm_output=_to_str(row.get("llm_output")),
        )
    logger.info("Loaded %d users from %s", len(users), path)
    return users


def load_items(path: str) -> Dict[str, ItemRecord]:
    rows = load_table(path)
    items: Dict[str, ItemRecord] = {}
    for row in rows:
        nid = _to_str(row.get("note_id"))
        if not nid:
            continue
        items[nid] = ItemRecord(
            note_id=nid,
            title=_to_str(row.get("title")),
            content=_to_str(row.get("content")),
            label=_to_str(row.get("label")),
            good_attr_raw=_to_str(row.get("good_attr_raw")),
            parsed_attr=_as_dict(row.get("parsed_attr")),
        )
    logger.info("Loaded %d items from %s", len(items), path)
    return items


def _parse_conv_time(value: Any) -> Optional[float]:
    """Best-effort parse of conv_time into a sortable numeric timestamp.

    conv_time is frequently empty or "0" in this dataset, so failures are normal.
    """
    if value is None:
        return None
    s = str(value).strip()
    if not s or s == "0":
        return None
    # Numeric epoch (seconds or ms)
    try:
        num = float(s)
        if num <= 0:
            return None
        return num
    except ValueError:
        pass
    # ISO-ish datetime
    try:
        import pandas as pd

        ts = pd.to_datetime(s, errors="coerce")
        if ts is not None and not pd.isna(ts):
            return float(ts.value)  # nanoseconds since epoch
    except Exception:
        pass
    return None


def _parse_date_partition(value: Any) -> Optional[float]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def load_interactions(path: str) -> List[Dict[str, Any]]:
    """Load interactions, preserving original row order via an index."""
    rows = load_table(path)
    out: List[Dict[str, Any]] = []
    for idx, row in enumerate(rows):
        uid = _to_str(row.get("user_id"))
        nid = _to_str(row.get("note_id"))
        if not uid or not nid:
            continue
        out.append(
            {
                "user_id": uid,
                "note_id": nid,
                "conv_time": _to_str(row.get("conv_time")),
                "date_partition": _to_str(row.get("date_partition")),
                "_row_idx": idx,
            }
        )
    logger.info("Loaded %d interactions from %s", len(out), path)
    return out


def order_user_histories(
    interactions: List[Dict[str, Any]],
) -> Dict[str, List[str]]:
    """Group interactions by user and sort chronologically.

    Sorting key per spec 2.2:
      1. conv_time if parseable;
      2. else date_partition;
      3. else original row order.
    To get a *stable, total* order we always include row_idx as a final tiebreaker,
    and use a 3-level sort key where missing values sort consistently.
    """
    from collections import defaultdict

    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in interactions:
        grouped[row["user_id"]].append(row)

    histories: Dict[str, List[str]] = {}
    for uid, rows in grouped.items():
        def sort_key(r: Dict[str, Any]) -> Tuple[int, float, int, float, int]:
            ct = _parse_conv_time(r.get("conv_time"))
            dp = _parse_date_partition(r.get("date_partition"))
            row_idx = int(r.get("_row_idx", 0))
            # Primary: has conv_time -> sort by it. Items with conv_time and
            # without are kept in row order relative to each other via row_idx,
            # so the overall sequence stays stable when timestamps are missing.
            return (
                0 if ct is not None else 1,
                ct if ct is not None else 0.0,
                0 if dp is not None else 1,
                dp if dp is not None else 0.0,
                row_idx,
            )

        ordered = sorted(rows, key=sort_key)
        # Deduplicate while preserving order (defensive; dataset is deduped).
        seen = set()
        seq: List[str] = []
        for r in ordered:
            nid = r["note_id"]
            if nid in seen:
                continue
            seen.add(nid)
            seq.append(nid)
        histories[uid] = seq
    return histories


@dataclass
class Dataset:
    """In-memory dataset bundle."""

    users: Dict[str, UserRecord]
    items: Dict[str, ItemRecord]
    interactions: List[Dict[str, Any]]
    histories: Dict[str, List[str]]
    item_popularity: Dict[str, int]

    @classmethod
    def load(cls, cfg) -> "Dataset":
        users = load_users(str(cfg.data_path(cfg.dataset.user_file)))
        items = load_items(str(cfg.data_path(cfg.dataset.item_file)))
        interactions = load_interactions(
            str(cfg.data_path(cfg.dataset.interaction_file))
        )
        histories = order_user_histories(interactions)

        from collections import Counter

        pop = Counter(r["note_id"] for r in interactions)
        item_popularity = dict(pop)

        logger.info(
            "Dataset ready: users=%d items=%d interactions=%d users_with_history=%d",
            len(users),
            len(items),
            len(interactions),
            len(histories),
        )
        return cls(
            users=users,
            items=items,
            interactions=interactions,
            histories=histories,
            item_popularity=item_popularity,
        )

    def get_user(self, user_id: str) -> Optional[UserRecord]:
        return self.users.get(user_id)

    def get_item(self, note_id: str) -> Optional[ItemRecord]:
        return self.items.get(note_id)
