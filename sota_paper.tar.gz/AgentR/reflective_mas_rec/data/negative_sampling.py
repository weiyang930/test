"""Mixed negative sampling to turn next-item samples into candidate ranking tasks.

Strategies (spec 2.6):
  random_ratio, popular_ratio, same_label_ratio, same_category_ratio.

Rules:
  1. negative must not be in the user's history / valid / test item;
  2. negative must exist in the item table;
  3. sample without replacement;
  4. backfill with random negatives if a strategy is short;
  5. shuffle the final candidate list.
"""
from __future__ import annotations

import json
import random
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .dataset import Dataset, ItemRecord
from .split import Sample, UserSplit
from ..utils.io import write_jsonl
from ..utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class RankSample:
    sample_id: str
    user_id: str
    history_items: List[str]
    positive_item: str
    negative_items: List[str]
    candidate_items: List[str]
    split: str
    # Optional: note_id -> SASRec recall rank (for recall->rerank setting).
    # Empty for legacy samples (fully backward compatible).
    sasrec_rank_map: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "sample_id": self.sample_id,
            "user_id": self.user_id,
            "history_items": self.history_items,
            "positive_item": self.positive_item,
            "negative_items": self.negative_items,
            "candidate_items": self.candidate_items,
            "split": self.split,
        }
        if self.sasrec_rank_map:
            d["sasrec_rank_map"] = self.sasrec_rank_map
        return d


def _primary_label(item: ItemRecord) -> str:
    label = (item.label or "").strip()
    if label:
        return label.split(",")[0].strip()
    return ""


def _category(item: ItemRecord) -> str:
    return str(item.parsed_attr.get("category_l1", "") or "").strip()


class NegativeSampler:
    def __init__(self, dataset: Dataset, cfg, user_splits: List[UserSplit]):
        self.dataset = dataset
        self.cfg = cfg
        self.rng = random.Random(cfg.negative_sampling.seed)

        self.all_items: List[str] = list(dataset.items.keys())

        # Popularity-ranked item list (descending).
        self.popular_items: List[str] = [
            nid
            for nid, _ in sorted(
                dataset.item_popularity.items(), key=lambda x: x[1], reverse=True
            )
        ]

        # label -> [item_ids], category_l1 -> [item_ids]
        self.by_label: Dict[str, List[str]] = defaultdict(list)
        self.by_category: Dict[str, List[str]] = defaultdict(list)
        for nid, item in dataset.items.items():
            lab = _primary_label(item)
            if lab:
                self.by_label[lab].append(nid)
            cat = _category(item)
            if cat:
                self.by_category[cat].append(nid)

        # Per-user forbidden set: full history + valid + test.
        self.forbidden: Dict[str, Set[str]] = {}
        for sp in user_splits:
            forb = set(sp.train_items)
            forb.add(sp.valid_item)
            forb.add(sp.test_item)
            self.forbidden[sp.user_id] = forb

        # cf_hard mode: load per-user CF hard-negative pool.
        self.mode = getattr(cfg.negative_sampling, "mode", "mixed")
        self.cf_hard_pool: Dict[str, List[str]] = {}
        if self.mode == "cf_hard":
            path = cfg.negative_sampling.cf_hard_neg_file
            if not path:
                raise ValueError(
                    "negative_sampling.mode=cf_hard requires cf_hard_neg_file"
                )
            item_set = set(self.all_items)
            n_loaded = 0
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    rec = json.loads(line)
                    uid = str(rec.get("user_id", ""))
                    # keep only items present in the item table
                    pool = [str(x) for x in rec.get("hard_negatives", []) if str(x) in item_set]
                    if uid:
                        self.cf_hard_pool[uid] = pool
                        n_loaded += 1
            logger.info(
                "Loaded CF hard-neg pool for %d users from %s", n_loaded, path
            )

    def _counts(self, k: int) -> Dict[str, int]:
        ns = self.cfg.negative_sampling
        c_random = int(round(k * ns.random_ratio))
        c_pop = int(round(k * ns.popular_ratio))
        c_label = int(round(k * ns.same_label_ratio))
        c_cat = int(round(k * ns.same_category_ratio))
        total = c_random + c_pop + c_label + c_cat
        # Reconcile rounding so the four strategies sum to k (rest -> random).
        c_random += k - total
        if c_random < 0:
            # Trim from the largest non-random bucket.
            deficit = -c_random
            c_random = 0
            for attr in ["pop", "label", "cat"]:
                if deficit <= 0:
                    break
                cur = {"pop": c_pop, "label": c_label, "cat": c_cat}[attr]
                take = min(cur, deficit)
                if attr == "pop":
                    c_pop -= take
                elif attr == "label":
                    c_label -= take
                else:
                    c_cat -= take
                deficit -= take
        return {"random": c_random, "popular": c_pop, "label": c_label, "cat": c_cat}

    def _sample_from(
        self, pool: List[str], n: int, forbidden: Set[str], chosen: Set[str]
    ) -> List[str]:
        if n <= 0 or not pool:
            return []
        candidates = [
            x for x in pool if x not in forbidden and x not in chosen
        ]
        if not candidates:
            return []
        self.rng.shuffle(candidates)
        picked = candidates[:n]
        chosen.update(picked)
        return picked

    def _random_pool(self) -> List[str]:
        return self.all_items

    def _sample_cf_hard(self, sample: Sample, k: int) -> List[str]:
        """cf_hard mode: take top CF hard negatives for this user, then backfill.

        The user's CF pool is ranked best-first. We exclude the sample's own
        positive (and history/valid/test forbidden set), keep CF order for the
        chosen hard negatives, and backfill with random negatives if short.
        """
        forbidden = set(self.forbidden.get(sample.user_id, set()))
        forbidden.update(sample.history_items)
        forbidden.add(sample.positive_item)
        chosen: Set[str] = set()

        ns = self.cfg.negative_sampling
        n_hard = int(round(k * ns.cf_hard_ratio))
        pool = self.cf_hard_pool.get(sample.user_id, [])
        negatives: List[str] = []
        for nid in pool:
            if len(negatives) >= n_hard:
                break
            if nid in forbidden or nid in chosen:
                continue
            negatives.append(nid)
            chosen.add(nid)
        # Backfill (random) to reach k.
        if len(negatives) < k:
            negatives += self._sample_from(
                self._random_pool(), k - len(negatives), forbidden, chosen
            )
        return negatives[:k]

    def sample_negatives(self, sample: Sample, k: int) -> List[str]:
        if self.mode == "cf_hard":
            return self._sample_cf_hard(sample, k)

        forbidden = set(self.forbidden.get(sample.user_id, set()))
        forbidden.update(sample.history_items)
        forbidden.add(sample.positive_item)
        chosen: Set[str] = set()

        pos_item = self.dataset.get_item(sample.positive_item)
        pos_label = _primary_label(pos_item) if pos_item else ""
        pos_cat = _category(pos_item) if pos_item else ""

        counts = self._counts(k)
        negatives: List[str] = []

        # same_label
        negatives += self._sample_from(
            self.by_label.get(pos_label, []), counts["label"], forbidden, chosen
        )
        # same_category
        negatives += self._sample_from(
            self.by_category.get(pos_cat, []), counts["cat"], forbidden, chosen
        )
        # popular
        negatives += self._sample_from(
            self.popular_items, counts["popular"], forbidden, chosen
        )
        # random
        negatives += self._sample_from(
            self._random_pool(), counts["random"], forbidden, chosen
        )

        # Backfill with random until we have k negatives.
        if len(negatives) < k:
            backfill = self._sample_from(
                self._random_pool(), k - len(negatives), forbidden, chosen
            )
            negatives += backfill

        return negatives[:k]

    def build_rank_sample(self, sample: Sample, k: int) -> RankSample:
        negatives = self.sample_negatives(sample, k)
        candidates = [sample.positive_item] + negatives
        self.rng.shuffle(candidates)
        return RankSample(
            sample_id=sample.sample_id,
            user_id=sample.user_id,
            history_items=sample.history_items,
            positive_item=sample.positive_item,
            negative_items=negatives,
            candidate_items=candidates,
            split=sample.split,
        )

    def build_rank_samples(self, samples: List[Sample]) -> List[RankSample]:
        k = self.cfg.negative_sampling.num_negatives
        out = [self.build_rank_sample(s, k) for s in samples]
        logger.info(
            "Built %d rank samples (1 pos + %d negatives)", len(out), k
        )
        return out


def save_rank_samples(samples: List[RankSample], path: str) -> int:
    return write_jsonl(path, (s.to_dict() for s in samples))


def load_rank_samples(path: str) -> List[RankSample]:
    from ..utils.io import read_jsonl

    rows = read_jsonl(path)
    return [
        RankSample(
            sample_id=r["sample_id"],
            user_id=r["user_id"],
            history_items=r["history_items"],
            positive_item=r["positive_item"],
            negative_items=r["negative_items"],
            candidate_items=r["candidate_items"],
            split=r["split"],
            sasrec_rank_map=r.get("sasrec_rank_map", {}),
        )
        for r in rows
    ]
