"""Item compact card construction for LLM prompts (spec 3.1)."""
from __future__ import annotations

from typing import Any, Dict, Optional

from .dataset import ItemRecord


def _clip(text: str, n: int) -> str:
    if text is None:
        return ""
    text = str(text).strip()
    if n is not None and len(text) > n:
        return text[:n].rstrip() + "…"
    return text


def _clean_attr(value: Any) -> str:
    s = str(value or "").strip()
    if s.upper() in ("UNKNOWN", "NONE", "NULL", "NAN"):
        return ""
    return s


def build_item_compact_card(
    item: ItemRecord, max_content_chars: int = 160
) -> Dict[str, Any]:
    """Compact item representation. Returns a dict with stable keys.

    Missing item -> a minimal placeholder card so the pipeline never crashes.
    """
    if item is None:
        return {
            "note_id": "",
            "title": "",
            "label": "",
            "product_name": "",
            "brand_name": "",
            "category_l1": "",
            "category_l2": "",
            "price": "",
            "content_snippet": "",
        }
    attr = item.parsed_attr or {}
    return {
        "note_id": item.note_id,
        "title": _clip(item.title, 80),
        "label": item.label or "",
        "product_name": _clean_attr(attr.get("product_name")),
        "brand_name": _clean_attr(attr.get("brand_name")),
        "category_l1": _clean_attr(attr.get("category_l1")),
        "category_l2": _clean_attr(attr.get("category_l2")),
        "price": _clean_attr(attr.get("price")),
        "content_snippet": _clip(item.content, max_content_chars),
    }


def build_cards_for_ids(
    dataset, note_ids, max_content_chars: int = 160
) -> Dict[str, Dict[str, Any]]:
    cards: Dict[str, Dict[str, Any]] = {}
    for nid in note_ids:
        item = dataset.get_item(nid)
        cards[nid] = build_item_compact_card(item, max_content_chars)
    return cards
