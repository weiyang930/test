"""Build Rank Agent SFT data from traces (spec 13.1).

The corrected output always places the positive candidate first, regardless of
what the prompt-time Rank Agent produced. Reasoning fields are reused from the
trace when available and adjusted to reflect the corrected decision.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from ..llm.prompt_templates import build_rank_prompt
from ..utils.io import iter_jsonl, write_jsonl
from ..utils.json_utils import dumps
from ..utils.logging import get_logger

logger = get_logger(__name__)

INSTRUCTION = (
    "Rank the candidate items by the likelihood that the user will interact with "
    "them next. Output valid JSON."
)

# Body-ordering strategy for the corrected SFT target (positions 2..N).
#   "model"  (default): keep the prompt-time model's predicted order (original behavior).
#   "sasrec": order the non-positive candidates by their SASRec recall rank.
# Rationale: on real-retrieved eval the SASRec body order is already strong
# (positive avg rank ~3.7), but the model rollout body is ~decorrelated from it
# (Spearman ~0.39), so teacher-forcing the rollout body teaches the model to
# scramble positions 2..N -> R@3/R@5/NDCG/MRR regress even when R@1 improves.
# Setting SFT_BODY_ORDER=sasrec makes the target "lift positive to #1, otherwise
# respect SASRec" so body ranking is preserved.
_BODY_ORDER = os.environ.get("SFT_BODY_ORDER", "model").strip().lower()


def _sasrec_rank_map(trace: Dict[str, Any]) -> Dict[str, Any]:
    """candidate_id -> sasrec_rank, from rank_input_candidates."""
    out: Dict[str, Any] = {}
    for c in trace.get("rank_input_candidates") or []:
        cid = c.get("candidate_id")
        if cid is not None:
            out[cid] = c.get("sasrec_rank")
    return out


def _corrected_ranking(trace: Dict[str, Any]) -> List[str]:
    """Positive candidate first, remaining candidates in a body order.

    Body order is controlled by SFT_BODY_ORDER (see module constant):
    "model" keeps the model's rollout order; "sasrec" sorts by SASRec recall rank.
    """
    pos = trace.get("positive_candidate_id")
    cand_ids = list((trace.get("candidate_id_map") or {}).keys())

    if _BODY_ORDER == "sasrec":
        sr = _sasrec_rank_map(trace)
        # Only trust sasrec ordering if every candidate has a rank; else fall back.
        if cand_ids and all(sr.get(c) is not None for c in cand_ids):
            order = sorted(cand_ids, key=lambda c: sr[c])
        else:
            model_ranking = (trace.get("rank_output") or {}).get("ranking") or []
            order = [c for c in model_ranking if c in cand_ids] or cand_ids
    else:
        model_ranking = (trace.get("rank_output") or {}).get("ranking") or []
        order = [c for c in model_ranking if c in cand_ids] or cand_ids

    corrected = [pos] + [c for c in order if c != pos]
    # ensure completeness
    for c in cand_ids:
        if c not in corrected:
            corrected.append(c)
    return corrected


def trace_to_sft_example(trace: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    cand_ids = list((trace.get("candidate_id_map") or {}).keys())
    if not cand_ids:
        return None
    candidates = trace.get("rank_input_candidates") or []
    memory = trace.get("user_memory_before") or trace.get("user_memory_after") or {}
    evidence = trace.get("evidence_output")
    reflection_memory = trace.get("reflection_memory_before")

    system, user_prompt = build_rank_prompt(
        sample_id=trace.get("sample_id", ""),
        user_memory=memory,
        candidates=candidates,
        evidence_guidance=evidence,
        reflection_memory=reflection_memory,
        include_item_memory=bool(trace.get("item_memories")),
    )

    corrected = _corrected_ranking(trace)
    rank_out = trace.get("rank_output") or {}
    refl = trace.get("reflection_output") or {}
    feedback = refl.get("rank_feedback", {}) if isinstance(refl, dict) else {}

    output = {
        "ranking": corrected,
        "top_reason": "The top item best matches the user's validated preference evidence.",
        "decision_rules": feedback.get("preferred_evidence")
        or rank_out.get("decision_rules", [])
        or ["Prioritize behavior-supported preference matches."],
        "used_evidence": feedback.get("preferred_evidence", []) or rank_out.get("used_evidence", []),
        "downweighted_evidence": feedback.get("downweight_evidence", [])
        or rank_out.get("downweighted_evidence", []),
        "uncertainty": rank_out.get("uncertainty", "low"),
    }
    return {
        "instruction": INSTRUCTION,
        "input": user_prompt,
        "output": dumps(output),
        "system": system,
        "meta": {
            "sample_id": trace.get("sample_id"),
            "user_id": trace.get("user_id"),
            "split": trace.get("split"),
            "positive_candidate_id": trace.get("positive_candidate_id"),
        },
    }


def build_sft_data(trace_path: str, output_path: str, limit: Optional[int] = None) -> int:
    examples: List[Dict[str, Any]] = []
    for trace in iter_jsonl(trace_path, limit=limit):
        ex = trace_to_sft_example(trace)
        if ex is not None:
            examples.append(ex)
    n = write_jsonl(output_path, examples)
    logger.info("Wrote %d SFT examples to %s", n, output_path)
    return n
