"""Build per-sample agent inputs (letter candidate IDs + item cards).

Candidate items are presented to agents with stable letter IDs (A, B, C, ...)
to decouple ranking from raw note_ids and reduce ID memorization. We keep a
bidirectional map so metrics can be computed against the ground-truth note_id.
"""
from __future__ import annotations

import string
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..data.item_card import build_item_compact_card


def _letter_ids(n: int) -> List[str]:
    letters = list(string.ascii_uppercase)
    if n <= len(letters):
        return letters[:n]
    # Extend with AA, AB, ... if ever needed (K up to 19 stays single-letter).
    out = list(letters)
    i = 0
    while len(out) < n:
        out.append(letters[i // 26] + letters[i % 26])
        i += 1
    return out[:n]


@dataclass
class SampleContext:
    sample_id: str
    user_id: str
    split: str
    history_items: List[str]
    candidate_note_ids: List[str]
    positive_note_id: str
    candidate_ids: List[str]  # letter ids aligned to candidate_note_ids
    positive_candidate_id: str
    history_cards: List[Dict[str, Any]]
    candidates: List[Dict[str, Any]]  # [{candidate_id, note_id, item_compact_info}]
    note_to_cid: Dict[str, str] = field(default_factory=dict)
    cid_to_note: Dict[str, str] = field(default_factory=dict)

    def ranking_to_note_ids(self, ranking: List[str]) -> List[str]:
        return [self.cid_to_note.get(cid, cid) for cid in ranking]


def build_sample_context(rank_sample, dataset, cfg) -> SampleContext:
    max_chars = cfg.item.max_content_chars
    history_cards = [
        build_item_compact_card(dataset.get_item(nid), max_chars)
        for nid in rank_sample.history_items
    ]
    note_ids = list(rank_sample.candidate_items)
    cids = _letter_ids(len(note_ids))
    note_to_cid = {nid: cids[i] for i, nid in enumerate(note_ids)}
    cid_to_note = {cids[i]: nid for i, nid in enumerate(note_ids)}

    rank_map = getattr(rank_sample, "sasrec_rank_map", {}) or {}
    candidates = []
    for i, nid in enumerate(note_ids):
        info = build_item_compact_card(dataset.get_item(nid), max_chars)
        cand = {"candidate_id": cids[i], "note_id": nid, "item_compact_info": info}
        if nid in rank_map:
            cand["sasrec_rank"] = rank_map[nid]
        candidates.append(cand)

    return SampleContext(
        sample_id=rank_sample.sample_id,
        user_id=rank_sample.user_id,
        split=rank_sample.split,
        history_items=rank_sample.history_items,
        candidate_note_ids=note_ids,
        positive_note_id=rank_sample.positive_item,
        candidate_ids=cids,
        positive_candidate_id=note_to_cid[rank_sample.positive_item],
        history_cards=history_cards,
        candidates=candidates,
        note_to_cid=note_to_cid,
        cid_to_note=cid_to_note,
    )
