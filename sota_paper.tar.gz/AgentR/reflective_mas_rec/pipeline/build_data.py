"""Orchestrate split + sample + negative-sampling construction from raw data."""
from __future__ import annotations

from typing import Dict, List

from ..config import AppConfig
from ..data.dataset import Dataset
from ..data.split import (
    build_leave_one_out_splits,
    build_train_samples,
    build_valid_samples,
    build_test_samples,
    save_splits,
)
from ..data.negative_sampling import NegativeSampler, save_rank_samples
from ..utils.logging import get_logger

logger = get_logger(__name__)


def build_splits(cfg: AppConfig, dataset: Dataset = None):
    dataset = dataset or Dataset.load(cfg)
    splits = build_leave_one_out_splits(
        dataset.histories,
        min_seq_len=cfg.split.min_seq_len,
        max_users=cfg.runtime.max_users,
        user_offset=getattr(cfg.runtime, "user_offset", 0),
    )
    path = str(cfg.out("splits", "splits.jsonl"))
    save_splits(splits, path)
    logger.info("Saved %d splits to %s", len(splits), path)
    return splits, dataset


def build_samples(cfg: AppConfig, dataset: Dataset = None, splits=None):
    if dataset is None or splits is None:
        splits, dataset = build_splits(cfg, dataset)

    train_samples = build_train_samples(
        splits, cfg.split.min_history_len, cfg.split.max_history_len
    )
    valid_samples = build_valid_samples(splits, cfg.split.max_history_len)
    test_samples = build_test_samples(splits, cfg.split.max_history_len)

    sampler = NegativeSampler(dataset, cfg, splits)
    train_rank = sampler.build_rank_samples(train_samples)
    valid_rank = sampler.build_rank_samples(valid_samples)
    test_rank = sampler.build_rank_samples(test_samples)

    save_rank_samples(train_rank, str(cfg.out("samples", "train_rank_samples.jsonl")))
    save_rank_samples(valid_rank, str(cfg.out("samples", "valid_rank_samples.jsonl")))
    save_rank_samples(test_rank, str(cfg.out("samples", "test_rank_samples.jsonl")))
    logger.info(
        "Saved rank samples: train=%d valid=%d test=%d",
        len(train_rank), len(valid_rank), len(test_rank),
    )
    return {
        "train": train_rank,
        "valid": valid_rank,
        "test": test_rank,
        "dataset": dataset,
        "splits": splits,
    }
