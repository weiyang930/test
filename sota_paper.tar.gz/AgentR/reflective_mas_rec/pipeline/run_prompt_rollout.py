"""Prompt-only closed-loop rollout orchestrator (spec 9 & 10).

Pipeline modes (cfg.runtime.pipeline_mode):
  single_llm      : single LLM ranker baseline (no memory/evidence/reflection).
  memory_only     : Memory Agent + Rank Agent.
  memory_evidence : Memory + Evidence + Rank Agent.
  full_mas        : Memory + (Item Memory) + Evidence + Rank + Reflection + Updater.

Leakage rules (spec 20) strictly enforced:
  - Train rollout builds memory/reflection memory per user in chronological order.
  - Valid evaluated with memory built from train history only.
  - Optionally update memory after valid (cfg.evaluation.update_memory_after_valid).
  - Test evaluated using train (+optional valid) memory; test label NEVER used for
    reflection or memory update before test metrics are computed.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List, Optional

from ..config import AppConfig
from ..data.dataset import Dataset
from ..data.negative_sampling import RankSample, load_rank_samples
from ..agents.memory_agent import MemoryAgent
from ..agents.item_memory_agent import ItemMemoryAgent
from ..agents.evidence_agent import EvidenceAgent
from ..agents.rank_agent import RankAgent, SingleLLMRanker
from ..agents.reflection_agent import ReflectionAgent
from ..agents.memory_updater import MemoryUpdater
from ..evaluation.metrics import compute_sample_metrics
from ..evaluation.report import save_report, format_report
from ..llm.client import build_llm_client
from ..llm.mock_handler import mock_handler
from ..utils.io import JsonlWriter
from ..utils.logging import get_logger
from .sample_context import SampleContext, build_sample_context

logger = get_logger(__name__)


MODE_FLAGS = {
    "single_llm": dict(memory=False, evidence=False, reflection=False),
    "memory_only": dict(memory=True, evidence=False, reflection=False),
    "memory_evidence": dict(memory=True, evidence=True, reflection=False),
    "full_mas": dict(memory=True, evidence=True, reflection=True),
}


class RolloutRunner:
    def __init__(self, cfg: AppConfig, dataset: Optional[Dataset] = None) -> None:
        self.cfg = cfg
        self.dataset = dataset or Dataset.load(cfg)

        # Resolve pipeline mode flags (config switches can further disable agents).
        mode = cfg.runtime.pipeline_mode
        flags = dict(MODE_FLAGS.get(mode, MODE_FLAGS["full_mas"]))
        self.use_memory = flags["memory"] and cfg.agents.use_memory_agent
        self.use_evidence = flags["evidence"] and cfg.agents.use_evidence_agent
        self.use_reflection = flags["reflection"] and cfg.agents.use_reflection_agent
        self.use_item_memory = cfg.agents.use_item_memory_agent or cfg.item.use_item_memory_agent
        self.is_single_llm = mode == "single_llm"

        self.client = build_llm_client(cfg.llm)
        if cfg.llm.provider == "mock":
            self.client.set_mock_handler(mock_handler)

        self.memory_agent = MemoryAgent(cfg, self.client) if self.use_memory else None
        self.item_memory_agent = (
            ItemMemoryAgent(cfg, self.client) if self.use_item_memory else None
        )
        self.evidence_agent = EvidenceAgent(cfg, self.client) if self.use_evidence else None
        self.rank_agent = RankAgent(cfg, self.client)
        self.single_ranker = SingleLLMRanker(cfg, self.client) if self.is_single_llm else None
        self.reflection_agent = (
            ReflectionAgent(cfg, self.client) if self.use_reflection else None
        )
        self.updater = MemoryUpdater(cfg) if self.use_reflection else None

        # Per-user persistent state across the closed loop.
        self.user_memory: Dict[str, Dict[str, Any]] = {}
        self.user_reflection: Dict[str, Dict[str, Any]] = {}
        # Cross-user collaborative item memory (note_id -> {collab_notes:[...]}),
        # accumulated from contrastive reflection. This is the AgentCF channel by
        # which unrelated users transfer preference signal through shared items.
        self.collab_item_memory: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------------ #
    def _load_samples(self, split: str) -> List[RankSample]:
        path = str(self.cfg.out("samples", f"{split}_rank_samples.jsonl"))
        samples = load_rank_samples(path)
        if self.cfg.runtime.max_samples is not None:
            samples = samples[: self.cfg.runtime.max_samples]
        return samples

    def _group_by_user(self, samples: List[RankSample]) -> Dict[str, List[RankSample]]:
        grouped: Dict[str, List[RankSample]] = defaultdict(list)
        for s in samples:
            grouped[s.user_id].append(s)
        return grouped

    def _attach_evidence(self, ctx: SampleContext, evidence: Dict[str, Any]) -> None:
        emap = EvidenceAgent.evidence_card_map(evidence)
        for c in ctx.candidates:
            c["evidence_card"] = emap.get(c["candidate_id"])

    def _collab_notes_for(self, card: Dict[str, Any], note_id: str) -> Dict[str, List[str]]:
        """Look up de-noised collaborative audience notes for a candidate.

        De-noising (added after 2000-user run showed noise > signal at scale):
          1. Aggregate notes from the exact item, then feature keys (fallback).
          2. Drop notes whose reinforcement ``count`` is below a threshold when
             stronger notes exist (filters one-off hallucinated audience guesses).
          3. Resolve like/avoid contradiction per candidate: keep only the
             polarity whose total reinforcement count dominates; suppress the
             minority side instead of showing both (which confused the ranker).
        """
        by_item = self.collab_item_memory.get("by_item", {})
        by_feat = self.collab_item_memory.get("by_feature", {})
        min_count = getattr(self.cfg.memory, "collab_min_count", 2)

        pos, neg = [], []  # lists of (content, count)
        seen = set()

        def take(notes):
            for n in sorted(notes, key=lambda x: -x.get("count", 1)):
                key = n["content"][:30]
                if key in seen:
                    continue
                seen.add(key)
                cnt = n.get("count", 1)
                (neg if n.get("polarity") == "negative" else pos).append((n["content"], cnt))

        entry = by_item.get(note_id)
        if entry:
            take(entry.get("notes", []))
        if len(pos) + len(neg) < 4:  # backfill with feature-level signal
            for fk in self.updater.feature_keys(card):
                fe = by_feat.get(fk)
                if fe:
                    take(fe.get("notes", []))

        # Threshold filter: if any note reaches min_count, drop the count==1
        # singletons (likely noise); otherwise keep what little we have.
        def filt(lst):
            strong = [x for x in lst if x[1] >= min_count]
            return strong if strong else lst

        pos, neg = filt(pos), filt(neg)
        pos_w = sum(c for _, c in pos)
        neg_w = sum(c for _, c in neg)

        # Contradiction resolution: keep dominant polarity; suppress minority
        # unless both are comparably supported (within 1.5x).
        out: Dict[str, List[str]] = {}
        if pos and (pos_w >= neg_w or neg_w < 1.5 * pos_w):
            out["likes"] = [c for c, _ in pos[:2]]
        if neg and (neg_w >= pos_w or pos_w < 1.5 * neg_w):
            out["avoids"] = [c for c, _ in neg[:2]]
        return out

    def _attach_collab_memory(self, ctx: SampleContext) -> None:
        """READ side of the AgentCF channel: rank/evidence see "what kind of
        users engaged / avoided this item (or look-alike items)", learned from
        OTHER users' contrastive reflections — i.e. collaborative filtering."""
        if not self.collab_item_memory or self.updater is None:
            return
        for c in ctx.candidates:
            notes = self._collab_notes_for(c.get("item_compact_info", {}), c.get("note_id"))
            if notes:
                c["collab_memory"] = notes

    @staticmethod
    def _category_of(card: Dict[str, Any]) -> str:
        c = card or {}
        return c.get("category_l1") or c.get("category_l2") or (
            (c.get("label") or "").split(",")[0].split("，")[0].strip()
        )

    def exploration_profile(self, history_cards: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Deterministic user exploration signal from history category sequence.

        Counters the false-avoid problem: collaborative 'avoids' notes wrongly
        suppress new-category positives for users who habitually explore. We give
        the ranker an explicit exploration rate + the set of historical
        categories so it can decide how much to trust 'avoids' / category match.
        """
        cats = [self._category_of(c) for c in (history_cards or [])]
        cats = [c for c in cats if c]
        if not cats:
            return {"exploration_rate": 0.5, "history_categories": [], "tendency": "unknown"}
        seen = set()
        novel = 0
        for c in cats:
            if c not in seen:
                novel += 1
            seen.add(c)
        rate = novel / len(cats)
        tendency = "high_explorer" if rate >= 0.6 else ("low_explorer" if rate <= 0.35 else "mixed")
        return {
            "exploration_rate": round(rate, 2),
            "history_categories": sorted(seen)[:12],
            "tendency": tendency,
        }

    def _attach_item_memory(self, ctx: SampleContext) -> None:
        if self.item_memory_agent is None:
            return
        cards = [c["item_compact_info"] for c in ctx.candidates]
        mem_map = self.item_memory_agent.build_many(cards)
        for c in ctx.candidates:
            c["item_memory"] = mem_map.get(c["note_id"])

    # ------------------------------------------------------------------ #
    def _process_sample(
        self,
        ctx: SampleContext,
        user_record,
        allow_reflection: bool,
    ) -> Dict[str, Any]:
        """Run agents for one sample; returns a full trace dict.

        ``allow_reflection`` gates whether reflection + memory update may run
        (must be False for test to prevent label leakage).
        """
        cfg = self.cfg
        user_id = ctx.user_id

        memory_before = self.user_memory.get(user_id)
        reflection_before = self.user_reflection.get(user_id, {"reflection_summary": []})

        # ----- single LLM baseline path -----
        if self.is_single_llm:
            rank_out = self.single_ranker.rank(
                sample_id=ctx.sample_id,
                profile_fields=user_record.profile_fields if user_record else {},
                llm_output=user_record.llm_output if user_record else "",
                history_cards=ctx.history_cards,
                candidates=ctx.candidates,
            )
            return self._finalize_trace(
                ctx, rank_out, memory_before={}, reflection_before={},
                evidence=None, reflection_out=None,
                memory_after={}, reflection_after={},
            )

        # ----- MAS path -----
        # Memory: build/refresh for this sample.
        if self.use_memory:
            memory = self.memory_agent.build(
                user_id=user_id,
                profile_fields=user_record.profile_fields if user_record else {},
                llm_output=user_record.llm_output if user_record else "",
                history_cards=ctx.history_cards,
                sample_id=ctx.sample_id,
                previous_memory=memory_before,
                reflection_memory=reflection_before,
            )
        else:
            memory = {}

        if self.use_item_memory:
            self._attach_item_memory(ctx)
        self._attach_collab_memory(ctx)

        evidence = None
        if self.use_evidence:
            evidence = self.evidence_agent.run(
                sample_id=ctx.sample_id, user_id=user_id, user_memory=memory,
                candidates=ctx.candidates, reflection_memory=reflection_before,
                include_item_memory=self.use_item_memory,
            )
            self._attach_evidence(ctx, evidence)

        rank_out = self.rank_agent.rank(
            sample_id=ctx.sample_id, user_memory=memory, candidates=ctx.candidates,
            evidence_guidance=evidence, reflection_memory=reflection_before,
            include_item_memory=self.use_item_memory, history_cards=ctx.history_cards,
            exploration=self.exploration_profile(ctx.history_cards),
        )

        reflection_out = None
        memory_after = memory
        reflection_after = reflection_before
        if self.use_reflection and allow_reflection:
            reflection_out = self.reflection_agent.run(
                sample_id=ctx.sample_id, user_id=user_id, user_memory=memory,
                candidates=ctx.candidates, rank_output=rank_out,
                ground_truth_positive=ctx.positive_candidate_id,
                evidence_guidance=evidence, reflection_memory=reflection_before,
            )
            note_cards = {c["note_id"]: c.get("item_compact_info", {}) for c in ctx.candidates}
            memory_after, reflection_after = self.updater.update(
                memory, reflection_before,
                reflection_out.get("memory_update_ops", []),
                reflection_out.get("rank_feedback"),
                item_memory_store=self.collab_item_memory,
                note_cards=note_cards,
            )
            # Persist updated state for subsequent samples of this user.
            self.user_memory[user_id] = memory_after
            self.user_reflection[user_id] = reflection_after
        elif self.use_memory:
            # Keep latest memory even without reflection.
            self.user_memory[user_id] = memory

        return self._finalize_trace(
            ctx, rank_out, memory_before=memory_before or {},
            reflection_before=reflection_before, evidence=evidence,
            reflection_out=reflection_out, memory_after=memory_after,
            reflection_after=reflection_after,
        )

    @staticmethod
    def _pop_raw(obj: Optional[Dict[str, Any]]) -> Optional[str]:
        """Extract and remove the private _raw_output from an agent result so it
        is recorded once under trace['raw_outputs'] instead of inside the
        structured output (keeps memory/evidence/reflection blocks clean)."""
        if not isinstance(obj, dict):
            return None
        return obj.pop("_raw_output", None)

    def _finalize_trace(
        self, ctx, rank_out, memory_before, reflection_before, evidence,
        reflection_out, memory_after, reflection_after,
    ) -> Dict[str, Any]:
        # Read parse-success flags before they get stripped, then capture raw
        # model text for every agent.
        evidence_parsed = (
            evidence.get("_parse_success", True) if isinstance(evidence, dict) else None
        )
        reflection_parsed = (
            reflection_out.get("_parse_success", True)
            if isinstance(reflection_out, dict) else False
        )
        raw_outputs = {
            "memory": (
                self.memory_agent.last_raw.pop(ctx.sample_id, None)
                if self.memory_agent is not None else None
            ),
            "evidence": self._pop_raw(evidence),
            "rank": self._pop_raw(rank_out),
            "reflection": self._pop_raw(reflection_out),
        }
        for o in (evidence, reflection_out):
            if isinstance(o, dict):
                o.pop("_parse_success", None)
        ranking_cids = rank_out.get("ranking") or []
        ranking_notes = ctx.ranking_to_note_ids(ranking_cids)
        metrics = compute_sample_metrics(
            ranking_cids, ctx.positive_candidate_id, num_candidates=len(ctx.candidates)
        )
        trace = {
            "sample_id": ctx.sample_id,
            "user_id": ctx.user_id,
            "split": ctx.split,
            "history_items": ctx.history_items,
            "positive_item": ctx.positive_note_id,
            "candidate_items": ctx.candidate_note_ids,
            "candidate_id_map": ctx.cid_to_note,
            "positive_candidate_id": ctx.positive_candidate_id,
            "user_memory_before": memory_before,
            "reflection_memory_before": reflection_before,
            "item_memories": {
                c["note_id"]: c.get("item_memory")
                for c in ctx.candidates
                if c.get("item_memory")
            },
            "evidence_output": evidence,
            "rank_input_candidates": ctx.candidates,
            "rank_output": rank_out,
            "ranking_note_ids": ranking_notes,
            "positive_rank": metrics["positive_rank"],
            "metrics": metrics,
            "reflection_output": reflection_out,
            "user_memory_after": memory_after,
            "reflection_memory_after": reflection_after,
            "raw_outputs": raw_outputs,
            "parse_status": {
                "rank_parse_success": rank_out.get("parse_success", False),
                "rank_ranking_exact": rank_out.get("ranking_exact", False),
                "evidence_parse_success": evidence_parsed,
                "reflection_parse_success": reflection_parsed,
            },
        }
        return trace

    # ------------------------------------------------------------------ #
    def _process_batch(
        self, contexts: List[SampleContext]
    ) -> List[Dict[str, Any]]:
        """Batched processing for one chunk of independent samples.

        Does NOT perform closed-loop reflection/memory updates. Suitable for
        single_llm / memory_only / memory_evidence (all splits) and for
        full_mas valid/test (where there is no within-split memory dependency).
        Uses the latest persisted per-user memory/reflection memory as context.
        """
        if not contexts:
            return []

        # ----- single LLM baseline -----
        if self.is_single_llm:
            reqs = []
            for ctx in contexts:
                ur = self.dataset.get_user(ctx.user_id)
                reqs.append({
                    "sample_id": ctx.sample_id,
                    "profile_fields": ur.profile_fields if ur else {},
                    "llm_output": ur.llm_output if ur else "",
                    "history_cards": ctx.history_cards,
                    "candidates": ctx.candidates,
                })
            rank_outs = self.single_ranker.rank_batch(reqs)
            return [
                self._finalize_trace(
                    ctx, ro, memory_before={}, reflection_before={},
                    evidence=None, reflection_out=None,
                    memory_after={}, reflection_after={},
                )
                for ctx, ro in zip(contexts, rank_outs)
            ]

        # ----- MAS path (no reflection update) -----
        # 1. Memory (batched, cache-aware).
        memories: List[Dict[str, Any]] = []
        if self.use_memory:
            mem_reqs = []
            for ctx in contexts:
                ur = self.dataset.get_user(ctx.user_id)
                mem_reqs.append({
                    "user_id": ctx.user_id,
                    "profile_fields": ur.profile_fields if ur else {},
                    "llm_output": ur.llm_output if ur else "",
                    "history_cards": ctx.history_cards,
                    "sample_id": ctx.sample_id,
                    "previous_memory": self.user_memory.get(ctx.user_id),
                    "reflection_memory": self.user_reflection.get(
                        ctx.user_id, {"reflection_summary": []}
                    ),
                })
            memories = self.memory_agent.build_batch(mem_reqs)
            for ctx, mem in zip(contexts, memories):
                self.user_memory[ctx.user_id] = mem
        else:
            memories = [{} for _ in contexts]

        # 2. Item memory (per candidate, cache-aware).
        if self.use_item_memory:
            for ctx in contexts:
                self._attach_item_memory(ctx)
        # Attach cross-user collaborative memory accumulated during train so that
        # valid/test (which use this non-closed-loop path) also benefit from the
        # collaborative signal. THIS WAS MISSING -> test collab coverage was 0.
        for ctx in contexts:
            self._attach_collab_memory(ctx)

        # 3. Evidence (batched).
        evidences: List[Optional[Dict[str, Any]]] = [None] * len(contexts)
        if self.use_evidence:
            ev_reqs = []
            for ctx, mem in zip(contexts, memories):
                ev_reqs.append({
                    "sample_id": ctx.sample_id, "user_id": ctx.user_id,
                    "user_memory": mem, "candidates": ctx.candidates,
                    "reflection_memory": self.user_reflection.get(
                        ctx.user_id, {"reflection_summary": []}
                    ),
                    "include_item_memory": self.use_item_memory,
                })
            evidences = self.evidence_agent.run_batch(ev_reqs)
            for ctx, ev in zip(contexts, evidences):
                self._attach_evidence(ctx, ev)

        # 4. Rank (batched + batched repair).
        rank_reqs = []
        for ctx, mem, ev in zip(contexts, memories, evidences):
            rank_reqs.append({
                "sample_id": ctx.sample_id, "user_memory": mem,
                "candidates": ctx.candidates, "evidence_guidance": ev,
                "reflection_memory": self.user_reflection.get(
                    ctx.user_id, {"reflection_summary": []}
                ),
                "include_item_memory": self.use_item_memory,
                "history_cards": ctx.history_cards,
                "exploration": self.exploration_profile(ctx.history_cards),
            })
        rank_outs = self.rank_agent.rank_batch(rank_reqs)

        traces = []
        for ctx, mem, ev, ro in zip(contexts, memories, evidences, rank_outs):
            traces.append(self._finalize_trace(
                ctx, ro, memory_before=self.user_memory.get(ctx.user_id, {}),
                reflection_before=self.user_reflection.get(
                    ctx.user_id, {"reflection_summary": []}
                ),
                evidence=ev, reflection_out=None,
                memory_after=mem,
                reflection_after=self.user_reflection.get(
                    ctx.user_id, {"reflection_summary": []}
                ),
            ))
        return traces

    def _process_batch_closed_loop(
        self, contexts: List[SampleContext]
    ) -> List[Dict[str, Any]]:
        """Batched processing WITH reflection + memory update.

        Each context MUST belong to a distinct user (one in-flight sample per
        user) so that within-user memory ordering is preserved. All LLM stages
        (memory/evidence/rank/reflection) are batched across users.
        """
        if not contexts:
            return []

        # 1. Memory (batched).
        mem_reqs = []
        for ctx in contexts:
            ur = self.dataset.get_user(ctx.user_id)
            mem_reqs.append({
                "user_id": ctx.user_id,
                "profile_fields": ur.profile_fields if ur else {},
                "llm_output": ur.llm_output if ur else "",
                "history_cards": ctx.history_cards,
                "sample_id": ctx.sample_id,
                "previous_memory": self.user_memory.get(ctx.user_id),
                "reflection_memory": self.user_reflection.get(
                    ctx.user_id, {"reflection_summary": []}
                ),
            })
        memories = self.memory_agent.build_batch(mem_reqs)
        memories_before = [self.user_memory.get(ctx.user_id) or {} for ctx in contexts]
        reflections_before = [
            self.user_reflection.get(ctx.user_id, {"reflection_summary": []})
            for ctx in contexts
        ]

        # 2. Item memory.
        if self.use_item_memory:
            for ctx in contexts:
                self._attach_item_memory(ctx)
        for ctx in contexts:
            self._attach_collab_memory(ctx)

        # 3. Evidence (batched).
        evidences: List[Optional[Dict[str, Any]]] = [None] * len(contexts)
        if self.use_evidence:
            ev_reqs = []
            for ctx, mem, rb in zip(contexts, memories, reflections_before):
                ev_reqs.append({
                    "sample_id": ctx.sample_id, "user_id": ctx.user_id,
                    "user_memory": mem, "candidates": ctx.candidates,
                    "reflection_memory": rb,
                    "include_item_memory": self.use_item_memory,
                })
            evidences = self.evidence_agent.run_batch(ev_reqs)
            for ctx, ev in zip(contexts, evidences):
                self._attach_evidence(ctx, ev)

        # 4. Rank (batched).
        rank_reqs = []
        for ctx, mem, ev, rb in zip(contexts, memories, evidences, reflections_before):
            rank_reqs.append({
                "sample_id": ctx.sample_id, "user_memory": mem,
                "candidates": ctx.candidates, "evidence_guidance": ev,
                "reflection_memory": rb,
                "include_item_memory": self.use_item_memory,
                "history_cards": ctx.history_cards,
                "exploration": self.exploration_profile(ctx.history_cards),
            })
        rank_outs = self.rank_agent.rank_batch(rank_reqs)

        # 5. Reflection (batched).
        refl_reqs_idx = list(range(len(contexts)))
        refl_outs: List[Optional[Dict[str, Any]]] = [None] * len(contexts)
        refl_payload = []
        for i in refl_reqs_idx:
            ctx = contexts[i]
            refl_payload.append({
                "sample_id": ctx.sample_id, "user_id": ctx.user_id,
                "user_memory": memories[i], "candidates": ctx.candidates,
                "rank_output": rank_outs[i],
                "ground_truth_positive": ctx.positive_candidate_id,
                "evidence_guidance": evidences[i],
                "reflection_memory": reflections_before[i],
            })
        refl_results = self.reflection_agent.run_batch(refl_payload)
        for k, i in enumerate(refl_reqs_idx):
            refl_outs[i] = refl_results[k]

        # 6. Memory update (local, no LLM) + persist per-user state.
        traces = []
        for i, ctx in enumerate(contexts):
            note_cards = {c["note_id"]: c.get("item_compact_info", {}) for c in ctx.candidates}
            mem_after, refl_after = self.updater.update(
                memories[i], reflections_before[i],
                refl_outs[i].get("memory_update_ops", []),
                refl_outs[i].get("rank_feedback"),
                item_memory_store=self.collab_item_memory,
                note_cards=note_cards,
            )
            self.user_memory[ctx.user_id] = mem_after
            self.user_reflection[ctx.user_id] = refl_after
            traces.append(self._finalize_trace(
                ctx, rank_outs[i], memory_before=memories_before[i],
                reflection_before=reflections_before[i], evidence=evidences[i],
                reflection_out=refl_outs[i], memory_after=mem_after,
                reflection_after=refl_after,
            ))
        return traces

    # ------------------------------------------------------------------ #
    def run(self) -> Dict[str, Any]:
        cfg = self.cfg
        train_samples = self._load_samples("train")
        valid_samples = self._load_samples("valid")
        test_samples = self._load_samples("test")

        by_user_train = self._group_by_user(train_samples)
        valid_by_user = {s.user_id: s for s in valid_samples}
        test_by_user = {s.user_id: s for s in test_samples}

        # Determine user order; take a window [user_offset : user_offset+max_users].
        # user_offset lets us shard the full user set across parallel rollout
        # workers (each worker owns a disjoint user window); collab_item_memory
        # is then per-shard (an accepted approximation vs a single global run).
        users = sorted(by_user_train.keys() | valid_by_user.keys() | test_by_user.keys())
        offset = int(getattr(cfg.runtime, "user_offset", 0) or 0)
        if offset:
            users = users[offset:]
        if cfg.runtime.max_users is not None:
            users = users[: cfg.runtime.max_users]

        per_sample_by_split: Dict[str, List[Dict[str, Any]]] = {
            "train": [], "valid": [], "test": []
        }

        save_traces = cfg.runtime.save_traces
        writers: Dict[str, Optional[JsonlWriter]] = {}
        if save_traces:
            for split in ("train", "valid", "test"):
                writers[split] = JsonlWriter(
                    str(cfg.out("traces", f"{split}_traces.jsonl"))
                )

        batch_size = max(1, int(cfg.llm.vllm_batch_size)) if cfg.llm.provider in ("vllm", "huggingface") else 64

        def _emit(split: str, traces: List[Dict[str, Any]]) -> None:
            for tr in traces:
                per_sample_by_split[split].append(tr["metrics"])
                if save_traces:
                    writers[split].write(tr)

        try:
            if not self.use_reflection:
                # ---- Fully batched path (no closed-loop memory update) ----
                for split, sample_lookup in (
                    ("train", by_user_train),
                    ("valid", {u: [s] for u, s in valid_by_user.items()}),
                    ("test", {u: [s] for u, s in test_by_user.items()}),
                ):
                    all_samples = []
                    for u in users:
                        all_samples.extend(sample_lookup.get(u, []))
                    for start in range(0, len(all_samples), batch_size):
                        chunk = all_samples[start : start + batch_size]
                        ctxs = [build_sample_context(s, self.dataset, cfg) for s in chunk]
                        _emit(split, self._process_batch(ctxs))
                    logger.info("Finished split=%s (%d samples)", split, len(all_samples))
            else:
                # ---- full_mas: round-based grouped-parallel closed loop on train ----
                # At round k we process the k-th train sample of every user that
                # still has one. Within a round, contexts come from distinct users,
                # so per-user memory ordering is preserved while all LLM stages are
                # batched across users. valid/test are fully batched afterwards.
                max_rounds = max(
                    (len(by_user_train.get(u, [])) for u in users), default=0
                )
                for k in range(max_rounds):
                    round_samples = [
                        by_user_train[u][k]
                        for u in users
                        if len(by_user_train.get(u, [])) > k
                    ]
                    for start in range(0, len(round_samples), batch_size):
                        chunk = round_samples[start : start + batch_size]
                        ctxs = [build_sample_context(s, self.dataset, cfg) for s in chunk]
                        _emit("train", self._process_batch_closed_loop(ctxs))
                    logger.info(
                        "Train closed-loop round %d/%d (%d samples)",
                        k + 1, max_rounds, len(round_samples),
                    )

                # Optional reflection-after-valid must stay sequential per user.
                allow_valid_reflection = (
                    self.use_reflection and cfg.evaluation.update_memory_after_valid
                )
                if allow_valid_reflection:
                    for user_id in users:
                        if user_id in valid_by_user:
                            ctx = build_sample_context(valid_by_user[user_id], self.dataset, cfg)
                            trace = self._process_sample(
                                ctx, self.dataset.get_user(user_id), allow_reflection=True
                            )
                            _emit("valid", [trace])
                else:
                    valid_list = [valid_by_user[u] for u in users if u in valid_by_user]
                    for start in range(0, len(valid_list), batch_size):
                        chunk = valid_list[start : start + batch_size]
                        ctxs = [build_sample_context(s, self.dataset, cfg) for s in chunk]
                        _emit("valid", self._process_batch(ctxs))

                # Test: always batched, never reflect.
                test_list = [test_by_user[u] for u in users if u in test_by_user]
                for start in range(0, len(test_list), batch_size):
                    chunk = test_list[start : start + batch_size]
                    ctxs = [build_sample_context(s, self.dataset, cfg) for s in chunk]
                    _emit("test", self._process_batch(ctxs))
        finally:
            for w in writers.values():
                if w is not None:
                    w.close()
            for ag in (self.memory_agent, self.item_memory_agent):
                if ag is not None:
                    ag.close()

        report = save_report(
            cfg, per_sample_by_split,
            extra={
                "pipeline_mode": cfg.runtime.pipeline_mode,
                "num_users": len(users),
                "llm_calls": self.client.num_calls,
            },
        )
        logger.info("Evaluation report:\n%s", format_report(report))
        return report


def run_prompt_rollout(cfg: AppConfig, dataset: Optional[Dataset] = None) -> Dict[str, Any]:
    return RolloutRunner(cfg, dataset).run()
