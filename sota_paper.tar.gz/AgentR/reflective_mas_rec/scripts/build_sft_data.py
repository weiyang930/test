"""CLI: build Rank Agent SFT data from traces.

Usage:
  python -m reflective_mas_rec.scripts.build_sft_data \
      --trace_path outputs/exp_v1/traces/train_traces.jsonl \
      --output_path outputs/exp_v1/sft/rank_agent_sft.jsonl
"""
import argparse
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from reflective_mas_rec.pipeline.build_sft_data import build_sft_data
from reflective_mas_rec.utils.logging import setup_logging


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace_path", required=True)
    parser.add_argument("--output_path", required=True)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    setup_logging()
    n = build_sft_data(args.trace_path, args.output_path, limit=args.limit)
    print(f"Wrote {n} SFT examples -> {args.output_path}")


if __name__ == "__main__":
    main()
