"""CLI: run an experiment (data prep optional + rollout + evaluation).

Usage:
  python -m reflective_mas_rec.scripts.run_exp \
      --config configs/exp_prompt_mas.yaml --mode prompt_rollout

  --mode prompt_rollout : build data if missing, then run rollout + eval.
  --build-data          : force rebuild splits + samples first.
  --pipeline-mode       : override cfg.runtime.pipeline_mode
                          (single_llm|memory_only|memory_evidence|full_mas).
"""
import argparse
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from reflective_mas_rec.config import load_config
from reflective_mas_rec.data.dataset import Dataset
from reflective_mas_rec.pipeline.build_data import build_samples
from reflective_mas_rec.pipeline.run_prompt_rollout import run_prompt_rollout
from reflective_mas_rec.evaluation.report import format_report
from reflective_mas_rec.utils.logging import setup_logging, get_logger

logger = get_logger("run_exp")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--mode", default="prompt_rollout")
    parser.add_argument("--build-data", action="store_true")
    parser.add_argument("--pipeline-mode", default=None)
    parser.add_argument("--max-users", type=int, default=None)
    parser.add_argument("--user-offset", type=int, default=None)
    parser.add_argument("--max-samples", type=int, default=None)
    parser.add_argument(
        "--output-dir", default=None,
        help="Override dataset.output_dir (per-shard traces/eval for parallel rollout).",
    )
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.runtime.log_level)

    if args.output_dir is not None:
        cfg.dataset.output_dir = args.output_dir
    if args.pipeline_mode:
        cfg.runtime.pipeline_mode = args.pipeline_mode
    if args.max_users is not None:
        cfg.runtime.max_users = args.max_users
    if args.user_offset is not None:
        cfg.runtime.user_offset = args.user_offset
    if args.max_samples is not None:
        cfg.runtime.max_samples = args.max_samples

    dataset = Dataset.load(cfg)

    samples_path = cfg.out("samples", "test_rank_samples.jsonl")
    if args.build_data or not samples_path.exists():
        logger.info("Building data (splits + samples)...")
        build_samples(cfg, dataset=dataset)

    if args.mode == "prompt_rollout":
        report = run_prompt_rollout(cfg, dataset=dataset)
        print("\n=== Evaluation ===")
        print(format_report(report))
        print(f"\nMetrics saved to: {cfg.out('eval', 'metrics.json')}")
        print(f"Traces saved to:  {cfg.out('traces')}")
    else:
        raise ValueError(f"Unknown mode: {args.mode}")


if __name__ == "__main__":
    main()
