#!/usr/bin/env python3
"""Fine-tune the Rank Agent with LoRA SFT on MAS-produced traces.

Training format
---------------
Each SFT example (built by pipeline/build_sft_data.py) is:
  {
    "instruction": "...",      # ignored at train time (already implied by system)
    "input":  "...full rank prompt: user memory + evidence + candidates...",
    "output": "{\"ranking\": [...], ...}",   # corrected ranking, positive first
    "system": "You are a listwise recommendation ranker...",
    "meta":   {...}
  }

We turn it into a chat completion:
  system:    example["system"]
  user:      example["input"]
  assistant: example["output"]

Loss is computed ONLY on the assistant turn (standard SFT masking), so the model
learns to emit the corrected ranking JSON given the exact MAS context it will see
at inference time. The trained adapter then replaces the prompt-time Rank Agent
inside the MAS pipeline (rank_agent_mode: "trained").

Usage
-----
  python -m reflective_mas_rec.scripts.train_rank_sft \
      --model-name ./models/Qwen/Qwen3-14B \
      --train-data outputs/shared_eval_2000_cfhard/sft/rank_agent_sft.jsonl \
      --output-dir outputs/rank_sft_qwen3_14b \
      --epochs 1 --batch-size 1 --grad-accum-steps 16 --max-length 5120
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import types
from pathlib import Path
from typing import Any, Dict, List, Optional

# PEFT 0.13.2 imports triton.ops (removed in triton >= 3.0) via bitsandbytes.
# Inject a stub so the import doesn't crash when we're not using quantisation.
if "triton.ops" not in sys.modules:
    _ops = types.ModuleType("triton.ops")
    _mpm = types.ModuleType("triton.ops.matmul_perf_model")
    _mpm.early_config_prune = lambda *a, **kw: None
    _mpm.estimate_matmul_time = lambda *a, **kw: 0.0
    sys.modules["triton.ops"] = _ops
    sys.modules["triton.ops.matmul_perf_model"] = _mpm

import torch
from torch.utils.data import DataLoader, Dataset

# Loss scope over the assistant JSON (label side).
#   "full" (default): compute loss on the ENTIRE assistant output, including the
#       whole ranking permutation (original behavior).
#   "top1": compute loss on the JSON structure + the FIRST ranked candidate id,
#       but MASK the loss on ranking positions 2..N (the "body"). Rationale: on
#       real-retrieved the body target is just SASRec's order, so supervising it
#       teaches the model to COPY the sasrec_recall_rank field instead of learning
#       to DISCRIMINATE which candidate is the true next item. Masking the body
#       focuses the gradient entirely on "which item is #1" -> tests whether the
#       body-copy supervision is what caps HR@1 at the SASRec baseline.
_LOSS_SCOPE = os.environ.get("SFT_LOSS_SCOPE", "full").strip().lower()


def _body_char_span(text: str, search_from: int = 0):
    """Char span [mask_start, mask_end) covering ranking positions 2..N.

    Given the assistant JSON `{"ranking": ["A", "B", ...], ...}`, returns the
    span from just after the FIRST id's closing quote up to (but not including)
    the closing ']' — i.e. the `, "B", "C", ..., "Z"` slice. Returns None if the
    array can't be located or has <2 elements (then we fall back to full loss).

    NOTE: `"ranking"` also appears in the USER prompt (the output schema is shown
    there), so we use rfind — the assistant JSON is always the last message, so
    the LAST `"ranking"` occurrence is the assistant's real output array.
    """
    i = text.rfind('"ranking"')
    if i < 0 or i < search_from:
        return None
    lb = text.find('[', i)
    if lb < 0:
        return None
    rb = text.find(']', lb)
    if rb < 0:
        return None
    q1 = text.find('"', lb, rb)          # opening quote of first id
    if q1 < 0:
        return None                       # empty array
    q2 = text.find('"', q1 + 1, rb)       # closing quote of first id
    if q2 < 0:
        return None
    q3 = text.find('"', q2 + 1, rb)       # opening quote of SECOND id (must exist)
    if q3 < 0:
        return None                       # only one element -> nothing to mask
    return (q2 + 1, rb)                    # after first id's close quote .. before ']'


def _load_jsonl(path: Path, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    records = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
            if limit and len(records) >= limit:
                break
    return records


class RankSFTDataset(Dataset):
    """Tokenizes rank SFT examples into (input_ids, labels) with assistant-only loss."""

    def __init__(self, records: List[Dict[str, Any]], tokenizer, max_length: int = 5120,
                 verbose: bool = False, tag: str = ""):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.examples = []
        n_skipped = 0
        import time as _time
        t0 = _time.time()
        total = len(records)
        for i, rec in enumerate(records):
            ex = self._tokenize_one(rec)
            if ex is not None:
                self.examples.append(ex)
            else:
                n_skipped += 1
            if verbose and (i + 1) % 2000 == 0:
                el = _time.time() - t0
                rate = (i + 1) / max(el, 1e-6)
                eta = (total - i - 1) / max(rate, 1e-6)
                print(f"  [tokenize {tag}] {i+1}/{total} "
                      f"({rate:.0f}/s, eta {eta/60:.1f}min)", flush=True)
        self.n_skipped = n_skipped

    def _tokenize_one(self, rec: Dict[str, Any]) -> Optional[Dict[str, torch.Tensor]]:
        system = rec.get("system") or "You are a listwise recommendation ranker."
        user = rec.get("input") or ""
        assistant = rec.get("output") or ""
        if not user or not assistant:
            return None

        messages_full = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
            {"role": "assistant", "content": assistant},
        ]
        messages_prefix = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        # enable_thinking=False keeps Qwen3 from emitting <think> blocks, matching
        # the compact-output contract used during the prompt-time rollout.
        try:
            full_text = self.tokenizer.apply_chat_template(
                messages_full, tokenize=False, add_generation_prompt=False,
                enable_thinking=False,
            )
            prefix_text = self.tokenizer.apply_chat_template(
                messages_prefix, tokenize=False, add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            full_text = self.tokenizer.apply_chat_template(
                messages_full, tokenize=False, add_generation_prompt=False,
            )
            prefix_text = self.tokenizer.apply_chat_template(
                messages_prefix, tokenize=False, add_generation_prompt=True,
            )

        full_enc = self.tokenizer(
            full_text, truncation=True, max_length=self.max_length,
            return_tensors="pt", return_offsets_mapping=(_LOSS_SCOPE == "top1"),
        )
        full_ids = full_enc["input_ids"][0]
        prefix_ids = self.tokenizer(
            prefix_text, truncation=True, max_length=self.max_length,
            return_tensors="pt",
        )["input_ids"][0]

        prefix_len = len(prefix_ids)
        if prefix_len >= len(full_ids):
            return None  # assistant turn truncated away -> no learnable tokens

        labels = full_ids.clone()
        labels[:prefix_len] = -100  # mask system + user

        if _LOSS_SCOPE == "top1":
            # Mask ranking positions 2..N (the body) so loss is only on structure
            # + first id. The assistant JSON starts after the prefix; locate the
            # ranking array in the full_text char space and map to token indices
            # via offset_mapping.
            offsets = full_enc["offset_mapping"][0].tolist()
            # assistant JSON is the last message; _body_char_span uses rfind so
            # it locks onto the assistant's ranking array, not the schema echo in
            # the user prompt. Guard: the array must start after the prefix.
            span = _body_char_span(full_text, search_from=len(prefix_text))
            if span is not None:
                ms, me = span
                for ti in range(prefix_len, len(full_ids)):
                    s, e = offsets[ti]
                    if s == e:  # special tokens have empty (0,0) offsets -> keep
                        continue
                    # mask tokens that overlap the body char span
                    if s >= ms and e <= me:
                        labels[ti] = -100
        return {"input_ids": full_ids, "labels": labels}

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.examples[idx]


def collate_fn(batch, pad_token_id: int):
    max_len = max(ex["input_ids"].size(0) for ex in batch)
    input_ids_padded, labels_padded, attention_masks = [], [], []
    for ex in batch:
        seq_len = ex["input_ids"].size(0)
        pad_len = max_len - seq_len
        input_ids_padded.append(
            torch.cat([ex["input_ids"], torch.full((pad_len,), pad_token_id, dtype=ex["input_ids"].dtype)])
        )
        labels_padded.append(
            torch.cat([ex["labels"], torch.full((pad_len,), -100, dtype=ex["labels"].dtype)])
        )
        attention_masks.append(
            torch.cat([torch.ones(seq_len, dtype=torch.long), torch.zeros(pad_len, dtype=torch.long)])
        )
    return {
        "input_ids": torch.stack(input_ids_padded),
        "labels": torch.stack(labels_padded),
        "attention_mask": torch.stack(attention_masks),
    }


def _setup_dist():
    """Initialize torch.distributed if launched via torchrun. Returns (is_dist, rank, local_rank, world_size)."""
    import torch.distributed as dist
    if "RANK" in os.environ and "WORLD_SIZE" in os.environ:
        rank = int(os.environ["RANK"])
        local_rank = int(os.environ.get("LOCAL_RANK", rank))
        world_size = int(os.environ["WORLD_SIZE"])
        torch.cuda.set_device(local_rank)
        from datetime import timedelta
        dist.init_process_group(backend="nccl", timeout=timedelta(hours=2))
        return True, rank, local_rank, world_size
    return False, 0, 0, 1


def train(args) -> None:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, get_peft_model, TaskType
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel as DDP
    from torch.utils.data.distributed import DistributedSampler

    is_dist, rank, local_rank, world_size = _setup_dist()
    is_main = (rank == 0)
    device = torch.device(f"cuda:{local_rank}")

    def log(*a, **kw):
        if is_main:
            print(*a, **kw, flush=True)

    random.seed(args.seed)
    torch.manual_seed(args.seed)

    log(f"[train] dist={is_dist} world_size={world_size} | loading tokenizer: {args.model_name}")
    tokenizer = AutoTokenizer.from_pretrained(args.model_name, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    log(f"[train] loading data: {args.train_data}")
    records = _load_jsonl(Path(args.train_data), limit=args.limit)
    random.seed(args.seed)  # same split across all ranks
    random.shuffle(records)
    n_valid = max(1, int(len(records) * args.valid_ratio))
    valid_records = records[:n_valid]
    train_records = records[n_valid:]
    log(f"[train] raw records: train={len(train_records):,} valid={len(valid_records):,}")

    # Tokenize ONCE on rank 0, cache to disk, other ranks load the cache.
    # IMPORTANT: the cache key MUST fingerprint the file CONTENT, not just its
    # path -- otherwise a rewritten train_data (same path, different data) hits
    # a stale cache and silently trains on the OLD data. We mix in the file
    # size + mtime + raw record count so any content change busts the cache.
    import hashlib
    _st = Path(args.train_data).stat()
    _content_sig = f"{_st.st_size}:{int(_st.st_mtime)}:{len(records)}"
    # SFT_LOSS_SCOPE changes the LABEL masking, so it MUST be part of the cache
    # key -- otherwise a top1 run silently reuses a cached "full" tokenization
    # (same path/max_length/seed) and trains on the wrong labels.
    cache_key = hashlib.md5(
        f"{args.train_data}|{_content_sig}|{args.max_length}|{args.limit}|{args.valid_ratio}|{args.seed}|scope={_LOSS_SCOPE}".encode()
    ).hexdigest()[:12]
    cache_dir = Path(args.output_dir).parent / "_tok_cache"
    cache_path = cache_dir / f"ranksft_{cache_key}.pt"

    def build_datasets():
        tr = RankSFTDataset(train_records, tokenizer, args.max_length,
                            verbose=is_main, tag="train")
        va = RankSFTDataset(valid_records, tokenizer, args.max_length,
                            verbose=False, tag="valid")
        return tr, va

    if cache_path.exists():
        log(f"[train] loading tokenized cache: {cache_path}")
        blob = torch.load(cache_path, weights_only=False)
        train_ds = RankSFTDataset.__new__(RankSFTDataset)
        train_ds.examples = blob["train_examples"]; train_ds.n_skipped = blob["train_skipped"]
        train_ds.tokenizer = tokenizer; train_ds.max_length = args.max_length
        valid_ds = RankSFTDataset.__new__(RankSFTDataset)
        valid_ds.examples = blob["valid_examples"]; valid_ds.n_skipped = blob["valid_skipped"]
        valid_ds.tokenizer = tokenizer; valid_ds.max_length = args.max_length
    else:
        if is_main:
            log(f"[train] tokenizing on rank0 (will cache -> {cache_path}) ...")
            cache_dir.mkdir(parents=True, exist_ok=True)
            train_ds, valid_ds = build_datasets()
            torch.save({
                "train_examples": train_ds.examples, "train_skipped": train_ds.n_skipped,
                "valid_examples": valid_ds.examples, "valid_skipped": valid_ds.n_skipped,
            }, cache_path)
            log(f"[train] tokenized cache saved -> {cache_path}")
        if is_dist:
            dist.barrier()  # non-main ranks wait for cache
        if not is_main:
            blob = torch.load(cache_path, weights_only=False)
            train_ds = RankSFTDataset.__new__(RankSFTDataset)
            train_ds.examples = blob["train_examples"]; train_ds.n_skipped = blob["train_skipped"]
            train_ds.tokenizer = tokenizer; train_ds.max_length = args.max_length
            valid_ds = RankSFTDataset.__new__(RankSFTDataset)
            valid_ds.examples = blob["valid_examples"]; valid_ds.n_skipped = blob["valid_skipped"]
            valid_ds.tokenizer = tokenizer; valid_ds.max_length = args.max_length
    log(f"[train] tokenized: train={len(train_ds):,} (skipped {train_ds.n_skipped}) "
        f"valid={len(valid_ds):,} (skipped {valid_ds.n_skipped})")

    pad_id = tokenizer.pad_token_id
    if is_dist:
        train_sampler = DistributedSampler(train_ds, num_replicas=world_size, rank=rank, shuffle=True, seed=args.seed)
        valid_sampler = DistributedSampler(valid_ds, num_replicas=world_size, rank=rank, shuffle=False)
    else:
        train_sampler = None
        valid_sampler = None
    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=(train_sampler is None),
        sampler=train_sampler,
        collate_fn=lambda b: collate_fn(b, pad_id), num_workers=2, pin_memory=True,
    )
    valid_loader = DataLoader(
        valid_ds, batch_size=args.batch_size, shuffle=False, sampler=valid_sampler,
        collate_fn=lambda b: collate_fn(b, pad_id), num_workers=2, pin_memory=True,
    )

    log(f"[train] loading base model on {device}: {args.model_name}")
    model = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        torch_dtype=torch.bfloat16,
        trust_remote_code=True,
        attn_implementation="flash_attention_2" if args.flash_attn else None,
    )
    model.config.use_cache = False

    lora_cfg = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
        bias="none",
    )
    model = get_peft_model(model, lora_cfg)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.to(device)
    if is_main:
        model.print_trainable_parameters()
    if is_dist:
        model = DDP(model, device_ids=[local_rank], output_device=local_rank,
                    find_unused_parameters=False, gradient_as_bucket_view=True)
    base_model = model.module if is_dist else model

    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.learning_rate, weight_decay=0.01,
    )
    total_steps = max(1, len(train_loader) // args.grad_accum_steps * args.epochs)
    warmup = int(total_steps * args.warmup_ratio)

    def lr_lambda(step):
        if step < warmup:
            return step / max(1, warmup)
        progress = (step - warmup) / max(1, total_steps - warmup)
        import math
        return 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * min(1.0, progress)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    out_dir = Path(args.output_dir)
    if is_main:
        out_dir.mkdir(parents=True, exist_ok=True)
    if is_dist:
        dist.barrier()
    loss_log = None
    if is_main:
        loss_log = open(out_dir / "loss_log.csv", "w", encoding="utf-8")
        loss_log.write("epoch,step,train_loss,valid_loss,lr\n")
        loss_log.flush()

    def all_reduce_scalar(val: float) -> float:
        if not is_dist:
            return val
        t = torch.tensor([val], device=device, dtype=torch.float64)
        dist.all_reduce(t, op=dist.ReduceOp.SUM)
        return t.item()

    def save_adapter(path: Path):
        if is_main:
            base_model.save_pretrained(path)
            tokenizer.save_pretrained(path)
            print(f"  saved adapter -> {path}", flush=True)
        if is_dist:
            dist.barrier()

    best_valid = float("inf")
    global_step = 0

    for epoch in range(1, args.epochs + 1):
        if is_dist and train_sampler is not None:
            train_sampler.set_epoch(epoch)
        model.train()
        run_loss, run_tok = 0.0, 0
        optimizer.zero_grad()
        for step, batch in enumerate(train_loader, start=1):
            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            attn = batch["attention_mask"].to(device)
            out = model(input_ids=input_ids, attention_mask=attn, labels=labels)
            loss = out.loss / args.grad_accum_steps
            loss.backward()

            n_active = (labels != -100).sum().item()
            run_loss += out.loss.item() * n_active
            run_tok += n_active

            if step % args.grad_accum_steps == 0:
                torch.nn.utils.clip_grad_norm_(
                    [p for p in model.parameters() if p.requires_grad], 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                global_step += 1

                if args.save_steps > 0 and global_step % args.save_steps == 0:
                    save_adapter(out_dir / f"checkpoint_step{global_step}")

            if step % args.log_steps == 0:
                avg = run_loss / max(run_tok, 1)
                lr_now = scheduler.get_last_lr()[0]
                log(f"  [ep {epoch}] step {step}/{len(train_loader)} "
                    f"loss={avg:.4f} lr={lr_now:.2e}")
                if is_main:
                    loss_log.write(f"{epoch},{step},{avg:.6f},,{lr_now:.2e}\n")
                    loss_log.flush()

        # validation (aggregate across ranks)
        model.eval()
        v_loss, v_tok = 0.0, 0
        with torch.no_grad():
            for batch in valid_loader:
                input_ids = batch["input_ids"].to(device)
                labels = batch["labels"].to(device)
                attn = batch["attention_mask"].to(device)
                out = model(input_ids=input_ids, attention_mask=attn, labels=labels)
                n_active = (labels != -100).sum().item()
                v_loss += out.loss.item() * n_active
                v_tok += n_active
        v_loss = all_reduce_scalar(v_loss)
        v_tok = all_reduce_scalar(v_tok)
        tr_loss_g = all_reduce_scalar(run_loss)
        tr_tok_g = all_reduce_scalar(run_tok)
        valid_loss = v_loss / max(v_tok, 1)
        train_loss = tr_loss_g / max(tr_tok_g, 1)
        log(f"[ep {epoch}] train_loss={train_loss:.4f} valid_loss={valid_loss:.4f}")
        if is_main:
            loss_log.write(f"{epoch},epoch_end,{train_loss:.6f},{valid_loss:.6f},"
                           f"{scheduler.get_last_lr()[0]:.2e}\n")
            loss_log.flush()

        save_adapter(out_dir / f"checkpoint_epoch{epoch}")
        if valid_loss < best_valid:
            best_valid = valid_loss
            save_adapter(out_dir / "best_checkpoint")
            log(f"  *** new best valid_loss={valid_loss:.4f}")

    # merge LoRA into base for fast vLLM serving (rank 0 only)
    if is_main:
        print("\n[train] merging LoRA into base ...", flush=True)
        merged = out_dir / "merged_model"
        merged_model = base_model.merge_and_unload()
        merged_model.save_pretrained(merged, safe_serialization=True)
        tokenizer.save_pretrained(merged)
        print(f"[train] merged model -> {merged}", flush=True)

        meta = {
            "base_model": args.model_name,
            "lora_rank": args.lora_rank, "lora_alpha": args.lora_alpha,
            "epochs": args.epochs, "learning_rate": args.learning_rate,
            "batch_size": args.batch_size, "grad_accum_steps": args.grad_accum_steps,
            "effective_batch": args.batch_size * args.grad_accum_steps * world_size,
            "max_length": args.max_length, "train_examples": len(train_ds),
            "valid_examples": len(valid_ds), "best_valid_loss": best_valid,
            "merged_model_dir": str(merged), "world_size": world_size,
        }
        (out_dir / "training_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        loss_log.close()
        print(f"[train] done. meta -> {out_dir/'training_meta.json'}", flush=True)
    if is_dist:
        dist.barrier()
        dist.destroy_process_group()


def main():
    p = argparse.ArgumentParser(description="LoRA SFT for the MAS Rank Agent")
    p.add_argument("--model-name", default="./models/Qwen/Qwen3-14B")
    p.add_argument("--train-data", required=True)
    p.add_argument("--output-dir", default="outputs/rank_sft_qwen3_14b")
    p.add_argument("--epochs", type=int, default=1)
    p.add_argument("--batch-size", type=int, default=1)
    p.add_argument("--grad-accum-steps", type=int, default=16)
    p.add_argument("--learning-rate", type=float, default=1e-4)
    p.add_argument("--max-length", type=int, default=5120)
    p.add_argument("--lora-rank", type=int, default=16)
    p.add_argument("--lora-alpha", type=int, default=32)
    p.add_argument("--lora-dropout", type=float, default=0.05)
    p.add_argument("--warmup-ratio", type=float, default=0.03)
    p.add_argument("--valid-ratio", type=float, default=0.02)
    p.add_argument("--save-steps", type=int, default=200)
    p.add_argument("--log-steps", type=int, default=10)
    p.add_argument("--limit", type=int, default=None, help="cap #records (debug)")
    p.add_argument("--flash-attn", action="store_true")
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    print(f"[train] config: {vars(args)}", flush=True)
    train(args)


if __name__ == "__main__":
    main()
