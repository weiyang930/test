#!/usr/bin/env python3
"""Lightweight evaluation of a trained Rank Agent, isolating the rank stage.

We reuse the prompt-time MAS traces (which already contain the user memory,
evidence cards, candidates and reflection memory built by the *prompt* model)
and ONLY re-run the ranking step with a trained model. This:

  * isolates the variable (only the ranker changes; memory/evidence are fixed),
  * is fast (only N test samples, no train closed loop), and
  * uses the exact same build_rank_prompt() as SFT, so the eval prompt matches
    the training input distribution.

Usage:
  python -m reflective_mas_rec.scripts.eval_trained_rank \
      --model ./outputs/rank_sft_qwen3_14b/merged_model \
      --trace outputs/shared_eval_500_cfhard/traces/test_traces.jsonl \
      --out   outputs/eval_trained_cfhard_500/eval_test_trained.json \
      --tp 8 --max-model-len 12288
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from reflective_mas_rec.llm.prompt_templates import build_rank_prompt
from reflective_mas_rec.llm.parsers import parse_rank_output
from reflective_mas_rec.evaluation.metrics import compute_sample_metrics, aggregate_metrics, reported_metric_keys


def _iter_jsonl(path: str):
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True, help="trained (merged) model path")
    p.add_argument("--trace", required=True, help="prompt-time trace jsonl (has memory+evidence)")
    p.add_argument("--out", required=True)
    p.add_argument("--tp", type=int, default=8)
    p.add_argument("--max-model-len", type=int, default=12288)
    p.add_argument("--max-tokens", type=int, default=1024)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--gpu-mem", type=float, default=0.9)
    p.add_argument("--enable-thinking", action="store_true")
    args = p.parse_args()

    traces = list(_iter_jsonl(args.trace))
    print(f"[eval] loaded {len(traces)} traces from {args.trace}", flush=True)

    # Build rank prompts identical to SFT input.
    prompts: List[str] = []
    system_prompt = None
    metas: List[Dict[str, Any]] = []
    for tr in traces:
        cand_ids = list((tr.get("candidate_id_map") or {}).keys())
        candidates = tr.get("rank_input_candidates") or []
        memory = tr.get("user_memory_before") or tr.get("user_memory_after") or {}
        evidence = tr.get("evidence_output")
        refl_mem = tr.get("reflection_memory_before")
        system, user_prompt = build_rank_prompt(
            sample_id=tr.get("sample_id", ""), user_memory=memory, candidates=candidates,
            evidence_guidance=evidence, reflection_memory=refl_mem,
            include_item_memory=bool(tr.get("item_memories")),
        )
        system_prompt = system
        prompts.append(user_prompt)
        metas.append({
            "sample_id": tr.get("sample_id"),
            "cand_ids": cand_ids,
            "positive_candidate_id": tr.get("positive_candidate_id"),
            "split": tr.get("split"),
        })

    # Load vLLM and generate.
    from vllm import LLM, SamplingParams
    print(f"[eval] loading vLLM model={args.model} tp={args.tp}", flush=True)
    llm = LLM(
        model=args.model, tensor_parallel_size=args.tp,
        gpu_memory_utilization=args.gpu_mem, max_model_len=args.max_model_len,
        trust_remote_code=True, dtype="auto", enforce_eager=True,
        enable_prefix_caching=True,
    )
    sp = SamplingParams(temperature=0.0, max_tokens=args.max_tokens)

    chat_kwargs: Dict[str, Any] = {}
    if not args.enable_thinking:
        chat_kwargs["chat_template_kwargs"] = {"enable_thinking": False}

    texts: List[str] = []
    bs = max(1, args.batch_size)
    for start in range(0, len(prompts), bs):
        chunk = prompts[start:start + bs]
        convs = [[{"role": "system", "content": system_prompt},
                  {"role": "user", "content": c}] for c in chunk]
        try:
            outs = llm.chat(convs, sampling_params=sp, use_tqdm=True, **chat_kwargs)
        except TypeError:
            outs = llm.chat(convs, sampling_params=sp, use_tqdm=True)
        for o in outs:
            texts.append(o.outputs[0].text.strip())
        print(f"[eval] generated {min(start+bs, len(prompts))}/{len(prompts)}", flush=True)

    # Parse + metrics.
    per_sample = []
    parse_fail = 0
    for meta, text in zip(metas, texts):
        cand_ids = meta["cand_ids"]
        fallback = cand_ids
        parsed = parse_rank_output(text, cand_ids, fallback)
        if not parsed.get("parse_success"):
            parse_fail += 1
        ranking = parsed.get("ranking") or fallback
        pos = meta["positive_candidate_id"]
        m = compute_sample_metrics(ranking, pos, num_candidates=len(cand_ids))
        m["sample_id"] = meta["sample_id"]
        per_sample.append(m)

    agg = aggregate_metrics(per_sample)
    rk = reported_metric_keys(agg.get("num_candidates", 10))
    summary = {
        "model": args.model,
        "trace": args.trace,
        "count": agg["count"],
        "parse_fail": parse_fail,
        **{k: agg[k] for k in rk if k in agg},
        "positive_rank": agg["positive_rank"],
        "reported_keys": rk,
    }
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    # also dump per-sample
    ps_path = out_path.with_suffix(".per_sample.jsonl")
    with open(ps_path, "w", encoding="utf-8") as f:
        for m in per_sample:
            f.write(json.dumps(m) + "\n")

    print("\n=== Trained Rank Eval ===", flush=True)
    print(json.dumps(summary, indent=2), flush=True)
    print(f"\nsaved -> {out_path}", flush=True)


if __name__ == "__main__":
    main()
