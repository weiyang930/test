"""CLI: build leave-one-out splits.

Usage:
  python -m reflective_mas_rec.scripts.build_splits --config configs/exp_prompt_mas.yaml
"""
import argparse
import os
import sys

# Ensure package is importable whether run as -m or as a direct file.
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from reflective_mas_rec.config import load_config
from reflective_mas_rec.pipeline.build_data import build_splits
from reflective_mas_rec.utils.logging import setup_logging


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.runtime.log_level)
    splits, _ = build_splits(cfg)
    print(f"Built {len(splits)} splits -> {cfg.out('splits', 'splits.jsonl')}")


if __name__ == "__main__":
    main()
