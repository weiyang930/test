"""CLI: build candidate ranking samples (train/valid/test).

Usage:
  python -m reflective_mas_rec.scripts.build_samples --config configs/exp_prompt_mas.yaml
"""
import argparse
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from reflective_mas_rec.config import load_config
from reflective_mas_rec.pipeline.build_data import build_samples
from reflective_mas_rec.utils.logging import setup_logging


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.runtime.log_level)
    result = build_samples(cfg)
    print(
        f"train={len(result['train'])} valid={len(result['valid'])} "
        f"test={len(result['test'])} -> {cfg.out('samples')}"
    )


if __name__ == "__main__":
    main()
