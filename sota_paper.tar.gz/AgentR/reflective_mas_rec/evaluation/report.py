"""Aggregate and persist evaluation results."""
from __future__ import annotations

from typing import Any, Dict, List

from .metrics import aggregate_metrics
from ..utils.io import write_json, write_jsonl
from ..utils.logging import get_logger

logger = get_logger(__name__)


def build_report(
    per_sample_by_split: Dict[str, List[Dict[str, Any]]],
    extra: Dict[str, Any] = None,
) -> Dict[str, Any]:
    report: Dict[str, Any] = {"splits": {}}
    for split, rows in per_sample_by_split.items():
        report["splits"][split] = aggregate_metrics(rows)
    if extra:
        report.update(extra)
    return report


def save_report(
    cfg,
    per_sample_by_split: Dict[str, List[Dict[str, Any]]],
    extra: Dict[str, Any] = None,
) -> Dict[str, Any]:
    report = build_report(per_sample_by_split, extra)
    write_json(str(cfg.out("eval", "metrics.json")), report)
    # per-sample
    flat: List[Dict[str, Any]] = []
    for split, rows in per_sample_by_split.items():
        flat.extend(rows)
    write_jsonl(str(cfg.out("eval", "per_sample_metrics.jsonl")), flat)
    return report


def format_report(report: Dict[str, Any]) -> str:
    lines = []
    for split, agg in report.get("splits", {}).items():
        keys = agg.get("reported_keys", [])
        parts = [f"{k}={agg.get(k, 0.0):.4f}" for k in keys]
        lines.append(
            f"[{split}] n={agg.get('count', 0)} "
            f"(candidates={agg.get('num_candidates')}) " + " ".join(parts)
        )
    return "\n".join(lines)
