"""Ranking metrics for next-item prediction over a candidate list.

Single-relevant-item setting (leave-one-out): each sample has exactly ONE
positive, so all metrics are a function of the positive's 1-indexed rank.
  - recall@k == hr@k == 1[rank<=k]  (with one relevant item, hit == full recall)
  - ndcg@k   == 1/log2(rank+1) if rank<=k else 0   (IDCG=1, so == its DCG)
  - ndcg@1   == recall@1 (1/log2(2)=1); recall@1 == hr@1.
We report recall@{1,3,5,10} and ndcg@{1,3,5,10} (+ mrr, positive_rank). hr@k
aliases are kept for backward compatibility with older result files/callers.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

# k values reported for both recall@k and ndcg@k.
K_VALUES: List[int] = [1, 3, 5, 10]


def positive_rank(ranking: List[str], positive_id: str) -> int:
    """1-indexed rank of the positive item; len+1 if missing (worst case)."""
    try:
        return ranking.index(positive_id) + 1
    except ValueError:
        return len(ranking) + 1


def hr_at_k(rank: int, k: int) -> float:
    return 1.0 if rank <= k else 0.0


def ndcg_at_k(rank: int, k: int) -> float:
    """Single-relevant-item NDCG@k. IDCG = 1 (best position)."""
    if rank <= k:
        return 1.0 / math.log2(rank + 1)
    return 0.0


def mrr(rank: int) -> float:
    return 1.0 / rank if rank > 0 else 0.0


def metrics_from_rank(rank: int, num_candidates: Optional[int] = None) -> Dict[str, Any]:
    """Build the full metric dict from a 1-indexed positive rank alone.

    This is the offline-recompute entry point: any saved per-sample record that
    carries the positive's integer rank can be re-expanded into the full metric
    set without re-running inference.
    """
    m: Dict[str, Any] = {"positive_rank": rank, "mrr": mrr(rank)}
    if num_candidates is not None:
        m["num_candidates"] = num_candidates
    for k in K_VALUES:
        m[f"recall@{k}"] = hr_at_k(rank, k)
        m[f"ndcg@{k}"] = ndcg_at_k(rank, k)
    # backward-compat aliases (recall@k == hr@k)
    m["hr@1"] = m["recall@1"]
    m["hr@5"] = m["recall@5"]
    m["hr@10"] = m["recall@10"]
    return m


def compute_sample_metrics(
    ranking: List[str], positive_id: str, num_candidates: Optional[int] = None
) -> Dict[str, Any]:
    rank = positive_rank(ranking, positive_id)
    nc = num_candidates if num_candidates is not None else len(ranking)
    return metrics_from_rank(rank, num_candidates=nc)


def reported_metric_keys(num_candidates: int) -> List[str]:
    """Full metric key set to report. recall@10/ndcg@10 are trivial when the
    candidate list has <=10 items (positive always inside), but we still report
    them for a uniform table across candidate-set sizes."""
    keys: List[str] = []
    for k in K_VALUES:
        keys.append(f"recall@{k}")
    for k in K_VALUES:
        keys.append(f"ndcg@{k}")
    keys.append("mrr")
    return keys


def aggregate_metrics(per_sample: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not per_sample:
        return {"count": 0}
    keys: List[str] = []
    for k in K_VALUES:
        keys.append(f"recall@{k}")
    for k in K_VALUES:
        keys.append(f"ndcg@{k}")
    keys += ["mrr", "positive_rank", "hr@1", "hr@5", "hr@10"]
    agg: Dict[str, Any] = {"count": len(per_sample)}
    for k in keys:
        vals = [m[k] for m in per_sample if k in m]
        if vals:
            agg[k] = sum(vals) / len(vals)
    nc = per_sample[0].get("num_candidates", len(per_sample))
    agg["num_candidates"] = nc
    agg["reported_keys"] = reported_metric_keys(nc)
    return agg
