# reflective_mas_rec — core multi-agent recommender package

Used by every stage of the pipeline; see the top-level `README.md` for how to run it.

- `agents/`: Memory, Evidence, Rank (prompt mode), Reflection and MemoryUpdater agents
  (plus an optional item-memory agent).
- `llm/`: LLM client (`vllm` in-process batched, `huggingface`, `openai_compatible`,
  `mock`), prompt templates and robust JSON/ranking parsers.
- `data/`: demo-schema dataset loader, leave-one-out splits, negative sampling
  (`cf_hard` = SASRec hard negatives), item cards.
- `pipeline/`:
  - `build_data.py`: splits → rank samples;
  - `run_prompt_rollout.py`: closed-loop rollout, one of the pipeline modes `full_mas`,
    `memory_evidence`, `memory_only`, `single_llm`;
  - `build_sft_data.py`: rank-agent SFT data from traces.
- `scripts/`:
  - `run_exp.py`: rollout (`--user-offset/--max-users` for sharding);
  - `build_sft_data.py`;
  - `train_rank_sft.py`: LoRA SFT, DDP, content-fingerprinted tokenization cache, auto-merge;
  - `eval_trained_rank.py`: trained rank agent on cf_hard traces;
  - `build_splits.py`, `build_samples.py`.
- `evaluation/`: HR / NDCG / MRR and reporting.

Configs are rendered per dataset from `configs/templates/` into `outputs/<ds>/configs/` by
`agentr_paths.py --make-configs`. The `mock` provider (`llm.provider: mock`) runs the whole
rollout on CPU for wiring checks.
