"""MemoryUpdater: apply reflection memory_update_ops to user + reflection memory.

For the MVP this supports summary-memory updates: add risk rule, strengthen
stable preference, weaken profile hypothesis, revise conflict note, annotate.
Unapplicable ops are appended as a risk rule or reflection note (spec 8).
"""
from __future__ import annotations

import copy
from typing import Any, Dict, List, Optional

from ..config import AppConfig
from ..utils.logging import get_logger

logger = get_logger(__name__)

_CONF_ORDER = ["low", "medium", "high"]


def _as_text(value: Any) -> str:
    """Coerce an LLM-produced field to a plain string.

    Real models sometimes return a dict/list where a string is expected (e.g.
    ``content`` as a nested object). Flatten such cases instead of crashing.
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        # Prefer a 'content'/'text' field, else join values.
        for k in ("content", "text", "value", "description"):
            if isinstance(value.get(k), str):
                return value[k].strip()
        return " ".join(_as_text(v) for v in value.values()).strip()
    if isinstance(value, (list, tuple)):
        return " ".join(_as_text(v) for v in value).strip()
    return str(value).strip()


def _bump_confidence(level: str, delta: str) -> str:
    if level not in _CONF_ORDER:
        level = "medium"
    idx = _CONF_ORDER.index(level)
    if delta == "small_positive":
        idx = min(idx + 1, len(_CONF_ORDER) - 1)
    elif delta == "small_negative":
        idx = max(idx - 1, 0)
    return _CONF_ORDER[idx]


class MemoryUpdater:
    def __init__(self, cfg: AppConfig) -> None:
        self.cfg = cfg
        self.max_reflection_rules = cfg.memory.max_reflection_rules

    def update(
        self,
        user_memory: Dict[str, Any],
        reflection_memory: Optional[Dict[str, Any]],
        memory_update_ops: List[Dict[str, Any]],
        rank_feedback: Optional[Dict[str, Any]] = None,
        item_memory_store: Optional[Dict[str, Dict[str, Any]]] = None,
        note_cards: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> (Dict[str, Any], Dict[str, Any]):
        """Apply reflection ops. When ``item_memory_store`` is provided,
        ``scope=item`` ops accumulate cross-user audience notes both onto the
        exact item (``by_item``) and onto its FEATURE keys (``by_feature``:
        category/brand/price), so zero-exposure new items at test time can still
        inherit a collaborative audience profile from look-alike items.

        ``note_cards`` maps note_id -> item_compact_info (for feature keys).
        """
        memory = copy.deepcopy(user_memory) if user_memory else {}
        refl = copy.deepcopy(reflection_memory) if reflection_memory else {"reflection_summary": []}
        if "reflection_summary" not in refl or not isinstance(refl["reflection_summary"], list):
            refl["reflection_summary"] = []

        ltm = memory.setdefault("long_term_memory", {})
        ltm.setdefault("stable_preferences", [])
        ltm.setdefault("profile_hypotheses", [])
        ltm.setdefault("negative_preferences", [])
        ltm.setdefault("risk_rules", [])
        ltm.setdefault("conflict_notes", [])

        for op in memory_update_ops or []:
            if not isinstance(op, dict):
                continue
            self._apply_op(memory, refl, op, item_memory_store, note_cards)

        # Fold rank_feedback.corrective_rule into reflection memory.
        if rank_feedback:
            rule = _as_text(rank_feedback.get("corrective_rule"))
            if rule:
                self._add_reflection_rule(refl, rule)

        self._compact_reflection(refl)
        return memory, refl

    @staticmethod
    def _price_bucket(price: str) -> str:
        try:
            p = float(str(price).replace("¥", "").replace(",", "").strip())
        except (TypeError, ValueError):
            return ""
        if p < 50:
            return "low"
        if p < 200:
            return "mid"
        if p < 1000:
            return "high"
        return "premium"

    def feature_keys(self, card: Optional[Dict[str, Any]]) -> List[str]:
        """Generalizable feature keys for an item (coarse enough to transfer to
        unseen items, specific enough to discriminate).

        Many items have empty structured category fields but ALWAYS carry a
        ``label`` (e.g. "笔记本电脑,电脑") that encodes the category. We fall back
        to the label's primary segment so feature-level collaborative
        generalization covers ~all items, not just the ~54% with category_l2.
        """
        if not card:
            return []
        c1 = _as_text(card.get("category_l1"))
        c2 = _as_text(card.get("category_l2"))
        brand = _as_text(card.get("brand_name"))
        pb = self._price_bucket(card.get("price"))
        # Category proxy: prefer structured cat2, then cat1, then label head.
        cat = c2 or c1
        if not cat:
            label = _as_text(card.get("label"))
            if label:
                cat = label.split(",")[0].split("，")[0].strip()
        keys: List[str] = []
        if cat:
            keys.append(f"cat:{cat}")
            if pb:
                keys.append(f"cat:{cat}|price:{pb}")
            if brand:
                keys.append(f"cat:{cat}|brand:{brand}")
        return keys

    def _add_note(self, bucket: List[Dict[str, Any]], content: str, polarity: str) -> None:
        """Append a polarity-tagged note with dedup-by-prefix + count, capped."""
        for n in bucket:
            if n.get("polarity") == polarity and content[:25] and content[:25] in n.get("content", ""):
                n["count"] = n.get("count", 1) + 1
                return
        bucket.append({"content": content, "polarity": polarity, "count": 1})
        cap = self.cfg.memory.max_reflection_rules
        if len(bucket) > cap * 2:
            bucket.sort(key=lambda x: -x.get("count", 1))
            del bucket[cap * 2:]

    def _apply_item_op(
        self,
        store: Dict[str, Dict[str, Any]],
        note_id: str,
        content: str,
        polarity: str,
        card: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Accumulate a cross-user audience note onto the exact item AND its
        feature keys. The feature-level store lets zero-exposure test items
        inherit an audience profile from look-alike items (the collaborative
        generalization channel)."""
        if not content:
            return
        by_item = store.setdefault("by_item", {})
        by_feat = store.setdefault("by_feature", {})
        if note_id:
            entry = by_item.setdefault(note_id, {"note_id": note_id, "notes": []})
            self._add_note(entry["notes"], content, polarity)
        for fk in self.feature_keys(card):
            entry = by_feat.setdefault(fk, {"feature": fk, "notes": []})
            self._add_note(entry["notes"], content, polarity)

    def _apply_op(
        self,
        memory: Dict[str, Any],
        refl: Dict[str, Any],
        op: Dict[str, Any],
        item_memory_store: Optional[Dict[str, Dict[str, Any]]] = None,
        note_cards: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> None:
        action = _as_text(op.get("op")).lower()
        scope = _as_text(op.get("scope")).lower()
        content = _as_text(op.get("content"))
        delta = _as_text(op.get("confidence_delta")) or "none"

        # Item-scoped collaborative update (AgentCF core signal).
        if scope == "item":
            note_id = _as_text(op.get("target_note_id")) or _as_text(op.get("target"))
            if item_memory_store is not None:
                polarity = "negative" if delta == "small_negative" else "positive"
                card = (note_cards or {}).get(note_id)
                self._apply_item_op(item_memory_store, note_id, content, polarity, card)
            return

        evidence = op.get("evidence", []) or []
        if not isinstance(evidence, list):
            evidence = [evidence]
        ltm = memory["long_term_memory"]

        if not content:
            return

        if scope == "reflection_memory":
            self._add_reflection_rule(refl, content)
            return

        if scope == "risk_rule" or action == "add" and scope not in (
            "short_term", "long_term", "bank_fragment"
        ):
            ltm["risk_rules"].append(
                {"content": content, "source": "reflection", "confidence": "medium"}
            )
            return

        if scope == "long_term":
            if action in ("add", "revise"):
                ltm["stable_preferences"].append(
                    {
                        "content": content,
                        "source": "reflection",
                        "confidence": "medium",
                        "evidence": evidence,
                    }
                )
            elif action == "strengthen":
                self._adjust_existing(ltm["stable_preferences"], content, "small_positive")
            elif action == "weaken":
                self._adjust_existing(ltm["profile_hypotheses"], content, "small_negative")
            elif action == "annotate":
                ltm["conflict_notes"].append(
                    {"conflict": content, "suggested_resolution": ""}
                )
            else:
                ltm["risk_rules"].append(
                    {"content": content, "source": "reflection", "confidence": "medium"}
                )
            return

        if scope == "short_term":
            stm = memory.setdefault("short_term_memory", {})
            stm.setdefault("short_term_constraints", [])
            stm["short_term_constraints"].append(content)
            return

        # Fallback: anything we cannot place becomes a risk rule.
        ltm["risk_rules"].append(
            {"content": content, "source": "reflection", "confidence": "medium"}
        )

    @staticmethod
    def _adjust_existing(entries: List[Dict[str, Any]], content: str, delta: str) -> None:
        target = None
        for e in entries:
            if isinstance(e, dict) and content[:20] and content[:20] in str(e.get("content", "")):
                target = e
                break
        if target is None and entries:
            target = entries[0]
        if target is not None:
            target["confidence"] = _bump_confidence(target.get("confidence", "medium"), delta)

    def _add_reflection_rule(self, refl: Dict[str, Any], rule: str) -> None:
        rule = rule.strip()
        if not rule:
            return
        existing = refl["reflection_summary"]
        # dedup by prefix similarity
        for r in existing:
            if rule[:25] and rule[:25] in r:
                return
        existing.append(rule)

    def _compact_reflection(self, refl: Dict[str, Any]) -> None:
        rules = refl["reflection_summary"]
        if len(rules) > self.max_reflection_rules:
            # Keep the most recent N rules.
            refl["reflection_summary"] = rules[-self.max_reflection_rules:]
