"""Base agent: shared LLM call + JSON parse + simple JSONL cache."""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from ..config import AppConfig
from ..llm.client import LLMClient
from ..utils.io import JsonlWriter, read_jsonl
from ..utils.json_utils import safe_json_loads
from ..utils.logging import get_logger

logger = get_logger(__name__)


class JsonlCache:
    """Append-only JSONL cache keyed by a string ``key`` field."""

    def __init__(self, path: str, enabled: bool = True) -> None:
        self.path = path
        self.enabled = enabled
        self._store: Dict[str, Any] = {}
        self._writer: Optional[JsonlWriter] = None
        if enabled and os.path.exists(path):
            for row in read_jsonl(path):
                k = row.get("key")
                if k is not None:
                    self._store[k] = row.get("value")

    def get(self, key: str) -> Optional[Any]:
        if not self.enabled:
            return None
        return self._store.get(key)

    def put(self, key: str, value: Any) -> None:
        if not self.enabled:
            return
        self._store[key] = value
        if self._writer is None:
            self._writer = JsonlWriter(self.path, mode="a")
        self._writer.write({"key": key, "value": value})

    def close(self) -> None:
        if self._writer is not None:
            self._writer.close()
            self._writer = None


def _looks_truncated(text: Any) -> bool:
    """Heuristic: a JSON-expecting output that does not close its top-level
    object is almost always a max_tokens truncation."""
    if not isinstance(text, str):
        return False
    s = text.rstrip()
    return bool(s) and not (s.endswith("}") or s.endswith("]") or s.endswith("```"))


class BaseAgent:
    name: str = "base"
    agent_key: str = "base"  # used to resolve per-agent model config / meta

    def __init__(self, cfg: AppConfig, client: LLMClient) -> None:
        self.cfg = cfg
        self.client = client
        self.model_cfg = cfg.agent_model(self.agent_key)
        # Count of outputs that failed to parse and look truncated (for a
        # single end-of-run warning instead of per-call log spam).
        self._truncated_count = 0
        self._parse_fail_count = 0

    def _note_parse_failure(self, text: Any) -> None:
        self._parse_fail_count += 1
        if _looks_truncated(text):
            self._truncated_count += 1
            if self._truncated_count in (1, 10, 100) or self._truncated_count % 500 == 0:
                logger.warning(
                    "[%s] output looks TRUNCATED (no closing brace); likely "
                    "max_tokens=%d too small. truncated=%d parse_fail=%d",
                    self.name, self.model_cfg.max_tokens,
                    self._truncated_count, self._parse_fail_count,
                )

    def _call_json(
        self,
        system_prompt: str,
        user_prompt: str,
        fallback: Dict[str, Any],
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Call the LLM and parse JSON, returning ``fallback`` on failure."""
        meta = meta or {}
        text = self.client.generate(
            user_prompt,
            system_prompt=system_prompt,
            model_name=self.model_cfg.model,
            temperature=self.model_cfg.temperature,
            max_tokens=self.model_cfg.max_tokens,
            response_format="json",
            meta=meta,
        )
        parsed = safe_json_loads(text, fallback=None)
        if isinstance(parsed, dict):
            result = parsed
            result.setdefault("_parse_success", True)
        else:
            result = dict(fallback)
            result["_parse_success"] = False
            self._note_parse_failure(text)
        result["_raw_output"] = text
        return result

    def _call_json_batch(
        self,
        system_prompt: str,
        user_prompts: List[str],
        fallbacks: List[Dict[str, Any]],
        metas: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """Batched LLM JSON call. One shared system prompt across the batch."""
        if not user_prompts:
            return []
        texts = self.client.generate_batch(
            user_prompts,
            system_prompt=system_prompt,
            model_name=self.model_cfg.model,
            temperature=self.model_cfg.temperature,
            max_tokens=self.model_cfg.max_tokens,
            response_format="json",
            metas=metas,
        )
        out: List[Dict[str, Any]] = []
        for text, fb in zip(texts, fallbacks):
            parsed = safe_json_loads(text, fallback=None)
            if isinstance(parsed, dict):
                parsed.setdefault("_parse_success", True)
                parsed["_raw_output"] = text
                out.append(parsed)
            else:
                res = dict(fb)
                res["_parse_success"] = False
                res["_raw_output"] = text
                self._note_parse_failure(text)
                out.append(res)
        return out
