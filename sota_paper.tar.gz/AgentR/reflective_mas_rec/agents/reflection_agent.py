"""ReflectionAgent: post-ranking diagnosis -> rank_feedback + memory_update_ops.

Runs ONLY when ground-truth labels are available (train/valid). Must never
reveal the answer as a rule.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseAgent
from ..config import AppConfig
from ..llm.client import LLMClient
from ..llm.prompt_templates import build_reflection_prompt
from ..utils.logging import get_logger

logger = get_logger(__name__)


def find_top_negative(ranking: List[str], positive_cid: str) -> Optional[str]:
    """Highest-ranked candidate that is NOT the positive (the worst mistake)."""
    for cid in ranking or []:
        if cid != positive_cid:
            return cid
    return None


def _card_for_cid(candidates: List[Dict[str, Any]], cid: Optional[str]) -> Optional[Dict[str, Any]]:
    if cid is None:
        return None
    for c in candidates:
        if c.get("candidate_id") == cid:
            return c
    return None


def _fallback_reflection(
    sample_id: str, ranking: List[str], ground_truth_positive: str
) -> Dict[str, Any]:
    pos = ranking.index(ground_truth_positive) if ground_truth_positive in ranking else -1
    success = pos == 0
    return {
        "sample_id": sample_id,
        "reflection_type": "success" if success else "failure",
        "contrastive_insight": {
            "positive_vs_negative": "",
            "discriminative_signal": "" if success else "unknown",
            "why_ranker_failed": "" if success else "Positive not ranked first.",
        },
        "rank_feedback": {
            "corrective_rule": "",
            "training_use": "can_be_used_for_sft_or_dpo",
        },
        "memory_update_ops": [],
    }


class ReflectionAgent(BaseAgent):
    name = "ReflectionAgent"
    agent_key = "reflection_agent"

    def run(
        self,
        sample_id: str,
        user_id: str,
        user_memory: Dict[str, Any],
        candidates: List[Dict[str, Any]],
        rank_output: Dict[str, Any],
        ground_truth_positive: str,
        evidence_guidance: Optional[Dict[str, Any]] = None,
        reflection_memory: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        ranking = rank_output.get("ranking") or []
        pos_rank = ranking.index(ground_truth_positive) + 1 if ground_truth_positive in ranking else None
        top_neg = find_top_negative(ranking, ground_truth_positive)
        pos_card = _card_for_cid(candidates, ground_truth_positive)
        neg_card = _card_for_cid(candidates, top_neg)
        system, user_prompt = build_reflection_prompt(
            sample_id=sample_id,
            user_id=user_id,
            user_memory=user_memory,
            candidates=candidates,
            rank_output=rank_output,
            ground_truth_positive=ground_truth_positive,
            evidence_guidance=evidence_guidance,
            reflection_memory=reflection_memory,
            positive_card=pos_card,
            top_negative_card=neg_card,
            positive_rank=pos_rank,
        )
        meta = {
            "agent": "reflection",
            "sample_id": sample_id,
            "user_id": user_id,
            "rank_ranking": ranking,
            "ground_truth_positive": ground_truth_positive,
            "top_negative": top_neg,
        }
        fallback = _fallback_reflection(sample_id, ranking, ground_truth_positive)
        out = self._call_json(system, user_prompt, fallback, meta=meta)
        return self._normalize(out, fallback, candidates)

    @staticmethod
    def _normalize(
        out: Dict[str, Any],
        fallback: Dict[str, Any],
        candidates: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        if not isinstance(out, dict):
            out = dict(fallback)
        out.setdefault("sample_id", fallback["sample_id"])
        out.setdefault("reflection_type", fallback["reflection_type"])
        out.setdefault("contrastive_insight", fallback["contrastive_insight"])
        out.setdefault("rank_feedback", fallback["rank_feedback"])
        if not isinstance(out.get("memory_update_ops"), list):
            out["memory_update_ops"] = []
        else:
            # The model sees items by letter candidate_id; translate any
            # item-scoped target back to the stable real note_id so the
            # collaborative item memory is keyed consistently across samples.
            cid2note = {}
            for c in (candidates or []):
                cid2note[str(c.get("candidate_id"))] = c.get("note_id")
            for op in out["memory_update_ops"]:
                if not isinstance(op, dict):
                    continue
                tgt = str(op.get("target_note_id") or op.get("target") or "")
                if tgt in cid2note and cid2note[tgt]:
                    op["target_note_id"] = cid2note[tgt]
        return out

    def run_batch(self, requests: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batched reflection.

        ``requests``: dicts with keys sample_id, user_id, user_memory, candidates,
        rank_output, ground_truth_positive, evidence_guidance, reflection_memory.
        """
        if not requests:
            return []
        prompts, metas, fallbacks = [], [], []
        system_prompt = None
        for req in requests:
            ranking = (req["rank_output"] or {}).get("ranking") or []
            gt = req["ground_truth_positive"]
            pos_rank = ranking.index(gt) + 1 if gt in ranking else None
            top_neg = find_top_negative(ranking, gt)
            pos_card = _card_for_cid(req["candidates"], gt)
            neg_card = _card_for_cid(req["candidates"], top_neg)
            system, user_prompt = build_reflection_prompt(
                sample_id=req["sample_id"], user_id=req["user_id"],
                user_memory=req["user_memory"], candidates=req["candidates"],
                rank_output=req["rank_output"],
                ground_truth_positive=gt,
                evidence_guidance=req.get("evidence_guidance"),
                reflection_memory=req.get("reflection_memory"),
                positive_card=pos_card, top_negative_card=neg_card,
                positive_rank=pos_rank,
            )
            system_prompt = system
            prompts.append(user_prompt)
            metas.append({
                "agent": "reflection", "sample_id": req["sample_id"],
                "user_id": req["user_id"], "rank_ranking": ranking,
                "ground_truth_positive": gt, "top_negative": top_neg,
            })
            fallbacks.append(_fallback_reflection(req["sample_id"], ranking, gt))

        parsed = self._call_json_batch(system_prompt, prompts, fallbacks, metas)
        return [
            self._normalize(o, fb, req["candidates"])
            for o, fb, req in zip(parsed, fallbacks, requests)
        ]
