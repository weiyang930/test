"""RankAgent (MAS-conditioned listwise ranker) + single-LLM baseline ranker.

Both produce a normalized rank output dict. RankAgent supports a repair retry
when the ranking is not an exact permutation, and a heuristic fallback ordering
based on lexical overlap with the user's recent history.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseAgent
from ..config import AppConfig
from ..llm.client import LLMClient
from ..llm.prompt_templates import build_rank_prompt, build_single_llm_prompt
from ..llm.parsers import parse_rank_output
from ..utils.logging import get_logger

logger = get_logger(__name__)


def _tokens(text: str) -> set:
    if not text:
        return set()
    for s in ",/|;:：，。、 \t\n（）()【】[]":
        text = text.replace(s, " ")
    return {t for t in text.lower().split() if t}


def _candidate_text(cand: Dict[str, Any]) -> str:
    info = cand.get("item_compact_info", {}) or {}
    return " ".join(
        str(info.get(k, ""))
        for k in ("title", "product_name", "label", "category_l1", "category_l2", "brand_name")
    )


def heuristic_ranking(candidates: List[Dict[str, Any]], context_text: str) -> List[str]:
    ctx = _tokens(context_text)
    scored = []
    for i, c in enumerate(candidates):
        overlap = len(ctx & _tokens(_candidate_text(c)))
        scored.append((overlap, -i, c.get("candidate_id")))
    scored.sort(reverse=True)
    return [cid for _, _, cid in scored]


def _context_text_from_history(history_cards: List[Dict[str, Any]]) -> str:
    parts = []
    for c in history_cards:
        for k in ("title", "product_name", "label", "category_l1", "category_l2", "brand_name"):
            if c.get(k):
                parts.append(str(c[k]))
    return " ".join(parts)


def _context_text_from_memory(memory: Dict[str, Any]) -> str:
    parts: List[str] = []
    ltm = memory.get("long_term_memory", {}) or {}
    for entry in ltm.get("stable_preferences", []) or []:
        if isinstance(entry, dict):
            parts.append(str(entry.get("content", "")))
    stm = memory.get("short_term_memory", {}) or {}
    parts += [str(x) for x in (stm.get("recent_intents") or [])]
    parts += [str(x) for x in (memory.get("ranking_guidance") or [])]
    return " ".join(parts)


class RankAgent(BaseAgent):
    name = "RankAgent"
    agent_key = "rank_agent"

    def rank(
        self,
        sample_id: str,
        user_memory: Dict[str, Any],
        candidates: List[Dict[str, Any]],
        evidence_guidance: Optional[Dict[str, Any]] = None,
        reflection_memory: Optional[Dict[str, Any]] = None,
        include_item_memory: bool = False,
        history_cards: Optional[List[Dict[str, Any]]] = None,
        exploration: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        candidate_ids = [c.get("candidate_id") for c in candidates]
        context_text = _context_text_from_memory(user_memory)
        if history_cards:
            context_text += " " + _context_text_from_history(history_cards)
        fallback_ranking = heuristic_ranking(candidates, context_text)

        meta = {
            "agent": "rank",
            "sample_id": sample_id,
            "candidates": candidates,
            "rank_context_text": context_text,
        }

        system, user_prompt = build_rank_prompt(
            sample_id=sample_id,
            user_memory=user_memory,
            candidates=candidates,
            evidence_guidance=evidence_guidance,
            reflection_memory=reflection_memory,
            include_item_memory=include_item_memory,
            exploration=exploration,
        )
        text = self.client.generate(
            user_prompt, system_prompt=system, model_name=self.model_cfg.model,
            temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
            response_format="json", meta=meta,
        )
        parsed = parse_rank_output(text, candidate_ids, fallback_ranking)
        parsed["_raw_output"] = text

        # Repair retry if not an exact permutation but parse succeeded.
        if parsed["parse_success"] and not parsed["ranking_exact"]:
            system_r, user_prompt_r = build_rank_prompt(
                sample_id=sample_id, user_memory=user_memory, candidates=candidates,
                evidence_guidance=evidence_guidance, reflection_memory=reflection_memory,
                include_item_memory=include_item_memory,
                repair_hint="Previous output ranking was not a valid permutation. "
                "Output 'ranking' as a JSON array containing every candidate_id exactly once.",
            )
            text_r = self.client.generate(
                user_prompt_r, system_prompt=system_r, model_name=self.model_cfg.model,
                temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
                response_format="json", meta=meta,
            )
            parsed_r = parse_rank_output(text_r, candidate_ids, fallback_ranking)
            parsed_r["_raw_output"] = text_r
            if parsed_r["ranking_exact"]:
                parsed = parsed_r

        parsed["sample_id"] = sample_id
        return parsed


    def rank_batch(self, requests: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batched ranking with a single batched repair pass.

        ``requests``: dicts with keys sample_id, user_memory, candidates,
        evidence_guidance, reflection_memory, include_item_memory, history_cards.
        """
        if not requests:
            return []
        prompts: List[str] = []
        metas: List[Dict[str, Any]] = []
        cand_ids_list: List[List[str]] = []
        fallbacks: List[List[str]] = []
        system_prompt = None
        for req in requests:
            candidates = req["candidates"]
            candidate_ids = [c.get("candidate_id") for c in candidates]
            context_text = _context_text_from_memory(req["user_memory"])
            if req.get("history_cards"):
                context_text += " " + _context_text_from_history(req["history_cards"])
            system, user_prompt = build_rank_prompt(
                sample_id=req["sample_id"], user_memory=req["user_memory"],
                candidates=candidates, evidence_guidance=req.get("evidence_guidance"),
                reflection_memory=req.get("reflection_memory"),
                include_item_memory=req.get("include_item_memory", False),
                exploration=req.get("exploration"),
            )
            system_prompt = system
            prompts.append(user_prompt)
            metas.append({
                "agent": "rank", "sample_id": req["sample_id"],
                "candidates": candidates, "rank_context_text": context_text,
            })
            cand_ids_list.append(candidate_ids)
            fallbacks.append(heuristic_ranking(candidates, context_text))

        texts = self.client.generate_batch(
            prompts, system_prompt=system_prompt, model_name=self.model_cfg.model,
            temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
            response_format="json", metas=metas,
        )
        parsed_list = []
        for i, t in enumerate(texts):
            p = parse_rank_output(t, cand_ids_list[i], fallbacks[i])
            p["_raw_output"] = t
            parsed_list.append(p)

        # Batched repair pass for non-exact-but-parsed outputs.
        repair_idx = [
            i for i, p in enumerate(parsed_list)
            if p["parse_success"] and not p["ranking_exact"]
        ]
        if repair_idx:
            r_prompts, r_metas = [], []
            for i in repair_idx:
                req = requests[i]
                _, up = build_rank_prompt(
                    sample_id=req["sample_id"], user_memory=req["user_memory"],
                    candidates=req["candidates"], evidence_guidance=req.get("evidence_guidance"),
                    reflection_memory=req.get("reflection_memory"),
                    include_item_memory=req.get("include_item_memory", False),
                    exploration=req.get("exploration"),
                    repair_hint="Output 'ranking' as a JSON array with every candidate_id exactly once.",
                )
                r_prompts.append(up)
                r_metas.append(metas[i])
            r_texts = self.client.generate_batch(
                r_prompts, system_prompt=system_prompt, model_name=self.model_cfg.model,
                temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
                response_format="json", metas=r_metas,
            )
            for j, i in enumerate(repair_idx):
                pr = parse_rank_output(r_texts[j], cand_ids_list[i], fallbacks[i])
                pr["_raw_output"] = r_texts[j]
                if pr["ranking_exact"]:
                    parsed_list[i] = pr

        for i, req in enumerate(requests):
            parsed_list[i]["sample_id"] = req["sample_id"]
        return parsed_list


class SingleLLMRanker(BaseAgent):
    """Baseline: single LLM ranker with no memory/evidence/reflection (spec 9.1)."""

    name = "SingleLLMRanker"
    agent_key = "rank_agent"

    def rank(
        self,
        sample_id: str,
        profile_fields: Optional[Dict[str, Any]],
        llm_output: str,
        history_cards: List[Dict[str, Any]],
        candidates: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        candidate_ids = [c.get("candidate_id") for c in candidates]
        context_text = _context_text_from_history(history_cards) + " " + (llm_output or "")
        fallback_ranking = heuristic_ranking(candidates, context_text)

        eff_profile = profile_fields if self.cfg.agents.use_profile_fields else None
        eff_persona = llm_output if self.cfg.agents.use_llm_output else ""

        meta = {
            "agent": "single_llm",
            "sample_id": sample_id,
            "candidates": candidates,
            "rank_context_text": context_text,
        }
        system, user_prompt = build_single_llm_prompt(
            sample_id=sample_id, profile_fields=eff_profile, llm_output=eff_persona,
            history_cards=history_cards, candidates=candidates,
        )
        text = self.client.generate(
            user_prompt, system_prompt=system, model_name=self.model_cfg.model,
            temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
            response_format="json", meta=meta,
        )
        parsed = parse_rank_output(text, candidate_ids, fallback_ranking)
        parsed["_raw_output"] = text
        if parsed["parse_success"] and not parsed["ranking_exact"]:
            system_r, user_prompt_r = build_single_llm_prompt(
                sample_id=sample_id, profile_fields=eff_profile, llm_output=eff_persona,
                history_cards=history_cards, candidates=candidates,
                repair_hint="Output 'ranking' as a JSON array with every candidate_id exactly once.",
            )
            text_r = self.client.generate(
                user_prompt_r, system_prompt=system_r, model_name=self.model_cfg.model,
                temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
                response_format="json", meta=meta,
            )
            parsed_r = parse_rank_output(text_r, candidate_ids, fallback_ranking)
            parsed_r["_raw_output"] = text_r
            if parsed_r["ranking_exact"]:
                parsed = parsed_r
        parsed["sample_id"] = sample_id
        return parsed

    def rank_batch(self, requests: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batched single-LLM ranking with a batched repair pass.

        ``requests``: dicts with keys sample_id, profile_fields, llm_output,
        history_cards, candidates.
        """
        if not requests:
            return []
        prompts, metas, cand_ids_list, fallbacks = [], [], [], []
        eff_list = []
        system_prompt = None
        for req in requests:
            candidates = req["candidates"]
            candidate_ids = [c.get("candidate_id") for c in candidates]
            llm_output = req.get("llm_output", "")
            context_text = _context_text_from_history(req.get("history_cards", [])) + " " + (llm_output or "")
            eff_profile = req.get("profile_fields") if self.cfg.agents.use_profile_fields else None
            eff_persona = llm_output if self.cfg.agents.use_llm_output else ""
            eff_list.append((eff_profile, eff_persona))
            system, user_prompt = build_single_llm_prompt(
                sample_id=req["sample_id"], profile_fields=eff_profile, llm_output=eff_persona,
                history_cards=req.get("history_cards", []), candidates=candidates,
            )
            system_prompt = system
            prompts.append(user_prompt)
            metas.append({
                "agent": "single_llm", "sample_id": req["sample_id"],
                "candidates": candidates, "rank_context_text": context_text,
            })
            cand_ids_list.append(candidate_ids)
            fallbacks.append(heuristic_ranking(candidates, context_text))

        texts = self.client.generate_batch(
            prompts, system_prompt=system_prompt, model_name=self.model_cfg.model,
            temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
            response_format="json", metas=metas,
        )
        parsed_list = []
        for i, t in enumerate(texts):
            p = parse_rank_output(t, cand_ids_list[i], fallbacks[i])
            p["_raw_output"] = t
            parsed_list.append(p)
        repair_idx = [
            i for i, p in enumerate(parsed_list)
            if p["parse_success"] and not p["ranking_exact"]
        ]
        if repair_idx:
            r_prompts, r_metas = [], []
            for i in repair_idx:
                req = requests[i]
                eff_profile, eff_persona = eff_list[i]
                _, up = build_single_llm_prompt(
                    sample_id=req["sample_id"], profile_fields=eff_profile, llm_output=eff_persona,
                    history_cards=req.get("history_cards", []), candidates=req["candidates"],
                    repair_hint="Output 'ranking' as a JSON array with every candidate_id exactly once.",
                )
                r_prompts.append(up)
                r_metas.append(metas[i])
            r_texts = self.client.generate_batch(
                r_prompts, system_prompt=system_prompt, model_name=self.model_cfg.model,
                temperature=self.model_cfg.temperature, max_tokens=self.model_cfg.max_tokens,
                response_format="json", metas=r_metas,
            )
            for j, i in enumerate(repair_idx):
                pr = parse_rank_output(r_texts[j], cand_ids_list[i], fallbacks[i])
                pr["_raw_output"] = r_texts[j]
                if pr["ranking_exact"]:
                    parsed_list[i] = pr
        for i, req in enumerate(requests):
            parsed_list[i]["sample_id"] = req["sample_id"]
        return parsed_list
