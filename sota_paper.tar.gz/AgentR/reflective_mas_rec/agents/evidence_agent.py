"""EvidenceAgent: validate candidate-level evidence (does NOT rank)."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseAgent
from ..config import AppConfig
from ..llm.client import LLMClient
from ..llm.prompt_templates import build_evidence_prompt
from ..utils.logging import get_logger

logger = get_logger(__name__)


def _fallback_evidence(sample_id: str, candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    cards = []
    for c in candidates:
        cards.append(
            {
                "candidate_id": c.get("candidate_id"),
                "support": [],
                "risk": [],
                "usage": "secondary_support",
            }
        )
    return {
        "sample_id": sample_id,
        "global_evidence_guidance": [],
        "candidate_evidence_cards": cards,
    }


class EvidenceAgent(BaseAgent):
    name = "EvidenceAgent"
    agent_key = "evidence_agent"

    def run(
        self,
        sample_id: str,
        user_id: str,
        user_memory: Dict[str, Any],
        candidates: List[Dict[str, Any]],
        reflection_memory: Optional[Dict[str, Any]] = None,
        include_item_memory: bool = False,
    ) -> Dict[str, Any]:
        system, user_prompt = build_evidence_prompt(
            sample_id=sample_id,
            user_id=user_id,
            user_memory=user_memory,
            candidates=candidates,
            reflection_memory=reflection_memory,
            include_item_memory=include_item_memory,
        )
        meta = {
            "agent": "evidence",
            "sample_id": sample_id,
            "user_id": user_id,
            "candidates": candidates,
        }
        fallback = _fallback_evidence(sample_id, candidates)
        out = self._call_json(system, user_prompt, fallback, meta=meta)
        if not isinstance(out, dict) or "candidate_evidence_cards" not in out:
            raw = out.get("_raw_output") if isinstance(out, dict) else None
            out = _fallback_evidence(sample_id, candidates)
            out["_raw_output"] = raw
            out["_parse_success"] = False
        out.setdefault("sample_id", sample_id)
        out.setdefault("global_evidence_guidance", [])
        out.setdefault("candidate_evidence_cards", [])
        return out

    def run_batch(self, requests: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batched evidence validation.

        ``requests``: list of dicts with keys sample_id, user_id, user_memory,
        candidates, reflection_memory, include_item_memory.
        """
        if not requests:
            return []
        prompts: List[str] = []
        metas: List[Dict[str, Any]] = []
        fallbacks: List[Dict[str, Any]] = []
        system_prompt = None
        for req in requests:
            system, user_prompt = build_evidence_prompt(
                sample_id=req["sample_id"], user_id=req["user_id"],
                user_memory=req["user_memory"], candidates=req["candidates"],
                reflection_memory=req.get("reflection_memory"),
                include_item_memory=req.get("include_item_memory", False),
            )
            system_prompt = system
            prompts.append(user_prompt)
            metas.append({
                "agent": "evidence", "sample_id": req["sample_id"],
                "user_id": req["user_id"], "candidates": req["candidates"],
            })
            fallbacks.append(_fallback_evidence(req["sample_id"], req["candidates"]))

        parsed = self._call_json_batch(system_prompt, prompts, fallbacks, metas)
        out: List[Dict[str, Any]] = []
        for req, o in zip(requests, parsed):
            if not isinstance(o, dict) or "candidate_evidence_cards" not in o:
                raw = o.get("_raw_output") if isinstance(o, dict) else None
                o = _fallback_evidence(req["sample_id"], req["candidates"])
                o["_raw_output"] = raw
                o["_parse_success"] = False
            o.setdefault("sample_id", req["sample_id"])
            o.setdefault("global_evidence_guidance", [])
            o.setdefault("candidate_evidence_cards", [])
            out.append(o)
        return out

    @staticmethod
    def evidence_card_map(evidence: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        result: Dict[str, Dict[str, Any]] = {}
        for card in evidence.get("candidate_evidence_cards", []) or []:
            cid = card.get("candidate_id")
            if cid is not None:
                result[str(cid)] = card
        return result
