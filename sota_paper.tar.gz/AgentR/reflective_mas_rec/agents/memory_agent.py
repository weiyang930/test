"""MemoryAgent: construct structured user preference memory (summary_only MVP).

Designed so that bank_only / summary_plus_bank can be added later without
changing the interface. Caches by user_id + sample_id + memory_config_hash.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseAgent, JsonlCache
from ..config import AppConfig
from ..llm.client import LLMClient
from ..llm.prompt_templates import build_memory_prompt
from ..utils.hashing import stable_hash
from ..utils.logging import get_logger

logger = get_logger(__name__)


def _empty_memory(user_id: str) -> Dict[str, Any]:
    return {
        "user_id": user_id,
        "long_term_memory": {
            "stable_preferences": [],
            "profile_hypotheses": [],
            "negative_preferences": [],
            "risk_rules": [],
            "conflict_notes": [],
        },
        "short_term_memory": {
            "recent_intents": [],
            "recent_evidence_items": [],
            "trend": "",
            "short_term_constraints": [],
        },
        "ranking_guidance": [],
    }


def _rule_fallback_memory(
    user_id: str,
    profile_fields: Optional[Dict[str, Any]],
    history_cards: List[Dict[str, Any]],
    short_term_window: int,
) -> Dict[str, Any]:
    """Deterministic rule-based memory used if the LLM fails entirely."""
    mem = _empty_memory(user_id)
    # Stable preferences from frequent history categories/labels.
    from collections import Counter

    cats = Counter()
    labels = Counter()
    for c in history_cards:
        if c.get("category_l1"):
            cats[c["category_l1"]] += 1
        if c.get("label"):
            labels[c["label"].split(",")[0].strip()] += 1
    for cat, cnt in cats.most_common(3):
        mem["long_term_memory"]["stable_preferences"].append(
            {
                "content": f"Frequently interacts with category: {cat}",
                "source": "history",
                "confidence": "high" if cnt >= 3 else "medium",
                "evidence": [],
            }
        )
    recent = history_cards[-short_term_window:]
    mem["short_term_memory"]["recent_intents"] = [
        c.get("label", "").split(",")[0].strip() for c in recent if c.get("label")
    ][:3]
    mem["short_term_memory"]["recent_evidence_items"] = [
        c.get("note_id", "") for c in recent
    ]
    mem["ranking_guidance"] = [
        "Prefer candidates whose category matches frequent history categories."
    ]
    if profile_fields:
        mem["long_term_memory"]["profile_hypotheses"].append(
            {
                "content": "Profile-derived hypothesis (needs behavior support).",
                "source": "profile",
                "confidence": "low",
                "evidence": [],
            }
        )
    return mem


class MemoryAgent(BaseAgent):
    name = "MemoryAgent"
    agent_key = "memory_agent"

    def __init__(self, cfg: AppConfig, client: LLMClient) -> None:
        super().__init__(cfg, client)
        self.cache = JsonlCache(
            str(cfg.out("cache", "user_memory.jsonl")),
            enabled=cfg.runtime.cache_enabled,
        )
        # Per-sample raw LLM output capture for tracing (sample_id -> raw text).
        # Cached entries have no fresh raw output (value stays None).
        self.last_raw: Dict[str, Optional[str]] = {}
        self._config_hash = stable_hash(
            {
                "memory_mode": cfg.memory.memory_mode,
                "short_term_window_size": cfg.memory.short_term_window_size,
                "use_llm_output": cfg.agents.use_llm_output,
                "use_profile_fields": cfg.agents.use_profile_fields,
                "model": self.model_cfg.model,
                "use_full_history": cfg.memory.use_full_history_for_memory,
            }
        )

    def _cache_key(self, user_id: str, sample_id: str) -> str:
        return f"{user_id}|{sample_id}|{self._config_hash}"

    def _prepare(
        self,
        user_id: str,
        profile_fields: Optional[Dict[str, Any]],
        llm_output: str,
        history_cards: List[Dict[str, Any]],
        sample_id: str,
        previous_memory: Optional[Dict[str, Any]] = None,
        reflection_memory: Optional[Dict[str, Any]] = None,
    ):
        eff_profile = profile_fields if self.cfg.agents.use_profile_fields else None
        eff_persona = llm_output if self.cfg.agents.use_llm_output else ""
        window = self.cfg.memory.short_term_window_size
        system, user_prompt = build_memory_prompt(
            user_id=user_id, profile_fields=eff_profile, llm_output=eff_persona,
            history_cards=history_cards, short_term_window=window,
            previous_memory=previous_memory, reflection_memory=reflection_memory,
        )
        recent = history_cards[-window:] if history_cards else []
        meta = {
            "agent": "memory", "user_id": user_id, "sample_id": sample_id,
            "recent_labels": [
                c.get("label", "").split(",")[0].strip() for c in recent if c.get("label")
            ],
            "recent_item_ids": [c.get("note_id", "") for c in recent],
        }
        fallback = _rule_fallback_memory(user_id, eff_profile, history_cards, window)
        return system, user_prompt, meta, fallback

    def build(
        self,
        user_id: str,
        profile_fields: Optional[Dict[str, Any]],
        llm_output: str,
        history_cards: List[Dict[str, Any]],
        sample_id: str,
        previous_memory: Optional[Dict[str, Any]] = None,
        reflection_memory: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        key = self._cache_key(user_id, sample_id)
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        system, user_prompt, meta, fallback = self._prepare(
            user_id, profile_fields, llm_output, history_cards, sample_id,
            previous_memory, reflection_memory,
        )
        memory = self._call_json(system, user_prompt, fallback, meta=meta)
        self.last_raw[sample_id] = memory.get("_raw_output")
        memory = self._normalize(memory, user_id)
        self.cache.put(key, memory)
        return memory

    def build_batch(self, requests: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batched memory construction.

        ``requests``: list of dicts with keys user_id, profile_fields, llm_output,
        history_cards, sample_id, previous_memory, reflection_memory.
        Cached entries are returned without an LLM call; the rest are batched.
        """
        results: List[Optional[Dict[str, Any]]] = [None] * len(requests)
        pending_idx: List[int] = []
        prompts: List[str] = []
        metas: List[Dict[str, Any]] = []
        fallbacks: List[Dict[str, Any]] = []
        system_prompt = None

        for i, req in enumerate(requests):
            key = self._cache_key(req["user_id"], req["sample_id"])
            cached = self.cache.get(key)
            if cached is not None:
                results[i] = cached
                continue
            system, user_prompt, meta, fallback = self._prepare(
                req["user_id"], req.get("profile_fields"), req.get("llm_output", ""),
                req.get("history_cards", []), req["sample_id"],
                req.get("previous_memory"), req.get("reflection_memory"),
            )
            system_prompt = system
            pending_idx.append(i)
            prompts.append(user_prompt)
            metas.append(meta)
            fallbacks.append(fallback)

        if prompts:
            parsed = self._call_json_batch(system_prompt, prompts, fallbacks, metas)
            for j, idx in enumerate(pending_idx):
                req = requests[idx]
                self.last_raw[req["sample_id"]] = parsed[j].get("_raw_output")
                mem = self._normalize(parsed[j], req["user_id"])
                self.cache.put(self._cache_key(req["user_id"], req["sample_id"]), mem)
                results[idx] = mem
        return [r for r in results]

    @staticmethod
    def _normalize(memory: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        base = _empty_memory(user_id)
        if not isinstance(memory, dict):
            return base
        # Drop private debug keys so they never leak into the cached/persisted
        # memory state or downstream prompts (raw output is captured separately).
        memory.pop("_raw_output", None)
        memory.pop("_parse_success", None)
        memory.setdefault("user_id", user_id)
        ltm = memory.get("long_term_memory")
        if not isinstance(ltm, dict):
            memory["long_term_memory"] = base["long_term_memory"]
        else:
            for k, v in base["long_term_memory"].items():
                ltm.setdefault(k, v)
        stm = memory.get("short_term_memory")
        if not isinstance(stm, dict):
            memory["short_term_memory"] = base["short_term_memory"]
        else:
            for k, v in base["short_term_memory"].items():
                stm.setdefault(k, v)
        if not isinstance(memory.get("ranking_guidance"), list):
            memory["ranking_guidance"] = []
        return memory

    def close(self) -> None:
        self.cache.close()
