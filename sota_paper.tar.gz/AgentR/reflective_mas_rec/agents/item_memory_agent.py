"""ItemMemoryAgent: structured item semantic memory with rule fallback + cache."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseAgent, JsonlCache
from ..config import AppConfig
from ..llm.client import LLMClient
from ..llm.prompt_templates import build_item_memory_prompt
from ..utils.logging import get_logger

logger = get_logger(__name__)


def rule_item_memory(card: Dict[str, Any]) -> Dict[str, Any]:
    """Template fallback using title, label, and parsed attributes."""
    attrs = [a for a in [card.get("brand_name"), card.get("label")] if a]
    return {
        "note_id": card.get("note_id", ""),
        "item_core_identity": card.get("product_name") or card.get("title", "") or "unknown item",
        "category_positioning": "/".join(
            x for x in [card.get("category_l1", ""), card.get("category_l2", "")] if x
        ),
        "key_attributes": attrs,
        "suitable_scenarios": [],
        "suitable_user_needs": [],
        "price_positioning": card.get("price", "") or "unknown",
        "risk_notes": [],
    }


class ItemMemoryAgent(BaseAgent):
    name = "ItemMemoryAgent"
    agent_key = "item_memory_agent"

    def __init__(self, cfg: AppConfig, client: LLMClient) -> None:
        super().__init__(cfg, client)
        self.cache = JsonlCache(
            str(cfg.out("cache", "item_memory.jsonl")),
            enabled=cfg.runtime.cache_enabled,
        )

    def build(self, card: Dict[str, Any]) -> Dict[str, Any]:
        note_id = card.get("note_id", "")
        cached = self.cache.get(note_id)
        if cached is not None:
            return cached
        system, user_prompt = build_item_memory_prompt(card)
        fallback = rule_item_memory(card)
        meta = {"agent": "item_memory", "item_card": card}
        mem = self._call_json(system, user_prompt, fallback, meta=meta)
        if not isinstance(mem, dict) or not mem:
            mem = fallback
        mem.setdefault("note_id", note_id)
        self.cache.put(note_id, mem)
        return mem

    def build_many(self, cards: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        return {c.get("note_id", ""): self.build(c) for c in cards}

    def close(self) -> None:
        self.cache.close()
