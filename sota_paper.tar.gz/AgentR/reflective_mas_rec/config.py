"""Config system: YAML -> typed dataclasses for the whole framework.

Mirrors the spec in section 15. Unknown / extra YAML keys are tolerated so the
config files can carry experiment annotations without breaking loading.
"""
from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


def _filter_known(cls, data: Dict[str, Any]) -> Dict[str, Any]:
    known = {f.name for f in fields(cls)}
    return {k: v for k, v in (data or {}).items() if k in known}


@dataclass
class DatasetConfig:
    root_dir: str = "./data/rednote/subset_20000users_u10_100_i10_seed42"
    output_dir: str = "./outputs/exp_v1"
    user_file: str = "users.parquet"
    item_file: str = "items.parquet"
    interaction_file: str = "interactions.parquet"


@dataclass
class SplitConfig:
    method: str = "leave_one_out"
    min_history_len: int = 5
    max_history_len: int = 20
    min_seq_len: int = 10  # only keep users with T >= this


@dataclass
class NegativeSamplingConfig:
    num_negatives: int = 9
    # mode: "mixed" (random/popular/label/category) | "cf_hard" (CF top-K negs)
    mode: str = "mixed"
    random_ratio: float = 0.4
    popular_ratio: float = 0.2
    same_label_ratio: float = 0.2
    same_category_ratio: float = 0.2
    seed: int = 42
    # cf_hard mode settings
    cf_hard_neg_file: Optional[str] = None  # jsonl: {user_id, hard_negatives:[...]}
    # Fraction of negatives drawn from CF hard pool; rest backfilled randomly.
    cf_hard_ratio: float = 1.0


@dataclass
class ItemConfig:
    max_content_chars: int = 160
    use_item_memory_agent: bool = False


@dataclass
class MemoryConfig:
    memory_mode: str = "summary_only"  # summary_only | bank_only | summary_plus_bank
    short_term_window_size: int = 5
    use_reflection_memory: bool = True
    max_reflection_rules: int = 5
    # When True, MemoryAgent may see the full train history; prompt stays compact.
    use_full_history_for_memory: bool = True
    # Min reinforcement count for a collaborative item note to survive de-noising
    # (filters one-off audience guesses; raise at larger user scale).
    collab_min_count: int = 2


@dataclass
class AgentsConfig:
    use_memory_agent: bool = True
    use_item_memory_agent: bool = False
    use_evidence_agent: bool = True
    use_reflection_agent: bool = True
    rank_agent_mode: str = "prompt"  # prompt | trained
    # Ablation switches on user-side inputs.
    use_llm_output: bool = True
    use_profile_fields: bool = True


@dataclass
class EvaluationConfig:
    metrics: List[str] = field(
        default_factory=lambda: ["hr@1", "hr@5", "ndcg@5", "mrr"]
    )
    update_memory_after_valid: bool = False


@dataclass
class AgentModelConfig:
    model: Optional[str] = None
    temperature: float = 0.0
    max_tokens: int = 1024


@dataclass
class LLMConfig:
    provider: str = "mock"  # mock | openai_compatible | vllm | huggingface
    base_url: Optional[str] = None
    api_key_env: str = "OPENAI_API_KEY"
    default_model: str = "qwen2.5-7b-instruct"
    temperature: float = 0.0
    max_tokens: int = 1024
    max_retries: int = 2
    # vLLM / HF specifics
    model_path: Optional[str] = None  # local weights path for vllm/hf backends
    tensor_parallel_size: int = 1
    gpu_memory_utilization: float = 0.9
    max_model_len: int = 8192
    enable_prefix_caching: bool = True
    # Disable vLLM's torch.compile/CUDA-graph capture. Use eager mode when the
    # compile step crashes the workers (e.g. inductor/triton incompatibility).
    enforce_eager: bool = False
    # Qwen3-style reasoning models emit <think>...</think>. Set False to disable
    # thinking (recommended for this framework; spec forbids long CoT).
    enable_thinking: bool = False
    # Belt-and-suspenders: when not thinking, also append Qwen3's `/no_think`
    # soft switch to each user prompt. The chat_template enable_thinking flag is
    # not always honored, so this makes the no-CoT behavior reliable.
    append_no_think_token: bool = True
    # vLLM batched generation chunk size (number of prompts per generate call).
    vllm_batch_size: int = 256
    # Per-agent overrides; keys: memory_agent, item_memory_agent, evidence_agent,
    # rank_agent, reflection_agent. Values map to AgentModelConfig fields.
    agents: Dict[str, Dict[str, Any]] = field(default_factory=dict)


@dataclass
class RuntimeConfig:
    max_users: Optional[int] = None
    # Skip the first N eligible users (sorted by user_id) before taking
    # max_users. Used to build a held-out user set disjoint from a trained
    # prefix (e.g. user_offset=2000 -> evaluate users the model never saw).
    user_offset: int = 0
    max_samples: Optional[int] = None
    num_workers: int = 4
    cache_enabled: bool = True
    save_traces: bool = True
    seed: int = 42
    log_level: str = "INFO"
    # Pipeline mode: single_llm | memory_only | memory_evidence | full_mas
    pipeline_mode: str = "full_mas"


@dataclass
class AppConfig:
    dataset: DatasetConfig = field(default_factory=DatasetConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    negative_sampling: NegativeSamplingConfig = field(
        default_factory=NegativeSamplingConfig
    )
    item: ItemConfig = field(default_factory=ItemConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    agents: AgentsConfig = field(default_factory=AgentsConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    name: str = "exp"

    # ---- path helpers ----
    def data_path(self, filename: str) -> Path:
        return Path(self.dataset.root_dir) / filename

    @property
    def output_dir(self) -> Path:
        return Path(self.dataset.output_dir)

    def out(self, *parts: str) -> Path:
        return self.output_dir.joinpath(*parts)

    def agent_model(self, agent_name: str) -> AgentModelConfig:
        """Resolve per-agent model config, falling back to llm defaults."""
        raw = self.llm.agents.get(agent_name, {}) or {}
        return AgentModelConfig(
            model=raw.get("model", self.llm.default_model),
            temperature=raw.get("temperature", self.llm.temperature),
            max_tokens=raw.get("max_tokens", self.llm.max_tokens),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def load_config(path: str) -> AppConfig:
    with open(path, "r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}

    cfg = AppConfig(
        dataset=DatasetConfig(**_filter_known(DatasetConfig, raw.get("dataset", {}))),
        split=SplitConfig(**_filter_known(SplitConfig, raw.get("split", {}))),
        negative_sampling=NegativeSamplingConfig(
            **_filter_known(NegativeSamplingConfig, raw.get("negative_sampling", {}))
        ),
        item=ItemConfig(**_filter_known(ItemConfig, raw.get("item", {}))),
        memory=MemoryConfig(**_filter_known(MemoryConfig, raw.get("memory", {}))),
        agents=AgentsConfig(**_filter_known(AgentsConfig, raw.get("agents", {}))),
        evaluation=EvaluationConfig(
            **_filter_known(EvaluationConfig, raw.get("evaluation", {}))
        ),
        llm=LLMConfig(**_filter_known(LLMConfig, raw.get("llm", {}))),
        runtime=RuntimeConfig(**_filter_known(RuntimeConfig, raw.get("runtime", {}))),
        name=raw.get("name", Path(path).stem),
    )
    return cfg
