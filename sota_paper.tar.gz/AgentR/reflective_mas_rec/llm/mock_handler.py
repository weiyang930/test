"""Deterministic structured mock handler for pipeline/trace validation.

Returns valid JSON for each agent so that the full MAS pipeline, trace saving,
evaluation, and SFT building can be exercised end-to-end without a real model.

The handler is intentionally simple and rule-based. For ranking it uses a light
lexical overlap heuristic between the user's recent history/persona and each
candidate so that mock metrics are non-degenerate (better than random).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..utils.json_utils import dumps


def _tokens(text: str) -> set:
    if not text:
        return set()
    seps = ",/|;:：，。、 \t\n（）()【】[]"
    for s in seps:
        text = text.replace(s, " ")
    return {t for t in text.lower().split() if len(t) >= 1}


def _candidate_text(cand: Dict[str, Any]) -> str:
    info = cand.get("item_compact_info", {}) or {}
    return " ".join(
        str(info.get(k, ""))
        for k in ("title", "product_name", "label", "category_l1", "category_l2", "brand_name")
    )


def _heuristic_rank(meta: Dict[str, Any]) -> List[str]:
    candidates = meta.get("candidates", []) or []
    context = meta.get("rank_context_text", "") or ""
    ctx_tokens = _tokens(context)
    scored = []
    for i, c in enumerate(candidates):
        cid = c.get("candidate_id")
        ct = _tokens(_candidate_text(c))
        overlap = len(ctx_tokens & ct)
        scored.append((overlap, -i, cid))
    scored.sort(reverse=True)
    return [cid for _, _, cid in scored]


def mock_handler(prompt: str, system_prompt: Optional[str], meta: Dict[str, Any]) -> str:
    agent = meta.get("agent", "")

    if agent == "memory":
        uid = meta.get("user_id", "")
        return dumps(
            {
                "user_id": uid,
                "long_term_memory": {
                    "stable_preferences": [
                        {
                            "content": "Behavior-supported interest in recent history categories.",
                            "source": "history",
                            "confidence": "medium",
                            "evidence": meta.get("recent_labels", [])[:3],
                        }
                    ],
                    "profile_hypotheses": [
                        {
                            "content": "Profile-derived hypothesis (needs behavior support).",
                            "source": "profile",
                            "confidence": "low",
                            "evidence": [],
                        }
                    ],
                    "negative_preferences": [],
                    "risk_rules": [
                        {
                            "content": "Do not over-rank items on demographic labels alone.",
                            "source": "rule",
                            "confidence": "medium",
                        }
                    ],
                    "conflict_notes": [],
                },
                "short_term_memory": {
                    "recent_intents": meta.get("recent_labels", [])[:3],
                    "recent_evidence_items": meta.get("recent_item_ids", [])[:3],
                    "trend": "Continuing recent browsing pattern.",
                    "short_term_constraints": [],
                },
                "ranking_guidance": [
                    "Prefer candidates matching recent behavior categories.",
                ],
            }
        )

    if agent == "item_memory":
        card = meta.get("item_card", {})
        return dumps(
            {
                "note_id": card.get("note_id", ""),
                "item_core_identity": card.get("product_name") or card.get("title", ""),
                "category_positioning": f"{card.get('category_l1','')}/{card.get('category_l2','')}",
                "key_attributes": [a for a in [card.get("brand_name"), card.get("label")] if a],
                "suitable_scenarios": [],
                "suitable_user_needs": [],
                "price_positioning": card.get("price", "") or "unknown",
                "risk_notes": [],
            }
        )

    if agent == "evidence":
        candidates = meta.get("candidates", []) or []
        cards = []
        for c in candidates:
            cards.append(
                {
                    "candidate_id": c.get("candidate_id"),
                    "support": [
                        {
                            "type": "category_match",
                            "content": "Category overlaps with user history.",
                            "strength": "medium",
                        }
                    ],
                    "risk": [],
                    "usage": "secondary_support",
                }
            )
        return dumps(
            {
                "sample_id": meta.get("sample_id", ""),
                "global_evidence_guidance": [
                    "Use behavior-supported category match as primary evidence.",
                ],
                "candidate_evidence_cards": cards,
            }
        )

    if agent in ("rank", "single_llm"):
        ranking = _heuristic_rank(meta)
        return dumps(
            {
                "sample_id": meta.get("sample_id", ""),
                "ranking": ranking,
                "top_reason": "Top item best matches recent behavior categories.",
                "decision_rules": ["Behavior match > profile label."],
                "used_evidence": ["category_match"],
                "downweighted_evidence": ["profile_overgeneralization"],
                "uncertainty": "medium",
            }
        )

    if agent == "reflection":
        ranking = meta.get("rank_ranking", []) or []
        gt = meta.get("ground_truth_positive", "")
        pos = ranking.index(gt) if gt in ranking else -1
        success = pos == 0
        top_neg = meta.get("top_negative", "")
        return dumps(
            {
                "sample_id": meta.get("sample_id", ""),
                "reflection_type": "success" if success else "failure",
                "contrastive_insight": {
                    "positive_vs_negative": ""
                    if success
                    else "Positive item fits an emerging new interest; negative only repeats past category.",
                    "discriminative_signal": "scenario_fit"
                    if success
                    else "exploration_of_new_category",
                    "why_ranker_failed": ""
                    if success
                    else "Ranker over-weighted coarse category match with history.",
                },
                "rank_feedback": {
                    "corrective_rule": "Do not assume the next item repeats the user's most frequent category; weigh recent exploration signals.",
                    "training_use": "can_be_used_for_sft_or_dpo",
                },
                "memory_update_ops": []
                if success
                else [
                    {
                        "op": "add",
                        "scope": "reflection_memory",
                        "content": "User sometimes explores new categories; avoid pure history-category matching.",
                        "confidence_delta": "small_positive",
                    },
                    {
                        "op": "add",
                        "scope": "item",
                        "target_note_id": (meta.get("candidates", [{}])[0].get("item_compact_info", {}) or {}).get("note_id", ""),
                        "content": "Attracts users exploring beyond their usual categories.",
                        "confidence_delta": "small_positive",
                    },
                ],
            }
        )

    return "{}"
