"""Generic LLM client interface.

Supports:
  - mock           : deterministic placeholder outputs for pipeline testing.
  - openai_compatible : OpenAI-style chat completions (incl. local vLLM server).
  - vllm           : in-process vLLM engine (batched).
  - huggingface    : local transformers causal LM (batched).

All agents call ``client.generate(...)`` (single) or ``client.generate_batch(...)``.
A ``mock_handler`` callback can be registered to produce structured mock outputs
per agent so the full pipeline + trace can be validated without any real model.
"""
from __future__ import annotations

import os
import re
import time
from typing import Any, Callable, Dict, List, Optional, Sequence

from ..config import LLMConfig
from ..utils.logging import get_logger

logger = get_logger(__name__)

# Signature: (prompt, system_prompt, meta) -> str
MockHandler = Callable[[str, Optional[str], Dict[str, Any]], str]

_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)

# Qwen3 soft switch that forces no chain-of-thought when appended to the prompt.
_NO_THINK_TOKEN = "/no_think"


def _strip_think(text: str) -> str:
    """Remove Qwen3-style <think>...</think> blocks. Also handles an unclosed
    leading <think> (keeps only content after a closing tag if present)."""
    if not text:
        return text
    cleaned = _THINK_RE.sub("", text)
    # If a stray closing tag remains (e.g. thinking enabled but no open tag
    # captured), keep the text after the last </think>.
    if "</think>" in cleaned:
        cleaned = cleaned.rsplit("</think>", 1)[-1]
    return cleaned


class LLMClient:
    def __init__(self, cfg: LLMConfig) -> None:
        self.cfg = cfg
        self.provider = cfg.provider
        self._mock_handler: Optional[MockHandler] = None
        # lazy backends
        self._hf_tokenizer = None
        self._hf_model = None
        self._hf_device = None
        self._vllm_model = None
        self._openai_client = None
        # simple call counter for diagnostics
        self.num_calls = 0

    # ------------------------------------------------------------------ #
    # Mock handler registration
    # ------------------------------------------------------------------ #
    def set_mock_handler(self, handler: MockHandler) -> None:
        self._mock_handler = handler

    # ------------------------------------------------------------------ #
    # Prompt helpers
    # ------------------------------------------------------------------ #
    def _user_content(self, prompt: str) -> str:
        """Append Qwen3's /no_think soft switch when thinking is disabled."""
        if (not self.cfg.enable_thinking) and self.cfg.append_no_think_token:
            if _NO_THINK_TOKEN not in prompt:
                return f"{prompt}\n{_NO_THINK_TOKEN}"
        return prompt

    # ------------------------------------------------------------------ #
    # Public generate API
    # ------------------------------------------------------------------ #
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        model_name: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> str:
        return self.generate_batch(
            [prompt],
            system_prompt=system_prompt,
            model_name=model_name,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format=response_format,
            metas=[meta or {}],
        )[0]

    def generate_batch(
        self,
        prompts: Sequence[str],
        system_prompt: Optional[str] = None,
        model_name: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[str] = None,
        metas: Optional[Sequence[Dict[str, Any]]] = None,
    ) -> List[str]:
        prompts = list(prompts)
        if not prompts:
            return []
        metas = list(metas) if metas is not None else [{} for _ in prompts]
        model_name = model_name or self.cfg.default_model
        temperature = self.cfg.temperature if temperature is None else temperature
        max_tokens = self.cfg.max_tokens if max_tokens is None else max_tokens
        self.num_calls += len(prompts)

        if self.provider == "mock":
            outputs = [
                self._mock_generate(p, system_prompt, m)
                for p, m in zip(prompts, metas)
            ]
        elif self.provider == "openai_compatible":
            outputs = [
                self._generate_openai(p, system_prompt, model_name, temperature, max_tokens, response_format)
                for p in prompts
            ]
        elif self.provider == "vllm":
            outputs = self._generate_vllm_batch(prompts, system_prompt, temperature, max_tokens)
        elif self.provider == "huggingface":
            outputs = self._generate_hf_batch(prompts, system_prompt, temperature, max_tokens)
        else:
            raise ValueError(f"Unknown LLM provider: {self.provider}")

        # Write the raw model text back into each caller-provided meta dict so
        # agents/traces can capture exactly what the model produced (critical for
        # debugging JSON parse / ranking failures). Also stash the user prompt.
        for prompt, meta, out in zip(prompts, metas, outputs):
            if isinstance(meta, dict):
                meta["_raw_output"] = out
                meta["_prompt"] = prompt
        return outputs

    # ------------------------------------------------------------------ #
    # Mock backend
    # ------------------------------------------------------------------ #
    def _mock_generate(self, prompt: str, system_prompt: Optional[str], meta: Dict[str, Any]) -> str:
        if self._mock_handler is not None:
            return self._mock_handler(prompt, system_prompt, meta)
        return "{}"

    # ------------------------------------------------------------------ #
    # OpenAI-compatible backend
    # ------------------------------------------------------------------ #
    def _get_openai_client(self):
        if self._openai_client is None:
            from openai import OpenAI

            api_key = os.getenv(self.cfg.api_key_env, "EMPTY")
            self._openai_client = OpenAI(api_key=api_key, base_url=self.cfg.base_url)
        return self._openai_client

    def _generate_openai(
        self,
        prompt: str,
        system_prompt: Optional[str],
        model_name: str,
        temperature: float,
        max_tokens: int,
        response_format: Optional[str],
    ) -> str:
        client = self._get_openai_client()
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        kwargs: Dict[str, Any] = dict(
            model=model_name,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=messages,
        )
        if response_format == "json":
            # Many OpenAI-compatible servers support this; ignore on failure.
            kwargs["response_format"] = {"type": "json_object"}

        last_err: Optional[Exception] = None
        for attempt in range(self.cfg.max_retries + 1):
            try:
                resp = client.chat.completions.create(**kwargs)
                return (resp.choices[0].message.content or "").strip()
            except Exception as exc:  # noqa: BLE001
                last_err = exc
                # Retry once without response_format if the server rejects it.
                if "response_format" in kwargs and attempt == 0:
                    kwargs.pop("response_format", None)
                time.sleep(min(2.0 * (attempt + 1), 5.0))
        logger.warning("OpenAI call failed after retries: %s", last_err)
        return ""

    # ------------------------------------------------------------------ #
    # vLLM (in-process) backend
    # ------------------------------------------------------------------ #
    def _load_vllm(self):
        if self._vllm_model is not None:
            return self._vllm_model
        from vllm import LLM

        model = self.cfg.model_path or self.cfg.default_model
        # Determinism controls (env overrides) for reproducible eval:
        #   MASREC_DISABLE_PREFIX_CACHE=1 -> turn off prefix caching (a major
        #     source of batch-to-batch non-determinism: cache hit vs miss run
        #     different kernels -> different float logits -> argmax flips).
        import os as _os
        enable_prefix = self.cfg.enable_prefix_caching
        if _os.environ.get("MASREC_DISABLE_PREFIX_CACHE", "0") == "1":
            enable_prefix = False
        logger.info(
            "Loading vLLM model=%s tp=%d max_len=%d enable_thinking=%s prefix_cache=%s",
            model, self.cfg.tensor_parallel_size, self.cfg.max_model_len,
            self.cfg.enable_thinking, enable_prefix,
        )
        self._vllm_model = LLM(
            model=model,
            tensor_parallel_size=self.cfg.tensor_parallel_size,
            enable_prefix_caching=enable_prefix,
            gpu_memory_utilization=self.cfg.gpu_memory_utilization,
            max_model_len=self.cfg.max_model_len,
            trust_remote_code=True,
            dtype="auto",
            enforce_eager=self.cfg.enforce_eager,
        )
        return self._vllm_model

    def _generate_vllm_batch(
        self,
        prompts: Sequence[str],
        system_prompt: Optional[str],
        temperature: float,
        max_tokens: int,
    ) -> List[str]:
        llm = self._load_vllm()
        from vllm import SamplingParams

        # Optional fixed seed for reproducible sampling path (helps determinism
        # even for greedy; set via MASREC_VLLM_SEED).
        import os as _os
        _seed_env = _os.environ.get("MASREC_VLLM_SEED")
        _seed = int(_seed_env) if _seed_env not in (None, "") else None
        sp = SamplingParams(temperature=temperature, max_tokens=max_tokens, seed=_seed)
        conversations = []
        for prompt in prompts:
            msgs: List[Dict[str, str]] = []
            if system_prompt:
                msgs.append({"role": "system", "content": system_prompt})
            msgs.append({"role": "user", "content": self._user_content(prompt)})
            conversations.append(msgs)

        # Control Qwen3-style thinking via chat template kwargs when supported.
        chat_kwargs: Dict[str, Any] = {}
        if not self.cfg.enable_thinking:
            chat_kwargs["chat_template_kwargs"] = {"enable_thinking": False}

        results: List[str] = []
        bs = max(1, int(self.cfg.vllm_batch_size))
        for start in range(0, len(conversations), bs):
            chunk = conversations[start : start + bs]
            try:
                outputs = llm.chat(chunk, sampling_params=sp, use_tqdm=False, **chat_kwargs)
            except TypeError:
                # Older vLLM without chat_template_kwargs support.
                outputs = llm.chat(chunk, sampling_params=sp, use_tqdm=False)
            for o in outputs:
                results.append(_strip_think(o.outputs[0].text).strip())
        return results

    def free_vllm(self, wait_free_gb: float = 15.0, timeout: float = 120.0) -> None:
        """Release the in-process vLLM engine and poll until GPU memory frees."""
        if self._vllm_model is None:
            return
        import gc
        import subprocess

        import torch

        del self._vllm_model
        self._vllm_model = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        deadline = time.time() + timeout
        wait_free_mib = int(wait_free_gb * 1024)
        while time.time() < deadline:
            try:
                out = subprocess.check_output(
                    ["nvidia-smi", "--query-gpu=memory.free", "--format=csv,noheader,nounits"],
                    timeout=5,
                ).decode()
                vals = [int(v.strip()) for v in out.strip().splitlines() if v.strip()]
                if all(v >= wait_free_mib for v in vals):
                    break
            except Exception:
                pass
            time.sleep(2)

    # ------------------------------------------------------------------ #
    # HuggingFace backend
    # ------------------------------------------------------------------ #
    def _load_hf(self):
        if self._hf_model is not None:
            return self._hf_tokenizer, self._hf_model
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        name = self.cfg.model_path or self.cfg.default_model
        self._hf_tokenizer = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
        if self._hf_tokenizer.pad_token is None:
            self._hf_tokenizer.pad_token = self._hf_tokenizer.eos_token
        self._hf_model = AutoModelForCausalLM.from_pretrained(
            name, torch_dtype="auto", device_map="auto", trust_remote_code=True
        )
        self._hf_device = getattr(self._hf_model, "device", torch.device("cpu"))
        return self._hf_tokenizer, self._hf_model

    def _generate_hf_batch(
        self,
        prompts: Sequence[str],
        system_prompt: Optional[str],
        temperature: float,
        max_tokens: int,
    ) -> List[str]:
        import torch

        tokenizer, model = self._load_hf()
        rendered = []
        for prompt in prompts:
            msgs = []
            if system_prompt:
                msgs.append({"role": "system", "content": system_prompt})
            msgs.append({"role": "user", "content": self._user_content(prompt)})
            tmpl_kwargs = {}
            if not self.cfg.enable_thinking:
                tmpl_kwargs["enable_thinking"] = False
            try:
                rendered_one = tokenizer.apply_chat_template(
                    msgs, tokenize=False, add_generation_prompt=True, **tmpl_kwargs
                )
            except TypeError:
                rendered_one = tokenizer.apply_chat_template(
                    msgs, tokenize=False, add_generation_prompt=True
                )
            rendered.append(rendered_one)
        inputs = tokenizer(rendered, return_tensors="pt", padding=True)
        inputs = {k: v.to(self._hf_device) for k, v in inputs.items()}
        with torch.no_grad():
            gen = model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                temperature=temperature,
                do_sample=temperature > 0,
                pad_token_id=tokenizer.eos_token_id,
            )
        lengths = inputs["attention_mask"].sum(dim=1).tolist()
        outs: List[str] = []
        for i, ln in enumerate(lengths):
            text = tokenizer.decode(gen[i][int(ln):], skip_special_tokens=True)
            outs.append(_strip_think(text).strip())
        return outs


def build_llm_client(cfg: LLMConfig) -> LLMClient:
    return LLMClient(cfg)
