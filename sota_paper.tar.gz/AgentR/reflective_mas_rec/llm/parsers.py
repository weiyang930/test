"""Parsing & validation of structured agent outputs.

Focuses on the Rank Agent ranking, which must be a permutation of the candidate
IDs. Provides repair and fallback logic per spec 6.3.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from ..utils.json_utils import safe_json_loads


def validate_ranking(
    raw_ranking: Any, candidate_ids: List[str]
) -> Tuple[Optional[List[str]], bool]:
    """Validate that ``raw_ranking`` is a permutation of ``candidate_ids``.

    Returns (ranking_or_None, is_exact). ``is_exact`` is True only if the model
    output was already a valid full permutation. Otherwise we attempt repair:
      - keep valid IDs in given order (dedup);
      - append any missing candidate IDs (stable order);
    and return (repaired, False). If nothing usable, returns (None, False).
    """
    if not isinstance(raw_ranking, list):
        return None, False
    cand_set = set(candidate_ids)
    seen = set()
    cleaned: List[str] = []
    for x in raw_ranking:
        xid = str(x).strip()
        if xid in cand_set and xid not in seen:
            cleaned.append(xid)
            seen.add(xid)
    is_exact = len(cleaned) == len(candidate_ids) and set(cleaned) == cand_set
    if is_exact:
        return cleaned, True
    if not cleaned:
        return None, False
    # repair: append missing candidates in original order
    for cid in candidate_ids:
        if cid not in seen:
            cleaned.append(cid)
            seen.add(cid)
    return cleaned, False


def parse_rank_output(
    text: Any, candidate_ids: List[str], fallback_ranking: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Parse Rank Agent output text into a normalized dict.

    Returns dict with keys:
      ranking, top_reason, decision_rules, used_evidence, downweighted_evidence,
      uncertainty, parse_success (bool), ranking_exact (bool).
    """
    parsed = safe_json_loads(text, fallback=None)
    result = {
        "ranking": None,
        "top_reason": "",
        "decision_rules": [],
        "used_evidence": [],
        "downweighted_evidence": [],
        "uncertainty": "",
        "parse_success": False,
        "ranking_exact": False,
    }
    if isinstance(parsed, dict):
        result["parse_success"] = True
        result["top_reason"] = str(parsed.get("top_reason", "") or "")
        result["decision_rules"] = _as_str_list(parsed.get("decision_rules"))
        result["used_evidence"] = _as_str_list(parsed.get("used_evidence"))
        result["downweighted_evidence"] = _as_str_list(parsed.get("downweighted_evidence"))
        result["uncertainty"] = str(parsed.get("uncertainty", "") or "")
        ranking, exact = validate_ranking(parsed.get("ranking"), candidate_ids)
        result["ranking"] = ranking
        result["ranking_exact"] = exact

    if result["ranking"] is None:
        # fallback ordering
        if fallback_ranking is not None:
            fb, _ = validate_ranking(fallback_ranking, candidate_ids)
            result["ranking"] = fb if fb is not None else list(candidate_ids)
        else:
            result["ranking"] = list(candidate_ids)
        result["ranking_exact"] = False
    return result


def _as_str_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, list):
        out = []
        for v in value:
            if isinstance(v, str):
                if v.strip():
                    out.append(v)
            elif v is not None:
                out.append(str(v))
        return out
    return [str(value)]


def parse_json_output(text: Any, fallback: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
    """Parse arbitrary JSON agent output; returns (obj, parse_success)."""
    parsed = safe_json_loads(text, fallback=None)
    if isinstance(parsed, dict):
        return parsed, True
    return dict(fallback), False
