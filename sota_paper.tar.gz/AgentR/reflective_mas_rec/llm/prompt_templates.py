"""Prompt templates for every agent, plus the single-LLM baseline ranker.

All prompts require valid JSON output. Rank Agent prompt explicitly forbids long
chain-of-thought and asks for short decision rules + evidence tags (spec 6.2/18).

Each builder returns (system_prompt, user_prompt).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..utils.json_utils import dumps

# --------------------------------------------------------------------------- #
# System prompts
# --------------------------------------------------------------------------- #

MEMORY_SYSTEM = (
    "You are a user preference modeling expert for a recommendation system. "
    "Build a structured user memory from profile fields, semantic persona, and "
    "interaction history item cards. Behavior history is stronger evidence than "
    "demographic/persona text; do not treat demographic labels as primary "
    "preference signals unless behavior supports them. Output valid JSON only."
)

ITEM_MEMORY_SYSTEM = (
    "You are an item semantics expert. Convert an item compact card into a "
    "structured item semantic memory describing its core identity, positioning, "
    "attributes, scenarios, suitable user needs, and risks. Output valid JSON only."
)

EVIDENCE_SYSTEM = (
    "You are a next-interaction plausibility analyst for recommendation. You DO "
    "NOT produce a final ranking. For each candidate you assess how plausible it "
    "is as the user's NEXT interaction. Crucially, the next interaction is often "
    "NOT the closest match to past history: users explore adjacent genres, artists, "
    "sub-styles, and price points. So a candidate that DIFFERS from history is not "
    "automatically risky -- distinguish a REASONABLE EXPLORATION (an adjacent or "
    "natural next step from the user's tastes) from a TRUE MISMATCH (unrelated to "
    "any preference). Reward candidates that are plausible next steps, whether they "
    "repeat history or sensibly extend it. Only flag risk when a candidate is "
    "genuinely unrelated, not merely novel. Output valid JSON only."
)

RANK_SYSTEM = (
    "You are a listwise recommendation ranker. Rank candidate items by the "
    "likelihood the user interacts with them next. Prioritize behavior-supported "
    "preferences over weak profile/persona signals. Use evidence cards when "
    "available but do not ignore item info. Do NOT produce long chain-of-thought; "
    "give short decision rules and evidence tags. Output valid JSON only."
)

REFLECTION_SYSTEM = (
    "You are a post-ranking diagnostic expert. You DO NOT rank candidates and you "
    "MUST NOT reveal the correct ranking as a rule (e.g. never say 'always rank A "
    "first'). Diagnose success/failure and produce transferable preference "
    "corrections and memory update operations. Output valid JSON only."
)

SINGLE_LLM_SYSTEM = (
    "You are a recommendation ranker. Given a user's profile, persona, history, "
    "and candidate items, rank the candidates by the likelihood the user will "
    "interact with them next. Output valid JSON only with a 'ranking' field that "
    "is a permutation of all candidate_id values."
)


# --------------------------------------------------------------------------- #
# Serialization helpers
# --------------------------------------------------------------------------- #


def _history_block(history_cards: List[Dict[str, Any]]) -> str:
    lines = []
    for i, c in enumerate(history_cards, 1):
        parts = [f"#{i}"]
        if c.get("title"):
            parts.append(f"title={c['title']}")
        if c.get("product_name"):
            parts.append(f"product={c['product_name']}")
        if c.get("label"):
            parts.append(f"label={c['label']}")
        if c.get("category_l1"):
            parts.append(f"cat={c['category_l1']}/{c.get('category_l2','')}")
        if c.get("brand_name"):
            parts.append(f"brand={c['brand_name']}")
        if c.get("price"):
            parts.append(f"price={c['price']}")
        lines.append("; ".join(parts))
    return "\n".join(lines) if lines else "(empty history)"


def _candidate_block(candidates: List[Dict[str, Any]], include_evidence: bool,
                     include_item_memory: bool) -> str:
    """Serialize candidate list. Each candidate is a dict with candidate_id,
    item_compact_info, optional item_memory, optional evidence_card."""
    out = []
    for c in candidates:
        cid = c.get("candidate_id")
        info = c.get("item_compact_info", {})
        block = {
            "candidate_id": cid,
            "item": {
                "title": info.get("title", ""),
                "product_name": info.get("product_name", ""),
                "label": info.get("label", ""),
                "category_l1": info.get("category_l1", ""),
                "category_l2": info.get("category_l2", ""),
                "brand_name": info.get("brand_name", ""),
                "price": info.get("price", ""),
                "content_snippet": info.get("content_snippet", ""),
            },
        }
        # Inject the recall model's (SASRec) prior rank when available. This is a
        # strong prior (SASRec recall HR@1~0.27): lower number = SASRec more
        # confident this is the next item. The ranker should trust high-ranked
        # (small N) candidates more and only override with strong semantic evidence.
        if c.get("sasrec_rank") is not None:
            block["sasrec_recall_rank"] = c["sasrec_rank"]
        if include_item_memory and c.get("item_memory"):
            block["item_memory"] = c["item_memory"]
        if c.get("collab_memory"):
            # Cross-user collaborative signal learned from other users'
            # contrastive reflections: {likes:[audiences that engage],
            # avoids:[audiences that reject]} for this item or look-alike items.
            block["collab_memory"] = c["collab_memory"]
        if include_evidence and c.get("evidence_card"):
            block["evidence_card"] = c["evidence_card"]
        out.append(block)
    return dumps(out, indent=2)


# --------------------------------------------------------------------------- #
# Memory Agent
# --------------------------------------------------------------------------- #


def build_memory_prompt(
    user_id: str,
    profile_fields: Optional[Dict[str, Any]],
    llm_output: str,
    history_cards: List[Dict[str, Any]],
    short_term_window: int,
    previous_memory: Optional[Dict[str, Any]] = None,
    reflection_memory: Optional[Dict[str, Any]] = None,
):
    profile_text = dumps(profile_fields) if profile_fields else "(profile disabled or empty)"
    persona_text = llm_output.strip() if llm_output else "(no persona)"
    persona_text = persona_text[:1800]
    recent_cards = history_cards[-short_term_window:] if history_cards else []

    user_prompt = f"""Construct structured user memory.

[user_id] {user_id}

[structured_profile_fields]
{profile_text}

[semantic_persona (llm_output, may be noisy)]
{persona_text}

[full_history_item_cards] (older -> newer)
{_history_block(history_cards)}

[recent_window_for_short_term] (last {short_term_window})
{_history_block(recent_cards)}
"""
    if previous_memory:
        user_prompt += f"\n[previous_memory]\n{dumps(previous_memory)[:1500]}\n"
    if reflection_memory and reflection_memory.get("reflection_summary"):
        user_prompt += f"\n[reflection_memory]\n{dumps(reflection_memory)}\n"

    user_prompt += """
Output JSON with EXACTLY this schema:
{
  "user_id": "...",
  "long_term_memory": {
    "stable_preferences": [{"content":"...","source":"profile|history|llm_output|reflection","confidence":"low|medium|high","evidence":["..."]}],
    "profile_hypotheses": [{"content":"...","source":"profile|llm_output","confidence":"low|medium|high","evidence":["..."]}],
    "negative_preferences": [{"content":"...","source":"history|reflection|rule","confidence":"low|medium|high"}],
    "risk_rules": [{"content":"...","source":"rule|reflection","confidence":"low|medium|high"}],
    "conflict_notes": [{"conflict":"...","suggested_resolution":"..."}]
  },
  "short_term_memory": {
    "recent_intents": ["..."],
    "recent_evidence_items": ["..."],
    "trend": "...",
    "short_term_constraints": ["..."]
  },
  "ranking_guidance": ["..."]
}
Rules: behavior history > demographic/persona text. Keep entries concise. JSON only."""
    return MEMORY_SYSTEM, user_prompt


# --------------------------------------------------------------------------- #
# Item Memory Agent
# --------------------------------------------------------------------------- #


def build_item_memory_prompt(item_card: Dict[str, Any]):
    user_prompt = f"""Build structured item semantic memory from this compact card.

[item_compact_card]
{dumps(item_card, indent=2)}

Output JSON with EXACTLY this schema:
{{
  "note_id": "{item_card.get('note_id','')}",
  "item_core_identity": "...",
  "category_positioning": "...",
  "key_attributes": ["..."],
  "suitable_scenarios": ["..."],
  "suitable_user_needs": ["..."],
  "price_positioning": "...",
  "risk_notes": ["..."]
}}
JSON only."""
    return ITEM_MEMORY_SYSTEM, user_prompt


# --------------------------------------------------------------------------- #
# Evidence Agent
# --------------------------------------------------------------------------- #


def build_evidence_prompt(
    sample_id: str,
    user_id: str,
    user_memory: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    reflection_memory: Optional[Dict[str, Any]] = None,
    include_item_memory: bool = False,
):
    user_prompt = f"""Assess each candidate's plausibility as the user's NEXT interaction. Do NOT output a final ranking.

[sample_id] {sample_id}
[user_id] {user_id}

[user_memory]
{dumps(user_memory, indent=2)[:3000]}
"""
    if reflection_memory and reflection_memory.get("reflection_summary"):
        user_prompt += f"\n[reflection_memory]\n{dumps(reflection_memory)}\n"
    user_prompt += f"""
[candidate_items]
{_candidate_block(candidates, include_evidence=False, include_item_memory=include_item_memory)}

Output JSON with EXACTLY this COMPACT schema (keep every string short, <=15 words):
{{
  "sample_id": "{sample_id}",
  "global_evidence_guidance": ["..."],
  "candidate_evidence_cards": [
    {{
      "candidate_id": "...",
      "support": [{{"type":"history_match|profile_match|short_term_match|price_compatibility|category_match|semantic_match|item_audience_match|reasonable_exploration","content":"...","strength":"weak|medium|strong"}}],
      "risk": [{{"type":"profile_overgeneralization|history_conflict|semantic_false_positive|context_irrelevance|price_misuse|category_drift|true_mismatch","content":"...","risk":"low|medium|high"}}],
      "usage": "strong_next|plausible_next|reasonable_exploration|weak_next|true_mismatch"
    }}
  ]
}}
Meaning of usage (pick ONE per candidate):
- strong_next: directly supported by history/profile, clearly plausible next pick.
- plausible_next: consistent with tastes, a natural next pick.
- reasonable_exploration: DIFFERS from history but is an adjacent/sensible next step (novelty is NOT a defect) -- use this instead of a risk label for plausible novelty.
- weak_next: only loosely related, little positive support.
- true_mismatch: genuinely unrelated to any preference.
Rules:
- One card per candidate, in candidate order.
- Do NOT penalize a candidate merely for differing from history. Reserve risk/true_mismatch for genuine irrelevance, not novelty.
- At most 2 support items and 2 risk items per candidate. Be concise.
- Omit a field's items with [] when none apply. No prose outside JSON. JSON only."""
    return EVIDENCE_SYSTEM, user_prompt


# --------------------------------------------------------------------------- #
# Rank Agent
# --------------------------------------------------------------------------- #


def build_rank_prompt(
    sample_id: str,
    user_memory: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    evidence_guidance: Optional[Dict[str, Any]] = None,
    reflection_memory: Optional[Dict[str, Any]] = None,
    include_item_memory: bool = False,
    repair_hint: Optional[str] = None,
    exploration: Optional[Dict[str, Any]] = None,
):
    candidate_ids = [c.get("candidate_id") for c in candidates]
    include_evidence = evidence_guidance is not None
    user_prompt = f"""Rank the candidate items by the likelihood that the user will interact with them next.

[sample_id] {sample_id}

[user_memory]
{dumps(user_memory, indent=2)[:2800]}
"""
    if exploration:
        rate = exploration.get("exploration_rate")
        tend = exploration.get("tendency")
        user_prompt += (
            f"\n[user_exploration] tendency={tend}, exploration_rate={rate} "
            f"(fraction of past interactions that were in a NEW category).\n"
            f"This user's next item is OFTEN in a category NOT in their history "
            f"when exploration_rate is high. Do NOT down-rank a candidate just "
            f"because its category is absent from history or a 'collab_memory.avoids' "
            f"note applies — for high/mixed explorers, weight novelty and specific "
            f"item fit over historical-category match.\n"
        )
    if reflection_memory and reflection_memory.get("reflection_summary"):
        user_prompt += f"\n[reflection_memory]\n{dumps(reflection_memory)}\n"
    if evidence_guidance:
        glob = evidence_guidance.get("global_evidence_guidance", [])
        user_prompt += f"\n[global_evidence_guidance]\n{dumps(glob)}\n"
    # Provide the SASRec recall rank as a NEUTRAL reference signal (not a directive).
    # Earlier strong wording ("KEEP high-ranked near top / make minimal changes")
    # caused the model to blindly copy SASRec's rank-1 to position 1, capping HR@1
    # at the SASRec baseline. We now present it as one signal among several and let
    # the model decide based on semantic evidence.
    has_sasrec_rank = any(c.get("sasrec_rank") is not None for c in candidates)
    if has_sasrec_rank:
        user_prompt += (
            "\n[sasrec_recall_rank]\n"
            "Each candidate has 'sasrec_recall_rank' = its rank from a collaborative-"
            "filtering recall model (SASRec). It reflects collaborative/popularity "
            "signal and is ONE useful input among several. It is NOT ground truth: "
            "SASRec's rank-1 is the true next item only ~27% of the time, so the "
            "remaining ~73% of the time a different candidate is correct. Weigh it "
            "together with user_memory and evidence; when semantic evidence clearly "
            "favors another candidate, rank that candidate first even if SASRec did "
            "not rank it first. Decide each position on the full evidence.\n"
        )
    user_prompt += f"""
[candidate_items]
{_candidate_block(candidates, include_evidence=include_evidence, include_item_memory=include_item_memory)}

[candidate_ids] {dumps(candidate_ids)}

Output JSON with EXACTLY this schema:
{{
  "sample_id": "{sample_id}",
  "ranking": [{", ".join(repr(c) for c in candidate_ids)}],
  "top_reason": "...",
  "decision_rules": ["..."],
  "used_evidence": ["..."],
  "downweighted_evidence": ["..."],
  "uncertainty": "..."
}}
Rules:
- 'ranking' MUST be a permutation containing every candidate_id exactly once.
- Prioritize behavior-supported preferences over weak profile/persona labels.
- If a candidate has 'collab_memory' with 'likes'/'avoids' (audiences that
  engaged or rejected this or look-alike items, learned from similar users),
  weigh it as a STRONG collaborative signal: rank UP when the current user
  matches 'likes', DOWN when they match 'avoids'. It separates look-alike items
  in the same category.
- Do not assume the next item just repeats the user's most frequent category.
- No long reasoning. Short decision rules and evidence tags only.
- JSON only."""
    if repair_hint:
        user_prompt += f"\n\n[REPAIR] {repair_hint}"
    return RANK_SYSTEM, user_prompt


# --------------------------------------------------------------------------- #
# Single-LLM baseline ranker
# --------------------------------------------------------------------------- #


def build_single_llm_prompt(
    sample_id: str,
    profile_fields: Optional[Dict[str, Any]],
    llm_output: str,
    history_cards: List[Dict[str, Any]],
    candidates: List[Dict[str, Any]],
    repair_hint: Optional[str] = None,
):
    candidate_ids = [c.get("candidate_id") for c in candidates]
    profile_text = dumps(profile_fields) if profile_fields else "(none)"
    persona_text = (llm_output or "(none)")[:1200]
    user_prompt = f"""Rank the candidate items for next-item prediction.

[sample_id] {sample_id}

[user_profile_fields]
{profile_text}

[user_persona]
{persona_text}

[user_history] (older -> newer)
{_history_block(history_cards)}

[candidate_items]
{_candidate_block(candidates, include_evidence=False, include_item_memory=False)}

[candidate_ids] {dumps(candidate_ids)}

Output JSON:
{{
  "sample_id": "{sample_id}",
  "ranking": [{", ".join(repr(c) for c in candidate_ids)}],
  "top_reason": "..."
}}
'ranking' MUST be a permutation of all candidate_ids. JSON only."""
    if repair_hint:
        user_prompt += f"\n\n[REPAIR] {repair_hint}"
    return SINGLE_LLM_SYSTEM, user_prompt


# --------------------------------------------------------------------------- #
# Reflection Agent
# --------------------------------------------------------------------------- #


def _item_one_line(card: Optional[Dict[str, Any]]) -> str:
    """Compact one-line description of an item for the contrastive block."""
    if not card:
        return "(unknown)"
    info = card.get("item_compact_info", card) or {}
    parts = []
    for k, lbl in (
        ("title", "title"), ("product_name", "product"), ("label", "label"),
        ("category_l1", "cat1"), ("category_l2", "cat2"),
        ("brand_name", "brand"), ("price", "price"),
    ):
        v = info.get(k)
        if v:
            parts.append(f"{lbl}={v}")
    cid = card.get("candidate_id")
    head = f"[{cid}] " if cid else ""
    return head + "; ".join(parts)


def build_reflection_prompt(
    sample_id: str,
    user_id: str,
    user_memory: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    rank_output: Dict[str, Any],
    ground_truth_positive: str,
    evidence_guidance: Optional[Dict[str, Any]] = None,
    reflection_memory: Optional[Dict[str, Any]] = None,
    positive_card: Optional[Dict[str, Any]] = None,
    top_negative_card: Optional[Dict[str, Any]] = None,
    positive_rank: Optional[int] = None,
):
    """Contrastive reflection (AgentCF-style).

    The diagnosis is framed as a pairwise comparison between the ground-truth
    positive item and the highest-ranked WRONG item (top_negative) that the
    ranker placed above (or tied with) the positive. The model must explain the
    DISCRIMINATIVE signal that distinguishes them, and emit memory updates for
    the user AND for each of the two items (scope=item).
    """
    success = positive_rank == 1 if positive_rank is not None else None
    user_prompt = f"""Diagnose the ranking by CONTRASTING the correct item against the wrongly preferred item.

[sample_id] {sample_id}
[user_id] {user_id}

[user_memory]
{dumps(user_memory, indent=2)[:2000]}
"""
    if evidence_guidance:
        user_prompt += f"\n[evidence_guidance]\n{dumps(evidence_guidance.get('global_evidence_guidance', []))}\n"

    user_prompt += f"""
[POSITIVE item — the user actually engaged with this NEXT]
{_item_one_line(positive_card)}

[TOP_NEGATIVE item — the ranker wrongly preferred this (a hard distractor the user did NOT engage)]
{_item_one_line(top_negative_card)}

[rank_output]
ranking: {dumps(rank_output.get('ranking'))}
ground_truth_positive_id: {ground_truth_positive}
positive_rank: {positive_rank if positive_rank is not None else 'unknown'} (1 = perfect)
top_reason: {rank_output.get('top_reason','')}
"""
    if reflection_memory and reflection_memory.get("reflection_summary"):
        user_prompt += f"\n[current_reflection_memory]\n{dumps(reflection_memory)}\n"

    focus = (
        "The ranking was CORRECT (positive ranked first). Briefly confirm the "
        "discriminative signal that made it correct so it transfers."
        if success else
        "The ranking was WRONG. The positive and top_negative are both plausible; "
        "your job is to find the DISCRIMINATIVE signal that should have separated "
        "them — NOT generic preferences. Why did the user pick the positive over "
        "this specific distractor? Consider: novelty/exploration (user trying a NEW "
        "category vs repeating history), specific attribute/scenario fit, freshness, "
        "or fine-grained need — signals beyond coarse category match."
    )
    user_prompt += f"""
[task] {focus}

Output JSON with EXACTLY this schema:
{{
  "sample_id": "...",
  "reflection_type": "success|failure",
  "contrastive_insight": {{
    "positive_vs_negative": "what concretely distinguishes the positive from the top_negative (<=25 words)",
    "discriminative_signal": "the transferable signal type (e.g. exploration_of_new_category, scenario_fit, freshness, specific_attribute, NOT coarse_category_match)",
    "why_ranker_failed": "the specific wrong assumption the ranker made (<=20 words)"
  }},
  "rank_feedback": {{
    "corrective_rule": "a SPECIFIC, transferable rule grounded in the contrast (not a generic 'prefer preferences' platitude)",
    "training_use": "can_be_used_for_sft_or_dpo"
  }},
  "memory_update_ops": [
    {{"op":"add|revise|strengthen|weaken","scope":"long_term|short_term|risk_rule|reflection_memory|item","target_note_id":"(REQUIRED when scope=item: the candidate letter id, e.g. the POSITIVE or TOP_NEGATIVE letter shown above)","content":"concise transferable note","confidence_delta":"small_positive|small_negative|none"}}
  ]
}}
Rules:
- For scope=item updates, describe the SPECIFIC audience for THIS item, anchored
  to concrete attributes/behaviors. Use the candidate letter id (e.g. A, B) as
  target_note_id. Add one for the positive and one for the top_negative.
  GOOD (specific): "Engaged by users who already follow Huawei/HarmonyOS devices."
  BAD (generic platitude, FORBIDDEN): "Engaged by users who like high-quality,
  scenario-relevant items." Such generic notes apply to everything and are useless.
- Each item note must name a concrete user trait, owned-category, brand affinity,
  price tier, or life-stage — NOT vague quality/scenario words.
- Never reveal the answer as a rule (do NOT say 'always rank X first').
- Be specific and discriminative, not generic. JSON only."""
    return REFLECTION_SYSTEM, user_prompt
