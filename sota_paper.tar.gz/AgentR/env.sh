# Machine-specific settings, sourced by every driver (scripts/*.sh, rl/run_grpo.sh).
# Override any of these from the environment instead of editing, e.g.
#   BASE_MODEL=/path/to/Qwen3-8B bash scripts/31_sc_sft.sh cd
# Defaults assume the three envs are on PATH-less locations you set here or export beforehand.

AGENTR_ROOT=${AGENTR_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}
export AGENTR_ROOT

# Python envs (see README "Environments"):
#   MAS_PY     vLLM + transformers + peft   (rollout, SFT, eval, prompt/SFT data building)
#   RECBOLE_PY RecBole 1.2.1                (SASRec training, recall / hard-negative export)
#   VERL_PY    verl 0.9 + vLLM + ray        (GRPO only)
export MAS_PY=${MAS_PY:-$AGENTR_ROOT/.venv_mas/bin/python}
export RECBOLE_PY=${RECBOLE_PY:-$AGENTR_ROOT/.venv_recbole/bin/python}
export VERL_PY=${VERL_PY:-$AGENTR_ROOT/.venv_verl/bin/python}

# Base LLM (Qwen3-8B, HF format). Rollout, SFT init and the zero-shot prompt baseline use it.
export BASE_MODEL=${BASE_MODEL:-$AGENTR_ROOT/models/Qwen/Qwen3-8B}

# CUDA toolkit bin (nvcc/ninja for vLLM / FlashInfer JIT) and a local scratch dir
# (Ray temp dirs need a SHORT path: AF_UNIX socket paths are limited to 107 chars).
export CUDA_BIN=${CUDA_BIN:-/usr/local/cuda-12.9/bin}
export SCRATCH=${SCRATCH:-${TMPDIR:-/tmp}/agentr_${USER:-user}}
export RAY_TMP_ROOT=${RAY_TMP_ROOT:-/tmp/ray_${USER:-user}}   # keep short (socket paths)
mkdir -p "$SCRATCH" "$RAY_TMP_ROOT" 2>/dev/null || true

# Multi-node SFT (scripts/train_sft.sh): NCCL interface PREFIX, not a full NIC name
# (NIC names can differ across nodes, e.g. enp72s0 vs enp73s0).
export NCCL_SOCKET_IFNAME=${NCCL_SOCKET_IFNAME:-enp}
