#!/usr/bin/env bash
# Stage 0: build one Amazon-Reviews-2023 category into the demo schema
#   data/amazon/<Category>/{users,items,interactions}.parquet
# (download -> 10-core filter + chronological split + optional downsample to TARGET_USERS
#  -> LLM persona per user -> finalize). Rednote is provided pre-built; skip this stage.
#
#   bash scripts/00_build_amazon_dataset.sh CDs_and_Vinyl
#   env: TARGET_USERS (15000), TP (1), PERSONA_MODEL ($BASE_MODEL), RAW_DIR (data/amazon_raw)
# Then register the dataset key in agentr_paths.py (DATASETS) if it is not there yet.
source "$(dirname "$0")/lib.sh"
CAT=${1:?Amazon category, e.g. CDs_and_Vinyl}
RAW_DIR=${RAW_DIR:-data/amazon_raw}
OUT_DIR=data/amazon/$CAT
mas_env
cd dataset_builder
LOG "1/4 download $CAT"
"$MAS_PY" 01_download.py --category "$CAT" --raw-dir "../$RAW_DIR"
LOG "2/4 build (filter + split + prune)"
"$MAS_PY" 02_build.py --category "$CAT" --raw-dir "../$RAW_DIR" --out-dir "../$OUT_DIR" \
  --target-users "${TARGET_USERS:-15000}"
LOG "3/4 personas (vLLM, ${PERSONA_MODEL:-$BASE_MODEL})"
"$MAS_PY" 03_gen_personas.py --profiling "../$OUT_DIR/profiling.jsonl" --out "../$OUT_DIR/personas.jsonl" \
  --persona-model "${PERSONA_MODEL:-$BASE_MODEL}" --tp "${TP:-1}"
LOG "4/4 finalize"
"$MAS_PY" 04_finalize.py --out-dir "../$OUT_DIR" --category "$CAT"
LOG "done -> $OUT_DIR"
