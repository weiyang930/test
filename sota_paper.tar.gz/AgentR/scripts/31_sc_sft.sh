#!/usr/bin/env bash
# Stage 3b (line B): source-conditioned listwise ranker, preserve-correct SFT (the main method).
#   prompt = source_conditioned/source_prompt.py (user state + SASRec source order as rank context
#            + candidate cards + relation context; NO evidence agent, NO scores)
#   target = source top-1 correct -> keep source order (preserve)
#            source top-1 wrong   -> [positive] + rest in source order (correct)
#   output = {"sample_id", "ranking": [full permutation]}   (--rationale none)
#
#   bash scripts/31_sc_sft.sh cd          (multi-node: see scripts/train_sft.sh)
#   env: MEMORY_FIELD=user_memory_before (default, = paper runs) | user_memory_after (leak-free)
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
SFT=$SC_DIR/sft_data.jsonl
if ! have "$SFT"; then
  rm -f "$SFT"
  LOG "build preserve-correct SFT data <- $RECALL_TRAIN_TRACES"
  "$MAS_PY" source_conditioned/build_preserve_correct_sft.py --dataset "$DS" \
    --rationale none --subset all --memory_field "${MEMORY_FIELD:-user_memory_before}" \
    --out "$SFT" --examples "$SC_DIR/sft_examples.jsonl"
fi
LOG "sft examples: $(wc -l < "$SFT")"
bash "$SCRIPTS/train_sft.sh" "$SFT" "$SC_DIR/model"
LOG "SC_SFT_DONE -> $SC_DIR/model/merged_model"
