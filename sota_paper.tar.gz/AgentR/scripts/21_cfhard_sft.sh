#!/usr/bin/env bash
# Stage 2b (line A): build rank-agent SFT data from the rollout train traces and train.
#   target = positive moved to #1, the rest kept in the rollout rank agent's order
#   (SFT_BODY_ORDER=model, default); prompt = build_rank_prompt (train == infer).
#
#   bash scripts/21_cfhard_sft.sh cd          (multi-node: see scripts/train_sft.sh)
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
SFT=$CF_DIR/sft/rank_agent_sft.jsonl
if ! have "$SFT"; then
  rm -f "$SFT"
  mkdir -p "$CF_DIR/sft"
  LOG "build_sft_data <- $CF_DIR/traces/train_traces.jsonl"
  "$MAS_PY" -m reflective_mas_rec.scripts.build_sft_data \
    --trace_path "$CF_DIR/traces/train_traces.jsonl" --output_path "$SFT"
fi
LOG "sft examples: $(wc -l < "$SFT")"
bash "$SCRIPTS/train_sft.sh" "$SFT" "$CF_DIR/model"
LOG "CFHARD_SFT_DONE -> $CF_DIR/model/merged_model"
