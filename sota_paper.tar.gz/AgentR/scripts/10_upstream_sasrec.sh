#!/usr/bin/env bash
# Stage 1 (per dataset): SASRec = the candidate source for both settings.
#   1. RecBole atomic files + per-user chronological splits
#   2. train SASRec (LS valid_and_test: trains on train_items only)
#   3. export top-50 real recall per test user           -> real_retrieved candidates (line B)
#   4. export top-200 SASRec hard negatives per user      -> cf_hard candidates (line A)
#   5. build the cf_hard rank samples (1 pos + 9 hard negs; train/valid/test windows)
#
#   GPU=0 bash scripts/10_upstream_sasrec.sh cd
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
export CUDA_VISIBLE_DEVICES=${GPU:-0}

if ! have "$RECBOLE_SPLITS"; then
  LOG "1/5 build_recbole_data -> recbole_baselines/dataset/$RECBOLE_NAME"
  unlink_if_link "recbole_baselines/dataset/$RECBOLE_NAME" "$RECBOLE_SPLITS"
  "$RECBOLE_PY" recbole_baselines/scripts/build_recbole_data.py \
    --data_root "./$DATA_DIR" --out_dir ./recbole_baselines/dataset --name "$RECBOLE_NAME" --min_seq_len 10
fi

CKPT=$(ls -t "$SASREC_DIR"/SASRec-*.pth 2>/dev/null | head -1 || true)
if [ -z "$CKPT" ] || [ "${FORCE:-0}" = 1 ]; then
  LOG "2/5 train SASRec -> $SASREC_DIR"
  "$RECBOLE_PY" recbole_baselines/scripts/train_recbole.py --model SASRec --dataset "$RECBOLE_NAME" \
    --gpu "$CUDA_VISIBLE_DEVICES" --checkpoint_dir "$SASREC_DIR" --results_dir "$OUT/sasrec/results" \
    > "$OUT/logs/sasrec_train.log" 2>&1
  CKPT=$(ls -t "$SASREC_DIR"/SASRec-*.pth | head -1)
fi
LOG "SASRec checkpoint: $CKPT"

have "$TOP50" || { LOG "3/5 export top-50 recall"; "$RECBOLE_PY" recbole_baselines/scripts/export_sasrec_topn_recall.py \
  --checkpoint "$CKPT" --splits "$RECBOLE_SPLITS" --top_n 50 --out "$TOP50.tmp" && mv "$TOP50.tmp" "$TOP50"; }
have "$CF_NEG" || { LOG "4/5 export top-200 hard negatives"; "$RECBOLE_PY" recbole_baselines/scripts/export_cf_hard_negatives.py \
  --checkpoint "$CKPT" --splits "$RECBOLE_SPLITS" --top_n 200 --out "$CF_NEG.tmp" && mv "$CF_NEG.tmp" "$CF_NEG"; }

if ! have "$CF_DIR/samples/test_rank_samples.jsonl"; then
  rm -f "$CF_DIR"/samples/{train,valid,test}_rank_samples.jsonl
  LOG "5/5 build cf_hard rank samples -> $CF_DIR/samples"
  "$MAS_PY" - "$CFG_DIR/cfhard_rollout.yaml" <<'PY'
import sys
from reflective_mas_rec.config import load_config
from reflective_mas_rec.data.dataset import Dataset
from reflective_mas_rec.pipeline.build_data import build_samples
cfg = load_config(sys.argv[1])
build_samples(cfg, dataset=Dataset.load(cfg))
PY
fi
wc -l "$CF_DIR"/samples/{train,valid,test}_rank_samples.jsonl
LOG "UPSTREAM_DONE"
