#!/usr/bin/env bash
# Stage 2a (line A, cf_hard): closed-loop MAS rollout over ALL users with the base LLM.
#   Memory -> Evidence -> Rank(prompt) -> Reflection -> MemoryUpdater, chronological per user
#   (train windows update memory/reflection; valid/test are evaluated with the final memory).
# Sharded over $GPUS by disjoint user windows (exactly equal to a single-process run).
# Output: $CF_DIR/traces/{train,valid,test}_traces.jsonl  (+ prompt-MAS eval in shard dirs)
#
#   GPUS=0,1,2,3,4,5,6,7 bash scripts/20_cfhard_rollout.sh cd
#   quick check: MAX_USERS=8 GPUS=0 bash scripts/20_cfhard_rollout.sh cd
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
if have "$CF_DIR/traces/test_traces.jsonl"; then LOG "traces exist ($CF_DIR/traces), skip (FORCE=1 to redo)"; exit 0; fi
NU=$(count_users "$CF_DIR/samples")
[ -n "${MAX_USERS:-}" ] && NU=$(( MAX_USERS < NU ? MAX_USERS : NU ))
SHARDS=$CF_DIR/shards
run_sharded_rollout "$CFG_DIR/cfhard_rollout.yaml" "$CF_DIR/samples" "$SHARDS" "$NU" cfhard_rollout
gpu_list
merge_shard_traces "$SHARDS" "$CF_DIR/traces" "${SHARD_TOTAL:-${#GPU_ARR[@]}}"
LOG "CFHARD_ROLLOUT_DONE"
