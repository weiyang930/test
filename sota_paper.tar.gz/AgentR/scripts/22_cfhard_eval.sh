#!/usr/bin/env bash
# Stage 2c (line A): trained rank agent on the cf_hard TEST traces (memory + evidence from the
# rollout), one shard per GPU, then aggregate + paired comparison vs the prompt-MAS rollout.
#
#   GPUS=0,1,2,3,4,5,6,7 bash scripts/22_cfhard_eval.sh cd [model_dir] [tag]
#   zero-shot prompt baseline: bash scripts/22_cfhard_eval.sh cd "$BASE_MODEL" promptzs
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
MODEL=${2:-$CF_DIR/model/merged_model}; TAG=${3:-sft}
EV=$CF_DIR/eval/$TAG; mkdir -p "$EV"
gpu_list; K=${#GPU_ARR[@]}
"$MAS_PY" - "$CF_DIR/traces/test_traces.jsonl" "$EV" "$K" "${LIMIT:-0}" <<'PY'
import math, sys
trace, outd, k, limit = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
lines = open(trace).readlines()
if limit: lines = lines[:limit]
sz = math.ceil(len(lines) / k)
for i in range(k):
    open(f"{outd}/test_s{i}.jsonl", "w").writelines(lines[i * sz:(i + 1) * sz])
print(f"split {len(lines)} test traces -> {k} shards")
PY
mas_env
pids=()
for i in "${!GPU_ARR[@]}"; do
  CUDA_VISIBLE_DEVICES=${GPU_ARR[$i]} VLLM_PORT=$((${PORT_BASE:-20000} + 5000 + i * 113)) \
    "$MAS_PY" -m reflective_mas_rec.scripts.eval_trained_rank --model "$MODEL" \
      --trace "$EV/test_s$i.jsonl" --out "$EV/eval_s$i.json" --tp 1 --max-model-len 12288 \
      > "$EV/eval_s$i.log" 2>&1 &
  pids+=($!); sleep "${STAGGER:-10}"
done
fail=0; for p in "${pids[@]}"; do wait "$p" || fail=$((fail + 1)); done
[ "$fail" -eq 0 ] || { LOG "ABORT: $fail eval shard(s) failed, see $EV/eval_s*.log"; exit 1; }
"$MAS_PY" - "$EV" <<'PY'
import glob, json, math, sys
d = sys.argv[1]
ranks = []
for f in sorted(glob.glob(f"{d}/eval_s*.per_sample.jsonl")):
    ranks += [json.loads(l)["positive_rank"] for l in open(f)]
pf = sum(json.load(open(f)).get("parse_fail", 0) for f in glob.glob(f"{d}/eval_s*.json"))
n = len(ranks)
m = {"n": n, "parse_fail": pf}
for k in (1, 3, 5):
    m[f"R@{k}"] = sum(r <= k for r in ranks) / n
    m[f"NDCG@{k}"] = sum(1 / math.log2(r + 1) for r in ranks if r <= k) / n
m["MRR"] = sum(1 / r for r in ranks) / n
json.dump(m, open(f"{d}/metrics.json", "w"), indent=2)
print(json.dumps(m, indent=2))
PY
LOG "CFHARD_EVAL_DONE -> $EV/metrics.json"
