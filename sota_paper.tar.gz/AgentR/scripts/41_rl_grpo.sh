#!/usr/bin/env bash
# Stage 4b (RL): GRPO from the preserve-correct SFT ranker on the OOS env, srA2 recipe
# (source-relative reward + NDCG gain, no std-normalisation; see rl/run_grpo.sh for knobs).
#
#   GPUS=0,1,2,3 bash scripts/41_rl_grpo.sh cd [run_name]
#   8xH100 80GB nodes: GPU_MEM=0.35 LOGP_MICRO=4 PPO_MICRO=2 GPUS=... bash scripts/41_rl_grpo.sh ...
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
NAME=${2:-srA2}; shift $(( $# >= 2 ? 2 : 1 ))   # remaining args -> extra hydra overrides
export NAME
export DATA=${DATA:-$ROOT/$RL_DIR/data/oosall}
export MODEL=${MODEL:-$ROOT/$SC_DIR/model/merged_model}
export OUT=$ROOT/$RL_DIR/runs/$NAME
if [ -e "$OUT/checkpoints" ] && [ "${RESUME:-0}" != 1 ]; then
  echo "run dir $OUT already has checkpoints; pick a new name or RESUME=1 (adds trainer.resume_mode=auto)" >&2; exit 1
fi
mkdir -p "$OUT"
[ -f "$OUT/train.log" ] && mv "$OUT/train.log" "$OUT/train.$(date +%s).log"
LOG "GRPO $NAME: model=$MODEL data=$DATA -> $OUT (log: $OUT/train.log)"
bash rl/run_grpo.sh ${RESUME:+trainer.resume_mode=auto} "$@" > "$OUT/train.log" 2>&1
LOG "RL_GRPO_DONE ($OUT)"
