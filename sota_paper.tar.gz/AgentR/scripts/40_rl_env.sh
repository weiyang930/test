#!/usr/bin/env bash
# Stage 4a (RL): out-of-sample (OOS) GRPO environment that mirrors how TEST prompts are built.
# Train-window SASRec recall is IN-SAMPLE (SASRec trained on those items) -> "copy SASRec"
# becomes reward-optimal and RL collapses. So RL prompts use windows whose target SASRec
# never saw:
#   valid   : target = valid item, main SASRec (LS valid_and_test trains on train_items only)
#   holdout : target = one of the last 4 train items, SASRec retrained on train_items[:-4]
# Memory = line-A cf_hard trace of the same window; prompt = the eval prompt builder.
# User-disjoint train/val split (md5(user)), then valid+holdout are concatenated -> oosall.
# REQUIRES: stage 1 (SASRec, splits), stage 2a (cf_hard train/valid traces).
#
#   GPU=0 bash scripts/40_rl_env.sh cd
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
export CUDA_VISIBLE_DEVICES=${GPU:-0}
unset ROCR_VISIBLE_DEVICES HIP_VISIBLE_DEVICES 2>/dev/null || true
O=$RL_DIR/oos; D=$RL_DIR/data; mkdir -p "$O" "$D"
MAIN=$(ls -t "$SASREC_DIR"/SASRec-*.pth | head -1)
if ! have "$O/valid_top10.jsonl"; then
  LOG "1/4 OOS recall, valid windows (main SASRec)"
  "$RECBOLE_PY" rl/oos_recall.py --checkpoint "$MAIN" --splits "$RECBOLE_SPLITS" --windows valid --out "$O/valid_top10.jsonl.tmp" && mv "$O/valid_top10.jsonl.tmp" "$O/valid_top10.jsonl"
fi
if ! ls "$O"/sasrec_h4/ckpt/SASRec-*.pth >/dev/null 2>&1; then
  LOG "2/4 holdout SASRec on ${RECBOLE_NAME}_h4 (train_items[:-4])"
  H4=recbole_baselines/dataset/${RECBOLE_NAME}_h4/${RECBOLE_NAME}_h4.inter
  if ! have "$H4"; then unlink_if_link "$(dirname "$H4")"; "$MAS_PY" rl/build_h4_dataset.py "$RECBOLE_NAME"; fi
  "$RECBOLE_PY" recbole_baselines/scripts/train_recbole.py --model SASRec --dataset "${RECBOLE_NAME}_h4" --gpu "$CUDA_VISIBLE_DEVICES" \
    --checkpoint_dir "$O/sasrec_h4/ckpt" --results_dir "$O/sasrec_h4/results" > "$O/sasrec_h4.train.log" 2>&1
fi
if ! have "$O/h4_top10.jsonl"; then
  LOG "3/4 OOS recall, holdout windows (h4 SASRec)"
  "$RECBOLE_PY" rl/oos_recall.py --checkpoint "$O/sasrec_h4/ckpt/SASRec-*.pth" --splits "$RECBOLE_SPLITS" \
    --windows holdout --H 4 --out "$O/h4_top10.jsonl.tmp" && mv "$O/h4_top10.jsonl.tmp" "$O/h4_top10.jsonl"
fi
if have "$D/oosall/train.parquet"; then LOG "$D/oosall exists, skip (FORCE=1 to redo)"; exit 0; fi
LOG "4/4 OOS prompts (verl parquet)"
SRC=agentr_rr_${DS}_oos
"$MAS_PY" rl/build_oos_prompts.py --dataset "$DS" --config "$CFG_DIR/recall_eval.yaml" --recall "$O/valid_top10.jsonl" \
  --trace "$CF_DIR/traces/valid_traces.jsonl" --window_tag valid --data_source "$SRC" --out_dir "$D/oosvalid"
"$MAS_PY" rl/build_oos_prompts.py --dataset "$DS" --config "$CFG_DIR/recall_eval.yaml" --recall "$O/h4_top10.jsonl" \
  --trace "$CF_DIR/traces/train_traces.jsonl" --window_tag h4 --data_source "$SRC" --out_dir "$D/oosh4"
"$MAS_PY" - "$D/oosvalid" "$D/oosh4" "$D/oosall" <<'PY'
import os, sys
import pandas as pd
a, b, o = sys.argv[1:4]; os.makedirs(o, exist_ok=True)
for s in ["train", "val"]:
    d = pd.concat([pd.read_parquet(f"{a}/{s}.parquet"), pd.read_parquet(f"{b}/{s}.parquet")], ignore_index=True)
    if s == "train":
        d = d.sample(frac=1.0, random_state=42).reset_index(drop=True)
    d.to_parquet(f"{o}/{s}.parquet", index=False); print(o, s, len(d))
tu = set(pd.read_parquet(f"{o}/train.parquet").extra_info.map(lambda e: e["user_id"]))
vu = set(pd.read_parquet(f"{o}/val.parquet").extra_info.map(lambda e: e["user_id"]))
print("user overlap train/val:", len(tu & vu))
PY
LOG "RL_ENV_DONE -> $D/oosall"
