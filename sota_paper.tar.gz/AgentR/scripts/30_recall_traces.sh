#!/usr/bin/env bash
# Stage 3a (line B, real_retrieved): training traces on REAL SASRec recall lists + the test set.
#   1. for every cf_hard train window, SASRec top-10 on its prefix (positive kept/forced in;
#      pos_in_recall marks natural hits)
#   2. keep hit-only windows (positive naturally in SASRec top-10)
#   3. memory(+evidence) trace generation with the base LLM (sharded over $GPUS)
#   4. test set = SASRec top-10 recall-hit test users, memory taken from the line-A cf_hard
#      test trace of the same user  (REQUIRES scripts/20_cfhard_rollout.sh to have run)
# Output: $RECALL_TRAIN_TRACES, $RECALL_INPUT
#
#   GPUS=0,1,2,3,4,5,6,7 bash scripts/30_recall_traces.sh cd
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
S=$RECALL_DIR/samples; mkdir -p "$S"
CKPT=$(ls -t "$SASREC_DIR"/SASRec-*.pth | head -1)
gpu_list
if ! have "$S/train_rank_samples_all.jsonl"; then
  rm -f "$S/train_rank_samples_all.jsonl"
  LOG "1/4 real-recall candidates for train windows (SASRec $CKPT)"
  CUDA_VISIBLE_DEVICES=${GPU_ARR[0]} "$RECBOLE_PY" recbole_baselines/scripts/build_recall_train_candidates.py \
    --checkpoint "$CKPT" --in_samples "$CF_DIR/samples/train_rank_samples.jsonl" \
    --out "$S/train_rank_samples_all.jsonl" --k 10
fi
if ! have "$RECALL_TRAIN_TRACES"; then
LOG "2/4 hit-only filter"
rm -f "$S"/{train,valid,test}_rank_samples.jsonl
"$MAS_PY" - "$S/train_rank_samples_all.jsonl" "$S/train_rank_samples.jsonl" <<'PY'
import json, sys
n = k = 0
with open(sys.argv[1]) as f, open(sys.argv[2], "w") as o:
    for line in f:
        n += 1
        if json.loads(line).get("pos_in_recall") is True:
            o.write(line); k += 1
print(f"hit-only kept {k}/{n} = {k / max(n, 1):.3f}")
PY
: > "$S/valid_rank_samples.jsonl"; : > "$S/test_rank_samples.jsonl"   # gen only touches train
NU=$(count_users "$S")
[ -n "${MAX_USERS:-}" ] && NU=$(( MAX_USERS < NU ? MAX_USERS : NU ))
LOG "3/4 trace generation over $NU users"
run_sharded_rollout "$CFG_DIR/recall_gen.yaml" "$S" "$RECALL_DIR/shards" "$NU" recall_gen
merge_shard_traces "$RECALL_DIR/shards" "$RECALL_DIR/traces" "${SHARD_TOTAL:-${#GPU_ARR[@]}}" train
else LOG "train traces exist ($RECALL_TRAIN_TRACES), skip 2-3"; fi
if ! have "$RECALL_INPUT"; then
  LOG "4/4 recall-hit test set (memory from $CF_DIR/traces/test_traces.jsonl)"
  rm -f "$RECALL_INPUT"
  "$MAS_PY" recbole_baselines/scripts/build_recall_intersect.py --recall "$TOP50" \
    --trace "$CF_DIR/traces/test_traces.jsonl" --out_dir "$(dirname "$RECALL_INPUT")" --top_k 10
fi
LOG "RECALL_TRACES_DONE"
