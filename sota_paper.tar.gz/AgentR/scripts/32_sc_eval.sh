#!/usr/bin/env bash
# Stage 3c (line B): evaluate a source-conditioned ranker on the recall-hit test users
# (10 SASRec candidates, greedy, parse failures fall back to source order), then the
# preserve/rescue/false-damage analysis + paired bootstrap / McNemar vs the SASRec source.
#
#   GPU=0 bash scripts/32_sc_eval.sh cd [model_dir] [tag]
#   zero-shot prompt baseline: bash scripts/32_sc_eval.sh cd "$BASE_MODEL" promptzs
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
MODEL=${2:-$SC_DIR/model/merged_model}; TAG=${3:-sft}
PRED=${PRED:-$SC_DIR/eval/$TAG}; mkdir -p "$(dirname "$PRED")"
mas_env
export CUDA_VISIBLE_DEVICES=${GPU:-0} VLLM_PORT=${VLLM_PORT:-$((22000 + ${GPU:-0} * 97))}
"$MAS_PY" source_conditioned/evaluate_ranker.py --dataset "$DS" --config "$CFG_DIR/recall_eval.yaml" \
  --model "$MODEL" --out "$PRED" ${LIMIT:+--limit $LIMIT} ${EVAL_EXTRA:-}
"$MAS_PY" source_conditioned/analyze_preserve_rescue.py --dataset "$DS" \
  --per_sample "$PRED.per_sample.jsonl" --diagnosis "$PRED.full.jsonl" --label "${DS}_$TAG" \
  --out "$PRED.analysis.md"
"$MAS_PY" rl/compare.py --a "$PRED.per_sample.jsonl" --b "$PRED.per_sample.jsonl" \
  --a_name "$TAG" --b_name SASRec --b_source | tee "$PRED.vs_sasrec.txt"
LOG "SC_EVAL_DONE -> $PRED.{json,per_sample.jsonl,analysis.md,vs_sasrec.txt}"
