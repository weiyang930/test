# Shared helpers for the pipeline drivers. Usage at the top of a driver:
#   source "$(dirname "$0")/lib.sh"; ds_setup "$1"
set -euo pipefail
SCRIPTS=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(dirname "$SCRIPTS")
source "$ROOT/env.sh"
cd "$ROOT"

LOG() { echo "[${DS:-agentr} $(date +%H:%M:%S)] $*"; }

# Every stage skips outputs that already exist (resumable, and never overwrites artifacts
# linked in by tools/link_legacy_outputs.sh). FORCE=1 redoes a stage.
have() { [ "${FORCE:-0}" != 1 ] && [ -s "$1" ]; }
unlink_if_link() { local x; for x in "$@"; do [ -L "$x" ] && rm -f "$x"; done; return 0; }

mas_env() {   # PATH for vLLM (ninja + nvcc) inside the MAS env
  export PATH="$(dirname "$MAS_PY"):$CUDA_BIN:$PATH"
  export VLLM_LOGGING_LEVEL=${VLLM_LOGGING_LEVEL:-WARNING} TOKENIZERS_PARALLELISM=false
  export CC=${CC:-/usr/bin/gcc} CXX=${CXX:-/usr/bin/g++}   # triton JIT needs a C compiler
}

# ds_setup <ds>: export the dataset's paths (agentr_paths.py) and render its configs.
ds_setup() {
  local ds=${1:?dataset key required (python agentr_paths.py --list)}
  local sh
  sh=$("$MAS_PY" "$ROOT/agentr_paths.py" "$ds" --shell --make-configs)
  eval "$sh"
  mkdir -p "$OUT/logs"
}

# count_users <samples_dir>: distinct users over {train,valid,test}_rank_samples.jsonl
# (= the user list the rollout windows over).
count_users() {
  "$MAS_PY" - "$1" <<'PY'
import json, os, sys
users = set()
for s in ("train", "valid", "test"):
    p = os.path.join(sys.argv[1], f"{s}_rank_samples.jsonl")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            if line.strip():
                users.add(json.loads(line)["user_id"])
print(len(users))
PY
}

# gpu_list -> array GPU_ARR from $GPUS (default: all visible GPUs)
gpu_list() {
  local g=${GPUS:-$(nvidia-smi --query-gpu=index --format=csv,noheader | paste -sd, -)}
  IFS=',' read -r -a GPU_ARR <<< "$g"
}

# user_windows <n_users> <k>: prints "offsets|counts" for k disjoint user windows.
# The rollout windows by DISTINCT user (users[offset:offset+max_users]), so sharding is
# exact (identical traces to a single-process run), never approximate.
user_windows() {
  "$MAS_PY" - "$1" "$2" <<'PY'
import sys
n, k = int(sys.argv[1]), int(sys.argv[2])
b, r = divmod(n, k)
cnt = [b] * (k - r) + [b + 1] * r
off = [sum(cnt[:i]) for i in range(k)]
print(" ".join(map(str, off)) + "|" + " ".join(map(str, cnt)))
PY
}

# run_sharded_rollout <config> <samples_dir> <shard_root> <n_users> <log_prefix>
# One vLLM process per GPU in $GPUS, each on a disjoint user window; waits for all.
# (Multi-node: run this driver on each node with SHARD_BASE/SHARD_TOTAL set, e.g.
#  node0 SHARD_BASE=0 SHARD_TOTAL=16, node1 SHARD_BASE=8 SHARD_TOTAL=16, both GPUS=0..7.)
run_sharded_rollout() {
  local cfg=$1 samples=$2 root=$3 nusers=$4 logp=$5
  gpu_list
  local total=${SHARD_TOTAL:-${#GPU_ARR[@]}} base=${SHARD_BASE:-0}
  local w; w=$(user_windows "$nusers" "$total")
  local offs cnts
  read -r -a offs <<< "${w%%|*}"; read -r -a cnts <<< "${w##*|}"
  LOG "rollout: $nusers users -> $total shards (this node: $base..$((base + ${#GPU_ARR[@]} - 1)))"
  mas_env
  local pids=() j
  for j in "${!GPU_ARR[@]}"; do
    local i=$((base + j)); [ "$i" -lt "$total" ] || break
    local sh="$root/s$i"; mkdir -p "$sh/samples"
    for f in train valid test; do ln -sf "$ROOT/$samples/${f}_rank_samples.jsonl" "$sh/samples/${f}_rank_samples.jsonl"; done
    CUDA_VISIBLE_DEVICES=${GPU_ARR[$j]} VLLM_PORT=$((${PORT_BASE:-20000} + i * 113)) \
      "$MAS_PY" -m reflective_mas_rec.scripts.run_exp --config "$cfg" --mode prompt_rollout \
        --output-dir "$sh" --user-offset "${offs[$i]}" --max-users "${cnts[$i]}" \
        > "$OUT/logs/${logp}_s$i.log" 2>&1 &
    pids+=($!)
    sleep "${STAGGER:-10}"   # stagger engine start-up (concurrent loads OOM / contend on fsx)
  done
  local fail=0 p
  for p in "${pids[@]}"; do wait "$p" || fail=$((fail + 1)); done
  [ "$fail" -eq 0 ] || { LOG "ABORT: $fail rollout shard(s) failed, see $OUT/logs/${logp}_s*.log"; exit 1; }
}

# merge_shard_traces <shard_root> <dst_dir> <n_shards> [splits...]
merge_shard_traces() {
  local root=$1 dst=$2 n=$3; shift 3
  local splits=("$@"); [ ${#splits[@]} -gt 0 ] || splits=(train valid test)
  mkdir -p "$dst"
  local s i
  for s in "${splits[@]}"; do
    rm -f "$dst/${s}_traces.jsonl"   # never write through a (legacy) symlink
    : > "$dst/${s}_traces.jsonl"
    for ((i = 0; i < n; i++)); do
      [ -f "$root/s$i/traces/${s}_traces.jsonl" ] && cat "$root/s$i/traces/${s}_traces.jsonl" >> "$dst/${s}_traces.jsonl"
    done
    LOG "merged ${s}_traces: $(wc -l < "$dst/${s}_traces.jsonl")"
  done
}
