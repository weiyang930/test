#!/usr/bin/env bash
# Stage 4c (RL): merge verl FSDP actor checkpoint(s) -> HF, evaluate with the SAME
# evaluate_ranker as SFT, and compare (paired bootstrap + McNemar) vs SFT and vs SASRec.
# Pre-registered checkpoint for srA2 = step 100 (val reward is not a reliable selector).
#
#   GPU=0 bash scripts/42_rl_eval.sh cd srA2 100 [more steps...]
#   CLEAN_CKPT=1 deletes global_step_<N> (~90 GB each) after a successful merge.
source "$(dirname "$0")/lib.sh"; ds_setup "$1"
NAME=${2:?run name}; shift 2
STEPS=("$@"); [ ${#STEPS[@]} -gt 0 ] || STEPS=(100)
RUN=$RL_DIR/runs/$NAME
SFT_PS=${SFT_PS:-$SC_DIR/eval/sft.per_sample.jsonl}
for st in "${STEPS[@]}"; do
  CK=$RUN/checkpoints/global_step_$st/actor; HF=$RUN/hf/step$st
  if [ ! -f "$HF/config.json" ]; then
    LOG "merge $CK -> $HF"
    PYTHONPATH="$ROOT/rl:${PYTHONPATH:-}" "$VERL_PY" -m verl.model_merger merge --backend fsdp --local_dir "$CK" --target_dir "$HF"
    cp -n "$CK"/huggingface/*token* "$CK"/huggingface/chat_template.jinja "$HF"/ 2>/dev/null || true
    [ "${CLEAN_CKPT:-0}" = 1 ] && [ -f "$HF/config.json" ] && rm -rf "$RUN/checkpoints/global_step_$st"
  fi
  PRED=$ROOT/$RUN/eval/step$st/rr bash "$SCRIPTS/32_sc_eval.sh" "$DS" "$ROOT/$HF" "rl_${NAME}_step$st"
  P=$RUN/eval/step$st/rr
  {
    if [ -f "$SFT_PS" ]; then
      echo "=== $NAME step$st vs SFT"
      "$MAS_PY" rl/compare.py --a "$P.per_sample.jsonl" --b "$SFT_PS" --a_name RL --b_name SFT
    fi
    echo "=== $NAME step$st vs SASRec"
    "$MAS_PY" rl/compare.py --a "$P.per_sample.jsonl" --b "$P.per_sample.jsonl" --a_name RL --b_name SASRec --b_source
  } | tee "$RUN/eval/step$st/compare_summary.txt"
done
LOG "RL_EVAL_DONE"
