#!/usr/bin/env bash
# LoRA SFT of the rank agent (reflective_mas_rec/scripts/train_rank_sft.py) with the paper recipe:
#   Qwen3-8B, LoRA r16/a32/dropout .05 on all attn+MLP projections, 1 epoch, lr 1e-4,
#   warmup .03 + cosine, max_len 6144, per-device batch 1, effective batch 32, bf16.
# Auto-merges the adapter into <out>/merged_model at the end.
#
#   bash scripts/train_sft.sh <train.jsonl> <out_dir>
# Single node by default (all visible GPUs). Multi-node: run once per node with
#   NNODES=2 NODE_RANK=0|1 MASTER_ADDR=<node0 ip> MASTER_PORT=29461 bash scripts/train_sft.sh ...
# GRAD_ACCUM defaults to keep the effective batch at 32 (= 32 / (NNODES*NPROC)).
# SFT_LOSS_SCOPE=full (default) | top1 is read by train_rank_sft.py.
source "$(dirname "$0")/lib.sh"
DATA=${1:?train jsonl}; OUTD=${2:?output dir}
NNODES=${NNODES:-1}; NODE_RANK=${NODE_RANK:-0}
NPROC=${NPROC:-$(nvidia-smi --query-gpu=index --format=csv,noheader | wc -l)}
EFF_BATCH=${EFF_BATCH:-32}
GRAD_ACCUM=${GRAD_ACCUM:-$(( EFF_BATCH / (NNODES * NPROC) > 0 ? EFF_BATCH / (NNODES * NPROC) : 1 ))}
if [ "${FORCE:-0}" != 1 ] && [ -f "$OUTD/merged_model/config.json" ]; then
  echo "[train_sft] $OUTD/merged_model exists, skip (FORCE=1 to retrain)"; exit 0
fi
[ -L "$OUTD/merged_model" ] && rm -f "$OUTD/merged_model"   # never save through a legacy symlink
mas_env
export FI_PROVIDER=${FI_PROVIDER:-efa} FI_EFA_USE_DEVICE_RDMA=${FI_EFA_USE_DEVICE_RDMA:-1}
export NCCL_DEBUG=${NCCL_DEBUG:-WARN} OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}
mkdir -p "$OUTD"
echo "[train_sft] nnodes=$NNODES node_rank=$NODE_RANK nproc=$NPROC grad_accum=$GRAD_ACCUM -> eff batch $((NNODES * NPROC * GRAD_ACCUM))"
"$MAS_PY" -m torch.distributed.run \
  --nnodes="$NNODES" --nproc-per-node="$NPROC" --node-rank="$NODE_RANK" \
  --master-addr="${MASTER_ADDR:-127.0.0.1}" --master-port="${MASTER_PORT:-29461}" \
  reflective_mas_rec/scripts/train_rank_sft.py \
    --model-name "${INIT_MODEL:-$BASE_MODEL}" --train-data "$DATA" --output-dir "$OUTD" \
    --epochs "${EPOCHS:-1}" --batch-size 1 --grad-accum-steps "$GRAD_ACCUM" \
    --max-length "${MAX_LEN:-6144}" --learning-rate "${LR:-1e-4}" ${SFT_EXTRA:-}
