`pip freeze` of the three environments the paper runs used (2026-10, Linux x86_64, CUDA 12.9 driver, H100/B200).

- `mas.freeze.txt`: `MAS_PY`. vLLM 0.25.0, torch 2.11.0+cu130, transformers 5.13.1,
  peft 0.19.1. On Blackwell, uninstall `torchcodec` and put `ninja` on PATH.
- `recbole.freeze.txt`: `RECBOLE_PY`. recbole 1.2.1, which needs numpy 1.26.4 and scipy
  1.11.4.
- `verl.freeze.txt`: `VERL_PY`. verl v0.9.0 (git 483b8a009ba3a97563edee3a19887e4862b8094a,
  installed from source), vLLM 0.24.0, ray 2.58. The only extra code verl needs here is
  the two compat files in `rl/compat/`.
