#!/usr/bin/env python
"""Phase II + reusable analysis: preserve/rescue bottleneck breakdown.

Takes a per_sample.jsonl (fields: user_id, sasrec_rank, mas_rank, parse_success)
and optionally a diagnosis.jsonl (full model_ranking for rescuable samples), plus
the dataset, and produces the full source-aware bottleneck report:

  - preserve/rescue confusion (preserve_success / false_damage / rescue_success /
    missed_rescue) and all rates + net rescue
  - metrics on source-correct / source-wrong subsets and by source-rank bucket
  - exploratory / new-category / new-brand splits (joined from history + items)
  - Kendall tau distance from source order, top1-change rate, unnecessary-reorder
    rate (where full ranking available)
  - McNemar (HR@1 vs source) + paired bootstrap for HR@1/3/5, NDCG@5, MRR

Reused by every experiment via --label. Read-only.

Usage:
  python analyze_preserve_rescue.py --dataset cd \
      --per_sample outputs/eval_recall_cd_8b_unanchor_v2/mas_rerank_result.per_sample.jsonl \
      --diagnosis  outputs/eval_recall_cd_8b_unanchor_v2/mas_rerank_result.diagnosis.jsonl \
      --label v2model --out <report.md>
"""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from common import (
    DATASET_KEYS,
    PROJ,
    candidate_letter_mapping,
    dataset,
    kendall_tau_distance,
    load_items,
    metrics_from_rank,
    norm_brand,
    read_jsonl,
    source_letter_order,
)


def _mean_metrics(ranks):
    if not ranks:
        return {k: float("nan") for k in ["hr@1", "hr@3", "hr@5", "ndcg@5", "mrr", "positive_rank"]}
    acc = defaultdict(float)
    for r in ranks:
        m = metrics_from_rank(r)
        for k, v in m.items():
            acc[k] += v
    return {k: acc[k] / len(ranks) for k in acc}


def _fmt_row(name, ranks):
    m = _mean_metrics(ranks)
    return (f"| {name} | {len(ranks)} | {m['hr@1']:.4f} | {m['hr@3']:.4f} | "
            f"{m['hr@5']:.4f} | {m['ndcg@5']:.4f} | {m['mrr']:.4f} | {m['positive_rank']:.3f} |")


def mcnemar(sas_hit, mas_hit):
    """R@1 McNemar. Returns (gain, lose, net, z)."""
    gain = sum(1 for s, m in zip(sas_hit, mas_hit) if (not s) and m)  # sas miss -> mas hit
    lose = sum(1 for s, m in zip(sas_hit, mas_hit) if s and (not m))  # sas hit -> mas miss
    b, c = lose, gain
    z = 0.0 if (b + c) == 0 else (abs(b - c) - 1) / ((b + c) ** 0.5)
    # signed z: positive means MAS better
    z = z if gain >= lose else -z
    return gain, lose, gain - lose, z


def paired_bootstrap(sas_ranks, mas_ranks, B=10000, seed=0):
    rng = np.random.default_rng(seed)
    n = len(sas_ranks)
    sas = np.array(sas_ranks, dtype=float)
    mas = np.array(mas_ranks, dtype=float)

    def metric_vec(ranks, fn):
        return np.array([fn(int(r)) for r in ranks], dtype=float)

    metrics = {
        "HR@1": lambda r: 1.0 if r <= 1 else 0.0,
        "HR@3": lambda r: 1.0 if r <= 3 else 0.0,
        "HR@5": lambda r: 1.0 if r <= 5 else 0.0,
        "NDCG@5": lambda r: (1.0 / np.log2(r + 1)) if r <= 5 else 0.0,
        "MRR": lambda r: 1.0 / r,
    }
    out = {}
    idx_all = np.arange(n)
    for name, fn in metrics.items():
        sv = metric_vec(sas, fn)
        mv = metric_vec(mas, fn)
        delta = mv.mean() - sv.mean()
        diffs = mv - sv
        boot = np.empty(B)
        for b in range(B):
            samp = rng.integers(0, n, n)
            boot[b] = diffs[samp].mean()
        lo, hi = np.percentile(boot, [2.5, 97.5])
        p = 2 * min((boot <= 0).mean(), (boot >= 0).mean())
        out[name] = {"sas": float(sv.mean()), "mas": float(mv.mean()),
                     "delta": float(delta), "ci": (float(lo), float(hi)), "p": float(p)}
    return out


def run(ds_key, per_sample_path, diagnosis_path, label, out_path, B):
    ds = dataset(ds_key)
    L = []
    W = L.append
    W(f"# Bottleneck analysis — {ds_key} — `{label}`\n")
    W(f"- per_sample: `{per_sample_path}`\n")
    if diagnosis_path:
        W(f"- diagnosis: `{diagnosis_path}`\n")

    ps = read_jsonl(per_sample_path)
    # per-user source & model rank
    by_uid = {}
    for r in ps:
        sr, mr = r.get("sasrec_rank"), r.get("mas_rank")
        if sr is None or mr is None:
            continue
        by_uid[r["user_id"]] = {"sasrec_rank": sr, "mas_rank": mr,
                                "parse_success": r.get("parse_success", True)}
    uids = list(by_uid)
    n = len(uids)
    W(f"- usable samples: **{n}**\n")

    sas_ranks = [by_uid[u]["sasrec_rank"] for u in uids]
    mas_ranks = [by_uid[u]["mas_rank"] for u in uids]
    sas_hit = [r == 1 for r in sas_ranks]
    mas_hit = [r == 1 for r in mas_ranks]

    # =====================================================================
    # Preserve/rescue confusion
    # =====================================================================
    preserve_success = sum(1 for u in uids
                           if by_uid[u]["sasrec_rank"] == 1 and by_uid[u]["mas_rank"] == 1)
    false_damage = sum(1 for u in uids
                       if by_uid[u]["sasrec_rank"] == 1 and by_uid[u]["mas_rank"] != 1)
    rescue_success = sum(1 for u in uids
                         if by_uid[u]["sasrec_rank"] != 1 and by_uid[u]["mas_rank"] == 1)
    missed_rescue = sum(1 for u in uids
                        if by_uid[u]["sasrec_rank"] != 1 and by_uid[u]["mas_rank"] != 1)
    src_correct = preserve_success + false_damage
    src_wrong = rescue_success + missed_rescue

    W("\n## Preserve / rescue confusion\n")
    W("| | model_top1 == positive | model_top1 != positive |\n|---|---|---|\n")
    W(f"| **source_top1 == positive** (n={src_correct}) | preserve_success = {preserve_success} "
      f"| false_damage = {false_damage} |\n")
    W(f"| **source_top1 != positive** (n={src_wrong}) | rescue_success = {rescue_success} "
      f"| missed_rescue = {missed_rescue} |\n")
    W("\n")
    W(f"- preservation rate = {preserve_success}/{src_correct} = "
      f"{preserve_success/src_correct:.4f}\n" if src_correct else "- preservation rate: n/a\n")
    W(f"- **false damage rate = {false_damage}/{src_correct} = "
      f"{false_damage/src_correct:.4f}**\n" if src_correct else "")
    W(f"- rescue rate = {rescue_success}/{src_wrong} = "
      f"{rescue_success/src_wrong:.4f}\n" if src_wrong else "")
    W(f"- missed rescue rate = {missed_rescue}/{src_wrong} = "
      f"{missed_rescue/src_wrong:.4f}\n" if src_wrong else "")
    W(f"- **net rescue = rescue_success - false_damage = {rescue_success} - {false_damage} "
      f"= {rescue_success - false_damage}**\n")
    W(f"- net rescue rate over all hit users = {(rescue_success - false_damage)/n:+.4f}\n")
    top1_change = sum(1 for u in uids
                      if (by_uid[u]["mas_rank"] == 1) != (by_uid[u]["sasrec_rank"] == 1))
    W(f"- top1 change rate (vs source, either direction) = {top1_change}/{n} = "
      f"{top1_change/n:.4f}\n")

    # =====================================================================
    # Metrics: overall, source-correct, source-wrong, by source-rank bucket
    # =====================================================================
    W("\n## Metrics by subset (model ranking)\n")
    W("| subset | n | HR@1 | HR@3 | HR@5 | NDCG@5 | MRR | pos_rank |\n"
      "|---|---|---|---|---|---|---|---|\n")
    W(_fmt_row("ALL (model)", mas_ranks) + "\n")
    W(_fmt_row("ALL (source)", sas_ranks) + "\n")
    sc = [by_uid[u]["mas_rank"] for u in uids if by_uid[u]["sasrec_rank"] == 1]
    sw = [by_uid[u]["mas_rank"] for u in uids if by_uid[u]["sasrec_rank"] != 1]
    W(_fmt_row("source-correct (model)", sc) + "\n")
    W(_fmt_row("source-wrong (model)", sw) + "\n")
    buckets = {"1": [1], "2": [2], "3": [3], "4-5": [4, 5], "6-10": [6, 7, 8, 9, 10]}
    for bname, rks in buckets.items():
        sub = [by_uid[u]["mas_rank"] for u in uids if by_uid[u]["sasrec_rank"] in rks]
        W(_fmt_row(f"src_rank={bname} (model)", sub) + "\n")

    # =====================================================================
    # Exploratory / category / brand splits (join history + items)
    # =====================================================================
    W("\n## Splits by positive novelty (join user history + item metadata)\n")
    items = load_items(ds.items_parquet)
    inp = {r["user_id"]: r for r in read_jsonl(ds.recall_input)}
    split_new_brand, split_same_brand = [], []
    split_new_cat, split_same_cat = [], []
    covered = 0
    for u in uids:
        r = inp.get(u)
        if not r:
            continue
        covered += 1
        pos = r["positive_item"]
        hist = r.get("history_items", [])
        pos_brand = norm_brand(items.get(pos, {}).get("brand", ""))
        pos_cat = items.get(pos, {}).get("category_l2", "")
        hist_brands = {norm_brand(items.get(h, {}).get("brand", "")) for h in hist}
        hist_cats = {items.get(h, {}).get("category_l2", "") for h in hist}
        mr = by_uid[u]["mas_rank"]
        (split_same_brand if (pos_brand and pos_brand in hist_brands) else split_new_brand).append(mr)
        (split_same_cat if (pos_cat and pos_cat in hist_cats) else split_new_cat).append(mr)
    W(f"- joined {covered}/{n} users to history+metadata\n\n")
    W("| split | n | HR@1 | HR@3 | HR@5 | NDCG@5 | MRR | pos_rank |\n"
      "|---|---|---|---|---|---|---|---|\n")
    W(_fmt_row("same-brand positive", split_same_brand) + "\n")
    W(_fmt_row("NEW-brand positive (exploratory)", split_new_brand) + "\n")
    W(_fmt_row("same-category positive", split_same_cat) + "\n")
    W(_fmt_row("NEW-category positive", split_new_cat) + "\n")
    W(f"\n- exploratory (new-brand) share = {len(split_new_brand)}/{covered} = "
      f"{len(split_new_brand)/covered:.4f}\n" if covered else "")

    # =====================================================================
    # Kendall tau + unnecessary reorder (needs full model ranking; diagnosis)
    # =====================================================================
    W("\n## Order-level stats (Kendall tau, unnecessary reorder)\n")
    if diagnosis_path and Path(diagnosis_path).exists():
        diag = read_jsonl(diagnosis_path)
        taus, reorder_when_correct, correct_covered = [], 0, 0
        n_full = 0
        for d in diag:
            u = d["user_id"]
            if u not in inp:
                continue
            model_ranking = d.get("model_ranking")
            if not model_ranking:
                continue
            src_order = source_letter_order(inp[u]["sample_id"], inp[u]["candidate_note_ids"])
            tau = kendall_tau_distance(model_ranking, src_order)
            taus.append(tau)
            n_full += 1
            if by_uid[u]["sasrec_rank"] == 1:  # source-correct
                correct_covered += 1
                if tau > 0:
                    reorder_when_correct += 1
        W(f"- diagnosis covers {n_full} samples with full model ranking "
          f"(NOTE: current eval dumps diagnosis ONLY for rescuable source_rank>1 "
          f"samples, so source-correct coverage here = {correct_covered}).\n")
        if taus:
            W(f"- mean Kendall tau distance from source order (over covered) = "
              f"{np.mean(taus):.3f} (max possible = 45 for 10 items)\n")
        if correct_covered:
            W(f"- unnecessary reordering rate when source_top1 correct = "
              f"{reorder_when_correct}/{correct_covered} = "
              f"{reorder_when_correct/correct_covered:.4f}\n")
        W("- ⚠️ Full order-level coverage for the source-correct set requires dumping "
          "ranking for ALL users; our `evaluate_ranker.py` does this for every new "
          "experiment. Existing v2 diagnosis only covers rescuable samples.\n")
    else:
        W("- no diagnosis file provided; order-level stats skipped. "
          "`evaluate_ranker.py` dumps full ranking for all users in new experiments.\n")

    # =====================================================================
    # Significance
    # =====================================================================
    W("\n## Significance\n")
    gain, lose, net, z = mcnemar(sas_hit, mas_hit)
    sig = "SIGNIFICANT (p<0.05)" if abs(z) >= 1.96 else "not significant"
    W(f"- **McNemar HR@1 vs source**: gain={gain}, lose={lose}, net={net:+d}, "
      f"z={z:.3f} → {sig}\n\n")
    boot = paired_bootstrap(sas_ranks, mas_ranks, B=B)
    W("Paired bootstrap (B={}):\n\n".format(B))
    W("| metric | source | model | delta | 95% CI | p | sig |\n|---|---|---|---|---|---|---|\n")
    for m, v in boot.items():
        sig = "***" if v["p"] < 0.05 else ""
        W(f"| {m} | {v['sas']:.4f} | {v['mas']:.4f} | {v['delta']:+.4f} | "
          f"[{v['ci'][0]:+.4f}, {v['ci'][1]:+.4f}] | {v['p']:.4f} | {sig} |\n")
    W("\n- ⚠️ Do NOT claim success on McNemar HR@1 alone; report the full bootstrap.\n")

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text("".join(L), encoding="utf-8")

    # machine-readable sidecar for collect_results.py (bootstrap significance)
    sidecar = {
        "label": label, "dataset": ds_key, "n": len(sas_ranks),
        "mcnemar_hr1": {"gain": gain, "lose": lose, "net": net, "z": z,
                        "significant": abs(z) >= 1.96},
        "bootstrap": {m: {"sas": v["sas"], "mas": v["mas"], "delta": v["delta"],
                          "ci": v["ci"], "p": v["p"], "significant": v["p"] < 0.05}
                      for m, v in boot.items()},
    }
    Path(str(out_path).rsplit(".", 1)[0] + ".json").write_text(
        json.dumps(sidecar, indent=2), encoding="utf-8")
    print(f"[analyze] wrote {out_path}")
    print(f"[analyze] wrote {str(out_path).rsplit('.', 1)[0] + '.json'}")
    print("".join(L))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cd", choices=DATASET_KEYS)
    ap.add_argument("--per_sample", required=True)
    ap.add_argument("--diagnosis", default=None)
    ap.add_argument("--label", default="model")
    ap.add_argument("--out", required=True)
    ap.add_argument("--B", type=int, default=10000)
    args = ap.parse_args()
    run(args.dataset, args.per_sample, args.diagnosis, args.label, args.out, args.B)
