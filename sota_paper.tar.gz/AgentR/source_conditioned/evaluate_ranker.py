#!/usr/bin/env python
"""Source-conditioned ranker evaluator (real-retrieved).

Reuses the repo's config/client/dataset/parser, builds prompts via the SHARED
source_prompt module (train==infer), replicates the exact eval-time md5 shuffle
+ letter assignment of the original MAS recall eval, generates with vLLM batch, and
writes:
  <out>.per_sample.jsonl  — canonical contract {user_id, sasrec_rank, mas_rank,
                            delta, parse_success} consumed by bootstrap/mcnemar
                            and analyze_preserve_rescue.py
  <out>.full.jsonl        — full model ranking for ALL users (fixes the
                            diagnosis-only-rescuable coverage gap)
  <out>.json              — aggregate summary (MAS + SASRec baseline)

No evidence agent. No numeric scores. Source order is context only. Ablation
toggles mirror source_prompt (no source order / minimal user state / no relations).

Usage:
  python source_conditioned/evaluate_ranker.py --dataset cd \
    --config outputs/cd/configs/recall_eval.yaml \
    --model outputs/cd/sc/model/merged_model \
    --out outputs/cd/sc/eval/sft
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import random as _r
import sys
from pathlib import Path

_ROOT = str(Path(__file__).resolve().parents[1])
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

sys.path.insert(0, str(Path(__file__).resolve().parent))  # for common/source_prompt

from reflective_mas_rec.config import load_config
from reflective_mas_rec.data.dataset import Dataset
from reflective_mas_rec.data.item_card import build_item_compact_card
from reflective_mas_rec.llm.client import build_llm_client
from reflective_mas_rec.llm.parsers import parse_rank_output

from common import DATASET_KEYS, metrics_from_rank, ndcg_at_k, norm_brand
from source_prompt import build_source_conditioned_prompt


def letter_ids(n):
    return [chr(ord("A") + i) for i in range(n)]


def build_contexts(rows, dataset, max_chars, items_meta):
    """Candidate construction: md5(sample_id) shuffle -> letters (same as the MAS recall eval)."""
    ctxs = []
    for d in rows:
        note_ids = d["candidate_note_ids"]
        nid_to_rank = {nid: i + 1 for i, nid in enumerate(note_ids)}
        shuffled = list(note_ids)
        seed = int(hashlib.md5(str(d["sample_id"]).encode("utf-8")).hexdigest()[:8], 16)
        _r.Random(seed).shuffle(shuffled)
        cids = letter_ids(len(shuffled))
        note_to_cid = {n: cids[i] for i, n in enumerate(shuffled)}
        candidates = []
        for i, nid in enumerate(shuffled):
            info = build_item_compact_card(dataset.get_item(nid), max_chars)
            candidates.append({
                "candidate_id": cids[i], "note_id": nid,
                "item_compact_info": info, "sasrec_rank": nid_to_rank[nid],
            })
        hist = d.get("history_items", [])
        hist_titles = [items_meta.get(h, {}).get("title", "") for h in hist if h in items_meta]
        hist_brands = {norm_brand(items_meta.get(h, {}).get("brand", "")) for h in hist}
        hist_cats = {items_meta.get(h, {}).get("category_l2", "") for h in hist}
        ctxs.append({
            "sample_id": d["sample_id"], "user_id": d["user_id"],
            "user_memory": d["user_memory"], "candidates": candidates,
            "positive_cid": note_to_cid[d["positive_item"]],
            "sasrec_rank": d["sasrec_positive_rank"],
            "hist_titles": hist_titles, "hist_brands": hist_brands, "hist_cats": hist_cats,
        })
    return ctxs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cd", choices=DATASET_KEYS)
    ap.add_argument("--config", required=True)
    ap.add_argument("--model", default=None, help="override model_path in config")
    ap.add_argument("--input", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--max_tokens", type=int, default=512)
    # ablation toggles
    ap.add_argument("--no_source_order", action="store_true")
    ap.add_argument("--minimal_user_state", action="store_true")
    ap.add_argument("--no_relations", action="store_true")
    ap.add_argument("--drop_memory", action="store_true",
                    help="V2: remove generated user memory, keep raw recent history")
    ap.add_argument("--minimal_item_meta", action="store_true",
                    help="V4/V5: strip rich item metadata (keep id + short title)")
    ap.add_argument("--minimal_no_title", action="store_true",
                    help="V4: with --minimal_item_meta, drop titles too (id only)")
    ap.add_argument("--top1_reorder", action="store_true",
                    help="V7: final ranking = [model_top1] + remaining candidates in "
                         "source order (top-1-only supervision inference)")
    ap.add_argument("--shuffle_display", default="md5",
                    choices=["md5", "source", "none"],
                    help="candidate display order (Ablation 6 position bias)")
    ap.add_argument("--rq3_dir", default=None,
                    help="if set, also write RQ3 contract: metrics.json, "
                         "predictions.per_sample.jsonl, prompt_examples.jsonl")
    ap.add_argument("--variant", default=None, help="variant name for RQ3 records")
    ap.add_argument("--source_name", default="SASRec",
                    help="recall backbone named in the prompt (source-swap experiments)")
    args = ap.parse_args()

    from common import dataset as _ds
    dsp = _ds(args.dataset)
    inp_path = args.input or str(dsp.recall_input)

    cfg = load_config(args.config)
    if args.model:
        cfg.llm.model_path = args.model
        # point all agent models at the same override if present
        for attr in ("rank_model_path", "evidence_model_path"):
            if hasattr(cfg, attr):
                setattr(cfg, attr, args.model)
    dataset = Dataset.load(cfg)
    client = build_llm_client(cfg.llm)
    max_chars = cfg.item.max_content_chars

    from common import load_items
    items_meta = load_items(dsp.items_parquet)

    rows = []
    with open(inp_path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if args.limit and i >= args.limit:
                break
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    print(f"[eval] {len(rows)} users | model={cfg.llm.model_path}", flush=True)

    ctxs = build_contexts(rows, dataset, max_chars, items_meta)

    # build prompts (shared module) — possibly with display reorder for ablation 6
    systems, prompts = [], []
    for ctx in ctxs:
        cands = ctx["candidates"]
        if args.shuffle_display == "source":
            cands = sorted(cands, key=lambda c: c["sasrec_rank"])
        elif args.shuffle_display == "none":
            cands = sorted(cands, key=lambda c: c["candidate_id"])
        system, prompt = build_source_conditioned_prompt(
            sample_id=ctx["sample_id"], user_memory=ctx["user_memory"],
            candidates=cands,
            history_titles=ctx["hist_titles"], history_brands=ctx["hist_brands"],
            history_cats=ctx["hist_cats"],
            include_relations=not args.no_relations,
            include_source_order=not args.no_source_order,
            minimal_user_state=args.minimal_user_state,
            drop_memory=args.drop_memory,
            minimal_item_meta=args.minimal_item_meta,
            minimal_include_title=not args.minimal_no_title,
            source_name=args.source_name,
        )
        systems.append(system)
        prompts.append(prompt)

    # single system prompt (all identical); generate in batch
    texts = client.generate_batch(
        prompts, system_prompt=systems[0], temperature=0.0, max_tokens=args.max_tokens,
    )

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    ps_path = args.out + ".per_sample.jsonl"
    full_path = args.out + ".full.jsonl"
    mas_agg = {k: 0.0 for k in ["hr@1", "hr@3", "hr@5", "ndcg@5", "mrr", "positive_rank"]}
    sas_agg = dict(mas_agg)
    parse_fail = 0
    n = len(ctxs)
    rq3_records = []  # RQ3 contract per-sample
    with open(ps_path, "w", encoding="utf-8") as pf, open(full_path, "w", encoding="utf-8") as ff:
        for ctx, text in zip(ctxs, texts):
            cand_ids = [c["candidate_id"] for c in ctx["candidates"]]
            src_order = [c["candidate_id"] for c in
                         sorted(ctx["candidates"], key=lambda c: c["sasrec_rank"])]
            parsed = parse_rank_output(text, cand_ids, fallback_ranking=src_order)
            # NOTE fallback = SOURCE order here (a parse failure => trust the prior),
            # a deliberate, documented choice (the live eval falls back to shuffled
            # display order; for source-conditioned reasoning source order is the
            # honest prior). parse_fail is reported so this is transparent.
            ranking = parsed["ranking"]
            is_parse_fail = not parsed["parse_success"]
            if is_parse_fail:
                parse_fail += 1
            # V7: reconstruct as [predicted_top1] + remaining in SOURCE order.
            # A parse failure (or top1 not in candidates) -> fall back to source order.
            if args.top1_reorder:
                if is_parse_fail or not ranking:
                    ranking = list(src_order)
                else:
                    top1 = ranking[0]
                    if top1 not in cand_ids:
                        ranking = list(src_order)
                    else:
                        ranking = [top1] + [c for c in src_order if c != top1]
            pos = ctx["positive_cid"]
            mas_rank = (ranking.index(pos) + 1) if pos in ranking else len(ranking) + 1
            sr = ctx["sasrec_rank"]
            m = metrics_from_rank(mas_rank)
            for k in mas_agg:
                mas_agg[k] += m[k]
            sm = metrics_from_rank(sr)
            for k in sas_agg:
                sas_agg[k] += sm[k]
            pf.write(json.dumps({
                "user_id": ctx["user_id"], "sasrec_rank": sr, "mas_rank": mas_rank,
                "delta": sr - mas_rank, "parse_success": parsed["parse_success"],
            }, ensure_ascii=False) + "\n")
            ff.write(json.dumps({
                "user_id": ctx["user_id"], "sasrec_rank": sr, "mas_rank": mas_rank,
                "positive_cid": pos, "source_order": src_order,
                "model_ranking": ranking, "parse_success": parsed["parse_success"],
                "top_reason": parsed.get("top_reason", ""),
            }, ensure_ascii=False) + "\n")
            if args.rq3_dir:
                cand_notes = [c["note_id"] for c in ctx["candidates"]]
                c2n = {c["candidate_id"]: c["note_id"] for c in ctx["candidates"]}
                pos_note = c2n.get(pos, pos)
                rq3_records.append({
                    "sample_id": ctx["sample_id"], "user_id": ctx["user_id"],
                    "positive_item_id": pos_note,
                    "candidate_item_ids": cand_notes,
                    "source_order": [c2n[c] for c in src_order if c in c2n],
                    "ranked_item_ids": [c2n[c] for c in ranking if c in c2n],
                    "positive_rank": mas_rank,
                    "r@1": int(mas_rank <= 1), "r@3": int(mas_rank <= 3),
                    "r@5": int(mas_rank <= 5),
                    "ndcg@1": m["hr@1"], "ndcg@3": ndcg_at_k(mas_rank, 3),
                    "ndcg@5": m["ndcg@5"],
                    "parse_fail": is_parse_fail,
                })

    summary = {
        "n_users": n, "dataset": args.dataset,
        "candidate_source": f"{args.source_name} real top-10 recall (recall-hit users)",
        "model": cfg.llm.model_path,
        "ablation": {"no_source_order": args.no_source_order,
                     "minimal_user_state": args.minimal_user_state,
                     "no_relations": args.no_relations,
                     "shuffle_display": args.shuffle_display},
        "MAS_rerank": {k: mas_agg[k] / n for k in mas_agg},
        "SASRec_baseline": {k: sas_agg[k] / n for k in sas_agg},
        "parse_fail": parse_fail,
    }
    Path(args.out + ".json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(f"[eval] wrote {ps_path}\n[eval] wrote {full_path}\n[eval] wrote {args.out}.json")

    # ------------------------------------------------------------------
    # RQ3 contract output
    # ------------------------------------------------------------------
    if args.rq3_dir:
        rq3 = Path(args.rq3_dir)
        rq3.mkdir(parents=True, exist_ok=True)
        # aggregate metrics.json in RQ3 metric names
        def agg(key):
            return sum(r[key] for r in rq3_records) / len(rq3_records)
        rq3_metrics = {
            "variant": args.variant or Path(args.rq3_dir).name,
            "dataset": args.dataset, "n_users": len(rq3_records),
            "r@1": agg("r@1"), "r@3": agg("r@3"), "r@5": agg("r@5"),
            "ndcg@1": agg("ndcg@1"), "ndcg@3": agg("ndcg@3"), "ndcg@5": agg("ndcg@5"),
            "mrr": mas_agg["mrr"] / n,
            "positive_rank": mas_agg["positive_rank"] / n,
            "parse_fail": parse_fail,
            "model": cfg.llm.model_path,
            "ablation": summary["ablation"],
        }
        (rq3 / "metrics.json").write_text(json.dumps(rq3_metrics, indent=2), encoding="utf-8")
        with open(rq3 / "predictions.per_sample.jsonl", "w", encoding="utf-8") as f:
            for r in rq3_records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        with open(rq3 / "prompt_examples.jsonl", "w", encoding="utf-8") as f:
            for ctx, prompt, system in list(zip(ctxs, prompts, systems))[:50]:
                f.write(json.dumps({"sample_id": ctx["sample_id"],
                                    "system": system, "input": prompt},
                                   ensure_ascii=False) + "\n")
        print(f"[eval][rq3] wrote {rq3}/metrics.json + predictions + prompt_examples")


if __name__ == "__main__":
    main()
