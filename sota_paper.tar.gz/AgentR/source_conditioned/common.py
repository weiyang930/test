"""Shared helpers for AgentR real-retrieved source-conditioned experiments.

Everything here is deterministic and read-only w.r.t. the source data. The
single most important invariant we reproduce is the candidate letter mapping
used by the original MAS real-recall eval (md5(sample_id) shuffle -> letters A..J) so
that any offline analysis lands in the *same* letter space as the eval outputs.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random as _r
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

PROJ = Path(__file__).resolve().parents[1]  # repo root
if str(PROJ) not in sys.path:
    sys.path.insert(0, str(PROJ))
import agentr_paths  # noqa: E402

# ---------------------------------------------------------------------------
# Dataset registry: resolved through agentr_paths (single source of truth).
# ---------------------------------------------------------------------------
@dataclass
class DatasetPaths:
    key: str                 # short name used in output dirs
    recall_input: Path       # outputs/<ds>/recall/eval_input/recall_eval_input.jsonl (hit-user test set)
    sasrec_recall: Path      # outputs/<ds>/sasrec/top50_recall.jsonl (source order, no scores)
    items_parquet: Path      # <data_dir>/items.parquet
    train_traces: Optional[Path]   # outputs/<ds>/recall/traces/train_traces.jsonl


DATASET_KEYS = list(agentr_paths.DATASETS)


def dataset(key: str) -> DatasetPaths:
    p = agentr_paths.paths(key)
    return DatasetPaths(
        key=key,
        recall_input=PROJ / p["RECALL_INPUT"],
        sasrec_recall=PROJ / p["TOP50"],
        items_parquet=PROJ / p["ITEMS_PARQUET"],
        train_traces=PROJ / p["RECALL_TRAIN_TRACES"],
    )


# ---------------------------------------------------------------------------
# Candidate letter mapping -- MUST match evaluate_ranker.build_contexts exactly.
# ---------------------------------------------------------------------------
def letter_ids(n: int) -> List[str]:
    """A, B, ... (matches reflective_mas_rec eval; only ever needs <=26)."""
    return [chr(ord("A") + i) for i in range(n)]


def candidate_letter_mapping(sample_id: str, note_ids: List[str]):
    """Reproduce the deterministic md5 shuffle + letter assignment used at eval.

    Returns (note_to_cid, cid_to_note, nid_to_source_rank) where source rank is
    the 1-indexed position in the ORIGINAL (pre-shuffle) SASRec recall order.
    """
    nid_to_rank = {nid: i + 1 for i, nid in enumerate(note_ids)}
    shuffled = list(note_ids)
    seed = int(hashlib.md5(str(sample_id).encode("utf-8")).hexdigest()[:8], 16)
    _r.Random(seed).shuffle(shuffled)
    cids = letter_ids(len(shuffled))
    note_to_cid = {n: cids[i] for i, n in enumerate(shuffled)}
    cid_to_note = {cids[i]: n for i, n in enumerate(shuffled)}
    return note_to_cid, cid_to_note, nid_to_rank


def source_letter_order(sample_id: str, note_ids: List[str]) -> List[str]:
    """The SASRec source order expressed in the eval's letter space (best-first)."""
    note_to_cid, _, _ = candidate_letter_mapping(sample_id, note_ids)
    return [note_to_cid[n] for n in note_ids]


# ---------------------------------------------------------------------------
# Metrics -- mirror reflective_mas_rec/evaluation/metrics.py (single positive).
# All are a function of the positive's 1-indexed rank.
# ---------------------------------------------------------------------------
def hr_at_k(rank: int, k: int) -> float:
    return 1.0 if (rank is not None and rank <= k) else 0.0


def ndcg_at_k(rank: int, k: int) -> float:
    if rank is None or rank > k:
        return 0.0
    return 1.0 / math.log2(rank + 1)


def mrr(rank: int) -> float:
    return 1.0 / rank if rank else 0.0


def metrics_from_rank(rank: int) -> Dict[str, float]:
    return {
        "hr@1": hr_at_k(rank, 1),
        "hr@3": hr_at_k(rank, 3),
        "hr@5": hr_at_k(rank, 5),
        "ndcg@5": ndcg_at_k(rank, 5),
        "mrr": mrr(rank),
        "positive_rank": float(rank),
    }


def kendall_tau_distance(order_a: List[str], order_b: List[str]) -> int:
    """Number of pairwise inversions between two permutations of the same set.

    Bubble-sort inversion count; O(n^2) is fine for n<=10 candidates.
    """
    pos_b = {x: i for i, x in enumerate(order_b)}
    seq = [pos_b[x] for x in order_a if x in pos_b]
    inv = 0
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]:
                inv += 1
    return inv


# ---------------------------------------------------------------------------
# IO helpers
# ---------------------------------------------------------------------------
def read_jsonl(path, limit: Optional[int] = None):
    rows = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if limit is not None and i >= limit:
                break
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def load_items(items_parquet: Path) -> Dict[str, dict]:
    """note_id -> {title, brand, category_l1, category_l2, price, content}."""
    import pandas as pd

    df = pd.read_parquet(items_parquet)
    out = {}
    for rec in df.to_dict(orient="records"):
        pa = rec.get("parsed_attr") or {}
        if isinstance(pa, str):
            try:
                pa = json.loads(pa)
            except Exception:
                pa = {}
        out[rec["note_id"]] = {
            "title": rec.get("title") or "",
            "brand": (pa.get("brand_name") or "").strip(),
            "category_l1": pa.get("category_l1") or "",
            "category_l2": pa.get("category_l2") or "",
            "price": pa.get("price") or "",
            "content": (rec.get("content") or "")[:400],
            "label": rec.get("label") or "",
        }
    return out


def norm_brand(b: str) -> str:
    """Amazon brand_name often carries a ' Format: ...' suffix; strip for grouping."""
    if not b:
        return ""
    b = b.split("Format:")[0]
    return " ".join(b.lower().split())
