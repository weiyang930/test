#!/usr/bin/env python
"""Build source-conditioned preserve-correct SFT data (Phase III + Exp 1/2).

Reads real-retrieved (line-B) training traces and emits {instruction, input,
output, system, meta} records (the format train_rank_sft.py consumes), using
the SHARED source_prompt.build_source_conditioned_prompt so train==infer.

Deterministic preserve-correct TARGET:
  - source_top1 == positive  -> target ranking = source order          (PRESERVE)
  - source_top1 != positive  -> target = [positive] + rest source order (CORRECT)

--rationale:
  none       -> output = ranking only (Exp 1 / Ablation 4)
  templated  -> output includes a preserve/correct top_reason + decision_rules
                explaining WHY (Exp 2 source-conditioned trace tuning)

--subset:
  all        -> all source-hit traces
  preserve   -> only source-correct traces  (Ablation 5)
  correct    -> only source-wrong traces     (Ablation 5)

No evidence agent. No numeric scores. Source order is context only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random as _random
from pathlib import Path

from common import DATASET_KEYS, PROJ, dataset, load_items, norm_brand
from source_prompt import (
    INSTRUCTION_SC,
    build_source_conditioned_prompt,
)


def _memory(t, memory_field):
    """User memory placed in the prompt.

    user_memory_before (default, = the published runs) can hold a LATER window's memory
    of the same user when several windows share a rollout batch (it is read after the
    batch wrote its memories) -> mild future leak on train prompts.  user_memory_after
    is the memory the sample actually used (leak-free).  See README "Known caveats".
    """
    other = "user_memory_after" if memory_field == "user_memory_before" else "user_memory_before"
    return t.get(memory_field) or t.get(other) or {}


def source_order_letters(ric):
    return [c["candidate_id"] for c in sorted(ric, key=lambda c: c["sasrec_rank"])]


def build_target_ranking(ric, positive_cid):
    """Preserve-correct deterministic target."""
    order = source_order_letters(ric)
    src_top1 = order[0]
    if src_top1 == positive_cid:
        return order, "preserve"
    corrected = [positive_cid] + [c for c in order if c != positive_cid]
    return corrected, "correct"


def build_target_positive_first_random(ric, positive_cid, sample_id, seed):
    """V8: positive at #1, remaining 9 in a FIXED deterministic random order.

    The rest-order is a per-sample deterministic shuffle seeded by
    (seed, sample_id) so it is reproducible and independent of source order.
    'kind' still reports preserve/correct (whether source_top1 was already the
    positive) for diagnostics parity with the preserve-correct target.
    """
    order = source_order_letters(ric)
    src_top1 = order[0]
    kind = "preserve" if src_top1 == positive_cid else "correct"
    rest = [c for c in order if c != positive_cid]
    h = hashlib.md5(f"{seed}::{sample_id}".encode("utf-8")).hexdigest()[:8]
    _random.Random(int(h, 16)).shuffle(rest)
    return [positive_cid] + rest, kind


def make_rationale(kind, positive_cid, src_top1, blockers):
    if kind == "preserve":
        return {
            "top_reason": (f"Source rank-1 candidate {src_top1} is already the best "
                           "next-item prediction; user evidence does not clearly favor "
                           "another candidate, so preserve the collaborative source order."),
            "decision_rules": [
                f"source_top1={src_top1} has the strongest collaborative prior and no "
                "candidate shows clearly stronger user-specific evidence",
                "preserve source order when evidence is weak or ambiguous",
                "avoid unnecessary reordering that could displace a correct top-1",
            ],
        }
    # correct
    return {
        "top_reason": (f"Candidate {positive_cid} has user/sequence-specific support that "
                       f"outweighs the source-top blockers ({', '.join(blockers)}); promote "
                       "it to rank 1 while keeping the remaining collaborative order intact."),
        "decision_rules": [
            f"promote {positive_cid}: its brand/category/attributes fit the user's next-"
            "interaction intent better than the source rank-1 item",
            f"source-top blockers {blockers} are plausible collaborative priors but "
            "misleading here",
            "keep all other candidates in source order to avoid damaging mid-list ranking",
        ],
    }


def run(ds_key, split_limit, rationale, subset, out_path, examples_path,
        target="preserve_correct", seed=42, source_name="SASRec",
        train_traces_override=None, memory_field="user_memory_before"):
    ds = dataset(ds_key)
    from pathlib import Path as _P
    train_traces = _P(train_traces_override) if train_traces_override else ds.train_traces
    if not train_traces or not _P(train_traces).exists():
        raise SystemExit(f"train traces not found: {train_traces}")
    items = load_items(ds.items_parquet)

    n_in = n_out = n_preserve = n_correct = n_skip = 0
    examples = []
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(train_traces, encoding="utf-8") as f, \
         open(out_path, "w", encoding="utf-8") as w:
        for line in f:
            line = line.strip()
            if not line:
                continue
            n_in += 1
            if split_limit and n_out >= split_limit:
                break
            t = json.loads(line)
            ric = t.get("rank_input_candidates") or []
            pos = t.get("positive_candidate_id")
            if len(ric) < 2 or pos is None:
                n_skip += 1
                continue
            if not all(c.get("sasrec_rank") is not None for c in ric):
                n_skip += 1
                continue
            cid_set = {c["candidate_id"] for c in ric}
            if pos not in cid_set:
                n_skip += 1
                continue

            if target == "positive_first_random":
                target_ranking, kind = build_target_positive_first_random(
                    ric, pos, t["sample_id"], seed)
            else:
                target_ranking, kind = build_target_ranking(ric, pos)
            if subset == "preserve" and kind != "preserve":
                continue
            if subset == "correct" and kind != "correct":
                continue

            # history titles/brands/cats for source-conditioned prompt
            hist = t.get("history_items") or []
            hist_titles = [items.get(h, {}).get("title", "") for h in hist if h in items]
            hist_brands = {norm_brand(items.get(h, {}).get("brand", "")) for h in hist}
            hist_cats = {items.get(h, {}).get("category_l2", "") for h in hist}

            system, user_prompt = build_source_conditioned_prompt(
                sample_id=t["sample_id"],
                user_memory=_memory(t, memory_field),
                candidates=ric,
                history_titles=hist_titles,
                history_brands=hist_brands,
                history_cats=hist_cats,
                source_name=source_name,
            )

            order = source_order_letters(ric)
            out_obj = {"sample_id": t["sample_id"], "ranking": target_ranking}
            if rationale == "templated":
                blockers = order[:3]
                out_obj.update(make_rationale(kind, pos, order[0], blockers))
            rec = {
                "instruction": INSTRUCTION_SC,
                "input": user_prompt,
                "output": json.dumps(out_obj, ensure_ascii=False),
                "system": system,
                "meta": {
                    "sample_id": t["sample_id"], "user_id": t.get("user_id"),
                    "split": t.get("split"), "positive_candidate_id": pos,
                    "kind": kind,
                },
            }
            w.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_out += 1
            if kind == "preserve":
                n_preserve += 1
            else:
                n_correct += 1
            if len(examples) < 5:
                examples.append(rec)

    if examples_path:
        Path(examples_path).parent.mkdir(parents=True, exist_ok=True)
        with open(examples_path, "w", encoding="utf-8") as ef:
            for e in examples:
                ef.write(json.dumps(e, ensure_ascii=False) + "\n")

    print(f"[build_sft] in={n_in} out={n_out} preserve={n_preserve} correct={n_correct} "
          f"skip={n_skip}")
    print(f"[build_sft] rationale={rationale} subset={subset}")
    print(f"[build_sft] wrote {out_path}")
    if examples_path:
        print(f"[build_sft] examples -> {examples_path}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cd", choices=DATASET_KEYS)
    ap.add_argument("--limit", type=int, default=0, help="cap output records (0=all)")
    ap.add_argument("--rationale", default="none", choices=["none", "templated"])
    ap.add_argument("--subset", default="all", choices=["all", "preserve", "correct"])
    ap.add_argument("--target", default="preserve_correct",
                    choices=["preserve_correct", "positive_first_random"],
                    help="V8 uses positive_first_random (pos #1, rest fixed-random)")
    ap.add_argument("--seed", type=int, default=42, help="seed for positive_first_random rest order")
    ap.add_argument("--out", required=True)
    ap.add_argument("--examples", default=None)
    ap.add_argument("--source_name", default="SASRec",
                    help="recall backbone named in the prompt (source-swap experiments)")
    ap.add_argument("--train_traces", default=None,
                    help="override train_traces path (source-swap: source-specific traces)")
    ap.add_argument("--memory_field", default="user_memory_before",
                    choices=["user_memory_before", "user_memory_after"],
                    help="trace field used as prompt memory (default reproduces the paper runs)")
    args = ap.parse_args()
    run(args.dataset, args.limit, args.rationale, args.subset, args.out, args.examples,
        target=args.target, seed=args.seed, source_name=args.source_name,
        train_traces_override=args.train_traces, memory_field=args.memory_field)
