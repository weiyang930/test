"""Source-conditioned listwise ranking prompt (Phase III).

Single source of truth for the prompt, imported by BOTH the SFT data builder
and the evaluator, so train==infer by construction (fixes the [user_exploration]
mismatch found in Check 4).

Four blocks:
  A. User State           — long/short-term memory + recent history titles
  B. Retrieval Context    — SASRec source order as RANKS (no numeric scores)
  C. Candidate States     — id/title/brand/category/price/snippet per candidate
  D. Candidate Relation   — DETERMINISTIC: same-category / same-brand groups,
                            near-duplicate titles, safe-continuation vs
                            exploratory-jump flag, source-top blockers

Output is a FULL ranked permutation (not an edit action). No evidence agent.
No numeric SASRec score anywhere — this is source-conditioned reasoning, not
score fusion. Source order is context; the model still decides every position.
"""
from __future__ import annotations

import json
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional

def rank_system_sc(source_name: str = "SASRec") -> str:
    """System prompt for the source-conditioned ranker.

    source_name names the recall backbone that produced+ordered the candidates
    (default 'SASRec' -> byte-identical to the original prompt so all existing
    SASRec experiments are unchanged). For source-swap experiments this is the
    real backbone (VQ-Rec / TASTE / GRU4Rec) so the model is not told the wrong
    source. Only the NAME varies; the reasoning instructions are identical.
    """
    return (
        "You are a source-conditioned listwise recommendation ranker. A collaborative "
        f"sequential recommender ({source_name}) already retrieved and ordered these candidates; "
        "its order is a STRONG collaborative prior but is correct at rank-1 only ~27% of "
        "the time. Your job: output a full ranked list predicting the user's NEXT "
        "interaction. Preserve the source order when user-specific evidence is weak or "
        "ambiguous; override it only when candidate/user evidence clearly supports a "
        "different item. The next item is often an exploratory jump (new brand/category) "
        "— do not down-rank a candidate merely because it is novel. Give short decision "
        "rules, no long chain-of-thought. Output valid JSON only."
    )


# Back-compat module constant (default source). Existing importers keep working.
RANK_SYSTEM_SC = rank_system_sc()

INSTRUCTION_SC = (
    "Produce the final ranking over ALL candidates, predicting the user's next "
    "interaction. Output valid JSON only."
)


def _dumps(o) -> str:
    return json.dumps(o, ensure_ascii=False, indent=2)


def _norm_brand(b: str) -> str:
    if not b:
        return ""
    b = b.split("Format:")[0]
    return " ".join(b.lower().split())


def _title_key(t: str) -> str:
    return " ".join((t or "").lower().split())


def _user_state_block(user_memory: Dict[str, Any], history_titles: List[str],
                      drop_memory: bool = False) -> str:
    """Block A. Compact user state; keep only signal-bearing memory fields.

    drop_memory=True (Ablation V2 'w/o user memory'): empties the *generated*
    long/short-term memory + ranking_guidance but KEEPS the raw recent-history
    titles so the prompt stays well-formed. Isolates the contribution of the
    Memory / preference-state construction while leaving raw history intact.
    """
    if drop_memory:
        txt = "[user_state] (user memory / preference-state removed for ablation)\n{}\n"
        if history_titles:
            recent = history_titles[-12:]
            txt += (f"\n[recent_history] (most recent last, {len(recent)} items)\n"
                    + _dumps(recent) + "\n")
        txt += ("\nPredict the user's NEXT interaction — not the item most globally "
                "similar to their history. Users frequently explore adjacent styles.\n")
        return txt
    ltm = user_memory.get("long_term_memory", {}) or {}
    stm = user_memory.get("short_term_memory", {}) or {}
    guide = user_memory.get("ranking_guidance", {}) or user_memory.get("ranking_guidance")
    state = {}
    if ltm.get("stable_preferences"):
        state["stable_preferences"] = [
            p.get("content") for p in ltm["stable_preferences"][:4] if isinstance(p, dict)
        ]
    if ltm.get("profile_hypotheses"):
        state["profile_hypotheses"] = [
            p.get("content") for p in ltm["profile_hypotheses"][:2] if isinstance(p, dict)
        ]
    if stm:
        # short_term_memory may be a dict or list; stringify compactly
        state["short_term_intent"] = stm
    if guide:
        state["ranking_guidance"] = guide
    txt = f"[user_state]\n{_dumps(state)[:2200]}\n"
    if history_titles:
        recent = history_titles[-12:]
        txt += (f"\n[recent_history] (most recent last, {len(recent)} items)\n"
                + _dumps(recent) + "\n")
    txt += ("\nPredict the user's NEXT interaction — not the item most globally "
            "similar to their history. Users frequently explore adjacent styles.\n")
    return txt


def _raw_user_state_block(raw_user: Dict[str, Any]) -> str:
    """Block A for the SINGLE-AGENT variant (AgentCR P0-2 V1).

    Replaces the Memory-Agent output with the SAME raw inputs the Memory Agent
    consumes (structured profile fields, dataset persona text, full history item
    cards older->newer, same truncation as build_memory_prompt). No structured
    memory, no reflection, no other agent's intermediate output.
    """
    from reflective_mas_rec.llm.prompt_templates import _history_block

    profile = raw_user.get("profile_fields") or {}
    persona = (raw_user.get("llm_output") or "").strip()[:1800]
    cards = raw_user.get("history_cards") or []
    txt = "[user_profile_fields]\n" + (_dumps(profile) if profile else "(none)") + "\n"
    txt += "\n[user_persona]\n" + (persona or "(none)") + "\n"
    txt += ("\n[user_history] (older -> newer)\n" + _history_block(cards) + "\n")
    txt += ("\nPredict the user's NEXT interaction — not the item most globally "
            "similar to their history. Users frequently explore adjacent styles.\n")
    return txt


def _retrieval_context_block(candidates: List[Dict[str, Any]],
                             source_name: str = "SASRec") -> str:
    """Block B. Source order as ranks (NO numeric scores)."""
    ranked = sorted(
        [c for c in candidates if c.get("sasrec_rank") is not None],
        key=lambda c: c["sasrec_rank"],
    )
    if not ranked:
        return ""
    lines = [
        "[retrieval_context]",
        "The candidate list below was retrieved and ordered by a collaborative "
        f"sequential recommender ({source_name}). Source order (rank 1 = strongest "
        "collaborative prior). This is context, NOT a score and NOT ground truth:",
    ]
    for c in ranked:
        lines.append(f"  {c['sasrec_rank']}. {c['candidate_id']}")
    lines.append(
        "Treat source order as a strong prior: keep it when your evidence is weak; "
        "reorder only where user/candidate evidence clearly justifies it."
    )
    return "\n".join(lines) + "\n"


def _candidate_states_block(candidates: List[Dict[str, Any]],
                            minimal_item_meta: bool = False,
                            include_title: bool = True) -> str:
    """Block C. Per-candidate metadata (no evidence card, no score).

    minimal_item_meta=True (Ablations V4 'source order only' / V5 'w/o item
    metadata'): strip rich semantics (brand/category/price/attributes). Keep
    only candidate_id (+ short title when include_title). V5 keeps title; V4
    keeps only id + short title.
    """
    out = []
    for c in candidates:
        info = c.get("item_compact_info", {}) or {}
        if minimal_item_meta:
            rec = {"candidate_id": c.get("candidate_id")}
            if include_title:
                rec["title"] = (info.get("title") or info.get("product_name") or "")[:80]
            out.append(rec)
        else:
            out.append({
                "candidate_id": c.get("candidate_id"),
                "title": info.get("title") or info.get("product_name") or "",
                "brand": info.get("brand_name") or "",
                "category": info.get("category_l2") or info.get("category_l1") or "",
                "price": info.get("price") or "",
                "attributes": (info.get("content_snippet") or "")[:200],
            })
    return "[candidate_states]\n" + _dumps(out) + "\n"


def _relation_context_block(
    candidates: List[Dict[str, Any]],
    history_brands: set,
    history_cats: set,
    expose_source: bool = True,
) -> str:
    """Block D. DETERMINISTIC relational signals among candidates.

    expose_source=False (Ablation V3 'w/o source order'): omit source_top_blockers
    so no SASRec-rank information leaks through the relations block.
    """
    cid = {c["candidate_id"]: c for c in candidates}
    info_of = {c["candidate_id"]: (c.get("item_compact_info", {}) or {}) for c in candidates}

    # same-category groups
    cat_groups: Dict[str, List[str]] = {}
    for c in candidates:
        cat = (info_of[c["candidate_id"]].get("category_l2")
               or info_of[c["candidate_id"]].get("category_l1") or "")
        cat_groups.setdefault(cat, []).append(c["candidate_id"])
    cat_groups = {k: v for k, v in cat_groups.items() if len(v) > 1 and k}

    # same-brand groups
    brand_groups: Dict[str, List[str]] = {}
    for c in candidates:
        b = _norm_brand(info_of[c["candidate_id"]].get("brand_name", ""))
        brand_groups.setdefault(b, []).append(c["candidate_id"])
    brand_groups = {k: v for k, v in brand_groups.items() if len(v) > 1 and k}

    # near-duplicate titles
    ids = list(cid)
    near_dups = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            ta = _title_key(info_of[ids[i]].get("title") or info_of[ids[i]].get("product_name") or "")
            tb = _title_key(info_of[ids[j]].get("title") or info_of[ids[j]].get("product_name") or "")
            if ta and tb and SequenceMatcher(None, ta, tb).ratio() >= 0.85:
                near_dups.append([ids[i], ids[j]])

    # safe-continuation vs exploratory-jump relative to history
    continuation = {}
    for c in candidates:
        b = _norm_brand(info_of[c["candidate_id"]].get("brand_name", ""))
        cat = (info_of[c["candidate_id"]].get("category_l2")
               or info_of[c["candidate_id"]].get("category_l1") or "")
        if b and b in history_brands:
            continuation[c["candidate_id"]] = "safe_brand_continuation"
        elif cat and cat in history_cats:
            continuation[c["candidate_id"]] = "safe_category_continuation"
        else:
            continuation[c["candidate_id"]] = "exploratory_jump"

    # source-top blockers: candidates ranked ABOVE the median source rank
    # (i.e. the strong-prior items the model must consciously decide to keep/override)
    ranked = sorted([c for c in candidates if c.get("sasrec_rank") is not None],
                    key=lambda c: c["sasrec_rank"])
    blockers = [c["candidate_id"] for c in ranked[:3]]

    rel = {
        "same_category_groups": list(cat_groups.values()),
        "same_brand_groups": list(brand_groups.values()),
        "near_duplicate_titles": near_dups,
        "continuation_type": continuation,
    }
    if expose_source:
        rel["source_top_blockers"] = blockers
    txt = ("[candidate_relations] (deterministic, computed from metadata + history)\n"
           + _dumps(rel) + "\n")
    txt += ("continuation_type flags whether each candidate continues a known "
            "brand/category or is an exploratory jump.")
    if expose_source:
        txt += (" source_top_blockers are the strongest collaborative priors — keep "
                "one at the top unless clear evidence promotes another candidate.")
    txt += "\n"
    return txt


def build_source_conditioned_prompt(
    sample_id: str,
    user_memory: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    history_titles: Optional[List[str]] = None,
    history_brands: Optional[set] = None,
    history_cats: Optional[set] = None,
    include_relations: bool = True,
    include_source_order: bool = True,
    minimal_user_state: bool = False,
    drop_memory: bool = False,
    minimal_item_meta: bool = False,
    minimal_include_title: bool = True,
    source_name: str = "SASRec",
    raw_user: Optional[Dict[str, Any]] = None,
):
    """Return (system, user_prompt). Deterministic; no evidence, no scores.

    Ablation toggles:
      include_source_order=False  -> V3 'w/o source order' (remove Block B + all
                                     source ranks incl. relations' source_top_blockers)
      minimal_user_state=True     -> legacy source-only (strip Block A body)
      include_relations=False     -> remove Block D
      drop_memory=True            -> V2 'w/o user memory' (empty generated memory,
                                     keep raw recent history)
      minimal_item_meta=True      -> V4/V5 (strip rich item metadata; keep id +
                                     optional short title)
      minimal_include_title=False -> V4 keeps only candidate_id (no title)

    Note: relations (Block D) are derived from item metadata, so callers doing
    V5 (w/o item metadata) pass include_relations=False as well.
    """
    candidate_ids = [c.get("candidate_id") for c in candidates]
    history_titles = history_titles or []
    history_brands = history_brands or set()
    history_cats = history_cats or set()

    parts = [f"{INSTRUCTION_SC}\n\n[sample_id] {sample_id}\n"]

    # Block A
    if raw_user is not None:
        # AgentCR P0-2 V1 single-agent: raw user info instead of Memory output.
        parts.append(_raw_user_state_block(raw_user))
    elif minimal_user_state:
        parts.append("[user_state] (minimal)\n{}\n")
    else:
        parts.append(_user_state_block(user_memory, history_titles,
                                       drop_memory=drop_memory))

    # Block B
    cands_for_prompt = candidates
    if include_source_order:
        parts.append(_retrieval_context_block(candidates, source_name=source_name))
    else:
        # strip sasrec_rank so no source signal leaks into other blocks
        cands_for_prompt = [{k: v for k, v in c.items() if k != "sasrec_rank"}
                            for c in candidates]

    # Block C
    parts.append(_candidate_states_block(cands_for_prompt,
                                         minimal_item_meta=minimal_item_meta,
                                         include_title=minimal_include_title))

    # Block D — derived from item metadata; source_top_blockers gated on source order
    if include_relations:
        parts.append(_relation_context_block(candidates, history_brands, history_cats,
                                             expose_source=include_source_order))

    # candidate ids + output schema
    parts.append(f"[candidate_ids] {json.dumps(candidate_ids)}\n")
    parts.append(
        "Output JSON with EXACTLY this schema:\n"
        "{\n"
        f'  "sample_id": "{sample_id}",\n'
        f'  "ranking": [{", ".join(repr(c) for c in candidate_ids)}],\n'
        '  "top_reason": "...",\n'
        '  "decision_rules": ["..."]\n'
        "}\n"
        "Rules:\n"
        "- 'ranking' MUST be a permutation containing every candidate_id exactly once.\n"
        "- Consider the source order a strong collaborative prior; preserve it when "
        "evidence is weak, override only with clear support.\n"
        "- Do not assume the next item repeats the most frequent history category.\n"
        "- Output a full ranked list, not edit actions. JSON only."
    )
    return rank_system_sc(source_name), "\n".join(parts)


# ---------------------------------------------------------------------------
# Pointwise (Variant 6): score ONE candidate at a time as yes/no. Same user
# state + candidate metadata blocks as the listwise prompt so the only variable
# vs AgentR-SFT is the TRAINING OBJECTIVE (pointwise binary vs listwise
# permutation). No score fusion, no numeric SASRec score.
# ---------------------------------------------------------------------------
POINTWISE_SYSTEM = (
    "You are a recommendation relevance judge. Given a user's state and ONE "
    "candidate item, decide whether this candidate is the user's NEXT interaction. "
    "Answer with a single word: Yes or No."
)

POINTWISE_INSTRUCTION = (
    "Decide whether the candidate item below is the user's NEXT interaction. "
    "Answer 'Yes' or 'No' only."
)


def build_pointwise_prompt(
    user_memory: Dict[str, Any],
    candidate: Dict[str, Any],
    history_titles: Optional[List[str]] = None,
    drop_memory: bool = False,
):
    """Return (system, user_prompt) for a single (user, candidate) judgement.

    Mirrors the listwise user-state block; candidate is shown with full metadata.
    The training LABEL is the token 'Yes' / 'No'; at inference we score P('Yes').
    """
    history_titles = history_titles or []
    info = candidate.get("item_compact_info", {}) or {}
    cand_view = {
        "candidate_id": candidate.get("candidate_id"),
        "title": info.get("title") or info.get("product_name") or "",
        "brand": info.get("brand_name") or "",
        "category": info.get("category_l2") or info.get("category_l1") or "",
        "price": info.get("price") or "",
        "attributes": (info.get("content_snippet") or "")[:200],
    }
    parts = [f"{POINTWISE_INSTRUCTION}\n"]
    parts.append(_user_state_block(user_memory, history_titles, drop_memory=drop_memory))
    parts.append("[candidate_item]\n" + _dumps(cand_view) + "\n")
    parts.append("Is this candidate the user's next interaction? Answer 'Yes' or 'No'.")
    return POINTWISE_SYSTEM, "\n".join(parts)
