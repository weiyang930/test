# AgentR — multi-agent LLM reranking for sequential recommendation

A standalone, code-only copy of our MAS-for-Rec method with its three working stages:
**prompt** (multi-agent rollout), **SFT** (rank-agent training) and **RL** (GRPO on the ranker).
The data and checkpoints are not included. `tools/link_legacy_outputs.sh` links the
artifacts of the original research tree into this layout, so every stage can be re-run or
evaluated without recomputing what came before it.

Every task is 10-choose-1 listwise reranking with a single positive. The model outputs a
**full permutation** of the candidates as JSON. There is no score fusion: the SASRec
source order goes into the prompt as context only.

| Setting | Candidates | Users evaluated | Method |
|---|---|---|---|
| **cf_hard** (line A) | 1 positive + 9 SASRec hard negatives | all test users | Closed-loop MAS (Memory → Evidence → Rank → Reflection → MemoryUpdater). Rollout traces train the rank agent (positive-first target). |
| **real_retrieved** (line B) | SASRec top-10 real recall | recall-hit test users | Source-conditioned listwise ranker (no evidence agent). **Preserve-correct** SFT, then **GRPO** with a source-relative reward. |

## Reference results (Qwen3-8B; full tables in the original `develop/` docs)

| | CD | Kindle_Store | Rednote |
|---|---|---|---|
| **real_retrieved R@1**, n users | 1024 | 669 | 3369 |
| SASRec source | 0.2568 | 0.3333 | 0.2939 |
| Ours (prompt, zero-shot) | 0.2256 | 0.3991 | 0.2535 |
| Ours (SFT, preserve-correct) | 0.2852 | 0.4305 | 0.3298 |
| Ours (SFT + GRPO srA2 recipe, step 100) | **0.3213** | **0.5501** | 0.3336 (ns vs SFT) |
| **cf_hard R@1**, n users | 9198 | 15000 | 18151 |
| SASRec | 0.0276 | 0.0153 | 0.0548 |
| Ours (prompt-MAS rollout, zero-shot) | 0.1891 | 0.1847 | 0.1818 |
| Ours (SFT) | **0.4063** | **0.4348** | **0.2772** |

GRPO also helps on Grocery (+3.2pt) and Software (+1.7pt, but seed-sensitive). It is
null on Rednote, Video_Games and Baby_Products.

**Re-evaluating with this repo.** The prompts are byte-identical to the original runs. On
H100 vs the original B200 runs, greedy vLLM decoding flips a handful of users per test
set (see "Verification" below).

## Layout

```
agentr_paths.py           dataset registry + output layout (single source of truth)
env.sh                    python envs, base model, CUDA bin, scratch dir (override via env)
configs/templates/        cfhard_rollout / recall_gen / recall_eval YAML -> outputs/<ds>/configs/
reflective_mas_rec/       core MAS package: agents, prompts, data/splits/negatives, rollout,
                          cf_hard SFT data builder, LoRA SFT trainer, trained-rank eval
source_conditioned/       real_retrieved ranker: prompt (source_prompt.py), preserve-correct SFT
                          data, evaluator, preserve/rescue/false-damage analysis
rl/                       GRPO (verl): OOS env builders, source-relative reward, launcher,
                          sdpa/flash-attn compat shims, compare.py, tb_summary.py
recbole_baselines/        SASRec training + recall / hard-negative / candidate export (RecBole)
dataset_builder/          Amazon-Reviews-2023 category -> demo-schema parquet (+ LLM personas)
scripts/                  numbered stage drivers (below), lib.sh, train_sft.sh
tools/                    link_legacy_outputs.sh, merge_lora_ckpt.py (merge an interrupted LoRA ckpt)
```

All outputs of dataset `<ds>` go to `outputs/<ds>/{sasrec,cfhard,recall,sc,rl,configs,logs}`.
See the docstring of `agentr_paths.py` for the full layout. `AGENTR_OUT_ROOT` relocates the
whole tree (for example, for a smoke run).

Registered datasets (`python agentr_paths.py --list`): `cd`, `kindle_store`, `rednote`,
`software`, `videogames`, `baby_products`, `sports_and_outdoors`, `grocery_and_gourmet_food`,
`movies_and_tv`, `home_and_kitchen`. To add one, add a line to `DATASETS`.

## Environments

Three python envs, set in `env.sh` (defaults: `.venv_mas`, `.venv_recbole`, `.venv_verl` under the repo root). Exact versions are frozen in `envs/`.

| var | stack | used for |
|---|---|---|
| `MAS_PY` | vllm 0.25, torch 2.11+cu130, transformers 5.x, peft (`reflective_mas_rec/requirements.txt`) | rollout, SFT, eval, data building |
| `RECBOLE_PY` | recbole 1.2.1, numpy 1.26.4, scipy 1.11.4 | SASRec, recall / negative export |
| `VERL_PY` | verl v0.9.0 (git 483b8a0), vllm 0.24, ray 2.58, tensorboard | GRPO only |

The MAS env needs two fixes on B200 (Blackwell):
- uninstall `torchcodec`;
- put `ninja` on PATH (`lib.sh: mas_env` does this).

verl runs with sdpa: `rl/compat` installs a pure-PyTorch `flash_attn.bert_padding` shim and
patches verl to its padded attention path.

`BASE_MODEL` must point at a Qwen3-8B HF directory (default `models/Qwen/Qwen3-8B`).

## Pipeline

Run every stage from the repo root. `GPUS` (comma list) or `GPU` picks devices. Every stage
skips outputs that already exist (`FORCE=1` redoes a stage).

```bash
DS=cd
# 0  data (Amazon only; rednote is provided)       -> data/amazon/<Cat>/*.parquet
bash scripts/00_build_amazon_dataset.sh CDs_and_Vinyl
# 1  SASRec + candidates + cf_hard samples
GPU=0 bash scripts/10_upstream_sasrec.sh $DS
# 2  line A (cf_hard): MAS rollout -> SFT -> eval
GPUS=0,1,2,3,4,5,6,7 bash scripts/20_cfhard_rollout.sh $DS
bash scripts/21_cfhard_sft.sh $DS
GPUS=0,1,2,3,4,5,6,7 bash scripts/22_cfhard_eval.sh $DS            # [model] [tag]
# 3  line B (real_retrieved): recall traces + test set -> preserve-correct SFT -> eval
GPUS=0,1,2,3,4,5,6,7 bash scripts/30_recall_traces.sh $DS          # needs stage 2 test traces
bash scripts/31_sc_sft.sh $DS
GPU=0 bash scripts/32_sc_eval.sh $DS                                # [model] [tag]
GPU=0 bash scripts/32_sc_eval.sh $DS "$BASE_MODEL" promptzs         # zero-shot prompt baseline
# 4  RL: OOS env -> GRPO (srA2 recipe) -> merge + eval vs SFT / SASRec
GPU=0 bash scripts/40_rl_env.sh $DS                                 # needs stage 2 train/valid traces
GPUS=0,1,2,3 bash scripts/41_rl_grpo.sh $DS srA2
GPU=0 bash scripts/42_rl_eval.sh $DS srA2 100                       # pre-registered step
```

### Stage notes

- **Sharded rollout (stages 20 and 30).** Each GPU runs one vLLM process on a disjoint
  window of *distinct users*. The result is exactly the single-process result (sharding
  by sample instead caused a past bug).
  - Multi-node: run the driver once per node with `SHARD_TOTAL=16 SHARD_BASE=0` or `=8`,
    then merge.
  - Use `MAX_USERS=n` for a quick check.
- **SFT (`scripts/train_sft.sh`).**
  - Recipe: LoRA r16/α32/dropout 0.05 on q,k,v,o,gate,up,down; 1 epoch; lr 1e-4; warmup
    0.03 then cosine; max_len 6144; bf16; effective batch 32. The adapter is auto-merged
    into `merged_model/`.
  - The paper runs used 2 nodes × 8 GPUs. Single node keeps the effective batch at 32
    through grad accumulation.
  - Multi-node: set `NNODES`, `NODE_RANK`, `MASTER_ADDR` and `MASTER_PORT`, and run once
    per node.
- **cf_hard SFT target.** The positive goes to #1 and the rest keep the rollout rank
  agent's order (`SFT_BODY_ORDER=model`). The prompt is `build_rank_prompt` (train ==
  infer), and the trace supplies memory and evidence.
- **Preserve-correct target (main real_retrieved change).**
  - If the source top-1 is the positive, the target is the source order.
  - Otherwise, the target is `[positive] + rest in source order`.
  - The output is `{"sample_id","ranking"}` only (`--rationale none`). Train and eval
    share `source_prompt.build_source_conditioned_prompt`.
- **Why an out-of-sample RL env.** SASRec is in-sample on train windows, so "copy SASRec"
  is reward-optimal there and GRPO collapses. Stage 40 uses two kinds of windows whose
  target SASRec never saw:
  - valid windows, with the main SASRec;
  - the last 4 train items, with a SASRec retrained on `train_items[:-4]`.

  Prompts are built exactly like test prompts.
- **Reward.** The reward (`rl/reward_sr.py`, `source_relative_ndcg`) is
  `α·preserve + β·rescue_score − γ·false_damage + λ·(g(m) − g(s))`, with α=1, β=2, γ=1,
  λ=0.5, where g(r) = 1/log2(r+1), s is the positive's source rank and m its model rank.
  Invalid output scores −1.
  - It needs `norm_adv_by_std_in_grpo=false`. With std-normalisation, the weights cancel
    back to plain HR.
  - Other settings: T 0.7, lr 5e-7, KL 0.05 (low_var_kl), clip_high 0.28, BS64 × G8,
    200 steps.
  - **Use step 100.** Validation reward does not select checkpoints reliably, and CD
    overshoots by step 200.
- **8×H100 for GRPO.** Set `GPU_MEM=0.35 LOGP_MICRO=4 PPO_MICRO=2`. Each verl checkpoint is
  ~90 GB; `CLEAN_CKPT=1 scripts/42_rl_eval.sh` deletes it after the merge.
- **Significance.** `rl/compare.py` reports paired bootstrap (B = 10000) and McNemar on
  HR@1. It reads either per-sample schema (real_retrieved or cf_hard).

## Reusing the original artifacts

```bash
bash tools/link_legacy_outputs.sh /path/to/original/project cd kindle_store rednote
ln -s /path/to/Qwen3-8B models/Qwen/Qwen3-8B      # or export BASE_MODEL=...
GPU=0 bash scripts/32_sc_eval.sh cd                  # re-evaluate the CD SFT ranker
GPU=1 bash scripts/42_rl_eval.sh cd legacy_srA2 100  # re-evaluate CD GRPO step 100
```

How the links stay safe:
- They are leaf-level (files and model dirs) inside real directories.
- Drivers skip existing outputs and `rm` a link instead of writing through it.

So the original tree is never modified.

## Verification of this copy (2026-10-26, H100 node, against the original artifacts)

- **Byte-identical to the original runs:**
  - preserve-correct SFT data (CD / Kindle / Rednote, md5 match);
  - cf_hard SFT data (Kindle, first 3000 traces);
  - OOS RL prompts and ground truth (CD valid + holdout, every row);
  - all 1024 CD real_retrieved eval prompts (hashed against the original code);
  - the SASRec top-10 export from the original checkpoint.
- **Re-evaluating the original checkpoints with this repo** (R@1):

  | Run | This repo | Original |
  |---|---|---|
  | CD SFT | 0.2822 | 0.2852 |
  | Kindle SFT | 0.4320 | 0.4305 |
  | Rednote SFT | 0.3271 | 0.3298 |
  | CD GRPO step 100 | 0.3203 | 0.3213 |
  | CD cf_hard SFT | 0.4064 | 0.4063 |

  The inputs are identical. The gaps are vLLM greedy-decoding nondeterminism across GPU
  types (B200 vs H100): the original code on the same H100 node gives Kindle 0.4320
  (identical to this repo) and CD 0.2842. Every improvement over SASRec stays
  significant.
- **Smoke-tested in this repo:**
  - stage 10 (SASRec retrain + exports + samples; a retrained SASRec is a slightly
    different model: hit@10 0.1107 vs 0.1113);
  - stage 20 rollout start-up;
  - stages 22 and 32;
  - stage 41 (2 GRPO steps) and stage 42 (merge, eval, compare).

  Stages 21/31 use the same trainer the paper used.

## Known caveats (inherited from the paper runs; kept for reproducibility)

- **Train-prompt memory leak.** `build_preserve_correct_sft.py` uses the trace field
  `user_memory_before`, as the paper runs did.
  - When several windows of one user share a rollout batch, that field can hold a *later*
    window's memory. The positive's title appears in about 23% of CD train prompts; test
    prompts are clean.
  - `MEMORY_FIELD=user_memory_after bash scripts/31_sc_sft.sh <ds>` builds leak-free SFT
    data. This variant has not been retrained yet.
  - The RL env reads cf_hard traces, which are clean.
- **The evidence prompt changed on 2026-07-22** (the "plausible-next" evidence prompt in
  `llm/prompt_templates.py`, which this repo carries). The CD/rednote cf_hard rollouts
  predate it; Kindle's uses it.
- **Kindle preserve-correct SFT** in the paper is the step-5000 checkpoint (about half an
  epoch, interrupted). `tools/merge_lora_ckpt.py` merges such a checkpoint.
- **Not included** (exploratory or negative): DPO, rationale (templated) SFT, pointwise
  scoring, the IA-GRPO dual-controller variants, the 2026-07 RL attempt, baselines
  (CF/text/LLM/agentic) and the RQ analysis scripts. All of these remain in the original
  tree.
