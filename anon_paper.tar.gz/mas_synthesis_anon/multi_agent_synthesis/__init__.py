"""multi_agent_synthesis: a prompt-based, offline synthetic-task generation
pipeline for agentic LLMs, with tau2-Bench Telecom as the first target.

The package is organized so that the *pipeline* is domain-agnostic and all
benchmark-specific logic lives behind a :class:`DomainAdapter`.
"""

__version__ = "0.1.0"
