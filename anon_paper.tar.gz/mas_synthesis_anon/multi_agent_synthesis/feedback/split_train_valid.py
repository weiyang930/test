"""Stratified train/valid split with a monotonic accumulated valid pool.

Hard invariant: once a sample_id enters the valid pool, it NEVER goes to train in
any later round. The splitter consumes the ledger first (force those ids to valid),
then splits the genuinely-new samples by stratified bucket. Stratification bucket is
task_family x expected_outcome -- single-value, stable, not sparse.

Performance feedback is computed only on the accumulated valid pool, so this split is
what keeps before/after success rates off the training data.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple

from .sample_record import FeedbackSample

DEFAULTS = {
    "valid_ratio": 0.2,
    "min_valid_threshold_per_bucket": 5,   # bucket smaller than this -> fallback
    "min_valid_samples_per_bucket": 2,     # floor: if a bucket DOES split, take >=2
}


def _bucket(sample: FeedbackSample) -> str:
    """Stratification bucket: task_family x expected_outcome.

    P0: task_family is now multi-valued (1-3). The bucket uses sorted '+' join
    so multi-intent tasks form their own bucket (a 'flight_change+flight_cancel'
    sample is NOT lumped with single-family flight_change). Fewer-sample
    multi-intent buckets fall back to all-train via the existing threshold logic.
    """
    mp = sample.micro_plan
    fam_raw = mp.get("task_family", "")
    if isinstance(fam_raw, list):
        fam = "+".join(sorted(str(x) for x in fam_raw if x))
    else:
        fam = str(fam_raw)
    out = mp.get("expected_outcome", "")
    return f"{fam}|{out}"


def _rank(sample_id: str, seed: int) -> str:
    """Deterministic pseudo-random rank for a sample id (seeded hash)."""
    return hashlib.sha256(f"{seed}:{sample_id}".encode()).hexdigest()


def stratified_train_valid_split(
    samples: List[FeedbackSample],
    valid_pool_ledger: Set[str],
    valid_ratio: float = 0.2,
    config: Optional[Dict] = None,
    seed: int = 0,
) -> Tuple[List[FeedbackSample], List[FeedbackSample]]:
    """Return (train_split, valid_split). Deterministic given seed.

    1. Any sample whose id is already in valid_pool_ledger is forced to valid.
    2. Remaining (new) samples are bucketed by task_family x expected_outcome.
       Within each bucket, the lowest-ranked ceil(valid_ratio * n) samples go to
       valid (rank = seeded hash, so it's stable and reproducible).
    3. Buckets with fewer than min_valid_threshold_per_bucket samples fall back to
       all-train (too small to carve a reliable valid slice).
    4. When a bucket DOES split, it takes at least min_valid_samples_per_bucket
       (capped at the bucket size).

    Mutates each input sample's `.split` field in place ("train"/"valid") -- this is
    the intended contract: the returned samples carry their assigned split for the
    coverage/performance modules and for persistence.
    """
    cfg = {**DEFAULTS, **(config or {})}
    threshold = cfg["min_valid_threshold_per_bucket"]
    floor = cfg["min_valid_samples_per_bucket"]

    train: List[FeedbackSample] = []
    valid: List[FeedbackSample] = []

    new_samples: List[FeedbackSample] = []
    for s in samples:
        if s.sample_id in valid_pool_ledger:
            s.split = "valid"
            valid.append(s)
        else:
            new_samples.append(s)

    # Bucket only the NEW samples; ledger ids were already forced to valid above,
    # so they never reach the per-bucket split (the never-train invariant).
    buckets: Dict[str, List[FeedbackSample]] = defaultdict(list)
    for s in new_samples:
        buckets[_bucket(s)].append(s)

    import math
    for _, members in sorted(buckets.items()):
        if len(members) < threshold:
            for s in members:
                s.split = "train"
                train.append(s)
            continue
        ranked = sorted(members, key=lambda s: _rank(s.sample_id, seed))
        n_valid = max(floor, math.ceil(valid_ratio * len(members)))
        n_valid = min(n_valid, len(members))
        for i, s in enumerate(ranked):
            if i < n_valid:
                s.split = "valid"
                valid.append(s)
            else:
                s.split = "train"
                train.append(s)

    return train, valid


def append_to_valid_pool(new_valid_samples: List[FeedbackSample],
                         valid_pool_path: str) -> None:
    """Append new valid sample_ids to the accumulated ledger (JSONL). Idempotent:
    ids already in the pool are not written again."""
    existing = load_valid_pool(valid_pool_path)
    os.makedirs(os.path.dirname(os.path.abspath(valid_pool_path)), exist_ok=True)
    with open(valid_pool_path, "a") as fh:
        for s in new_valid_samples:
            if s.sample_id in existing:
                continue
            existing.add(s.sample_id)
            fh.write(json.dumps({"sample_id": s.sample_id,
                                 "round_id": s.round_id}) + "\n")


def load_valid_pool(valid_pool_path: str) -> Set[str]:
    """Read the ledger, returning the set of sample_ids locked as valid. Missing
    file -> empty set."""
    if not os.path.exists(valid_pool_path):
        return set()
    out: Set[str] = set()
    with open(valid_pool_path) as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            out.add(json.loads(line)["sample_id"])
    return out
