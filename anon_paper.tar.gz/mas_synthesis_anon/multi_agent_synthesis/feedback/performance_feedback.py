"""Task-agent performance / utility feedback, aggregated per Level-1+Level-2 key
over the accumulated valid pool ONLY (never training data).

Decoupled from reward: before_eval_results / after_eval_results are plain
{sample_id: success} dicts the CALLER produces (success may be 0/1 or a float in
[0,1]). This module never runs eval or training. A sample missing from an eval dict
is excluded from that rate's denominator (we can't score what wasn't evaluated).

valid_count for a key = number of its valid samples that HAVE an after-eval result
(the support we can actually score). When that count is below
min_valid_count_for_performance the key is `insufficient_support` and is excluded
from the actionable buckets so the macro layer never acts on noise.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from .dimension_keys import build_marginal_keys, build_pairwise_keys, key_id, normalize_values
from .sample_record import FeedbackSample

DEFAULTS = {
    "min_valid_count_for_performance": 10,
    "reliable_valid_count": 20,
    "mastered_threshold": 0.7,
    "weak_threshold": 0.4,
    "delta_eps": 0.03,
}


def _classify(valid_count, before, after, delta, cfg) -> str:
    if valid_count < cfg["min_valid_count_for_performance"]:
        return "insufficient_support"
    if delta < -cfg["delta_eps"]:
        return "regressed"
    if after >= cfg["mastered_threshold"]:
        return "mastered"
    if after < cfg["mastered_threshold"] and delta > cfg["delta_eps"]:
        return "weak_but_improving"
    if after < cfg["weak_threshold"] and abs(delta) <= cfg["delta_eps"]:
        return "weak_and_stagnant"
    return "weak"


def _stats_for_family(valid_samples, before, after, builder, cfg) -> List[Dict]:
    # key_id -> {key, before_sum, before_n, after_sum, after_n}
    acc: Dict[str, Dict] = {}
    for s in valid_samples:
        values = normalize_values(s.micro_plan)
        sid = s.sample_id
        b_val = before.get(sid)
        a_val = after.get(sid)
        for key in builder(values):
            kid = key_id(key)
            slot = acc.setdefault(kid, {"key": key, "b_sum": 0.0, "b_n": 0,
                                        "a_sum": 0.0, "a_n": 0})
            if b_val is not None:
                slot["b_sum"] += float(b_val)
                slot["b_n"] += 1
            if a_val is not None:
                slot["a_sum"] += float(a_val)
                slot["a_n"] += 1

    stats: List[Dict] = []
    for kid in sorted(acc):
        slot = acc[kid]
        key = slot["key"]
        before_rate = (slot["b_sum"] / slot["b_n"]) if slot["b_n"] else 0.0
        after_rate = (slot["a_sum"] / slot["a_n"]) if slot["a_n"] else 0.0
        delta = after_rate - before_rate
        valid_count = slot["a_n"]  # support = scored (after) samples
        status = _classify(valid_count, before_rate, after_rate, delta, cfg)
        stats.append({
            "key_type": key["key_type"],
            "dimensions": key["dimensions"],
            "values": key["values"],
            "valid_count": valid_count,
            "before_success_rate": round(before_rate, 6),
            "after_success_rate": round(after_rate, 6),
            "delta_success_rate": round(delta, 6),
            "performance_status": status,
        })
    return stats


def compute_performance_feedback(
    before_eval_results: Dict[str, float],
    after_eval_results: Dict[str, float],
    valid_samples: List[FeedbackSample],
    config: Optional[Dict] = None,
) -> Dict:
    cfg = {**DEFAULTS, **(config or {})}
    marginal_stats = _stats_for_family(valid_samples, before_eval_results,
                                       after_eval_results, build_marginal_keys, cfg)
    pairwise_stats = _stats_for_family(valid_samples, before_eval_results,
                                       after_eval_results, build_pairwise_keys, cfg)

    def _picks(stats, status):
        return [{"key_type": s["key_type"], "dimensions": s["dimensions"],
                 "values": s["values"]}
                for s in stats if s["performance_status"] == status]

    all_stats = marginal_stats + pairwise_stats
    return {
        "marginal_stats": marginal_stats,
        "pairwise_stats": pairwise_stats,
        "mastered_keys": _picks(all_stats, "mastered"),
        "weak_but_improving_keys": _picks(all_stats, "weak_but_improving"),
        "weak_and_stagnant_keys": _picks(all_stats, "weak_and_stagnant"),
        "regressed_keys": _picks(all_stats, "regressed"),
    }
