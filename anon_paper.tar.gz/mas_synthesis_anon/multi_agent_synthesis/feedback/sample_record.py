"""FeedbackSample: the persisted per-accepted-sample record the feedback pipeline
consumes. Extraction reads the REALIZED micro_plan (what the sample actually is),
NOT the macro condition (what we asked for) -- coverage/performance must reflect
reality.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, Field

from .dimension_keys import ALL_KEYS, MULTI_VALUE_KEYS


class FeedbackSample(BaseModel):
    sample_id: str                                  # = candidate_id
    round_id: str
    intended_condition: Dict[str, Any] = Field(default_factory=dict)
    micro_plan: Dict[str, Any] = Field(default_factory=dict)  # realized 6 dims
    split: str = ""                                 # "train" | "valid" (filled by splitter)


def feedback_sample_from_candidate(
    candidate: Any,
    round_id: str,
    intended_condition: Optional[Dict[str, Any]] = None,
) -> FeedbackSample:
    """Build a FeedbackSample from an accepted TaskCandidate.

    Realized dims come from blueprint.dimension_plan["selected_dimensions"], except
    expected_outcome which is read via blueprint.expected_outcome() (defaults to
    "fulfill", unwraps list form). Single-value dims default to "" when absent;
    multi-value dims default to []. micro_plan keeps single-value dims as str and
    multi-value dims as list (the on-disk shape the rest of the pipeline expects).
    """
    bp = candidate.blueprint
    sel = (bp.dimension_plan or {}).get("selected_dimensions", {}) if bp.dimension_plan else {}

    micro_plan: Dict[str, Any] = {}
    for k in ALL_KEYS:
        if k == "expected_outcome":
            micro_plan[k] = bp.expected_outcome()
            continue
        raw = sel.get(k)
        if k in MULTI_VALUE_KEYS:
            micro_plan[k] = list(raw) if isinstance(raw, (list, tuple)) else (
                [] if raw is None else [raw])
        else:
            if isinstance(raw, (list, tuple)):
                micro_plan[k] = str(raw[0]) if raw else ""
            else:
                micro_plan[k] = "" if raw is None else str(raw)

    return FeedbackSample(
        sample_id=candidate.candidate_id,
        round_id=round_id,
        intended_condition=intended_condition or {},
        micro_plan=micro_plan,
        split="",
    )
