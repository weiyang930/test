"""Feedback module: turns accepted samples into coverage + performance signals
for the macro planner. See docs/superpowers/specs/2026-06-14-feedback-design.md."""

from .sample_record import FeedbackSample, feedback_sample_from_candidate
from .split_train_valid import (
    stratified_train_valid_split,
    append_to_valid_pool,
    load_valid_pool,
)
from .coverage_feedback import compute_coverage_feedback
from .performance_feedback import compute_performance_feedback
from .macro_feedback_summary import build_macro_feedback_summary

__all__ = [
    "FeedbackSample",
    "feedback_sample_from_candidate",
    "stratified_train_valid_split",
    "append_to_valid_pool",
    "load_valid_pool",
    "compute_coverage_feedback",
    "compute_performance_feedback",
    "build_macro_feedback_summary",
]
