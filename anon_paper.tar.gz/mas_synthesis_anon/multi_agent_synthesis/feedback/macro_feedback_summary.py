"""Join coverage feedback x performance feedback into the macro-consumable summary.

The priority matrix (v1) joins coverage_status x performance_status per key_id:
  undercovered + weak_but_improving -> high
  undercovered + weak               -> high
  undercovered + weak_and_stagnant  -> explore
  overcovered  + mastered           -> low
  overcovered  + weak               -> medium
  weak_and_stagnant (any coverage)  -> explore
  regressed (any coverage)          -> zero_or_pause
  insufficient_support              -> fall back to coverage-only for that key
When a key has NO performance entry (e.g. no eval ran this round) it uses the
coverage-only mapping: undercovered -> high, overcovered -> low, normal -> medium.

NOTE (this round): the summary is COMPUTED and SAVED but NOT wired into MacroPlanner.
recommended_macro_signals is the contract the next spec will consume.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from .dimension_keys import key_id


def _key_ref(stat: Dict) -> Dict:
    return {"key_type": stat["key_type"], "dimensions": stat["dimensions"],
            "values": stat["values"]}


def _coverage_only_priority(cov_status: str) -> str:
    if cov_status == "undercovered":
        return "high"
    if cov_status == "overcovered":
        return "low"
    return "medium"


def _joined_priority(cov_status: str, perf_status: str) -> str:
    if perf_status == "regressed":
        return "zero_or_pause"
    if perf_status == "weak_and_stagnant":
        return "explore"
    if cov_status == "undercovered" and perf_status == "weak_but_improving":
        return "high"
    if cov_status == "undercovered" and perf_status == "weak":
        return "high"
    if cov_status == "overcovered" and perf_status == "mastered":
        return "low"
    if cov_status == "overcovered" and perf_status == "weak":
        return "medium"
    # any remaining combination: lean on coverage
    return _coverage_only_priority(cov_status)


_BUCKET = {
    "high": "high_priority_keys",
    "medium": "medium_priority_keys",
    "low": "low_priority_keys",
    "zero_or_pause": "zero_or_pause_keys",
    "explore": "explore_keys",
}


def build_macro_feedback_summary(
    coverage_feedback: Dict,
    performance_feedback: Dict,
    round_id: str = "",
    config: Optional[Dict] = None,
) -> Dict:
    signals: Dict[str, List[Dict]] = {v: [] for v in _BUCKET.values()}

    cov_stats = coverage_feedback.get("marginal_stats", []) + \
        coverage_feedback.get("pairwise_stats", [])
    perf_stats = performance_feedback.get("marginal_stats", []) + \
        performance_feedback.get("pairwise_stats", [])
    perf_by_id = {key_id(_key_ref(s)): s["performance_status"] for s in perf_stats}

    for cov in cov_stats:
        kid = key_id(_key_ref(cov))
        cov_status = cov["coverage_status"]
        perf_status = perf_by_id.get(kid)
        if perf_status is None or perf_status == "insufficient_support":
            priority = _coverage_only_priority(cov_status)
        else:
            priority = _joined_priority(cov_status, perf_status)
        signals[_BUCKET[priority]].append(_key_ref(cov))

    return {
        "round_id": round_id,
        "coverage_feedback": coverage_feedback,
        "performance_feedback": performance_feedback,
        "recommended_macro_signals": signals,
    }
