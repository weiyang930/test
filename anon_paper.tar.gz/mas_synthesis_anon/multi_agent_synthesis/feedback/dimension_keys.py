"""Single source of truth for the feedback coordinate system.

Defines the 6-dim ontology (shared with macro/micro via dimensions/areal_sea.yaml
shared_keys), the exactly-5 pairwise crosses, and how to EXPLODE a sample's realized
dimension values into countable keys. Every other feedback module imports from here so
all three layers stay on one coordinate system.

Multi-value dims explode: each value in the list is counted once. So a sample with
policy_or_constraint_focus=[refund, compensation] contributes to BOTH the `refund` and
`compensation` marginal keys. As a result, the count total for a multi-value dim can
exceed the number of samples -- this is intended.
"""

from __future__ import annotations

from itertools import product
from typing import Dict, List

# P0: task_family moved to MULTI_VALUE_KEYS (1-3 vals); two new single-value
# axes (task_composition, entity_scope) added.
# P0: task_family moved to MULTI_VALUE_KEYS (1-3 vals); task_composition,
# entity_scope added. 2026-06-19: solution_search, answer_obligation (fail-set
# axes) added as single-value so feedback can weight them (when omitted they are
# realized as "none", which still counts -- the macro layer reads the under-served
# "pick_optimal"/"exact_value" cells from the feedback marginals).
SINGLE_VALUE_KEYS = (
    "task_composition", "entity_scope",
    "expected_outcome", "difficulty_profile",
    "solution_search", "answer_obligation",
)
MULTI_VALUE_KEYS = (
    "task_family",
    "policy_or_constraint_focus", "tool_use_pattern", "interaction_challenge",
)
ALL_KEYS = (
    "task_family", "task_composition", "entity_scope",
    "expected_outcome", "policy_or_constraint_focus",
    "tool_use_pattern", "interaction_challenge", "difficulty_profile",
    "solution_search", "answer_obligation",
)

# Pairwise crosses (spec §2). dims order is FIXED -- never sorted -- so
# task_family x tool_use_pattern is never flipped. 2026-06-19: added the two
# fail-set axes crossed with expected_outcome so feedback can localize weakness
# on "pick_optimal x fulfill" / "exact_value x fulfill".
PAIRWISE_KEYS = (
    ("task_family", "expected_outcome"),
    ("policy_or_constraint_focus", "expected_outcome"),
    ("tool_use_pattern", "expected_outcome"),
    ("task_family", "tool_use_pattern"),
    ("policy_or_constraint_focus", "tool_use_pattern"),
    ("solution_search", "expected_outcome"),
    ("answer_obligation", "expected_outcome"),
)


def normalize_values(raw: Dict) -> Dict[str, List[str]]:
    """Normalize a realized 6-dim plan to Dict[str, List[str]].

    Single-value dims (str or 1-element list) -> 1-element list. Multi-value dims
    (list) -> the list as-is. None / missing -> empty list. Defensive: any non-str
    scalar is stringified, so downstream counting is uniform.
    """
    out: Dict[str, List[str]] = {}
    for k in ALL_KEYS:
        v = raw.get(k)
        if v is None:
            out[k] = []
        elif isinstance(v, (list, tuple)):
            out[k] = [str(x) for x in v]
        else:
            out[k] = [str(v)]
    return out


def build_marginal_keys(values: Dict[str, List[str]]) -> List[Dict]:
    """Explode all 6 dims into marginal keys: one key per (dim, value)."""
    keys: List[Dict] = []
    for dim in ALL_KEYS:
        for val in values.get(dim, []):
            keys.append({"key_type": "marginal", "dimensions": [dim], "values": [val]})
    return keys


def build_pairwise_keys(values: Dict[str, List[str]]) -> List[Dict]:
    """Explode the 5 fixed pairwise crosses via cartesian product. A pair where
    EITHER dim has no values contributes nothing."""
    keys: List[Dict] = []
    for d1, d2 in PAIRWISE_KEYS:
        v1s = values.get(d1, [])
        v2s = values.get(d2, [])
        for a, b in product(v1s, v2s):
            keys.append({"key_type": "pairwise", "dimensions": [d1, d2], "values": [a, b]})
    return keys


def key_id(key: Dict) -> str:
    """Stable, hashable id for a key, for counting / table lookup.

    Dimension order is fixed by ALL_KEYS / PAIRWISE_KEYS and is preserved here (not
    sorted), so it stays consistent with the builders. key_type is part of the id so a
    marginal and a pairwise with coincidentally-equal surface text never collide.
    """
    pairs = zip(key["dimensions"], key["values"])
    body = "|".join(f"{d}={v}" for d, v in pairs)
    return f"{key['key_type']}::{body}"
