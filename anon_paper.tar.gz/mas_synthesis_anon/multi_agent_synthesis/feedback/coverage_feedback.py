"""Coverage / distribution feedback over Level-1 marginals + Level-2 pairwise keys.

coverage_status uses a relative-uniform baseline (no preset target distribution):
within one dimension group (a marginal dim, or a fixed pairwise dim-pair), the
expected share of a key = 1 / (distinct values currently present in that group).
A key is undercovered if its share < under_factor * expected, overcovered if
> over_factor * expected, else normal.

Because multi-value dims explode, the count total within such a group can exceed the
number of samples -- that's expected and the ratio denominator accounts for it.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Optional

from .dimension_keys import build_marginal_keys, build_pairwise_keys, key_id, normalize_values
from .sample_record import FeedbackSample

DEFAULTS = {"under_factor": 0.5, "over_factor": 1.5}


def _group_id(key: Dict) -> str:
    """The dimension group a key belongs to (its dims, order preserved)."""
    return "|".join(key["dimensions"])


def _count(samples: List[FeedbackSample], builder) -> Dict[str, Dict]:
    """Map key_id -> {key dict, count} for one key family (marginal or pairwise)."""
    acc: Dict[str, Dict] = {}
    for s in samples:
        values = normalize_values(s.micro_plan)
        for key in builder(values):
            kid = key_id(key)
            if kid not in acc:
                acc[kid] = {"key": key, "count": 0}
            acc[kid]["count"] += 1
    return acc


def _stats_for_family(train, valid, builder, cfg) -> List[Dict]:
    train_c = _count(train, builder)
    valid_c = _count(valid, builder)
    all_ids = set(train_c) | set(valid_c)

    # group totals (train+valid) for the relative-uniform baseline
    group_total: Dict[str, int] = defaultdict(int)
    group_values: Dict[str, set] = defaultdict(set)
    merged: Dict[str, Dict] = {}
    for kid in all_ids:
        key = (train_c.get(kid) or valid_c.get(kid))["key"]
        tc = train_c.get(kid, {}).get("count", 0)
        vc = valid_c.get(kid, {}).get("count", 0)
        total = tc + vc
        merged[kid] = {"key": key, "train": tc, "valid": vc, "total": total}
        gid = _group_id(key)
        group_total[gid] += total
        group_values[gid].add(tuple(key["values"]))

    stats: List[Dict] = []
    for kid in sorted(all_ids):
        m = merged[kid]
        key = m["key"]
        gid = _group_id(key)
        gtotal = group_total[gid]
        ratio = (m["total"] / gtotal) if gtotal else 0.0
        n_vals = max(1, len(group_values[gid]))
        expected = 1.0 / n_vals
        if ratio < cfg["under_factor"] * expected:
            status = "undercovered"
        elif ratio > cfg["over_factor"] * expected:
            status = "overcovered"
        else:
            status = "normal"
        stats.append({
            "key_type": key["key_type"],
            "dimensions": key["dimensions"],
            "values": key["values"],
            "train_count": m["train"],
            "valid_count": m["valid"],
            "total_count": m["total"],
            "ratio": round(ratio, 6),
            "coverage_status": status,
        })
    return stats


def compute_coverage_feedback(
    train_samples: List[FeedbackSample],
    valid_samples: List[FeedbackSample],
    config: Optional[Dict] = None,
) -> Dict:
    cfg = {**DEFAULTS, **(config or {})}
    marginal_stats = _stats_for_family(train_samples, valid_samples,
                                       build_marginal_keys, cfg)
    pairwise_stats = _stats_for_family(train_samples, valid_samples,
                                       build_pairwise_keys, cfg)

    def _picks(stats, status):
        return [{"key_type": s["key_type"], "dimensions": s["dimensions"],
                 "values": s["values"]}
                for s in stats if s["coverage_status"] == status]

    all_stats = marginal_stats + pairwise_stats
    return {
        "marginal_stats": marginal_stats,
        "pairwise_stats": pairwise_stats,
        "undercovered_keys": _picks(all_stats, "undercovered"),
        "overcovered_keys": _picks(all_stats, "overcovered"),
    }
