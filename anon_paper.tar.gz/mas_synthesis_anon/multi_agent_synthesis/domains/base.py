"""DomainAdapter: the single seam between the domain-agnostic pipeline and a
concrete benchmark.

Everything benchmark-specific (task format, env reset/replay/evaluator, entity
existence, difficulty/coverage heuristics) lives behind this interface. The
main pipeline (planner -> generator -> verifiers -> filter -> export) only ever
calls these methods; it never imports tau2 or telecom directly.

To onboard a new benchmark/domain you implement one subclass.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Tuple

from ..schemas import GTAction, TaskBlueprint, TaskCandidate


class DomainAdapter(ABC):
    name: str = "base"

    # ------------------------------------------------------------- static context
    @abstractmethod
    def load_schema(self) -> Dict[str, Any]:
        """Return tool/entity/state schema info used to build generation context."""

    @abstractmethod
    def load_policy(self) -> str:
        """Return the domain policy text (also used as the assistant system prompt)."""

    @abstractmethod
    def load_tools(self) -> Dict[str, Any]:
        """Return tool signatures (assistant + user side), keyed by tool name."""

    @abstractmethod
    def load_examples(self) -> List[Dict[str, Any]]:
        """Return a few-shot pool of reference tasks for the generator prompt."""

    @abstractmethod
    def sample_db_snippets(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Return concrete DB records (entities) relevant to this blueprint."""

    # ----------------------------------------------------- blueprint -> intent
    @abstractmethod
    def infer_environment_requirements(self, blueprint: TaskBlueprint) -> List[str]:
        """Derive environment_requirement list from family/skill/difficulty."""

    @abstractmethod
    def build_generation_context(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Assemble everything the Generator needs: schema, policy summary, tools,
        few-shots, db snippets, env requirements, intent."""

    # --------------------------------------------------------- task hard checks
    @abstractmethod
    def check_entities_exist(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Verify referenced entities (ids) exist. Return (ok, reasons)."""

    @abstractmethod
    def check_initial_state(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Verify the task's initial_state can be loaded into a fresh env."""

    @abstractmethod
    def check_evaluator_callable(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Verify the evaluation_criteria can be evaluated (assertions resolve)."""

    @abstractmethod
    def check_not_solved_at_init(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Verify the task is NOT already satisfied right after initialization."""

    @abstractmethod
    def check_tools_exist(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Verify every gt_action / evaluation action names a real tool."""

    @abstractmethod
    def check_tool_args(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Best-effort check that tool arguments match the tool schema."""

    def check_gt_nontrivial(
        self, task_candidate: TaskCandidate
    ) -> Tuple[bool, List[str]]:
        """Default: accept. Domains that allow agent-authored gt override this to
        reject degenerate (empty / read-only) solutions. Rule-only, no LLM."""
        return True, []

    # ----------------------------------------------------------------- replay
    @abstractmethod
    def replay_gt_actions(
        self, task_candidate: TaskCandidate, gt_actions: List[GTAction]
    ) -> Dict[str, Any]:
        """Execute gt_actions against a fresh env initialized from the task, then
        evaluate. Return a dict with at least::

            {"success": bool, "final_reward": float,
             "replay_log": [...], "failure_reasons": [...]}
        """

    # ---------------------------------------------------- filter/coverage hooks
    @abstractmethod
    def compute_difficulty(self, task_candidate: TaskCandidate) -> str:
        """Derive an observed difficulty label from the concrete task."""

    @abstractmethod
    def compute_coverage_keys(self, task_candidate: TaskCandidate) -> Dict[str, str]:
        """Return coverage dimensions, e.g. {family, skill, difficulty, cell}."""

    @abstractmethod
    def dedup_signature(self, task_candidate: TaskCandidate) -> str:
        """Stable signature used for exact-duplicate detection."""

    @abstractmethod
    def entity_signature(self, task_candidate: TaskCandidate) -> str:
        """Signature over (entities + fault shape) for near-duplicate detection."""
