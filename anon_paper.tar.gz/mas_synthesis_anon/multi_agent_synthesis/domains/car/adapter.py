"""CarBenchAdapter: bridge the car-bench voice-assistant benchmark into the
pipeline synthesis framework.

Unlike telecom/retail/airline (which subclass ``Tau2BaseAdapter`` and reuse the
tau2 Environment machinery), car-bench is a SEPARATE repo with a completely
different env model:

  * State does NOT live on an env object -- it lives in three process-level
    ``contextvars`` (``context_state`` = mutable vehicle state, ``fixed_context``
    = battery/location/time/prefs, ``task_config`` = calendar id). Every task
    must ``.set()`` a fresh ContextState/FixedContext/TaskConfig, populate them
    from the task's ``context_init_config`` dict, and ``.reset()`` afterwards.
  * There are 57 tool CLASSES (``ALL_TOOLS``), each with ``.get_info()`` (an
    OpenAI-style schema) and ``.invoke(data, **kwargs)`` (mutates the contextvar).
  * Reward is car-bench's own deterministic 6-dimension self-verify
    (``calculate_state_based_reward`` + ``calculate_tool_subset_reward`` + ...),
    NOT tau2's DB-hash / env-assertion evaluator.

So this adapter subclasses :class:`DomainAdapter` DIRECTLY and reimplements every
env-mechanic against car-bench's own primitives. The pipeline stays byte-for-byte
unchanged: we present car's env behind the exact surface the shared code probes
(``make_environment().tools.db.model_json_schema()`` / ``.get_tools()`` /
``get_policy()``), and we run the acceptance gate (``replay_gt_actions`` ->
``success and final_reward>=1.0``) via car's own self-verify reward decision.

CROSS-VERSION NOTE: car-bench may be installed in a separate virtualenv than the
pipeline. The deterministic reward path imports no LLM dependencies, so importing
car-bench's env/reward modules from the pipeline interpreter works regardless. We
add the car repo root to ``sys.path`` lazily.

CONTEXT-INIT SMUGGLE: the synthesis generator emits a tau2-shaped task body and
preserves only ``initial_state.initialization_actions`` (a list of
``{func_name, arguments}`` dicts). car needs a 40-key ``context_init_config`` +
calendar_id + task_type to reconstruct its initial vehicle state. We carry all of
that inside ONE sentinel init action::

    {"func_name": "__car_context_init__", "arguments": {"car_task": {...}}}

where ``car_task`` is the car ``Task`` minus its ``actions`` (actions come from
``gt_actions``). ``make_faulted_env`` and ``replay_gt_actions`` both parse this
sentinel; if it is absent we fall back to a default ContextState (empty scenario).
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

from .. import register_adapter
from ...schemas import GTAction, TaskBlueprint, TaskCandidate
from ..base import DomainAdapter

# --------------------------------------------------------------------------- paths
# The car-bench repo root that must be on sys.path (contains the `car_bench` pkg).
# It is an external dependency; point CAR_BENCH_SRC at a local checkout.
_CAR_REPO_ROOT = os.environ.get("CAR_BENCH_SRC", "/path/to/car_bench")
_CAR_REF_TASKS = os.path.join(_CAR_REPO_ROOT, "docs", "reference_data", "tasks")

_SENTINEL_FUNC = "__car_context_init__"


def _ensure_car_importable() -> None:
    """Put the car-bench repo root on sys.path so ``import car_bench.*`` works
    from the pipeline's (py3.13) interpreter. Idempotent."""
    if _CAR_REPO_ROOT not in sys.path:
        sys.path.insert(0, _CAR_REPO_ROOT)
    if _CAR_REF_TASKS not in sys.path:
        # reference TASKS modules (tasks_base.py, ...) live here as top-level mods.
        sys.path.insert(0, _CAR_REF_TASKS)


# =========================================================================== shims
class _ToolTypeShim:
    """Mimics tau2's ``ToolType`` enum member -- only ``.value`` is read by
    ``_tool_specs`` (via ``get_tool_types``)."""

    __slots__ = ("value",)

    def __init__(self, value: str):
        self.value = value


class _CarToolObj:
    """Wraps a car tool CLASS so it looks like a tau2 tool object to the shared
    introspector: exposes ``.name`` and ``.openai_schema`` (car's ``get_info()``
    is already OpenAI-style: ``{"type":"function","function":{...}}``)."""

    __slots__ = ("name", "openai_schema", "_cls")

    def __init__(self, cls):
        info = cls.get_info()
        self.name = info["function"]["name"]
        self.openai_schema = info
        self._cls = cls


class _CarDBShim:
    """Stands in for a tau2 ``db`` pydantic model. car has no relational DB (state
    is contextvars), so we expose an EMPTY table/enum surface. The shared
    ``_introspect_tables`` iterates ``model_json_schema()['properties']`` and skips
    any entry without an item ``$ref`` -> yields ``tables={}``, which is correct:
    car's real surface is its tool catalog, not tables. ``model_dump()`` (used by
    the entity sampler) returns ``{}`` -> no seed entity ids (car explore does not
    need them; there is a single vehicle)."""

    def model_json_schema(self) -> Dict[str, Any]:
        return {"type": "object", "properties": {}, "$defs": {}}

    def model_dump(self) -> Dict[str, Any]:
        return {}


class _CarToolKitShim:
    """Stands in for a tau2 assistant ``ToolKit``. Provides exactly what the
    shared code touches: ``.db``, ``.get_tools()`` (name -> tool obj), and
    ``.tool_type(name)`` (-> ``_ToolTypeShim``)."""

    def __init__(self, tool_objs: List[_CarToolObj], type_map: Dict[str, str]):
        self.db = _CarDBShim()
        self._objs = {t.name: t for t in tool_objs}
        self._types = type_map

    def get_tools(self) -> Dict[str, _CarToolObj]:
        return dict(self._objs)

    def tool_type(self, name: str) -> _ToolTypeShim:
        return _ToolTypeShim(self._types.get(name, "read"))


class _CarEnvShim:
    """Presents car-bench behind the tau2 ``Environment`` surface the pipeline
    probes: ``.tools`` (toolkit shim), ``.get_tools()`` (list of tool objs),
    ``.get_user_tools()`` / ``.user_tools`` (car has none), ``.get_policy()``.

    This shim is READ-ONLY w.r.t. env introspection. Live action execution (for
    the explore agent) goes through the adapter's ``exec_action``, which drives
    car's real ``tools_map[name].invoke`` against the process contextvars."""

    def __init__(self, adapter: "CarBenchAdapter"):
        self._adapter = adapter
        self.tools = _CarToolKitShim(adapter._tool_objs(), adapter._tool_type_map())
        self.user_tools = None

    def get_tools(self) -> List[_CarToolObj]:
        return list(self.tools.get_tools().values())

    def get_user_tools(self) -> List[Any]:
        return []

    def get_policy(self) -> str:
        return self._adapter.load_policy()


# ========================================================================== adapter
@register_adapter("car")
class CarBenchAdapter(DomainAdapter):
    """car-bench domain adapter (subclasses DomainAdapter directly)."""

    domain: str = "car"

    def __init__(self, config_path: Optional[str] = None):
        _ensure_car_importable()
        # Lazily-populated caches.
        self._all_tools = None            # list of car tool CLASSES
        self._tools_map = None            # name -> car tool CLASS (for invoke)
        self._tool_objs_cache: Optional[List[_CarToolObj]] = None
        self._type_map_cache: Optional[Dict[str, str]] = None
        self._policy_text: Optional[str] = None
        self._examples_cache: Optional[List[Dict[str, Any]]] = None
        self._offline_base_tasks = None
        self._tool_names_cache: Optional[set] = None

    # --------------------------------------------------------------- car imports
    def _car(self):
        """Import car-bench pieces (lazy; cached on the module)."""
        _ensure_car_importable()
        from car_bench.envs.car_voice_assistant.tools import ALL_TOOLS  # noqa
        return ALL_TOOLS

    def _tool_classes(self):
        if self._all_tools is None:
            self._all_tools = list(self._car())
            self._tools_map = {
                c.get_info()["function"]["name"]: c for c in self._all_tools
            }
        return self._all_tools

    def _tool_objs(self) -> List[_CarToolObj]:
        if self._tool_objs_cache is None:
            self._tool_objs_cache = [_CarToolObj(c) for c in self._tool_classes()]
        return self._tool_objs_cache

    def _tool_type_map(self) -> Dict[str, str]:
        """Classify every tool as read / write / generic from car's group lists."""
        if self._type_map_cache is not None:
            return self._type_map_cache
        _ensure_car_importable()
        import car_bench.envs.car_voice_assistant.tools as T

        def names(const: str) -> List[str]:
            return [c.get_info()["function"]["name"] for c in getattr(T, const, [])]

        write = set(names("SET_VEHICLE_STATE_TOOLS")) | set(
            names("SET_NAVIGATION_TOOLS")
        ) | set(names("SET_PRODUCTIVITY_AND_COMMUNICATION_TOOLS"))
        generic = set(names("CROSS_DOMAIN_TOOLS"))  # think/calculate/planning
        out: Dict[str, str] = {}
        for c in self._tool_classes():
            n = c.get_info()["function"]["name"]
            out[n] = "write" if n in write else ("generic" if n in generic else "read")
        self._type_map_cache = out
        return out

    def _tool_names(self) -> set:
        if self._tool_names_cache is None:
            self._tool_names_cache = {
                c.get_info()["function"]["name"] for c in self._tool_classes()
            }
        return self._tool_names_cache

    def _user_action_names(self) -> set:
        _ensure_car_importable()
        from car_bench.types import USER_AS_A_TOOL_ACTION_NAMES

        return set(USER_AS_A_TOOL_ACTION_NAMES)

    def _offline_base(self):
        """Real car-bench base tasks (native pydantic) for few-shots + grounding."""
        if self._offline_base_tasks is None:
            _ensure_car_importable()
            try:
                import tasks_base  # top-level module under _CAR_REF_TASKS

                self._offline_base_tasks = list(tasks_base.TASKS)
            except Exception:
                self._offline_base_tasks = []
        return self._offline_base_tasks

    # =====================================================================
    # env surface (shims)
    # =====================================================================
    def make_environment(self, solo_mode: bool = False) -> _CarEnvShim:
        """A read-only env shim exposing the tau2 surface the pipeline probes."""
        return _CarEnvShim(self)

    # =====================================================================
    # static context
    # =====================================================================
    def load_schema(self) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "tools": sorted(self._tool_names()),
            "tool_types": self._tool_type_map(),
            "user_action_names": sorted(self._user_action_names()),
        }

    def load_policy(self) -> str:
        """The car voice-assistant policy (wiki.md)."""
        if self._policy_text is None:
            wiki = os.path.join(
                _CAR_REPO_ROOT,
                "car_bench",
                "envs",
                "car_voice_assistant",
                "wiki.md",
            )
            try:
                with open(wiki, "r") as f:
                    self._policy_text = f.read()
            except Exception:
                self._policy_text = ""
        return self._policy_text

    def load_tools(self) -> Dict[str, Any]:
        """Tool signatures keyed by name: ``{actor, schema}`` (OpenAI schema)."""
        types = self._tool_type_map()
        out: Dict[str, Any] = {}
        for obj in self._tool_objs():
            out[obj.name] = {
                "actor": "assistant",
                "tool_type": types.get(obj.name, "read"),
                "schema": obj.openai_schema,
            }
        return out

    def load_examples(self) -> List[Dict[str, Any]]:
        """A few real base tasks as reference shots (instruction + gt + init)."""
        if self._examples_cache is not None:
            return self._examples_cache
        examples: List[Dict[str, Any]] = []
        for t in self._offline_base()[:6]:
            examples.append(
                {
                    "id": t.task_id,
                    "instruction": t.instruction,
                    "persona": t.persona,
                    "task_type": str(getattr(t.task_type, "value", t.task_type)),
                    "gt_actions": [
                        {"name": a.name, "arguments": dict(a.kwargs)} for a in t.actions
                    ],
                    "context_init_config": dict(t.context_init_config),
                    "calendar_id": t.calendar_id,
                }
            )
        self._examples_cache = examples
        return examples

    def sample_db_snippets(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """car has a single vehicle (no entity rows). Surface a few REAL base
        ``context_init_config`` dicts so the generator can ground its initial
        vehicle state in a plausible starting configuration (rotated by bp id)."""
        base = self._offline_base()
        configs = [dict(t.context_init_config) for t in base[:8]]
        target = None
        if base:
            seed = int(
                hashlib.sha256((blueprint.blueprint_id or "").encode()).hexdigest(), 16
            )
            t = base[seed % len(base)]
            target = {
                "context_init_config": dict(t.context_init_config),
                "calendar_id": t.calendar_id,
            }
        return {"sample_context_init_configs": configs, "target_init": target}

    # =====================================================================
    # blueprint -> intent
    # =====================================================================
    def infer_environment_requirements(self, blueprint: TaskBlueprint) -> List[str]:
        reqs: List[str] = ["single_vehicle_context"]
        plan = blueprint.dimension_plan or {}
        sd = plan.get("selected_dimensions", {}) if isinstance(plan, dict) else {}

        def _val(key: str) -> str:
            v = sd.get(key)
            if isinstance(v, list):
                return str(v[0]) if v else ""
            return str(v or "")

        nature = _val("task_nature")
        if nature.startswith("hallucination"):
            reqs.append(f"capability_removed:{nature}")
        elif nature.startswith("disambiguation"):
            reqs.append(f"ambiguity:{nature}")
        beh = _val("expected_behavior")
        if beh:
            reqs.append(f"expected_behavior:{beh}")
        return reqs

    def build_generation_context(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "blueprint": blueprint.model_dump(),
            "task_family": blueprint.task_family,
            "difficulty_level": blueprint.difficulty_level,
            "environment_requirement": blueprint.environment_requirement
            or self.infer_environment_requirements(blueprint),
            "policy": self.load_policy(),
            "tools": self.load_tools(),
            "db_snippets": self.sample_db_snippets(blueprint),
            "examples": self.load_examples(),
        }

    # =====================================================================
    # car task reconstruction (from the tau2-shaped candidate)
    # =====================================================================
    def _extract_car_task_fields(self, candidate: TaskCandidate) -> Dict[str, Any]:
        """Pull the smuggled car Task fields out of the sentinel init action.

        Returns a dict with keys: context_init_config, calendar_id, task_type,
        disambiguation_element_*, removed_part. Missing sentinel -> sensible
        defaults (empty scenario, BASE task)."""
        init = (candidate.task or {}).get("initial_state") or {}
        for a in init.get("initialization_actions") or []:
            if (a or {}).get("func_name") == _SENTINEL_FUNC:
                args = (a or {}).get("arguments") or {}
                ct = args.get("car_task") or args
                return {
                    "context_init_config": dict(ct.get("context_init_config") or {}),
                    "calendar_id": str(ct.get("calendar_id") or ""),
                    "task_type": str(ct.get("task_type") or "base"),
                    "disambiguation_element_internal": ct.get(
                        "disambiguation_element_internal"
                    ),
                    "disambiguation_element_user": ct.get(
                        "disambiguation_element_user"
                    ),
                    "disambiguation_element_note": ct.get(
                        "disambiguation_element_note"
                    ),
                    "removed_part": ct.get("removed_part"),
                }
        return {
            "context_init_config": {},
            "calendar_id": "",
            "task_type": "base",
            "disambiguation_element_internal": None,
            "disambiguation_element_user": None,
            "disambiguation_element_note": None,
            "removed_part": None,
        }

    def _build_car_task(self, candidate: TaskCandidate, gt_actions: List[GTAction]):
        """Reconstruct a car-bench ``Task`` from the candidate + gt_actions."""
        _ensure_car_importable()
        from car_bench.types import Action as CarAction, Task as CarTask, TaskType

        f = self._extract_car_task_fields(candidate)
        actions = [
            CarAction(name=a.name, kwargs=dict(a.arguments), index=i)
            for i, a in enumerate(gt_actions)
        ]
        try:
            tt = TaskType(f["task_type"])
        except Exception:
            tt = TaskType.BASE
        instr = (
            (candidate.task or {}).get("ticket")
            or (((candidate.task or {}).get("user_scenario") or {}).get("instructions") or {}).get(
                "reason_for_call"
            )
            or ""
        )
        return CarTask(
            task_id=candidate.task_id,
            calendar_id=f["calendar_id"],
            actions=actions,
            persona="",
            instruction=str(instr),
            context_init_config=f["context_init_config"],
            task_type=tt,
            disambiguation_element_internal=f["disambiguation_element_internal"],
            disambiguation_element_user=f["disambiguation_element_user"],
            disambiguation_element_note=f["disambiguation_element_note"],
            removed_part=f["removed_part"],
        )

    # =====================================================================
    # content hard checks
    # =====================================================================
    def check_entities_exist(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        # car has a single vehicle context; no cross-entity ids to validate.
        return True, []

    def check_tools_exist(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        valid = self._tool_names() | self._user_action_names()
        reasons: List[str] = []
        for a in task_candidate.effective_gt_actions():
            if a.name not in valid:
                reasons.append(f"unknown tool '{a.name}' (gt_action)")
        return (len(reasons) == 0), reasons

    def check_tool_args(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        tools = self.load_tools()
        user_actions = self._user_action_names()
        reasons: List[str] = []
        for a in task_candidate.effective_gt_actions():
            if a.name in user_actions:
                continue  # pseudo-actions have no fixed schema
            spec = tools.get(a.name)
            if spec is None:
                continue  # existence handled elsewhere
            params = (
                spec.get("schema", {}).get("function", {}).get("parameters", {})
            )
            props = set((params.get("properties") or {}).keys())
            required = set(params.get("required") or [])
            given = set((a.arguments or {}).keys())
            missing = required - given
            unknown = given - props
            if missing:
                reasons.append(f"{a.name}: missing required args {sorted(missing)}")
            if unknown:
                reasons.append(f"{a.name}: unknown args {sorted(unknown)}")
        return (len(reasons) == 0), reasons

    def check_initial_state(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """The task's ``context_init_config`` must load into fresh car contexts."""
        try:
            self._set_car_context(
                self._extract_car_task_fields(task_candidate)
            )
        except Exception as e:
            return False, [f"initial_state_not_loadable: {e}"]
        finally:
            self._reset_car_context()
        return True, []

    def check_evaluator_callable(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """The gt actions must reconstruct into a valid car Task."""
        try:
            self._build_car_task(
                task_candidate, task_candidate.effective_gt_actions()
            )
        except Exception as e:
            return False, [f"car_task_build_error: {e}"]
        return True, []

    def check_not_solved_at_init(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """A fulfill task must actually change vehicle state (otherwise the agent
        has nothing to do). Decline/clarify tasks are exempt (their correct
        behavior is a user-facing message, not a state change)."""
        gt = task_candidate.effective_gt_actions()
        beh = self._expected_behavior(task_candidate)
        if beh in ("decline_infeasible", "clarify_with_user"):
            return True, []
        types = self._tool_type_map()
        has_write = any(types.get(a.name) == "write" for a in gt)
        if not has_write:
            return False, ["fulfill task has no state-changing (write) action"]
        return True, []

    def check_gt_nontrivial(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        gt = task_candidate.effective_gt_actions()
        if not gt:
            return False, ["empty gt_actions"]
        beh = self._expected_behavior(task_candidate)
        types = self._tool_type_map()
        user_actions = self._user_action_names()
        writes = [a for a in gt if types.get(a.name) == "write"]
        if beh in ("decline_infeasible", "clarify_with_user"):
            # correct behavior = talk to the user, do NOT mutate vehicle state.
            if writes:
                return False, [
                    f"{beh} task must not call state-changing tools "
                    f"(found {[a.name for a in writes]})"
                ]
            if not any(a.name in user_actions for a in gt):
                return False, [f"{beh} task must include a user-facing action"]
            return True, []
        # fulfill / resolve_from_preferences: must change state.
        if not writes:
            return False, ["gt has no state-changing action (all read-only)"]
        return True, []

    def _expected_behavior(self, candidate: TaskCandidate) -> str:
        plan = candidate.blueprint.dimension_plan or {}
        sd = plan.get("selected_dimensions", {}) if isinstance(plan, dict) else {}
        v = sd.get("expected_behavior")
        if isinstance(v, list):
            return str(v[0]) if v else "fulfill_reach_goal"
        return str(v or "fulfill_reach_goal")

    # =====================================================================
    # replay + reward (car self-verify)
    # =====================================================================
    def _set_car_context(self, fields: Dict[str, Any]):
        """Set fresh car contextvars from the task fields. Stores reset tokens on
        the instance so ``_reset_car_context`` can restore them."""
        _ensure_car_importable()
        from car_bench.envs.car_voice_assistant.context.dynamic_context_state import (
            ContextState,
            context_state,
        )
        from car_bench.envs.car_voice_assistant.context.fixed_context import (
            FixedContext,
            fixed_context,
        )
        from car_bench.envs.car_voice_assistant.tasks.task_config import (
            TaskConfig,
            task_config,
        )

        cic = fields.get("context_init_config") or {}
        self._tok_tc = task_config.set(TaskConfig())
        task_config.get().update_state(calendar_id=fields.get("calendar_id") or "")
        self._tok_ctx = context_state.set(ContextState())
        self._tok_fx = fixed_context.set(FixedContext())
        # A context_init_config carries BOTH fixed (car_color/battery/...) and
        # dynamic (window/sunroof/...) keys; feed both -- ContextState/FixedContext
        # silently ignore keys they don't own.
        fixed_context.get().update_state(**cic)
        context_state.get().update_state(**cic)

    def _reset_car_context(self):
        _ensure_car_importable()
        from car_bench.envs.car_voice_assistant.context.dynamic_context_state import (
            context_state,
        )
        from car_bench.envs.car_voice_assistant.context.fixed_context import (
            fixed_context,
        )
        from car_bench.envs.car_voice_assistant.tasks.task_config import task_config

        for var, tok in (
            (context_state, getattr(self, "_tok_ctx", None)),
            (fixed_context, getattr(self, "_tok_fx", None)),
            (task_config, getattr(self, "_tok_tc", None)),
        ):
            if tok is not None:
                try:
                    var.reset(tok)
                except Exception:
                    pass

    def replay_gt_actions(
        self, task_candidate: TaskCandidate, gt_actions: List[GTAction]
    ) -> Dict[str, Any]:
        """Reconstruct the car task, replay gt_actions as the agent trajectory,
        and run car-bench's deterministic self-verify. Accept iff reward==1.0.

        Returns ``{success, final_reward, replay_log, failure_reasons}`` (the
        DomainAdapter contract). No LLM, no HF network for vehicle-control tasks."""
        _ensure_car_importable()
        replay_log: List[Dict[str, Any]] = []
        reasons: List[str] = []

        try:
            from car_bench.envs.base import to_hashable, consistent_hash
            from car_bench.envs.reward_calculators import (
                calculate_state_based_reward,
                calculate_tool_subset_reward,
                tool_execution_errors_during_runtime,
            )
            from car_bench.envs.car_voice_assistant.context.dynamic_context_state import (
                context_state,
            )
            from car_bench.types import USER_AS_A_TOOL_ACTION_NAMES
        except Exception as e:
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": [f"car_import_error: {e}"],
            }

        try:
            car_task = self._build_car_task(task_candidate, gt_actions)
        except Exception as e:
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": [f"car_task_build_error: {e}"],
            }

        self._tool_classes()  # populate _tools_map
        tools_map = self._tools_map
        user_actions = set(USER_AS_A_TOOL_ACTION_NAMES)

        def ghash(cs):
            return consistent_hash(to_hashable(cs))

        def step_fn(action, messages):
            if action.name in tools_map:
                tools_map[action.name].invoke(data={}, **action.kwargs)

        # (the three runtime-error contextvars are set below via
        # _set_error_contextvars before scoring, else the reward path LookupErrors.)
        fields = self._extract_car_task_fields(task_candidate)
        try:
            self._set_car_context(fields)
        except Exception as e:
            self._reset_car_context()
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": [f"init_state_error: {e}"],
            }

        try:
            self._set_error_contextvars()
            # Replay gt as the agent trajectory; record hashes after each tool
            # action (mirrors car-bench's GT hash-recording timing exactly).
            agent_hashes = [ghash(context_state.get())]
            performed = []
            for i, a in enumerate(car_task.actions):
                if a.name in user_actions:
                    performed.append(a)
                    replay_log.append({"step": i, "name": a.name, "status": "user"})
                    continue
                if a.name not in tools_map:
                    reasons.append(f"step {i} {a.name}: not a car tool")
                    replay_log.append({"step": i, "name": a.name, "status": "error"})
                    break
                try:
                    tools_map[a.name].invoke(data={}, **a.kwargs)
                    performed.append(a)
                    agent_hashes.append(ghash(context_state.get()))
                    replay_log.append({"step": i, "name": a.name, "status": "ok"})
                except Exception as e:
                    reasons.append(f"step {i} {a.name}: {e}")
                    replay_log.append(
                        {"step": i, "name": a.name, "status": "crash",
                         "error": str(e)[:300]}
                    )
                    break

            # Tool-execution gate (aligns synthesis self-verify with rollout /
            # official eval, which run with score_tool_execution_errors=True).
            # car tools do NOT raise on a bad argument (e.g. an invalid enum such
            # as seat_zone="driver" vs the required "DRIVER"); they return a
            # {"status":"FAILURE","errors":...} JSON AND append the message to the
            # tool_execution_errors_during_runtime contextvar, then skip their
            # state update. Without this check such a GT scores reward==1 here
            # (both GT-replay sides no-op the state, hashes match; tool_subset
            # only checks tool *names*) yet ALWAYS scores 0 at rollout time
            # (r_tool_execution=0) -> the task is un-solvable and pollutes the
            # accepted set. Reject any GT whose own replay raised a tool error.
            texec_errors = list(tool_execution_errors_during_runtime.get() or [])
            if texec_errors:
                for msg in texec_errors:
                    reasons.append(f"gt_replay tool_execution_error: {msg}")
                return {
                    "success": False,
                    "final_reward": 0.0,
                    "replay_log": replay_log,
                    "failure_reasons": reasons,
                }

            if reasons:
                return {
                    "success": False,
                    "final_reward": 0.0,
                    "replay_log": replay_log,
                    "failure_reasons": reasons,
                }

            reward, dims = self._score_car(
                car_task, agent_hashes, performed, ghash, step_fn, tools_map,
                calculate_state_based_reward, calculate_tool_subset_reward,
            )
            success = reward >= 1.0
            if not success:
                reasons.append(f"car self-verify reward={reward} (<1.0); dims={dims}")
            return {
                "success": success,
                "final_reward": float(reward),
                "replay_log": replay_log,
                "failure_reasons": reasons,
                "reward_dims": dims,
            }
        except Exception as e:
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": reasons + [f"replay_error: {e}"],
            }
        finally:
            self._reset_car_context()

    def _set_error_contextvars(self):
        """car's reward reads three runtime-error contextvars; set them to [] so
        pure replay does not hit LookupError."""
        _ensure_car_importable()
        from car_bench.envs.reward_calculators import (
            tool_execution_errors_during_runtime,
            policy_errors_during_runtime,
            end_conversation_failure,
        )

        tool_execution_errors_during_runtime.set([])
        policy_errors_during_runtime.set([])
        end_conversation_failure.set([])

    def _score_car(
        self, car_task, agent_hashes, performed, ghash, step_fn, tools_map,
        calc_state, calc_subset,
    ) -> Tuple[float, Dict[str, Any]]:
        """Aggregate car's deterministic reward dimensions -> reward in [0,1].

        base / disambiguation: reward = max(0, 1 + delta_state + delta_subset)
          (state_final + state_intermediate + tool_subset all deterministic).
        hallucination: state/subset are skipped by car (return None); the correct
          behavior is a user-facing decline with NO state change -- we already
          enforce that in check_gt_nontrivial, so a clean replay = pass."""
        # state-based (final + intermediate)
        rf, ri, ra, dstate = calc_state(
            car_task, agent_hashes, ghash, step_fn, tools_map, []
        )
        # tool-subset
        ts, miss, dsub = calc_subset(car_task, performed)

        dims = {
            "r_actions_final": rf,
            "r_actions_intermediate": ri,
            "r_tool_subset": ts,
            "tool_subset_missing": miss,
        }
        # If state-based returned None (hallucination task type), car skips those
        # dimensions; a clean replay of a decline (enforced upstream) is a pass.
        if rf is None and ts is None:
            return 1.0, dims
        reward = 1.0 + float(dstate or 0.0) + float(dsub or 0.0)
        return max(0.0, reward), dims

    # =====================================================================
    # explore primitives (used by ExploreSynthesisAgent)
    # =====================================================================
    def make_faulted_env(self, init_actions: List[Dict[str, Any]]):
        """Set up a fresh car context (from a sentinel init action if present) and
        return a lightweight env handle the explore agent drives via exec_action.

        NOTE: car state is process-global contextvars; each call re-sets them, so
        exploration of candidate N does not leak into N+1 (values are overwritten,
        not stacked)."""
        fields = {
            "context_init_config": {},
            "calendar_id": "",
            "task_type": "base",
        }
        for a in init_actions or []:
            if (a or {}).get("func_name") == _SENTINEL_FUNC:
                args = (a or {}).get("arguments") or {}
                ct = args.get("car_task") or args
                fields["context_init_config"] = dict(ct.get("context_init_config") or {})
                fields["calendar_id"] = str(ct.get("calendar_id") or "")
                fields["task_type"] = str(ct.get("task_type") or "base")
                break
        self._set_car_context(fields)
        return _CarEnvShim(self)

    def exec_action(
        self,
        env,
        actor: str,
        name: str,
        arguments: Dict[str, Any],
        idx: int,
        max_content_chars: int = 500,
    ) -> Dict[str, Any]:
        """Execute ONE tool against the live car context (mutates contextvars) and
        return a flat observation. Mirrors Tau2BaseAdapter.exec_action's shape."""
        self._tool_classes()
        tools_map = self._tools_map
        if name not in tools_map:
            return {"status": "error", "content": f"unknown tool '{name}'"}
        try:
            result = tools_map[name].invoke(data={}, **(arguments or {}))
            content = result if isinstance(result, str) else json.dumps(result, default=str)
            # car tools signal failure via a JSON {"status":"FAILURE",...} string.
            status = "ok"
            if isinstance(content, str) and '"status": "FAILURE"' in content:
                status = "error"
            return {"status": status, "content": content[:max_content_chars]}
        except Exception as e:
            return {"status": "crash", "content": str(e)[:max_content_chars]}

    # =====================================================================
    # filter / coverage hooks
    # =====================================================================
    def compute_difficulty(self, task_candidate: TaskCandidate) -> str:
        gt = task_candidate.effective_gt_actions()
        types = self._tool_type_map()
        n_write = sum(1 for a in gt if types.get(a.name) == "write")
        n = len(gt)
        if n <= 2 and n_write <= 1:
            return "easy"
        if n <= 5 and n_write <= 3:
            return "medium"
        return "hard"

    def _dims(self, candidate: TaskCandidate) -> Dict[str, str]:
        plan = candidate.blueprint.dimension_plan or {}
        sd = plan.get("selected_dimensions", {}) if isinstance(plan, dict) else {}

        def one(k: str, default: str = "") -> str:
            v = sd.get(k)
            if isinstance(v, list):
                return str(v[0]) if v else default
            return str(v or default)

        return {
            "task_family": one("task_family", candidate.blueprint.task_family),
            "task_nature": one("task_nature", "base_execute"),
            "expected_behavior": one("expected_behavior", "fulfill_reach_goal"),
            "difficulty_profile": one(
                "difficulty_profile", candidate.blueprint.difficulty_level
            ),
        }

    def compute_coverage_keys(self, task_candidate: TaskCandidate) -> Dict[str, str]:
        d = self._dims(task_candidate)
        cell = f"{d['task_family']}|{d['task_nature']}|{d['difficulty_profile']}"
        return {
            "task_family": d["task_family"],
            "task_nature": d["task_nature"],
            "difficulty_level": d["difficulty_profile"],
            "cell": cell,
        }

    def dedup_signature(self, task_candidate: TaskCandidate) -> str:
        acts = [
            (a.actor, a.name, json.dumps(a.arguments, sort_keys=True, default=str))
            for a in task_candidate.effective_gt_actions()
        ]
        f = self._extract_car_task_fields(task_candidate)
        payload = {
            "acts": acts,
            "context_init_config": json.dumps(
                f.get("context_init_config") or {}, sort_keys=True, default=str
            ),
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()

    def entity_signature(self, task_candidate: TaskCandidate) -> str:
        """Near-dup key: family + nature + the sorted multiset of gt tool names +
        the sorted set of touched state fields (from write-tool args). Two tasks
        that drive the same tools to the same fields are near-duplicates even if
        their NL text differs."""
        d = self._dims(task_candidate)
        gt = task_candidate.effective_gt_actions()
        tool_names = sorted(a.name for a in gt)
        arg_keys = sorted(
            {k for a in gt for k in (a.arguments or {}).keys()}
        )
        payload = {
            "family": d["task_family"],
            "nature": d["task_nature"],
            "tools": tool_names,
            "arg_keys": arg_keys,
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()
