"""car-bench domain adapter package."""
