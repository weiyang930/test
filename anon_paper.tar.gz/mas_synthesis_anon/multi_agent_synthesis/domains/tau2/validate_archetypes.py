"""Replay-validate the curated archetype catalog against the live tau2 env.

The archetype catalog (``configs/telecom_archetypes.yaml``) is the only
hand-authored part of the DomainCard. To make sure no archetype is a guess that
the env cannot actually realize, this module REPLAYS each archetype's
``replay_template`` (init_actions -> gt_actions) against a fresh telecom env and
checks the deterministic evaluator returns reward==1 (i.e. the fault is real and
the fix resolves it). Archetypes that fail are reported, not silently trusted.

This reuses the adapter's ``replay_gt_actions`` machinery (the same evaluator the
pipeline uses for generated tasks), so a passing archetype is guaranteed to be a
realizable coverage atom.

Run standalone:
    python -m multi_agent_synthesis.domains.tau2.validate_archetypes
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

from ...schemas import GTAction, TaskBlueprint, TaskCandidate
from .domain_card import load_archetypes
from .telecom_adapter import Tau2TelecomAdapter

_HERE = os.path.dirname(os.path.abspath(__file__))
_ARCHETYPES_YAML = os.path.join(_HERE, "configs", "telecom_archetypes.yaml")


def load_archetype_catalog(
    path: str = _ARCHETYPES_YAML, adapter: Any = None
) -> List[Dict[str, Any]]:
    """Load the catalog with entity placeholders bound to a live DB entity."""
    return load_archetypes(path=path, adapter=adapter)


def _build_candidate(arch: Dict[str, Any]) -> TaskCandidate:
    """Turn an archetype's replay_template into a TaskCandidate the adapter can
    replay. The template carries a real init_state + gt_actions + assertions."""
    tmpl = arch["replay_template"]
    init_actions = tmpl.get("init_actions") or []
    gt = [
        GTAction(actor=a["actor"], name=a["name"], arguments=a.get("arguments") or {})
        for a in tmpl.get("gt_actions") or []
    ]
    assertions = tmpl.get("assertions") or []

    task_body: Dict[str, Any] = {
        "id": f"archetype_{arch['id']}",
        "description": {"purpose": f"archetype validation: {arch['id']}"},
        "user_scenario": {
            "instructions": {
                "domain": "telecom",
                "reason_for_call": f"archetype validation: {arch['id']}",
                "task_instructions": "Follow the agent's troubleshooting steps.",
            }
        },
        "initial_state": {"initialization_actions": init_actions},
        "evaluation_criteria": {
            "actions": [
                {
                    "action_id": f"{a.name}_{i}",
                    "requestor": a.actor,
                    "name": a.name,
                    "arguments": dict(a.arguments),
                }
                for i, a in enumerate(gt)
            ],
            "env_assertions": assertions,
            "reward_basis": ["ENV_ASSERTION"] if assertions else ["ACTION"],
        },
    }

    bp = TaskBlueprint(
        blueprint_id=f"bp_archetype_{arch['id']}",
        domain="telecom",
        task_family=arch["intent_family"],
        target_skill_pattern=arch.get("fix_locus", "user_device"),
        difficulty_level="easy",
    )
    return TaskCandidate(
        candidate_id=f"arch_{arch['id']}",
        task_id=task_body["id"],
        blueprint=bp,
        task=task_body,
        gt_actions=gt,
        assertions=assertions,
    )


def validate_all(verbose: bool = True) -> Dict[str, Any]:
    """Replay every archetype; return a report. reward==1 means realizable."""
    adapter = Tau2TelecomAdapter()
    catalog = load_archetype_catalog(adapter=adapter)
    results: List[Dict[str, Any]] = []
    for arch in catalog:
        cand = _build_candidate(arch)
        rep = adapter.replay_gt_actions(cand, cand.gt_actions)
        is_escalation = arch.get("fix_locus") == "escalation"
        # Escalation tasks intentionally leave the env unresolved; reward comes
        # from the ACTION (transfer call), not env assertions. We only require
        # the replay to execute without error there.
        if is_escalation:
            ok = not any("error" in r.get("status", "") for r in rep["replay_log"]) and not [
                r for r in rep["replay_log"] if r.get("status") == "crash"
            ]
        else:
            ok = rep["success"] and rep["final_reward"] >= 1.0
        results.append(
            {
                "id": arch["id"],
                "intent_family": arch["intent_family"],
                "resolution_tool": arch.get("resolution_tool"),
                "fix_locus": arch.get("fix_locus"),
                "ok": ok,
                "reward": rep["final_reward"],
                "reasons": rep["failure_reasons"],
            }
        )
        if verbose:
            mark = "PASS" if ok else "FAIL"
            tool = arch.get("resolution_tool") or "(user-side)"
            print(
                f"[{mark}] {arch['id']:34s} reward={rep['final_reward']:.1f} "
                f"locus={arch.get('fix_locus'):14s} fix_tool={tool}"
            )
            if not ok:
                for r in rep["failure_reasons"]:
                    print(f"        reason: {r}")

    n_pass = sum(1 for r in results if r["ok"])
    report = {
        "n_archetypes": len(results),
        "n_pass": n_pass,
        "n_fail": len(results) - n_pass,
        "results": results,
    }
    if verbose:
        print(f"\n{n_pass}/{len(results)} archetypes validated (reward==1 / clean replay).")
    return report


if __name__ == "__main__":
    validate_all(verbose=True)
