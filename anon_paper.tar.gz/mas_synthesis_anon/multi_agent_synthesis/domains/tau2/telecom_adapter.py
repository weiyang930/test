"""Tau2TelecomAdapter: the concrete telecom domain adapter.

This is the only place the pipeline learns telecom-specific facts. It loads the
hand-curated domain knowledge (``configs/telecom_domain.yaml``) plus the live
tau2 telecom env (policy text + tool schemas), and implements the
generation-context + hard-check + coverage hooks the pipeline needs.

It subclasses :class:`Tau2BaseAdapter`, which already owns the tau2 env mechanics
(env construction, canonical<->tau2 action translation, replay + deterministic
evaluation, and the env-dependent hard checks: initial_state / evaluator /
not_solved_at_init). Here we add the *content* checks that only need the static
domain knowledge (entities, tool schemas) plus generation-context assembly.
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Tuple

import yaml

from .. import register_adapter
from ...schemas import GTAction, TaskBlueprint, TaskCandidate
from .base_adapter import Tau2BaseAdapter

_HERE = os.path.dirname(os.path.abspath(__file__))
_DOMAIN_CFG = os.path.join(_HERE, "configs", "telecom_domain.yaml")


@register_adapter("telecom")
class Tau2TelecomAdapter(Tau2BaseAdapter):
    """Telecom domain adapter for the synthesis pipeline."""

    domain: str = "telecom"

    def __init__(self, config_path: Optional[str] = None):
        super().__init__()
        self._cfg_path = config_path or _DOMAIN_CFG
        with open(self._cfg_path, "r") as f:
            self._cfg: Dict[str, Any] = yaml.safe_load(f)
        # Lazily-populated caches.
        self._policy_text: Optional[str] = None
        self._tools_cache: Optional[Dict[str, Any]] = None
        self._assert_names_cache: Optional[set] = None
        self._examples_cache: Optional[List[Dict[str, Any]]] = None
        # Live-DB entity records (for skeleton entity rotation), lazily built.
        self._live_entities_cache: Optional[List[Dict[str, Any]]] = None
        self._source_entity_cache: Optional[Dict[str, Any]] = None
        # archetype_id -> entities whose rebound skeleton still replays reward==1.
        self._valid_entities_cache: Dict[str, List[Dict[str, Any]]] = {}
        # customer_id -> record, for fast existence checks.
        self._customers: Dict[str, Dict[str, Any]] = {
            c["customer_id"]: c for c in self._cfg.get("entities", {}).get("customers", [])
        }
        # line_id -> customer_id
        self._lines: Dict[str, str] = {}
        for c in self._customers.values():
            for lid in c.get("line_ids", []) or []:
                self._lines[lid] = c["customer_id"]

    # =====================================================================
    # static context
    # =====================================================================
    def load_schema(self) -> Dict[str, Any]:
        """Tool + entity + task-family schema used to build generation context."""
        return {
            "domain": self.domain,
            "entities": self._cfg.get("entities", {}),
            "task_families": self._cfg.get("task_families", {}),
            "difficulty_fault_counts": self._cfg.get("difficulty_fault_counts", {}),
            "tools": list(self.load_tools().keys()),
        }

    def load_policy(self) -> str:
        """The telecom agent policy (manual). Read live from the tau2 env."""
        if self._policy_text is None:
            env = self.make_environment()
            self._policy_text = env.get_policy() or ""
        return self._policy_text

    def _assert_func_names(self) -> set:
        """Names of env assertion methods (resolved via getattr, not the tool
        registry) on the assistant + user toolkits."""
        if self._assert_names_cache is not None:
            return self._assert_names_cache
        env = self.make_environment()
        names: set = set()
        for kit in (getattr(env, "tools", None), getattr(env, "user_tools", None)):
            if kit is None:
                continue
            for attr in dir(kit):
                if attr.startswith("assert_") and callable(getattr(kit, attr)):
                    names.add(attr)
        self._assert_names_cache = names
        return names

    def load_tools(self) -> Dict[str, Any]:
        """Assistant + user tool signatures keyed by tool name.

        Each value is ``{actor, schema}`` where ``schema`` is the tool's
        openai-style function schema (name/description/parameters).
        """
        if self._tools_cache is not None:
            return self._tools_cache
        env = self.make_environment()
        out: Dict[str, Any] = {}
        for t in env.get_tools():
            out[t.name] = {"actor": "assistant", "schema": t.openai_schema}
        for t in env.get_user_tools() or []:
            # User tools include both side-effecting actions and assert_* funcs.
            out[t.name] = {"actor": "user", "schema": t.openai_schema}
        self._tools_cache = out
        return out

    def load_examples(self) -> List[Dict[str, Any]]:
        """Few-shot pool, derived from the VALIDATED archetype catalog.

        Task-set-free: each example is built from an archetype's replay_template
        (a real, reward==1 task skeleton) rather than read from any official task
        corpus. This keeps the generator's reference shots env-grounded and lets
        the method port to domains that have no benchmark tasks at all.
        """
        if self._examples_cache is not None:
            return self._examples_cache
        from .domain_card import load_archetypes

        examples: List[Dict[str, Any]] = []
        for arch in load_archetypes(adapter=self):
            tmpl = arch.get("replay_template") or {}
            init_actions = tmpl.get("init_actions") or []
            gt_actions = tmpl.get("gt_actions") or []
            assertions = tmpl.get("assertions") or []
            if not (init_actions and assertions):
                continue
            examples.append({
                "id": arch.get("id"),
                "ticket": arch.get("intent_family", ""),
                "initial_state": {"initialization_actions": init_actions},
                "evaluation_criteria": {
                    "actions": [
                        {
                            "action_id": f"{a.get('name')}_{i}",
                            "requestor": a.get("actor"),
                            "name": a.get("name"),
                            "arguments": a.get("arguments", {}),
                        }
                        for i, a in enumerate(gt_actions)
                    ],
                    "env_assertions": assertions,
                },
            })
        self._examples_cache = examples
        return examples

    def _active_target_lines(self) -> List[Dict[str, Any]]:
        """All Active lines on Active accounts, as flat target records.

        These are the only lines a user can authenticate against (set_user_info
        looks up by line phone number) AND act on for service/data/mms faults.
        Surfacing them as explicit targets lets the generator spread tasks across
        entities instead of fixating on a single line (the near-dup filter keys on
        entities+fault-shape, so spreading multiplies the unique-task space).
        """
        out: List[Dict[str, Any]] = []
        for c in self._customers.values():
            if c.get("account_status") != "Active":
                continue
            for ln in c.get("lines", []) or []:
                if ln.get("status") == "Active":
                    out.append({
                        "customer_id": c.get("customer_id"),
                        "full_name": c.get("full_name"),
                        "line_id": ln.get("line_id"),
                        "line_phone": ln.get("phone_number"),
                    })
        return out

    def sample_db_snippets(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Concrete DB records relevant to this blueprint.

        For telecom, tasks operate on a customer with at least one Active line.
        We surface the Active customers (with their lines) so the Generator can
        ground the scenario in a real entity, PLUS a deterministically-rotated
        ``target_line`` (by blueprint id) to push entity diversity.
        """
        active = [
            c for c in self._customers.values() if c.get("account_status") == "Active"
        ]
        targets = self._active_target_lines()
        target_line = None
        if targets:
            seed = int(
                hashlib.sha256((blueprint.blueprint_id or "").encode()).hexdigest(), 16
            )
            target_line = targets[seed % len(targets)]
        return {
            "active_customers": active,
            "all_customers": list(self._customers.values()),
            "target_line": target_line,
        }

    # =====================================================================
    # pinned skeleton + entity rotation (V1)
    # =====================================================================
    # The archetype's replay_template is a real, reward==1 skeleton but it is
    # bound to ONE live entity (pick_live_entity always returns the first Active
    # customer/line). If every same-archetype blueprint reused that single entity
    # the near-dup filter (keyed on entities + fault shape) would collapse the 42
    # Type-1 cells back to ~14 -- the exact V0 collapse. So entity selection is the
    # Generator's job (per the blueprint schema): we deterministically rotate over
    # all usable live entities by blueprint id, keeping the validated skeleton
    # structure intact while spreading tasks across distinct customers/lines.
    _SOURCE_TOKENS = ("{{customer_id}}", "{{line_id}}", "{{phone}}", "{{name}}",
                      "{{data_used_over_limit}}")

    def _live_entities(self) -> List[Dict[str, Any]]:
        """All usable (Active customer + Active line) records from the live env DB,
        each shaped like ``pick_live_entity`` (so token rebinding is uniform)."""
        if self._live_entities_cache is not None:
            return self._live_entities_cache
        db = self.make_environment().tools.db.model_dump()
        customers = db.get("customers") or []
        lines = db.get("lines") or []
        plans = {p.get("plan_id"): p for p in (db.get("plans") or [])}
        line_by_id = {l.get("line_id"): l for l in lines}
        out: List[Dict[str, Any]] = []
        for c in customers:
            if c.get("account_status") != "Active":
                continue
            for lid in c.get("line_ids") or []:
                ln = line_by_id.get(lid)
                if not (ln and ln.get("status") == "Active"):
                    continue
                limit = plans.get(ln.get("plan_id"), {}).get("data_limit_gb")
                out.append({
                    "customer_id": c.get("customer_id"),
                    "line_id": ln.get("line_id"),
                    "phone": ln.get("phone_number"),
                    "name": c.get("full_name") or c.get("name"),
                    # data_used that puts the line just over its plan limit, so a
                    # small refuel reliably clears the overage on ANY plan.
                    "data_used_over_limit": round((limit + 0.1), 1) if limit is not None else 15.1,
                })
        self._live_entities_cache = out
        return out

    def _source_entity(self) -> Dict[str, Any]:
        """The entity the catalog's replay_templates were bound to at load time
        (``pick_live_entity``). We invert that binding to rotate to a fresh one."""
        if self._source_entity_cache is None:
            from .domain_card import pick_live_entity

            self._source_entity_cache = pick_live_entity(self)
        return self._source_entity_cache

    def _replays_clean(self, blueprint: TaskBlueprint, dst: Dict[str, Any]) -> bool:
        """Rebind this blueprint's skeleton to entity ``dst`` and check it still
        replays to reward==1 (escalation: clean, error-free replay). This is the
        same gate the catalog itself passed -- we re-apply it per rotated entity so
        rotation can never silently break an entity-specific precondition (e.g.
        overdue_bill needs a customer who does NOT already have an overdue bill)."""
        tmpl = blueprint.replay_template or {}
        src = self._source_entity()
        rebound = self._rebind_to_entity(tmpl, src, dst)
        gt = [
            GTAction(
                actor=a["actor"], name=a["name"], arguments=a.get("arguments") or {}
            )
            for a in rebound.get("gt_actions") or []
        ]
        assertions = list(rebound.get("assertions") or [])
        task_body: Dict[str, Any] = {
            "id": f"poolcheck_{blueprint.archetype_id}",
            "description": {"purpose": "entity pool validation"},
            "user_scenario": {
                "instructions": {
                    "domain": "telecom",
                    "reason_for_call": "pool check",
                    "task_instructions": "Follow the agent's troubleshooting steps.",
                }
            },
            "initial_state": {
                "initialization_actions": rebound.get("init_actions") or []
            },
            "evaluation_criteria": {
                "actions": [
                    {
                        "action_id": f"{a.name}_{i}",
                        "requestor": a.actor,
                        "name": a.name,
                        "arguments": dict(a.arguments),
                    }
                    for i, a in enumerate(gt)
                ],
                "env_assertions": assertions,
                "reward_basis": ["ENV_ASSERTION"] if assertions else ["ACTION"],
            },
        }
        cand = TaskCandidate(
            candidate_id=task_body["id"],
            task_id=task_body["id"],
            blueprint=blueprint,
            task=task_body,
            gt_actions=gt,
            assertions=assertions,
        )
        try:
            rep = self.replay_gt_actions(cand, gt)
        except Exception:
            return False
        log = rep.get("replay_log") or []
        if any("error" in (r.get("status") or "") or r.get("status") == "crash"
               for r in log):
            return False
        if blueprint.fix_locus == "escalation":
            return True
        return bool(rep.get("success")) and rep.get("final_reward", 0) >= 1.0

    def _valid_entities_for(self, blueprint: TaskBlueprint) -> List[Dict[str, Any]]:
        """Live entities whose rebound skeleton still replays clean, cached per
        archetype. The source entity (the catalog's validation entity) is always
        included as a guaranteed-valid fallback, so the pool is never empty."""
        # Key on the COMPOSITE id (anchor + secondaries in gt order), not the
        # anchor alone: two composites that share an anchor but layer different
        # secondaries have different skeletons and therefore different valid pools.
        key = blueprint.composite_id() if blueprint.archetype_id else "_legacy"
        if key in self._valid_entities_cache:
            return self._valid_entities_cache[key]
        src = self._source_entity()
        pool: List[Dict[str, Any]] = []
        for ent in self._live_entities():
            if ent.get("customer_id") == src.get("customer_id") and ent.get(
                "line_id"
            ) == src.get("line_id"):
                continue  # source added unconditionally below
            if self._replays_clean(blueprint, ent):
                pool.append(ent)
        pool.insert(0, src)  # always-valid fallback, deterministic position
        self._valid_entities_cache[key] = pool
        return pool

    def _rotated_entity(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Deterministically pick a replay-valid live entity for this blueprint."""
        pool = self._valid_entities_for(blueprint)
        if not pool:
            return self._source_entity()
        seed = int(
            hashlib.sha256((blueprint.blueprint_id or "").encode()).hexdigest(), 16
        )
        return pool[seed % len(pool)]

    def _rebind_to_entity(self, obj: Any, src: Dict[str, Any], dst: Dict[str, Any]) -> Any:
        """Recursively replace the source entity's concrete values with the
        rotated entity's values inside an already-bound replay_template.

        We match on the source entity's *values* (customer_id/line_id/phone/name/
        data_used_over_limit), so this works whether the template was loaded with
        raw tokens or pre-bound -- the planner ships pre-bound templates.
        """
        remap = {
            src.get("customer_id"): dst.get("customer_id"),
            src.get("line_id"): dst.get("line_id"),
            src.get("phone"): dst.get("phone"),
            src.get("name"): dst.get("name"),
            src.get("data_used_over_limit"): dst.get("data_used_over_limit"),
        }
        # Drop identity entries that would rewrite unrelated values (e.g. None).
        remap = {k: v for k, v in remap.items() if k is not None and v is not None}

        def _walk(o: Any) -> Any:
            if isinstance(o, dict):
                return {k: _walk(v) for k, v in o.items()}
            if isinstance(o, list):
                return [_walk(v) for v in o]
            if isinstance(o, str) and o in self._SOURCE_TOKENS:
                key = o.strip("{}")
                return dst.get(key, o)
            if o in remap:
                return remap[o]
            return o

        return _walk(obj)

    def pinned_skeleton(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """The validated (reward==1) init/gt/assertions skeleton for this
        blueprint, with its entity rotated for diversity.

        Returns ``{entity, init_actions, gt_actions, assertions}``. The Generator
        installs this verbatim so the structural ground truth is never authored by
        the LLM (the LLM only writes the natural-language shell)."""
        tmpl = blueprint.replay_template or {}
        src = self._source_entity()
        dst = self._rotated_entity(blueprint)
        rebound = self._rebind_to_entity(tmpl, src, dst)
        return {
            "entity": dst,
            "init_actions": rebound.get("init_actions") or [],
            "gt_actions": rebound.get("gt_actions") or [],
            "assertions": rebound.get("assertions") or [],
        }

    # =====================================================================
    # blueprint -> intent
    # =====================================================================
    def infer_environment_requirements(self, blueprint: TaskBlueprint) -> List[str]:
        # Archetype-driven preconditions (V1): the fault the archetype injects IS
        # the precondition, and an active account/line is always needed to act.
        reqs: List[str] = ["existing_active_account_or_line"]
        if getattr(blueprint, "setup_tools", None):
            reqs += [f"fault_injected:{t}" for t in blueprint.setup_tools]
        if blueprint.fix_locus == "agent_mutation" and blueprint.resolution_tool:
            reqs.append(f"agent_must_call:{blueprint.resolution_tool}")
        elif blueprint.fix_locus == "escalation" and blueprint.escalation_tool:
            reqs.append(f"agent_must_escalate:{blueprint.escalation_tool}")
        if blueprint.primary_assertion:
            reqs.append(f"resolved_by:{blueprint.primary_assertion}")
        # Legacy fallback if no archetype info is present (V0 blueprints).
        if len(reqs) == 1:
            mapping = self._cfg.get("env_requirement_by_skill", {})
            legacy = list(mapping.get(blueprint.target_skill_pattern, []))
            reqs += legacy
        return reqs

    def build_generation_context(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Assemble everything the Generator needs for this blueprint.

        V1: the structural ground truth is a *pinned skeleton* (the archetype's
        validated replay_template with a rotated entity). The LLM authors only the
        natural-language shell, so we surface the skeleton + archetype contract +
        identity_path instead of the V0 ``task_family_spec`` vocabulary.
        """
        family = self._cfg.get("task_families", {}).get(blueprint.task_family, {})
        fault_count = self._cfg.get("difficulty_fault_counts", {}).get(
            blueprint.difficulty_level, 1
        )
        env_reqs = blueprint.environment_requirement or self.infer_environment_requirements(
            blueprint
        )
        skeleton = self.pinned_skeleton(blueprint) if blueprint.archetype_id else None
        return {
            "domain": self.domain,
            "blueprint": blueprint.model_dump(),
            "task_family": blueprint.task_family,
            "task_family_spec": family,  # legacy V0 fallback only
            "target_skill_pattern": blueprint.target_skill_pattern,
            "difficulty_level": blueprint.difficulty_level,
            "num_faults": fault_count,
            "environment_requirement": env_reqs,
            "policy": self.load_policy(),
            "tools": self.load_tools(),
            "db_snippets": self.sample_db_snippets(blueprint),
            "examples": self.load_examples(),
            # --- V1 archetype contract + pinned skeleton ---
            "archetype_id": blueprint.archetype_id,
            "identity_path": blueprint.identity_path,
            "fix_locus": blueprint.fix_locus,
            "resolution_tool": blueprint.resolution_tool,
            "escalation_tool": blueprint.escalation_tool,
            "primary_assertion": blueprint.primary_assertion,
            "required_assertions": list(blueprint.required_assertions or []),
            "setup_tools": list(blueprint.setup_tools or []),
            "pinned_skeleton": skeleton,
        }

    # =====================================================================
    # content hard checks (entity / tool existence + arg shape)
    # =====================================================================
    def _iter_task_entity_refs(self, candidate: TaskCandidate) -> Tuple[set, set]:
        """Collect referenced customer_ids and line_ids from gt_actions + init."""
        cust_ids: set = set()
        line_ids: set = set()

        def _scan_args(args: Any) -> None:
            if not isinstance(args, dict):
                return
            cid = args.get("customer_id")
            lid = args.get("line_id")
            if isinstance(cid, str) and cid:
                cust_ids.add(cid)
            if isinstance(lid, str) and lid:
                line_ids.add(lid)

        for a in candidate.effective_gt_actions():
            _scan_args(a.arguments)
        init = (candidate.task or {}).get("initial_state") or {}
        for a in init.get("initialization_actions") or []:
            _scan_args((a or {}).get("arguments") or {})
        # Also scan evaluation_criteria.actions if present.
        ec = (candidate.task or {}).get("evaluation_criteria") or {}
        for a in ec.get("actions") or []:
            _scan_args((a or {}).get("arguments") or {})
        return cust_ids, line_ids

    def check_entities_exist(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        reasons: List[str] = []
        cust_ids, line_ids = self._iter_task_entity_refs(candidate)
        for cid in cust_ids:
            if cid not in self._customers:
                reasons.append(f"unknown customer_id: {cid}")
        for lid in line_ids:
            if lid not in self._lines:
                reasons.append(f"unknown line_id: {lid}")
        # Cross-check line belongs to the named customer when both are present.
        for a in candidate.effective_gt_actions():
            args = a.arguments or {}
            cid, lid = args.get("customer_id"), args.get("line_id")
            if (
                isinstance(cid, str)
                and isinstance(lid, str)
                and lid in self._lines
                and self._lines[lid] != cid
            ):
                reasons.append(f"line {lid} does not belong to customer {cid}")
        return (len(reasons) == 0), reasons

    def check_tools_exist(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        tools = self.load_tools()
        reasons: List[str] = []

        def _check(name: str, where: str) -> None:
            if name not in tools:
                reasons.append(f"unknown tool '{name}' ({where})")

        for a in candidate.effective_gt_actions():
            _check(a.name, "gt_action")
        ec = (candidate.task or {}).get("evaluation_criteria") or {}
        for a in ec.get("actions") or []:
            n = (a or {}).get("name")
            if n:
                _check(n, "evaluation action")
        assert_names = self._assert_func_names()
        for ea in ec.get("env_assertions") or []:
            n = (ea or {}).get("func_name")
            # Assertions resolve via getattr on the toolkit, not the tool
            # registry, so validate them against the assert_* method set.
            if n and n not in assert_names:
                reasons.append(f"unknown assertion func '{n}' (env_assertion)")
        return (len(reasons) == 0), reasons

    def check_tool_args(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Best-effort: required params present, no unknown params."""
        tools = self.load_tools()
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            spec = tools.get(a.name)
            if spec is None:
                continue  # tool-existence handled elsewhere
            params = (
                spec.get("schema", {}).get("function", {}).get("parameters", {})
            )
            props = set((params.get("properties") or {}).keys())
            required = set(params.get("required") or [])
            given = set((a.arguments or {}).keys())
            missing = required - given
            unknown = given - props
            if missing:
                reasons.append(f"{a.name}: missing required args {sorted(missing)}")
            if unknown:
                reasons.append(f"{a.name}: unknown args {sorted(unknown)}")
        return (len(reasons) == 0), reasons

    def check_gt_nontrivial(
        self, candidate: TaskCandidate
    ) -> Tuple[bool, List[str]]:
        """Reject degenerate agent-authored gt (interactive mode). Rule-only.

        - gt must be non-empty;
        - agent_mutation archetypes must call their resolution_tool;
        - escalation archetypes must call their escalation_tool;
        - at least one action must be state-changing (not a getter / identity setup).
        Pinned-skeleton gt always passes, so summarizer mode is unaffected."""
        bp = candidate.blueprint
        gt = candidate.effective_gt_actions()
        if not gt:
            return False, ["empty gt_actions: agent produced no resolving action"]
        names = [a.name for a in gt]
        if getattr(bp, "fix_locus", None) == "agent_mutation" and bp.resolution_tool:
            if bp.resolution_tool not in names:
                return False, [f"gt missing required resolution_tool '{bp.resolution_tool}'"]
        elif getattr(bp, "fix_locus", None) == "escalation" and bp.escalation_tool:
            if bp.escalation_tool not in names:
                return False, [f"gt missing required escalation_tool '{bp.escalation_tool}'"]
        _noop = {"set_user_info", "set_user_location"}
        has_effect = any(
            not n.startswith("get_") and not n.startswith("assert_") and n not in _noop
            for n in names
        )
        if not has_effect:
            return False, ["gt has no state-changing action (all read-only/setup)"]
        return True, []

    # =====================================================================
    # filter / coverage hooks
    # =====================================================================
    def compute_difficulty(self, candidate: TaskCandidate) -> str:
        """Observed difficulty ~= number of independent faults injected.

        Faults are the user-side ``initialization_actions`` that put the device
        into a broken state (everything except the identity/location setup).
        """
        init = (candidate.task or {}).get("initial_state") or {}
        setup_funcs = {"set_user_info", "set_user_location"}
        fault_count = 0
        for a in init.get("initialization_actions") or []:
            fn = (a or {}).get("func_name")
            if fn and fn not in setup_funcs:
                fault_count += 1
        counts = self._cfg.get("difficulty_fault_counts", {"easy": 1, "medium": 2, "hard": 3})
        # Map count back to the nearest difficulty label.
        if fault_count <= counts.get("easy", 1):
            return "easy"
        if fault_count <= counts.get("medium", 2):
            return "medium"
        return "hard"

    def entity_signature(self, candidate: TaskCandidate) -> str:
        """Signature over (entities + fault shape) for near-dup detection.

        Two tasks that touch the same customer/lines with the same set of
        injected faults are near-duplicates even if their NL text differs.

        Most archetypes bind their entity via ``set_user_info(name, phone)`` (the
        user identifies themselves on the device), NOT via customer_id/line_id
        args -- so we MUST also fold the set_user_info identity (phone/name) into
        the signature. Without it the rotated entity is invisible here and
        distinct-entity tasks would falsely collapse to one signature (the V0
        coverage-collapse this pipeline exists to prevent)."""
        cust_ids, line_ids = self._iter_task_entity_refs(candidate)
        init = (candidate.task or {}).get("initial_state") or {}
        init_actions = init.get("initialization_actions") or []
        identity: List[str] = []
        for a in init_actions:
            if (a or {}).get("func_name") == "set_user_info":
                args = (a or {}).get("arguments") or {}
                phone = args.get("phone_number") or args.get("phone")
                if phone:
                    identity.append(f"phone:{phone}")
                if args.get("name"):
                    identity.append(f"name:{args['name']}")
        faults = sorted(
            (a or {}).get("func_name", "")
            for a in init_actions
            if (a or {}).get("func_name") not in {"set_user_info", "set_user_location"}
        )
        payload: Dict[str, Any] = {
            "family": candidate.blueprint.task_family,
            "customers": sorted(cust_ids),
            "lines": sorted(line_ids),
            "identity": sorted(identity),
            "faults": faults,
        }
        if not candidate.effective_gt_actions():
            payload["refusal"] = self._refusal_content_key(candidate)
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()
