"""ArchetypeSynthesizer: reverse-derive resolution archetypes from the env alone.

This is the task-set-free replacement for the hand-authored archetype catalog.
Given only a live environment (its ``assert_*`` families + the tool->field map
the :class:`AffordanceProber` learned), it reverse-derives candidate
(fault -> fix -> assertion) archetypes and keeps only those that REPLAY to
reward==1. No official task corpus is ever read.

Reverse-derivation loop (per user-observable boolean/enum assertion)::

    1. pick a real entity from the live env DB (generic; no hardcoded ids)
    2. establish the "resolved" expectation on a clean device
         (whichever expected value the assertion holds at on a fresh env)
    3. for each candidate SETUP tool: apply it; if the assertion flips
         resolved -> broken, we found a real fault
    4. for each candidate FIX tool: apply it on the broken state; if the
         assertion flips broken -> resolved, we found the fix
    5. emit (setup -> fix -> assert) as a candidate and REPLAY-validate it;
         keep it only if reward==1

The discovery in steps 2-4 is done LIVE against the toolkit (fast, no evaluator);
step 5 reuses the adapter's deterministic replay so a surviving archetype is a
guaranteed-realizable coverage atom -- exactly the guarantee the hand catalog had.

Entity-parameterized assertions (e.g. ``assert_data_refueling_amount`` needing
customer_id/line_id/amount) are reported as ``needs_entity_binding`` rather than
auto-synthesized here; they map to the agent-mutation atoms and are derived with
concrete args in a follow-up pass.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from ...schemas import GTAction, TaskBlueprint, TaskCandidate
from .affordance_prober import AffordanceProber, ProbeReport

# Identity/location setup that is NOT a fault (mirrors the hand catalog's split).
_NON_FAULT_SETUP = {"set_user_info", "set_user_location", "simulate_network_search"}


@dataclass
class SynthesizedArchetype:
    id: str
    assertion: str
    expected: Any
    setup_tool: str
    fix_tool: str
    fix_actor: str  # "user" | "assistant"
    fix_locus: str  # "user_device" | "agent_mutation"
    replay_template: Dict[str, Any]
    reward: float = 0.0
    validated: bool = False


@dataclass
class SynthesisReport:
    archetypes: List[SynthesizedArchetype]
    auto_covered_assertions: List[str]
    needs_entity_binding: List[str]
    uncovered_assertions: List[str]
    all_assertions: List[str]

    def coverage_str(self) -> str:
        return (
            f"{len(self.auto_covered_assertions)}/{len(self.all_assertions)} "
            "assertions auto-covered by a replay-validated archetype"
        )


class ArchetypeSynthesizer:
    def __init__(self, adapter, probe: Optional[ProbeReport] = None):
        self.adapter = adapter
        self.probe = probe or AffordanceProber(adapter).run()

    # --------------------------------------------------------- entity selection
    def _pick_entity(self) -> Dict[str, Any]:
        """Grab one Active customer + Active line + phone from the live env DB.

        Generic: reads only the env's own DB (no task corpus, no hardcoded ids).
        """
        db = self.adapter.make_environment().tools.db.model_dump()
        customers = db.get("customers") or []
        lines = db.get("lines") or []
        line_by_id = {l.get("line_id"): l for l in lines}
        for c in customers:
            if c.get("account_status") != "Active":
                continue
            for lid in c.get("line_ids") or []:
                ln = line_by_id.get(lid)
                if ln and ln.get("status") == "Active":
                    return {
                        "customer_id": c.get("customer_id"),
                        "line_id": lid,
                        "phone": ln.get("phone_number"),
                        "name": c.get("full_name") or c.get("name"),
                    }
        # fallback: first customer/line whatever the status.
        c = customers[0] if customers else {}
        lid = (c.get("line_ids") or [None])[0]
        ln = line_by_id.get(lid, {})
        return {
            "customer_id": c.get("customer_id"),
            "line_id": lid,
            "phone": ln.get("phone_number"),
            "name": c.get("full_name") or c.get("name"),
        }

    # ----------------------------------------------------- assertion classification
    def _assertion_kind(self, env, name: str) -> Tuple[str, List[str]]:
        """Return (kind, non_default_params).

        kind in {"bool", "enum_str", "entity"}: bool/enum_str assertions read
        user-observable state and can be auto-synthesized; "entity" ones need
        customer_id/line_id/etc and are deferred.
        """
        kit = getattr(env, "user_tools")
        fn = getattr(kit, name, None) or getattr(getattr(env, "tools"), name, None)
        assert fn is not None, f"assertion {name} not found on toolkits"
        sig = inspect.signature(fn)
        params = [p for p in sig.parameters if p != "self"]
        required = [
            p for p, pp in sig.parameters.items()
            if p != "self" and pp.default is inspect.Parameter.empty
        ]
        if any(p in ("customer_id", "line_id", "bill_id", "overdue_bill_id") for p in params):
            return "entity", required
        # single expected_* arg -> bool or str
        ann = {p: pp.annotation for p, pp in sig.parameters.items() if p != "self"}
        if "expected_status" in ann and ann["expected_status"] is bool:
            return "bool", required
        if "expected_status" in ann and ann["expected_status"] is str:
            return "enum_str", required
        if not required:
            return "bool", required  # no-arg assertion (e.g. assert_internet_not_excellent)
        return "entity", required

    def _eval_assertion(self, kit, name: str, expected: Any) -> Optional[bool]:
        """Call a user-side assertion live; return its bool result or None on error."""
        fn = getattr(kit, name)
        try:
            sig = inspect.signature(fn)
            if any(p != "self" for p in sig.parameters):
                return bool(fn(expected))
            return bool(fn())
        except Exception:
            return None

    def _resolved_expectation(self, name: str, kind: str) -> Optional[Any]:
        """Find the expected value that HOLDS on a clean device (the resolved state)."""
        env = self.adapter.make_environment()
        env.user_tools.set_user_info(name="Probe User", phone_number=self._entity["phone"])
        kit = env.user_tools
        if kind == "bool":
            for exp in (True, False):
                if self._eval_assertion(kit, name, exp) is True:
                    return exp
            return None
        if kind == "enum_str":
            for exp in ("connected", "suspended", "disconnected", "active"):
                if self._eval_assertion(kit, name, exp) is True:
                    return exp
            return None
        return None

    def _entity_assertion_resolvable(self, env, name: str) -> bool:
        """Does an entity assertion HOLD (some expected value) on a clean device?

        Binds the live entity's customer_id/line_id, sweeps the candidate expected
        values, and returns True iff some value is satisfied at healthy state. A
        *reverse* entity assertion (e.g. assert_overdue_bill_exists -- true only
        while a bill is overdue, raises once resolved) holds at NO value on a clean
        device, so it returns False and is binned non_resolvable. Fully mechanical:
        the clean-device truth table decides, no hand list of reverse assertions.
        """
        fn = getattr(env.tools, name, None) or getattr(env.user_tools, name, None)
        if fn is None:
            return False
        sig = inspect.signature(fn)
        params = [p for p in sig.parameters if p != "self"]
        exp_param = next((p for p in params if p.startswith("expected")), None)
        base: Dict[str, Any] = {}
        for p in params:
            if p == "customer_id":
                base[p] = self._entity.get("customer_id")
            elif p == "line_id":
                base[p] = self._entity.get("line_id")
            elif p in ("bill_id", "overdue_bill_id"):
                # no bill is overdue on a clean device; a nonexistent id lets a
                # "fixed" assertion pass and a "reverse" one fail/raise -> exactly
                # the signal we want.
                base[p] = "B_CLEAN_PROBE"
        if exp_param is None:
            try:
                return bool(fn(**base))
            except Exception:
                return False
        for exp in (True, False, "Active", "Suspended", "connected", "active"):
            kk = dict(base)
            kk[exp_param] = exp
            try:
                if bool(fn(**kk)) is True:
                    return True
            except Exception:
                continue
        return False

    # ------------------------------------------------------------ candidate tools
    def _user_setup_fix_candidates(self) -> List[str]:
        """User-side zero-arg tools that were observed to change SOME state field."""
        out = []
        for name, eff in self.probe.tool_effects.items():
            if eff.actor != "user" or eff.error:
                continue
            if name in _NON_FAULT_SETUP:
                continue
            if eff.changed:  # only tools with an observable effect are useful
                out.append(name)
        return sorted(out)

    # ----------------------------------------------------- resolvability split
    def resolvability_split(self) -> Dict[str, List[str]]:
        """Classify every assert_* by whether it CAN be a resolution target.

        Cheap (no replay): uses only the signature + clean-device probing the
        synthesizer already does. Returns three disjoint lists:

          - ``resolvable``    : a "resolved" expectation exists on a clean device
                                (bool/enum_str assertions we can drive to pass) ->
                                these SHOULD be covered by >=1 archetype.
          - ``needs_entity``  : entity-parameterized (customer_id/line_id/...) that
                                HOLD at a healthy state -> resolvable in principle,
                                just need concrete args.
          - ``non_resolvable``: reverse assertions that only hold at fault-state
                                (e.g. assert_internet_not_excellent, or the entity
                                reverse assert_overdue_bill_exists which raises once
                                resolved). There is no "fixed" target, so they are
                                NOT a completeness obligation -- the gate excludes
                                them, not fails forever on them.

        The split is fully mechanical: a bool/enum_str assertion whose resolved
        expectation cannot be established on a clean device is non_resolvable; an
        entity assertion that holds at NO expected value on a clean device (binding
        the live entity) is likewise non_resolvable (a reverse assertion).
        """
        self._entity = self._pick_entity()
        probe_env = self.adapter.make_environment()
        probe_env.user_tools.set_user_info(
            name="Probe User", phone_number=self._entity.get("phone")
        )
        resolvable: List[str] = []
        needs_entity: List[str] = []
        non_resolvable: List[str] = []
        for assertion in self.probe.assertion_families:
            kind, _ = self._assertion_kind(probe_env, assertion)
            if kind == "entity":
                if self._entity_assertion_resolvable(probe_env, assertion):
                    needs_entity.append(assertion)
                else:
                    non_resolvable.append(assertion)
                continue
            if self._resolved_expectation(assertion, kind) is None:
                non_resolvable.append(assertion)
            else:
                resolvable.append(assertion)
        return {
            "resolvable": sorted(resolvable),
            "needs_entity": sorted(needs_entity),
            "non_resolvable": sorted(non_resolvable),
        }

    # --------------------------------------------------------------- synthesis
    def synthesize(self) -> SynthesisReport:
        self._entity = self._pick_entity()
        probe_env = self.adapter.make_environment()
        all_asserts = self.probe.assertion_families
        candidates = self._user_setup_fix_candidates()

        archetypes: List[SynthesizedArchetype] = []
        auto_covered: List[str] = []
        needs_entity: List[str] = []
        uncovered: List[str] = []

        for assertion in all_asserts:
            kind, _ = self._assertion_kind(probe_env, assertion)
            if kind == "entity":
                needs_entity.append(assertion)
                continue
            resolved = self._resolved_expectation(assertion, kind)
            if resolved is None:
                # assertion holds at fault-state (e.g. assert_internet_not_excellent)
                # -> not a "resolved" target; skip auto-synthesis.
                uncovered.append(assertion)
                continue

            found_for_assertion = False
            for setup in candidates:
                if not self._fault_confirmed(assertion, resolved, setup):
                    continue
                fix, actor = self._find_fix(assertion, resolved, setup, candidates)
                if fix is None:
                    continue
                arch = self._emit_and_validate(assertion, resolved, setup, fix, actor)
                if arch.validated:
                    archetypes.append(arch)
                    found_for_assertion = True
            if found_for_assertion:
                auto_covered.append(assertion)
            else:
                uncovered.append(assertion)

        return SynthesisReport(
            archetypes=archetypes,
            auto_covered_assertions=sorted(set(auto_covered)),
            needs_entity_binding=sorted(set(needs_entity)),
            uncovered_assertions=sorted(set(uncovered)),
            all_assertions=all_asserts,
        )

    # --------------------------------------------------- canonical planner atoms
    @staticmethod
    def _intent_family_for(assertion: str) -> str:
        """Mechanical assertion -> intent_family label (keyword heuristic, portable).

        The label is only the task_family tag the planner stamps on the blueprint;
        it does not affect any coverage gate. Kept as a simple keyword map so a new
        domain needs no hand catalog to get a sensible family.
        """
        a = assertion.lower()
        if "mms" in a or "sms" in a:
            return "mms_issue"
        if "data" in a or "roaming" in a or "internet" in a or "speed" in a:
            return "mobile_data_issue"
        return "service_issue"

    def canonical_archetypes(self) -> List[Dict[str, Any]]:
        """Collapse the raw replay-validated archetypes into clean planner atoms.

        The raw ``synthesize()`` output is intentionally redundant: every fix tool
        emits one archetype per assertion it happens to flip (side-effects) and a
        degenerate ``setup==fix`` representative. For the planner's Type-1 grid we
        want exactly ONE atom per covered *assertion* (the assertion IS the atom's
        coverage identity), realized by the cleanest available (setup -> fix) pair:

          * drop the degenerate ``setup==fix`` rep when a real fault injector exists
          * prefer a dedicated injector setup (``turn_*_on`` / ``unseat_*`` ...) so
            the fault is established by a distinct tool, not by the fix itself
          * the verifying assertion becomes ``primary_assertion``; we do NOT fold in
            the side-effect assertions of other atoms (each gets its own clean atom)

        Returns dicts in the exact shape the planner/DomainCard consume so they can
        be unioned with the hand catalog. Fully mechanical -- no hand lists.
        """
        rep = self.synthesize()
        by_assertion: Dict[str, List[SynthesizedArchetype]] = {}
        for ar in rep.archetypes:
            by_assertion.setdefault(ar.assertion, []).append(ar)

        out: List[Dict[str, Any]] = []
        for assertion, group in sorted(by_assertion.items()):
            non_degenerate = [a for a in group if a.setup_tool != a.fix_tool]
            pool = non_degenerate or group
            # prefer a dedicated injector setup over a toggle-as-setup.
            pool.sort(key=lambda a: (not a.setup_tool.startswith(("turn_", "unseat_",
                                                                   "remove_", "break_",
                                                                   "lock_", "set_")),
                                     a.setup_tool))
            best = pool[0]
            is_agent = best.fix_actor == "assistant"
            out.append({
                "id": f"auto_{best.fix_tool}__{assertion}",
                "intent_family": self._intent_family_for(assertion),
                "resolution_tool": best.fix_tool if is_agent else None,
                "fix_locus": best.fix_locus,
                "primary_assertion": assertion,
                "extra_assertions": [],
                "user_fix_actions": [] if is_agent else [best.fix_tool],
                "setup_tools": [best.setup_tool],
                "replay_template": best.replay_template,
                "source": "auto_synth",
            })
        return out

    # ----------------------------------------------- extra-assertion discovery
    # Candidate expected values to sweep per assertion kind. Mechanical: we try
    # each and keep whichever holds at the resolved state under real replay.
    _EXTRA_EXPECTED_SWEEP = [True, False, "Active", "connected", "active"]

    def _harvest_entity_args(self, replay_template: Dict[str, Any]) -> Dict[str, Any]:
        """Collect only ENTITY-id args (customer_id/line_id/bill_id) from a
        template. We deliberately ignore ``expected_*`` args so a candidate
        assertion's expected value is swept fresh, never polluted by another
        assertion's expectation carried in the template."""
        keep = {"customer_id", "line_id", "bill_id", "overdue_bill_id"}
        pool: Dict[str, Any] = {}
        for grp in ("init_actions", "gt_actions", "assertions"):
            for a in replay_template.get(grp) or []:
                for k, v in (a.get("arguments") or {}).items():
                    if k in keep and k not in pool:
                        pool[k] = v
        return pool

    def _replay_reward(self, archetype: Dict[str, Any]) -> float:
        """Build a candidate from an archetype dict and return its replay reward.

        Local import avoids a module cycle (validate_archetypes imports domain_card
        which imports this module)."""
        from .validate_archetypes import _build_candidate

        cand = _build_candidate(archetype)
        rep = self.adapter.replay_gt_actions(cand, cand.gt_actions)
        return float(rep["final_reward"]) if rep.get("success") else 0.0

    def _assertion_unmet_at_fault(
        self, replay_template: Dict[str, Any], assertion_entry: Dict[str, Any]
    ) -> bool:
        """Replay only the FAULT (init_actions, no gt_actions) and check the single
        candidate assertion is NOT satisfied. Proves the fix is what establishes the
        assertion -- so we attach it only where the archetype's fix genuinely flips
        it, never as a vacuously-true terminal state (which would be misleading
        noise in the blueprint contract). Adjudicated by the same replay evaluator,
        no manual state probing."""
        fault = {
            "id": "fault_probe",
            "intent_family": "probe",
            "fix_locus": "user_device",
            "replay_template": {
                "init_actions": replay_template.get("init_actions") or [],
                "gt_actions": [],
                "assertions": [assertion_entry],
            },
        }
        return self._replay_reward(fault) < 1.0

    def discover_extra_assertions(
        self, archetypes: List[Dict[str, Any]], obligation: List[str]
    ) -> List[Dict[str, Any]]:
        """Attach extra verifying assertions to archetypes, replay-adjudicated.

        For each resolvable assertion in ``obligation`` not yet anyone's primary,
        try adding it (with entity args harvested from the template and an expected
        value swept from a fixed candidate set) to each archetype whose gold state
        could plausibly satisfy it. Keep the attachment ONLY if the *joint* replay
        still reaches reward==1 -- the env replay gate is the sole adjudicator, no
        manual state probing (which proved unreliable vs the canonical evaluator).

        This closes coverage holes whose verifying assertion is a natural byproduct
        of an existing fix (e.g. a refuel also makes the line Active and clears the
        data-usage-exceeded flag) without inventing a new synthesis path. Returns a
        new archetype list (inputs are not mutated). Fully mechanical, no hand list.
        """
        import copy

        primaries = {a.get("primary_assertion") for a in archetypes}
        already_extra = {
            e for a in archetypes for e in (a.get("extra_assertions") or [])
        }
        targets = [
            x for x in obligation if x not in primaries and x not in already_extra
        ]
        if not targets:
            return archetypes

        probe_env = self.adapter.make_environment()
        out = [copy.deepcopy(a) for a in archetypes]
        for arch in out:
            tmpl = arch.get("replay_template")
            if not tmpl or self._replay_reward(arch) < 1.0:
                continue  # only extend archetypes that already pass on their own
            ent_args = self._harvest_entity_args(tmpl)
            for assertion in targets:
                if assertion in (arch.get("extra_assertions") or []):
                    continue
                fn = getattr(probe_env.tools, assertion, None) or getattr(
                    probe_env.user_tools, assertion, None
                )
                if fn is None:
                    continue
                etype = "assistant" if getattr(probe_env.tools, assertion, None) else "user"
                params = [p for p in inspect.signature(fn).parameters if p != "self"]
                exp_param = next((p for p in params if p.startswith("expected")), None)
                base = {p: ent_args[p] for p in params if p in ent_args}
                sweep = [None] if exp_param is None else list(self._EXTRA_EXPECTED_SWEEP)
                for exp in sweep:
                    args = dict(base)
                    if exp_param is not None:
                        args[exp_param] = exp
                    entry = {"env_type": etype, "func_name": assertion, "arguments": args}
                    # require the fix to FLIP it: unmet at fault, met after the fix.
                    if not self._assertion_unmet_at_fault(tmpl, entry):
                        continue
                    trial = copy.deepcopy(arch)
                    trial["replay_template"]["assertions"].append(entry)
                    if self._replay_reward(trial) >= 1.0:
                        arch["replay_template"]["assertions"].append(entry)
                        arch.setdefault("extra_assertions", [])
                        if assertion not in arch["extra_assertions"]:
                            arch["extra_assertions"].append(assertion)
                        break  # this assertion now covered on this archetype
        return out

    # ---- live discovery primitives (no evaluator, just toolkit calls) --------
    def _fresh_broken_env(self, setup: str):
        """Fresh env + identity + apply one setup tool. Returns env."""
        env = self.adapter.make_environment()
        env.user_tools.set_user_info(name="Probe User", phone_number=self._entity["phone"])
        getattr(env.user_tools, setup)()
        return env

    def _fault_confirmed(self, assertion, resolved, setup) -> bool:
        env = self._fresh_broken_env(setup)
        val = self._eval_assertion(env.user_tools, assertion, resolved)
        return val is False  # resolved expectation no longer holds => fault real

    def _find_fix(self, assertion, resolved, setup, candidates):
        """On the broken state, find a tool that restores the resolved expectation."""
        for fix in candidates:
            env = self._fresh_broken_env(setup)
            try:
                getattr(env.user_tools, fix)()
            except Exception:
                continue
            if self._eval_assertion(env.user_tools, assertion, resolved) is True:
                return fix, "user"
        return None, ""

    def _emit_and_validate(self, assertion, resolved, setup, fix, actor) -> SynthesizedArchetype:
        """Build a replay_template and run the deterministic replay gate."""
        phone = self._entity["phone"]
        init_actions = [
            {"env_type": "user", "func_name": "set_user_info",
             "arguments": {"name": "Probe User", "phone_number": phone}},
            {"env_type": "user", "func_name": setup, "arguments": {}},
        ]
        gt_actions = [GTAction(actor=actor, name=fix, arguments={})]
        assertions = [
            {"env_type": "user", "func_name": assertion,
             "arguments": {"expected_status": resolved}}
        ]
        template = {
            "init_actions": init_actions,
            "gt_actions": [{"actor": a.actor, "name": a.name, "arguments": a.arguments} for a in gt_actions],
            "assertions": assertions,
        }
        cand = self._build_candidate(assertion, setup, fix, template, gt_actions, assertions)
        rep = self.adapter.replay_gt_actions(cand, gt_actions)
        return SynthesizedArchetype(
            id=f"auto_{setup}__{fix}__{assertion}",
            assertion=assertion, expected=resolved,
            setup_tool=setup, fix_tool=fix, fix_actor=actor,
            fix_locus="agent_mutation" if actor == "assistant" else "user_device",
            replay_template=template,
            reward=rep["final_reward"], validated=rep["success"] and rep["final_reward"] >= 1.0,
        )

    def _build_candidate(self, assertion, setup, fix, template, gt_actions, assertions) -> TaskCandidate:
        task_body = {
            "id": f"synth_{setup}_{fix}",
            "description": {"purpose": f"auto-synth {assertion}"},
            "user_scenario": {"instructions": {
                "domain": getattr(self.adapter, "domain", "unknown"),
                "reason_for_call": f"auto-synth {assertion}",
                "task_instructions": "Follow troubleshooting steps.",
            }},
            "initial_state": {"initialization_actions": template["init_actions"]},
            "evaluation_criteria": {
                "actions": [
                    {"action_id": f"{a.name}_{i}", "requestor": a.actor,
                     "name": a.name, "arguments": dict(a.arguments)}
                    for i, a in enumerate(gt_actions)
                ],
                "env_assertions": assertions,
                "reward_basis": ["ENV_ASSERTION"],
            },
        }
        bp = TaskBlueprint(
            blueprint_id=f"bp_synth_{setup}_{fix}",
            domain=getattr(self.adapter, "domain", "unknown"),
            task_family="auto", target_skill_pattern="user_device",
            difficulty_level="easy",
        )
        return TaskCandidate(
            candidate_id=f"synth_{setup}_{fix}", task_id=task_body["id"],
            blueprint=bp, task=task_body, gt_actions=gt_actions, assertions=assertions,
        )


def _format(rep: SynthesisReport) -> str:
    lines = [f"\n=== ArchetypeSynthesizer (task-set-free) ===",
             rep.coverage_str(), ""]
    lines.append(f"AUTO-COVERED assertions ({len(rep.auto_covered_assertions)}):")
    for a in rep.auto_covered_assertions:
        lines.append(f"  + {a}")
    lines.append(f"\nNEEDS ENTITY BINDING (agent-mutation, deferred) ({len(rep.needs_entity_binding)}):")
    for a in rep.needs_entity_binding:
        lines.append(f"  ~ {a}")
    lines.append(f"\nUNCOVERED ({len(rep.uncovered_assertions)}):")
    for a in rep.uncovered_assertions:
        lines.append(f"  - {a}")
    lines.append(f"\nVALIDATED ARCHETYPES ({len(rep.archetypes)}):")
    for ar in rep.archetypes:
        lines.append(f"  [reward={ar.reward:.1f}] {ar.setup_tool:24s} -> {ar.fix_tool:24s} | {ar.assertion}")
    return "\n".join(lines)


if __name__ == "__main__":
    from .telecom_adapter import Tau2TelecomAdapter

    synth = ArchetypeSynthesizer(Tau2TelecomAdapter())
    print(_format(synth.synthesize()))
