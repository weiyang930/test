"""CompositionProbe: measure which coverage atoms can co-exist on one line.

Before the planner/generator learn to build *composite* (multi-fault) tasks, we
must answer the one empirical unknown that decides whether composition is even
worth doing: of all atom pairs/triples, how many are *physically realizable* on a
single line? Two faults on the same device can mask each other (airplane mode
kills signal, so you cannot observe a data-saver slowdown), so the feasible set is
strictly smaller than the naive Cartesian product. This probe measures the real
feasible set, mechanically, with zero hand lists.

Composition contract (depth-d, d = num secondary atoms, total = d+1):

    Task = Anchor (+ d Secondaries), all bound to ONE entity/line.
      init       = set_user_info (once) + every atom's fault-injection actions
      assertions = the conjunction of every atom's assertion(s) (deduped)
      gt_actions = every atom's resolution actions, concatenated

Three composition gates (ALL must hold; reuses the synthesizer's gates verbatim):

  G1  precondition compatibility -- every fault injects without a tool error
      (subsumed by the joint replay G3, which fails on any init error).
  G2  no masking / no vacuity -- at the COMPOSED fault state (all faults, no
      fixes), EVERY assertion is FALSE. Proves each atom is genuinely "live" and
      not silently satisfied. This is exactly the masking detector: a composition
      where one fault hides another's symptom fails here. Reuses
      ``ArchetypeSynthesizer._assertion_unmet_at_fault``.
  G3  joint resolution -- after the merged gt actions, the joint replay reaches
      reward==1 (every assertion flips True). Reuses
      ``ArchetypeSynthesizer._replay_reward``.

Escalation atoms (issue intentionally unresolvable -> transfer) are excluded:
"escalate" and "also fix this other fault" are semantically contradictory, so an
escalation atom may only appear solo (depth-0).

Feasibility is symmetric (a property of the unordered atom *set*): we try both gt
orderings and accept the set if either passes, since gt step order (e.g. a
trailing reboot_device) can matter.

Run standalone:
    python -m multi_agent_synthesis.domains.tau2.composition_probe [--triples]
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .archetype_synthesizer import ArchetypeSynthesizer
from .domain_card import build_domain_card
from .telecom_adapter import Tau2TelecomAdapter

_IDENTITY_SETUP = "set_user_info"


def merge_atoms(atoms: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Merge a list of atoms (already in gt order) into one composite archetype
    dict, identically to how the feasibility probe validated them.

    This is the single source of truth for composition: the probe uses it to test
    feasibility, and the planner uses it to rebuild the exact validated composite
    skeleton from the card's gt-ordered atom lists. ``atoms`` MUST be in the gt
    order recorded by the probe (the order that passed the gates), since gt step
    order can decide resolvability.

      - init: every atom's init actions, but set_user_info kept once (identity).
      - gt: each atom's gt actions concatenated in list order.
      - assertions: union, deduped by (func_name, arguments).
    """
    merged_init: List[Dict[str, Any]] = []
    seen_identity = False
    for atom in atoms:
        for act in atom["replay_template"].get("init_actions") or []:
            if act.get("func_name") == _IDENTITY_SETUP:
                if seen_identity:
                    continue
                seen_identity = True
            merged_init.append(act)

    merged_gt: List[Dict[str, Any]] = []
    for atom in atoms:
        merged_gt.extend(atom["replay_template"].get("gt_actions") or [])

    merged_assert: List[Dict[str, Any]] = []
    seen_a: set = set()
    for atom in atoms:
        for a in atom["replay_template"].get("assertions") or []:
            key = (a.get("func_name"), json.dumps(a.get("arguments"), sort_keys=True))
            if key in seen_a:
                continue
            seen_a.add(key)
            merged_assert.append(a)

    return {
        "id": "+".join(a["id"] for a in atoms),
        "intent_family": "composite",
        "fix_locus": "composite",
        "replay_template": {
            "init_actions": merged_init,
            "gt_actions": merged_gt,
            "assertions": merged_assert,
        },
    }


@dataclass
class PairResult:
    a: str
    b: str
    feasible: bool
    reward: float
    gt_order: str            # "ab" / "ba" / "" (which ordering passed)
    reason: str = ""


@dataclass
class TripleResult:
    atoms: List[str]
    feasible: bool
    reward: float
    reason: str = ""


@dataclass
class CompositionReport:
    n_atoms: int                       # composable atoms (escalation excluded)
    excluded_atoms: List[str]          # escalation / no-assertion atoms
    n_pairs_tested: int
    n_pairs_feasible: int
    pair_feasible: List[List[str]]     # feasible unordered pairs
    pair_infeasible: List[Dict[str, str]]   # {pair, reason}
    sociability: Dict[str, int]        # atom -> #feasible partners (degree)
    # depth-3 (optional)
    n_triples_tested: int = 0
    n_triples_feasible: int = 0
    triple_feasible: List[List[str]] = field(default_factory=list)

    def to_card_dict(self) -> Dict[str, Any]:
        """The minimal validated feasible-set the planner consumes off the card."""
        return {
            "feasible_pairs": self.pair_feasible,
            "feasible_triples": self.triple_feasible,
            "excluded": self.excluded_atoms,
            "sociability": self.sociability,
        }


class CompositionProbe:
    def __init__(
        self,
        adapter: Optional[Tau2TelecomAdapter] = None,
        archetypes: Optional[List[Dict[str, Any]]] = None,
    ):
        """``archetypes`` lets the card builder pass the already-assembled atom set
        so we do NOT rebuild the card here (which would recurse, since the builder
        calls this probe). When omitted (standalone runs), we build a card WITHOUT
        composition to get the atoms, avoiding the same recursion."""
        self.adapter = adapter or Tau2TelecomAdapter()
        self.synth = ArchetypeSynthesizer(self.adapter)
        if archetypes is None:
            card = build_domain_card(
                self.adapter, validate=False, include_composition=False
            )
            archetypes = list(card.archetypes or [])
        self._all = list(archetypes)

    # --------------------------------------------------------------- atom pool
    def _composable(self) -> Tuple[List[Dict[str, Any]], List[str]]:
        """Atoms eligible for composition (have >=1 assertion, not escalation)."""
        ok: List[Dict[str, Any]] = []
        excluded: List[str] = []
        for a in self._all:
            tmpl = a.get("replay_template") or {}
            if a.get("fix_locus") == "escalation" or not (tmpl.get("assertions")):
                excluded.append(a["id"])
            else:
                ok.append(a)
        return ok, sorted(excluded)

    # ---------------------------------------------------------------- compose
    @staticmethod
    def _compose(atoms: List[Dict[str, Any]], gt_order: List[int]) -> Dict[str, Any]:
        """Merge a set of atoms into one synthetic composite archetype dict, with
        gt actions concatenated in ``gt_order``. Delegates to the shared
        ``merge_atoms`` so the probe and the planner build byte-identical
        composites."""
        return merge_atoms([atoms[i] for i in gt_order])

    # ------------------------------------------------------------------ gates
    def _gate(self, composed: Dict[str, Any]) -> Tuple[bool, float, str]:
        tmpl = composed["replay_template"]
        # G2: every assertion must be FALSE at the composed fault state.
        for a in tmpl["assertions"]:
            if not self.synth._assertion_unmet_at_fault(tmpl, a):
                return (
                    False,
                    0.0,
                    f"masked/vacuous: {a.get('func_name')} already true at fault",
                )
        # G3: joint replay reward==1.
        reward = self.synth._replay_reward(composed)
        if reward < 1.0:
            return False, reward, f"joint replay reward={reward:.2f}<1"
        return True, reward, ""

    def _feasible_set(
        self, atoms: List[Dict[str, Any]]
    ) -> Tuple[bool, float, List[str], str]:
        """Try gt orderings; feasible if any ordering passes all gates. On success
        returns the atom ids in the *winning gt order* -- this is what the planner
        replays verbatim, so the order (which can decide resolvability) must be
        preserved, not the unordered set."""
        n = len(atoms)
        orders = [list(range(n)), list(range(n - 1, -1, -1))] if n == 2 else \
            [list(p) for p in itertools.permutations(range(n))]
        last_reason = ""
        for order in orders:
            composed = self._compose(atoms, order)
            ok, reward, reason = self._gate(composed)
            if ok:
                return True, reward, [atoms[i]["id"] for i in order], ""
            last_reason = reason
        return False, 0.0, [], last_reason

    # --------------------------------------------------------------- driver
    def run(self, do_triples: bool = False) -> CompositionReport:
        atoms, excluded = self._composable()
        by_id = {a["id"]: a for a in atoms}
        ids = [a["id"] for a in atoms]

        # feasible lists are stored in WINNING GT ORDER (replayed verbatim by the
        # planner), so they are never sorted. We sort only the outer list, by the
        # sorted-id key, for a stable, diff-friendly card.
        pair_feasible: List[List[str]] = []
        pair_infeasible: List[Dict[str, str]] = []
        sociability: Dict[str, int] = {i: 0 for i in ids}
        feasible_pair_set: set = set()

        for a_id, b_id in itertools.combinations(ids, 2):
            ok, _reward, gt_ids, reason = self._feasible_set([by_id[a_id], by_id[b_id]])
            if ok:
                pair_feasible.append(gt_ids)
                feasible_pair_set.add(frozenset((a_id, b_id)))
                sociability[a_id] += 1
                sociability[b_id] += 1
            else:
                pair_infeasible.append({"pair": f"{a_id} + {b_id}", "reason": reason})

        report = CompositionReport(
            n_atoms=len(atoms),
            excluded_atoms=excluded,
            n_pairs_tested=len(ids) * (len(ids) - 1) // 2,
            n_pairs_feasible=len(pair_feasible),
            pair_feasible=sorted(pair_feasible, key=sorted),
            pair_infeasible=pair_infeasible,
            sociability=dict(sorted(sociability.items(), key=lambda kv: -kv[1])),
        )

        if do_triples:
            triple_feasible: List[List[str]] = []
            n_tested = 0
            # prune: only triples whose all 3 pairs are feasible.
            for a, b, c in itertools.combinations(ids, 3):
                if not (
                    frozenset((a, b)) in feasible_pair_set
                    and frozenset((a, c)) in feasible_pair_set
                    and frozenset((b, c)) in feasible_pair_set
                ):
                    continue
                n_tested += 1
                ok, _reward, gt_ids, _reason = self._feasible_set(
                    [by_id[a], by_id[b], by_id[c]]
                )
                if ok:
                    triple_feasible.append(gt_ids)
            report.n_triples_tested = n_tested
            report.n_triples_feasible = len(triple_feasible)
            report.triple_feasible = sorted(triple_feasible, key=sorted)

        return report


# ===========================================================================
# rendering
# ===========================================================================
def render(report: CompositionReport, verbose: bool = False) -> str:
    L: List[str] = []
    L.append("=" * 78)
    L.append("COMPOSITION FEASIBILITY PROBE  (same-line, replay-adjudicated)")
    L.append("=" * 78)

    L.append(
        f"\ncomposable atoms: {report.n_atoms}  "
        f"(excluded: {report.excluded_atoms})"
    )

    dens = (
        report.n_pairs_feasible / report.n_pairs_tested
        if report.n_pairs_tested
        else 0.0
    )
    L.append("\n[ DEPTH-2 PAIRS ]")
    L.append(
        f"  feasible: {report.n_pairs_feasible}/{report.n_pairs_tested}  "
        f"(density={dens:.2f})"
    )

    L.append("\n[ SOCIABILITY ] (atom -> # feasible same-line partners, max "
             f"{report.n_atoms - 1})")
    for atom, deg in report.sociability.items():
        bar = "#" * deg
        flag = "  <<< antisocial (masks/blocks most)" if deg <= 1 else ""
        L.append(f"  {atom[:50]:50s} {deg:2d} {bar}{flag}")

    if report.n_triples_tested:
        tdens = report.n_triples_feasible / report.n_triples_tested
        L.append("\n[ DEPTH-3 TRIPLES ] (only triples with all 3 pairs feasible)")
        L.append(
            f"  feasible: {report.n_triples_feasible}/{report.n_triples_tested} "
            f"pruned-candidates  (density={tdens:.2f})"
        )

    if verbose:
        L.append("\n[ FEASIBLE PAIRS ]")
        for p in report.pair_feasible:
            L.append(f"  {p[0]}  +  {p[1]}")
        L.append("\n[ INFEASIBLE PAIRS ]")
        for p in report.pair_infeasible:
            L.append(f"  {p['pair']}\n      {p['reason']}")
        if report.triple_feasible:
            L.append("\n[ FEASIBLE TRIPLES ]")
            for t in report.triple_feasible:
                L.append(f"  {' + '.join(t)}")

    L.append("\n[ READ ]")
    L.append("  density >~0.4 and few antisocial atoms => depth-2 is worth wiring")
    L.append("  into the planner (mechanical secondary selection from feasible set).")
    L.append("  density very low / many antisocial => composition buys little; keep")
    L.append("  num_faults as a single-atom difficulty knob instead.")
    L.append("=" * 78)
    return "\n".join(L)


def main() -> int:
    ap = argparse.ArgumentParser(description="Atom co-occurrence feasibility probe.")
    ap.add_argument("--triples", action="store_true", help="also probe depth-3")
    ap.add_argument("--verbose", action="store_true", help="list every pair/triple")
    ap.add_argument("--json-out", default=None, help="dump the feasible sets as JSON")
    args = ap.parse_args()

    report = CompositionProbe().run(do_triples=args.triples)
    print(render(report, verbose=args.verbose))

    if args.json_out:
        with open(args.json_out, "w") as f:
            json.dump(asdict(report), f, indent=2, ensure_ascii=False)
        print(f"\n[json written to {args.json_out}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
