"""Tau2BaseAdapter: shared tau2-Bench mechanics for all tau2 domains.

This wraps ONLY the tau2 *Environment* half (state machine + tools + hashing +
deterministic evaluator). The tau2 agent/orchestrator half is never imported.

Concrete domains (telecom, retail, airline) subclass this and supply:
  - ``domain`` name
  - tool/assertion tables + few-shots + db snippet sampling
  - blueprint -> env-requirement / intent mappings
  - difficulty/coverage/dedup heuristics

Canonical action translation
-----------------------------
The pipeline speaks the canonical ``GTAction{actor,type,name,arguments}``. tau2
speaks ``Action{action_id,requestor,name,arguments}`` for evaluation and
``EnvFunctionCall{env_type,func_name,arguments}`` for init. This base class owns
that translation so subclasses and the pipeline never touch it.
"""

from __future__ import annotations

import copy
from abc import abstractmethod
from typing import Any, Dict, List, Tuple, cast

from ...env_bootstrap import ensure_tau2_importable
from ...schemas import GTAction, TaskCandidate
from ..base import DomainAdapter

ensure_tau2_importable()

# tau2 imports (Environment half + data models + deterministic evaluator).
from tau2.data_model.tasks import (  # noqa: E402
    Action,
    EnvFunctionCall,
    InitializationData,
    RewardType,
    Task,
)
from tau2.evaluator.evaluator_env import EnvironmentEvaluator  # noqa: E402
from tau2.data_model.message import (  # noqa: E402
    AssistantMessage,
    ToolCall,
    ToolMessage,
    UserMessage,
)
from tau2.registry import registry  # noqa: E402


class Tau2BaseAdapter(DomainAdapter):
    """Shared tau2 logic. ``domain`` must be set by subclasses."""

    domain: str = "tau2_base"

    def __init__(self):
        self._env_constructor = registry.get_env_constructor(self.domain)

    # ------------------------------------------------------------------- env
    def make_environment(self, solo_mode: bool = False):
        """Fresh tau2 environment for this domain (manual policy)."""
        return self._env_constructor(solo_mode=solo_mode)

    # ---------------------------------------------------- affordance probing hook
    # The single domain-specific seam the generic affordance prober needs: a flat,
    # comparable snapshot of the user-observable env state. Subclasses point this
    # at their state model(s). Default: every pydantic model found on user_tools.
    _SNAPSHOT_ATTRS: Tuple[str, ...] = ("device", "surroundings")

    def snapshot_state(self, env) -> Dict[str, Any]:
        """Flat dict of user-observable state, for diff-probing tool effects.

        Generic: dumps each pydantic state model named in ``_SNAPSHOT_ATTRS`` on
        ``env.user_tools``, prefixing keys with the attr name so two models can
        share a field name without colliding. A new domain only needs to set
        ``_SNAPSHOT_ATTRS`` (or override this) -- no probing logic changes.
        """
        out: Dict[str, Any] = {}
        kit = getattr(env, "user_tools", None)
        if kit is None:
            return out
        for attr in self._SNAPSHOT_ATTRS:
            obj = getattr(kit, attr, None)
            if obj is None or not hasattr(obj, "model_dump"):
                continue
            for k, v in obj.model_dump().items():
                out[f"{attr}.{k}"] = v
        return out

    # ------------------------------------------------- canonical <-> tau2 actions
    @staticmethod
    def _gt_to_tau2_action(gt: GTAction, idx: int) -> Action:
        kwargs: Dict[str, Any] = dict(
            action_id=f"{gt.name}_{idx}",
            requestor=cast(Any, gt.actor),
            name=gt.name,
            arguments=dict(gt.arguments),
        )
        # ACTION-basis match filter; None lets tau2 compare all args (DB default).
        compare_args = getattr(gt, "compare_args", None)
        if compare_args is not None:
            kwargs["compare_args"] = list(compare_args)
        return Action(**kwargs)

    @staticmethod
    def _init_actions_to_envcalls(task_body: Dict[str, Any]) -> List[EnvFunctionCall]:
        init = (task_body or {}).get("initial_state") or {}
        out = []
        for a in init.get("initialization_actions") or []:
            out.append(EnvFunctionCall(**a))
        return out

    @staticmethod
    def _init_data(task_body: Dict[str, Any]):
        init = (task_body or {}).get("initial_state") or {}
        data = init.get("initialization_data")
        if data is None:
            return None
        return InitializationData(**data)

    def _build_tau2_task(self, candidate: TaskCandidate) -> Task:
        """Construct a tau2 ``Task`` from the candidate's task body, with the
        ground-truth actions installed as evaluation_criteria.actions so the
        deterministic evaluator can build the gold environment from them."""
        body = copy.deepcopy(candidate.task or {})
        body.setdefault("id", candidate.task_id)
        # Ensure evaluation_criteria reflects the (effective) gt actions + assertions.
        ec = body.get("evaluation_criteria") or {}
        # If the generator already supplied actions/env_assertions, keep them;
        # otherwise derive actions from gt_actions.
        if not ec.get("actions"):
            ec["actions"] = [
                self._gt_to_tau2_action(a, i).model_dump()
                for i, a in enumerate(candidate.effective_gt_actions())
            ]
        if not ec.get("reward_basis"):
            # Telecom-style default: prefer env assertions when present, else DB.
            ec["reward_basis"] = (
                [RewardType.ENV_ASSERTION.value]
                if ec.get("env_assertions")
                else [RewardType.DB.value]
            )
        body["evaluation_criteria"] = ec
        return Task(**body)

    # --------------------------------------------------------------- replay core
    def replay_gt_actions(
        self, task_candidate: TaskCandidate, gt_actions: List[GTAction]
    ) -> Dict[str, Any]:
        """Initialize a fresh env from the task, execute gt_actions in order,
        then evaluate with tau2's deterministic evaluator.

        We construct a synthetic trajectory of tool-call messages so that the
        canonical ``EnvironmentEvaluator`` (which rebuilds env from the message
        history) sees exactly the actions we replayed.
        """
        reasons: List[str] = []
        replay_log: List[Dict[str, Any]] = []

        try:
            tau2_task = self._build_tau2_task(task_candidate)
        except Exception as e:  # malformed task body
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": [f"task_build_error: {e}"],
            }

        # 1) Live replay against a fresh env (catches execution errors early).
        env = self.make_environment()
        init_data = None
        init_actions = None
        if tau2_task.initial_state is not None:
            init_data = tau2_task.initial_state.initialization_data
            init_actions = tau2_task.initial_state.initialization_actions
        try:
            env.set_state(
                initialization_data=init_data,
                initialization_actions=init_actions,
                message_history=[],
            )
        except Exception as e:
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": [f"init_state_error: {e}"],
            }

        # Snapshot the DB right after init. A refusal task's gt must leave this
        # unchanged (the correct behavior is to make NO write); we compare against
        # the post-replay hash below instead of relying on the gold-vs-predicted
        # DB-hash (which is circular: gold and predicted come from the same gt).
        is_refusal = bool(getattr(task_candidate.blueprint, "is_refusal", lambda: False)())
        init_db_hash = env.get_db_hash()
        init_user_db_hash = env.get_user_db_hash()

        messages: List[Any] = []
        for i, gt in enumerate(gt_actions):
            tool_call = ToolCall(
                id=f"call_{i}",
                name=gt.name,
                arguments=dict(gt.arguments),
                requestor=cast(Any, gt.actor),
            )
            try:
                tool_msg: ToolMessage = env.get_response(tool_call)
                env.sync_tools()
                ok = not getattr(tool_msg, "error", False)
                replay_log.append(
                    {
                        "step": i,
                        "actor": gt.actor,
                        "name": gt.name,
                        "arguments": gt.arguments,
                        "status": "ok" if ok else "error",
                        "content": str(getattr(tool_msg, "content", ""))[:500],
                    }
                )
                if not ok:
                    reasons.append(f"step {i} {gt.name}: tool error")
                # Build trajectory messages mirroring requestor role.
                if gt.actor == "assistant":
                    messages.append(AssistantMessage(role="assistant", content=None, tool_calls=[tool_call]))
                else:
                    messages.append(UserMessage(role="user", content=None, tool_calls=[tool_call]))
                messages.append(tool_msg)
            except Exception as e:
                replay_log.append(
                    {"step": i, "name": gt.name, "status": "crash", "error": str(e)[:500]}
                )
                reasons.append(f"step {i} {gt.name}: {e}")
                return {
                    "success": False,
                    "final_reward": 0.0,
                    "replay_log": replay_log,
                    "failure_reasons": reasons,
                }

        # 2) Acceptance, branched on the task's declared INTENT.
        #
        # REFUSE: the correct behavior is to make NO state change. We accept iff
        #   the (read-only) gt executed cleanly AND left the DB byte-identical to
        #   the post-init snapshot -- i.e. no illegal write happened. This does
        #   NOT use the gold-vs-predicted DB-hash (that compare is circular: both
        #   envs are built from the same gt), and it deliberately ignores
        #   COMMUNICATE -- a refusal is judged purely by action-absence.
        #
        # FULFILL: accept iff the gt replays end-to-end without a tool error
        #   (executability). We dropped the old reward==1 requirement: that gate
        #   only re-checked that gt-as-gold == gt-as-prediction (always true for a
        #   clean replay), so it filtered nothing beyond executability while
        #   blocking non-deterministic-but-correct tasks. The reward is still
        #   reported for visibility; it just no longer gates acceptance.
        if is_refusal:
            final_db_hash = env.get_db_hash()
            final_user_db_hash = env.get_user_db_hash()
            db_unchanged = (
                final_db_hash == init_db_hash
                and final_user_db_hash == init_user_db_hash
            )
            if not db_unchanged:
                reasons.append("refusal task mutated the DB (gt must be read-only)")
            success = (not reasons) and db_unchanged
            return {
                "success": success,
                "final_reward": 1.0 if success else 0.0,
                "replay_log": replay_log,
                "failure_reasons": reasons,
            }

        # FULFILL path: still run the canonical evaluator for a reported reward,
        # but acceptance hinges on executability (no tool errors) only.
        try:
            reward_info = EnvironmentEvaluator.calculate_reward(
                environment_constructor=self._env_constructor,
                task=tau2_task,
                full_trajectory=messages,
                solo_mode=False,
            )
            final_reward = float(reward_info.reward)
        except Exception as e:
            return {
                "success": False,
                "final_reward": 0.0,
                "replay_log": replay_log,
                "failure_reasons": reasons + [f"evaluation_error: {e}"],
            }

        # ENV_ASSERTION tasks (telecom authoring) DO gate on reward==1. Unlike the
        # DB gold-vs-predicted compare (circular: gold and predicted are both built
        # from the same gt), the env assertion is an INDEPENDENT bar -- "did the
        # authored fault actually clear". A gt that replays cleanly but leaves the
        # symptom unfixed (reward 0) is genuinely wrong and must be rejected, else
        # it yields zero reward==1 rollouts. Shape-gated on the declared basis, so
        # airline/retail DB tasks (never ENV_ASSERTION) keep the executability-only
        # acceptance above.
        ec = tau2_task.evaluation_criteria
        basis = [getattr(b, "value", b) for b in (getattr(ec, "reward_basis", None) or [])]
        if "ENV_ASSERTION" in basis and final_reward < 1.0:
            reasons.append(
                "ENV_ASSERTION gt did not clear the symptom "
                f"(reward={final_reward}); resolution chain is incomplete/incorrect"
            )

        success = not reasons
        return {
            "success": success,
            "final_reward": final_reward,
            "replay_log": replay_log,
            "failure_reasons": reasons,
        }

    # --------------------------------------------- agentic-solver env primitives
    def make_faulted_env(self, init_actions: List[Dict[str, Any]]):
        """Fresh env with the task's initialization (fault injection) applied.

        The InteractiveSolver drops the agent into THIS env -- the faults are
        already injected (init is pinned). The agent explores from here; the
        assertions (the hidden bar) are never installed into this env, so the
        agent cannot see or touch them.
        """
        env = self.make_environment()
        envcalls = [EnvFunctionCall(**a) for a in (init_actions or [])]
        env.set_state(
            initialization_data=None,
            initialization_actions=envcalls,
            message_history=[],
        )
        return env

    def exec_action(
        self,
        env,
        actor: str,
        name: str,
        arguments: Dict[str, Any],
        idx: int,
        max_content_chars: int = 500,
    ) -> Dict[str, Any]:
        """Execute ONE tool call against a live exploration env and return a flat
        observation. Wraps the tau2 ToolCall plumbing so the solver stays
        domain-agnostic. This mutates ``env`` (exploration side effects are
        expected; the final gt is re-replayed on a CLEAN env elsewhere).

        ``max_content_chars`` caps the returned content; the default 500 suits the
        interactive solver, but a free-exploration agent that must read whole
        records (e.g. a user's full reservation list, which tau2 places at the end
        of the payload) should pass a larger limit so trailing ids aren't lost."""
        tc = ToolCall(
            id=f"explore_{idx}",
            name=name,
            arguments=dict(arguments or {}),
            requestor=cast(Any, actor),
        )
        try:
            tool_msg = env.get_response(tc)
            env.sync_tools()
            ok = not getattr(tool_msg, "error", False)
            return {
                "status": "ok" if ok else "error",
                "content": str(getattr(tool_msg, "content", ""))[:max_content_chars],
            }
        except Exception as e:  # malformed call from the agent -- report, don't crash
            return {"status": "crash", "content": str(e)[:max_content_chars]}

    # -------------------------------------------------- shared hard-check helpers
    def check_initial_state(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        try:
            tau2_task = self._build_tau2_task(task_candidate)
            env = self.make_environment()
            init_data = None
            init_actions = None
            if tau2_task.initial_state is not None:
                init_data = tau2_task.initial_state.initialization_data
                init_actions = tau2_task.initial_state.initialization_actions
            env.set_state(
                initialization_data=init_data,
                initialization_actions=init_actions,
                message_history=[],
            )
            return True, []
        except Exception as e:
            return False, [f"initial_state_not_loadable: {e}"]

    def check_evaluator_callable(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Confirm assertions/actions resolve against the env (without requiring
        them to pass)."""
        reasons: List[str] = []
        try:
            tau2_task = self._build_tau2_task(task_candidate)
        except Exception as e:
            return False, [f"task_build_error: {e}"]
        ec = tau2_task.evaluation_criteria
        if ec is None:
            return False, ["no_evaluation_criteria"]
        env = self.make_environment()
        try:
            init = tau2_task.initial_state
            env.set_state(
                initialization_data=init.initialization_data if init else None,
                initialization_actions=init.initialization_actions if init else None,
                message_history=[],
            )
        except Exception as e:
            return False, [f"init_error: {e}"]
        for ea in ec.env_assertions or []:
            try:
                env.run_env_assertion(ea, raise_assertion_error=False)
            except Exception as e:
                reasons.append(f"assertion {ea.func_name} not callable: {e}")
        # A refusal task is judged by action-ABSENCE (DB unchanged), so an empty
        # actions/assertions set is valid and expected -- only fulfill tasks need
        # something concrete to evaluate.
        is_refusal = bool(getattr(task_candidate.blueprint, "is_refusal", lambda: False)())
        if not (ec.env_assertions or ec.actions) and not is_refusal:
            reasons.append("no actions or env_assertions to evaluate")
        return (len(reasons) == 0), reasons

    def check_not_solved_at_init(self, task_candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """The task must be unsolved right after initialization (otherwise the
        agent has nothing to do)."""
        try:
            tau2_task = self._build_tau2_task(task_candidate)
        except Exception as e:
            return False, [f"task_build_error: {e}"]
        ec = tau2_task.evaluation_criteria
        env = self.make_environment()
        init = tau2_task.initial_state
        try:
            env.set_state(
                initialization_data=init.initialization_data if init else None,
                initialization_actions=init.initialization_actions if init else None,
                message_history=[],
            )
        except Exception as e:
            return False, [f"init_error: {e}"]

        assertions = (ec.env_assertions or []) if ec else []
        if not assertions:
            # No env assertions to probe init-state; treat as inconclusive-pass
            # (DB-based tasks rely on replay reward instead).
            return True, []
        all_met = True
        for ea in assertions:
            try:
                met = env.run_env_assertion(ea, raise_assertion_error=False)
                all_met = all_met and bool(met)
            except Exception:
                all_met = False
        if all_met:
            # Escalate/terminal-broken tasks (telecom "unfixable -> transfer") keep
            # the symptom broken on purpose: the terminal env_assertion (e.g.
            # no_service) is TRUE at init by design. There "something to do" lives
            # in the ACTION dimension (agent must call transfer_to_human_agents),
            # not in flipping an assertion. So when the basis also declares ACTION
            # and a non-empty gt action list exists, all-assertions-met at init is
            # NOT "already solved". Shape-gated on the declared basis + gt, so
            # airline/retail (env_assertions empty -> returned above) are untouched.
            basis = [getattr(b, "value", b) for b in ((ec.reward_basis or []) if ec else [])]
            has_gt_actions = bool(ec.actions) if ec else False
            if "ACTION" in basis and has_gt_actions:
                return True, []
            return False, ["already_solved_at_init: all env_assertions pass before any action"]
        return True, []

    # ---------------------------------------------------------- dedup/coverage
    def compute_coverage_keys(self, task_candidate: TaskCandidate) -> Dict[str, str]:
        bp = task_candidate.blueprint
        return {
            "task_family": bp.task_family,
            "target_skill_pattern": bp.target_skill_pattern,
            "difficulty_level": bp.difficulty_level,
            "cell": bp.coverage_cell(),
        }

    @staticmethod
    def _refusal_content_key(task_candidate: TaskCandidate) -> Dict[str, Any]:
        """Discriminator for empty-gt (refusal) tasks. A refusal's gt is an empty
        action list, so the action-based signatures collapse EVERY refusal to one
        hash (the coverage-collapse this pipeline exists to prevent). For these we
        key on what is actually being refused: the dimension cell + the user
        instruction text (which names the entity and the forbidden request)."""
        task = task_candidate.task or {}
        instr = (
            task.get("ticket")
            or (((task.get("user_scenario") or {}).get("instructions") or {}).get(
                "reason_for_call"
            ))
            or ""
        )
        return {
            "cell": task_candidate.blueprint.dimension_cell(),
            "instruction": instr.strip(),
        }

    def dedup_signature(self, task_candidate: TaskCandidate) -> str:
        import hashlib
        import json

        acts = [
            (a.actor, a.name, json.dumps(a.arguments, sort_keys=True))
            for a in task_candidate.effective_gt_actions()
        ]
        init = (task_candidate.task or {}).get("initial_state") or {}
        payload: Dict[str, Any] = {
            "init": init.get("initialization_actions"),
            "acts": acts,
        }
        if not acts:
            payload["refusal"] = self._refusal_content_key(task_candidate)
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()

    # ----------------------------------------------------- abstract for subclass
    @abstractmethod
    def load_policy(self) -> str: ...

    @abstractmethod
    def load_tools(self) -> Dict[str, Any]: ...
