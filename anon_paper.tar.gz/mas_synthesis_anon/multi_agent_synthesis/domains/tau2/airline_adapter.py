"""Tau2AirlineAdapter: the concrete airline domain adapter.

Airline summarizer-mode synthesis is structurally the retail twin:
  * NO user_tools, NO assert_* env assertions -> judging is pure DB-hash.
  * tasks run on the STOCK db (reservations already active) -> NO fault injection;
    the "coverage atom" is a TRANSACTION TYPE and the gt is a single agent WRITE.

Two airline-specific facts shape this adapter:
  * NO identity-lookup tools. The user_id is handed to the agent directly (there is
    no find_user_by_email / name+zip), so there is NO identity_path coverage axis.
    The config passes a single placeholder identity ("direct_user_id") so the
    planner grid stays archetype-only; this adapter ignores it.
  * Only DETERMINISM-SAFE writes are realized in v1. ``book_reservation`` mints a
    fresh reservation_id + ``created_at`` timestamp and ``send_certificate`` mints
    a new payment-method id; those generated values diverge between the gold and
    predicted replays and break DB-hash equality. The four writes below all mutate
    fields of an EXISTING reservation in place, so gold == predicted by
    construction -> reward==1.

Like retail, the one real piece of work is binding an archetype's placeholder
tokens ({{cancel_res_id}}, ...) to a REAL stock reservation whose shape satisfies
the transaction's preconditions, rotating across reservations for diversity.
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Tuple

import yaml

from .. import register_adapter
from ...schemas import TaskBlueprint, TaskCandidate
from .base_adapter import Tau2BaseAdapter

_HERE = os.path.dirname(os.path.abspath(__file__))
_DOMAIN_CFG = os.path.join(_HERE, "configs", "airline_domain.yaml")
_ARCHETYPES_YAML = os.path.join(_HERE, "configs", "airline_archetypes.yaml")

# Cabin tiers, cheapest -> most expensive (the upgrade ladder).
_CABIN_ORDER = ["basic_economy", "economy", "business"]


@register_adapter("airline")
class Tau2AirlineAdapter(Tau2BaseAdapter):
    """Airline domain adapter for the synthesis pipeline (DB-hash reward)."""

    domain: str = "airline"

    def __init__(self, config_path: Optional[str] = None):
        super().__init__()
        self._cfg_path = config_path or _DOMAIN_CFG
        with open(self._cfg_path, "r") as f:
            self._cfg: Dict[str, Any] = yaml.safe_load(f)
        self._policy_text: Optional[str] = None
        self._tools_cache: Optional[Dict[str, Any]] = None
        self._db_cache: Optional[Dict[str, Any]] = None
        # archetype_id -> list of token dicts (rotation pool), lazily built.
        self._candidates_cache: Dict[str, List[Dict[str, Any]]] = {}

    # =====================================================================
    # static context
    # =====================================================================
    def load_schema(self) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "task_families": self._cfg.get("task_families", {}),
            "tools": list(self.load_tools().keys()),
        }

    def load_policy(self) -> str:
        if self._policy_text is None:
            env = self.make_environment()
            self._policy_text = env.get_policy() or ""
        return self._policy_text

    def load_tools(self) -> Dict[str, Any]:
        """Assistant tool signatures keyed by name. Airline has no user tools."""
        if self._tools_cache is not None:
            return self._tools_cache
        env = self.make_environment()
        out: Dict[str, Any] = {}
        for t in env.get_tools():
            out[t.name] = {"actor": "assistant", "schema": t.openai_schema}
        try:
            user_tools = env.get_user_tools() or []
        except ValueError:
            user_tools = []  # airline exposes no user-side tools
        for t in user_tools:
            out[t.name] = {"actor": "user", "schema": t.openai_schema}
        self._tools_cache = out
        return out

    def load_examples(self) -> List[Dict[str, Any]]:
        """No few-shots for v1: the pinned skeleton in the prompt is enough."""
        return []

    def sample_db_snippets(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Airline grounds the generator with the bound-reservation view inside
        the pinned skeleton, so no separate DB snippet block is needed."""
        return {}

    def _db(self) -> Dict[str, Any]:
        """Cached stock-DB snapshot (flights/users/reservations) as plain dicts."""
        if self._db_cache is None:
            self._db_cache = dict(self.make_environment().tools.db.model_dump())
        return self._db_cache

    # =====================================================================
    # archetype catalog (raw tokens; bound per-blueprint in pinned_skeleton)
    # =====================================================================
    def load_raw_archetypes(self) -> List[Dict[str, Any]]:
        with open(_ARCHETYPES_YAML) as f:
            return (yaml.safe_load(f) or {}).get("archetypes", [])

    def build_card(self):
        """Minimal DomainCard for the planner: just the (tokenized) archetypes.

        Airline (like retail) has no auto-synthesizer / composition probe /
        assertion families, so we skip the factual + composition layers the
        telecom card builds. The planner only consumes ``card.archetypes`` and
        ``card.composition``."""
        from .domain_card import DomainCard

        return DomainCard(
            domain=self.domain,
            tables={},
            enums={},
            assistant_tools={},
            user_tools={},
            device_state_fields={},
            surroundings_fields={},
            assertion_families=[],
            archetypes=self.load_raw_archetypes(),
            composition={},
        )

    # =====================================================================
    # payment helpers (airline update-write rules)
    # =====================================================================
    @staticmethod
    def _pm_can_pay_update(pm_spec: Optional[Dict[str, Any]], amount: float) -> bool:
        """Whether a payment method can cover ``amount`` on an UPDATE write.
        Certificates are rejected by the env for updates; gift cards need their
        balance >= amount; credit cards are always sufficient."""
        if not pm_spec:
            return False
        source = pm_spec.get("source") or ""
        if source == "certificate":
            return False
        if source == "gift_card":
            return float(pm_spec.get("amount", 0.0)) >= float(amount)
        return True  # credit_card

    def _pick_payment(self, user: Dict[str, Any], amount: float) -> Optional[str]:
        """First payment method (deterministic by sorted id) that can cover
        ``amount`` under the update rules. Prefers credit cards implicitly only by
        id ordering -- correctness does not depend on which payable method is
        chosen, since gold and predicted replay the same one."""
        pms = user.get("payment_methods") or {}
        for pid in sorted(pms):
            if self._pm_can_pay_update(pms[pid], amount):
                return pid
        return None

    # =====================================================================
    # token binding: archetype placeholders -> a real stock reservation
    # =====================================================================
    def _upgrade_cost(
        self, reservation: Dict[str, Any], target_cabin: str
    ) -> Optional[int]:
        """Charge to upgrade EVERY segment of ``reservation`` to ``target_cabin``,
        or None if the upgrade is not realizable (a segment is unavailable at the
        target cabin, lacks seats for all passengers, or has no target price).
        Mirrors update_reservation_flights' pricing exactly."""
        flights = self._db().get("flights") or {}
        npax = len(reservation.get("passengers") or [])
        new_total = 0
        old_total = 0
        for seg in reservation.get("flights") or []:
            fl = flights.get(seg.get("flight_number"))
            if not fl:
                return None
            fdate = (fl.get("dates") or {}).get(seg.get("date"))
            if not fdate or fdate.get("status") != "available":
                return None
            seats = (fdate.get("available_seats") or {}).get(target_cabin, 0)
            if seats < npax:
                return None
            prices = fdate.get("prices") or {}
            if target_cabin not in prices:
                return None
            new_total += int(prices[target_cabin]) * npax
            old_total += int(seg.get("price", 0)) * npax
        return new_total - old_total

    def _candidates_for(self, archetype_id: str, reservation_state: str) -> List[Dict[str, Any]]:
        """Build the rotation pool of token dicts for one archetype, by scanning
        stock reservations that satisfy the transaction's preconditions. Validity
        is construction-guaranteed (we follow each tool's checks); the per-candidate
        TrajectoryVerifier replay is the final gate, so we do not pre-replay here."""
        if archetype_id in self._candidates_cache:
            return self._candidates_cache[archetype_id]
        db = self._db()
        reservations = db.get("reservations") or {}
        users = db.get("users") or {}
        pool: List[Dict[str, Any]] = []

        for rid in sorted(reservations):
            res = reservations[rid]
            # "active" = not cancelled (status is null in the stock db).
            if res.get("status") is not None:
                continue
            user = users.get(res.get("user_id")) or {}
            passengers = res.get("passengers") or []

            if archetype_id == "cancel_reservation":
                pool.append({"{{cancel_res_id}}": rid})

            elif archetype_id == "update_reservation_passengers":
                if not passengers:
                    continue
                # A realistic single-field correction: fix the lead passenger's
                # date of birth. Choose a value guaranteed to differ so the write
                # is a genuine DB mutation (same passenger count -> tool accepts).
                new_pax = [dict(p) for p in passengers]
                old_dob = new_pax[0].get("dob")
                new_pax[0]["dob"] = "1990-01-01" if old_dob != "1990-01-01" else "1985-06-15"
                pool.append({
                    "{{pax_res_id}}": rid,
                    "{{pax_passengers}}": new_pax,
                })

            elif archetype_id == "update_reservation_baggages":
                # Add exactly one paid bag -> $50 charge; need a payable method.
                pm = self._pick_payment(user, 50)
                if pm is None:
                    continue
                pool.append({
                    "{{bag_res_id}}": rid,
                    "{{bag_total}}": int(res.get("total_baggages", 0)) + 1,
                    "{{bag_nonfree}}": int(res.get("nonfree_baggages", 0)) + 1,
                    "{{bag_pm_id}}": pm,
                })

            elif archetype_id == "update_reservation_flights":
                cur = res.get("cabin")
                if cur not in _CABIN_ORDER:
                    continue
                ci = _CABIN_ORDER.index(cur)
                if ci + 1 >= len(_CABIN_ORDER):
                    continue  # already top tier
                target = _CABIN_ORDER[ci + 1]
                cost = self._upgrade_cost(res, target)
                if cost is None or cost <= 0:
                    continue  # not realizable, or not an actual upcharge
                pm = self._pick_payment(user, cost)
                if pm is None:
                    continue
                flights_arg = [
                    {"flight_number": seg.get("flight_number"), "date": seg.get("date")}
                    for seg in res.get("flights") or []
                ]
                pool.append({
                    "{{flt_res_id}}": rid,
                    "{{flt_target_cabin}}": target,
                    "{{flt_flights}}": flights_arg,
                    "{{flt_pm_id}}": pm,
                })

        self._candidates_cache[archetype_id] = pool
        return pool

    @staticmethod
    def _bind_tokens(obj: Any, mapping: Dict[str, Any]) -> Any:
        if isinstance(obj, dict):
            return {k: Tau2AirlineAdapter._bind_tokens(v, mapping) for k, v in obj.items()}
        if isinstance(obj, list):
            return [Tau2AirlineAdapter._bind_tokens(v, mapping) for v in obj]
        if isinstance(obj, str) and obj in mapping:
            return mapping[obj]
        return obj

    @staticmethod
    def _res_id_from_tokens(token_map: Dict[str, Any]) -> Optional[str]:
        for k in ("{{cancel_res_id}}", "{{pax_res_id}}", "{{bag_res_id}}", "{{flt_res_id}}"):
            if k in token_map:
                return token_map[k]
        return None

    def _reservation_view(self, token_map: Dict[str, Any]) -> Dict[str, Any]:
        """A readable description of the bound reservation for the generator."""
        rid = self._res_id_from_tokens(token_map)
        db = self._db()
        res = (db.get("reservations") or {}).get(rid, {})
        user = (db.get("users") or {}).get(res.get("user_id"), {})
        name = user.get("name") or {}
        pms = user.get("payment_methods") or {}
        return {
            "reservation_id": rid,
            "status": res.get("status") or "active",
            "user_id": res.get("user_id"),
            "user_name": f"{name.get('first_name','')} {name.get('last_name','')}".strip(),
            "membership": user.get("membership"),
            "cabin": res.get("cabin"),
            "flight_type": res.get("flight_type"),
            "origin": res.get("origin"),
            "destination": res.get("destination"),
            "flights": [
                {"flight_number": f.get("flight_number"), "date": f.get("date"),
                 "origin": f.get("origin"), "destination": f.get("destination"),
                 "price": f.get("price")}
                for f in (res.get("flights") or [])
            ],
            "passengers": res.get("passengers") or [],
            "total_baggages": res.get("total_baggages"),
            "nonfree_baggages": res.get("nonfree_baggages"),
            "insurance": res.get("insurance"),
            "payment_methods": [
                {"id": pid,
                 "source": spec.get("source"),
                 **({"amount": spec.get("amount")} if "amount" in spec else {})}
                for pid, spec in pms.items()
            ],
            "bound_tokens": {k.strip("{}"): v for k, v in token_map.items()},
        }

    def pinned_skeleton(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Bind the archetype's tokens to a rotated real stock reservation. Returns
        ``{entity, init_actions, gt_actions, assertions}`` installed verbatim by
        the Generator (the LLM only writes the NL shell)."""
        tmpl = blueprint.replay_template or {}
        family = blueprint.task_family
        state = (
            self._cfg.get("task_families", {}).get(family, {}).get("reservation_state")
            or "active"
        )
        pool = self._candidates_for(blueprint.archetype_id or family, state)
        if not pool:
            token_map: Dict[str, Any] = {}
        else:
            seed = int(
                hashlib.sha256((blueprint.blueprint_id or "").encode()).hexdigest(), 16
            )
            token_map = pool[seed % len(pool)]
        bound = self._bind_tokens(tmpl, token_map)
        return {
            "entity": self._reservation_view(token_map) if token_map else {},
            "init_actions": bound.get("init_actions") or [],
            "gt_actions": bound.get("gt_actions") or [],
            "assertions": bound.get("assertions") or [],
        }

    # =====================================================================
    # blueprint -> intent / generation context
    # =====================================================================
    def infer_environment_requirements(self, blueprint: TaskBlueprint) -> List[str]:
        reqs: List[str] = ["existing_user_with_reservation"]
        fam = self._cfg.get("task_families", {}).get(blueprint.task_family, {})
        state = fam.get("reservation_state")
        if state:
            reqs.append(f"reservation_state:{state}")
        if blueprint.resolution_tool:
            reqs.append(f"agent_must_call:{blueprint.resolution_tool}")
        return reqs

    def build_generation_context(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        family = self._cfg.get("task_families", {}).get(blueprint.task_family, {})
        env_reqs = blueprint.environment_requirement or self.infer_environment_requirements(
            blueprint
        )
        skeleton = self.pinned_skeleton(blueprint) if blueprint.archetype_id else None
        return {
            "domain": self.domain,
            "blueprint": blueprint.model_dump(),
            "task_family": blueprint.task_family,
            "task_family_spec": family,
            "target_skill_pattern": blueprint.target_skill_pattern,
            "difficulty_level": blueprint.difficulty_level,
            "num_faults": 1,
            "environment_requirement": env_reqs,
            "policy": self.load_policy(),
            "tools": self.load_tools(),
            "db_snippets": {},
            "examples": self.load_examples(),
            "archetype_id": blueprint.archetype_id,
            "identity_path": blueprint.identity_path,
            "fix_locus": blueprint.fix_locus,
            "resolution_tool": blueprint.resolution_tool,
            "escalation_tool": blueprint.escalation_tool,
            "primary_assertion": blueprint.primary_assertion,
            "required_assertions": list(blueprint.required_assertions or []),
            "setup_tools": list(blueprint.setup_tools or []),
            "reservation_state": family.get("reservation_state"),
            "pinned_skeleton": skeleton,
        }

    # =====================================================================
    # content hard checks
    # =====================================================================
    def check_entities_exist(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        db = self._db()
        reservations = db.get("reservations") or {}
        users = db.get("users") or {}
        flights = db.get("flights") or {}
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            args = a.arguments or {}
            rid = args.get("reservation_id")
            if rid is None:
                continue
            res = reservations.get(rid)
            if res is None:
                reasons.append(f"unknown reservation_id: {rid}")
                continue
            user = users.get(res.get("user_id")) or {}
            user_pms = set((user.get("payment_methods") or {}).keys())
            pm = args.get("payment_id")
            if pm is not None and pm not in user_pms:
                reasons.append(f"payment id {pm} not owned by user {res.get('user_id')}")
            # passenger-count immutability (update_reservation_passengers).
            new_pax = args.get("passengers")
            if new_pax is not None and len(new_pax) != len(res.get("passengers") or []):
                reasons.append(f"passenger count {len(new_pax)} != reservation count")
            # every referenced flight number must exist.
            for seg in args.get("flights") or []:
                fn = (seg or {}).get("flight_number")
                if fn and fn not in flights:
                    reasons.append(f"unknown flight_number {fn}")
        return (len(reasons) == 0), reasons

    def check_tools_exist(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        tools = self.load_tools()
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            if a.name not in tools:
                reasons.append(f"unknown tool '{a.name}' (gt_action)")
        ec = (candidate.task or {}).get("evaluation_criteria") or {}
        for a in ec.get("actions") or []:
            n = (a or {}).get("name")
            if n and n not in tools:
                reasons.append(f"unknown tool '{n}' (evaluation action)")
        return (len(reasons) == 0), reasons

    def check_tool_args(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        tools = self.load_tools()
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            spec = tools.get(a.name)
            if spec is None:
                continue
            params = spec.get("schema", {}).get("function", {}).get("parameters", {})
            props = set((params.get("properties") or {}).keys())
            required = set(params.get("required") or [])
            given = set((a.arguments or {}).keys())
            missing = required - given
            unknown = given - props
            if missing:
                reasons.append(f"{a.name}: missing required args {sorted(missing)}")
            if unknown:
                reasons.append(f"{a.name}: unknown args {sorted(unknown)}")
        return (len(reasons) == 0), reasons

    def check_gt_nontrivial(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Non-triviality, branched on the task's declared INTENT.

        fulfill: the agent must DO something, so the gt cannot be empty (an empty
                 gt here means the explore agent never converged -- a generation
                 failure, not a valid task). We do NOT additionally require a
                 WRITE: in v0 the synth/explore prompt already restricts gt to
                 state-changing calls, so a non-empty fulfill gt is a write by
                 construction; demanding one here is the false premise that used
                 to kill refusal tasks, so it is gone.
        refuse:  the CORRECT behavior is to make NO state change, so an empty or
                 read-only gt is exactly right -- never reject it for "no write".
        """
        gt = candidate.effective_gt_actions()
        if candidate.blueprint.is_refusal():
            # A refusal's gt is read-only / empty by design; that is the point.
            return True, []
        if not gt:
            return False, ["empty gt_actions: explore did not converge (fulfill task)"]
        return True, []

    def _write_tool_names(self) -> set:
        """Names of WRITE-type tools (authoritative, from the env toolkit)."""
        from tau2.environment.toolkit import get_tool_types

        env = self.make_environment()
        types = {n: t.value for n, t in get_tool_types(env.tools).items()}
        return {n for n, t in types.items() if t == "write"}

    # =====================================================================
    # filter / coverage hooks
    # =====================================================================
    def compute_difficulty(self, candidate: TaskCandidate) -> str:
        n = len(candidate.effective_gt_actions())
        counts = self._cfg.get("difficulty_action_counts", {"easy": 1, "medium": 2, "hard": 3})
        if n <= counts.get("easy", 1):
            return "easy"
        if n <= counts.get("medium", 2):
            return "medium"
        return "hard"

    def entity_signature(self, candidate: TaskCandidate) -> str:
        """Signature over (transaction family + the exact write args) for near-dup
        detection. Two tasks performing the same transaction on the same
        reservation with the same arguments are near-duplicates regardless of NL."""
        acts = [
            (a.name, json.dumps(a.arguments, sort_keys=True))
            for a in candidate.effective_gt_actions()
        ]
        payload: Dict[str, Any] = {
            "family": candidate.blueprint.task_family,
            "acts": sorted(acts),
        }
        if not acts:
            payload["refusal"] = self._refusal_content_key(candidate)
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()
