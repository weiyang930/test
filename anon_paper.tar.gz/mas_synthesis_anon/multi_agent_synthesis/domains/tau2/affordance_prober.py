"""AffordanceProber: learn the env's fault/fix surface by differential probing.

This is the GENERIC, task-set-free way to discover what an environment can do.
It NEVER reads an official task corpus -- everything is learned by poking a fresh
environment and diffing the resulting state. That makes it portable to any new
domain that has no benchmark tasks at all.

Two things are probed:

1. **Tool effects** (``probe_tool_effects``):
   For each callable, no-required-arg tool: snapshot state -> call tool ->
   snapshot again -> diff. The changed fields ARE that tool's effect surface.
   This learns the ``tool -> {state field: (before, after)}`` map mechanically,
   replacing the hand-copied "which tool changes which field" knowledge.

2. **Assertion sensitivity** (``probe_assertion_baseline``):
   On a fresh env, evaluate every ``assert_*`` at its "healthy" expectation. The
   ones that pass on a clean device define the *resolved* terminal states; a
   fault is then anything that flips one of them to fail. (The synthesizer uses
   this together with the tool-effect map to reverse-derive archetypes.)

The only domain-specific seam is ``adapter.snapshot_state(env)`` (a flat,
comparable dict of user-observable state) -- everything here is domain-agnostic.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ToolEffect:
    """What a single zero-arg tool call changed in the env state."""

    tool: str
    actor: str  # "user" | "assistant"
    changed: Dict[str, Tuple[Any, Any]] = field(default_factory=dict)
    error: Optional[str] = None

    @property
    def changed_fields(self) -> List[str]:
        return sorted(self.changed)


@dataclass
class ProbeReport:
    tool_effects: Dict[str, ToolEffect]
    assertion_families: List[str]
    # field -> list of tools observed to change it (the inverse index).
    field_to_tools: Dict[str, List[str]]


def _zero_arg_callable(fn) -> bool:
    """True if fn can be called with no arguments (besides self)."""
    try:
        sig = inspect.signature(fn)
    except (ValueError, TypeError):
        return False
    for name, p in sig.parameters.items():
        if name == "self":
            continue
        if p.default is inspect.Parameter.empty and p.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            return False
    return True


def _diff(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Tuple[Any, Any]]:
    out: Dict[str, Tuple[Any, Any]] = {}
    for k in before.keys() | after.keys():
        b, a = before.get(k), after.get(k)
        if b != a:
            out[k] = (b, a)
    return out


class AffordanceProber:
    """Differential prober over a domain adapter's fresh environments."""

    # Tools that are assertions/reads, not state mutators -- skip when probing
    # effects (assert_* are probed separately; check_*/get_* are pure reads).
    _SKIP_PREFIXES = ("assert_", "check_", "get_")

    def __init__(self, adapter):
        self.adapter = adapter

    # ------------------------------------------------------------ tool effects
    def _candidate_tools(self, env) -> List[Tuple[str, str, Any]]:
        """(name, actor, bound_fn) for every zero-arg, mutating-looking tool."""
        out: List[Tuple[str, str, Any]] = []
        for actor, kit in (("user", getattr(env, "user_tools", None)),
                            ("assistant", getattr(env, "tools", None))):
            if kit is None:
                continue
            for name in dir(kit):
                if name.startswith("_") or name.startswith(self._SKIP_PREFIXES):
                    continue
                fn = getattr(kit, name, None)
                if not callable(fn) or not _zero_arg_callable(fn):
                    continue
                out.append((name, actor, fn))
        return out

    def probe_tool_effects(self) -> Dict[str, ToolEffect]:
        """Learn ``tool -> changed state fields`` by call-and-diff on fresh envs.

        Each tool is probed on its OWN fresh env so effects never contaminate
        each other. Only zero-required-arg tools are auto-probed here (the ones
        needing ids/values are handled by the synthesizer with concrete args).
        """
        effects: Dict[str, ToolEffect] = {}
        # discover the tool list once (from a throwaway env).
        names = self._candidate_tools(self.adapter.make_environment())
        for name, actor, _ in names:
            env = self.adapter.make_environment()
            before = self.adapter.snapshot_state(env)
            kit = getattr(env, "user_tools" if actor == "user" else "tools")
            fn = getattr(kit, name)
            try:
                fn()
            except Exception as e:  # tool needs context we didn't supply
                effects[name] = ToolEffect(tool=name, actor=actor, error=str(e)[:120])
                continue
            after = self.adapter.snapshot_state(env)
            effects[name] = ToolEffect(
                tool=name, actor=actor, changed=_diff(before, after)
            )
        return effects

    # --------------------------------------------------------- assertion surface
    def assertion_families(self, env=None) -> List[str]:
        """All ``assert_*`` methods across assistant + user toolkits."""
        env = env or self.adapter.make_environment()
        names: set = set()
        for kit in (getattr(env, "tools", None), getattr(env, "user_tools", None)):
            if kit is None:
                continue
            for attr in dir(kit):
                if attr.startswith("assert_") and callable(getattr(kit, attr)):
                    names.add(attr)
        return sorted(names)

    # ------------------------------------------------------------------ report
    def run(self) -> ProbeReport:
        effects = self.probe_tool_effects()
        field_to_tools: Dict[str, List[str]] = {}
        for name, eff in effects.items():
            for f in eff.changed_fields:
                field_to_tools.setdefault(f, []).append(name)
        return ProbeReport(
            tool_effects=effects,
            assertion_families=self.assertion_families(),
            field_to_tools=field_to_tools,
        )


def _format_report(rep: ProbeReport) -> str:
    lines: List[str] = []
    lines.append("=== TOOL EFFECTS (learned by diff, zero task-set) ===")
    for name in sorted(rep.tool_effects):
        eff = rep.tool_effects[name]
        if eff.error:
            tag = f"(needs args/context: {eff.error})"
        elif eff.changed:
            tag = ", ".join(
                f"{k}:{b}->{a}" for k, (b, a) in sorted(eff.changed.items())
            )
        else:
            tag = "(no observable change on clean env)"
        lines.append(f"  [{eff.actor:9s}] {name:30s} {tag}")
    lines.append("\n=== FIELD -> TOOLS THAT CHANGE IT (inverse index) ===")
    for f in sorted(rep.field_to_tools):
        lines.append(f"  {f:40s} <- {rep.field_to_tools[f]}")
    lines.append(f"\n=== ASSERTION FAMILIES ({len(rep.assertion_families)}) ===")
    for a in rep.assertion_families:
        lines.append(f"  {a}")
    return "\n".join(lines)


if __name__ == "__main__":
    from .telecom_adapter import Tau2TelecomAdapter

    prober = AffordanceProber(Tau2TelecomAdapter())
    print(_format_report(prober.run()))
