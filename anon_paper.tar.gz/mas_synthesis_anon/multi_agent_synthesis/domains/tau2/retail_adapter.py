"""Tau2RetailAdapter: the concrete retail domain adapter.

Retail is structurally simpler than telecom for synthesis:
  * NO user_tools, NO assert_* env assertions -> judging is pure DB-hash.
  * tasks run on the STOCK db (orders already pending/delivered) -> NO fault
    injection; the "coverage atom" is a TRANSACTION TYPE (cancel / modify_* /
    return / exchange), and the gt is a single agent-side WRITE.

So this adapter is much thinner than the telecom one: no affordance probing, no
assertion reversal, no user-device rotation. The one piece of real work is
binding an archetype's placeholder tokens ({{pending_order_id}}, ...) to a REAL
stock order whose state + item/variant/payment shape satisfies the transaction's
preconditions, rotating across orders for entity diversity.

It subclasses :class:`Tau2BaseAdapter`, which owns env construction + canonical
<->tau2 action translation + the deterministic DB-hash replay/evaluator and the
env-dependent hard checks (initial_state / evaluator / not_solved_at_init).
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Tuple

import yaml

from .. import register_adapter
from ...schemas import TaskBlueprint, TaskCandidate
from .base_adapter import Tau2BaseAdapter

_HERE = os.path.dirname(os.path.abspath(__file__))
_DOMAIN_CFG = os.path.join(_HERE, "configs", "retail_domain.yaml")
_ARCHETYPES_YAML = os.path.join(_HERE, "configs", "retail_archetypes.yaml")

# Identity-resolution paths the retail env actually exposes (no get_customer_by_*).
RETAIL_IDENTITY_PATHS = ["find_user_id_by_email", "find_user_id_by_name_zip"]


@register_adapter("retail")
class Tau2RetailAdapter(Tau2BaseAdapter):
    """Retail domain adapter for the synthesis pipeline (DB-hash reward)."""

    domain: str = "retail"

    def __init__(self, config_path: Optional[str] = None):
        super().__init__()
        self._cfg_path = config_path or _DOMAIN_CFG
        with open(self._cfg_path, "r") as f:
            self._cfg: Dict[str, Any] = yaml.safe_load(f)
        self._policy_text: Optional[str] = None
        self._tools_cache: Optional[Dict[str, Any]] = None
        self._db_cache: Optional[Dict[str, Any]] = None
        # archetype_id -> list of token dicts (rotation pool), lazily built.
        self._candidates_cache: Dict[str, List[Dict[str, Any]]] = {}

    # =====================================================================
    # static context
    # =====================================================================
    def load_schema(self) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "task_families": self._cfg.get("task_families", {}),
            "tools": list(self.load_tools().keys()),
        }

    def load_policy(self) -> str:
        if self._policy_text is None:
            env = self.make_environment()
            self._policy_text = env.get_policy() or ""
        return self._policy_text

    def load_tools(self) -> Dict[str, Any]:
        """Assistant tool signatures keyed by name. Retail has no user tools."""
        if self._tools_cache is not None:
            return self._tools_cache
        env = self.make_environment()
        out: Dict[str, Any] = {}
        for t in env.get_tools():
            out[t.name] = {"actor": "assistant", "schema": t.openai_schema}
        try:
            user_tools = env.get_user_tools() or []
        except ValueError:
            user_tools = []  # retail exposes no user-side tools
        for t in user_tools:
            out[t.name] = {"actor": "user", "schema": t.openai_schema}
        self._tools_cache = out
        return out

    def load_examples(self) -> List[Dict[str, Any]]:
        """No few-shots for v1: the pinned skeleton in the prompt is enough
        grounding, and retail templates carry no assertions to illustrate."""
        return []

    def sample_db_snippets(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Retail grounds the generator with the bound-order view inside the
        pinned skeleton, so no separate DB snippet block is needed."""
        return {}

    def _db(self) -> Dict[str, Any]:
        """Cached stock-DB snapshot (orders/users/products) as plain dicts."""
        if self._db_cache is None:
            self._db_cache = dict(self.make_environment().tools.db.model_dump())
        return self._db_cache

    # =====================================================================
    # archetype catalog (raw tokens; bound per-blueprint in pinned_skeleton)
    # =====================================================================
    def load_raw_archetypes(self) -> List[Dict[str, Any]]:
        with open(_ARCHETYPES_YAML) as f:
            return (yaml.safe_load(f) or {}).get("archetypes", [])

    def build_card(self):
        """Minimal DomainCard for the planner: just the (tokenized) archetypes.

        Retail has no auto-synthesizer / composition probe / assertion families,
        so we skip the factual + composition layers the telecom card builds. The
        planner only consumes ``card.archetypes`` and ``card.composition``.
        """
        from .domain_card import DomainCard

        return DomainCard(
            domain=self.domain,
            tables={},
            enums={},
            assistant_tools={},
            user_tools={},
            device_state_fields={},
            surroundings_fields={},
            assertion_families=[],
            archetypes=self.load_raw_archetypes(),
            composition={},
        )

    # =====================================================================
    # token binding: archetype placeholders -> a real stock order
    # =====================================================================
    @staticmethod
    def _order_pm(order: Dict[str, Any]) -> Optional[str]:
        ph = order.get("payment_history") or []
        return ph[0].get("payment_method_id") if ph else None

    @staticmethod
    def _pm_can_pay(pm_spec: Optional[Dict[str, Any]], amount: float) -> bool:
        """Whether a payment method can cover ``amount``. Gift cards need their
        balance to be >= amount; credit cards / paypal are always sufficient."""
        if not pm_spec:
            return False
        if (pm_spec.get("source") or "").startswith("gift_card") or "balance" in pm_spec:
            return float(pm_spec.get("balance", 0.0)) >= float(amount)
        return True

    def _cheapest_alt_variant(
        self, item: Dict[str, Any], pm_spec: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """A different, available variant id of the SAME product, cheapest first
        (minimizes price diff so gift-card balance checks rarely bind). When a
        payment method is given, the chosen variant's price-difference charge must
        be coverable by it (a gift card needs balance >= max(0, new-old)), so the
        modify/exchange WRITE never errors with insufficient balance."""
        products = self._db().get("products") or {}
        prod = products.get(item.get("product_id"))
        if not prod:
            return None
        old_price = float(item.get("price", 0.0))
        best_id, best_price = None, None
        for vid, v in (prod.get("variants") or {}).items():
            if vid == item.get("item_id") or not v.get("available"):
                continue
            price = float(v.get("price", 0.0))
            if pm_spec is not None and not self._pm_can_pay(pm_spec, max(0.0, price - old_price)):
                continue
            if best_price is None or price < best_price:
                best_id, best_price = vid, price
        return best_id

    def _candidates_for(self, archetype_id: str, order_state: str) -> List[Dict[str, Any]]:
        """Build the rotation pool of token dicts for one archetype, by scanning
        stock orders that satisfy the transaction's preconditions. Validity is
        construction-guaranteed (we follow each tool's checks); the per-candidate
        TrajectoryVerifier replay is the final gate, so we do not pre-replay here.
        """
        if archetype_id in self._candidates_cache:
            return self._candidates_cache[archetype_id]
        db = self._db()
        orders = db.get("orders") or {}
        users = db.get("users") or {}
        pool: List[Dict[str, Any]] = []

        for oid in sorted(orders):
            order = orders[oid]
            if order.get("status") != order_state:
                continue
            pm = self._order_pm(order)
            items = order.get("items") or []
            user = users.get(order.get("user_id")) or {}
            pms = list((user.get("payment_methods") or {}).keys())

            if archetype_id in ("cancel_pending_order", "modify_pending_order_address"):
                pool.append({"{{pending_order_id}}": oid})

            elif archetype_id == "modify_pending_order_items":
                # single-payment pending order (tool needs payment method) + an
                # item with an available alternate variant whose price-diff charge
                # the order's payment method can cover.
                if pm is None:
                    continue
                pm_spec = (user.get("payment_methods") or {}).get(pm)
                for it in items:
                    alt = self._cheapest_alt_variant(it, pm_spec)
                    if alt:
                        pool.append({
                            "{{pending_order_id}}": oid,
                            "{{pending_item_id}}": it["item_id"],
                            "{{pending_alt_item_id}}": alt,
                            "{{pending_pm_id}}": pm,
                        })
                        break

            elif archetype_id == "modify_pending_order_payment":
                # exactly one prior payment + a DIFFERENT payment method that can
                # actually cover the order amount (a gift card needs balance >=
                # the order total, else the WRITE errors with insufficient balance).
                ph = order.get("payment_history") or []
                if len(ph) != 1 or ph[0].get("transaction_type") != "payment":
                    continue
                amount = ph[0].get("amount") or 0.0
                user_pm_specs = (user.get("payment_methods") or {})
                alt_pm = next(
                    (
                        p for p in pms
                        if p != pm and self._pm_can_pay(user_pm_specs.get(p), amount)
                    ),
                    None,
                )
                if alt_pm:
                    pool.append({
                        "{{pending_order_id}}": oid,
                        "{{pending_alt_pm_id}}": alt_pm,
                    })

            elif archetype_id == "return_delivered_order":
                if pm is None or not items:
                    continue
                pool.append({
                    "{{delivered_order_id}}": oid,
                    "{{delivered_item_id}}": items[0]["item_id"],
                    "{{delivered_pm_id}}": pm,  # original pm is always allowed
                })

            elif archetype_id == "exchange_delivered_order":
                if pm is None:
                    continue
                pm_spec = (user.get("payment_methods") or {}).get(pm)
                for it in items:
                    alt = self._cheapest_alt_variant(it, pm_spec)
                    if alt:
                        pool.append({
                            "{{delivered_order_id}}": oid,
                            "{{delivered_item_id}}": it["item_id"],
                            "{{delivered_alt_item_id}}": alt,
                            "{{delivered_pm_id}}": pm,
                        })
                        break

        self._candidates_cache[archetype_id] = pool
        return pool

    @staticmethod
    def _bind_tokens(obj: Any, mapping: Dict[str, Any]) -> Any:
        if isinstance(obj, dict):
            return {k: Tau2RetailAdapter._bind_tokens(v, mapping) for k, v in obj.items()}
        if isinstance(obj, list):
            return [Tau2RetailAdapter._bind_tokens(v, mapping) for v in obj]
        if isinstance(obj, str) and obj in mapping:
            return mapping[obj]
        return obj

    def _order_view(self, token_map: Dict[str, Any]) -> Dict[str, Any]:
        """A readable description of the bound order for the generator prompt."""
        oid = token_map.get("{{pending_order_id}}") or token_map.get("{{delivered_order_id}}")
        db = self._db()
        order = (db.get("orders") or {}).get(oid, {})
        user = (db.get("users") or {}).get(order.get("user_id"), {})
        name = user.get("name") or {}
        return {
            "order_id": oid,
            "status": order.get("status"),
            "user_id": order.get("user_id"),
            "user_name": f"{name.get('first_name','')} {name.get('last_name','')}".strip(),
            "email": user.get("email"),
            "zip": (user.get("address") or {}).get("zip"),
            "items": [
                {"name": it.get("name"), "item_id": it.get("item_id"),
                 "options": it.get("options"), "price": it.get("price")}
                for it in (order.get("items") or [])
            ],
            "payment_methods": list((user.get("payment_methods") or {}).keys()),
            "bound_tokens": {k.strip("{}"): v for k, v in token_map.items()},
        }

    def pinned_skeleton(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        """Bind the archetype's tokens to a rotated real stock order. Returns
        ``{entity, init_actions, gt_actions, assertions}`` installed verbatim by
        the Generator (the LLM only writes the NL shell)."""
        tmpl = blueprint.replay_template or {}
        family = blueprint.task_family
        order_state = (
            self._cfg.get("task_families", {}).get(family, {}).get("order_state")
            or ("delivered" if "delivered" in (blueprint.archetype_id or "") else "pending")
        )
        pool = self._candidates_for(blueprint.archetype_id or family, order_state)
        if not pool:
            token_map: Dict[str, Any] = {}
        else:
            seed = int(
                hashlib.sha256((blueprint.blueprint_id or "").encode()).hexdigest(), 16
            )
            token_map = pool[seed % len(pool)]
        bound = self._bind_tokens(tmpl, token_map)
        return {
            "entity": self._order_view(token_map) if token_map else {},
            "init_actions": bound.get("init_actions") or [],
            "gt_actions": bound.get("gt_actions") or [],
            "assertions": bound.get("assertions") or [],
        }

    # =====================================================================
    # blueprint -> intent / generation context
    # =====================================================================
    def infer_environment_requirements(self, blueprint: TaskBlueprint) -> List[str]:
        reqs: List[str] = ["existing_user_with_order"]
        fam = self._cfg.get("task_families", {}).get(blueprint.task_family, {})
        state = fam.get("order_state")
        if state:
            reqs.append(f"order_state:{state}")
        if blueprint.resolution_tool:
            reqs.append(f"agent_must_call:{blueprint.resolution_tool}")
        return reqs

    def build_generation_context(self, blueprint: TaskBlueprint) -> Dict[str, Any]:
        family = self._cfg.get("task_families", {}).get(blueprint.task_family, {})
        env_reqs = blueprint.environment_requirement or self.infer_environment_requirements(
            blueprint
        )
        skeleton = self.pinned_skeleton(blueprint) if blueprint.archetype_id else None
        return {
            "domain": self.domain,
            "blueprint": blueprint.model_dump(),
            "task_family": blueprint.task_family,
            "task_family_spec": family,
            "target_skill_pattern": blueprint.target_skill_pattern,
            "difficulty_level": blueprint.difficulty_level,
            "num_faults": 1,
            "environment_requirement": env_reqs,
            "policy": self.load_policy(),
            "tools": self.load_tools(),
            "db_snippets": {},
            "examples": self.load_examples(),
            "archetype_id": blueprint.archetype_id,
            "identity_path": blueprint.identity_path,
            "fix_locus": blueprint.fix_locus,
            "resolution_tool": blueprint.resolution_tool,
            "escalation_tool": blueprint.escalation_tool,
            "primary_assertion": blueprint.primary_assertion,
            "required_assertions": list(blueprint.required_assertions or []),
            "setup_tools": list(blueprint.setup_tools or []),
            "order_state": family.get("order_state"),
            "pinned_skeleton": skeleton,
        }

    # =====================================================================
    # content hard checks
    # =====================================================================
    def check_entities_exist(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        db = self._db()
        orders = db.get("orders") or {}
        users = db.get("users") or {}
        products = db.get("products") or {}
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            args = a.arguments or {}
            oid = args.get("order_id")
            if oid is None:
                continue
            order = orders.get(oid)
            if order is None:
                reasons.append(f"unknown order_id: {oid}")
                continue
            order_item_ids = [it.get("item_id") for it in order.get("items") or []]
            user = users.get(order.get("user_id")) or {}
            user_pms = set((user.get("payment_methods") or {}).keys())
            for iid in args.get("item_ids") or []:
                if iid not in order_item_ids:
                    reasons.append(f"item {iid} not in order {oid}")
            # new_item_ids must be real variants of the matching item's product.
            for old_iid, new_iid in zip(
                args.get("item_ids") or [], args.get("new_item_ids") or []
            ):
                it = next(
                    (x for x in order.get("items") or [] if x.get("item_id") == old_iid),
                    None,
                )
                if it is None:
                    continue
                variants = (products.get(it.get("product_id")) or {}).get("variants") or {}
                if new_iid not in variants:
                    reasons.append(f"variant {new_iid} not a variant of product {it.get('product_id')}")
            pm = args.get("payment_method_id")
            if pm is not None and pm not in user_pms:
                reasons.append(f"payment method {pm} not owned by user {order.get('user_id')}")
        return (len(reasons) == 0), reasons

    def check_tools_exist(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        tools = self.load_tools()
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            if a.name not in tools:
                reasons.append(f"unknown tool '{a.name}' (gt_action)")
        ec = (candidate.task or {}).get("evaluation_criteria") or {}
        for a in ec.get("actions") or []:
            n = (a or {}).get("name")
            if n and n not in tools:
                reasons.append(f"unknown tool '{n}' (evaluation action)")
        return (len(reasons) == 0), reasons

    def check_tool_args(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        tools = self.load_tools()
        reasons: List[str] = []
        for a in candidate.effective_gt_actions():
            spec = tools.get(a.name)
            if spec is None:
                continue
            params = spec.get("schema", {}).get("function", {}).get("parameters", {})
            props = set((params.get("properties") or {}).keys())
            required = set(params.get("required") or [])
            given = set((a.arguments or {}).keys())
            missing = required - given
            unknown = given - props
            if missing:
                reasons.append(f"{a.name}: missing required args {sorted(missing)}")
            if unknown:
                reasons.append(f"{a.name}: unknown args {sorted(unknown)}")
        return (len(reasons) == 0), reasons

    def check_gt_nontrivial(self, candidate: TaskCandidate) -> Tuple[bool, List[str]]:
        """Non-triviality, branched on the task's declared INTENT (mirrors airline).

        fulfill: the agent must DO something, so a fulfill gt must contain at least
                 one DB-mutating WRITE (a read-only/empty gt means explore never
                 converged -- a generation failure, not a valid task).
        refuse:  the CORRECT behavior is to make NO state change, so an empty or
                 read-only gt is exactly right -- never reject it for "no write".
                 (Requiring a WRITE here was the false premise that silently killed
                 ALL 614 refusal tasks in the v5 retail round-1 synth; airline fixed
                 this long ago, retail was ported before the fix.)
        """
        gt = candidate.effective_gt_actions()
        if candidate.blueprint.is_refusal():
            # A refusal's gt is read-only / empty by design; that is the point.
            return True, []
        if not gt:
            return False, ["empty gt_actions: no transaction"]
        bp = candidate.blueprint
        names = [a.name for a in gt]
        if bp.resolution_tool and bp.resolution_tool not in names:
            return False, [f"gt missing required resolution_tool '{bp.resolution_tool}'"]
        write_tools = self._write_tool_names()
        if not any(n in write_tools for n in names):
            return False, ["gt has no DB-mutating WRITE action"]
        return True, []

    def _write_tool_names(self) -> set:
        """Names of WRITE-type tools (authoritative, from the env toolkit)."""
        from tau2.environment.toolkit import get_tool_types

        env = self.make_environment()
        types = {n: t.value for n, t in get_tool_types(env.tools).items()}
        return {n for n, t in types.items() if t == "write"}

    # =====================================================================
    # filter / coverage hooks
    # =====================================================================
    def compute_difficulty(self, candidate: TaskCandidate) -> str:
        n = len(candidate.effective_gt_actions())
        counts = self._cfg.get("difficulty_action_counts", {"easy": 1, "medium": 2, "hard": 3})
        if n <= counts.get("easy", 1):
            return "easy"
        if n <= counts.get("medium", 2):
            return "medium"
        return "hard"

    def entity_signature(self, candidate: TaskCandidate) -> str:
        """Signature over (transaction family + the order + the exact write args)
        for near-dup detection. Two tasks that perform the same transaction on the
        same order with the same arguments are near-duplicates regardless of NL."""
        acts = [
            (a.name, json.dumps(a.arguments, sort_keys=True))
            for a in candidate.effective_gt_actions()
        ]
        payload: Dict[str, Any] = {
            "family": candidate.blueprint.task_family,
            "acts": sorted(acts),
        }
        if not acts:
            payload["refusal"] = self._refusal_content_key(candidate)
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()
