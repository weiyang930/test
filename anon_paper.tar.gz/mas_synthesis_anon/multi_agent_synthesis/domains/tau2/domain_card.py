"""DomainCard: the structured, env-derived knowledge the Planner consumes.

The card has two layers, built by very different processes:

1. **Auto-introspected factual layer** (this module's ``introspect_*`` fns).
   Pulled directly from the *live* tau2 telecom env and the DB pydantic schema --
   never from any official task corpus. This layer is mechanical and therefore
   *complete by construction*: every DB table, every tool (with its authoritative
   READ/WRITE/GENERIC type), and every env-assertion family. No hand-typed
   tool/assertion lists -> nothing silently omitted.

2. **Curated archetype layer** (``archetypes.yaml``, validated separately).
   The fault->fix->assertion "resolution archetypes" that define the coverage
   atoms. Hand-authored once, but every archetype is replay-validated against the
   env (must reach reward==1) before it is trusted. Lives outside this module so
   the factual layer can never be polluted by guesses.

The Planner (Phase B) consumes the merged card; the acceptance dashboard
(Phase C) checks the planner's blueprint set against the card's affordance
inventory (all WRITE tools forced, all assertion families covered, etc.).

This module imports ONLY the tau2 Environment half (via the adapter's env
constructor) -- never the agent/orchestrator half.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ...env_bootstrap import ensure_tau2_importable

ensure_tau2_importable()

from tau2.environment.toolkit import get_tool_types  # noqa: E402


# ===========================================================================
# dataclasses describing the factual layer
# ===========================================================================
@dataclass
class ToolSpec:
    """One tool the env exposes, with its authoritative classification."""

    name: str
    actor: str  # "assistant" | "user"
    tool_type: str  # "read" | "write" | "generic" (from env, authoritative)
    parameters: List[str] = field(default_factory=list)
    # Full JSON-schema ``properties`` dict for the tool args, preserved so
    # nested object/enum structure can be rendered for synth agents. ``parameters``
    # (top-level names only) is kept for back-compat with existing consumers.
    param_schema: Dict[str, Any] = field(default_factory=dict)
    description: str = ""

    @property
    def is_mutating(self) -> bool:
        return self.tool_type == "write"


@dataclass
class TableSpec:
    """One DB table (entity collection) + its field schema."""

    name: str  # "customers", "lines", ...
    item_model: str  # "Customer", "Line", ...
    primary_key: Optional[str]
    fields: Dict[str, str]  # field -> type string
    mutable_fields: List[str] = field(default_factory=list)


@dataclass
class DomainCard:
    """The full structured domain knowledge fed to the Planner."""

    domain: str
    # --- factual layer (auto-introspected) ---
    tables: Dict[str, TableSpec]
    enums: Dict[str, List[str]]  # AccountStatus -> [...], LineStatus -> [...]
    assistant_tools: Dict[str, ToolSpec]
    user_tools: Dict[str, ToolSpec]
    device_state_fields: Dict[str, Any]  # MockPhoneAttributes fault surface
    surroundings_fields: Dict[str, Any]  # UserSurroundings fault surface
    assertion_families: List[str]  # env_assertion func names available
    # --- curated layer (filled from archetypes.yaml, validated separately) ---
    archetypes: List[Dict[str, Any]] = field(default_factory=list)
    # --- composition layer (replay-validated feasible multi-atom sets) ---
    # Which archetype atoms can co-exist on one line (the planner draws composite
    # tasks ONLY from this validated set, never an ad-hoc cartesian product). Keys:
    #   feasible_pairs: List[[id, id]]   feasible_triples: List[[id, id, id]]
    #   excluded:       List[id]         (escalation / assertion-less, solo only)
    composition: Dict[str, Any] = field(default_factory=dict)

    # convenience views -----------------------------------------------------
    @property
    def mutating_assistant_tools(self) -> List[str]:
        return [n for n, s in self.assistant_tools.items() if s.is_mutating]

    @property
    def read_assistant_tools(self) -> List[str]:
        return [n for n, s in self.assistant_tools.items() if s.tool_type == "read"]

    @property
    def identity_tools(self) -> List[str]:
        """Read tools that resolve a customer (the identity-path axis)."""
        return [n for n in self.assistant_tools if n.startswith("get_customer_by_")]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "tables": {
                n: {
                    "item_model": t.item_model,
                    "primary_key": t.primary_key,
                    "fields": t.fields,
                    "mutable_fields": t.mutable_fields,
                }
                for n, t in self.tables.items()
            },
            "enums": self.enums,
            "assistant_tools": {
                n: {
                    "actor": s.actor,
                    "tool_type": s.tool_type,
                    "parameters": s.parameters,
                }
                for n, s in self.assistant_tools.items()
            },
            "user_tools": {
                n: {"tool_type": s.tool_type, "parameters": s.parameters}
                for n, s in self.user_tools.items()
            },
            "device_state_fields": self.device_state_fields,
            "surroundings_fields": self.surroundings_fields,
            "assertion_families": self.assertion_families,
            "archetypes": self.archetypes,
            "composition": self.composition,
        }


# ===========================================================================
# introspection helpers
# ===========================================================================
def _resolve_type(prop: Dict[str, Any]) -> str:
    """Render a pydantic JSON-schema property as a short type string."""
    if "type" in prop:
        return prop["type"]
    if "$ref" in prop:
        return prop["$ref"].split("/")[-1]
    if "anyOf" in prop:
        parts = []
        for sub in prop["anyOf"]:
            if sub.get("type") == "null":
                continue
            parts.append(_resolve_type(sub))
        return "|".join(parts) or "null"
    if "items" in prop:
        return f"array[{_resolve_type(prop['items'])}]"
    return "any"


# heuristic primary keys by table (the *_id field matching the singular).
_PK_HINT = {
    "customers": "customer_id",
    "lines": "line_id",
    "bills": "bill_id",
    "devices": "device_id",
    "plans": "plan_id",
}


def introspect_db_schema(db) -> "tuple[Dict[str, TableSpec], Dict[str, List[str]]]":
    """Extract table specs + enum value sets from the DB pydantic model."""
    schema = db.model_json_schema()
    defs = schema.get("$defs", {})

    # enums first (used to annotate field types).
    enums: Dict[str, List[str]] = {}
    for name, d in defs.items():
        if "enum" in d:
            enums[name] = list(d["enum"])

    tables: Dict[str, TableSpec] = {}
    for table_name, finfo in (schema.get("properties") or {}).items():
        item_ref = (finfo.get("items") or {}).get("$ref")
        if not item_ref:
            continue
        model = item_ref.split("/")[-1]
        model_def = defs.get(model, {})
        props = model_def.get("properties", {})
        fields = {p: _resolve_type(pi) for p, pi in props.items()}
        pk = _PK_HINT.get(table_name)
        # mutable fields = everything except the primary key and immutable refs.
        # (we keep this broad; the curated archetype layer pins exact effects.)
        mutable = [f for f in fields if f != pk]
        tables[table_name] = TableSpec(
            name=table_name,
            item_model=model,
            primary_key=pk,
            fields=fields,
            mutable_fields=mutable,
        )
    return tables, enums


def render_param_schema(props: Dict[str, Any], _depth: int = 0) -> str:
    """Render a JSON-schema ``properties`` dict as a compact, human-readable
    nested arg signature so synth agents see object/enum structure instead of
    just top-level key names.

    Example (get_user_preferences):
        preference_categories:{points_of_interest:{airports:bool, ...}, ...}

    Falls back gracefully for flat args (returns just ``name:type``).
    """
    if not props or _depth > 3:  # guard runaway recursion
        return ""
    parts: List[str] = []
    for name, spec in props.items():
        if not isinstance(spec, dict):
            parts.append(str(name))
            continue
        t = spec.get("type")
        enum = spec.get("enum")
        sub = spec.get("properties")
        if enum:
            vals = "|".join(str(v) for v in enum[:8])
            parts.append(f"{name}:enum[{vals}]")
        elif t == "object" and isinstance(sub, dict) and sub:
            parts.append(f"{name}:{{{render_param_schema(sub, _depth + 1)}}}")
        elif t == "array":
            item = spec.get("items") or {}
            it = item.get("type") or "any"
            if item.get("properties"):
                it = "{" + render_param_schema(item["properties"], _depth + 1) + "}"
            parts.append(f"{name}:[{it}]")
        else:
            parts.append(f"{name}:{t or 'any'}")
    return ", ".join(parts)


def _tool_specs(toolkit, tool_objs, actor: str) -> Dict[str, ToolSpec]:
    """Build ToolSpecs from env tool objects, annotated with the toolkit's
    authoritative READ/WRITE/GENERIC types. ``tool_objs`` come from
    ``env.get_tools()`` / ``env.get_user_tools()`` (real Tool objects)."""
    types = {n: t.value for n, t in get_tool_types(toolkit).items()}
    out: Dict[str, ToolSpec] = {}
    for tool in tool_objs:
        s = tool.openai_schema
        props = s.get("function", {}).get("parameters", {}).get("properties", {}) or {}
        params = list(props.keys())
        out[tool.name] = ToolSpec(
            name=tool.name,
            actor=actor,
            tool_type=types.get(tool.name, "read"),
            parameters=params,
            param_schema=props,
            description=(s.get("function", {}).get("description", "") or "")[:200],
        )
    return out


def _model_field_surface(db, model_name: str) -> Dict[str, Any]:
    """Flatten a user-side state model's fields into name -> type/enum values."""
    schema = db.model_json_schema()
    defs = schema.get("$defs", {})
    d = defs.get(model_name, {})
    out: Dict[str, Any] = {}
    for p, pi in (d.get("properties") or {}).items():
        ref = pi.get("$ref")
        if ref:
            dn = ref.split("/")[-1]
            sub = defs.get(dn, {})
            out[p] = sub.get("enum") or list((sub.get("properties") or {}).keys()) or dn
        else:
            out[p] = _resolve_type(pi)
    return out


def introspect_assertion_families(env) -> List[str]:
    """All env-assertion functions (assert_*) on assistant + user toolkits."""
    names: set = set()
    for kit in (env.tools, env.user_tools):
        for attr in dir(kit):
            if attr.startswith("assert_") and callable(getattr(kit, attr)):
                names.add(attr)
    return sorted(names)


# ===========================================================================
# public entrypoint
# ===========================================================================
def build_factual_card(adapter) -> DomainCard:
    """Build the auto-introspected factual layer of the DomainCard.

    ``adapter`` is a Tau2*Adapter instance (gives us ``make_environment`` and
    ``domain``). The curated archetype layer is attached separately by
    :func:`load_archetypes` after replay-validation.
    """
    env = adapter.make_environment()
    db = env.tools.db
    user_db = env.user_tools.db

    tables, enums = introspect_db_schema(db)
    assistant_tools = _tool_specs(env.tools, env.get_tools(), "assistant")
    user_tools = _tool_specs(env.user_tools, env.get_user_tools() or [], "user")
    device_fields = _model_field_surface(user_db, "MockPhoneAttributes")
    surroundings = _model_field_surface(user_db, "UserSurroundings")
    assertion_families = introspect_assertion_families(env)

    return DomainCard(
        domain=adapter.domain,
        tables=tables,
        enums=enums,
        assistant_tools=assistant_tools,
        user_tools=user_tools,
        device_state_fields=device_fields,
        surroundings_fields=surroundings,
        assertion_families=assertion_families,
    )


_ARCHETYPES_YAML = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "configs", "telecom_archetypes.yaml"
)


# The archetype catalog stores placeholder tokens ({{customer_id}}/{{line_id}}/
# {{phone}}/{{name}}) instead of hardcoded entity ids. They are bound to a real
# entity pulled live from the env DB at load time, so the catalog never depends
# on a specific DB snapshot. Bill ids minted *during* a scenario (e.g.
# new_bill_id) are NOT tokens -- they are arbitrary new ids the scenario
# creates, not DB lookups.
def pick_live_entity(adapter) -> Dict[str, Any]:
    """Grab one Active customer + Active line + phone from the live env DB.

    Generic: reads only the env's own DB (no task corpus, no hardcoded ids).
    Mirrors ArchetypeSynthesizer._pick_entity so the archetype catalog and the
    auto-synthesizer ground on the same kind of real entity.
    """
    db = adapter.make_environment().tools.db.model_dump()
    customers = db.get("customers") or []
    lines = db.get("lines") or []
    plans = {p.get("plan_id"): p for p in (db.get("plans") or [])}
    line_by_id = {l.get("line_id"): l for l in lines}

    def _record(c, ln) -> Dict[str, Any]:
        limit = plans.get(ln.get("plan_id"), {}).get("data_limit_gb")
        return {
            "customer_id": c.get("customer_id"),
            "line_id": ln.get("line_id"),
            "phone": ln.get("phone_number"),
            "name": c.get("full_name") or c.get("name"),
            # data_used that puts the line just over its plan limit, so a small
            # refuel reliably clears the overage on ANY plan (snapshot-free).
            "data_used_over_limit": round((limit + 0.1), 1) if limit is not None else 15.1,
        }

    for c in customers:
        if c.get("account_status") != "Active":
            continue
        for lid in c.get("line_ids") or []:
            ln = line_by_id.get(lid)
            if ln and ln.get("status") == "Active":
                return _record(c, ln)
    c = customers[0] if customers else {}
    lid = (c.get("line_ids") or [None])[0]
    ln = line_by_id.get(lid, {}) or {}
    return _record(c, ln)


def _bind_tokens(obj: Any, mapping: Dict[str, Any]) -> Any:
    """Recursively replace placeholder tokens in nested dict/list structures."""
    if isinstance(obj, dict):
        return {k: _bind_tokens(v, mapping) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_bind_tokens(v, mapping) for v in obj]
    if isinstance(obj, str) and obj in mapping:
        return mapping[obj]
    return obj


def bind_archetype_entities(
    archetypes: List[Dict[str, Any]], entity: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """Bind the catalog's entity placeholders to a concrete live entity."""
    mapping = {
        "{{customer_id}}": entity.get("customer_id"),
        "{{line_id}}": entity.get("line_id"),
        "{{phone}}": entity.get("phone"),
        "{{name}}": entity.get("name"),
        "{{data_used_over_limit}}": entity.get("data_used_over_limit"),
    }
    return [_bind_tokens(a, mapping) for a in archetypes]


def load_archetypes(
    path: str = _ARCHETYPES_YAML, adapter: Any = None
) -> List[Dict[str, Any]]:
    """Load the curated archetype catalog (the coverage atoms).

    These are hand-authored but replay-validated separately by
    ``validate_archetypes.py`` (every archetype must reach reward==1). We do NOT
    re-validate here -- the validator is the gate; this loader just reads the
    trusted catalog into the card.

    The catalog stores entity placeholders ({{customer_id}}/{{line_id}}/
    {{phone}}/{{name}}) instead of hardcoded ids. When ``adapter`` is given, they
    are bound to a real Active entity pulled live from the env DB, so the catalog
    is portable across DB snapshots. Without an adapter the raw tokens are
    returned (only useful for inspection, not replay).
    """
    import yaml

    with open(path) as f:
        data = yaml.safe_load(f)
    archetypes = data.get("archetypes", [])
    if adapter is not None:
        archetypes = bind_archetype_entities(archetypes, pick_live_entity(adapter))
    return archetypes


def merge_auto_archetypes(
    hand: List[Dict[str, Any]], auto: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """Union auto-synthesized atoms into the hand catalog, deduped by assertion.

    The hand catalog is the curated REGRESSION set; the auto-synthesizer is the
    primary, portable path. We only adopt an auto-atom whose ``primary_assertion``
    is not already the primary of some hand archetype -- i.e. auto-atoms close the
    *coverage holes* the hand catalog leaves, without duplicating atoms it already
    realizes (which would just bloat the Type-1 grid with redundant cells).

    Mechanical, no hand lists: the set difference over primary_assertion decides
    what is added. When the hand catalog is eventually retired this same call with
    ``hand=[]`` yields a pure auto-derived atom set.
    """
    hand_primaries = {a.get("primary_assertion") for a in hand if a.get("primary_assertion")}
    merged = list(hand)
    for a in auto:
        if a.get("primary_assertion") not in hand_primaries:
            merged.append(a)
    return merged


def build_domain_card(
    adapter,
    validate: bool = False,
    include_auto_archetypes: bool = True,
    discover_extra_assertions: bool = True,
    include_composition: bool = True,
    composition_triples: bool = True,
) -> DomainCard:
    """Build the full DomainCard: factual layer + curated archetype layer.

    This is the Planner-facing entrypoint. The factual layer is auto-introspected
    (complete by construction); the archetype layer is the hand catalog unioned
    with the env-derived auto-synthesized atoms (the auto layer is the portable
    primary path; see :func:`merge_auto_archetypes`). Set ``validate=True`` to
    additionally replay-check every hand archetype against a fresh env before
    trusting it (slower; the standalone validator is the normal gate). Set
    ``include_auto_archetypes=False`` to get the hand catalog alone (regression).

    When ``discover_extra_assertions`` is on, a replay-adjudicated pass attaches
    any resolvable terminal-state assertion that is a natural byproduct of an
    existing fix (e.g. a refuel also clears the data-usage-exceeded flag and keeps
    the line Active) as an ``extra_assertion`` -- closing coverage holes whose
    verifying assertion needs entity args but no new fault/fix path.
    """
    card = build_factual_card(adapter)
    archetypes = load_archetypes(adapter=adapter)
    if validate:
        from .validate_archetypes import validate_all

        report = validate_all(verbose=False)
        failed = [r["id"] for r in report["results"] if not r["ok"]]
        if failed:
            raise ValueError(
                f"archetype catalog has unvalidated entries (reward!=1): {failed}. "
                "Fix the replay_template before using the card."
            )
    if include_auto_archetypes or discover_extra_assertions:
        from .archetype_synthesizer import ArchetypeSynthesizer

        synth = ArchetypeSynthesizer(adapter)
        if include_auto_archetypes:
            archetypes = merge_auto_archetypes(
                archetypes, synth.canonical_archetypes()
            )
        if discover_extra_assertions:
            split = synth.resolvability_split()
            obligation = split["resolvable"] + split["needs_entity"]
            archetypes = synth.discover_extra_assertions(archetypes, obligation)
    card.archetypes = archetypes
    if include_composition:
        card.composition = _load_or_build_composition(
            adapter, archetypes, composition_triples
        )
    return card


# ===========================================================================
# composition feasibility cache (replay-validated; expensive to recompute)
# ===========================================================================
_COMPOSITION_CACHE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "configs", "composition_cache.json"
)


def _composition_fingerprint(
    adapter, archetypes: List[Dict[str, Any]], triples: bool
) -> str:
    """A hash that changes iff the feasible set could change: the atom set (ids +
    their replay_templates) AND the live env DB. Either drifting invalidates the
    cached matrix, so we never serve a stale feasible set."""
    import hashlib

    atom_sig = json.dumps(
        sorted(
            [a.get("id"), a.get("replay_template")] for a in archetypes
        ),
        sort_keys=True,
        default=str,
    )
    try:
        db = adapter.make_environment().tools.db.model_dump()
        db_sig = json.dumps(db, sort_keys=True, default=str)
    except Exception:
        db_sig = ""
    payload = f"triples={triples}\n{atom_sig}\n{db_sig}"
    return hashlib.sha256(payload.encode()).hexdigest()


def _load_or_build_composition(
    adapter, archetypes: List[Dict[str, Any]], triples: bool
) -> Dict[str, Any]:
    """Return the feasible composition matrix, reusing the on-disk cache when the
    fingerprint matches. The replay probe is expensive (~25s with triples), and
    the result only changes when atoms or the env DB change -- exactly what the
    fingerprint covers -- so caching is safe and keeps every card build fast."""
    fp = _composition_fingerprint(adapter, archetypes, triples)
    try:
        with open(_COMPOSITION_CACHE) as f:
            cached = json.load(f)
        if cached.get("fingerprint") == fp:
            return cached["composition"]
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        pass

    from .composition_probe import CompositionProbe

    probe = CompositionProbe(adapter, archetypes=archetypes)
    composition = probe.run(do_triples=triples).to_card_dict()
    try:
        with open(_COMPOSITION_CACHE, "w") as f:
            json.dump({"fingerprint": fp, "composition": composition}, f, indent=2)
    except OSError:
        pass  # cache is an optimization; never fail the build on a write error
    return composition
