"""Tau2 domain adapters (telecom first)."""

from .base_adapter import Tau2BaseAdapter

__all__ = ["Tau2BaseAdapter"]
