"""Domain adapters. The pipeline depends only on :class:`DomainAdapter`."""

from .base import DomainAdapter

_REGISTRY = {}


def register_adapter(name: str):
    def _wrap(cls):
        _REGISTRY[name] = cls
        cls.name = name
        return cls

    return _wrap


def get_adapter(name: str, **kwargs) -> DomainAdapter:
    """Lazily import and instantiate the adapter registered under ``name``."""
    if name not in _REGISTRY:
        # Lazy import of known adapters so unrelated deps aren't pulled in.
        if name == "telecom":
            from .tau2.telecom_adapter import Tau2TelecomAdapter  # noqa: F401
        elif name == "retail":
            from .tau2.retail_adapter import Tau2RetailAdapter  # noqa: F401
        elif name == "airline":
            from .tau2.airline_adapter import Tau2AirlineAdapter  # noqa: F401
        elif name == "car":
            from .car.adapter import CarBenchAdapter  # noqa: F401
    if name not in _REGISTRY:
        raise KeyError(f"No domain adapter registered for '{name}'.")
    return _REGISTRY[name](**kwargs)


__all__ = ["DomainAdapter", "register_adapter", "get_adapter"]
