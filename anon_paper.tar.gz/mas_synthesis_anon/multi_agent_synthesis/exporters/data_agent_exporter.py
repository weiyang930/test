"""DataAgentSFTExporter: emit the generation step as training data.

This is the seed corpus for the long-term goal -- training a *data-generation
agent*. Each record pairs the abstract control input (blueprint + the generation
intent) with the concrete, verified task the LLM produced. A future agent can be
SFT'd on (blueprint -> verified task) pairs, then improved with RL using the same
verifiers as the reward signal.
"""

from __future__ import annotations

from typing import Any

from .base import BaseExporter
from ..schemas import TaskCandidate
from ..schemas.report_schema import TrajectoryVerificationReport


class DataAgentSFTExporter(BaseExporter):
    relative_path = "accepted/data_agent_sft.jsonl"

    def build_record(
        self,
        candidate: TaskCandidate,
        trajectory_report: TrajectoryVerificationReport,
    ) -> Any:
        if not trajectory_report.passed:
            return None
        gt = [
            {"actor": a.actor, "name": a.name, "arguments": a.arguments}
            for a in candidate.effective_gt_actions()
        ]
        return {
            "input": {
                "blueprint": candidate.blueprint.model_dump(),
            },
            "output": {
                "task": candidate.task,
                "gt_actions": gt,
                "assertions": candidate.assertions,
                "expected_solution_outline": candidate.expected_solution_outline,
                "skill_necessity_rationale": candidate.skill_necessity_rationale,
            },
            "verification": {
                "final_reward": trajectory_report.final_reward,
                "repaired": trajectory_report.repaired,
            },
            "generation_metadata": candidate.generation_metadata.model_dump(),
        }
