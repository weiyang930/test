"""SFTTrajectoryExporter: emit the verified ground-truth resolving trajectory.

The record captures the (effective) ground-truth action sequence plus the
replay trace that proved it reaches reward 1.0. Downstream this is the "gold
solution" an SFT pipeline can format into messages. We keep it format-neutral
(actions + replay log) rather than baking in a chat template here.
"""

from __future__ import annotations

from typing import Any

from .base import BaseExporter
from ..schemas import TaskCandidate
from ..schemas.report_schema import TrajectoryVerificationReport


class SFTTrajectoryExporter(BaseExporter):
    relative_path = "accepted/sft_trajectories.jsonl"

    def build_record(
        self,
        candidate: TaskCandidate,
        trajectory_report: TrajectoryVerificationReport,
    ) -> Any:
        # Only export trajectories that actually passed verification.
        if not trajectory_report.passed:
            return None
        gt = [
            {"actor": a.actor, "name": a.name, "arguments": a.arguments}
            for a in candidate.effective_gt_actions()
        ]
        return {
            "task_id": candidate.task_id,
            "domain": candidate.blueprint.domain,
            "ticket": candidate.task.get("ticket"),
            "user_scenario": candidate.task.get("user_scenario"),
            "gt_actions": gt,
            "assertions": candidate.assertions,
            "expected_solution_outline": candidate.expected_solution_outline,
            "skill_necessity_rationale": candidate.skill_necessity_rationale,
            "replay_log": trajectory_report.replay_trajectory,
            "final_reward": trajectory_report.final_reward,
            "repaired": trajectory_report.repaired,
        }
