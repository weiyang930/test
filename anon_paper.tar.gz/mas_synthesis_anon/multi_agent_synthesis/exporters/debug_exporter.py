"""DebugBundleExporter: one human-readable per-candidate bundle.

Unlike the JSONL exporters, this writes a single ``debug_bundle.json`` into the
candidate's own dir, collecting everything a human needs to understand the
candidate at a glance: blueprint, task, gt actions, assertions, and the replay
outcome. Useful when triaging why a candidate passed or failed.
"""

from __future__ import annotations

from ..logging_utils.artifact_logger import ArtifactLogger
from ..schemas import TaskCandidate
from ..schemas.report_schema import (
    TaskVerificationReport,
    TrajectoryVerificationReport,
)


class DebugBundleExporter:
    def __init__(self, logger: ArtifactLogger):
        self.logger = logger

    def export(
        self,
        candidate: TaskCandidate,
        task_report: TaskVerificationReport,
        trajectory_report: TrajectoryVerificationReport,
        kept: bool,
    ) -> str:
        bundle = {
            "candidate_id": candidate.candidate_id,
            "task_id": candidate.task_id,
            "kept": kept,
            "blueprint": candidate.blueprint.model_dump(),
            "task": candidate.task,
            "gt_actions": [
                {"actor": a.actor, "name": a.name, "arguments": a.arguments}
                for a in candidate.effective_gt_actions()
            ],
            "assertions": candidate.assertions,
            "task_verification": task_report.model_dump(),
            "trajectory_verification": trajectory_report.model_dump(),
        }
        return self.logger.save_json(candidate.candidate_id, "debug_bundle.json", bundle)
