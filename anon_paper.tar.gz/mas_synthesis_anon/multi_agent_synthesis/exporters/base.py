"""Shared exporter base: a thin wrapper over the ArtifactLogger's jsonl sink."""

from __future__ import annotations

from typing import Any

from ..logging_utils.artifact_logger import ArtifactLogger
from ..schemas import TaskCandidate
from ..schemas.report_schema import TrajectoryVerificationReport


class BaseExporter:
    """Exporters append one JSONL record per accepted candidate."""

    relative_path: str = "accepted/export.jsonl"

    def __init__(self, logger: ArtifactLogger):
        self.logger = logger
        self.count = 0

    def export(
        self,
        candidate: TaskCandidate,
        trajectory_report: TrajectoryVerificationReport,
    ) -> None:
        record = self.build_record(candidate, trajectory_report)
        if record is not None:
            self.logger.append_jsonl(self.relative_path, record)
            self.count += 1

    def build_record(
        self,
        candidate: TaskCandidate,
        trajectory_report: TrajectoryVerificationReport,
    ) -> Any:
        raise NotImplementedError
