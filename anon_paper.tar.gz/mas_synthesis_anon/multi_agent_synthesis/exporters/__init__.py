"""Exporters: turn accepted candidates into downstream training artifacts.

Three sinks, all JSONL, written under the run's ``accepted/`` dir:

  - RLTaskExporter        -> accepted/rl_tasks.jsonl
        tau2-ready task objects (the env + evaluation_criteria) for RL rollouts.
  - SFTTrajectoryExporter -> accepted/sft_trajectories.jsonl
        the ground-truth resolving trajectory (replay) as an SFT example.
  - DataAgentSFTExporter  -> accepted/data_agent_sft.jsonl
        the (blueprint -> task) generation step itself, as training data for a
        future data-generation agent.

A DebugBundleExporter writes a single human-readable per-candidate bundle.
"""

from .rl_exporter import RLTaskExporter
from .sft_exporter import SFTTrajectoryExporter
from .data_agent_exporter import DataAgentSFTExporter
from .debug_exporter import DebugBundleExporter

__all__ = [
    "RLTaskExporter",
    "SFTTrajectoryExporter",
    "DataAgentSFTExporter",
    "DebugBundleExporter",
]
