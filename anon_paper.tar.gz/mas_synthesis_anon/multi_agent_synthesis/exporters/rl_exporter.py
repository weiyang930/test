"""RLTaskExporter: emit tau2-ready task objects for RL rollouts.

Each record is the concrete task body (with id, user_scenario, initial_state,
evaluation_criteria) plus light provenance. This is exactly what an RL trainer
needs to spin up the env and score rollouts deterministically -- no ground-truth
actions are included (the policy must discover them).
"""

from __future__ import annotations

from typing import Any

from .base import BaseExporter
from ..schemas import TaskCandidate
from ..schemas.report_schema import TrajectoryVerificationReport


class RLTaskExporter(BaseExporter):
    relative_path = "accepted/rl_tasks.jsonl"

    def build_record(
        self,
        candidate: TaskCandidate,
        trajectory_report: TrajectoryVerificationReport,
    ) -> Any:
        return {
            "task_id": candidate.task_id,
            "domain": candidate.blueprint.domain,
            "task": candidate.task,
            "provenance": {
                "candidate_id": candidate.candidate_id,
                "blueprint_id": candidate.blueprint.blueprint_id,
                "task_family": candidate.blueprint.task_family,
                "target_skill_pattern": candidate.blueprint.target_skill_pattern,
                "difficulty_level": candidate.blueprint.difficulty_level,
                "verified_reward": trajectory_report.final_reward,
                "repaired": trajectory_report.repaired,
            },
        }
