"""ArtifactLogger: persists every module input/output for every candidate.

Run directory layout (created lazily)::

    runs/run_YYYYMMDD_HHMMSS_<tag>/
        configs/        # snapshot of the configs used
        candidates/
            candidate_000001/
                blueprint.json
                generator_input.json
                generator_output_raw.txt
                generator_output_parsed.json
                task_verifier_report.json
                trajectory_verifier_report.json
                trajectory_repair_attempts.jsonl
                replay_log.jsonl
                filter_report.json
                final_task.json
                gt_actions.json
                metadata.json
        accepted/   tasks.jsonl, sft_trajectories.jsonl, data_agent_sft.jsonl, full_candidates.jsonl
        rejected/   rejected_tasks.jsonl, rejection_summary.json
        reports/    coverage_report.json, verifier_stats.json, filter_stats.json, run_summary.json

The logger is intentionally dumb and side-effect-only: it knows paths, not
pipeline semantics. It is safe to call from multiple threads (appends are
serialized with a lock); for multi-process runners, prefer per-candidate dirs
(always unique) and reduce jsonl appends in the parent.
"""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from typing import Any


def _utcstamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _to_jsonable(obj: Any) -> Any:
    """Best-effort conversion of pydantic / dataclass objects to plain JSON."""
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if hasattr(obj, "model_dump"):  # pydantic v2
        return obj.model_dump()
    if hasattr(obj, "dict"):  # pydantic v1 fallback
        return obj.dict()
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    return obj


class ArtifactLogger:
    def __init__(self, run_dir: str):
        self.run_dir = os.path.abspath(run_dir)
        self._lock = threading.Lock()
        for sub in ("configs", "candidates", "accepted", "rejected", "reports"):
            os.makedirs(os.path.join(self.run_dir, sub), exist_ok=True)

    # ------------------------------------------------------------------ paths
    @classmethod
    def create_run_dir(cls, base_dir: str, tag: str = "synthesis_run") -> str:
        path = os.path.join(base_dir, f"run_{_utcstamp()}_{tag}")
        os.makedirs(path, exist_ok=True)
        return path

    def candidate_dir(self, candidate_id: str) -> str:
        return os.path.join(self.run_dir, "candidates", candidate_id)

    def create_candidate(self, candidate_id: str) -> str:
        path = self.candidate_dir(candidate_id)
        os.makedirs(path, exist_ok=True)
        return path

    # ------------------------------------------------------------- per-candidate
    def save_json(self, candidate_id: str, name: str, obj: Any) -> str:
        self.create_candidate(candidate_id)
        path = os.path.join(self.candidate_dir(candidate_id), name)
        with open(path, "w") as f:
            json.dump(_to_jsonable(obj), f, indent=2, ensure_ascii=False)
        return path

    def save_text(self, candidate_id: str, name: str, text: str) -> str:
        self.create_candidate(candidate_id)
        path = os.path.join(self.candidate_dir(candidate_id), name)
        with open(path, "w") as f:
            f.write(text if text is not None else "")
        return path

    def append_candidate_jsonl(self, candidate_id: str, name: str, obj: Any) -> str:
        self.create_candidate(candidate_id)
        path = os.path.join(self.candidate_dir(candidate_id), name)
        with open(path, "a") as f:
            f.write(json.dumps(_to_jsonable(obj), ensure_ascii=False) + "\n")
        return path

    # ----------------------------------------------------------------- aggregate
    def append_jsonl(self, relative_path: str, obj: Any) -> str:
        """Append to a run-relative jsonl path, e.g. 'accepted/tasks.jsonl'."""
        path = os.path.join(self.run_dir, relative_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with self._lock:
            with open(path, "a") as f:
                f.write(json.dumps(_to_jsonable(obj), ensure_ascii=False) + "\n")
        return path

    def save_report(self, name: str, obj: Any) -> str:
        path = os.path.join(self.run_dir, "reports", name)
        with open(path, "w") as f:
            json.dump(_to_jsonable(obj), f, indent=2, ensure_ascii=False)
        return path

    def save_config_snapshot(self, name: str, obj: Any) -> str:
        path = os.path.join(self.run_dir, "configs", name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if name.endswith((".yaml", ".yml")):
            import yaml

            with open(path, "w") as f:
                yaml.safe_dump(_to_jsonable(obj), f, sort_keys=False, allow_unicode=True)
        else:
            with open(path, "w") as f:
                json.dump(_to_jsonable(obj), f, indent=2, ensure_ascii=False)
        return path
