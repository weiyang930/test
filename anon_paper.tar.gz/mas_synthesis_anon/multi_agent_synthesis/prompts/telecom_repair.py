"""Repair prompt builder for telecom ground-truth action sequences.

When a candidate's gt_actions don't drive the env to a passing state, the
TrajectoryVerifier asks the LLM to propose a corrected action sequence. The
repair prompt hands the model: the task, the current (failing) actions, the
replay log (what each action did + errors), the target assertions, and the tool
catalog -- and asks for a corrected gt_actions array as strict JSON.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Tuple

REPAIR_PROMPT_VERSION = "telecom_repair"

_SYSTEM = """You are repairing the ground-truth action sequence for a tau2-bench \
TELECOM troubleshooting task. The current sequence FAILS: after applying it, the \
required assertions do not all pass. Produce a corrected MINIMAL sequence of \
actions that, applied from the task's initial state, makes ALL assertions pass.

Rules:
- Use ONLY tools/user-actions from the provided catalog; never invent names/args.
- Output STRICT JSON only: an object {"gt_actions": [ ... ]} and nothing else.
- Each action: {"actor": "user"|"assistant", "name": <tool>, "arguments": {...}}.
- Keep it minimal: only the actions needed to resolve the injected fault(s)."""


def _format_tools(tools: Dict[str, Any]) -> str:
    lines: List[str] = []
    for name, spec in sorted(tools.items()):
        fn = spec.get("schema", {}).get("function", {})
        params = (fn.get("parameters", {}) or {}).get("properties", {}) or {}
        required = set((fn.get("parameters", {}) or {}).get("required") or [])
        args = ", ".join(
            f"{p}{'*' if p in required else ''}:{i.get('type','any')}"
            for p, i in params.items()
        )
        lines.append(f"  - [{spec.get('actor')}] {name}({args})")
    return "\n".join(lines)


def build_repair_prompt(
    *,
    task_body: Dict[str, Any],
    current_actions: List[Dict[str, Any]],
    replay_log: List[Dict[str, Any]],
    assertions: List[Dict[str, Any]],
    failure_reasons: List[str],
    tools: Dict[str, Any],
) -> Tuple[str, str]:
    init = (task_body or {}).get("initial_state", {})
    user_parts = [
        "## TASK TICKET",
        str(task_body.get("ticket", "")),
        "",
        "## INITIAL STATE (faults injected here)",
        json.dumps(init.get("initialization_actions", []), indent=1),
        "",
        "## TARGET ASSERTIONS (must all be TRUE after your actions)",
        json.dumps(assertions, indent=1),
        "",
        "## CURRENT (FAILING) gt_actions",
        json.dumps(current_actions, indent=1),
        "",
        "## REPLAY LOG (what happened when the current actions ran)",
        json.dumps(replay_log, indent=1),
        "",
        "## FAILURE REASONS",
        "\n".join(f"- {r}" for r in failure_reasons) or "- (assertions did not pass)",
        "",
        "## TOOL CATALOG",
        _format_tools(tools),
        "",
        'Output the corrected sequence as strict JSON: {"gt_actions": [...]}',
    ]
    return _SYSTEM, "\n".join(user_parts)
