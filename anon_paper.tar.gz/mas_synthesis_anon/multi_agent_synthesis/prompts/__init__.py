"""Prompt templates (repair prompts shared by the trajectory verifiers)."""
