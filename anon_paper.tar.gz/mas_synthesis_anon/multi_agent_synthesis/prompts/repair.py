"""v0 repair prompt builder (DB-hash reward; in-place writes, no assertions).

When a v0 candidate's pseudo-GT actions don't replay to reward==1, this asks the
LLM to PROPOSE a corrected action sequence. Unlike telecom_repair (which targets
env_assertions), v0/airline/retail are judged by the DB-state hash: the corrected
sequence must drive the STOCK db to the intended end-state purely through
in-place writes against EXISTING entities (no minted ids/timestamps).

The proposal is NOT trusted -- the same deterministic replay re-decides. The LLM
only proposes; the gate accepts only if reward==1.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Tuple

REPAIR_PROMPT_VERSION = "repair_v1"

_SYSTEM = """You are repairing the ground-truth action sequence for a tool-use \
task judged by the resulting DATABASE STATE (a db-state hash, not assertions). \
The current sequence FAILS: replaying it does not produce the intended final \
database state. Produce a corrected MINIMAL sequence of state-changing tool \
calls that, applied from the task's initial state, reaches the intended end \
state.

Rules:
- Use ONLY tools from the provided catalog; never invent tool names or arguments.
- Bind every argument to a REAL entity id present in the task / replay log; do \
NOT invent ids.
- Prefer IN-PLACE modifications of EXISTING entities. Do NOT use actions that \
mint brand-new ids or timestamps (those break the deterministic db-hash).
- Output STRICT JSON only: an object {"gt_actions": [ ... ]} and nothing else.
- Each action: {"actor": "assistant"|"user", "name": <tool>, "arguments": {...}}.
- Keep it minimal: only the state-changing actions needed to reach the goal."""


def _format_tools(tools: Dict[str, Any]) -> str:
    lines: List[str] = []
    for name, spec in sorted(tools.items()):
        fn = spec.get("schema", {}).get("function", {})
        params = (fn.get("parameters", {}) or {}).get("properties", {}) or {}
        required = set((fn.get("parameters", {}) or {}).get("required") or [])
        # ``properties`` can carry non-dict siblings (e.g. a stray
        # ``additionalProperties: false`` emitted by some tool schemas, seen in
        # car's calculate_datetime). Guard so a bool/None value doesn't crash the
        # whole repair-prompt build (which was being swallowed as a None outcome
        # and mislabelled synth_task_timeout upstream).
        args = ", ".join(
            f"{p}{'*' if p in required else ''}:"
            f"{i.get('type', 'any') if isinstance(i, dict) else 'any'}"
            for p, i in params.items()
            if isinstance(i, dict)
        )
        lines.append(f"  - [{spec.get('actor')}] {name}({args})")
    return "\n".join(lines)


def build_repair_prompt(
    *,
    task_body: Dict[str, Any],
    hidden_task_spec: Dict[str, Any],
    current_actions: List[Dict[str, Any]],
    replay_log: List[Dict[str, Any]],
    failure_reasons: List[str],
    tools: Dict[str, Any],
) -> Tuple[str, str]:
    instr = (task_body or {}).get("user_scenario", {}).get("instructions", {})
    goal = (hidden_task_spec or {}).get("expected_completion_criteria") or []
    facts = (hidden_task_spec or {}).get("ground_truth_facts") or []
    user_parts = [
        "## USER REQUEST",
        json.dumps(instr, ensure_ascii=False, indent=1),
        "",
        "## INTENDED FINAL STATE (must hold after your actions)",
        json.dumps(goal, ensure_ascii=False, indent=1),
        "",
        "## GROUND-TRUTH FACTS (real entities, do not contradict)",
        json.dumps(facts, ensure_ascii=False, indent=1),
        "",
        "## CURRENT (FAILING) gt_actions",
        json.dumps(current_actions, ensure_ascii=False, indent=1),
        "",
        "## REPLAY LOG (what happened when the current actions ran)",
        json.dumps(replay_log, ensure_ascii=False, indent=1),
        "",
        "## FAILURE REASONS",
        "\n".join(f"- {r}" for r in failure_reasons) or "- (db state did not match)",
        "",
        "## TOOL CATALOG",
        _format_tools(tools),
        "",
        'Output the corrected sequence as strict JSON: {"gt_actions": [...]}',
    ]
    return _SYSTEM, "\n".join(user_parts)
