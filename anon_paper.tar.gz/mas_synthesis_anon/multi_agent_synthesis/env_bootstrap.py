"""Make the local pinned tau2-bench fork importable.

We reuse the *Environment* half of the local tau2-bench fork (state machine +
tools + hashing + evaluator) -- see the §6.6 "two halves of tau2" split. This
module puts that fork's ``src`` on ``sys.path`` exactly once, so the rest of the
package can ``import tau2`` without caring where it lives.

The path is overridable via the ``TAU2_BENCH_SRC`` env var for portability.
"""

from __future__ import annotations

import os
import sys

_DEFAULT_TAU2_SRC = (
    "/path/to/tau2-bench/src"
)

_BOOTSTRAPPED = False


def ensure_tau2_importable() -> str:
    """Idempotently add the tau2 fork ``src`` dir to ``sys.path``.

    Returns the resolved src path. Raises if it cannot be found.
    """
    global _BOOTSTRAPPED
    src = os.environ.get("TAU2_BENCH_SRC", _DEFAULT_TAU2_SRC)
    if not os.path.isdir(src):
        raise FileNotFoundError(
            f"tau2-bench src not found at '{src}'. "
            "Set TAU2_BENCH_SRC to the fork's src directory."
        )
    if src not in sys.path:
        sys.path.insert(0, src)
    _BOOTSTRAPPED = True
    return src
