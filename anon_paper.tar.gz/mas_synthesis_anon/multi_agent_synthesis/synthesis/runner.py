"""Pluggable concurrency backend for per-candidate work.

The pipeline's per-candidate stage (generate -> verify -> trajectory -> filter)
is I/O-bound (LLM calls) and CPU-light, and the tau2 env must be importable in
the worker -- which rules out the verl/ray venv. So the default backend is a
thread pool (shares the imported tau2 module, good for I/O concurrency). A
serial backend is provided for deterministic debugging, and a Ray backend is
left as an opt-in stub for when a tau2-capable Ray cluster is available.

A runner is just ``map(fn, items) -> list`` with a chosen execution strategy.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from typing import Callable, Iterable, List, Optional, TypeVar

T = TypeVar("T")
R = TypeVar("R")


class SerialRunner:
    """Run tasks one at a time. Deterministic; best for debugging."""

    def map(
        self,
        fn: Callable[[T], R],
        items: Iterable[T],
        task_timeout: Optional[float] = None,
    ) -> List[R]:
        # task_timeout is ignored serially (a serial run has no other work to
        # protect); accepted only to keep the runner interface uniform.
        return [fn(x) for x in items]


class ThreadPoolRunner:
    """Thread-pool backend. Default: good for LLM-I/O-bound per-candidate work."""

    def __init__(self, max_workers: int = 8):
        self.max_workers = max_workers

    def map(
        self,
        fn: Callable[[T], R],
        items: Iterable[T],
        task_timeout: Optional[float] = None,
    ) -> List[R]:
        """Map ``fn`` over ``items``, preserving input order.

        If ``task_timeout`` is set, any task that does not finish within that many
        seconds yields ``None`` in its slot instead of blocking the batch. This
        bounds a wedged call (e.g. a hung SSL recv on the un-watchdogged worker-
        thread Bedrock path); the underlying thread leaks but the batch proceeds.
        """
        items = list(items)
        if not items:
            return []
        if task_timeout is None:
            with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
                return list(ex.map(fn, items))
        # With a timeout we must NOT block on a wedged worker at executor exit, so
        # we drive the futures ourselves and shut down WITHOUT waiting. A timed-out
        # task yields None in its slot; its thread leaks but the batch proceeds.
        ex = ThreadPoolExecutor(max_workers=self.max_workers)
        try:
            futures = [ex.submit(fn, x) for x in items]
            results: List[R] = []
            # Each future gets the full task_timeout. They run concurrently, so
            # waiting on an earlier (possibly wedged) future does not consume the
            # budget of later ones -- those finish in the background meanwhile.
            for fut in futures:
                try:
                    results.append(fut.result(timeout=task_timeout))
                except FutureTimeout:
                    fut.cancel()
                    results.append(None)  # type: ignore[arg-type]
                except Exception:  # noqa: BLE001 - surface as a dropped slot
                    # A raised exception is NOT a wall-clock timeout. Print the
                    # traceback so a per-candidate crash (e.g. a malformed tool
                    # schema breaking the repair-prompt build) is visible instead
                    # of being silently collapsed to None and mislabelled
                    # synth_task_timeout by the caller.
                    import traceback
                    traceback.print_exc()
                    results.append(None)  # type: ignore[arg-type]
            return results
        finally:
            ex.shutdown(wait=False)


def get_runner(backend: str = "thread", max_workers: int = 8):
    """Factory for the configured backend."""
    backend = (backend or "thread").lower()
    if backend in ("serial", "sync", "none"):
        return SerialRunner()
    if backend in ("thread", "threads", "threadpool"):
        return ThreadPoolRunner(max_workers=max_workers)
    if backend == "ray":
        raise NotImplementedError(
            "Ray backend is not enabled: the verl/ray venv cannot import tau2. "
            "Use 'thread' (default) or 'serial'."
        )
    raise ValueError(f"Unknown runner backend: {backend!r}")
