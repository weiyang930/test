"""Synthesis pipeline stages: planner, generator, and the run orchestrator."""
