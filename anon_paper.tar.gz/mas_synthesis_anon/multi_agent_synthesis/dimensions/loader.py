"""DimensionSpec: load + validate a swappable v0 dimension yaml.

The yaml shape (see ``areal_sea.yaml``)::

    shared_keys: [task_family, policy_or_constraint_focus, ...]
    selection_rules: {key: {min, max}, ...}
    difficulty_profile: {easy: {...}, medium: {...}, hard: {...}}
    domains:
      <domain>:
        dimension_values: {key: [vals...], ...}
        difficulty: {...}          # optional per-domain override

A loaded :class:`DimensionSpec` exposes ``for_domain(domain)`` -> a
:class:`DomainDimensions` view that the v0 Planner Agent renders into its prompt
and validates the LLM's selection against. Nothing here talks to tau2 or the
env -- this is pure config, deliberately decoupled from the domain card.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

import yaml


@dataclass
class DomainDimensions:
    """One domain's dimension view: per-key value lists + difficulty knobs."""

    domain: str
    shared_keys: List[str]
    selection_rules: Dict[str, Dict[str, int]]
    dimension_values: Dict[str, List[str]]
    difficulty_profile: Dict[str, Dict[str, Any]]
    cross_rules: List[Dict[str, Any]] = field(default_factory=list)

    def values_for(self, key: str) -> List[str]:
        return list(self.dimension_values.get(key, []))

    def difficulty_controls(self, level: str) -> Dict[str, Any]:
        """The control knobs (expected_tool_calls, ...) for a difficulty level."""
        return dict(self.difficulty_profile.get(level, {}))

    def selection_bounds(self, key: str) -> "tuple[int, int]":
        rule = self.selection_rules.get(key, {})
        return int(rule.get("min", 1)), int(rule.get("max", 1))

    def to_planner_json(self) -> Dict[str, Any]:
        """The exact JSON block injected into the Planner Agent's user prompt."""
        return {
            "domain": self.domain,
            "dimension_values": self.dimension_values,
            "difficulty_interpretation": self.difficulty_profile,
        }

    def validate_selection(self, selected: Dict[str, Any]) -> List[str]:
        """Return a list of violations (empty == valid) for an LLM selection.

        Checks: only known KEYS, count within selection_rules. Values are NOT
        required to be in the value list -- the macro layer may propose new
        values to open up uncovered directions, and the micro planner is allowed
        to choose them (they flow through to the generator). The deterministic
        replay reward remains the real quality gate.
        """
        problems: List[str] = []
        for key in self.shared_keys:
            lo, hi = self.selection_bounds(key)
            raw = selected.get(key)
            vals = self._as_list(raw)
            if len(vals) < lo or len(vals) > hi:
                problems.append(
                    f"{key}: selected {len(vals)} value(s), expected [{lo},{hi}]"
                )
        extra = set(selected) - set(self.shared_keys)
        if extra:
            problems.append(f"unknown dimension keys: {sorted(extra)}")
        problems.extend(self._cross_rule_violations(selected))
        return problems

    # the gt_write_count buckets in ascending order; used by require_min_write_bucket.
    _WRITE_BUCKET_ORDER = ["0", "1", "2", "3-4", "5+"]

    def _cross_rule_violations(self, selected: Dict[str, Any]) -> List[str]:
        """Enforce the yaml's cross_rules (empty -> no-op, e.g. v1).

        Each rule has a ``when`` map (key -> list of trigger values); if the
        selection's value for that key is in the list, the rule FIRES and its
        ``require_*`` clauses must hold. Supported clauses:
          * require_non_single_composition: task_composition != "single"
          * require_write_bucket: gt_write_count == <value>
          * require_min_write_bucket: gt_write_count index >= <value>'s index
        """
        problems: List[str] = []
        for rule in self.cross_rules:
            when = rule.get("when") or {}
            fired = all(
                self._norm_single(selected.get(k)) in [str(x) for x in (v or [])]
                for k, v in when.items()
            )
            if not when or not fired:
                continue
            label = ", ".join(f"{k}={v}" for k, v in when.items())
            comp = self._norm_single(selected.get("task_composition"))
            wbucket = self._norm_single(selected.get("gt_write_count"))
            if rule.get("require_non_single_composition") and comp == "single":
                problems.append(
                    f"cross_rule [{label}]: task_composition must not be 'single'")
            req_wb = rule.get("require_write_bucket")
            if req_wb is not None and wbucket != str(req_wb):
                problems.append(
                    f"cross_rule [{label}]: gt_write_count must be '{req_wb}'")
            min_wb = rule.get("require_min_write_bucket")
            if min_wb is not None:
                order = self._WRITE_BUCKET_ORDER
                cur_i = order.index(wbucket) if wbucket in order else -1
                min_i = order.index(str(min_wb)) if str(min_wb) in order else 0
                if cur_i < min_i:
                    problems.append(
                        f"cross_rule [{label}]: gt_write_count must be at least '{min_wb}'")
        return problems

    @staticmethod
    def _norm_single(raw: Any) -> str:
        if isinstance(raw, list):
            return str(raw[0]) if raw else ""
        return str(raw or "")

    @staticmethod
    def _as_list(raw: Any) -> List[str]:
        if raw is None:
            return []
        if isinstance(raw, str):
            return [raw]
        if isinstance(raw, list):
            return [str(x) for x in raw]
        return [str(raw)]


@dataclass
class DimensionSpec:
    """A whole dimension yaml: shared schema + every domain's value lists."""

    path: str
    shared_keys: List[str]
    selection_rules: Dict[str, Dict[str, int]]
    difficulty_profile: Dict[str, Dict[str, Any]]
    domains: Dict[str, Dict[str, Any]]
    cross_rules: List[Dict[str, Any]] = field(default_factory=list)

    def has_domain(self, domain: str) -> bool:
        return domain in self.domains

    def for_domain(self, domain: str) -> DomainDimensions:
        if domain not in self.domains:
            raise KeyError(
                f"domain '{domain}' not in dimension spec {self.path} "
                f"(have: {sorted(self.domains)})"
            )
        dconf = self.domains[domain]
        dim_values = dconf.get("dimension_values") or {}
        # per-domain difficulty override, else the shared one.
        diff = dconf.get("difficulty") or self.difficulty_profile
        missing = [k for k in self.shared_keys if k not in dim_values]
        if missing:
            raise ValueError(
                f"domain '{domain}' in {self.path} missing dimension_values for: {missing}"
            )
        return DomainDimensions(
            domain=domain,
            shared_keys=list(self.shared_keys),
            selection_rules=self.selection_rules,
            dimension_values=dim_values,
            difficulty_profile=diff,
            cross_rules=list(self.cross_rules),
        )


def load_dimensions(path: str) -> DimensionSpec:
    """Load + lightly validate a dimension yaml into a :class:`DimensionSpec`."""
    with open(path, "r") as f:
        raw: Dict[str, Any] = yaml.safe_load(f) or {}
    shared_keys = list(raw.get("shared_keys") or [])
    if not shared_keys:
        raise ValueError(f"{path}: missing 'shared_keys'")
    domains = dict(raw.get("domains") or {})
    if not domains:
        raise ValueError(f"{path}: missing 'domains'")
    return DimensionSpec(
        path=path,
        shared_keys=shared_keys,
        selection_rules=dict(raw.get("selection_rules") or {}),
        difficulty_profile=dict(raw.get("difficulty_profile") or {}),
        domains=domains,
        cross_rules=list(raw.get("cross_rules") or []),
    )
