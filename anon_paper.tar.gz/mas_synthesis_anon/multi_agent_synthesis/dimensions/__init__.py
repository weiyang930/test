"""Swappable dimension-value definitions for the v0 synthesis paradigm.

A dimension yaml (e.g. ``areal_sea.yaml``) defines the fixed dimension keys
+ per-domain value lists the v0 Planner Agent selects from. Swap definitions by
adding a new yaml and pointing the run config / CLI at it -- no code changes.
"""

from .loader import DimensionSpec, DomainDimensions, load_dimensions

__all__ = ["DimensionSpec", "DomainDimensions", "load_dimensions"]
