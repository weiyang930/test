"""TaskVerifier: the cheap, static "is this task even well-formed?" gate.

Runs the adapter's hard checks (no LLM, no replay reward) and aggregates them
into a :class:`TaskVerificationReport`. A candidate that fails here is rejected
before we spend a replay/evaluation on it.

The checks (all delegated to the domain adapter):
  - entities_exist      : every referenced id is real
  - tools_exist         : every action/assertion names a real tool/assert func
  - tool_args           : arguments match the tool schema
  - initial_state       : the initial_state loads into a fresh env
  - evaluator_callable  : the evaluation_criteria can actually be evaluated
  - not_solved_at_init  : the task is NOT already satisfied at init

The order is cheapest-first; we still run them all so the report is complete,
but callers can short-circuit on the first failure if they prefer.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Set, Tuple

from ..domains.base import DomainAdapter
from ..schemas import TaskCandidate
from ..schemas.report_schema import TaskVerificationReport

# Which write tool(s) "realize" each airline task_family. Families with no direct
# write tool (e.g. loyalty lookups, pure inquiries) map to the empty set and are
# excluded from the per-family coverage requirement. Used by the composition gate
# to detect a multi-family plan that silently collapsed to a single write.
_AIRLINE_FAMILY_WRITES: Dict[str, Set[str]] = {
    "flight_booking": {"book_reservation"},
    "flight_change": {"update_reservation_flights"},
    "flight_cancellation": {"cancel_reservation"},
    "refund_or_compensation": {"send_certificate", "cancel_reservation"},
    "seat_or_baggage_service": {
        "update_reservation_baggages",
        "update_reservation_passengers",
    },
    "loyalty_or_membership_service": set(),
}
_AIRLINE_WRITE_TOOLS: Set[str] = {
    "book_reservation",
    "update_reservation_flights",
    "cancel_reservation",
    "send_certificate",
    "update_reservation_baggages",
    "update_reservation_passengers",
}
# Read/lookup tools that ground a write (inspect the entity, compare fares, read a
# balance) without changing the DB. The base-50 eval set's judging chains are full
# of these (get_reservation_details alone appears 57x across 50 tasks); a v3 gt that
# jumps straight to writes with no preceding read is the degenerate shape that makes
# the GT-agent rollout trajectory too short and skips the "verify-then-act" skill.
_AIRLINE_READ_TOOLS: Set[str] = {
    "get_reservation_details",
    "get_user_details",
    "search_direct_flight",
    "search_onestop_flight",
    "list_all_airports",
    "get_flight_status",
    "calculate",
}


def check_composition_conformance(
    candidate: TaskCandidate,
) -> Tuple[bool, List[str]]:
    """Reject tasks whose realized GT does not honor the blueprint's task_composition.

    This closes the measured "multi-intent label -> single-write GT" leak: a
    'sequence' plan that names 2-3 families but resolves to one write is not a
    multi-intent task. Semantics per composition:
      - single        : no constraint here (other checks cover it).
      - sequence + fulfill : every family is carried out, so each writeable family
                        must be covered by a matching write AND >=2 distinct write
                        tools must appear (genuine multi-intent, not one tool
                        repeated). This is the shape that collapsed in P0.
      - sequence + mixed   : one family is fulfilled and another is correctly
                        REFUSED (its write is intentionally absent), so we only
                        require >=1 resolving write -- the refused family has no GT
                        write by design.
      - conditional_fallback : the fallback branch must resolve -> >=1 write.
      - parallel_mix  : the compliant side writes, the forbidden side does not ->
                        >=1 write (exactly-one-side is not structurally checkable
                        here; refusal-absence is enforced by the replay gate).
    Refusal tasks are exempt (their GT is intentionally empty).

    Note: a family with no dedicated write tool (refund_or_compensation -- refunds
    are a side effect of cancel, or are refused) does not demand its own write.
    """
    bp = candidate.blueprint
    if bp.is_refusal():
        return True, []
    comp = bp.task_composition()
    if comp == "single":
        return True, []

    # Airline-specific tool mapping; other domains pass through until they define one.
    if bp.domain != "airline":
        return True, []

    write_names = [
        a.name for a in candidate.effective_gt_actions()
        if a.name in _AIRLINE_WRITE_TOOLS
    ]
    distinct_writes = set(write_names)
    n_writes = len(write_names)

    # mixed/fallback/parallel all have at least one family that is correctly
    # refused (no write), so they only need the compliant side to resolve.
    if comp in ("conditional_fallback", "parallel_mix") or bp.expected_outcome() == "mixed":
        if n_writes < 1:
            return False, [
                f"composition={comp} (outcome={bp.expected_outcome()}) requires "
                f">=1 resolving write, GT has 0"
            ]
        return True, []

    if comp == "sequence":  # fulfill sequence: every writeable family must resolve
        families = bp.task_families()
        writeable = [f for f in families if _AIRLINE_FAMILY_WRITES.get(f)]
        covered = [
            f for f in writeable
            if distinct_writes & _AIRLINE_FAMILY_WRITES.get(f, set())
        ]
        # Need a distinct write per writeable family (>=2 when 2+ families write).
        need = min(2, len(writeable)) if writeable else 2
        problems: List[str] = []
        if len(writeable) >= 2 and len(distinct_writes) < 2:
            problems.append(
                f"composition=sequence (fulfill) needs >=2 distinct write tools, "
                f"GT has {sorted(distinct_writes) or 'none'}"
            )
        if writeable and len(covered) < need:
            uncovered = [f for f in writeable if f not in covered]
            problems.append(
                f"composition=sequence (fulfill): families {uncovered} have no "
                f"covering write in GT (covered {covered}/{writeable})"
            )
        if problems:
            return False, problems
        return True, []

    return True, []


# v3 write-count buckets -> the inclusive [lo, hi] range of real write actions
# the realized GT must fall in (hi=None means open-ended). Mirrors the buckets in
# dimensions/areal_sea.yaml::gt_write_count.
_WRITE_COUNT_RANGES: Dict[str, Tuple[int, "int | None"]] = {
    "0": (0, 0),
    "1": (1, 1),
    "2": (2, 2),
    "3-4": (3, 4),
    "5+": (5, None),
}


def check_write_count_conformance(
    candidate: TaskCandidate,
) -> Tuple[bool, List[str]]:
    """Reject tasks whose realized GT write-count contradicts the plan's
    gt_write_count bucket (the v3 WRITE-COUNT axis).

    This closes the "gt_write_count label -> fewer-write GT" leak (the v3 analogue
    of the round3 composition collapse): a plan that claims '3-4' but resolves to a
    single write would otherwise be filed into the '3-4' coverage cell, inflating
    the reported multi-write coverage with tasks that did not realize it. Counting
    only WRITE actions (reads do not count) makes the cell label match the GT.

    Legacy/v1 blueprints carry no gt_write_count (empty) -> no-op. Refusal tasks
    declare bucket '0' and their GT is empty, so they pass naturally.
    """
    bp = candidate.blueprint
    bucket = bp.gt_write_count()
    rng = _WRITE_COUNT_RANGES.get(bucket)
    if rng is None:  # empty (legacy) or an unknown bucket -> do not gate
        return True, []

    # Domain write-tool set. airline is the only domain with v3 axes today; other
    # domains pass through until they define one.
    if bp.domain == "airline":
        write_tools = _AIRLINE_WRITE_TOOLS
    else:
        return True, []

    n_writes = sum(
        1 for a in candidate.effective_gt_actions() if a.name in write_tools
    )
    lo, hi = rng
    if n_writes < lo or (hi is not None and n_writes > hi):
        hi_txt = "inf" if hi is None else str(hi)
        return False, [
            f"gt_write_count bucket '{bucket}' expects [{lo},{hi_txt}] write "
            f"actions, realized GT has {n_writes}"
        ]
    return True, []


def check_read_grounding(
    candidate: TaskCandidate,
) -> Tuple[bool, List[str]]:
    """Reject tasks whose GT writes are not grounded by any preceding read.

    The base-50 eval judging chains are read-then-write (inspect the reservation /
    look up a balance / compare fares, THEN modify). A v3 gt that contains only
    write actions teaches the GT-agent rollout to act without verifying state,
    producing a 2-step trajectory that misses the "lookup-then-act" skill the eval
    set's hard tasks (14/23/44 etc.) hinge on. We require: any task with >=1 write
    must also contain >=1 read/lookup action. Refusal tasks (0 writes) and pure
    read tasks pass; reads do not affect DB-hash judging, so this never changes
    which final state is correct -- only the SHAPE of the gt chain.
    """
    bp = candidate.blueprint
    if bp.domain != "airline":  # only airline defines v3 read/write sets today
        return True, []
    actions = candidate.effective_gt_actions()
    n_writes = sum(1 for a in actions if a.name in _AIRLINE_WRITE_TOOLS)
    if n_writes == 0:  # refusal / pure-read task -- nothing to ground
        return True, []
    n_reads = sum(1 for a in actions if a.name in _AIRLINE_READ_TOOLS)
    if n_reads == 0:
        return False, [
            f"GT has {n_writes} write(s) but 0 read/lookup actions -- a grounded "
            f"solution must inspect state before writing (eval chains are "
            f"read-then-write); add the get_*/search_* calls the writes depend on"
        ]
    return True, []


class TaskVerifier:
    def __init__(
        self,
        adapter: DomainAdapter,
        enable_action_basis: bool = False,
        enable_write_count_gate: bool = False,
        enable_read_grounding_gate: bool = False,
    ):
        self.adapter = adapter
        # composition conformance only matters for multi-write ACTION-basis tasks
        # (round3). With ACTION off every task is single-write DB, so the gate is
        # a no-op; skip registering it to keep the check list to the validated set.
        self.enable_action_basis = enable_action_basis
        # v3 write-count conformance: reject GT that does not realize the plan's
        # gt_write_count bucket. Default OFF so v0/v1 are untouched; v3 turns it on
        # because gt_write_count is a coverage axis there and a stale label would
        # inflate the multi-write cells.
        self.enable_write_count_gate = enable_write_count_gate
        # v3 read-grounding: reject GT that writes without any preceding read.
        # Default OFF so v0/v1 are untouched; v3 turns it on so synthesized chains
        # match the eval set's read-then-write shape (and the rollout trajectory is
        # not a degenerate 2-step write-only chain).
        self.enable_read_grounding_gate = enable_read_grounding_gate

    def _checks(
        self,
    ) -> List[Tuple[str, Callable[[TaskCandidate], Tuple[bool, List[str]]]]]:
        a = self.adapter
        checks: List[Tuple[str, Callable[[TaskCandidate], Tuple[bool, List[str]]]]] = [
            ("entities_exist", a.check_entities_exist),
            ("tools_exist", a.check_tools_exist),
            ("tool_args", a.check_tool_args),
            ("initial_state", a.check_initial_state),
            ("evaluator_callable", a.check_evaluator_callable),
            ("not_solved_at_init", a.check_not_solved_at_init),
            ("gt_nontrivial", a.check_gt_nontrivial),
        ]
        if self.enable_action_basis:
            checks.append(("composition_conformance", check_composition_conformance))
        if self.enable_write_count_gate:
            checks.append(("write_count_conformance", check_write_count_conformance))
        if self.enable_read_grounding_gate:
            checks.append(("read_grounding", check_read_grounding))
        return checks

    def verify(
        self, candidate: TaskCandidate, stop_on_first: bool = False
    ) -> TaskVerificationReport:
        report = TaskVerificationReport()
        for name, fn in self._checks():
            try:
                ok, reasons = fn(candidate)
            except Exception as e:  # a check itself blowing up == failure
                ok, reasons = False, [f"{name} raised: {e}"]
            report.checks[name] = bool(ok)
            if not ok:
                report.failure_reasons.extend(f"[{name}] {r}" for r in reasons)
                if stop_on_first:
                    break
        return report.finalize()
