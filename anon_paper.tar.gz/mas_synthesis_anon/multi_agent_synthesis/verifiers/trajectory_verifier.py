"""TrajectoryVerifier (+ Repairer): replay-based ground-truth validity.

This is the expensive gate. It replays a candidate's ground-truth actions
against a fresh env (via the adapter) and checks the deterministic reward. If
the reward is < 1.0 and repair is enabled, it asks the LLM to propose a
corrected action sequence (up to ``max_repair_attempts`` times), re-replaying
each proposal. The first sequence that reaches reward 1.0 is recorded as the
candidate's ``repaired_gt_actions``.

The verifier never invents domain logic: it replays via the adapter and only
uses the LLM to *propose* new action lists, which are then re-validated by the
same deterministic replay. A repair is only accepted if it actually passes.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from ..domains.base import DomainAdapter
from ..llm.base import BaseLLMClient
from ..prompts.telecom_repair import build_repair_prompt
from ..schemas import GTAction, TaskCandidate
from ..schemas.report_schema import TrajectoryVerificationReport


class TrajectoryVerifier:
    def __init__(
        self,
        adapter: DomainAdapter,
        llm: Optional[BaseLLMClient] = None,
        max_repair_attempts: int = 2,
        repair_max_tokens: int = 6000,
    ):
        self.adapter = adapter
        self.llm = llm
        self.max_repair_attempts = max_repair_attempts
        self.repair_max_tokens = repair_max_tokens

    # ------------------------------------------------------------------ public
    def verify(
        self, candidate: TaskCandidate, allow_repair: bool = True
    ) -> TrajectoryVerificationReport:
        report = TrajectoryVerificationReport()

        actions = list(candidate.effective_gt_actions())
        res = self.adapter.replay_gt_actions(candidate, actions)
        report.final_reward = float(res.get("final_reward", 0.0))
        report.replay_trajectory = res.get("replay_log", [])
        report.final_gt_actions = actions

        if res.get("success"):
            report.passed = True
            return report

        report.failure_reasons = list(res.get("failure_reasons", []))

        if not (allow_repair and self.llm is not None and self.max_repair_attempts > 0):
            return report

        # Repair loop: ask the LLM for a corrected action list, re-replay.
        for attempt in range(1, self.max_repair_attempts + 1):
            report.num_repair_attempts = attempt
            proposed = self._propose_repair(candidate, res)
            if not proposed:
                report.failure_reasons.append(f"repair attempt {attempt}: no actions parsed")
                continue
            res = self.adapter.replay_gt_actions(candidate, proposed)
            report.final_reward = float(res.get("final_reward", 0.0))
            report.replay_trajectory = res.get("replay_log", [])
            report.final_gt_actions = proposed
            if res.get("success"):
                candidate.repaired_gt_actions = proposed
                report.passed = True
                report.repaired = True
                return report
            report.failure_reasons.append(
                f"repair attempt {attempt}: reward={report.final_reward}"
            )

        return report

    # ----------------------------------------------------------------- repair
    def _propose_repair(
        self, candidate: TaskCandidate, last_res: Dict[str, Any]
    ) -> List[GTAction]:
        assert self.llm is not None
        tools = self.adapter.load_tools()  # type: ignore[attr-defined]
        current = [
            {"actor": a.actor, "name": a.name, "arguments": a.arguments}
            for a in candidate.effective_gt_actions()
        ]
        system, user = build_repair_prompt(
            task_body=candidate.task,
            current_actions=current,
            replay_log=last_res.get("replay_log", []),
            assertions=candidate.assertions,
            failure_reasons=last_res.get("failure_reasons", []),
            tools=tools,
        )
        resp = self.llm.complete_prompt(system, user, max_tokens=self.repair_max_tokens)
        return self._parse_actions(resp.text)

    @staticmethod
    def _parse_actions(text: str) -> List[GTAction]:
        text = (text or "").strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
        obj: Any = None
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            start, end = text.find("{"), text.rfind("}")
            if start != -1 and end > start:
                try:
                    obj = json.loads(text[start : end + 1])
                except json.JSONDecodeError:
                    return []
        if not isinstance(obj, dict):
            return []
        raw = obj.get("gt_actions") or []
        out: List[GTAction] = []
        for a in raw:
            if isinstance(a, dict) and a.get("name"):
                out.append(
                    GTAction(
                        actor=str(a.get("actor", "user")),
                        name=str(a["name"]),
                        arguments=dict(a.get("arguments") or {}),
                    )
                )
        return out
