"""BaseLLMClient: the single seam between the pipeline and any LLM provider."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class LLMResponse:
    """Normalized response from any client."""

    text: str
    model: str
    raw: Optional[Any] = None
    usage: Dict[str, Any] = field(default_factory=dict)


class BaseLLMClient(ABC):
    """All clients implement a single ``complete`` call.

    ``messages`` follows the OpenAI chat shape
    (``[{"role": "system"|"user"|"assistant", "content": str}, ...]``). The
    client is responsible for translating that to its provider's API.
    """

    model: str = "unknown"

    @abstractmethod
    def complete(
        self,
        messages: List[Dict[str, str]],
        *,
        max_tokens: int = 8000,
        temperature: float = 1.0,
        **kwargs: Any,
    ) -> LLMResponse:
        """Run a single completion and return normalized text."""

    # Convenience wrapper for the common (system, user) prompt shape.
    def complete_prompt(
        self,
        system: str,
        user: str,
        **kwargs: Any,
    ) -> LLMResponse:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user})
        return self.complete(messages, **kwargs)
