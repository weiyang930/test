"""QwenLocalClient: litellm -> a LOCAL vLLM OpenAI-compatible endpoint.

Sibling to :class:`BedrockLLMClient`, used to swap the SYNTHESIS-stage generator
(explore agent + planner) from Opus to a locally-served open model (Qwen3-30B).
The point is to test whether the synthesis pipeline adapts to an open-source
generator -- i.e. whether Qwen-30B-synthesized data still lifts the Qwen-8B
student the way Opus-synthesized data does (Opus cold-start = 68.8%).

Why a separate, much simpler client than Bedrock's:
  - The Bedrock client's forked-child SIGKILL watchdog exists to interrupt wedged
    OpenSSL reads against a REMOTE endpoint. A local vLLM server on the same box
    does not exhibit that failure mode, so a plain litellm call with a real
    wall-clock ``timeout`` + retries is enough.
  - The pipeline only consumes ``.text`` (and optionally ``.usage``); the explore
    loop and planner both parse free-text JSON, so we need no tool-calling shape.

vLLM is served with ``--reasoning-parser qwen3``, so the model's ``<think>``
block is split out into ``message.reasoning_content`` and ``message.content``
holds only the final (JSON) answer -- exactly what the parsers expect.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from .base import BaseLLMClient, LLMResponse

DEFAULT_MODEL = "qwen3-30b"
DEFAULT_API_BASE = "http://localhost:8010/v1"


class QwenLocalClient(BaseLLMClient):
    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        api_base: str = DEFAULT_API_BASE,
        api_key: str = "EMPTY",
        read_timeout: int = 600,
        num_retries: int = 4,
        # enable_thinking is accepted for signature parity with BedrockLLMClient
        # (the pipeline passes it). For a vLLM-served Qwen *thinking* model the
        # think block is produced by the model + stripped by --reasoning-parser;
        # there is no Anthropic-style ``thinking`` request param to set.
        enable_thinking: bool = True,
        # A Qwen3 *thinking* model spends 800-3000+ completion tokens reasoning
        # BEFORE it emits the answer. Callers in this pipeline pass small caps
        # (the planner uses max_tokens=2000), which truncates the model mid-think
        # so it NEVER reaches the JSON answer -> 0 blueprints. We floor max_tokens
        # so the think budget can't starve the answer.
        min_max_tokens: int = 8000,
    ):
        self.model = model
        self.api_base = api_base
        self.api_key = api_key
        self.read_timeout = read_timeout
        self.num_retries = num_retries
        self.enable_thinking = enable_thinking
        self.min_max_tokens = min_max_tokens

    def complete(
        self,
        messages: List[Dict[str, str]],
        *,
        max_tokens: int = 8000,
        temperature: float = 1.0,
        **kwargs: Any,
    ) -> LLMResponse:
        import litellm

        # A thinking model must have room to think AND answer; floor the cap.
        if self.enable_thinking and max_tokens < self.min_max_tokens:
            max_tokens = self.min_max_tokens

        # litellm routes any model to an OpenAI-compatible server when given an
        # ``openai/`` prefix + api_base. vLLM ignores the prefix and matches the
        # served-model-name, so we strip it for the wire ``model`` field.
        call_kwargs: Dict[str, Any] = {
            "model": f"openai/{self.model}",
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "api_base": self.api_base,
            "api_key": self.api_key,
            "timeout": self.read_timeout,
        }
        call_kwargs.update(kwargs)

        attempts = self.num_retries + 1
        last_exc: Optional[BaseException] = None
        for attempt in range(1, attempts + 1):
            try:
                resp = litellm.completion(**call_kwargs)
                return LLMResponse(
                    text=self._extract_text(resp),
                    model=self.model,
                    raw=resp,
                    usage=self._extract_usage(resp),
                )
            except Exception as exc:  # noqa: BLE001 - retry any provider error
                last_exc = exc
                if attempt < attempts:
                    time.sleep(min(2 ** attempt, 15))

        assert last_exc is not None
        raise last_exc

    @classmethod
    def _extract_text(cls, resp: Any) -> str:
        try:
            content = resp.choices[0].message.content
        except (AttributeError, IndexError, KeyError):
            return ""
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    parts.append(block)
            content = "".join(parts)
        return cls._strip_think(str(content or ""))

    @staticmethod
    def _strip_think(text: str) -> str:
        """Drop the Qwen3 thinking block, keeping only the post-think answer.

        vLLM's --reasoning-parser SHOULD move the think block into
        ``reasoning_content`` and leave ``content`` clean. In practice the Qwen3
        thinking model emits the reasoning with only a CLOSING ``</think>`` (the
        opening ``<think>`` is implicit in the chat template), which the parser
        does not match -- so the whole chain-of-thought lands in ``content``
        ahead of the real JSON answer. We strip it ourselves: everything up to
        and including the last ``</think>`` is reasoning; the remainder is the
        answer. A well-formed ``<think>...</think>`` pair is handled by the same
        last-``</think>`` split.
        """
        marker = "</think>"
        idx = text.rfind(marker)
        if idx != -1:
            return text[idx + len(marker):].strip()
        return text.strip()

    @staticmethod
    def _extract_usage(resp: Any) -> Dict[str, Any]:
        usage: Optional[Any] = getattr(resp, "usage", None)
        if usage is None:
            return {}
        try:
            return dict(usage)
        except (TypeError, ValueError):
            return {
                "prompt_tokens": getattr(usage, "prompt_tokens", None),
                "completion_tokens": getattr(usage, "completion_tokens", None),
                "total_tokens": getattr(usage, "total_tokens", None),
            }
