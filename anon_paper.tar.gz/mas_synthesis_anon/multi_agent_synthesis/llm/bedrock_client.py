"""BedrockLLMClient: litellm -> Bedrock with the node's default AWS creds.

This is the proven baseline path: ``litellm.completion(model="bedrock/...")``
picks up the EC2 instance's default credentials (no API key, no role
assumption). It is the only LLM path the tau2 venv can run, since PyAwsHelper
is unavailable there.

Notes learned from the baseline:
  - With extended thinking enabled, ``max_tokens`` MUST exceed the thinking
    budget, so we default to a comfortably large max and a modest budget.
  - We return only the final text (thinking blocks are dropped).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseLLMClient, LLMResponse

# Default to the latest Opus available on Bedrock in this account.
DEFAULT_MODEL = "bedrock/us.anthropic.claude-opus-4-5-20251101-v1:0"
DEFAULT_REGION = "us-east-1"


class BedrockLLMClient(BaseLLMClient):
    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        region: str = DEFAULT_REGION,
        thinking_budget: int = 2048,
        enable_thinking: bool = True,
        read_timeout: int = 180,
        num_retries: int = 4,
        fork_hard_timeout: int = 90,
    ):
        self.model = model
        self.region = region
        self.thinking_budget = thinking_budget
        self.enable_thinking = enable_thinking
        # A single explore/planner call returns within ~1-2 min; cap well below
        # that so a silently-hung request fails fast and is retried, instead of
        # blocking the (serial) planner indefinitely.
        self.read_timeout = read_timeout
        self.num_retries = num_retries
        # Wall-clock budget for the forked-child planner path. A healthy planner
        # call averages ~20s, so 90s comfortably covers a slow-but-progressing
        # response while killing a genuine wedge fast enough that a retry recovers
        # quickly (vs. the old read_timeout+60=240s, which made each wedge cost
        # 4 min and looked like a stall).
        self.fork_hard_timeout = fork_hard_timeout

    def complete(
        self,
        messages: List[Dict[str, str]],
        *,
        max_tokens: int = 8000,
        temperature: float = 1.0,
        **kwargs: Any,
    ) -> LLMResponse:
        import threading
        import time

        import litellm

        # ROOT CAUSE (confirmed by probing the socket read timeout directly):
        # httpx's read timeout is applied PER-RECV via socket.settimeout(180), not
        # as a wall-clock budget for the whole call. A half-open connection that
        # dribbles a few bytes (TCP keepalive / trickle) resets the per-recv timer
        # every time, so ``ssl.recv`` -- and thus the whole call -- NEVER times
        # out. The planner is serial, so one such wedged call froze the entire run.
        #
        # We tried, and EMPIRICALLY RULED OUT, every in-process interrupt:
        #   * litellm ``timeout`` / ``num_retries``  -> never fires (per-recv).
        #   * ``socket.setdefaulttimeout``            -> httpcore overrides it.
        #   * a thread-pool watchdog                  -> can't cancel the hung
        #     thread; abandoning it poisons litellm's shared connection pool.
        #   * a ``SIGALRM`` watchdog                  -> OpenSSL retries on EINTR,
        #     so the Python signal handler is deferred and never runs.
        # Nothing at the Python/socket/signal layer can interrupt a wedged OpenSSL
        # read. The only guaranteed interrupt is OS-level process termination.
        #
        # So on the MAIN thread (the serial planner -- verified via py-spy) we run
        # each call in a FORKED CHILD under a hard wall-clock timeout; if it hangs
        # we SIGKILL the child (unconditional, works wherever it is stuck) and
        # retry. At planner time the process is single-threaded, so ``fork`` is
        # safe and the child inherits the already-warm litellm import via COW (no
        # per-call re-import cost). The 64-worker generation phase runs OFF the
        # main thread, where fork is unsafe; there we fall back to a direct call --
        # acceptable because one wedged worker only loses its own task, it does not
        # freeze the (parallel) run.
        on_main_thread = threading.current_thread() is threading.main_thread()
        hard_timeout = self.fork_hard_timeout

        # Thinking requires max_tokens > thinking_budget.
        if self.enable_thinking and max_tokens <= self.thinking_budget:
            max_tokens = self.thinking_budget + 4000

        call_kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "aws_region_name": self.region,
            "timeout": self.read_timeout,
        }
        if self.enable_thinking:
            # With thinking on, Anthropic requires temperature == 1.
            call_kwargs["temperature"] = 1.0
            call_kwargs["thinking"] = {
                "type": "enabled",
                "budget_tokens": self.thinking_budget,
            }
        else:
            call_kwargs["temperature"] = temperature
        call_kwargs.update(kwargs)

        # We drive retries ourselves (rather than litellm's ``num_retries``) so a
        # hard-watchdog timeout -- which now actually fires -- is retried.
        attempts = self.num_retries + 1
        last_exc: Optional[BaseException] = None
        for attempt in range(1, attempts + 1):
            try:
                if on_main_thread:
                    text, usage = self._completion_forked(
                        call_kwargs, hard_timeout
                    )
                    return LLMResponse(
                        text=text, model=self.model, raw=None, usage=usage
                    )
                resp = litellm.completion(**call_kwargs)
                return LLMResponse(
                    text=self._extract_text(resp),
                    model=self.model,
                    raw=resp,
                    usage=self._extract_usage(resp),
                )
            except Exception as exc:  # noqa: BLE001 - retry any provider error
                last_exc = exc
                if attempt < attempts:
                    # exponential backoff, capped, so transient errors recover.
                    time.sleep(min(2 ** attempt, 15))

        assert last_exc is not None
        raise last_exc

    @classmethod
    def _completion_forked(
        cls,
        call_kwargs: Dict[str, Any],
        hard_timeout: int,
    ):
        """Run one completion in a forked child under a hard wall-clock timeout.

        Returns ``(text, usage)``. If the child exceeds ``hard_timeout`` it is
        SIGKILLed and ``TimeoutError`` is raised; if it dies or errors we raise
        ``RuntimeError`` so the caller's retry loop kicks in. The raw response
        object cannot cross the process boundary, so ``LLMResponse.raw`` is None
        on this path (downstream only uses ``.text`` / ``.usage``).
        """
        import multiprocessing as mp

        ctx = mp.get_context("fork")
        q = ctx.Queue()
        proc = ctx.Process(
            target=cls._fork_worker, args=(q, call_kwargs), daemon=True
        )
        proc.start()
        try:
            status, payload, usage = q.get(timeout=hard_timeout)
        except Exception:  # noqa: BLE001 - includes queue.Empty (timeout)
            proc.terminate()
            proc.join(2)
            if proc.is_alive():
                proc.kill()
                proc.join()
            raise TimeoutError(
                f"litellm.completion exceeded hard watchdog ({hard_timeout}s); "
                "child killed"
            )
        proc.join(5)
        if status != "ok":
            raise RuntimeError(f"forked completion failed: {payload}")
        return payload, (usage or {})

    @classmethod
    def _fork_worker(cls, q: Any, call_kwargs: Dict[str, Any]) -> None:
        try:
            import litellm

            # The child inherits (via COW) litellm's cached httpx client, which
            # holds an open SSL socket fd belonging to the PARENT. Reusing that fd
            # across processes corrupts the TLS connection and can wedge. Clear
            # the cache so the child always dials a fresh connection of its own.
            try:
                cache = getattr(litellm, "in_memory_llm_clients_cache", None)
                if cache is not None and hasattr(cache, "cache_dict"):
                    cache.cache_dict.clear()
            except Exception:  # noqa: BLE001 - best-effort; fresh fork usually clean
                pass

            resp = litellm.completion(**call_kwargs)
            q.put(("ok", cls._extract_text(resp), cls._extract_usage(resp)))
        except Exception as exc:  # noqa: BLE001 - report back, never hang
            q.put(("err", repr(exc), None))

    @staticmethod
    def _extract_text(resp: Any) -> str:
        try:
            choice = resp.choices[0]
            content = choice.message.content
        except (AttributeError, IndexError, KeyError):
            return ""
        if isinstance(content, str):
            return content
        # Some providers return a list of content blocks.
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    parts.append(block)
            return "".join(parts)
        return str(content or "")

    @staticmethod
    def _extract_usage(resp: Any) -> Dict[str, Any]:
        usage: Optional[Any] = getattr(resp, "usage", None)
        if usage is None:
            return {}
        try:
            return dict(usage)
        except (TypeError, ValueError):
            return {
                "prompt_tokens": getattr(usage, "prompt_tokens", None),
                "completion_tokens": getattr(usage, "completion_tokens", None),
                "total_tokens": getattr(usage, "total_tokens", None),
            }
