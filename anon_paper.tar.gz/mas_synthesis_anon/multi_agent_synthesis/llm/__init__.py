"""LLM client abstraction for the synthesis pipeline.

The pipeline talks to models only through :class:`BaseLLMClient`, so the
Generator (and later, verifiers/repairers) never bind to a specific provider.
Two concrete clients ship in V0:

  - :class:`BedrockLLMClient` -- the real path, litellm -> Bedrock with the
    node's default AWS credentials (no API key, no role assumption).
  - :class:`MockLLMClient` -- deterministic canned responses for offline smoke
    tests, so the whole pipeline can run without network access.
  - :class:`QwenLocalClient` -- litellm -> a local vLLM OpenAI endpoint, to run
    the synthesis generator on an open model (Qwen3-30B) instead of Opus.
"""

from .base import BaseLLMClient, LLMResponse
from .bedrock_client import BedrockLLMClient
from .mock_client import MockLLMClient
from .qwen_local_client import QwenLocalClient

__all__ = [
    "BaseLLMClient",
    "LLMResponse",
    "BedrockLLMClient",
    "MockLLMClient",
    "QwenLocalClient",
]
