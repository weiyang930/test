"""MockLLMClient: deterministic canned responses for offline smoke tests.

V1: the structural ground truth (init/gt/assertions) is PINNED by the adapter
from the archetype's validated replay_template -- the LLM (and therefore the
mock) only authors the natural-language shell. So the mock no longer needs a
per-family canned task; it returns a single, schema-valid NL shell for ANY
blueprint. The pinned skeleton supplies everything that makes replay pass, so a
mock smoke run still exercises the full V1 path (generator -> verifiers -> filter
-> export) end-to-end and every accepted task replays to reward==1.

The mock reads the identity path out of the prompt so known_info is consistent
with the required identity axis (the only NL field with a hard constraint).
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from .base import BaseLLMClient, LLMResponse

# NL shell the mock emits for any blueprint. The adapter pins the real skeleton,
# so these prose fields just have to be present + schema-valid (and known_info
# must match the identity path, which we fill in from the prompt).
_SHELL: Dict[str, Any] = {
    "task": {
        "description": {"purpose": "Troubleshoot and resolve the reported issue."},
        "user_scenario": {
            "instructions": {
                "domain": "telecom",
                "reason_for_call": (
                    "Something on my phone isn't working and I need help fixing it."
                ),
                "known_info": "<filled from identity path>",
                "task_instructions": (
                    "Follow the agent's guidance. Ground every answer about your "
                    "device on tool-call results, and perform any user-side action "
                    "the agent asks for. Consider the issue resolved ONLY once the "
                    "agent has confirmed the fix actually worked."
                ),
            }
        },
        "ticket": (
            "Customer reports a device/service problem and wants it resolved and "
            "verified before the call ends."
        ),
    },
    "expected_solution_outline": [
        "Identify the customer/line using the stated identity info.",
        "Diagnose the reported symptom by checking device/service status.",
        "Apply the appropriate resolution (guide the user or call the fix tool).",
        "Verify the issue is resolved before closing.",
    ],
    "skill_necessity_rationale": (
        "The agent must diagnose, apply the correct resolution path, and verify "
        "the fix rather than assuming it worked."
    ),
}


class MockLLMClient(BaseLLMClient):
    def __init__(self, model: str = "mock"):
        self.model = model

    def complete(
        self,
        messages: List[Dict[str, str]],
        *,
        max_tokens: int = 8000,
        temperature: float = 1.0,
        **kwargs: Any,
    ) -> LLMResponse:
        prompt = "\n".join(m.get("content", "") for m in messages)
        shell = json.loads(json.dumps(_SHELL))  # deep copy
        shell["task"]["user_scenario"]["instructions"]["known_info"] = (
            self._known_info_for(prompt)
        )
        return LLMResponse(text=json.dumps(shell), model=self.model, raw=None, usage={})

    @staticmethod
    def _known_info_for(prompt: str) -> str:
        """Make known_info consistent with the required identity path + entity,
        both of which appear in the V1 prompt's CONTRACT/ENTITY blocks.

        The identity path is read from the CONTRACT's ``identity path :`` line --
        NOT by substring-checking the tool name, which always appears in the tool
        catalog regardless of the path the blueprint actually requires."""
        cust = _grep(r"customer_id\s*=\s*([A-Za-z0-9]+)", prompt)
        name = _grep(r"full_name\s*=\s*(.+)", prompt)
        phone = _grep(r"LINE_phone\s*=\s*([0-9\-]+)", prompt)
        identity = _grep(r"identity path\s*:\s*(get_customer_by_\w+)", prompt)
        if identity == "get_customer_by_id":
            return f"Customer id: {cust or 'C1001'}."
        if identity == "get_customer_by_name":
            return f"Name: {name or 'John Smith'}, Date of birth: 1985-06-15."
        # default: by phone
        return f"Name: {name or 'John Smith'}, Phone: {phone or '555-123-2001'}."


def _grep(pattern: str, text: str) -> str:
    m = re.search(pattern, text)
    return m.group(1).strip() if m else ""
