"""Structured objects shared across the synthesis pipeline."""

from .blueprint_schema import TaskBlueprint
from .candidate_schema import (
    GenerationMetadata,
    GTAction,
    TaskCandidate,
)
from .report_schema import (
    AcceptedSample,
    FilterReport,
    RejectedSample,
    TaskVerificationReport,
    TrajectoryVerificationReport,
)

__all__ = [
    "TaskBlueprint",
    "TaskCandidate",
    "GTAction",
    "GenerationMetadata",
    "TaskVerificationReport",
    "TrajectoryVerificationReport",
    "FilterReport",
    "AcceptedSample",
    "RejectedSample",
]
