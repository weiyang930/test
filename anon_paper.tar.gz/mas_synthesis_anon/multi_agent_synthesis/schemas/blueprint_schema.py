"""Structured task blueprint produced by the Planner.

A blueprint is an *abstract* control object: it fixes the task family, the
target skill/failure pattern, and the difficulty level, plus the environment
requirements the domain adapter inferred from those. It deliberately does NOT
name concrete entities (customer ids, line ids, ...) -- that is the Generator's
job. Keeping the blueprint abstract is what makes generation controllable and
reusable across domains.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class TaskBlueprint(BaseModel):
    """An abstract, JSON-serializable task specification.

    A blueprint pins a single **coverage atom** (a validated resolution
    archetype) crossed with the orthogonal Type-1 coverage axes, plus the Type-2
    control axes that only modulate difficulty/diversity. The archetype fields
    are what make generation *verifiable*: they name the exact fault to inject,
    the resolution tool/effect the gold solution must reach, and the env
    assertion that proves resolution -- so the Generator cannot drift into an
    env-unverifiable task.
    """

    blueprint_id: str = Field(description="Unique id for this blueprint.")
    domain: str = Field(description="Domain name, e.g. 'telecom'.")

    task_family: str = Field(description="Task family, e.g. 'mobile_data_issue'.")
    target_skill_pattern: str = Field(
        description="Skill/failure pattern the task must exercise."
    )
    difficulty_level: str = Field(description="One of easy|medium|hard.")

    # --- Type-1 coverage axes (MUST be exhausted by the planner) ----------
    archetype_id: Optional[str] = Field(
        default=None,
        description="Validated resolution archetype this task realizes (coverage atom).",
    )
    identity_path: Optional[str] = Field(
        default=None,
        description="Identity-resolution path: get_customer_by_phone|_id|_name.",
    )
    fix_locus: Optional[str] = Field(
        default=None,
        description="agent_mutation | user_device | escalation (from the archetype).",
    )

    # --- archetype contract: what the generated task MUST realize ---------
    resolution_tool: Optional[str] = Field(
        default=None,
        description="Agent WRITE tool the gold solution must call to fix, or null.",
    )
    primary_assertion: Optional[str] = Field(
        default=None,
        description="Env assertion family that proves the fault is resolved.",
    )
    required_assertions: List[str] = Field(
        default_factory=list,
        description="All env-assertion families the task must include.",
    )
    setup_tools: List[str] = Field(
        default_factory=list,
        description="Tools used ONLY to inject the fault (not part of the fix).",
    )
    escalation_tool: Optional[str] = Field(
        default=None,
        description="For escalation atoms: the transfer tool the agent must call.",
    )
    replay_template: Optional[Dict[str, Any]] = Field(
        default=None,
        description="The validated init_actions+gt_actions+assertions skeleton.",
    )

    # --- composition (depth) axis -----------------------------------------
    # A composite task layers ``depth`` secondary faults on top of the anchor
    # archetype, all bound to ONE entity/line. depth=0 is the (degenerate) single-
    # atom task. The anchor is the coverage atom (``archetype_id``); secondaries
    # are control-only and NEVER enter the coverage denominator. The composite's
    # validated init+gt+assertions live in ``replay_template`` (built and replay-
    # gated by the planner), so the rest of the pipeline consumes it verbatim and
    # is composition-agnostic.
    depth: int = Field(
        default=0,
        description="Number of secondary faults layered on the anchor (0 = single atom).",
    )
    secondary_archetype_ids: List[str] = Field(
        default_factory=list,
        description="Secondary atoms composed onto the anchor (provenance; control-only).",
    )

    # --- Type-2 control axes (balanced, do NOT affect coverage) -----------
    num_faults: int = Field(
        default=1,
        description="Number of independent faults to inject (= depth + 1; difficulty knob).",
    )
    persona: Optional[str] = Field(
        default=None, description="User-simulator persona/style (diversity knob)."
    )

    # Inferred by the domain adapter from the sampled dimensions above.
    environment_requirement: List[str] = Field(
        default_factory=list,
        description="Environment preconditions the generated task must satisfy.",
    )
    generation_intent: str = Field(
        default="",
        description="Natural-language description of what to generate, for the LLM.",
    )

    # Provenance / bookkeeping.
    coverage_key: Optional[str] = Field(
        default=None,
        description="The Type-1 coverage cell key (archetype|identity_path).",
    )

    # --- v0 (dimension-value paradigm) -----------------------------------
    # The v0 Planner Agent does NOT use archetypes; it selects a structured plan
    # from a fixed domain dimension-value schema (5 shared keys). That plan lives
    # here. v1 ignores this field entirely (it stays None on the archetype path),
    # so the two paradigms share one schema without interfering. When set, the v0
    # coverage cell is derived from these dimensions, not from archetype_id.
    dimension_plan: Optional[Dict[str, Any]] = Field(
        default=None,
        description="v0 dimension-value plan: selected_dimensions + difficulty controls.",
    )

    def coverage_cell(self) -> str:
        """The Type-1 coverage cell. Falls back to the legacy key only when no
        archetype is set (so the V0 planner still works)."""
        if self.archetype_id:
            return f"{self.archetype_id}|{self.identity_path or 'any'}"
        return f"{self.task_family}|{self.target_skill_pattern}|{self.difficulty_level}"

    def expected_outcome(self) -> str:
        """The v0 INTENT axis: 'fulfill' (carry out the request) or 'refuse'
        (decline a policy-violating request). Defaults to 'fulfill' so any
        blueprint without the axis (legacy plans, v1) behaves as before."""
        if not self.dimension_plan:
            return "fulfill"
        sd = self.dimension_plan.get("selected_dimensions", {})
        val = sd.get("expected_outcome") or "fulfill"
        return str(val[0] if isinstance(val, list) else val) or "fulfill"

    def is_refusal(self) -> bool:
        return self.expected_outcome() == "refuse"

    def task_composition(self) -> str:
        """The v0 STRUCTURE axis: how the 1-3 task_family values combine.
        One of single | sequence | conditional_fallback | parallel_mix. Defaults
        to 'single' for legacy/v1 plans without the axis."""
        if not self.dimension_plan:
            return "single"
        sd = self.dimension_plan.get("selected_dimensions", {})
        val = sd.get("task_composition") or "single"
        return str(val[0] if isinstance(val, list) else val) or "single"

    def task_families(self) -> List[str]:
        """The intended task_family list (P0: 1-3 families for multi-intent)."""
        if not self.dimension_plan:
            return [self.task_family] if self.task_family else []
        sd = self.dimension_plan.get("selected_dimensions", {})
        raw = sd.get("task_family", self.task_family)
        fams = raw if isinstance(raw, list) else [raw]
        return [str(x) for x in fams if x]

    def gt_write_count(self) -> str:
        """The v3 WRITE-COUNT axis: the bucket the plan claims this task's GT
        should have ('0'|'1'|'2'|'3-4'|'5+'). Empty string for legacy/v1 plans
        without the axis, so the write-count gate is a no-op on them."""
        if not self.dimension_plan:
            return ""
        sd = self.dimension_plan.get("selected_dimensions", {})
        val = sd.get("gt_write_count") or ""
        return str(val[0] if isinstance(val, list) else val)

    def dimension_cell(self) -> str:
        """The v0 coverage cell: task_family | outcome | sorted(policy_focus) |
        difficulty. Used by the v0 filter for coverage capping/dedup. Falls back
        to the legacy cell when no dimension_plan is set (so this is safe to call
        on any bp).

        task_family may be multi-valued (P0: 1-3 families to express multi-intent
        tasks). The cell uses sorted '+' join to keep the cell stable regardless
        of family order in the planner output.
        """
        if not self.dimension_plan:
            return self.coverage_cell()
        sd = self.dimension_plan.get("selected_dimensions", {})
        fam_raw = sd.get("task_family", self.task_family)
        fams = fam_raw if isinstance(fam_raw, list) else [fam_raw]
        fam = "+".join(sorted(str(x) for x in fams if x))
        focus = "+".join(sorted(sd.get("policy_or_constraint_focus") or []))
        diff = sd.get("difficulty_profile", self.difficulty_level)
        return f"{fam}|{self.expected_outcome()}|{focus}|{diff}"

    def control_cell(self) -> str:
        """The Type-2 control cell (for balance checking, not coverage).
        num_faults encodes depth (num_faults = depth + 1), so depth balance is
        checked here too."""
        return f"{self.num_faults}|{self.persona or 'default'}"

    def composite_id(self) -> str:
        """Stable id of the composed atom set: anchor first, then secondaries in
        the validated gt order. depth=0 collapses to the anchor id."""
        return "+".join([self.archetype_id or "?"] + list(self.secondary_archetype_ids))
