"""Reports emitted by verifiers and the filter pipeline, plus accept/reject
record shapes. All JSON-serializable.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .candidate_schema import GTAction


class TaskVerificationReport(BaseModel):
    """Hard-validity report. ``passed`` is the AND of all checks."""

    passed: bool = False
    checks: Dict[str, bool] = Field(default_factory=dict)
    failure_reasons: List[str] = Field(default_factory=list)
    details: Dict[str, Any] = Field(default_factory=dict)

    def finalize(self) -> "TaskVerificationReport":
        self.passed = bool(self.checks) and all(self.checks.values())
        return self


class TrajectoryVerificationReport(BaseModel):
    """Replay-based verification of ground-truth actions."""

    passed: bool = False
    repaired: bool = False
    final_reward: float = 0.0
    num_repair_attempts: int = 0
    replay_log_path: Optional[str] = None
    failure_reasons: List[str] = Field(default_factory=list)
    # The replay trace (per-action ok/error + the messages used for evaluation).
    replay_trajectory: List[Dict[str, Any]] = Field(default_factory=list)
    final_gt_actions: List[GTAction] = Field(default_factory=list)


class FilterReport(BaseModel):
    """Outcome of the filter pipeline for one candidate."""

    kept: bool = False
    # Per-filter pass/fail. A candidate is kept only if every enabled filter passes.
    filters: Dict[str, bool] = Field(default_factory=dict)
    rejection_reasons: List[str] = Field(default_factory=list)
    details: Dict[str, Any] = Field(default_factory=dict)

    def finalize(self) -> "FilterReport":
        self.kept = bool(self.filters) and all(self.filters.values())
        return self


class AcceptedSample(BaseModel):
    """Minimal record describing an accepted candidate (provenance index)."""

    candidate_id: str
    task_id: str
    domain: str
    task_family: str
    target_skill_pattern: str
    difficulty_level: str
    has_sft_trajectory: bool = False
    repaired: bool = False


class RejectedSample(BaseModel):
    """Why a candidate was rejected and at which stage."""

    candidate_id: str
    task_id: Optional[str] = None
    stage: str = Field(description="generation|task_verify|trajectory_verify|filter")
    reasons: List[str] = Field(default_factory=list)
    coverage_cell: Optional[str] = None
