"""Concrete task candidate produced by the Generator.

The Generator turns an abstract :class:`TaskBlueprint` into a concrete,
executable task: a tau2-style task body, a ground-truth action sequence, and
the expected final-state assertions. This object is what the verifiers consume.

Action format (canonical, domain-agnostic)
------------------------------------------
The Generator emits actions in a generic shape::

    {"actor": "assistant"|"user", "type": "tool_call", "name": str, "arguments": {}}

The domain adapter is responsible for translating this canonical shape into
whatever the underlying environment needs (for tau2: ``Action`` objects with a
``requestor`` field). We never bake tau2 specifics into this schema.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .blueprint_schema import TaskBlueprint


class GTAction(BaseModel):
    """One ground-truth action in the canonical, domain-agnostic format."""

    actor: str = Field(description="Who performs the action: 'assistant' or 'user'.")
    type: str = Field(default="tool_call", description="Action type. v0: 'tool_call'.")
    name: str = Field(description="Tool/function name.")
    arguments: Dict[str, Any] = Field(default_factory=dict)
    compare_args: Optional[List[str]] = Field(
        default=None,
        description=(
            "ACTION-basis only: argument names that must match the agent's tool "
            "call. None = compare all args (DB-basis default). Omit dynamically-"
            "minted ids (e.g. a new reservation_id) so booking tasks are judgeable."
        ),
    )


class GenerationMetadata(BaseModel):
    generator_model: str = "unknown"
    prompt_version: str = "telecom_generator"
    extra: Dict[str, Any] = Field(default_factory=dict)


class TaskCandidate(BaseModel):
    """A concrete, generated task plus its ground truth and provenance."""

    candidate_id: str = Field(description="Unique id (e.g. candidate_000001).")
    task_id: str = Field(description="Stable task id used downstream.")

    blueprint: TaskBlueprint

    # The concrete task body. For tau2 this carries user_scenario, initial_state,
    # evaluation_criteria, ticket, description -- kept as a free dict so the
    # schema stays domain-agnostic; the adapter validates/normalizes it.
    task: Dict[str, Any] = Field(default_factory=dict)

    gt_actions: List[GTAction] = Field(default_factory=list)
    expected_final_state: Dict[str, Any] = Field(default_factory=dict)
    assertions: List[Dict[str, Any]] = Field(default_factory=list)
    expected_solution_outline: List[str] = Field(default_factory=list)
    skill_necessity_rationale: str = ""

    generation_metadata: GenerationMetadata = Field(default_factory=GenerationMetadata)

    # Populated by the trajectory verifier if a repair produced better actions.
    repaired_gt_actions: Optional[List[GTAction]] = None

    def effective_gt_actions(self) -> List[GTAction]:
        """Return repaired actions if present, else the original ones."""
        return self.repaired_gt_actions or self.gt_actions
