"""Run the Ontology Reflector: build prompt -> call LLM -> parse output."""
from __future__ import annotations

from typing import Any, Dict

from .reflector_prompt import build_reflector_prompt
from .reflector_output_parser import parse_reflector_output


def _call_llm(llm_client, system: str, user: str) -> str:
    if hasattr(llm_client, "complete"):
        return llm_client.complete(system, user)
    if hasattr(llm_client, "generate"):
        return llm_client.generate(system + "\n\n" + user)
    if callable(llm_client):
        return llm_client(system + "\n\n" + user)
    raise TypeError("llm_client must have .complete(system,user), .generate(prompt), "
                    "or be callable")


def run_reflector(audit_package: Dict[str, Any], llm_client) -> Dict[str, Any]:
    system, user = build_reflector_prompt(audit_package)
    raw = _call_llm(llm_client, system, user)
    return parse_reflector_output(raw)
