"""Build the ontology_audit_package (spec §7) and the reflector LLM prompt.
The reflector reviews experimental dimensions and proposes new ones, preferring
to promote existing diagnostic probes."""
from __future__ import annotations

import json
from typing import Any, Dict, List

from ..ontology.ontology_schema import Ontology

ALLOWED_ACTIONS = [
    "no_change", "promote_probe_to_dimension", "add_value",
    "promote_experimental", "keep_experimental", "deprecate_experimental",
]


def build_experimental_dimension_cards(
    ontology: Ontology, feedback_report: Dict[str, Any]
) -> List[Dict[str, Any]]:
    data = feedback_report.get("data_feedback") or []
    perf = feedback_report.get("performance_feedback") or []
    cards = []
    for dim in ontology.dimensions:
        if dim.status != "experimental":
            continue
        cov = {row["value"]: {"count": row["round_count"], "ratio": row["round_ratio"]}
               for row in data if row["dimension"] == dim.name}
        prf = {row["value"]: {"before_success": row["before_success_rate"],
                              "after_success": row["after_success_rate"],
                              "delta": row["delta_success_rate"]}
               for row in perf if row["dimension"] == dim.name}
        cards.append({
            "dimension": dim.name,
            "status": dim.status,
            "values": list(dim.values),
            "coverage_summary": cov,
            "performance_summary": prf,
            "notes": [f"source={dim.source}"],
        })
    return cards


def build_ontology_audit_package(
    ontology: Ontology,
    feedback_report: Dict[str, Any],
    probe_report: Dict[str, Any],
    history: List[Dict[str, Any]],
    max_new_dimensions_per_round: int = 1,
) -> Dict[str, Any]:
    return {
        "round_id": probe_report.get("round_id", ""),
        "current_ontology": ontology.model_dump(),
        "dimension_feedback_report": {
            "data_feedback": feedback_report.get("data_feedback", []),
            "performance_feedback": feedback_report.get("performance_feedback", []),
        },
        "experimental_dimension_cards": build_experimental_dimension_cards(
            ontology, feedback_report),
        "diagnostic_probe_report": probe_report,
        "previous_reflector_outputs": history,
        "notes": {
            "max_new_dimensions_per_round": max_new_dimensions_per_round,
            "allowed_actions": ALLOWED_ACTIONS,
        },
    }


_SYSTEM = """You are the ONTOLOGY REFLECTOR for a self-evolving task-synthesis
pipeline. You DO NOT write tasks or sampling plans. You only change the
COORDINATE SYSTEM (the set of dimensions used to describe tasks).

You receive an ontology_audit_package: the current ontology, a dimension-value
feedback report (coverage + before/after-training performance), experimental
dimension cards, and a diagnostic probe report.

Output TWO sections as strict JSON:
A. "dimension_reviews": for each EXPERIMENTAL dimension, decide one of
   {"promote","keep_experimental","deprecate"} with a reason and evidence.
B. "new_proposals": propose ontology changes, each one of
   {"no_change","promote_probe_to_dimension","add_value"} with reason+evidence.

TWO WAYS A PROBE CAN JUSTIFY A NEW DIMENSION (consider BOTH):
  (A) FAILURE-DRIVEN (exploit): the probe has buckets that OCCUR in the data and
      correlate with validation failures (see failure_correlation_summary). Promote
      it so future rounds can deepen that painful region.
  (B) COVERAGE-GAP-DRIVEN (explore): the probe's distribution is bunched at the low
      end with an EMPTY or near-empty high end (see coverage_note, and the
      zero-filled bucket ladder -- a value like "3+": 0.0 means that region is
      absent, NOT unimportant). A bucket that never occurs can never fail, so it
      will show NO failure correlation -- that silence is itself the signal. If a
      count axis is saturated at 0/1 with empty high end (2, 3-4, 5+), SUSPECT the synthesis pipeline
      is under-exploring that axis, and promote it so future rounds can DELIBERATELY
      sample the missing region. Do this even with zero current failure correlation.
  PRIORITY: when several probes qualify and the per-round cap forces a choice,
  prefer a FAILURE-DRIVEN promotion (A) first; take a pure COVERAGE-GAP promotion
  (B) when no probe shows a strong failure signal, or with leftover budget.

HARD RULES:
- You may add at most {max_new} new dimension(s) this round
  (max_new_dimensions_per_round).
- PREFER promote_probe_to_dimension over inventing arbitrary axes: a new
  dimension should correspond to an existing diagnostic probe that is either
  failure-correlated (A) or a coverage gap (B) per the two ways above.
- Never deprecate seed or promoted dimensions.
- Values must be a small finite low-cardinality set.
- Do not rename, merge, delete, or change the meaning of existing values.
- ⭐ PROMOTE THE PROBE'S `suggested_axis` WHEN IT HAS ONE. A probe is a numeric/
  boolean DETECTOR (great for FINDING a gap from data) but the GENERATOR cannot
  act on a raw count like "num_numeric_fields=3+". Each probe that maps to a
  generator-executable axis carries a `suggested_axis` = {name, values, why}. When
  you promote such a probe, set dimension_name = suggested_axis.name and values =
  suggested_axis.values VERBATIM (these are SEMANTIC, generator-executable values,
  e.g. computation = none|aggregate|constrained_optimization|conditional_threshold).
  Do NOT promote the raw count buckets in that case -- the generator would not know
  how to realize "3+".
- ONLY when a probe has NO `suggested_axis`: name the dimension after what the
  probe literally measures, and use the exact count buckets INCLUDING "0"
  (literal count buckets like "0","1","2","3-4","5+", not "short/medium/long"); keep the "0" bucket
  consistent with expected_outcome=refuse so the axes compose cleanly.

FIELD NAMES ARE EXACT (do not invent aliases like "proposed_dimension_name"):
- a promote_probe_to_dimension proposal MUST use these keys:
  {"action": "promote_probe_to_dimension", "probe_id": "<existing probe_id>",
   "dimension_name": "<new_dim_name>", "values": ["...", "..."],
   "reason": "...", "evidence": "..."}
- an add_value proposal MUST use:
  {"action": "add_value", "dimension_name": "<existing dim>", "values": ["..."],
   "reason": "..."}
- a dimension_review MUST use:
  {"dimension": "<name>", "decision": "promote|keep_experimental|deprecate",
   "reason": "...", "evidence": "..."}

Respond with ONLY a JSON object:
{"round_id": "...", "ontology_version_in": "...",
 "dimension_reviews": [...], "new_proposals": [...], "summary": "..."}"""


def build_reflector_prompt(audit_package: Dict[str, Any]) -> "tuple[str, str]":
    max_new = audit_package.get("notes", {}).get("max_new_dimensions_per_round", 1)
    system = _SYSTEM.replace("{max_new}", str(max_new))
    user = ("Here is the ontology_audit_package. Review experimental dimensions "
            "and propose at most {n} new dimension(s).\n\n".format(n=max_new)
            + json.dumps(audit_package, indent=2))
    return system, user
