"""Tolerant parser for the reflector LLM's output. Extracts the JSON object from
fenced/prose-wrapped text, normalizes synonyms, and fills missing keys."""
from __future__ import annotations

import json
from typing import Any, Dict, Union

_REVIEW_SYNONYMS = {
    "promote_experimental": "promote",
    "deprecate_experimental": "deprecate",
    "keep": "keep_experimental",
}

# Real LLMs (observed: Opus) sometimes emit proposal fields under "proposed_*"
# aliases. Normalize them to the canonical keys the safety-check + ontology-update
# consume, so a good proposal is never silently dropped on a field-name mismatch.
_PROPOSAL_KEY_SYNONYMS = {
    "proposed_dimension_name": "dimension_name",
    "dimension": "dimension_name",
    "proposed_values": "values",
    "proposed_value": "values",
}


def _extract_json(text: str) -> Dict[str, Any]:
    # strip code fences
    if "```" in text:
        parts = text.split("```")
        for p in parts:
            p = p.strip()
            if p.startswith("json"):
                p = p[4:].strip()
            if p.startswith("{"):
                try:
                    return json.loads(p)
                except json.JSONDecodeError:
                    continue
    # fall back: first '{' to last '}'
    if "{" in text and "}" in text:
        chunk = text[text.index("{"):text.rindex("}") + 1]
        return json.loads(chunk)
    raise ValueError("no JSON object found in reflector output")


def parse_reflector_output(raw_output: Union[str, Dict[str, Any]]) -> Dict[str, Any]:
    obj = raw_output if isinstance(raw_output, dict) else _extract_json(raw_output)

    reviews = obj.get("dimension_reviews") or []
    normalized_reviews = []
    for r in reviews:
        nr = dict(r)  # shallow copy so we never mutate the caller's input
        d = nr.get("decision")
        if d in _REVIEW_SYNONYMS:
            nr["decision"] = _REVIEW_SYNONYMS[d]
        normalized_reviews.append(nr)

    proposals = obj.get("new_proposals") or []
    normalized_proposals = []
    for p in proposals:
        np = dict(p)  # shallow copy; never mutate caller input
        for alias, canonical in _PROPOSAL_KEY_SYNONYMS.items():
            if alias in np and canonical not in np:
                np[canonical] = np[alias]
        normalized_proposals.append(np)

    return {
        "round_id": obj.get("round_id", ""),
        "ontology_version_in": obj.get("ontology_version_in", ""),
        "dimension_reviews": normalized_reviews,
        "new_proposals": normalized_proposals,
        "summary": obj.get("summary", ""),
    }
