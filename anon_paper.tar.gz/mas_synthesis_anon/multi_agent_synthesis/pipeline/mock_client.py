"""PipelineMock: a v0-aware mock LLM for offline end-to-end smoke runs.

The single ``BaseLLMClient`` is shared by every v0 stage (planner / synthesis /
feasibility / repair), so this mock inspects the prompt to decide which canned,
schema-valid response to emit. It always grounds the synthesized task on the
FIRST reservation in the prompt's REAL ENTITY SAMPLE block and proposes a single
``cancel_reservation`` write -- the simplest determinism-safe airline transaction
-- so the full pipeline (plan -> synth -> feasibility -> verify(replay) -> filter
-> export) runs without network access and every accepted task replays to
reward==1.

This exercises plumbing, NOT model quality; the real run uses Bedrock.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from ..llm.base import BaseLLMClient, LLMResponse


def _first_reservation_id(prompt: str) -> str:
    m = re.search(r'"reservation_id":\s*"([A-Z0-9]+)"', prompt)
    return m.group(1) if m else "UNKNOWN"


class PipelineMock(BaseLLMClient):
    model = "mock-v0-pipeline"

    def __init__(self):
        self._plan_counter = 0

    def complete(
        self,
        messages: List[Dict[str, str]],
        *,
        max_tokens: int = 8000,
        temperature: float = 1.0,
        **kwargs: Any,
    ) -> LLMResponse:
        system = "\n".join(
            m.get("content", "") for m in messages if m.get("role") == "system"
        )
        prompt = "\n".join(m.get("content", "") for m in messages)

        if "synthesis planner" in system:
            return LLMResponse(text=self._planner(), model=self.model)
        if "task synthesis agent" in system:
            return LLMResponse(text=self._synthesis(prompt), model=self.model)
        if "feasibility pre-screener" in system:
            return LLMResponse(text=self._feasibility(), model=self.model)
        if "repairing the ground-truth" in system:
            return LLMResponse(text=self._repair(prompt), model=self.model)
        # default: empty object
        return LLMResponse(text="{}", model=self.model)

    # -------------------------------------------------------------- planner
    def _planner(self) -> str:
        self._plan_counter += 1
        n = self._plan_counter
        out = {
            "domain": "airline",
            "plan_id": f"plan_{n:04d}",
            "selected_dimensions": {
                # v4 is basics-only: single task_family (string), no
                # task_composition / entity_scope / fail-set axes -> the 6-dim
                # schema only, else the micro validator rejects unknown keys.
                "task_family": "flight_cancellation",
                # alternate fulfill/refuse so the mock pipeline exercises both
                # intent paths (refuse on even counters).
                "expected_outcome": "refuse" if n % 2 == 0 else "fulfill",
                "policy_or_constraint_focus": ["change_or_cancellation_fee"],
                "tool_use_pattern": ["lookup_verify_then_modify",
                                     "state_change_with_confirmation"],
                "interaction_challenge": [],
                "difficulty_profile": "easy",
            },
            "generation_intent": "Cancel an existing active reservation in place.",
            "success_focus": ["reservation status becomes cancelled"],
            "diversity_notes": ["rotate across reservations"],
            "expected_difficulty_controls": {
                "expected_tool_calls": "2-3",
                "num_policy_constraints": "1",
                "num_entities": "1-2",
                "requires_clarification": False,
                "allows_user_false_claim": False,
                "requires_state_change": True,
            },
        }
        return json.dumps(out)

    # ------------------------------------------------------------- synthesis
    def _synthesis(self, prompt: str) -> str:
        rid = _first_reservation_id(prompt)
        # The plan JSON is echoed into the synthesis prompt; a refuse plan must
        # yield an EMPTY gt (correct behavior is to decline, no state change).
        is_refuse = '"expected_outcome": "refuse"' in prompt
        if is_refuse:
            return json.dumps({
                "task_id": f"airline_flight_cancellation_refuse_{rid}",
                "domain": "airline",
                "source_plan_id": "plan_mock",
                "selected_dimensions": {},
                "user_instruction":
                    f"I demand a full refund cancellation of reservation {rid}.",
                "hidden_task_spec": {
                    "scenario_context": "User pushes for a cancellation the fee "
                                        "policy forbids.",
                    "user_private_info": {"reservation_id": rid},
                    "ground_truth_facts": [
                        f"Reservation {rid} is past the free-cancellation window."],
                    "hidden_constraints": [
                        "No refund/cancellation allowed outside the policy window."],
                    "policy_constraints": ["Cancellation fee policy is violated."],
                    "expected_completion_criteria": [
                        "Agent verifies and DECLINES; no state change."],
                    "must_have_tool_calls": [],
                    "forbidden_actions": ["cancel_reservation"],
                    "confirmation_requirements": [],
                },
                "required_entities": {"orders_or_reservations_or_lines": [rid]},
                "candidate_solution_plan": {
                    "high_level_steps": [
                        "Look up the reservation", "Confirm policy forbids it",
                        "Politely decline"],
                    "candidate_pseudo_gt_actions": [],
                    "expected_final_state": {},
                    "expected_user_visible_resolution":
                        "I'm sorry, this reservation can't be cancelled for a "
                        "refund under our fee policy.",
                },
                "task_quality_notes": {
                    "why_requires_tool_use": "Agent must read to prove ineligibility.",
                    "why_matches_plan": "refuse: policy trap on cancellation fee.",
                    "difficulty_justification": "Read-only verification then deny.",
                    "possible_failure_modes": ["wrongly cancelling anyway"],
                },
            })
        out = {
            "task_id": f"airline_flight_cancellation_{rid}",
            "domain": "airline",
            "source_plan_id": "plan_mock",
            "selected_dimensions": {},
            "user_instruction": f"I'd like to cancel my reservation {rid}, please.",
            "hidden_task_spec": {
                "scenario_context": "Customer requests cancellation of an active reservation.",
                "user_private_info": {"reservation_id": rid},
                "ground_truth_facts": [f"Reservation {rid} is active and cancellable."],
                "hidden_constraints": ["Cancel only after confirming with the user."],
                "policy_constraints": ["Confirm cancellation before executing."],
                "expected_completion_criteria": [f"Reservation {rid} status=cancelled."],
                "must_have_tool_calls": ["cancel_reservation"],
                "forbidden_actions": ["book_reservation"],
                "confirmation_requirements": ["Explicit confirmation before cancelling."],
            },
            "required_entities": {"orders_or_reservations_or_lines": [rid]},
            "candidate_solution_plan": {
                "high_level_steps": ["Look up the reservation", "Cancel it in place"],
                "candidate_pseudo_gt_actions": [
                    {"step_id": 1, "actor": "assistant", "action_type": "tool_call",
                     "tool_name": "cancel_reservation",
                     "arguments": {"reservation_id": rid},
                     "purpose": "Cancel the reservation in place."}
                ],
                "expected_final_state": {"reservation_status": "cancelled"},
                "expected_user_visible_resolution":
                    f"Your reservation {rid} has been cancelled.",
            },
            "task_quality_notes": {
                "why_requires_tool_use": "Status changes only via the cancel tool.",
                "why_matches_plan": "flight_cancellation, in-place modify.",
                "difficulty_justification": "Single write, one entity.",
                "possible_failure_modes": ["cancelling a non-cancellable reservation"],
            },
        }
        return json.dumps(out)

    # ----------------------------------------------------------- feasibility
    def _feasibility(self) -> str:
        return json.dumps({
            "feasible": True,
            "confidence": 0.9,
            "reasons": ["grounded id + requires cancel tool"],
            "requires_genuine_tool_use": True,
            "instruction_leaks_answer": False,
            "entities_grounded": True,
        })

    # ---------------------------------------------------------------- repair
    def _repair(self, prompt: str) -> str:
        rid = _first_reservation_id(prompt)
        return json.dumps({"gt_actions": [
            {"actor": "assistant", "name": "cancel_reservation",
             "arguments": {"reservation_id": rid}}]})
