"""TrajectoryAgent: agentic exploration loop that discovers gt by tool use.

Stage 4a (optional) of the v0 pipeline. Mirrors v1's InteractiveSolver but is
shaped for DB-reward domains (airline/retail): the env runs on the STOCK db (no
fault injection), there is no user-observable device snapshot, and the agent
diagnoses by calling READ tools then submits the STATE-CHANGING writes that
resolve the request.

It reuses the adapter's ``exec_action`` / ``make_faulted_env`` primitives
verbatim (decision: reuse the v1 trajectory primitives). The agent never sees
any scoring internals; its submission is a PROPOSAL that the deterministic
replay gate (ReplayVerifier) adjudicates. This module scores nothing.

In ``summarizer`` mode the pipeline skips this agent and trusts the synthesis
agent's draft pseudo-GT; in ``interactive`` mode it runs this loop to produce
the gt by genuine exploration. Either way replay is the arbiter.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..llm.base import BaseLLMClient, LLMResponse

PROMPT_VERSION = "trajectory_v1"


@dataclass
class TrajectoryResult:
    final_gt_actions: Optional[List[Dict[str, Any]]]
    transcript: List[Dict[str, Any]] = field(default_factory=list)
    n_turns: int = 0
    terminated_reason: str = ""  # submit | max_turns | parse_error | empty_submit


_SYSTEM = """You are a customer-support agent resolving a request by INTERACTING \
with real tools against a live system. Each turn, respond with a SINGLE JSON \
object and nothing else.

To call a tool (look something up, or apply a change):
{"action": "call", "actor": "assistant"|"user", "name": "<tool_name>", "arguments": {...}}

When the request is resolved, submit the MINIMAL ordered list of the \
STATE-CHANGING actions that constitute the resolution (exclude pure \
read/lookup calls):
{"action": "submit", "gt_actions": [{"actor": "...", "name": "...", "arguments": {...}}, ...]}

Rules:
- Look up the relevant records with READ tools before making any change.
- Bind every argument to a REAL id you saw in a tool result or the task; never \
invent ids.
- Prefer IN-PLACE modifications of EXISTING records; do not mint new ids.
- Submit only the resolving (state-changing) actions, in execution order.
- Output ONLY the JSON object for the current turn."""


def _parse_obj(text: str) -> Optional[Dict[str, Any]]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            obj = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return obj if isinstance(obj, dict) else None


def _tool_catalog(tools: Dict[str, Any]) -> str:
    """Render the tool catalog. ``tools`` may be either the v0-context shape
    ({actor, tool_type, parameters, description}) or the adapter shape
    ({actor, schema}); handle both."""
    lines: List[str] = []
    for name, spec in sorted(tools.items()):
        if name.startswith("assert_"):
            continue
        actor = spec.get("actor", "assistant")
        if "schema" in spec:
            fn = (spec.get("schema") or {}).get("function") or {}
            desc = (fn.get("description") or "").strip().replace("\n", " ")[:120]
            params = list(((fn.get("parameters") or {}).get("properties") or {}).keys())
        else:
            desc = (spec.get("description") or "").strip().replace("\n", " ")[:120]
            params = list(spec.get("parameters") or [])
        ttype = spec.get("tool_type", "")
        tag = f"/{ttype}" if ttype else ""
        lines.append(f"- [{actor}{tag}] {name}({', '.join(params)}): {desc}")
    return "\n".join(lines)


class TrajectoryAgent:
    """Agentic exploration loop. Pure proposal generator (scores nothing)."""

    def __init__(
        self,
        adapter,
        llm: BaseLLMClient,
        max_turns: int = 12,
        max_tokens: int = 4000,
    ):
        self.adapter = adapter
        self.llm = llm
        self.max_turns = max_turns
        self.max_tokens = max_tokens

    def explore(
        self,
        task_body: Dict[str, Any],
        tools: Dict[str, Any],
        entity_sample: Optional[List[Dict[str, Any]]] = None,
    ) -> TrajectoryResult:
        init_actions = (task_body.get("initial_state") or {}).get(
            "initialization_actions"
        ) or []
        env = self.adapter.make_faulted_env(init_actions)
        catalog = _tool_catalog(tools)
        instr = (task_body.get("user_scenario") or {}).get("instructions") or {}
        request = json.dumps(instr, ensure_ascii=False)
        ents = json.dumps(entity_sample or [], ensure_ascii=False)
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": _SYSTEM},
            {
                "role": "user",
                "content": (
                    f"Customer request:\n{request}\n\n"
                    f"Relevant records (real ids):\n{ents}\n\n"
                    f"Available tools:\n{catalog}\n\n"
                    "Begin. Respond with one JSON action."
                ),
            },
        ]
        transcript: List[Dict[str, Any]] = []

        for turn in range(self.max_turns):
            resp: LLMResponse = self.llm.complete(messages, max_tokens=self.max_tokens)
            obj = _parse_obj(resp.text)
            if obj is None:
                transcript.append({"turn": turn, "raw": resp.text[:300], "err": "parse"})
                return TrajectoryResult(None, transcript, turn + 1, "parse_error")

            if obj.get("action") == "submit":
                gt = [
                    {
                        "actor": str(a.get("actor", "assistant")),
                        "name": str(a.get("name")),
                        "arguments": dict(a.get("arguments") or {}),
                    }
                    for a in (obj.get("gt_actions") or [])
                    if isinstance(a, dict) and a.get("name")
                ]
                transcript.append({"turn": turn, "submit": gt})
                if not gt:
                    return TrajectoryResult(None, transcript, turn + 1, "empty_submit")
                return TrajectoryResult(gt, transcript, turn + 1, "submit")

            name = obj.get("name")
            if not name:
                transcript.append({"turn": turn, "raw": obj, "err": "no_name"})
                return TrajectoryResult(None, transcript, turn + 1, "parse_error")
            actor = str(obj.get("actor", "assistant"))
            args = dict(obj.get("arguments") or {})
            obs = self.adapter.exec_action(env, actor, name, args, turn)
            transcript.append({"turn": turn, "call": name, "obs": obs})
            messages.append({"role": "assistant", "content": json.dumps(obj)})
            messages.append(
                {
                    "role": "user",
                    "content": (
                        f"Tool result: {json.dumps(obs, ensure_ascii=False)}\n"
                        "Next JSON action."
                    ),
                }
            )

        return TrajectoryResult(None, transcript, self.max_turns, "max_turns")

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION
