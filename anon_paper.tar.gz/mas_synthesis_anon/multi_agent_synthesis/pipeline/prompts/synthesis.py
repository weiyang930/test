"""pipeline Task Synthesis Agent prompt builder (forked verbatim from
../../prompts/synthesis.py).

v5 uses THIS generator (not the v0 single-write one): it is the validated v3
pure-DB generator that already knows how to realize the `computation` semantic
axis (none/aggregate/constrained_optimization/conditional_threshold) and
multi-write chains -- no trick, no ACTION basis. This is why v3 could synthesize
multi-numeric/multi-write tasks and the bare v0 prompt could not. The shared v3
copy (used by the synthesis pipeline) is untouched.

----- original v3 docstring -----
v3 Task Synthesis Agent prompt builder (pure DB judging + multi-write chains).

Instantiates ONE v3 synthesis plan into ONE concrete, executable task bound to
REAL environment entities. v3 judging is ALWAYS by database-state hash (DB), with
an optional COMMUNICATE check (the exact figure(s) the agent must report back).
There is NO ACTION-basis and NO compare_args -- the v3 audit showed the base-50
eval set is 100% DB(+COMMUNICATE), and booking IS deterministic (the airline
``book_reservation`` draws ids from a FIXED pool), so multi-write chains -- INCLUDING
booking -- are reproducible and DB-hash judgeable.

Key difference from the v0 single-intent DB prompt: that prompt FORBADE booking
and multi-write (it only allowed a single in-place edit). v3 OPENS UP:
  * deterministic booking is allowed (the new reservation_id is drawn from the
    env's fixed pool, so the final DB state is reproducible);
  * multi-write chains are allowed and EXPECTED when num_write >= "2" /
    task_composition != "single";
  * the num_write + computation axes tell the agent exactly how many writes
    and how much arithmetic the correct trajectory needs.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Tuple

PROMPT_VERSION = "synthesis_v1"


_SYSTEM = """You are a task synthesis agent for interactive tool-use benchmark \
environments.

Your job is to instantiate a structured synthesis plan into ONE concrete, \
executable task, bound to REAL entities from the environment database. Your \
output defines the task, hidden constraints, expected completion criteria, and a \
candidate pseudo-ground-truth action plan.

Principles:
- The task must be executable under the current environment state.
- The task must require genuine tool use; it must NOT be solvable from the user \
instruction alone.
- The user-facing instruction must NOT reveal all hidden validation criteria.
- Use REAL entity ids from the provided sample (do not invent ids).
- The task must match the selected planner dimensions (task_family list, \
task_composition, entity_scope, expected_outcome, focus, patterns, computation, \
num_write, difficulty).
- Honor the plan's task_composition (how the 1-3 task_family values combine):
  * "single": exactly one family; one intent end-to-end.
  * "sequence": chain 2-3 families IN ORDER. The pseudo-GT MUST contain one \
resolving write PER family, in order (e.g. cancel_reservation THEN \
update_reservation_baggages). A multi-family sequence whose GT has a single write \
is INVALID.
  * "conditional_fallback": user prefers family A; if eligibility/policy blocks \
A, the agent falls back to family B. The pseudo-GT contains B's resolving \
write(s) (A is unreachable per the hidden policy fact).
  * "parallel_mix": user makes TWO requests (one allowed + one forbidden). Pairs \
with expected_outcome=mixed -- the gt has the write(s) for the compliant request \
and NO write for the forbidden one.
- Honor the plan's entity_scope:
  * "single_entity": exactly one reservation/order/line.
  * "filtered_subset": a FILTER of the user's entities; act on each match.
  * "all_user_entities": iterate over EVERY entity the user owns; one resolving \
write per affected entity.
- Honor the plan's expected_outcome:
  * "fulfill": the request is policy-compliant; candidate_pseudo_gt_actions are \
the state-changing write(s) that resolve it.
  * "refuse": the request VIOLATES the plan's policy_or_constraint_focus and the \
correct behavior is to DECLINE. candidate_pseudo_gt_actions MUST be an EMPTY list \
(no state change). State the forbidden request, the violated rule, and the \
database fact that proves it must be denied, in hidden_task_spec.
  * "mixed": TWO requests, one compliant + one forbidden. The pseudo-GT has the \
resolving write(s) for the compliant part ONLY.
- Honor the plan's num_write. REALIZATION IS MANDATORY, not aspirational: the \
number of WRITE (state-changing) actions in candidate_pseudo_gt_actions MUST \
fall in the selected bucket ("0", "1", "2", "3-4", "5+"), or the sample is \
rejected as a shell. When the bucket is "2"/"3-4"/"5+" you MUST design a genuine \
MULTI-WRITE business chain that needs that many state-changing calls -- e.g. \
cancel one reservation AND book a replacement AND send a certificate; or update \
flights AND update baggages AND update passengers on the same reservation. Do \
NOT emit a single write padded with reads; do NOT collapse a "3-4" plan into one \
edit. The chain must be a coherent real request the user would actually make, \
not unrelated writes stapled together. Reads and `calculate` do NOT count toward \
this -- but the gt MUST \
still INCLUDE the read/lookup calls the agent must make to ground each write \
(inspect the reservation before modifying it, look up balances/fares before \
computing). A gt that jumps straight to writes with no preceding reads is an \
INVALID degenerate shape (the real eval tasks always read-then-write).
- Honor the plan's computation. REALIZATION IS MANDATORY, not decorative: when \
computation is aggregate or conditional_threshold the gt MUST carry the \
arithmetic, or the sample is rejected as a shell (declared-but-not-realized). \
Concretely, such a gt MUST contain a `calculate` action AND/OR a \
`communicate_info` figure that contains a number:
  * "none": no nontrivial arithmetic.
  * "aggregate": the solution sums/counts/totals across entities; emit a \
`calculate` action for the total and add a "communicate_info" field with the \
exact figure the agent must report. Do NOT skip the calculate and jump to the write.
  * "constrained_optimization": the user gives CONSTRAINTS, not a named option; \
the hidden_task_spec records the real optimum so the gt write targets it, and a \
suboptimal choice must fail.
  * "conditional_threshold": the solution computes a value with a `calculate` \
action, compares it to a threshold, and BRANCHES; the gt reflects the correct \
branch for the real entity values, and communicate_info reports the computed \
value (e.g. the fare difference / fee) that drove the branch. A threshold task \
that jumps straight to the write with no `calculate` and no reported number is \
an INVALID shell -- the arithmetic is the whole point.
- If the plan requires clarification, the initial user instruction should omit \
some info naturally; put what the user can later provide in user_private_info.
- If the plan allows a user false claim, state the false claim AND the database \
fact that contradicts it in hidden_task_spec.
- For a fulfill task, specify the confirmation needed before a state change.
- Output STRICT JSON only. No markdown, no commentary."""


_OUTPUT_CONTRACT = """Return a JSON object with EXACTLY this schema:

{
  "task_id": "<string>",
  "domain": "<domain>",
  "source_plan_id": "<the plan_id>",
  "selected_dimensions": {<copy of the plan's selected_dimensions>},
  "user_instruction": "<what the simulated user initially says; a plain string>",
  "communicate_info": ["<exact figure(s) the agent must state back, if any>"],
  "hidden_task_spec": {
    "scenario_context": "<string>",
    "user_private_info": {<info the user can reveal when asked>},
    "ground_truth_facts": ["<fact grounded in the real entities>"],
    "hidden_constraints": ["<policy/eligibility constraint not stated upfront>"],
    "policy_constraints": ["<relevant policy rule>"],
    "expected_completion_criteria": ["<observable success condition>"],
    "must_have_tool_calls": ["<tool name the solution must use>"],
    "forbidden_actions": ["<action that must NOT occur>"],
    "confirmation_requirements": ["<what to confirm before a state change>"]
  },
  "required_entities": {
    "customers_or_accounts": [<real ids>],
    "orders_or_reservations_or_lines": [<real ids>],
    "products_or_flights_or_plans": [<real ids>],
    "payments_or_credits_or_memberships": [<real ids>],
    "other_entities": []
  },
  "candidate_solution_plan": {
    "reward_basis": ["DB"],
    "high_level_steps": ["<step>", "..."],
    "candidate_pseudo_gt_actions": [
      {"step_id": 1, "actor": "assistant", "action_type": "tool_call",
       "tool_name": "<tool>", "arguments": {<concrete args using REAL ids>},
       "purpose": "<why>"}
    ],
    "expected_final_state": {<partial final-state description>},
    "expected_user_visible_resolution": "<string>"
  },
  "task_quality_notes": {
    "why_requires_tool_use": "<string>",
    "why_matches_plan": "<string>",
    "difficulty_justification": "<string>",
    "possible_failure_modes": ["<string>"]
  }
}

Rules:
- user_instruction, scenario_context, and expected_user_visible_resolution are \
PLAIN STRINGS, never nested objects.
- reward_basis is ALWAYS ["DB"]. Do NOT use ACTION basis and do NOT emit \
compare_args -- v3 judges every task by exact final database state.
- candidate_pseudo_gt_actions lists the ORDERED tool calls that constitute the \
solution. It MUST interleave the READ/lookup calls a careful agent has to make \
FIRST to ground each decision (e.g. get_reservation_details to inspect the \
current cabin/flights/fees before changing them, search_direct_flight to compare \
fares, get_user_details to read balances/memberships) with the STATE-CHANGING \
write calls that resolve the request. Order them as a real agent would act: read \
the entities you are about to touch, then write. Only the WRITE (state-changing) \
calls count toward num_write; the reads do not count but MUST be present \
whenever the correct write depends on observed state (which is almost always). \
Each call must use REAL ids from the entity sample (a brand-new booking's \
reservation_id is the one exception -- it does not exist yet; describe it by its \
flight/passenger/payment args) and arguments valid against the tool schema. For a \
non-"single" composition there MUST be one write per intended family. For a \
"refuse" task the WRITE list MUST be EMPTY, but you should still include the \
read(s) that let the agent discover the request must be denied (e.g. the \
get_reservation_details that reveals the non-refundable fare).
- communicate_info: include it ONLY when the task requires the agent to report a \
precise figure (computation=aggregate / a balance / total saved / fare \
difference). It is a list of the exact string(s) the agent must say back (e.g. \
["1628"]). Ground every figure in real entity values so it is deterministic. Omit \
or leave empty when no figure must be reported.
- These pseudo-GT actions are a DRAFT; a downstream validator replays and may \
repair them. Make them your best concrete guess."""


# Airline determinism note for the v3 DB path. UNLIKE the v0 single-intent note,
# this PERMITS deterministic booking and multi-write chains: the env mints new
# reservation ids from a fixed pool, so the final DB state is reproducible.
_AIRLINE_DETERMINISM = """DETERMINISM REQUIREMENT (airline judging is by database \
state hash):
- The solution may be a SINGLE in-place modification of an existing reservation \
(cancel it, change its cabin/flights, correct passenger details, add/remove \
baggage), OR a MULTI-WRITE chain. Build multi-write chains out of writes against \
EXISTING reservations (e.g. cancel one reservation AND update another; update \
several reservations; cancel-then-update different existing reservations), as \
dictated by the plan's num_write and task_composition.
- Booking a brand-new reservation IS allowed: the environment draws the new \
reservation_id from a FIXED deterministic pool, so the resulting database state \
is reproducible and DB-hash judgeable. When booking, describe the reservation by \
its flights / passengers / cabin / baggage / payment args (the new reservation_id \
is assigned by the env -- do not invent one).
- CRITICAL ORDERING RULE for booking: a ``book_reservation`` call must be the \
LAST write in the gt sequence, and NO later action may reference the newly-booked \
reservation. The env assigns the new id only at execution time, so you cannot \
know it when writing the gt; any later tool call that needs that id (e.g. \
``update_reservation_baggages`` / ``update_reservation_flights`` on the just-booked \
reservation, or a placeholder like {{NEW_RESERVATION_ID}}) is NOT replayable and \
will be rejected. If the task needs both a booking AND a modification, modify an \
EXISTING reservation and put the booking last -- do not book-then-modify the \
same new reservation.
- Every WRITE must be a real, replayable tool call against REAL entities (or a \
deterministic booking). Do NOT depend on wall-clock time or random values. Never \
emit a placeholder id token in any tool argument -- every reservation_id must be a \
concrete id from the entity sample.
- INCLUDE the grounding READ calls in the gt, ordered before the writes that \
depend on them: get_reservation_details for every reservation you modify or \
cancel, get_user_details when a balance / membership / payment method drives the \
decision, search_direct_flight when a fare or flight must be compared/chosen. \
Reads are pure lookups (they never change the database), so they do NOT affect \
the DB-hash judging -- their only job is to make the gt the same read-then-write \
shape the agent must actually follow.
- Invariants: the passenger COUNT on an EXISTING reservation cannot change; \
payment methods must be ones the user already owns; pay any fee from an existing \
payment method.
- PAYMENT RULES (the env enforces these; a gt that breaks them is NOT replayable):
  * A CERTIFICATE (payment_id like ``certificate_*``) may ONLY be used to PAY for \
a brand-new ``book_reservation``. It is REJECTED for any \
``update_reservation_flights`` / ``update_reservation_baggages`` fee ("Certificate \
cannot be used to update reservation"). For any UPDATE that costs money, pay with \
the user's CREDIT CARD (``credit_card_*``) or, if its balance covers the fee, a \
GIFT CARD (``gift_card_*``) -- never a certificate.
  * When ``book_reservation`` takes a ``payment_methods`` split, the amounts MUST \
sum to EXACTLY the reservation's total price (sum of each flight's cabin price x \
number of passengers, PLUS 50 per NON-FREE checked bag, PLUS 30 x passengers if \
insurance is "yes"). An off-by-anything split is rejected ("Payment amount does \
not add up"). Compute the total with ``calculate`` and make the split add up to it \
precisely.
  * A GIFT CARD can only be used if its remaining balance is >= the amount charged \
to it; read the balance with ``get_user_details`` before relying on it.
- BOOKING PAYMENT-SPLIT PROTOCOL (this is the #1 cause of non-replayable gt -- \
follow it MECHANICALLY, do NOT guess any price):
  1. ``update_reservation_flights`` and ``update_reservation_baggages`` take a \
SINGLE ``payment_id`` (NOT a list) -- the env computes the fee itself, so you can \
NEVER get an amount wrong on an update. ``book_reservation`` is the ONLY write \
where you must pre-state amounts that sum EXACTLY to the env-computed total. \
Therefore: if the plan can be satisfied by modifying an EXISTING reservation \
(change cabin/flights, add baggage), PREFER that over a brand-new booking -- it \
sidesteps the split entirely. Only emit ``book_reservation`` when the plan truly \
needs a NEW reservation.
  2. When you DO book, the total is fully determined by the env formula: \
``total_price = sum over each chosen flight of prices[CABIN] * num_passengers \
+ 50 * nonfree_baggages + 30 * num_passengers (only if insurance == "yes")``. \
The per-flight price is ``prices[CABIN]`` from that flight's ``search_direct_flight`` \
/ ``search_onestop_flight`` result for the EXACT cabin you are booking -- NOT the \
basic_economy price when booking economy, NOT a price you remember from another \
flight. You MUST have a ``search_*`` read for every flight in the booking, and you \
MUST read ``prices[<the booking cabin>]`` off that exact result.
  3. Emit a ``calculate`` whose expression writes the formula out term by term \
using ONLY those looked-up per-cabin prices (e.g. ``(161 + 161) * 2 + 50`` for a \
2-passenger round trip in economy at 161 each with one extra bag), and make your \
``payment_methods`` amounts sum to EXACTLY that ``calculate`` result. Do a final \
self-check: the sum of your split == the calculate output == the env total. If \
they do not match, you used a wrong per-cabin price -- re-read the search result.
  4. Each gift-card / certificate amount in the split must be <= that method's \
balance (gift card) or fit the certificate-only-for-booking rule; put any \
remainder on the credit card (credit cards have no balance cap)."""


def _entity_sample_block(entities: List[Dict[str, Any]]) -> str:
    if not entities:
        return "REAL ENTITY SAMPLE: (none provided)"
    return (
        "REAL ENTITY SAMPLE (use ONLY these concrete ids; pick whichever fits the "
        "plan):\n" + json.dumps(entities, ensure_ascii=False, indent=2)
    )


def build_synthesis_prompt(
    domain: str,
    plan: Dict[str, Any],
    tool_schema_summary: str,
    database_summary: str,
    policy_text: str,
    entity_sample: List[Dict[str, Any]],
    determinism_note: str = "",
) -> Tuple[str, str]:
    """Return (system, user) for one v3 Task Synthesis Agent call.

    The prompt is always the pure-DB variant (no ACTION basis): one or more
    replayable writes -- including deterministic booking -- judged by final DB
    state, with an optional communicate_info figure check.
    """
    user_parts = [
        "Instantiate one concrete task from the following synthesis plan.",
        "",
        f"DOMAIN:\n{domain}",
        "",
        "SYNTHESIS PLAN:",
        json.dumps(plan, ensure_ascii=False, indent=2),
        "",
        f"TOOL SCHEMAS:\n{tool_schema_summary}",
        "",
        f"DATABASE / ENVIRONMENT SUMMARY:\n{database_summary}",
        "",
        f"POLICY:\n{policy_text}",
        "",
        _entity_sample_block(entity_sample),
    ]
    if determinism_note:
        user_parts += ["", determinism_note]
    user_parts += ["", _OUTPUT_CONTRACT, "", "Output strict JSON only."]
    return _SYSTEM, "\n".join(user_parts)
