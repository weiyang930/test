"""pipeline Planner Agent prompt builder (dimension-value paradigm).

Forked from ../../prompts/planner.py and trimmed to the clean v5 scope:
the deprecated multi-intent, action-basis, and fail-set machinery are all
removed. The planner is always SINGLE-INTENT (exactly one task_family) and the
expected_outcome is fulfill | refuse | mixed. `mixed` means one task whose
correct trajectory both does an allowed write AND declines a forbidden part.

The Planner Agent selects ONE structured synthesis plan from the fixed,
swappable domain dimension-value schema. It defines a task *distribution* (a
type of task to instantiate later), NOT a concrete task with fixed entities.
Output is strict JSON validated downstream against the dimension yaml's
selection_rules + value lists.
"""

from __future__ import annotations

import json
from typing import Any, Dict, Tuple

PROMPT_VERSION = "planner_v2"

# The validated seed axes. Their prompt text is byte-stable (round-1 behavior is
# unchanged). Any ACTIVE ontology dimension NOT in this set is a reflector-added
# axis and is rendered ADDITIVELY into the rules + output contract, so a newly
# promoted axis (e.g. num_write) actually flows through to the micro plan.
_SEED_KEYS = (
    "task_family", "expected_outcome", "policy_or_constraint_focus",
    "tool_use_pattern", "interaction_challenge", "difficulty_profile",
)


def _extra_axes(dimension_values_json: Dict[str, Any],
                selection_rules: Dict[str, Any]) -> list:
    """Active dims beyond the seed 6 -> (key, values, lo, hi). Order-preserving."""
    dim_values = dimension_values_json.get("dimension_values") or {}
    out = []
    for key in dim_values:
        if key in _SEED_KEYS:
            continue
        rule = selection_rules.get(key, {"min": 0, "max": 1})
        out.append((key, list(dim_values[key]),
                    int(rule.get("min", 0)), int(rule.get("max", 1))))
    return out


def _extra_rules_block(extra: list) -> str:
    """One '- Select ...' rule line per reflector-added axis."""
    lines = []
    for key, _vals, lo, hi in extra:
        if lo == hi:
            lines.append(f"- Select exactly {hi} {key} value(s) "
                         f"(this axis was added by the ontology reflector).")
        else:
            lines.append(f"- Select {lo} to {hi} {key} value(s) "
                         f"(this axis was added by the ontology reflector).")
    return ("\n" + "\n".join(lines)) if lines else ""


def _extra_contract_lines(extra: list) -> str:
    """JSON template fields for the reflector-added axes, injected into
    selected_dimensions (after the seed fields)."""
    lines = []
    for key, vals, lo, hi in extra:
        hint = " | ".join(str(v) for v in vals) if vals else "<value>"
        if hi == 1:
            lines.append(f'    "{key}": "<one value: {hint}>"')
        else:
            lines.append(f'    "{key}": ["<{lo} to {hi} values from: {hint}>"]')
    return (",\n" + ",\n".join(lines)) if lines else ""


_SYSTEM = """You are a synthesis planner for interactive tool-use benchmark tasks.

Your job is to generate ONE structured synthesis plan by selecting values from a \
fixed domain-specific dimension schema. The plan defines a task DISTRIBUTION, not \
a fully instantiated task. A downstream Task Synthesis Agent will use your plan, \
the domain policy, tool schemas, and database information to instantiate a \
concrete executable task.

Rules:
- Use ONLY the provided dimension keys.
- Select ONLY values from the provided domain-specific value lists.
- Select exactly one task_family.
- Select exactly one expected_outcome (see below).
- Select one or two policy_or_constraint_focus values.
- Select one to three tool_use_pattern values.
- Select zero to two interaction_challenge values.
- Select exactly one difficulty_profile.{extra_rules}
- The selected values must be mutually compatible and realizable with the listed tools.
- The plan must encourage genuine multi-turn, multi-step tool use.
- The plan must NOT be a template with fixed entities. Describe a task TYPE to \
instantiate later.
- Output STRICT JSON only. No markdown, no comments.

expected_outcome (the INTENT axis -- what a CORRECT trajectory looks like):
- "fulfill": the user's request is policy-COMPLIANT. The correct agent verifies \
eligibility, then CARRIES OUT the request with the resolving write action(s). \
Pick this for the normal "get the task done" tasks.
- "refuse": the user's request VIOLATES the selected policy_or_constraint_focus \
(e.g. asks for a refund/cancellation/change the policy forbids, or pressures the \
agent with a false claim). The correct agent verifies via read tools, finds the \
request is NOT allowed, and DECLINES -- it makes NO state-changing write. Use the \
policy_or_constraint_focus to define the exact rule being violated. A refuse task \
is a policy TRAP: the user pushes for an action the agent must refuse to perform.
- "mixed": within ONE single-family task, the correct trajectory has BOTH a \
policy-compliant part the agent CARRIES OUT (the resolving write) AND a part that \
VIOLATES the selected policy_or_constraint_focus which the agent must DECLINE. \
The correct GT contains the write(s) for the compliant part and makes NO illegal \
write for the forbidden part. Use this when the same request bundles an allowed \
action with a forbidden extra (e.g. change a flight leg -- allowed -- but the user \
also pushes for a fee waiver the policy forbids, which the agent refuses)."""


_OUTPUT_CONTRACT = """Return a JSON object with EXACTLY this schema:

{
  "domain": "<domain>",
  "plan_id": "<unique short string>",
  "selected_dimensions": {
    "task_family": "<one value>",
    "expected_outcome": "fulfill | refuse | mixed",
    "policy_or_constraint_focus": ["<one or two values>"],
    "tool_use_pattern": ["<one to three values>"],
    "interaction_challenge": ["<zero to two values>"],
    "difficulty_profile": "easy | medium | hard"@@EXTRA_DIMS@@
  },
  "generation_intent": "<concise NL explanation of the task type to generate>",
  "success_focus": ["<concrete condition the final task/trajectory must satisfy>", "..."],
  "diversity_notes": ["<how to avoid near-duplicates: vary entities, policy, tool sequence>"],
  "expected_difficulty_controls": {
    "expected_tool_calls": "...",
    "num_policy_constraints": "...",
    "num_entities": "...",
    "requires_clarification": true,
    "allows_user_false_claim": false,
    "requires_state_change": true
  }
}

Set expected_difficulty_controls to the values prescribed by the chosen \
difficulty_profile in the DIMENSION VALUES block. Every selected value must come \
verbatim from the provided lists."""


def _render_condition_block(cond: Dict[str, Any]) -> list:
    """Render the macro three-state condition as guidance for the micro planner.

    preferred = soft (encouraged), allowed = hard (must pick from these for that
    key), forbidden = hard exclusion, avoid_patterns = cross-dimension shapes to
    avoid. Pure prompt guidance -- nothing here is enforced in code; the planner
    is trusted to honor it.
    """
    preferred = cond.get("preferred_values") or {}
    allowed = cond.get("allowed_values") or {}
    forbidden = cond.get("forbidden_values") or {}
    avoid = cond.get("avoid_patterns") or []
    objective = cond.get("objective") or ""
    parts = ["", "GENERATION CONDITION (from the macro planner -- honor it):"]
    if objective:
        parts.append(f"- objective: {objective}")
    if preferred:
        parts.append(
            "- PREFERRED values (soft -- strongly prefer choosing from these): "
            + json.dumps(preferred, ensure_ascii=False))
    if allowed:
        parts.append(
            "- ALLOWED values (hard -- for each listed dimension you MUST pick "
            "only from these): " + json.dumps(allowed, ensure_ascii=False))
    if forbidden:
        parts.append(
            "- FORBIDDEN values (hard -- never select these): "
            + json.dumps(forbidden, ensure_ascii=False))
    if avoid:
        parts.append(
            "- AVOID these cross-dimension patterns: " + json.dumps(avoid, ensure_ascii=False))
    parts.append(
        "Choose all remaining dimensions freely so the whole selection is "
        "mutually compatible and realizable with the listed tools.")
    return parts


def build_planner_prompt(
    domain: str,
    context_summary: str,
    tool_schema_summary: str,
    database_summary: str,
    policy_summary: str,
    dimension_values_json: Dict[str, Any],
    condition: Dict[str, Any] | None = None,
    selection_rules: Dict[str, Any] | None = None,
) -> Tuple[str, str]:
    """Return (system, user) for one Planner Agent call (single-intent).

    ``dimension_values_json`` is ``DomainDimensions.to_planner_json()`` (the
    domain's value lists + difficulty interpretation). ``selection_rules`` is the
    domain's per-key min/max bounds. Any ACTIVE dimension beyond the seed 6 (i.e.
    an axis the ontology reflector promoted, such as num_write) is rendered
    ADDITIVELY into the rules + output contract here, so the micro planner actually
    emits it. With no extra axes the prompt is byte-identical to the seed version.

    ``condition`` is an optional macro three-state constraint dict supplied by
    the macro layer. When ``None`` the planner is fully free (legacy behavior).
    """
    cond = condition or {}
    rules = selection_rules or {}
    extra = _extra_axes(dimension_values_json, rules)
    system = _SYSTEM.replace("{extra_rules}", _extra_rules_block(extra))
    contract = _OUTPUT_CONTRACT.replace("@@EXTRA_DIMS@@", _extra_contract_lines(extra))
    user_parts = [
        "Generate one synthesis plan for the following domain.",
        "",
        f"DOMAIN:\n{domain}",
        "",
        f"DOMAIN CONTEXT SUMMARY:\n{context_summary}",
        "",
        f"AVAILABLE TOOLS SUMMARY:\n{tool_schema_summary}",
        "",
        f"DATABASE / ENVIRONMENT SUMMARY:\n{database_summary}",
        "",
        f"POLICY SUMMARY:\n{policy_summary}",
        "",
        "DIMENSION VALUES (select ONLY from these):",
        json.dumps(dimension_values_json, ensure_ascii=False, indent=2),
    ]
    if cond:
        user_parts += _render_condition_block(cond)
    user_parts += [
        "",
        contract,
        "",
        "Output strict JSON only.",
    ]
    return system, "\n".join(user_parts)
