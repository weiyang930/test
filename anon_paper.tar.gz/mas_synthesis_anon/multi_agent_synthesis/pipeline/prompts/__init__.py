"""pipeline-private prompt builders. Forked from ../../prompts/ with the
deprecated multi-intent machinery removed (single-intent only). v4/v3/v0 keep
their shared originals untouched."""
