"""pipeline Macro Planner prompt builder (forked from ../../prompts/macro_planner).

Forked so v5 can make the macro ONTOLOGY-DRIVEN: the allowed dimension keys are
derived from the live schema (not the hardcoded 6) so a reflector-added axis
(e.g. num_write) can actually be pinned, and a NEWLY-ADDED-AXES block tells the
macro to deliberately lean into a just-promoted axis's under-covered values. The
shared v4 prompt (used by the synthesis pipeline) is untouched.

Cold-start behavior is unchanged: with no feedback a 6-DIMENSION balance prior is
injected (strong = balanced full-coverage seed; weak = under-curated natural skew).
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

PROMPT_VERSION = "macro_planner_v1"

# 6-dimension cold-start prior. No feedback yet -> aim for a balanced, uniform-ish
# spread over the SIX base axes (the original mother-642 schema). The goal is NOT
# to hit a benchmark ceiling on round 1 -- it is to give the self-evolving loop a
# non-degenerate starting distribution so every cell gets measurable support.
# --- STRONG prior (round-1, 2026-06-23: scored 64.4%) -------------------------
# Actively engineers a balanced, full-coverage, all-difficulty, 50/50
# fulfill/refuse distribution. This essentially hands the "answer" to round 1, so
# the round-1 score lands close to the curated mother-642 (64.4% vs 68.8%, gap <
# 1 stdev). Kept for reproducibility / as the strong baseline; selected by
# prior_strength="strong".
_COLD_START_6DIM_STRONG = """COLD-START COVERAGE PRIOR (no feedback yet -- aim for a \
BALANCED, uniform-ish spread over the six base dimensions, NOT a natural-traffic \
distribution):
- Spread budget roughly EVENLY across task_family: every family should get a \
comparable share of the blueprint slots. Do NOT let one or two families dominate.
- Spread expected_outcome across fulfill / refuse: aim for a roughly even split. \
Do NOT make everything fulfill or everything refuse -- refuse (policy-trap) tasks \
are as important as fulfill tasks.
- Vary policy_or_constraint_focus widely across the listed values so no single \
constraint is over-represented; pair them sensibly with the task_family.
- Vary tool_use_pattern and interaction_challenge so the batch exercises the full \
range (lookups, verifies, multi-hop, confirmations; missing-info, ambiguity, \
false-claim, pressure).
- Spread difficulty_profile across easy / medium / hard.
- This is a deliberately exploratory, uniform-ish seed. We WANT every \
(task_family x outcome) cell to get enough samples to be measurable next round; \
we do NOT want round 1 to over-optimize any single shape.
"""

# --- WEAK prior (2026-06-23: deliberately under-curated round-1) --------------
# The strong prior was TOO good: by forcing 50/50 fulfill/refuse and a full
# easy/medium/hard spread it over-represented exactly the hard refuse/policy-trap
# cells the model is weakest on, training them up and pushing round-1 within
# noise of the mother. The weak prior removes that engineering: it asks only for a
# plausible, realistic batch and lets the distribution fall where the LLM's own
# sense of "typical customer traffic" puts it -- which skews fulfill-heavy and
# easier, leaving the hard refuse cells under-covered. That under-coverage is the
# point: it lowers the round-1 ceiling (expected ~60% or below) and opens a real
# gap for the feedback loop to discover and close. Selected by prior_strength="weak".
_COLD_START_6DIM_WEAK = """COLD-START PRIOR (no feedback yet -- generate a PLAUSIBLE, \
realistic first batch; do NOT engineer a balanced or full-coverage distribution):
- Cover several task_family values so the batch is not single-family, but you do \
NOT need an even split -- let the mix reflect what a realistic stream of customer \
requests would look like.
- Choose expected_outcome naturally per task: most everyday requests can be \
fulfilled, so do NOT force a 50/50 fulfill/refuse split -- include refuse cases \
only where they arise organically.
- Pick policy_or_constraint_focus, tool_use_pattern and interaction_challenge \
that fit each task; you need not deliberately span their full ranges.
- Let difficulty_profile fall where it naturally lands; do NOT deliberately \
manufacture an even easy/medium/hard spread.
- This is an intentionally under-curated seed. It is FINE if some cells end up \
sparsely covered or missing -- those gaps are what the next feedback round is \
meant to detect and fill. Do not try to pre-empt the loop by covering everything now.
"""

# prior_strength -> prior text. Default "strong" preserves the round-1 behavior.
_COLD_START_PRIORS = {
    "strong": _COLD_START_6DIM_STRONG,
    "weak": _COLD_START_6DIM_WEAK,
}

# Static semantics for each recommended_macro_signals bucket. The leading word
# (INVEST / SUPPLEMENT / SATURATED / PAUSE / EXPLORE) is what the prompt and the
# tests key on.
_BUCKET_RUBRIC = (
    ("high_priority_keys",
     "INVEST: lean into these directions (assign high budget)."),
    ("medium_priority_keys",
     "SUPPLEMENT: moderate additional coverage."),
    ("low_priority_keys",
     "SATURATED/MASTERED: generate sparingly or not at all."),
    ("zero_or_pause_keys",
     "PAUSE: do NOT actively add these; anything regressed needs diagnosis, "
     "not more volume."),
    ("explore_keys",
     "EXPLORE: weak and stagnant -- worth probing from a new angle (small "
     "exploratory budget)."),
)


def _render_key_ref(key: Dict[str, Any]) -> str:
    """One key-ref dict -> one line. marginal: dim=value; pairwise: d1=v1 x d2=v2."""
    dims = key.get("dimensions") or []
    vals = key.get("values") or []
    body = " x ".join(f"{d}={v}" for d, v in zip(dims, vals))
    return f"- {key.get('key_type', 'marginal')}: {body}"


def format_feedback_signals(signals: Optional[Dict[str, Any]]) -> str:
    """Render recommended_macro_signals (5 buckets) into a compact structured
    block. Returns "" when signals is None/empty or every bucket is empty, so the
    no-feedback prompt is byte-identical to the cold-start path."""
    if not signals:
        return ""
    sections = []
    for bucket, rubric in _BUCKET_RUBRIC:
        keys = signals.get(bucket) or []
        if not keys:
            continue
        lines = [f"[{bucket}] {rubric}"]
        lines.extend(_render_key_ref(k) for k in keys)
        sections.append("\n".join(lines))
    if not sections:
        return ""
    header = (
        "FEEDBACK FROM LAST ROUND (coverage x task-agent performance):\n"
        "Treat these as PRIORITY SIGNALS, not hard rules. Use your judgment "
        "about how strongly to act on each."
    )
    return header + "\n\n" + "\n\n".join(sections)


_SYSTEM_TMPL = """You are the MACRO planner for an interactive tool-use task \
synthesizer. You decide the DIRECTIONS the next batch of synthesized tasks \
should cover, and how much budget each direction gets. You do NOT write a \
concrete task or a full dimension selection -- a downstream MICRO planner does \
that. You only emit partial constraints over the shared dimension schema.

Each condition uses these fields:
- condition_id: short unique string.
- objective_type: one of [undercovered, over_mastered, failure_targeted, \
exploration, repair].
- objective: one sentence on what CAPABILITY this direction exercises (e.g. \
"needs two writes", "needs a constrained-optimization computation"). State the \
skill/shape, NOT a fixed action script -- do NOT dictate a specific tool sequence \
on a specific entity (e.g. "book a new reservation then update THAT new \
reservation"). Which concrete, replayable write combination realizes the shape is \
the downstream planner's job; over-scripting it here can force an unrealizable \
trajectory.
- preferred_values: {dimension_key: [values]} SOFT preference (micro is \
encouraged to pick from these).
- allowed_values: {dimension_key: [values]} HARD constraint (micro must pick \
from these for that key).
- forbidden_values: {dimension_key: [values]} HARD exclusion.
- avoid_patterns: list of cross-dimension bad patterns to avoid (e.g. \
"modify_without_policy_check", "lookup_only").
- budget_level: one of [zero, low, medium, high, explore]. Higher = more \
samples allocated to this direction. "zero" means do NOT generate this. \
"explore" is a small exploratory budget.
- rationale: why this direction is useful.

Rules:
- The keys inside preferred_values / allowed_values / forbidden_values MUST be \
dimension keys from the schema shown below (@@KEY_LIST@@). Do NOT invent new KEYS.
- You MAY propose a new VALUE that is not in the listed value lists, if it \
opens up a genuinely useful uncovered direction AND is realizable with the \
shown tools/policy. Ground every new value in the environment shown; do not \
hallucinate values the tools/policy cannot support.
- Output STRICT JSON only, no markdown."""

def _system_prompt(key_list: str) -> str:
    return _SYSTEM_TMPL.replace("@@KEY_LIST@@", key_list)


def _newly_added_block(axes: Optional[List[Dict[str, Any]]]) -> str:
    """Tell the macro to deliberately tilt toward a just-promoted axis's
    under-covered values. ``axes`` = [{name, values, why}], from the ontology
    update of the PREVIOUS round. Empty -> "" (prompt unchanged)."""
    if not axes:
        return ""
    lines = [
        "NEWLY ADDED DIMENSION(S) THIS ROUND (the ontology reflector just promoted "
        "these axes -- they are BRAND NEW and currently UNDER-COVERED in the data):"
    ]
    for a in axes:
        name = a.get("name", "")
        vals = a.get("values") or []
        why = a.get("why") or ""
        lines.append(f"- {name} (values: {', '.join(str(v) for v in vals)})"
                     + (f" -- {why}" if why else ""))
    lines.append(
        "DELIBERATELY allocate budget so the next batch SPANS each new axis's value "
        "range -- especially the values that are currently empty/under-covered (e.g. "
        "the high end of a count axis). Pin the new axis in preferred_values/"
        "allowed_values on several conditions and give those a real (medium/high) "
        "budget. Do NOT leave a newly added axis unsampled this round.")
    return "\n".join(lines)


_OUTPUT_CONTRACT = """Return a JSON object with EXACTLY this schema:

{
  "conditions": [
    {
      "condition_id": "<short unique string>",
      "objective_type": "undercovered | over_mastered | failure_targeted | exploration | repair",
      "objective": "<one sentence>",
      "preferred_values": {"<dimension_key>": ["<value>", "..."]},
      "allowed_values": {"<dimension_key>": ["<value>", "..."]},
      "forbidden_values": {"<dimension_key>": ["<value>", "..."]},
      "avoid_patterns": ["<cross-dimension bad pattern>", "..."],
      "budget_level": "zero | low | medium | high | explore",
      "rationale": "<why useful>"
    }
  ]
}

Any of preferred_values / allowed_values / forbidden_values / avoid_patterns \
may be empty. Propose enough conditions (with budget levels) to sensibly fill \
the requested number of blueprint slots."""


def build_macro_prompt(
    domain: str,
    context_summary: str,
    tool_schema_summary: str,
    policy_summary: str,
    dimension_values_json: Dict[str, Any],
    n: int,
    feedback: Optional[Dict[str, Any]] = None,
    prior_strength: str = "strong",
    newly_added_axes: Optional[List[Dict[str, Any]]] = None,
) -> Tuple[str, str]:
    """Return (system, user) for one v5 macro proposal call.

    The allowed dimension KEYS are derived from ``dimension_values_json`` (the live
    active ontology), so a reflector-added axis can be pinned -- not hardcoded to 6.

    ``feedback`` is the summary's ``recommended_macro_signals`` dict (or None).
    On cold start (no feedback) a 6-dimension cold-start prior is injected;
    ``prior_strength`` selects strong (balanced) or weak (under-curated) seed.

    ``newly_added_axes`` = [{name, values, why}] for any axis the reflector promoted
    in the PREVIOUS round; when present, a block tells the macro to deliberately
    tilt budget toward those new axes' under-covered values (this is what makes a
    just-promoted axis actually get sampled next round).
    """
    key_list = ", ".join((dimension_values_json.get("dimension_values") or {}).keys())
    user_parts = [
        f"Propose generation directions to fill {n} blueprint slots for this domain.",
        "",
        f"DOMAIN:\n{domain}",
        "",
        f"DOMAIN CONTEXT SUMMARY:\n{context_summary}",
        "",
        f"AVAILABLE TOOLS SUMMARY:\n{tool_schema_summary}",
        "",
        f"POLICY SUMMARY:\n{policy_summary}",
        "",
        "EXISTING DIMENSION VALUES (you may propose NEW values beyond these):",
        json.dumps(dimension_values_json, ensure_ascii=False, indent=2),
        "",
    ]
    new_axis_block = _newly_added_block(newly_added_axes)
    if new_axis_block:
        user_parts.extend([new_axis_block, ""])
    feedback_block = format_feedback_signals(feedback)
    if feedback_block:
        # With feedback, the loop drives the mix -- no cold-start prior.
        user_parts.extend([feedback_block, ""])
    elif new_axis_block:
        # A just-promoted axis is a DIRECTED signal (attack this new dimension),
        # not a cold start. The balanced cold-start prior would fight it -- it
        # forces 50/50 fulfill/refuse (refuse => 0 writes) and spreads budget
        # evenly across all six seed axes, diluting the very concentration the new
        # axis asks for. So a new-axis round is NOT cold: skip the prior and let
        # the NEWLY-ADDED-AXES block drive the mix.
        pass
    else:
        # True cold start: no feedback AND no new axis -> seed a starting prior.
        prior = _COLD_START_PRIORS.get(prior_strength, _COLD_START_6DIM_STRONG)
        user_parts.extend([prior, ""])
    user_parts.extend([
        _OUTPUT_CONTRACT,
        "",
        "Output strict JSON only.",
    ])
    return _system_prompt(key_list), "\n".join(user_parts)
