"""pipeline Free-Exploration synthesis agent prompt (dimension-value paradigm).

Forked from ../../prompts/explore.py and trimmed to the clean v5 scope:
the deprecated multi-intent, ACTION-basis, and fail-set machinery are all
removed. Exploration is always SINGLE-INTENT, judged by DB-hash. `mixed` is
handled as a single-task expected_outcome.

Unlike the summarizer Task Synthesis Agent -- which is HANDED a curated, joined
entity view by a plan-agnostic sampler and drafts a task from it -- this agent is
dropped into a LIVE environment with only the dimension plan, the tool catalog,
and a handful of bare seed ids. It then FREELY decides what to look up, discovers
real entities itself by calling read tools, may trial-run a write to confirm
feasibility, and finally SUBMITS a complete task spec.

The submitted task uses the SAME strict-JSON schema the summarizer agent emits
(``synthesis_base._OUTPUT_CONTRACT``) so the downstream replay gate / verifier /
exporters are untouched. The submitted candidate_pseudo_gt_actions are still a
DRAFT -- the deterministic replay reward==1 is the sole arbiter of correctness.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

from .synthesis_base import _AIRLINE_DETERMINISM_DB, _OUTPUT_CONTRACT

PROMPT_VERSION = "explore_v2_axis_realization"

_SYSTEM_HEAD = """You are a benchmark task DESIGNER operating a live tool-use \
environment. You design ONE concrete, replay-safe SINGLE-INTENT task (exactly one \
task_family) that matches a given plan, by EXPLORING the environment yourself to \
find real entities -- you are not given a curated record list, only a few seed ids \
to start from.

Work in turns. Each turn output a SINGLE JSON object and nothing else:

To explore (look something up, or trial-run a change to confirm it works):
{"action": "call", "actor": "assistant", "name": "<tool>", "arguments": {...}}

When you have found real entities that fit the plan, submit the finished task:
{"action": "submit", "task": {<the task object, schema below>}}

The plan carries an `expected_outcome` that decides what the task -- and its \
candidate_pseudo_gt_actions -- must look like:

- expected_outcome = "fulfill": the user's request is policy-COMPLIANT. Find \
real entities on which the request CAN be carried out, confirm the resolving \
write works, and put the confirmed state-changing write(s) into \
candidate_pseudo_gt_actions.

- expected_outcome = "refuse": this is a POLICY TRAP. The user will ask for an \
action that VIOLATES the plan's policy_or_constraint_focus (e.g. a refund / \
cancellation / change the policy forbids). Find real entities on which the \
request is genuinely NOT allowed -- verify with READ tools that the policy is \
violated (e.g. the reservation is past the refund window, the fare class is \
non-refundable, the booking is too old). The CORRECT behavior is to DECLINE, so \
candidate_pseudo_gt_actions must contain NO state-changing write -- leave it as \
an EMPTY list. Do NOT perform the forbidden action. Capture the violated rule and \
the read facts that prove it in hidden_task_spec.

- expected_outcome = "mixed": within the SAME single-family task the user bundles \
a policy-COMPLIANT part (carry it out -> resolving write) AND a part that VIOLATES \
the policy_or_constraint_focus (must DECLINE). Find real entities where exactly \
this split holds; candidate_pseudo_gt_actions contains ONLY the write(s) for the \
compliant part and NO write for the forbidden part. Capture both requests and the \
read fact that forbids the forbidden one in hidden_task_spec."""

# Reflector-added axes (num_write, computation) are declared in the plan but the
# explore agent, left to its own devices, tends to satisfy only the write shape
# and silently skip the arithmetic -- so a plan that declares computation gets
# REJECTED by the conformance gate ("declared aggregate but GT realizes no
# arithmetic"). This block makes both axes explicit, mirroring the (validated)
# synthesis realization instructions but phrased for the exploration loop.
_AXIS_REALIZATION = """
REALIZING THE PLAN'S num_write AND computation AXES (both are MANDATORY when the \
plan declares them -- the downstream conformance gate rejects a task that declares \
an axis it does not realize):

- num_write = the number of STATE-CHANGING write calls the solution requires \
(reads never count). If the plan asks for 2 / 3-4 / 5+ writes, you MUST design a \
COHERENT business request that genuinely needs that many writes against REAL \
entities you discovered -- e.g. change a reservation's flights AND add baggage AND \
correct a passenger name (3 writes on one reservation), or cancel one reservation \
AND modify another. Do NOT pad with meaningless repeats; each write must be a real \
part of the user's story and must replay to reward==1. Prefer writes on EXISTING \
reservations (update_*/cancel) to reach the high end -- they are easiest to ground \
to exact values. If you use book_reservation, you MUST have first called \
search_direct_flight/search_onestop_flight and read the ACTUAL flight numbers and \
prices, and the payment_methods amounts MUST sum to the exact total the env will \
charge (trial-run the book in this scratch env to confirm it succeeds before \
submitting) -- a book with guessed prices or FLIGHT_FROM_SEARCH-style placeholders \
will fail replay.

- computation != none = the task requires arithmetic the agent must actually \
perform. You MUST include the ``calculate`` call(s) in candidate_pseudo_gt_actions \
with a CONCRETE numeric expression built from the REAL prices/fees/balances you \
read during exploration (e.g. "164 + 268 - 100", never symbolic names like \
business_price_leg1), AND when the plan's computation is ``aggregate`` (a total the \
user asked to be told), put the exact resulting figure as a string in \
``communicate_info`` (e.g. ["712"]). Ground every number in values you actually \
observed so the arithmetic is deterministic. If computation is "none", do NOT add \
a calculate call.

"""

# Telecom is the only "authoring" domain: airline/retail tasks run on the STOCK
# db (the world is already actionable, the agent DISCOVERS a real entity that
# fits the plan), but a telecom fault does not exist until the task INJECTS it.
# Each telecom task therefore must additionally AUTHOR two fields the other
# domains leave empty: `initialization_actions` (the fault script that breaks the
# device at task start) and `env_assertions` (the symptom-cleared bar the reward
# is judged on). Both are drawn VERBATIM from the family's real fault catalog
# (handed to the agent in the opening) so every func_name/argument is replay-safe
# -- the agent chooses WHICH faults (matching the plan's fault_profile +
# difficulty) and the resolving action chain, never invents func names. This
# block is injected ONLY for domain==telecom; airline/retail never see it and
# their discovery flow is byte-for-byte unchanged.
_TELECOM_FAULT_AUTHORING = """
TELECOM FAULT AUTHORING (MANDATORY for this domain -- you are AUTHORING a broken \
device, not discovering an existing fact):

A telecom task is a troubleshooting call: the customer's device is BROKEN at the \
start and the agent must guide them (and/or act on the backend) until the symptom \
clears. The break does not exist in the stock world -- YOU must script it. The \
FAULT CATALOG in the opening lists, per family, a set of {fault -> fix -> proof} \
TRIPLES plus the family's `baseline_assertions`. You compose a task by SELECTING \
triples; never invent func names or arguments -- copy them VERBATIM from the \
catalog.

STEP 1 -- pick triples. Choose AS MANY catalog triples as the plan's difficulty \
implies (easy=1, medium=2, hard=3 -- see difficulty_fault_counts), matching the \
plan's `fault_profile` / `diagnostic_challenge`. For multi_fault_stacked / \
nested_path_dependency, pick distinct triples that stack.

STEP 2 -- emit "initialization_actions" (top-level): the fault script replayed at \
task start. It MUST be:
    1. FIRST a user identity bind: {"env_type":"user","func_name":"set_user_info",\
"arguments":{"name":"<real customer full_name>","phone_number":"<a real LINE \
phone_number you discovered, e.g. 555-123-2004>"}} (identify by a LINE phone, NOT \
the account contact number);
    2. THEN, for EACH picked triple, that triple's `fault` call(s) copied VERBATIM \
(a triple's `fault` may be a single call or a list -- include all of them).
Whenever a triple's fault/fix references customer_id/line_id, use the SAME real \
ids you bound in set_user_info (the catalog shows C1001/L1002 as a template -- \
rebind to your discovered ids).

STEP 3 -- emit "env_assertions" (top-level): the hidden success bar. This is a \
LIST and usually has MORE THAN ONE element. Build it as:
    (a) ALL of the family's `baseline_assertions` (always required), PLUS
    (b) every picked fixable triple's `extra_assertion` (if it has one -- e.g. a \
data-refuel proof).
Each element: {"env_type":...,"func_name":"assert_*","arguments":{...},\
"assert_value":true}, copied VERBATIM. The reward passes ONLY when EVERY assertion \
holds -- this is what forces the resolution to fix ALL injected faults, not just \
one.

STEP 4 -- emit the RESOLUTION CHAIN into candidate_pseudo_gt_actions, in order: \
the concatenation of every picked triple's `fix` calls (each with its real \
`actor` -- device fixes are actor "user", backend fixes like enable_roaming/\
refuel_data/resume_line/send_payment_request are actor "assistant"). Emit each as \
{"actor":..,"tool_name":<name>,"arguments":{...}}. Cover EVERY injected fault.

expected_outcome for telecom (set reward_basis accordingly):
- "resolved": every picked triple is fixable. The resolution chain clears ALL \
faults so every env_assertion passes. reward_basis = ["ENV_ASSERTION"].
- "escalate_transfer": you picked at least one triple with `fixable: false` (e.g. \
a SIM PIN lock). The fault CANNOT be self-served, so the symptom stays broken and \
the CORRECT action is to escalate. In this case:
    * "env_assertions" = the family's `unsolved_assertion` as a one-element list \
(the STILL-BROKEN bar, e.g. assert_service_status expected "no_service") -- do NOT \
use baseline_assertions, and do NOT attempt a device fix for the unfixable part;
    * candidate_pseudo_gt_actions = the picked triple's `fix` (the \
transfer_to_human_agents call), actor "assistant";
    * reward_basis = ["ENV_ASSERTION", "ACTION"] (judged on BOTH the still-broken \
symptom AND the transfer call).
  Do NOT mix fixable and unfixable faults in one task -- an escalate task's faults \
are unfixable-only.

Bind the identity (name + line phone) to a REAL customer/line you looked up during \
exploration. Every fault/fix/assertion func name comes ONLY from the catalog.
"""

# car-bench is the SECOND authoring domain (after telecom), but authors a
# different thing: NOT a fault script, but the vehicle's INITIAL STATE. The world
# starts from a DEFAULT vehicle context; a car task pins a concrete starting
# configuration (windows/climate/lights/nav/battery/occupancy/...) so the scenario
# and its precondition/trap actually hold, then defines the GT tool sequence. Two
# further differences from airline/retail discovery:
#   1. GT includes READS, not only writes. car reward checks that GT's non-respond
#      tools are a SUBSET of what the agent calls, so any read the scenario truly
#      needs (get_weather before ambient lighting, get_user_preferences to resolve
#      an ambiguity, a get_* to confirm a precondition) MUST be in the GT list.
#   2. hallucination / disambiguation tasks have NO state-changing GT: the correct
#      behavior is a user-facing message (decline / clarify), so GT contains the
#      user-as-a-tool action (respond / ask_user_for_confirmation / clarify_*) and
#      NO write. This block is injected ONLY for domain==car.
_CAR_AUTHORING = """
CAR TASK AUTHORING (MANDATORY for this domain -- you are AUTHORING a vehicle's \
INITIAL STATE, then a tool-use scenario on it):

A car task is a single-turn-of-events voice-assistant request against ONE vehicle. \
The vehicle has a full state (windows, sunroof, sunshade, climate, lights, nav, \
battery/charging, occupancy, contacts/calendar) that starts from a DEFAULT unless \
you pin it. You author the task in three parts:

STEP 1 -- author the INITIAL VEHICLE STATE. Copy ONE of the REAL context templates \
in the opening (a full `context_init_config` dict, 40+ keys) as your baseline, then \
CHANGE only the keys your scenario needs -- e.g. set `sunshade_position` so a \
"close the sunshade" request has something to close; set `air_conditioning` true so \
opening a window >25% trips the AC policy; set an occupant so seat-heating is \
allowed; set `current_location`/`current_datetime` for a weather/nav scenario. Use \
READ tools during exploration to confirm exactly what the tools return for your \
chosen state. Keep every other key from the template unchanged (they must remain a \
valid, complete vehicle state).

STEP 2 -- decide the CORRECT BEHAVIOR from the plan's task_nature + expected_behavior:
- base_execute / fulfill_reach_goal: the request is fully achievable. GT = the \
read(s) the scenario genuinely needs THEN the state-changing write(s) that reach \
the goal. Trial-run each write in this scratch env to confirm it succeeds.
- hallucination_* / decline_infeasible: the request needs a capability that is \
absent (a tool that does not exist for this action, a parameter the tool does not \
accept, or information no tool can return). The vehicle CANNOT satisfy it, so the \
correct behavior is to tell the user it cannot be done. GT contains NO write -- only \
a user-facing `respond` action stating the limitation. (You are NOT removing a \
tool; you are picking a request the 57-tool surface genuinely cannot fulfill.)
- disambiguation_internal / resolve_from_preferences: the request is under-specified \
but resolvable WITHOUT asking -- call get_user_preferences, resolve the value from \
it, THEN carry out the write. GT = [get_user_preferences, <the resolved write(s)>].
- disambiguation_user / clarify_with_user: the request is genuinely ambiguous and \
NOT resolvable from preferences. The correct behavior is to ask the user a \
clarifying question. GT contains NO write -- only the user-facing clarify action.

STEP 3 -- emit the GT into candidate_pseudo_gt_actions, in execution order, using \
REAL car tool names and arguments valid against the tool schema. INCLUDE the reads \
the scenario requires (unlike other domains, reads count). For a REQUIRES_CONFIRMATION \
tool (send_email / open_close_trunk_door / set_head_lights_high_beams) the plan's \
confirmation_required pattern means the GT must include the confirmation step first.

Emit each GT action as {"actor": "assistant"|"user", "tool_name": <name>, \
"arguments": {...}}. For decline/clarify tasks the single GT action is a user-facing \
message tool (actor "assistant", e.g. tool_name "respond") with the message text in \
arguments -- NO vehicle-state write.

HARD REQUIREMENT FOR THE base_execute DATASET (this run synthesizes ONLY \
base_execute tasks -- every plan's task_nature is base_execute and its \
expected_behavior is fulfill_reach_goal or resolve_from_preferences):
- candidate_pseudo_gt_actions MUST end with at least ONE state-changing WRITE tool \
(a SET_VEHICLE_STATE tool such as set_climate_temperature, open_close_window, \
set_charging_*, send_email, etc.). A GT that contains ONLY reads and/or a `respond` \
message is INVALID and the sample is DISCARDED.
- Do NOT stop the task at a clarifying question. If the request is under-specified, \
this is a resolve_from_preferences task: call get_user_preferences (or the relevant \
read), RESOLVE the value yourself, THEN perform the write(s). The correct terminal \
behavior is that the vehicle state changed -- never an open-ended question back to \
the user.
- Do NOT author a request the vehicle cannot satisfy (that is the decline dataset, \
synthesized separately). Every base_execute request MUST be genuinely achievable \
with the 57-tool surface, and your GT MUST carry it out to completion.
- Before submitting, re-read your candidate_pseudo_gt_actions: if the last action is \
a `respond`/ask/clarify with no preceding write, REVISE the task into a concrete \
achievable request and add the resolving write(s).
"""

# car-only addendum: carry the authored initial vehicle state (and the car task
# metadata the adapter needs to reconstruct + score) inside ONE sentinel top-level
# initialization_action. This reuses the exact telecom `initialization_actions`
# carrier the pipeline already threads through _to_candidate -> the adapter's
# _extract_car_task_fields parses it back out. airline/retail never see this.
_CAR_SCHEMA_ADDENDUM = """CAR ONLY -- add this EXTRA top-level field to the \
submitted task object (in addition to the schema above). It carries the authored \
initial vehicle state so the environment can be reconstructed at task start:

  "initialization_actions": [
    {"func_name": "__car_context_init__", "arguments": {"car_task": {
       "context_init_config": {<the FULL 40+ key vehicle state you authored in STEP 1>},
       "calendar_id": "<a calendar id from a template, or "">",
       "task_type": "<base|hallucination|disambiguation>"
    }}}
  ]

task_type is: "base" for base_execute; "hallucination" for any hallucination_* \
task_nature; "disambiguation" for either disambiguation_* task_nature. \
candidate_pseudo_gt_actions holds the GT tool sequence from STEP 3 (reads + writes; \
or a single user-facing message for decline/clarify tasks). Leave \
candidate_solution_plan.reward_basis unset -- car uses its own deterministic \
self-verify, not DB/ENV_ASSERTION."""


_SYSTEM_TAIL = _AXIS_REALIZATION + """
Exploration rules:
- Start from the seed ids. Look records up with READ tools, follow references \
(a user's reservations, a reservation's flights), branch until you find entities \
that fit the plan's task_family, expected_outcome, and constraints.
- Bind every id in the task to a REAL id you actually saw in a tool result. \
Never invent ids.
- For fulfill tasks you MAY call a write tool during exploration to confirm it \
succeeds; this is a scratch environment. For refuse tasks, do NOT call the \
forbidden write -- only read enough to PROVE the request must be denied.
- Keep exploring (don't submit) until you can fill every required field with \
real, verified values."""


# Telecom-only addendum: the base _OUTPUT_CONTRACT (shared with airline/retail)
# has no fault-authoring slots. For telecom we permit two EXTRA top-level fields
# on the submitted task object. Kept out of the shared contract so airline/retail
# never see them.
_TELECOM_SCHEMA_ADDENDUM = """TELECOM ONLY -- add these two EXTRA top-level fields \
to the submitted task object (in addition to the schema above):

  "initialization_actions": [
    {"env_type":"user","func_name":"set_user_info","arguments":{"name":"<full name>","phone_number":"<line phone>"}},
    {"env_type":"<user|assistant>","func_name":"<fault func from a picked triple>","arguments":{<verbatim>}}
    // ... one (or more) fault call(s) per picked triple
  ],
  "env_assertions": [
    // resolved task: ALL of the family's baseline_assertions + each picked triple's extra_assertion
    {"env_type":"user","func_name":"assert_<...>","arguments":{"expected_status":<...>},"assert_value":true},
    {"env_type":"assistant","func_name":"assert_<...>","arguments":{<...>},"assert_value":true}
    // escalate_transfer task: instead a ONE-element list = the family's unsolved_assertion (still-broken bar)
  ]

Set candidate_solution_plan.reward_basis = ["ENV_ASSERTION"] for a resolved task, \
or ["ENV_ASSERTION", "ACTION"] for an escalate_transfer task. \
candidate_pseudo_gt_actions holds the resolution chain (the concatenation of every \
picked triple's fix, each with its real "actor"). These fields are copied VERBATIM \
from the FAULT CATALOG -- never invent func names, and env_assertions is normally \
a MULTI-element list."""


def build_explore_system(determinism_note: str = "", domain: str = "") -> str:
    system = _SYSTEM_HEAD + _SYSTEM_TAIL
    out = [system]
    # Authoring domains inject their own authoring block. telecom scripts a fault +
    # assertion; car authors the initial vehicle state. The blocks are domain-gated
    # so airline/retail prompts are byte-for-byte unchanged.
    if domain == "telecom":
        out += ["", _TELECOM_FAULT_AUTHORING]
    elif domain == "car":
        out += ["", _CAR_AUTHORING]
    if determinism_note:
        out += ["", determinism_note]
    out += ["", "SUBMITTED TASK SCHEMA (the value of \"task\"):", _OUTPUT_CONTRACT]
    if domain == "telecom":
        out += ["", _TELECOM_SCHEMA_ADDENDUM]
    elif domain == "car":
        out += ["", _CAR_SCHEMA_ADDENDUM]
    return "\n".join(out)


def build_explore_opening(
    domain: str,
    plan: Dict[str, Any],
    tool_schema_summary: str,
    database_summary: str,
    policy_text: str,
    seed_ids: List[str],
    fault_catalog: Any = None,
    car_context_templates: Any = None,
) -> str:
    """The first user turn that frames the design task and seeds exploration.

    ``fault_catalog`` (telecom only) is the per-family {fault -> fix -> proof}
    triple catalog + baseline_assertions the authoring block draws from; None for
    airline/retail, whose opening is unchanged.

    ``car_context_templates`` (car only) is a list of REAL full ``context_init_
    config`` dicts the authoring block copies + tweaks for STEP 1; None elsewhere."""
    parts = [
        "Design one task from the following plan by exploring the environment.",
        "",
        f"DOMAIN:\n{domain}",
        "",
        "SYNTHESIS PLAN:",
        json.dumps(plan, ensure_ascii=False, indent=2),
        "",
        f"TOOL SCHEMAS:\n{tool_schema_summary}",
        "",
        f"DATABASE / ENVIRONMENT SUMMARY:\n{database_summary}",
        "",
        f"POLICY:\n{policy_text}",
    ]
    if fault_catalog:
        parts += [
            "",
            "FAULT CATALOG (telecom authoring). For the family matching the plan's "
            "task_family, `fault_catalog` lists {fault -> fix -> proof} triples and "
            "`baseline_assertions` lists the always-required success bars. Select "
            "triples matching fault_profile (as many as difficulty implies), copy "
            "their func_name/arguments/env_type/actor VERBATIM, and build "
            "env_assertions = baseline_assertions + each picked triple's "
            "extra_assertion. Triples with fixable:false are escalate-only (use the "
            "family's unsolved_assertion). Rebind the C1001/L1002 template ids to "
            "the real customer/line you discovered:",
            json.dumps(fault_catalog, ensure_ascii=False, indent=2),
        ]
    if car_context_templates:
        parts += [
            "",
            "REAL VEHICLE-STATE TEMPLATES (car authoring, STEP 1). Each is a full "
            "`context_init_config` from a real task. COPY one as your baseline and "
            "change ONLY the keys your scenario needs; keep every other key so the "
            "state stays a valid, complete vehicle configuration:",
            json.dumps(car_context_templates, ensure_ascii=False, indent=2),
        ]
    parts += [
        "",
        "SEED IDS to start exploring from (look these up first, then branch):",
        json.dumps(seed_ids, ensure_ascii=False),
        "",
        "Begin exploring. Respond with one JSON action.",
    ]
    return "\n".join(parts)


def airline_determinism_note_db() -> str:
    return _AIRLINE_DETERMINISM_DB
