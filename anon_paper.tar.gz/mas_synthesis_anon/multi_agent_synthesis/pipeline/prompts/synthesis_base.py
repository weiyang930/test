"""pipeline Task Synthesis Agent prompt builder (dimension-value paradigm).

Forked from ../../prompts/synthesis_base.py and trimmed to the clean v5 scope:
the deprecated multi-intent, ACTION-basis, and fail-set machinery are all
removed. Synthesis is always SINGLE-INTENT (one task_family), judged by DB-hash
(in-place writes against existing entities). `mixed` is handled as a single-task
expected_outcome (one allowed write + one declined forbidden part).

Instantiates ONE structured synthesis plan into ONE concrete, executable task
bound to REAL environment entities. Adapted from the user's AReaL-SEA spec §4.

The agent only sees obtainable info (tool schemas, db field surface, policy) +
a sample of REAL entities pulled from the live DB (concrete ids it must use, not
invent). It outputs candidate pseudo-GT actions which are NOT trusted yet -- the
deterministic replay gate downstream is the sole arbiter of correctness.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Tuple

PROMPT_VERSION = "synthesis_v1"

_SYSTEM = """You are a task synthesis agent for interactive tool-use benchmark \
environments.

Your job is to instantiate a structured synthesis plan into ONE concrete, \
executable task, bound to REAL entities from the environment database. Your \
output defines the task, hidden constraints, expected completion criteria, and a \
candidate pseudo-ground-truth action plan.

Principles:
- The task must be executable under the current environment state.
- The task must require genuine tool use; it must NOT be solvable from the user \
instruction alone.
- The user-facing instruction must NOT reveal all hidden validation criteria.
- Use REAL entity ids from the provided sample (do not invent ids).
- The task is SINGLE-INTENT: exactly one task_family. The task must match the \
selected planner dimensions (family, expected_outcome, focus, patterns, difficulty).
- Honor the plan's expected_outcome:
  * "fulfill": the request is policy-compliant; candidate_pseudo_gt_actions are \
the state-changing write(s) that resolve it, each directly replayable.
  * "refuse": the request VIOLATES the plan's policy_or_constraint_focus and the \
correct behavior is to DECLINE. candidate_pseudo_gt_actions MUST be an EMPTY list \
(no state change). State the forbidden request, the violated rule, and the \
database fact that proves it must be denied, in hidden_task_spec.
  * "mixed": within the SAME single-family task the user bundles a policy-COMPLIANT \
part (the agent carries it out -> resolving write) AND a part that VIOLATES the \
policy_or_constraint_focus (the agent must DECLINE). candidate_pseudo_gt_actions \
contains ONLY the write(s) for the compliant part and NO write for the forbidden \
part. Record both the allowed and forbidden request + the DB fact that forbids it \
in hidden_task_spec.
- If the plan requires clarification, the initial user instruction should omit \
some info naturally; put what the user can later provide in user_private_info.
- If the plan allows a user false claim, state the false claim AND the database \
fact that contradicts it in hidden_task_spec.
- For a fulfill task, specify the confirmation needed before a state change.
- Output STRICT JSON only. No markdown, no commentary."""

_OUTPUT_CONTRACT = """Return a JSON object with EXACTLY this schema:

{
  "task_id": "<string>",
  "domain": "<domain>",
  "source_plan_id": "<the plan_id>",
  "selected_dimensions": {<copy of the plan's selected_dimensions>},
  "user_instruction": "<what the simulated user initially says; a plain string>",
  "hidden_task_spec": {
    "scenario_context": "<string>",
    "user_private_info": {<info the user can reveal when asked>},
    "ground_truth_facts": ["<fact grounded in the real entities>"],
    "hidden_constraints": ["<policy/eligibility constraint not stated upfront>"],
    "policy_constraints": ["<relevant policy rule>"],
    "expected_completion_criteria": ["<observable success condition>"],
    "must_have_tool_calls": ["<tool name the solution must use>"],
    "forbidden_actions": ["<action that must NOT occur>"],
    "confirmation_requirements": ["<what to confirm before a state change>"]
  },
  "required_entities": {
    "customers_or_accounts": [<real ids>],
    "orders_or_reservations_or_lines": [<real ids>],
    "products_or_flights_or_plans": [<real ids>],
    "payments_or_credits_or_memberships": [<real ids>],
    "other_entities": []
  },
  "candidate_solution_plan": {
    "high_level_steps": ["<step>", "..."],
    "candidate_pseudo_gt_actions": [
      {"step_id": 1, "actor": "assistant", "action_type": "tool_call",
       "tool_name": "<tool>", "arguments": {<concrete args using REAL ids>},
       "purpose": "<why>"}
    ],
    "expected_final_state": {<partial final-state description>},
    "expected_user_visible_resolution": "<string>"
  },
  "task_quality_notes": {
    "why_requires_tool_use": "<string>",
    "why_matches_plan": "<string>",
    "difficulty_justification": "<string>",
    "possible_failure_modes": ["<string>"]
  }
}

Rules:
- user_instruction, scenario_context, and expected_user_visible_resolution are \
PLAIN STRINGS, never nested objects.
- candidate_pseudo_gt_actions MUST list only the STATE-CHANGING tool calls that \
constitute the solution (exclude pure read/lookup calls). Each must use REAL ids \
from the provided entity sample and arguments valid against the tool schema. \
For a "refuse" task this list MUST be EMPTY (the correct behavior is to make no \
state change), and expected_user_visible_resolution states the polite denial. For \
a "mixed" task list only the compliant part's write(s).
- These pseudo-GT actions are a DRAFT; a downstream validator replays and may \
repair them. Make them your best concrete guess."""

# Airline determinism note (judging is by database state hash; in-place writes only).
_AIRLINE_DETERMINISM_DB = """DETERMINISM REQUIREMENT (airline judging is by database \
state hash):
- Ground the task on an EXISTING reservation from the entity sample and make the \
solution an IN-PLACE modification of it (cancel it, change its cabin/flights, \
correct passenger details, or add/remove baggage), paying any fee from an \
existing payment method.
- Do NOT design tasks whose solution mints brand-new ids or timestamps (e.g. \
booking a completely new reservation, or issuing a new travel certificate): such \
actions are not reproducible by the deterministic checker and the task will be \
rejected.
- The passenger COUNT on a reservation cannot change. Payment methods must be \
ones the user already owns."""


def _entity_sample_block(entities: List[Dict[str, Any]]) -> str:
    if not entities:
        return "REAL ENTITY SAMPLE: (none provided)"
    return (
        "REAL ENTITY SAMPLE (use ONLY these concrete ids; pick whichever fits the "
        "plan):\n" + json.dumps(entities, ensure_ascii=False, indent=2)
    )


def build_synthesis_prompt(
    domain: str,
    plan: Dict[str, Any],
    tool_schema_summary: str,
    database_summary: str,
    policy_text: str,
    entity_sample: List[Dict[str, Any]],
    determinism_note: str = "",
) -> Tuple[str, str]:
    """Return (system, user) for one Task Synthesis Agent call (single-intent,
    DB-hash judging)."""
    user_parts = [
        "Instantiate one concrete task from the following synthesis plan.",
        "",
        f"DOMAIN:\n{domain}",
        "",
        "SYNTHESIS PLAN:",
        json.dumps(plan, ensure_ascii=False, indent=2),
        "",
        f"TOOL SCHEMAS:\n{tool_schema_summary}",
        "",
        f"DATABASE / ENVIRONMENT SUMMARY:\n{database_summary}",
        "",
        f"POLICY:\n{policy_text}",
        "",
        _entity_sample_block(entity_sample),
    ]
    if determinism_note:
        user_parts += ["", determinism_note]
    user_parts += ["", _OUTPUT_CONTRACT, "", "Output strict JSON only."]
    return _SYSTEM, "\n".join(user_parts)
