"""pipeline: self-evolving ontology synthesis loop (forks v4 synthesis core)."""
