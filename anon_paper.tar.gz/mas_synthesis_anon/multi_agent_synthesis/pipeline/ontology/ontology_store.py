"""Persistence + planner-view for the versioned ontology. The ontology REPLACES
the static dimension YAML as the live dimension source feeding macro/micro
planners: `to_domain_dimensions` rebuilds a DomainDimensions over ACTIVE dims
only, so the forked planners (which call .to_planner_json()/.values_for()/
.validate_selection()) need no change."""
from __future__ import annotations

import json
import os
from typing import Any, Dict

from multi_agent_synthesis.dimensions.loader import (
    DomainDimensions, load_dimensions,
)
from .ontology_schema import Dimension, Ontology


def load_ontology(version_or_path: str, ontology_dir: str = "") -> Ontology:
    path = version_or_path
    if not os.path.isfile(path) and ontology_dir:
        path = os.path.join(ontology_dir, f"{version_or_path}.json")
    with open(path, "r") as fh:
        return Ontology.model_validate(json.load(fh))


def save_ontology(ontology: Ontology, output_path: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w") as fh:
        json.dump(ontology.model_dump(), fh, indent=2)


def bootstrap_O0_from_yaml(yaml_path: str, domain: str) -> Ontology:
    spec = load_dimensions(yaml_path)
    dd = spec.for_domain(domain)
    dims = []
    for key in dd.shared_keys:
        dims.append(Dimension(
            name=key,
            description=f"seed dimension '{key}' from {os.path.basename(yaml_path)}",
            values=list(dd.values_for(key)),
            status="seed",
            source="initial_seed",
        ))
    return Ontology(ontology_version="O_0", dimensions=dims)


def to_domain_dimensions(
    ontology: Ontology,
    domain: str,
    selection_rules: Dict[str, Dict[str, int]],
    difficulty_profile: Dict[str, Any],
) -> DomainDimensions:
    active = ontology.active_dimensions()
    dimension_values = {d.name: list(d.values) for d in active}
    shared_keys = [d.name for d in active]
    rules = {k: selection_rules.get(k, {"min": 0, "max": 3}) for k in shared_keys}
    return DomainDimensions(
        domain=domain,
        shared_keys=shared_keys,
        selection_rules=rules,
        dimension_values=dimension_values,
        difficulty_profile=difficulty_profile,
        cross_rules=[],
    )


def next_version(version: str) -> str:
    n = int(version.split("_")[1])
    return f"O_{n + 1}"
