"""Versioned ontology data model. Dimensions carry a status (seed/experimental/
promoted/deprecated). Per-value status/source are sidecar maps so adding a value
never breaks the planner JSON (which only reads `values`)."""
from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import BaseModel, Field

STATUSES = ("seed", "experimental", "promoted", "deprecated")


class Dimension(BaseModel):
    name: str
    description: str = ""
    values: List[str] = Field(default_factory=list)
    status: str = "experimental"
    source: str = ""
    value_status: Dict[str, str] = Field(default_factory=dict)   # value -> status
    value_source: Dict[str, str] = Field(default_factory=dict)   # value -> source


class Ontology(BaseModel):
    ontology_version: str
    dimensions: List[Dimension] = Field(default_factory=list)

    def active_dimensions(self) -> List[Dimension]:
        return [d for d in self.dimensions if d.status != "deprecated"]

    def get(self, name: str) -> Optional[Dimension]:
        for d in self.dimensions:
            if d.name == name:
                return d
        return None

    def dimension_names(self) -> List[str]:
        return [d.name for d in self.dimensions]
