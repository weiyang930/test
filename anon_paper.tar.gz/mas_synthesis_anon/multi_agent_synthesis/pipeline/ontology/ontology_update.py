"""Apply ACCEPTED reflector decisions to produce O_{r+1} (spec §10). Never
mutates the input ontology. Status transitions:
  review.promote        : experimental -> promoted
  review.keep_experimental: no change
  review.deprecate      : experimental -> deprecated
  promote_probe_to_dimension: add new dim, status=experimental
  add_value             : append value(s), value_status=experimental
"""
from __future__ import annotations

from typing import Any, Dict, Tuple

from .ontology_schema import Dimension, Ontology
from .ontology_store import next_version


def apply_ontology_updates(
    ontology: Ontology,
    reflector_output: Dict[str, Any],
    safety_report: Dict[str, Any],
    max_new_dimensions_per_round: int = 1,
) -> Tuple[Ontology, Dict[str, Any]]:
    new = Ontology.model_validate(ontology.model_dump())  # deep copy
    new.ontology_version = next_version(ontology.ontology_version)
    applied, skipped = [], []
    new_dimensions_count = 0

    prop_safety = safety_report.get("proposals", {})
    for idx, prop in enumerate(reflector_output.get("new_proposals") or []):
        ok = prop_safety.get(idx, prop_safety.get(str(idx), {})).get("accepted", False)
        action = prop.get("action")
        if action == "no_change":
            continue
        if not ok:
            skipped.append({"proposal_index": idx, "action": action,
                            "reasons": prop_safety.get(idx, prop_safety.get(str(idx), {})).get("reasons", [])})
            continue
        if action == "promote_probe_to_dimension":
            if new_dimensions_count >= max_new_dimensions_per_round:
                skipped.append({"proposal_index": idx, "action": action,
                                "reasons": [f"exceeds max_new_dimensions_per_round={max_new_dimensions_per_round}"]})
                continue
            new.dimensions.append(Dimension(
                name=prop["dimension_name"],
                description=prop.get("description", ""),
                values=list(prop.get("values") or []),
                status="experimental",
                source=f"promoted_probe:{prop.get('probe_id')}",
            ))
            applied.append({"action": action, "dimension": prop["dimension_name"]})
            new_dimensions_count += 1
        elif action == "add_value":
            dim = new.get(prop["dimension_name"])
            for v in prop.get("values") or []:
                if v not in dim.values:
                    dim.values.append(v)
                    dim.value_status[v] = "experimental"
                    dim.value_source[v] = "reflector_add_value"
            applied.append({"action": action, "dimension": prop["dimension_name"],
                            "values": prop.get("values")})

    rev_safety = safety_report.get("reviews", {})
    for rev in reflector_output.get("dimension_reviews") or []:
        name = rev.get("dimension")
        decision = rev.get("decision")
        if not rev_safety.get(name, {}).get("accepted", False):
            skipped.append({"dimension": name, "decision": decision,
                            "reasons": rev_safety.get(name, {}).get("reasons", [])})
            continue
        dim = new.get(name)
        if decision == "promote":
            dim.status = "promoted"
        elif decision == "deprecate":
            dim.status = "deprecated"
        # keep_experimental: no-op
        applied.append({"decision": decision, "dimension": name})

    report = {
        "ontology_version_in": ontology.ontology_version,
        "ontology_version_out": new.ontology_version,
        "applied": applied,
        "skipped": skipped,
    }
    return new, report
