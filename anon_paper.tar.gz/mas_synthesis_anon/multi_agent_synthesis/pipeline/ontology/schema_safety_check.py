"""Pure STRUCTURAL gate on reflector proposals (spec §9). It NEVER judges
semantic usefulness — only validity. Any failing proposal/review is rejected and
the ontology is left unchanged for it."""
from __future__ import annotations

from typing import Any, Dict

from .ontology_schema import Ontology


def _is_identifier(name: str) -> bool:
    return bool(name) and name.isidentifier()


def schema_safety_check(
    reflector_output: Dict[str, Any],
    ontology: Ontology,
    probe_report: Dict[str, Any],
    max_value_cardinality: int = 8,
) -> Dict[str, Any]:
    existing_names = set(ontology.dimension_names())
    probe_ids = {p.get("probe_id") for p in (probe_report.get("probe_stats") or [])}

    proposals_report: Dict[int, Dict[str, Any]] = {}
    for idx, prop in enumerate(reflector_output.get("new_proposals") or []):
        reasons = []
        action = prop.get("action")
        if action == "no_change":
            proposals_report[idx] = {"accepted": True, "reasons": []}
            continue
        if action == "promote_probe_to_dimension":
            name = prop.get("dimension_name", "")
            values = prop.get("values") or []
            if not _is_identifier(name):
                reasons.append(f"dimension_name '{name}' is not a valid identifier")
            if name in existing_names:
                reasons.append(f"dimension name '{name}' must be unique (already exists)")
            if not (1 <= len(values) <= max_value_cardinality):
                reasons.append(
                    f"values cardinality {len(values)} out of [1,{max_value_cardinality}]")
            if prop.get("probe_id") not in probe_ids:
                reasons.append(f"source probe '{prop.get('probe_id')}' not in probe_report")
        elif action == "add_value":
            name = prop.get("dimension_name", "")
            new_vals = prop.get("values") or []
            dim = ontology.get(name)
            if dim is None:
                reasons.append(f"add_value target '{name}' does not exist")
            else:
                total = len(set(dim.values) | set(new_vals))
                if total > max_value_cardinality:
                    reasons.append(
                        f"add_value would push '{name}' to cardinality {total} "
                        f"> {max_value_cardinality}")
                if not new_vals:
                    reasons.append("add_value has no new values")
        else:
            reasons.append(f"unknown proposal action '{action}'")
        proposals_report[idx] = {"accepted": not reasons, "reasons": reasons}

    reviews_report: Dict[str, Dict[str, Any]] = {}
    for rev in reflector_output.get("dimension_reviews") or []:
        name = rev.get("dimension", "")
        decision = rev.get("decision")
        reasons = []
        dim = ontology.get(name)
        if dim is None:
            reasons.append(f"review target '{name}' does not exist")
        elif decision == "deprecate":
            if dim.status in ("seed", "promoted"):
                reasons.append(f"cannot deprecate {dim.status} dimension '{name}' (v1 rule)")
        elif decision not in ("promote", "keep_experimental", "deprecate"):
            reasons.append(f"unknown review decision '{decision}'")
        if decision in ("promote", "deprecate", "keep_experimental") and dim is not None and dim.status != "experimental":
            reasons.append(f"can only {decision} an experimental dimension; "
                           f"'{name}' is {dim.status}")
        reviews_report[name] = {"accepted": not reasons, "reasons": reasons}

    return {"proposals": proposals_report, "reviews": reviews_report}
