"""Real-entity sampler: pulls concrete ids from the live tau2 DB for v0.

The Task Synthesis Agent must bind its task to REAL entities (it may not invent
ids). This sampler reads the stock DB via the adapter's live env and returns a
compact, obtainable-only view of a handful of records (no white-box scoring
internals -- just the same fields a real operator would see through the tools).

It is domain-aware where it matters: for airline the meaningful unit is an
ACTIVE reservation joined with its owning user + payment methods (the shape the
four determinism-safe writes operate on). A generic fallback samples a few rows
from each table for any other domain.

Sampling is deterministic given a seed so a run is reproducible; rotation across
the id space gives diversity when many tasks are synthesized from one plan.
"""

from __future__ import annotations

import hashlib
import random
from typing import Any, Dict, List


def _seed_int(seed: str) -> int:
    return int(hashlib.sha256(seed.encode()).hexdigest(), 16)


def _rotate(ids: List[str], seed: str, k: int) -> List[str]:
    """Deterministically pick up to ``k`` ids, rotated by ``seed``."""
    if not ids:
        return []
    start = _seed_int(seed) % len(ids)
    return [ids[(start + i) % len(ids)] for i in range(min(k, len(ids)))]


def _sample_spread(ids: List[str], seed: str, k: int) -> List[str]:
    """Deterministically pick up to ``k`` ids spread RANDOMLY across the whole id
    space (not a contiguous slice). Reproducible for a given ``seed``."""
    if not ids:
        return []
    rng = random.Random(_seed_int(seed))
    return rng.sample(ids, min(k, len(ids)))


def _table_id_field(records: List[Dict[str, Any]]) -> str:
    """First key ending in ``_id`` (but not ``_ids``) on the first record --
    e.g. ``customer_id`` for the telecom customers table. This is the primary
    key the read tools look records up by."""
    if not records or not isinstance(records[0], dict):
        return ""
    for k in records[0]:
        if k.endswith("_id") and not k.endswith("_ids"):
            return k
    return ""


def _table_ids(table: Any) -> List[str]:
    """Return the id strings of a DB table regardless of shape.

    airline/retail store each table as a dict-of-records keyed by id, so the ids
    are ``table.keys()``. telecom stores each table as a LIST of records, so the
    id lives on a per-record ``*_id`` field. Handling both keeps the shared
    sampler domain-agnostic (telecom's list shape used to silently yield []).
    """
    if isinstance(table, dict):
        return sorted(str(k) for k in table)
    if isinstance(table, list):
        idf = _table_id_field(table)
        if not idf:
            return []
        return sorted(
            str(r[idf]) for r in table if isinstance(r, dict) and r.get(idf) is not None
        )
    return []


def _airline_reservation_view(
    db: Dict[str, Any], rid: str
) -> Dict[str, Any]:
    """Obtainable view of one reservation joined with its user + payments."""
    reservations = db.get("reservations") or {}
    users = db.get("users") or {}
    res = reservations.get(rid) or {}
    user = users.get(res.get("user_id")) or {}
    name = user.get("name") or {}
    pms = user.get("payment_methods") or {}
    return {
        "reservation_id": rid,
        "status": res.get("status") or "active",
        "user_id": res.get("user_id"),
        "user_name": f"{name.get('first_name', '')} {name.get('last_name', '')}".strip(),
        "membership": user.get("membership"),
        "cabin": res.get("cabin"),
        "flight_type": res.get("flight_type"),
        "origin": res.get("origin"),
        "destination": res.get("destination"),
        "flights": [
            {
                "flight_number": f.get("flight_number"),
                "date": f.get("date"),
                "origin": f.get("origin"),
                "destination": f.get("destination"),
                "price": f.get("price"),
                "cabin": f.get("cabin"),
            }
            for f in (res.get("flights") or [])
        ],
        "passengers": res.get("passengers") or [],
        "total_baggages": res.get("total_baggages"),
        "nonfree_baggages": res.get("nonfree_baggages"),
        "insurance": res.get("insurance"),
        "payment_methods": [
            {
                "id": pid,
                "source": spec.get("source"),
                **({"amount": spec.get("amount")} if "amount" in spec else {}),
            }
            for pid, spec in pms.items()
        ],
    }


def _sample_airline(db: Dict[str, Any], seed: str, n: int) -> List[Dict[str, Any]]:
    """Sample ACTIVE (status is null) stock reservations, joined with user."""
    reservations = db.get("reservations") or {}
    active = [
        rid for rid in sorted(reservations) if reservations[rid].get("status") is None
    ]
    chosen = _rotate(active, seed, n)
    return [_airline_reservation_view(db, rid) for rid in chosen]


def _sample_generic(db: Dict[str, Any], seed: str, n: int) -> List[Dict[str, Any]]:
    """Fallback: a few raw rows from each table, id included. Handles both the
    dict-of-records shape (airline/retail) and the list-of-records shape
    (telecom, whose rows carry a ``*_id`` field)."""
    out: List[Dict[str, Any]] = []
    for tname in sorted(db):
        table = db[tname]
        if isinstance(table, dict):
            rows_by_id = {str(k): v for k, v in table.items()}
        elif isinstance(table, list):
            idf = _table_id_field(table)
            if not idf:
                continue
            rows_by_id = {
                str(r[idf]): r
                for r in table
                if isinstance(r, dict) and r.get(idf) is not None
            }
        else:
            continue
        ids = _rotate(sorted(rows_by_id), f"{seed}:{tname}", n)
        for _id in ids:
            row = rows_by_id.get(_id)
            if isinstance(row, dict):
                out.append({"_table": tname, "_id": _id, **row})
    return out


def sample_entities(
    adapter,
    domain: str,
    seed: str,
    n: int = 4,
) -> List[Dict[str, Any]]:
    """Return a compact list of REAL entity records the synthesis agent may bind.

    ``adapter`` is any tau2 adapter (provides ``make_environment``). ``seed``
    makes the sample deterministic + rotatable (use e.g. the plan_id + index).
    """
    db = dict(adapter.make_environment().tools.db.model_dump())
    if domain == "airline":
        return _sample_airline(db, seed, n)
    return _sample_generic(db, seed, n)


# ---- bare-id seeds for the free-exploration agent -------------------------
# The explore agent is meant to discover entities ITSELF via read tools, not be
# handed a curated joined view. But airline has no list_all_* tool, so an agent
# starting from nothing cannot reach even one user_id/reservation_id. We hand it
# the MINIMAL handle the env forces on us -- a few bare top-level ids -- and let
# it freely look them up and branch from there. No join, no plan-matching: it is
# deliberately plan-agnostic so the agent does the entity selection.

_SEED_TABLE: Dict[str, str] = {
    "airline": "users",
    "retail": "users",
    "telecom": "customers",
}


def seed_ids(adapter, domain: str, seed: str, n: int = 6) -> List[str]:
    """Return up to ``n`` bare top-level record ids (e.g. user_ids), sampled
    RANDOMLY (but deterministically per ``seed``) across the whole id space. The
    free-exploration agent starts from these and looks them up. A spread sample
    (rather than a contiguous slice) gives each exploration a more diverse set of
    entry points into the 500-user space."""
    db = dict(adapter.make_environment().tools.db.model_dump())
    table = db.get(_SEED_TABLE.get(domain, "users"))
    # airline/retail: dict-of-records keyed by id. telecom: list of records with
    # a per-record ``*_id`` field. ``_table_ids`` normalizes both.
    return _sample_spread(_table_ids(table), seed, n)
