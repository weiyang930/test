"""Single-round synthesis orchestrator: ``run_synthesis``.

Flow per run:

    DimensionPlanner.plan()             -> List[TaskBlueprint]
    for each blueprint (concurrently):
        TaskSynthesisAgent.synthesize() -> TaskCandidate (real entities)
        [interactive] TrajectoryAgent.explore() -> ground-truth PROPOSAL
        TaskVerifier.verify()           -> static hard checks
        ReplayVerifier.verify()         -> deterministic replay + repair (the GATE)
    DimensionFilter (serial, stateful)  -> dimension-cell coverage / dedup
    exporters                           -> RL / SFT / data-agent / debug

The judging core is deterministic replay (NO LLM judge): a fulfill task is
accepted iff its ground truth replays without tool errors; a refuse task is
accepted iff its (read-only) ground truth leaves the DB unchanged. The LLM
repair agent only PROPOSES; replay decides accept/reject.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..dimensions.loader import load_dimensions
from ..domains import get_adapter
from .ontology.ontology_store import load_ontology, to_domain_dimensions
from ..exporters import (
    DataAgentSFTExporter,
    DebugBundleExporter,
    RLTaskExporter,
    SFTTrajectoryExporter,
)
from ..llm import BedrockLLMClient, QwenLocalClient
from ..llm.base import BaseLLMClient
from .mock_client import PipelineMock
from ..logging_utils.artifact_logger import ArtifactLogger
from ..schemas import GTAction, TaskCandidate
from ..schemas.blueprint_schema import TaskBlueprint
from ..schemas.report_schema import (
    AcceptedSample,
    RejectedSample,
    TaskVerificationReport,
    TrajectoryVerificationReport,
)
from ..feedback import FeedbackSample, feedback_sample_from_candidate
from ..synthesis.runner import get_runner
from ..verifiers import TaskVerifier
from .condition_source import (
    FileConditionSource,
    FreeConditionSource,
    MacroPlanner,
    RoundRobinConditionSource,
)
from .dimension_filter import DimensionFilter
from .explore_synthesis_agent import ExploreSynthesisAgent
from .factual_context import build_synthesis_context
from .planner_agent import DimensionPlanner
from .task_synthesis_agent import TaskSynthesisAgent
from .trajectory_agent import TrajectoryAgent
from .replay_verifier import ReplayVerifier

# default dimension schema (swappable via cfg.dimensions_path)
import os
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
_DEFAULT_DIMS = os.path.join(_HERE, "..", "dimensions", "areal_sea.yaml")


def _load_macro_feedback(path: Optional[str]) -> Optional[Dict[str, Any]]:
    """Load a previous round's macro feedback for the closed-loop macro planner.

    Accepts either a full macro_feedback.json (with a top-level
    ``recommended_macro_signals``) or a bare signals dict. Returns the
    recommended_macro_signals dict (what MacroPlanner/build_macro_prompt expect),
    or None if no path / unreadable (-> cold start)."""
    if not path:
        return None
    import json
    with open(path) as fh:
        obj = json.load(fh)
    sig = obj.get("recommended_macro_signals", obj) if isinstance(obj, dict) else None
    return sig if isinstance(sig, dict) else None


@dataclass
class SynthesisConfig:
    domain: str = "airline"
    dimensions_path: Optional[str] = None     # defaults to areal_sea.yaml
    ontology_path: Optional[str] = None   # if set, active dims come from this ontology
    # planning
    num_blueprints: int = 20
    # macro layer: how the planner's per-blueprint conditions are chosen.
    #   "roundrobin" -> deterministic round-robin over pinned axes (default);
    #   "free"       -> no direction, every plan fully free (legacy behavior);
    #   "macro"      -> LLM macro planner (three-state conditions + budget
    #                   allocator). feedback is a placeholder this round.
    #   "file"       -> replay a fixed JSONL of conditions (conditions_file);
    #                   bypasses the macro LLM. For oracle/hand-authored arms.
    condition_source: str = "roundrobin"
    condition_pin_keys: Optional[List[str]] = None  # default: family x outcome
    # path to a JSONL of MacroConditions, consumed only when condition_source=="file".
    conditions_file: Optional[str] = None
    # micro planner is now PARALLEL + STATELESS (no coverage history). Conditions
    # are processed in batches of this size; concurrency is capped by max_workers.
    plan_batch_size: int = 40
    # per-plan wall-clock bound (seconds): on a worker thread the bedrock fork
    # watchdog does NOT fire, so this bounds a wedged call from stalling the batch.
    plan_task_timeout: float = 180.0
    # per-blueprint wall-clock bound (seconds) for the SYNTHESIS/EXPLORE stage.
    # explore drives a multi-turn live-env loop, so a single high-end (multi-book)
    # task can legitimately take minutes; but on the worker-thread bedrock path a
    # wedged SSL recv never returns and would pin a worker forever (observed: a
    # 5+ book task hung >20min with 0 cpu). Bounding it lets the batch drop that
    # one blueprint (-> None outcome) instead of stalling. Generous by default so
    # only truly-hung calls are cut. None = no bound (old behavior).
    synth_task_timeout: Optional[float] = 600.0
    # reuse a previously-saved blueprints.jsonl and SKIP the planner entirely --
    # decouples generation from planning so concurrency can be re-tuned without
    # paying the planner cost again.
    blueprints_from: Optional[str] = None
    # how many task candidates to synthesize PER plan (each replica re-explores
    # independently: temperature=1.0 + spread seed -> different real entities).
    # planner is serial/stateful (the scaling bottleneck), so few-plans x many-
    # tasks-per-plan is far cheaper than many-plans x one-task.
    tasks_per_plan: int = 1
    seed: int = 0
    planner_max_tokens: int = 2000
    planner_max_attempts: int = 3
    # synthesis
    # 16000 (aligned with the synthesis pipeline): thinking is ON and eats thinking_budget
    # (2048) out of this cap, so 6000 left only ~3952 tokens for OUTPUT -- enough
    # for a 0/1-write task but NOT for a multi-write (2/3-4/5+) task whose GT JSON
    # runs 12000+ chars (~5k tokens). The long outputs were silently TRUNCATED ->
    # unparseable -> dropped at synthesis. This (not generator ability: a 3-4
    # blueprint probed directly with a full token budget yields 3 writes 4/4) is
    # why num_write high-end never reached accepted. v3 used 16000 and could.
    synth_max_tokens: int = 16000
    entity_sample_size: int = 4
    # synthesis path:
    #   "summarizer"  -> sampler feeds a curated entity view; synth agent drafts gt
    #   "interactive" -> summarizer synth, then agent re-explores to refine gt
    #   "explore"     -> agent freely explores from bare seed ids, discovers its
    #                    own entities, and submits the whole task (no sampler view)
    # DEFAULT = "explore": the agent is dropped into a LIVE env and reads the
    # authoritative prices / real flight numbers before proposing GT, so
    # book_reservation payment splits actually balance. The old "summarizer"
    # default made the agent GUESS prices statically -> every book-containing
    # multiwrite task failed replay (0/32 in round2 prod260), collapsing the
    # book-class multiwrite that v3 relied on. See docs.
    trajectory_mode: str = "explore"
    solver_max_turns: int = 12
    explore_max_turns: int = 30
    explore_seed_count: int = 8
    explore_max_attempts: int = 3
    # save the FULL explore conversation (system/assistant/user + per-turn tool
    # log) to candidates/<id>/explore_trajectory.json. Off by default (the trace
    # is heavy); turn on only when you explicitly want the generation trajectory.
    save_explore_trajectory: bool = False
    # round2/round3 feature flags. Both default OFF: the H4 audit (2026-06-19)
    # showed base-50 eval is 100% DB+COMMUNICATE single-write, while these two
    # features produced ACTION-basis / multi-family tasks that never appear in
    # the eval set. Code is kept (flip a flag to re-enable) but disabled by
    # default so synthesis is the validated v0 single-intent DB path.
    #   (multi-intent / action-basis / fail-set axes were all removed from
    #    pipeline -- it is single-intent, DB-hash judged, basics-only.)
    # verification / repair (deterministic gate)
    allow_repair: bool = True
    max_repair_attempts: int = 2
    # filtering
    max_per_cell: int = 200
    min_actions: int = 1
    # 12 (aligned with the synthesis pipeline): a genuine 3-4/5+ write chain needs
    # reads+calculate+writes ~= 9 steps; the old cap of 6 silently rejected every
    # multi-write candidate (reward==1, task-verified) at the filter stage, which
    # is why num_write high-end (3-4/5+) never reached accepted.
    max_actions: int = 12
    enable_near_duplicate: bool = True
    # llm
    llm_backend: str = "mock"                 # "mock" | "bedrock" | "qwen"
    model: Optional[str] = None
    enable_thinking: bool = True
    # For llm_backend == "qwen": the local vLLM OpenAI endpoint the synthesis
    # generator/planner talks to. None -> QwenLocalClient default (port 8010).
    qwen_api_base: Optional[str] = None
    # concurrency
    runner_backend: str = "thread"
    max_workers: int = 8
    # logging
    runs_base_dir: str = "runs"
    run_tag: str = "synthesis_run"
    # feedback: identifies this synthesis round in feedback_samples.jsonl. Empty ->
    # the pipeline falls back to run_tag at runtime. One run = one round.
    round_id: str = ""
    # Path to a previous round's macro_feedback.json (from build_round_feedback.py).
    # When set AND condition_source == "macro", its recommended_macro_signals are
    # fed to the MacroPlanner so the loop is closed (feedback drives the next mix).
    # None -> cold start (the macro prompt seeds a balanced exploratory prior).
    feedback_from: Optional[str] = None
    # In-memory macro feedback signals (recommended_macro_signals 5-bucket dict),
    # e.g. produced by feedback_to_macro_signals.feedback_report_to_macro_signals
    # from a previous round's feedback_report. Takes precedence over feedback_from
    # (skips the temp-file round-trip). None -> fall back to feedback_from / cold start.
    macro_feedback_signals: Optional[Dict[str, Any]] = None
    # Cold-start prior strength for the MACRO planner (no-feedback rounds only).
    # "strong" = balanced full-coverage seed (round-1 baseline, scored 64.4%).
    # "weak"   = under-curated natural-skew seed; lowers the round-1 ceiling and
    #            leaves coverage gaps for the feedback loop to close (~60% or below).
    # Ignored once feedback_from drives the mix.
    macro_prior_strength: str = "strong"
    # Axes the ontology reflector promoted in the PREVIOUS round, as
    # [{"name","values","why"}]. When condition_source=="macro", these are handed
    # to the MacroPlanner so it deliberately tilts budget toward the new axes'
    # under-covered values (so a just-promoted axis actually gets sampled). Empty
    # on a plain round (no new axis).
    newly_added_axes: Optional[List[Dict[str, Any]]] = None


@dataclass
class _Outcome:
    candidate: Optional[TaskCandidate]
    task_report: Optional[TaskVerificationReport]
    traj_report: Optional[TrajectoryVerificationReport]
    error: Optional[str] = None
    blueprint_id: str = ""
    candidate_index: int = 0


@dataclass
class SynthesisResult:
    run_dir: str
    num_blueprints: int
    num_synthesized: int
    num_task_verified: int
    num_trajectory_verified: int
    num_accepted: int
    num_rejected: int
    coverage_counts: Dict[str, int] = field(default_factory=dict)
    rejection_by_stage: Dict[str, int] = field(default_factory=dict)


def _build_llm(cfg: SynthesisConfig) -> BaseLLMClient:
    if cfg.llm_backend == "mock":
        return PipelineMock()
    if cfg.llm_backend == "bedrock":
        kwargs: Dict[str, Any] = {"enable_thinking": cfg.enable_thinking}
        if cfg.model:
            kwargs["model"] = cfg.model
        return BedrockLLMClient(**kwargs)
    if cfg.llm_backend == "qwen":
        # SYNTHESIS-stage generator on a local vLLM-served open model. The user
        # simulator + GT agent at ROLLOUT/eval stay Opus (unchanged); only the
        # data-synthesis LLM swaps here.
        kwargs = {"enable_thinking": cfg.enable_thinking}
        if cfg.model:
            kwargs["model"] = cfg.model
        if cfg.qwen_api_base:
            kwargs["api_base"] = cfg.qwen_api_base
        return QwenLocalClient(**kwargs)
    raise ValueError(f"Unknown llm_backend: {cfg.llm_backend!r}")


def dims_from_config(cfg: "SynthesisConfig"):
    """Resolve the planner DomainDimensions. If cfg.ontology_path is set, ACTIVE
    ontology dims drive the planner (selection_rules + difficulty_profile still
    come from the base dimension yaml); else fall back to the static yaml."""
    base_spec = load_dimensions(cfg.dimensions_path or _DEFAULT_DIMS)
    base = base_spec.for_domain(cfg.domain)
    if not cfg.ontology_path:
        return base
    ontology = load_ontology(cfg.ontology_path)
    return to_domain_dimensions(
        ontology, cfg.domain,
        selection_rules=base.selection_rules,
        difficulty_profile=base.difficulty_profile,
    )


def run_synthesis(
    cfg: SynthesisConfig,
    adapter=None,
    llm: Optional[BaseLLMClient] = None,
) -> SynthesisResult:
    adapter = adapter or get_adapter(cfg.domain)
    llm = llm or _build_llm(cfg)

    # v5 HARD INVARIANT: basics-only, single-intent, DB-hash judged. The
    # multi-intent / action-basis / fail-set machinery was removed from
    # pipeline entirely -- there are no feature flags left to force off.

    run_dir = ArtifactLogger.create_run_dir(cfg.runs_base_dir, cfg.run_tag)
    logger = ArtifactLogger(run_dir)
    logger.save_config_snapshot("synthesis_config.json", cfg.__dict__)

    # obtainable-only domain surface (shared by all v0 agents)
    context = build_synthesis_context(adapter)
    dims = dims_from_config(cfg)

    planner = DimensionPlanner(
        domain=cfg.domain, dims=dims, context=context, llm=llm,
        max_tokens=cfg.planner_max_tokens, max_attempts=cfg.planner_max_attempts,
    )
    synth = TaskSynthesisAgent(
        adapter, context, llm,
        max_tokens=cfg.synth_max_tokens, entity_sample_size=cfg.entity_sample_size,
    )
    explorer = (
        ExploreSynthesisAgent(
            adapter, context, llm,
            max_turns=cfg.explore_max_turns, max_tokens=cfg.synth_max_tokens,
            seed_count=cfg.explore_seed_count,
            max_attempts=cfg.explore_max_attempts,
            capture_trace=cfg.save_explore_trajectory,
        )
        if cfg.trajectory_mode == "explore" else None
    )
    traj_agent = (
        TrajectoryAgent(adapter, llm, max_turns=cfg.solver_max_turns)
        if cfg.trajectory_mode == "interactive" else None
    )
    task_verifier = TaskVerifier(adapter)
    traj_verifier = ReplayVerifier(
        adapter, llm=llm if cfg.allow_repair else None,
        max_repair_attempts=cfg.max_repair_attempts,
    )
    # Reflector-added axes = active dims beyond the 6 seed axes. Each must have its
    # declared bucket REALIZED by the generator (declared-vs-realized gate) and is
    # backfilled into the feedback sample so the loop can see it next round.
    _SEED6 = {"task_family", "expected_outcome", "policy_or_constraint_focus",
              "tool_use_pattern", "interaction_challenge", "difficulty_profile"}
    # Telecom's O_0 re-cuts three of the seed axes to troubleshooting-native names
    # (fault_profile/resolution_locus/diagnostic_challenge replace focus/pattern/
    # challenge). They are SEED axes, not reflector-added, so exempt them from the
    # count/computation realization gate (which only knows the airline/retail
    # count axes). Airline/retail dims never contain these names -> unchanged.
    _TELECOM_SEED_AXES = {"fault_profile", "resolution_locus", "diagnostic_challenge"}
    # Car (the non-tau2 bridged domain) declares 7 CAR-NATIVE seed axes -- none of
    # them are count/computation axes, so the realization gate is already a no-op
    # for them (conformance skips any axis not in _COUNT_AXIS_PROBE), but they
    # are SEED axes, not reflector-added, so exempt them to keep the log honest.
    _CAR_SEED_AXES = {"task_nature", "expected_behavior", "state_precondition",
                      "interaction_challenge"}
    extra_axes = [k for k in dims.shared_keys
                  if k not in _SEED6 and k not in _TELECOM_SEED_AXES
                  and k not in _CAR_SEED_AXES]
    if extra_axes:
        print(f"[pipeline] reflector-added axes (realization-gated): {extra_axes}")

    cid_decisions: Dict[str, Dict[str, Any]] = {}
    if cfg.blueprints_from:
        # Reuse path: load saved blueprints and skip the serial planner entirely.
        import json
        blueprints = []
        with open(cfg.blueprints_from) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    blueprints.append(TaskBlueprint(**json.loads(line)))
        print(
            f"[synthesis] reused {len(blueprints)} blueprints from "
            f"{cfg.blueprints_from} (planner skipped)"
        )
    else:
        # Macro layer picks one condition per requested blueprint; the micro
        # planner then samples each in parallel (stateless given its condition).
        if cfg.condition_source == "free":
            csource = FreeConditionSource()
        elif cfg.condition_source == "roundrobin":
            csource = RoundRobinConditionSource(dims, pin_keys=cfg.condition_pin_keys)
        elif cfg.condition_source == "file":
            if not cfg.conditions_file:
                raise ValueError("condition_source=file requires conditions_file")
            csource = FileConditionSource(cfg.conditions_file)
            print(f"[synthesis] file conditions loaded from {cfg.conditions_file} "
                  f"({len(csource.last_valid_conditions)} conditions) -> oracle/replay arm")
        elif cfg.condition_source == "macro":
            # In-memory signals (from the feedback_report->signals bridge) win over
            # the file path; either one closes the loop and suppresses cold start.
            macro_feedback = cfg.macro_feedback_signals or _load_macro_feedback(cfg.feedback_from)
            if macro_feedback:
                n_sig = sum(len(v) for v in macro_feedback.values())
                src = "in-memory signals" if cfg.macro_feedback_signals else cfg.feedback_from
                print(f"[synthesis] macro feedback loaded from {src} "
                      f"({n_sig} signal keys) -> closed-loop macro")
            # An always-thinking Qwen backbone (Qwen3-*-Thinking-2507) reasons
            # without bound on the open-ended macro prompt and never emits the
            # conditions JSON -> [None]*n -> micro self-collapse. For that case
            # ONLY, run the macro call deterministically (temp=0 + think-off),
            # which converges to a clean balanced spread (empirically verified
            # 2026-07-14). base/Opus and non-thinking qwen keep the old path.
            macro_deterministic = (
                cfg.llm_backend == "qwen" and cfg.enable_thinking
                and "thinking" in (cfg.model or "").lower())
            if macro_deterministic:
                print("[synthesis] macro: always-thinking backbone detected -> "
                      "deterministic_json (temp0 + enable_thinking=False) to avoid "
                      "unbounded-think JSON collapse")
            csource = MacroPlanner(
                dims=dims, context=context, llm=llm, feedback=macro_feedback,
                prior_strength=cfg.macro_prior_strength,
                newly_added_axes=cfg.newly_added_axes,
                deterministic_json=macro_deterministic)
        else:
            raise ValueError(f"Unknown condition_source: {cfg.condition_source!r}")
        conditions = csource.next_conditions(cfg.num_blueprints)
        if isinstance(csource, (MacroPlanner, FileConditionSource)):
            cid_decisions = csource.cid_to_dict()
        blueprints = planner.plan(
            conditions,
            runner_backend=cfg.runner_backend,
            max_workers=cfg.max_workers,
            batch_size=cfg.plan_batch_size,
            task_timeout=cfg.plan_task_timeout,
        )
    if cid_decisions:
        for cid, cond in cid_decisions.items():
            logger.append_jsonl("reports/macro_decisions.jsonl", {"condition_id": cid, **cond})
    for bp in blueprints:
        logger.append_jsonl("reports/blueprints.jsonl", bp)

    runner = get_runner(cfg.runner_backend, cfg.max_workers)

    def _process(item) -> _Outcome:
        idx, bp = item
        agent = explorer if explorer is not None else synth
        _t0 = time.monotonic()
        try:
            cand = agent.synthesize(bp, idx)
        except Exception as e:
            print(f"[explore-timing] bp={bp.blueprint_id} diff={bp.difficulty_level} "
                  f"nfault={bp.num_faults} elapsed={time.monotonic()-_t0:.1f}s "
                  f"result=synthesis_error", flush=True)
            return _Outcome(None, None, None, error=f"synthesis_error: {e}",
                            blueprint_id=bp.blueprint_id, candidate_index=idx)
        _elapsed = time.monotonic() - _t0
        print(f"[explore-timing] bp={bp.blueprint_id} diff={bp.difficulty_level} "
              f"nfault={bp.num_faults} elapsed={_elapsed:.1f}s "
              f"result={'None' if cand is None else 'candidate'}", flush=True)
        if cand is None:
            return _Outcome(None, None, None, error="synthesis_unparseable",
                            blueprint_id=bp.blueprint_id, candidate_index=idx)

        logger.save_json(cand.candidate_id, "blueprint.json", bp)

        # Full generation trajectory (explore mode only, opt-in): the agent's
        # multi-turn env exploration that PRODUCED this task. Saved separately so
        # synthesis_output_parsed.json stays lean. Pop it off extra FIRST so the
        # heavy conversation isn't duplicated inside the candidate dump below.
        if cfg.save_explore_trajectory:
            explore_trace = cand.generation_metadata.extra.pop("explore_trace", None)
            if explore_trace is not None:
                logger.save_json(
                    cand.candidate_id, "explore_trajectory.json", explore_trace
                )

        logger.save_json(cand.candidate_id, "synthesis_output_parsed.json", cand)

        # optional agentic exploration -> gt PROPOSAL (replay still arbitrates)
        if traj_agent is not None:
            entities = cand.generation_metadata.extra.get("entity_sample") or []
            res = traj_agent.explore(cand.task, context.tools, entities)
            logger.save_json(cand.candidate_id, "trajectory_agent.json",
                             {"terminated": res.terminated_reason,
                              "n_turns": res.n_turns, "gt": res.final_gt_actions})
            if res.final_gt_actions:
                cand.gt_actions = [
                    GTAction(actor=a["actor"], name=a["name"],
                             arguments=a["arguments"])
                    for a in res.final_gt_actions
                ]
                synth._install_evaluation_criteria(cand.task, cand.gt_actions)
                cand.generation_metadata.extra["gt_source"] = "agent_explored"

        task_report = task_verifier.verify(cand)
        logger.save_json(cand.candidate_id, "task_verifier_report.json", task_report)
        if not task_report.passed:
            return _Outcome(cand, task_report, None,
                            blueprint_id=bp.blueprint_id, candidate_index=idx)

        traj_report = traj_verifier.verify(cand, allow_repair=cfg.allow_repair)
        logger.save_json(cand.candidate_id, "trajectory_verifier_report.json",
                         traj_report)
        return _Outcome(cand, task_report, traj_report,
                        blueprint_id=bp.blueprint_id, candidate_index=idx)

    # Fan each plan out into ``tasks_per_plan`` replicas. The global index is
    # unique per (plan, replica) so candidate ids/dirs never collide and each
    # replica's explore seed (blueprint_id:index:attempt) differs -> distinct
    # real entities. Planning ran once per plan (serial); only this generation
    # step is fanned out and concurrent.
    work = [
        (gi, bp)
        for gi, bp in enumerate(
            bp for bp in blueprints for _ in range(max(1, cfg.tasks_per_plan))
        )
    ]
    outcomes: List[_Outcome] = runner.map(
        _process, work, task_timeout=cfg.synth_task_timeout
    )

    # ---- filter + export (serial, stateful) ----
    dfilter = DimensionFilter(
        adapter, max_per_cell=cfg.max_per_cell, min_actions=cfg.min_actions,
        max_actions=cfg.max_actions, enable_near_duplicate=cfg.enable_near_duplicate,
    )
    rl_exp = RLTaskExporter(logger)
    sft_exp = SFTTrajectoryExporter(logger)
    da_exp = DataAgentSFTExporter(logger)
    debug_exp = DebugBundleExporter(logger)

    num_synth = num_task = num_traj = num_accepted = 0
    rej: Counter = Counter()

    for oc in outcomes:
        # A None slot = the runner hit synth_task_timeout on a wedged explore
        # call and dropped that blueprint to keep the batch moving. Count it as a
        # synthesis rejection (no candidate, no ids available).
        if oc is None:
            rej["synthesis_timeout"] += 1
            logger.append_jsonl("rejected/rejected_tasks.jsonl", RejectedSample(
                candidate_id="bp_unknown_timeout",
                stage="synthesis", reasons=["synth_task_timeout"]))
            continue
        if oc.candidate is None:
            rej["synthesis"] += 1
            logger.append_jsonl("rejected/rejected_tasks.jsonl", RejectedSample(
                candidate_id=f"bp_{oc.blueprint_id}_{oc.candidate_index}",
                stage="synthesis", reasons=[oc.error or "unknown"]))
            continue
        num_synth += 1
        cand = oc.candidate
        cell = cand.blueprint.dimension_cell()

        if oc.task_report is None or not oc.task_report.passed:
            rej["task_verify"] += 1
            reasons = oc.task_report.failure_reasons if oc.task_report else ["no task report"]
            logger.append_jsonl("rejected/rejected_tasks.jsonl", RejectedSample(
                candidate_id=cand.candidate_id, task_id=cand.task_id,
                stage="task_verify", reasons=reasons, coverage_cell=cell))
            debug_exp.export(cand, oc.task_report or TaskVerificationReport(),
                             oc.traj_report or TrajectoryVerificationReport(), kept=False)
            continue
        num_task += 1

        if oc.traj_report is None or not oc.traj_report.passed:
            rej["trajectory_verify"] += 1
            reasons = oc.traj_report.failure_reasons if oc.traj_report else ["no traj report"]
            logger.append_jsonl("rejected/rejected_tasks.jsonl", RejectedSample(
                candidate_id=cand.candidate_id, task_id=cand.task_id,
                stage="trajectory_verify", reasons=reasons, coverage_cell=cell))
            debug_exp.export(cand, oc.task_report,
                             oc.traj_report or TrajectoryVerificationReport(), kept=False)
            continue
        num_traj += 1

        freport = dfilter.filter(cand)
        logger.save_json(cand.candidate_id, "filter_report.json", freport)
        if not freport.kept:
            rej["filter"] += 1
            logger.append_jsonl("rejected/rejected_tasks.jsonl", RejectedSample(
                candidate_id=cand.candidate_id, task_id=cand.task_id,
                stage="filter", reasons=freport.rejection_reasons, coverage_cell=cell))
            debug_exp.export(cand, oc.task_report, oc.traj_report, kept=False)
            continue

        # Realization gate for reflector-added count axes: reject a sample whose GT
        # does NOT realize the declared bucket (declared 3+ but GT has 1 -> reject),
        # so the new axis's coverage cells are not inflated with trivial tasks.
        if extra_axes:
            from .conformance import (check_count_axis_conformance,
                                         check_semantic_axis_conformance)
            ok, conf_reasons = check_count_axis_conformance(cand, extra_axes)
            if ok:
                # Semantic-axis realization (e.g. computation aggregate/threshold
                # must actually compute) -- rejects declared-vs-realized shells.
                ok, conf_reasons = check_semantic_axis_conformance(cand, extra_axes)
            if not ok:
                rej["axis_conformance"] = rej.get("axis_conformance", 0) + 1
                logger.append_jsonl("rejected/rejected_tasks.jsonl", RejectedSample(
                    candidate_id=cand.candidate_id, task_id=cand.task_id,
                    stage="axis_conformance", reasons=conf_reasons, coverage_cell=cell))
                debug_exp.export(cand, oc.task_report, oc.traj_report, kept=False)
                continue

        num_accepted += 1
        rl_exp.export(cand, oc.traj_report)
        sft_exp.export(cand, oc.traj_report)
        da_exp.export(cand, oc.traj_report)
        debug_exp.export(cand, oc.task_report, oc.traj_report, kept=True)
        logger.append_jsonl("accepted/accepted_index.jsonl", AcceptedSample(
            candidate_id=cand.candidate_id, task_id=cand.task_id,
            domain=cand.blueprint.domain, task_family=cand.blueprint.task_family,
            target_skill_pattern=cand.blueprint.target_skill_pattern,
            difficulty_level=cand.blueprint.difficulty_level,
            has_sft_trajectory=True, repaired=oc.traj_report.repaired))
        cid = (cand.blueprint.dimension_plan or {}).get("condition_id")
        intended = cid_decisions.get(cid) if cid else None
        fs = feedback_sample_from_candidate(
            cand, round_id=cfg.round_id or cfg.run_tag,
            intended_condition=intended,
        )
        # The shared FeedbackSample builder only knows the fixed ALL_KEYS, so a
        # reflector-added axis would be dropped. Backfill the REALIZED bucket of
        # each extra axis into micro_plan so next round's reflector/feedback sees it.
        if extra_axes:
            from .conformance import realized_axis_values
            fs.micro_plan.update(realized_axis_values(cand, extra_axes))
        logger.append_jsonl("reports/feedback_samples.jsonl", fs)

    result = SynthesisResult(
        run_dir=run_dir,
        num_blueprints=len(blueprints),
        num_synthesized=num_synth,
        num_task_verified=num_task,
        num_trajectory_verified=num_traj,
        num_accepted=num_accepted,
        num_rejected=sum(rej.values()),
        coverage_counts=dfilter.coverage_counts(),
        rejection_by_stage=dict(rej),
    )
    logger.save_report("run_summary.json", result.__dict__)
    logger.save_report("coverage_report.json", dfilter.coverage_counts())
    return result
