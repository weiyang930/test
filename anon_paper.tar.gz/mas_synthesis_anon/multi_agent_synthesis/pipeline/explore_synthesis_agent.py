"""ExploreSynthesisAgent: dimension_plan -> TaskCandidate by FREE exploration.

The alternative to ``TaskSynthesisAgent`` (the summarizer path). Instead of
being handed a curated, plan-agnostic entity view by ``entity_sampler`` and
drafting a task from it, this agent is dropped into a LIVE environment with only:
  * the dimension plan,
  * the obtainable tool catalog + db/policy surface,
  * a few BARE seed ids (airline has no list_all_* tool, so an agent starting
    from nothing cannot reach even one record -- the seeds are the minimal handle
    the env forces on us).

It then drives a multi-turn loop: it FREELY decides which read tools to call,
follows references to discover real entities that fit the plan, may trial-run a
write to confirm feasibility, and finally SUBMITS a finished task in the SAME
strict-JSON schema the summarizer agent emits. Parsing into a TaskCandidate is
delegated to ``TaskSynthesisAgent._to_candidate`` so the downstream replay
gate / verifier / exporters are byte-for-byte unchanged.

The submitted pseudo-GT is still a DRAFT; deterministic replay reward==1 remains
the sole arbiter. This agent scores nothing and never sees scoring internals. It
reuses the adapter's ``make_faulted_env`` / ``exec_action`` primitives verbatim.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..llm.base import BaseLLMClient, LLMResponse
from .prompts.explore import (
    PROMPT_VERSION,
    airline_determinism_note_db,
    build_explore_opening,
    build_explore_system,
)
from ..schemas import TaskBlueprint, TaskCandidate
from .entity_sampler import seed_ids
from .factual_context import SynthesisContext
from .task_synthesis_agent import TaskSynthesisAgent

_DETERMINISM_NOTES_DB: Dict[str, str] = {"airline": airline_determinism_note_db()}


@dataclass
class ExploreTrace:
    n_turns: int = 0
    terminated_reason: str = ""  # submit | max_turns | parse_error | empty_submit
    # How many times a submit was bounced because its authored fault script could
    # not be replayed into a fresh env (telecom authoring self-check; 0 elsewhere).
    n_replay_rejects: int = 0
    calls: List[Dict[str, Any]] = field(default_factory=list)
    # Full multi-turn conversation (system/assistant/user) of THIS exploration
    # episode. Captured verbatim (never truncated) so the saved trajectory is
    # training-grade; only populated/saved when the pipeline asks for it.
    messages: List[Dict[str, str]] = field(default_factory=list)


def _first_balanced_object(text: str) -> Optional[str]:
    """Return the substring of the FIRST top-level ``{...}`` by brace-depth scan
    (string/escape aware), or ``None`` if no balanced object is present.

    Why not ``text.find("{") .. text.rfind("}")``: the 30b-thinking teacher
    reliably appends a stray trailing ``}`` after an otherwise valid submit JSON
    (observed imbalance = +1 close brace on ~all of its finish=stop failures), so
    ``rfind`` grabs through the junk brace and ``json.loads`` dies with "Extra
    data". Stopping at the depth-0 close instead ignores anything trailing and
    recovers the real object. A genuinely truncated stream (finish=length) never
    reaches depth 0, so this correctly returns None there."""
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None


def _parse_obj(text: str) -> Optional[Dict[str, Any]]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        frag = _first_balanced_object(text)
        if frag is None:
            return None
        try:
            obj = json.loads(frag)
        except json.JSONDecodeError:
            return None
    return obj if isinstance(obj, dict) else None


class ExploreSynthesisAgent:
    """Free-exploration synthesis agent. Pure proposal generator (scores nothing)."""

    def __init__(
        self,
        adapter,
        context: SynthesisContext,
        llm: BaseLLMClient,
        max_turns: int = 16,
        max_tokens: int = 6000,
        seed_count: int = 6,
        policy_chars: int = 12000,
        obs_chars: int = 3000,
        max_attempts: int = 3,
        capture_trace: bool = False,
    ):
        self.adapter = adapter
        self.context = context
        self.llm = llm
        self.max_turns = max_turns
        self.max_tokens = max_tokens
        self.seed_count = seed_count
        self.policy_chars = policy_chars
        self.obs_chars = obs_chars
        self.max_attempts = max_attempts
        # When True, the full (untruncated) exploration conversation of the
        # WINNING attempt is attached to the candidate so the pipeline can save
        # it. Off by default -- we only persist the heavy trace on demand.
        self.capture_trace = capture_trace
        # Reused purely for its _to_candidate parser (same output schema, same
        # single-intent DB-hash collapse).
        self._parser = TaskSynthesisAgent(adapter, context, llm)

    def synthesize(
        self, blueprint: TaskBlueprint, candidate_index: int
    ) -> Optional[TaskCandidate]:
        """Explore the env and return one TaskCandidate, or None if no parseable
        task was submitted within ``max_turns``.

        Exploration is stochastic (temperature 1.0): a run may wander to
        max_turns instead of submitting. That is variance, not infeasibility, so
        we re-roll a FRESH exploration (different seed-id rotation) up to
        ``max_attempts`` times before giving up."""
        attempts: List[str] = []
        for attempt in range(self.max_attempts):
            parsed, trace, discovered = self._explore(
                blueprint, candidate_index, attempt
            )
            attempts.append(trace.terminated_reason)
            if parsed is not None:
                model = getattr(self.llm, "model", "explore")
                cand = self._parser._to_candidate(
                    blueprint, parsed, candidate_index, model, discovered
                )
                cand.generation_metadata.prompt_version = PROMPT_VERSION
                cand.generation_metadata.extra["gt_source"] = "explore"
                cand.generation_metadata.extra["explore_turns"] = trace.n_turns
                cand.generation_metadata.extra["explore_terminated"] = (
                    trace.terminated_reason
                )
                cand.generation_metadata.extra["explore_attempts"] = attempts
                cand.generation_metadata.extra["explore_replay_rejects"] = (
                    trace.n_replay_rejects
                )
                if self.capture_trace:
                    # Full conversation of the WINNING attempt + per-turn tool
                    # call log + discovered entities. Verbatim, never truncated.
                    cand.generation_metadata.extra["explore_trace"] = {
                        "attempt_index": attempt,
                        "attempts": attempts,
                        "n_turns": trace.n_turns,
                        "terminated_reason": trace.terminated_reason,
                        "calls": trace.calls,
                        "messages": trace.messages,
                        "discovered": discovered,
                    }
                return cand
        return None

    def _fault_catalog(self) -> Optional[Dict[str, Any]]:
        """Telecom-only: the per-family {fault -> fix -> proof} triple catalog +
        baseline_assertions (+ difficulty fault-count map) the authoring prompt
        draws from. None for airline/retail (they discover on the stock db and
        never inject faults), so their opening is unchanged.

        Sourced from the adapter's hand-curated domain config (``load_schema``),
        which is env-grounded domain truth -- NOT white-box scoring internals: the
        agent still authors the concrete task; this just constrains the func names
        to ones the env actually supports so every fault/assertion replays."""
        if self.context.domain != "telecom":
            return None
        load_schema = getattr(self.adapter, "load_schema", None)
        if load_schema is None:
            return None
        schema = load_schema() or {}
        families = schema.get("task_families") or {}
        if not families:
            return None
        return {
            "task_families": families,
            "difficulty_fault_counts": schema.get("difficulty_fault_counts") or {},
        }

    def _car_context_templates(self, blueprint: TaskBlueprint) -> Optional[List[Dict[str, Any]]]:
        """Car-only: a handful of REAL ``context_init_config`` dicts the authoring
        block copies + tweaks for STEP 1 (the initial vehicle state). None for
        every other domain, so their opening is byte-for-byte unchanged.

        Sourced from the adapter's ``sample_db_snippets`` (real base-task contexts,
        rotated by blueprint id) -- env-grounded truth, not scoring internals."""
        if self.context.domain != "car":
            return None
        snip = getattr(self.adapter, "sample_db_snippets", None)
        if snip is None:
            return None
        data = snip(blueprint) or {}
        configs = data.get("sample_context_init_configs") or []
        return configs[:4] or None

    def _replay_authored_faults(
        self, init_actions: List[Dict[str, Any]]
    ) -> Optional[str]:
        """Replay authored ``initialization_actions`` into a FRESH faulted env.

        Returns ``None`` if the whole fault script injects cleanly, or a short
        error string if the env raises (an unmet precondition -- exactly what
        would later surface as ``initial_state_not_loadable`` at task_verify).

        This reuses the adapter's ``make_faulted_env`` verbatim -- the same
        primitive the downstream task_verifier uses -- so a pass here means the
        init state is genuinely loadable. It is only ever called on a submit that
        already carries authored init actions (telecom), so no other domain pays
        for it. Any exception type is treated as a rejectable precondition
        failure; we never let a replay error escape and crash the episode."""
        try:
            self.adapter.make_faulted_env(init_actions)
            return None
        except Exception as e:  # noqa: BLE001 -- env raises plain ValueError etc.
            msg = str(e).strip() or e.__class__.__name__
            return msg[:400]

    def _explore(
        self, blueprint: TaskBlueprint, candidate_index: int, attempt: int = 0
    ) -> "tuple[Optional[Dict[str, Any]], ExploreTrace, List[Dict[str, Any]]]":
        plan = blueprint.dimension_plan or {}
        # Vary the seed per attempt so a re-roll starts from a different set of
        # records rather than deterministically re-walking the same dead end.
        seed = f"{blueprint.blueprint_id}:{candidate_index}:{attempt}"
        seeds = seed_ids(self.adapter, self.context.domain, seed, self.seed_count)

        env = self.adapter.make_faulted_env([])
        system = build_explore_system(
            _DETERMINISM_NOTES_DB.get(self.context.domain, ""),
            domain=self.context.domain,
        )
        opening = build_explore_opening(
            domain=self.context.domain,
            plan=plan,
            tool_schema_summary=self.context.tool_schema_summary(),
            database_summary=self.context.database_summary(),
            policy_text=self.context.policy[: self.policy_chars],
            seed_ids=seeds,
            fault_catalog=self._fault_catalog(),
            car_context_templates=self._car_context_templates(blueprint),
        )
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": system},
            {"role": "user", "content": opening},
        ]
        trace = ExploreTrace()
        # Share the list by reference so every later append to ``messages`` is
        # reflected in the trace (full, untruncated conversation).
        trace.messages = messages
        discovered: List[Dict[str, Any]] = []

        for turn in range(self.max_turns):
            trace.n_turns = turn + 1
            resp: LLMResponse = self.llm.complete(
                messages, max_tokens=self.max_tokens, temperature=1.0
            )
            obj = _parse_obj(resp.text)
            if obj is None:
                trace.terminated_reason = "parse_error"
                return None, trace, discovered

            if obj.get("action") == "submit":
                task = obj.get("task")
                if not isinstance(task, dict):
                    trace.terminated_reason = "empty_submit"
                    return None, trace, discovered
                # Authoring self-check (telecom): a submitted task whose authored
                # `initialization_actions` cannot actually be replayed into a
                # faulted env (e.g. `suspend_line_for_overdue_bill` on a line that
                # is not ACTIVE, or a customer that already carries an overdue
                # bill) is doomed to die at task_verify (`initial_state_not_
                # loadable`). Rather than emit that dead-on-arrival candidate, we
                # replay the fault script here against a fresh env and, on any
                # precondition error, hand the REAL env error back to the agent so
                # it re-binds to a compliant entity / picks another fault. This is
                # the authoring counterpart to discovery's "read a real record":
                # the env's own truth is the arbiter -- no telecom-specific rule is
                # hard-coded here. Shape-gated on the presence of authored init
                # actions, so airline/retail (which submit with none) are
                # byte-for-byte unchanged.
                init_actions = task.get("initialization_actions")
                if init_actions:
                    err = self._replay_authored_faults(init_actions)
                    if err is not None:
                        trace.n_replay_rejects += 1
                        messages.append({"role": "assistant", "content": json.dumps(obj)})
                        messages.append(
                            {
                                "role": "user",
                                "content": (
                                    "REJECTED: replaying your initialization_actions "
                                    "into a fresh environment failed with this real "
                                    f"env error:\n{err}\n"
                                    "The fault you authored cannot be injected on the "
                                    "entity you chose (a precondition is unmet -- e.g. "
                                    "the line is not ACTIVE, or the customer already "
                                    "has an overdue bill, or an earlier fault in your "
                                    "list already changed that state). Re-bind to a "
                                    "REAL, compliant customer/line you verified via "
                                    "read tools (or pick a different fault), then "
                                    "submit again. Do NOT resubmit the same ids."
                                ),
                            }
                        )
                        continue
                trace.terminated_reason = "submit"
                return task, trace, discovered

            name = obj.get("name")
            if not name:
                trace.terminated_reason = "parse_error"
                return None, trace, discovered
            actor = str(obj.get("actor", "assistant"))
            args = dict(obj.get("arguments") or {})
            obs = self.adapter.exec_action(
                env, actor, name, args, turn, max_content_chars=self.obs_chars
            )
            trace.calls.append({"turn": turn, "name": name, "status": obs.get("status")})
            # Capture read-tool results as the "entity sample" for grounding.
            if obs.get("status") == "ok":
                discovered.append({"tool": name, "arguments": args,
                                   "result": obs.get("content")})
            messages.append({"role": "assistant", "content": json.dumps(obj)})
            messages.append(
                {
                    "role": "user",
                    "content": (
                        f"Tool result: {json.dumps(obs, ensure_ascii=False)}\n"
                        "Next JSON action (call another tool, or submit the task)."
                    ),
                }
            )

        trace.terminated_reason = "max_turns"
        return None, trace, discovered

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION
