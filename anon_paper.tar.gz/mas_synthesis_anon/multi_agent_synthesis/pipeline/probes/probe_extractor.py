"""Diagnostic probes: low-level features computed from a sample's GT actions.
Probes are NOT dimensions — the reflector promotes them. Accepts both the on-disk
action shape ({action_id,requestor,name,arguments}) and the canonical GTAction
shape ({actor,type,name,arguments,compare_args})."""
from __future__ import annotations

from typing import Any, Dict, List

AIRLINE_WRITE_TOOLS = frozenset({
    "book_reservation", "cancel_reservation", "send_certificate",
    "update_reservation_baggages", "update_reservation_flights",
    "update_reservation_passengers",
})
AIRLINE_READ_TOOLS = frozenset({
    "get_reservation_details", "get_user_details", "list_all_airports",
    "search_direct_flight", "search_onestop_flight", "get_flight_status",
})
# Retail domain tool classification, from tau2 retail tools.py @is_tool(ToolType.*)
# decorators (ground truth). Ported here because the extractor was airline-only
# and silently reported nwrite=0 / computation=no on ALL retail tasks -- the same
# airline-hardcoding porting gap that once killed retail refuse via gt_nontrivial.
# Airline and retail tool names are DISJOINT, so unioning is safe: airline
# behavior is unchanged, retail now counts its real writes.
RETAIL_WRITE_TOOLS = frozenset({
    "cancel_pending_order", "exchange_delivered_order_items",
    "modify_pending_order_address", "modify_pending_order_items",
    "modify_pending_order_payment", "modify_user_address",
    "return_delivered_order_items",
})
RETAIL_READ_TOOLS = frozenset({
    "find_user_id_by_email", "find_user_id_by_name_zip", "get_order_details",
    "get_product_details", "get_user_details", "list_all_product_types",
})
# Car-bench (in-car voice assistant) tool classification, from the round-1 GT
# action inventory. Same airline-hardcoding porting gap as retail: the extractor
# reported nwrite=0 / computation=no on ALL car tasks (car's set_*/open_close_*/
# navigation_* writes were invisible), collapsing every count probe to {'0':1.0}.
# Car tool names are DISJOINT from airline+retail, so unioning is safe. Writes =
# any state-changing actuator (set_*, open_close_*, navigation_* mutators) plus
# comms side-effects (send_email, call_phone_by_number); reads = get_*/search_*.
CAR_WRITE_TOOLS = frozenset({
    "set_seat_heating", "set_climate_temperature", "set_fan_speed",
    "set_steering_wheel_heating", "set_ambient_lights", "set_air_circulation",
    "set_air_conditioning", "set_reading_light", "set_head_lights_high_beams",
    "set_head_lights_low_beams", "set_fan_airflow_direction", "set_window_defrost",
    "open_close_sunshade", "open_close_sunroof", "open_close_trunk_door",
    "open_close_window",
    "set_new_navigation", "navigation_add_one_waypoint",
    "navigation_replace_one_waypoint", "navigation_replace_final_destination",
    "send_email", "call_phone_by_number",
})
CAR_READ_TOOLS = frozenset({
    "get_routes_from_start_to_destination", "get_user_preferences",
    "search_poi_along_the_route", "search_poi_at_location",
    "get_charging_specs_and_status", "get_current_navigation_state",
    "get_seats_occupancy", "get_location_id_by_location_name",
    "get_distance_by_soc", "get_climate_settings", "get_seat_heating_level",
    "get_contact_id_by_contact_name", "get_temperature_inside_car",
    "get_contact_information", "get_steering_wheel_heating_level",
    "get_weather", "get_trunk_door_position", "get_sunroof_and_sunshade_position",
    "get_ambient_light_status_and_color", "get_reading_lights_status",
    "get_exterior_lights_status", "get_vehicle_window_positions",
})
# Retail's explicit computation marker: the `calculate` tool (GENERIC) is called
# precisely when the task needs exact arithmetic (refund/fee/price math). This is
# retail's analogue of airline's fee_calc / fare-difference signal. Car's analogues
# are the charging/math helpers (SoC<->time conversions, explicit calculate_math).
COMPUTATION_TOOLS = frozenset({
    "calculate",
    "calculate_charging_time_by_soc", "calculate_charging_soc_by_time",
    "calculate_math", "convert_route_distance_and_time",
})

# Telecom (troubleshooting/billing agent) tool classification, from tau2 telecom
# tools.py @is_tool(ToolType.*) decorators (ground truth: 21 READ / 21 WRITE / 1
# GENERIC). Same airline-hardcoding porting gap as retail/car: the extractor
# reported nwrite=0 / computation=no on ALL telecom tasks (device/line/billing
# writes were invisible), collapsing every count probe to {'0':1.0}. Telecom tool
# names are DISJOINT from airline+retail+car, so unioning is safe. Writes = any
# state-changing device/line/billing actuator (toggle_*/turn-ish set_*, VPN/roaming
# connect, sim reseat, reboot, suspend/resume line, payments). transfer_to_human_agents
# is GENERIC (terminal escalation, no device-state change) -> intentionally in
# NEITHER set, the telecom analogue of retail's refuse short-circuit.
TELECOM_WRITE_TOOLS = frozenset({
    "connect_vpn", "disable_roaming", "disconnect_vpn", "enable_roaming",
    "grant_app_permission", "make_payment", "reboot_device", "refuel_data",
    "reseat_sim_card", "reset_apn_settings", "resume_line", "send_payment_request",
    "set_apn_settings", "set_network_mode_preference", "suspend_line",
    "toggle_airplane_mode", "toggle_data", "toggle_data_saver_mode",
    "toggle_roaming", "toggle_wifi", "toggle_wifi_calling",
})
TELECOM_READ_TOOLS = frozenset({
    "can_send_mms", "check_apn_settings", "check_app_permissions",
    "check_app_status", "check_data_restriction_status", "check_installed_apps",
    "check_network_mode_preference", "check_network_status", "check_payment_request",
    "check_sim_status", "check_status_bar", "check_vpn_status",
    "check_wifi_calling_status", "check_wifi_status", "get_bills_for_customer",
    "get_customer_by_id", "get_customer_by_name", "get_customer_by_phone",
    "get_data_usage", "get_details_by_id", "run_speed_test",
})

WRITE_TOOLS = AIRLINE_WRITE_TOOLS | RETAIL_WRITE_TOOLS | CAR_WRITE_TOOLS | TELECOM_WRITE_TOOLS
READ_TOOLS = AIRLINE_READ_TOOLS | RETAIL_READ_TOOLS | CAR_READ_TOOLS | TELECOM_READ_TOOLS
NUMERIC_ARG_KEYS = frozenset({
    # airline numeric/computation arg keys
    "amount", "amounts", "payment_methods", "total_baggages",
    "nonfree_baggages", "fee", "price", "refund", "cabin",
    # retail numeric/computation-ish arg keys (payment + multi-item)
    "payment_method_id", "item_ids", "new_item_ids",
})
_ENTITY_ID_KEYS = ("reservation_id", "user_id", "flight_number",
                   "order_id", "product_id")


def write_bucket(n: int) -> str:
    # Buckets match v3's gt_write_count (0/1/2/3-4/5+) so the reflector-promoted
    # num_write axis carries the same test-anchored high-end granularity: the
    # eval set has real 5+ tasks (7/18/32/33/39/42) that a coarse "3+" would blur.
    if n <= 0:
        return "0"
    if n == 1:
        return "1"
    if n == 2:
        return "2"
    if n <= 4:
        return "3-4"
    return "5+"


def iter_actions(sample: Dict[str, Any]) -> List[Dict[str, Any]]:
    raw = (sample.get("gt_actions")
           or (sample.get("task", {}).get("evaluation_criteria", {}) or {}).get("actions")
           or [])
    out = []
    for a in raw:
        if not isinstance(a, dict):
            continue
        out.append({
            "name": a.get("name", ""),
            "arguments": a.get("arguments") or {},
            "actor": a.get("actor") or a.get("requestor") or "assistant",
        })
    return out


def _payment_split(args: Dict[str, Any]) -> bool:
    pm = args.get("payment_methods")
    return isinstance(pm, list) and len(pm) >= 2


def extract_sample_probes(sample: Dict[str, Any]) -> Dict[str, Any]:
    acts = iter_actions(sample)
    writes = [a for a in acts if a["name"] in WRITE_TOOLS]
    reads = [a for a in acts if a["name"] in READ_TOOLS]
    has_calc = any(a["name"] in COMPUTATION_TOOLS for a in acts)

    entities = set()
    numeric_fields = 0
    fee_calc = False
    fare_diff = False
    for a in acts:
        args = a["arguments"]
        for k in _ENTITY_ID_KEYS:
            if k in args and isinstance(args[k], (str, int)):
                entities.add(f"{k}={args[k]}")
        for k in NUMERIC_ARG_KEYS:
            if k in args:
                numeric_fields += 1
        if _payment_split(args) or "amount" in args or "refund" in args or "fee" in args:
            fee_calc = True
        if a["name"] in ("update_reservation_flights", "update_reservation_baggages"):
            fare_diff = True

    # retail marks exact-arithmetic tasks with an explicit `calculate` tool call;
    # airline marks them via fee_calc / payment split. Either => requires_computation.
    requires_computation = "yes" if (has_calc or fee_calc or any(
        _payment_split(a["arguments"]) for a in writes)) else "no"
    fee_calc = fee_calc or has_calc

    focus = (sample.get("micro_plan", {}) or {}).get("policy_or_constraint_focus") or []
    num_policy = len(focus) if isinstance(focus, list) else (1 if focus else 0)

    nwrite = len(writes)
    return {
        "num_write_actions": nwrite,
        "num_write_bucket": write_bucket(nwrite),
        "num_read_actions": len(reads),
        "trajectory_length": len(acts),
        "num_state_changes": nwrite,
        "num_entities_touched": len(entities),
        "num_numeric_fields": numeric_fields,
        "requires_computation": requires_computation,
        "has_fare_difference": fare_diff,
        "has_refund_or_fee_calculation": fee_calc,
        "num_policy_constraints": num_policy,
    }
