"""Aggregate per-sample probes into a round-level report: per-probe distribution,
a failure_correlation_summary, AND a coverage_note. The reflector reads this to
decide which probes are worth promoting to dimensions.

Two signals are surfaced on purpose, so the reflector can both EXPLOIT and EXPLORE:
  * failure_correlation_summary -- where observed buckets fail (mode A: deepen a
    painful axis).
  * coverage_note + full zero-filled bucket ladder -- whether the task space
    barely exercises the high end of a COUNT axis (mode B: a coverage gap, e.g.
    "all tasks are 0/1 writes, 2+/3+ are empty"). A bucket that never occurs can
    never "fail", so without zero-filling + this note an empty high end is
    INVISIBLE to a failure-only lens. That invisibility is exactly what would stop
    the reflector from ever proposing a num_write axis on a low-write round-1 pool.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional

from .probe_extractor import extract_sample_probes, write_bucket

# Canonical full bucket ladder for COUNT probes. Always reported (zero-filled) so
# an empty high end shows up as an explicit 0.0, not as a missing key.
_COUNT_LADDER = ("0", "1", "2", "3-4", "5+")

# probe_id -> the GENERATOR-EXECUTABLE semantic axis it argues for. A probe is a
# numeric/boolean DETECTOR (good for finding gaps from data), but the generator
# cannot act on "num_numeric_fields=3+"; it CAN act on a semantic axis like
# computation="aggregate". So when the reflector promotes one of these probes it
# should promote the SUGGESTED AXIS (executable values), not the raw count bucket.
# Values mirror the validated v3 `computation` axis (synthesis already teaches
# the generator how to realize each). Only probes with a real executable mapping
# carry a suggestion; pure count probes (num_write etc.) map to a write-count axis.
_SUGGESTED_AXIS = {
    "num_numeric_fields": {
        "name": "computation",
        "values": ["none", "aggregate", "constrained_optimization", "conditional_threshold"],
        "why": "exact numeric computation depth (fees/refunds/splits/optimization); "
               "the generator realizes each value via the validated v3 computation axis",
    },
    "requires_computation": {
        "name": "computation",
        "values": ["none", "aggregate", "constrained_optimization", "conditional_threshold"],
        "why": "whether/which exact numeric computation the task requires",
    },
    "has_refund_or_fee_calculation": {
        "name": "computation",
        "values": ["none", "aggregate", "constrained_optimization", "conditional_threshold"],
        "why": "refund/fee/amount calculation depth",
    },
    "num_write_actions": {
        "name": "num_write",
        "values": ["0", "1", "2", "3-4", "5+"],
        "why": "number of state-changing writes the correct trajectory requires; "
               "the generator realizes multi-write chains via the validated v3 path",
    },
    "num_state_changes": {
        "name": "num_write",
        "values": ["0", "1", "2", "3-4", "5+"],
        "why": "number of DB state changes (writes) required",
    },
}

# probe_id -> (description, kind). kind in {"count","bool","cat"}.
_PROBE_SPECS = {
    "num_write_actions": ("Number of state-changing write actions in the gold trajectory.", "count"),
    "num_read_actions": ("Number of read/lookup actions in the gold trajectory.", "count"),
    "trajectory_length": ("Total number of gold actions.", "count"),
    "num_state_changes": ("Number of DB state changes (writes).", "count"),
    "num_entities_touched": ("Distinct entities referenced across actions.", "count"),
    "num_numeric_fields": ("Count of numeric/fee-bearing argument fields.", "count"),
    "num_policy_constraints": ("Number of policy/constraint foci on the task.", "count"),
    "requires_computation": ("Whether the task requires exact numeric computation.", "bool"),
    "has_fare_difference": ("Whether the task involves a fare-difference update.", "bool"),
    "has_refund_or_fee_calculation": ("Whether a refund/fee/amount calculation is involved.", "bool"),
}


def _bucket_value(probe_id: str, kind: str, value: Any) -> str:
    if kind == "count":
        return write_bucket(int(value))
    if kind == "bool":
        if isinstance(value, str):
            return value  # already "no"/"yes"
        return "yes" if value else "no"
    return str(value)


def extract_diagnostic_probes(
    samples: List[Dict[str, Any]],
    replay_logs: Optional[Any] = None,
    eval_logs: Optional[Any] = None,
    round_id: str = "",
) -> Dict[str, Any]:
    per_sample = [extract_sample_probes(s) for s in samples]

    def _failed(s: Dict[str, Any]) -> bool:
        vr = s.get("verifier_report") or {}
        if vr.get("passed") is False:
            return True
        return s.get("replay_passed") is False

    failed_flags = [_failed(s) for s in samples]
    n = len(samples) or 1

    probe_stats: List[Dict[str, Any]] = []
    for probe_id, (desc, kind) in _PROBE_SPECS.items():
        dist_counter: Counter = Counter()
        fail_by_bucket: Dict[str, int] = defaultdict(int)
        tot_by_bucket: Dict[str, int] = defaultdict(int)
        for feats, failed in zip(per_sample, failed_flags):
            b = _bucket_value(probe_id, kind, feats[probe_id])
            dist_counter[b] += 1
            tot_by_bucket[b] += 1
            if failed:
                fail_by_bucket[b] += 1
        # For COUNT probes, zero-fill the full ladder so an absent high bucket is
        # an explicit 0.0 (visible) rather than a missing key (invisible).
        if kind == "count":
            distribution = {b: round(dist_counter.get(b, 0) / n, 4)
                            for b in _COUNT_LADDER}
        else:
            distribution = {k: round(v / n, 4) for k, v in dist_counter.items()}

        # failure correlation: which bucket carries the highest failure RATE
        worst_bucket, worst_rate = None, -1.0
        for b, tot in tot_by_bucket.items():
            rate = fail_by_bucket[b] / tot if tot else 0.0
            if rate > worst_rate and fail_by_bucket[b] > 0:
                worst_bucket, worst_rate = b, rate
        if worst_bucket is None:
            summary = "No validation failures correlated with this probe."
        else:
            summary = (f"Failed cases concentrate at {probe_id}={worst_bucket} "
                       f"(failure rate {worst_rate:.2f}).")

        # coverage note (COUNT probes): flag when the axis is bunched at the low
        # end with an empty/near-empty high end -- a coverage gap worth exploring.
        coverage_note = ""
        if kind == "count":
            high = (distribution.get("2", 0.0) + distribution.get("3-4", 0.0)
                    + distribution.get("5+", 0.0))
            top = distribution.get("3-4", 0.0) + distribution.get("5+", 0.0)
            if top <= 0.005 and high <= 0.05:
                empty = [b for b in ("2", "3-4", "5+") if distribution.get(b, 0.0) <= 0.005]
                coverage_note = (
                    f"COVERAGE GAP: this count axis is saturated at the low end "
                    f"(0/1 = {distribution.get('0',0)+distribution.get('1',0):.2f}); "
                    f"buckets {','.join(empty)} are empty/near-empty "
                    f"(high end {high:.3f}). The task space barely exercises the "
                    f"high end of this axis -- it may be UNDER-COVERED, not absent "
                    f"because it is unimportant.")
            elif high >= 0.10:
                coverage_note = (
                    f"This count axis has real spread into the high end "
                    f"(2 and above together = {high:.2f}).")

        probe_stats.append({
            "probe_id": probe_id,
            "description": desc,
            "distribution": distribution,
            "failure_correlation_summary": summary,
            "coverage_note": coverage_note,
            # the generator-executable semantic axis to promote (if this probe has
            # one). The reflector promotes THIS, not the raw count bucket.
            "suggested_axis": _SUGGESTED_AXIS.get(probe_id),
        })

    return {"round_id": round_id, "probe_stats": probe_stats}
