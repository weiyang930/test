"""Macro layer: the ConditionSource interface (v0 two-layer planner).

The MACRO layer decides DIRECTION (coverage). It emits ``condition`` dicts -- each
a partial ``selected_dimensions`` -- that the MICRO planner
(:class:`multi_agent_synthesis.pipeline.planner_agent.DimensionPlanner`)
then completes into a full blueprint. A batch of micro calls under the SAME
condition is a clean i.i.d. sampling group, so the two layers split cleanly:

* macro = coarse grain (which cells to lean into) -- the natural home for feedback;
* micro = fine grain (concrete dimension values) -- the RL-trained policy.

A condition pins a SUBSET of the real dimension keys (NOT new abstract keys), so
micro needs no translation and -- when RL arrives -- both layers share one
coordinate system.

This module is the INTERFACE plus a deterministic placeholder. The real
feedback-driven macro (which metrics to compute, which axes to pin) is a separate
spec; only the signature here is the contract.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from itertools import product
from typing import Any, Dict, List, Optional

from ..dimensions.loader import DomainDimensions
from ..llm.base import BaseLLMClient
from .factual_context import SynthesisContext


BUDGET_LEVELS = ("zero", "low", "medium", "high", "explore")
OBJECTIVE_TYPES = (
    "undercovered", "over_mastered", "failure_targeted", "exploration", "repair",
)

# JSON schema for the macro proposal envelope, used as vLLM guided_json ONLY on
# the deterministic_json (always-thinking) path. It forces the model to emit a
# complete, schema-valid {"conditions":[...]} from the first token -- it cannot
# ramble into prose or stop mid-object. Empirically (2026-07-14) think-off+temp0
# ALONE is flaky (one rep truncated at 8k -> finish_reason=length -> invalid
# JSON); adding this grammar makes every rep converge (output is also more
# compact, so it finishes well under budget). Kept permissive (only ids/budget/
# preferred_values required) so it never over-constrains the macro's freedom to
# propose new values; validate_condition still does the real checking.
MACRO_CONDITIONS_JSON_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "conditions": {
            "type": "array", "minItems": 6, "maxItems": 40,
            "items": {
                "type": "object",
                "properties": {
                    "condition_id": {"type": "string"},
                    "objective_type": {"type": "string"},
                    "objective": {"type": "string"},
                    "preferred_values": {"type": "object"},
                    "allowed_values": {"type": "object"},
                    "forbidden_values": {"type": "object"},
                    "avoid_patterns": {"type": "array", "items": {"type": "string"}},
                    "budget_level": {"type": "string"},
                    "rationale": {"type": "string"},
                },
                "required": ["condition_id", "budget_level", "preferred_values"],
            },
        }
    },
    "required": ["conditions"],
}


def validate_condition(c: "MacroCondition", dim_keys: List[str]) -> List[str]:
    """Lightest possible check (spec §4). Returns violations (empty == valid).

    Intentionally does NOT check that values are in the value list -- the macro
    is allowed to propose brand-new values to open up uncovered directions.
    """
    problems: List[str] = []
    if not c.condition_id:
        problems.append("condition_id: empty")
    if c.budget_level not in BUDGET_LEVELS:
        problems.append(f"budget_level: '{c.budget_level}' not in {BUDGET_LEVELS}")
    # objective_type may be empty (optional), but if set must be a known enum.
    if c.objective_type and c.objective_type not in OBJECTIVE_TYPES:
        problems.append(
            f"objective_type: '{c.objective_type}' not in {OBJECTIVE_TYPES}")
    known = set(dim_keys)
    for field_name in ("preferred_values", "allowed_values", "forbidden_values"):
        for k in getattr(c, field_name):
            if k not in known:
                problems.append(f"{field_name}: unknown dimension key '{k}'")
    return problems


BUDGET_WEIGHTS = {"zero": 0, "low": 1, "medium": 2, "high": 4, "explore": 1}


def expand_by_budget(
    conditions: List["MacroCondition"], n: int
) -> List[Optional[Dict[str, Any]]]:
    """Expand budget-weighted conditions into exactly ``n`` slot dicts.

    Largest-remainder rounding makes the slot counts sum to exactly ``n``.
    ``zero``-budget conditions get 0 slots. If no positive weight remains (all
    zero, or no conditions) every slot is ``None`` (a fully-free plan).
    """
    if n <= 0:
        return []
    weighted = [(c, BUDGET_WEIGHTS.get(c.budget_level, 0)) for c in conditions]
    total_w = sum(w for _, w in weighted)
    if total_w == 0:
        return [None] * n
    # ideal (fractional) slot counts, then largest-remainder rounding.
    ideal = [(c, n * w / total_w) for c, w in weighted if w > 0]
    floors = [(c, int(x)) for c, x in ideal]
    assigned = sum(cnt for _, cnt in floors)
    remainder = n - assigned
    # hand the leftover slots to the largest fractional parts.
    frac_order = sorted(
        range(len(ideal)), key=lambda i: ideal[i][1] - int(ideal[i][1]), reverse=True
    )
    counts = [cnt for _, cnt in floors]
    for j in range(remainder):
        counts[frac_order[j % len(frac_order)]] += 1
    slots: List[Optional[Dict[str, Any]]] = []
    for (c, _), cnt in zip(ideal, counts):
        slots.extend(c.to_dict() for _ in range(cnt))
    return slots


def _parse_json_obj(text: str) -> Optional[Dict[str, Any]]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            obj = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return obj if isinstance(obj, dict) else None


def _salvage_conditions(text: str) -> List[Dict[str, Any]]:
    """Recover every COMPLETE ``{...}`` object from a truncated conditions array.

    The always-thinking backbone (Qwen3-*-Thinking-2507) IGNORES
    enable_thinking=False and reasons for 40-54k chars BEFORE emitting the JSON,
    so with a large (feedback-laden) macro prompt it runs out of the token budget
    mid-array: the LEADING conditions are complete + valid, only the trailing
    object and the array/object close are missing -> the body fails a strict
    parse (observed 2026-07-16). guided_json does NOT prevent this because the
    qwen3 reasoning parser leaves the <think> block outside the grammar, so the
    grammar only kicks in after the (unbounded) think.

    Rather than discard a perfectly good 5-condition plan over a missing brace,
    scan the ``conditions`` array brace/string-aware and return each complete
    top-level object, dropping only the truncated tail. Returns [] if the array
    marker is absent or nothing complete precedes the truncation.
    """
    text = (text or "").strip()
    m = re.search(r'"conditions"\s*:\s*\[', text)
    if not m:
        return []
    i, n = m.end(), len(text)
    objs: List[Dict[str, Any]] = []
    while i < n:
        while i < n and text[i] != "{":
            if text[i] == "]":   # array closed cleanly -> done
                return objs
            i += 1
        if i >= n:
            break
        start = i
        depth = 0
        in_str = esc = False
        closed = False
        while i < n:
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            elif ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        objs.append(json.loads(text[start : i + 1]))
                    except json.JSONDecodeError:
                        return objs  # first unparseable complete object -> stop
                    i += 1
                    closed = True
                    break
            i += 1
        if not closed:
            break   # ran off the end mid-object -> truncated tail, stop
    return objs


@dataclass
class MacroCondition:
    """One feedback-driven generation direction (the macro layer's output unit).

    The ``*_values`` keys are the EXISTING dimension keys (task_family,
    expected_outcome, ...) -- no new abstract keys. Values MAY go beyond the
    current value lists (the macro can propose new values to open up uncovered
    directions); the constraints are expressed to the micro planner via prompt,
    not enforced in code this round.
    """

    condition_id: str
    budget_level: str
    objective_type: str = ""
    objective: str = ""
    preferred_values: Dict[str, List[str]] = field(default_factory=dict)
    allowed_values: Dict[str, List[str]] = field(default_factory=dict)
    forbidden_values: Dict[str, List[str]] = field(default_factory=dict)
    avoid_patterns: List[str] = field(default_factory=list)
    rationale: str = ""

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "MacroCondition":
        return cls(
            condition_id=str(raw.get("condition_id", "")),
            budget_level=str(raw.get("budget_level", "")),
            objective_type=str(raw.get("objective_type", "")),
            objective=str(raw.get("objective", "")),
            preferred_values=dict(raw.get("preferred_values") or {}),
            allowed_values=dict(raw.get("allowed_values") or {}),
            forbidden_values=dict(raw.get("forbidden_values") or {}),
            avoid_patterns=list(raw.get("avoid_patterns") or []),
            rationale=str(raw.get("rationale", "")),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "condition_id": self.condition_id,
            "budget_level": self.budget_level,
            "objective_type": self.objective_type,
            "objective": self.objective,
            "preferred_values": self.preferred_values,
            "allowed_values": self.allowed_values,
            "forbidden_values": self.forbidden_values,
            "avoid_patterns": self.avoid_patterns,
            "rationale": self.rationale,
        }


class ConditionSource:
    """Emit ``n`` conditions (partial ``selected_dimensions`` dicts).

    ``None`` in a slot means a fully-free plan (micro chooses everything). The
    real macro will additionally consume feedback; this base signature is the
    stable contract the micro layer depends on.
    """

    def next_conditions(self, n: int) -> List[Optional[Dict[str, Any]]]:
        raise NotImplementedError


class FreeConditionSource(ConditionSource):
    """No direction at all: every plan is fully free (legacy v0 behavior)."""

    def next_conditions(self, n: int) -> List[Optional[Dict[str, Any]]]:
        return [None] * n


class FileConditionSource(ConditionSource):
    """Replay a fixed list of MacroConditions from a JSONL file (one per line).

    Bypasses the macro LLM entirely: the file IS the macro output. Used to test
    whether a hand-authored / oracle set of conditions outperforms the cold-start
    macro, without coupling that test to the macro's ability to emit them. Budget
    allocation reuses ``expand_by_budget`` exactly like MacroPlanner, so a
    file-sourced run is otherwise indistinguishable downstream.
    """

    def __init__(self, conditions_file: str):
        self.conditions_file = conditions_file
        self.last_valid_conditions: List[MacroCondition] = []
        with open(conditions_file) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                raw = json.loads(line)
                self.last_valid_conditions.append(MacroCondition.from_dict(raw))
        if not self.last_valid_conditions:
            raise ValueError(
                f"FileConditionSource: no conditions parsed from {conditions_file}")

    def cid_to_dict(self) -> Dict[str, Dict[str, Any]]:
        return {c.condition_id: c.to_dict() for c in self.last_valid_conditions}

    def next_conditions(self, n: int) -> List[Optional[Dict[str, Any]]]:
        return expand_by_budget(self.last_valid_conditions, n)


class RoundRobinConditionSource(ConditionSource):
    """Deterministic placeholder: round-robin over a Cartesian product of pinned
    axes (default ``task_family x expected_outcome``), leaving every other
    dimension free for the micro planner to sample.

    Which axes to pin is a PLACEHOLDER choice, not the final macro policy -- the
    feedback-driven version (next spec) decides that. Pinning only a couple of
    axes keeps a real sampling space for the micro planner (so a same-condition
    batch still has within-group diversity).
    """

    def __init__(
        self,
        dims: DomainDimensions,
        pin_keys: Optional[List[str]] = None,
    ):
        self.dims = dims
        self.pin_keys = pin_keys or ["task_family", "expected_outcome"]
        # Cartesian product of the pinned axes' value lists, in a stable order.
        value_lists = [self.dims.values_for(k) for k in self.pin_keys]
        if any(len(v) == 0 for v in value_lists):
            missing = [k for k, v in zip(self.pin_keys, value_lists) if not v]
            raise ValueError(
                f"RoundRobinConditionSource: no values for pinned key(s) {missing} "
                f"in domain '{self.dims.domain}'"
            )
        self._cells: List[Dict[str, Any]] = [
            dict(zip(self.pin_keys, combo)) for combo in product(*value_lists)
        ]
        self._cursor = 0

    def next_conditions(self, n: int) -> List[Optional[Dict[str, Any]]]:
        out: List[Optional[Dict[str, Any]]] = []
        for _ in range(n):
            out.append(dict(self._cells[self._cursor % len(self._cells)]))
            self._cursor += 1
        return out


class MacroPlanner(ConditionSource):
    """LLM macro layer: proposes feedback-driven generation directions.

    Reads the obtainable domain surface (the same SynthesisContext the micro planner
    sees, possibly truncated) and emits MacroConditions, which the budget
    allocator expands into per-blueprint slots. ``feedback`` (last round's
    ``recommended_macro_signals``) is injected into the prompt as priority
    signals the macro LLM weighs.
    """

    def __init__(
        self,
        dims: DomainDimensions,
        context: SynthesisContext,
        llm: BaseLLMClient,
        max_tokens: int = 8000,
        policy_chars: int = 3000,
        feedback: Optional[Any] = None,
        prior_strength: str = "strong",
        newly_added_axes: Optional[List[Dict[str, Any]]] = None,
        macro_call_timeout: float = 240.0,
        macro_call_attempts: int = 6,
        deterministic_json: bool = False,
    ):
        # per-attempt wall-clock bound + retries for the single main-thread macro
        # bedrock call (guards against a wedged SSL recv hanging the whole run).
        self._macro_call_timeout = macro_call_timeout
        self._macro_call_attempts = macro_call_attempts
        self.dims = dims
        self.context = context
        self.llm = llm
        self.max_tokens = max_tokens
        self.policy_chars = policy_chars
        self.feedback = feedback  # recommended_macro_signals dict (or None); injected into prompt
        self.prior_strength = prior_strength  # "strong" | "weak" cold-start prior (no-feedback only)
        # ALWAYS-THINKING backbones (Qwen3-*-Thinking-2507) reason without bound on
        # this open-ended macro prompt: they run to max_tokens and NEVER close
        # </think> / never emit {"conditions":[...]}, so the parser sees nothing
        # -> [None]*n -> the micro planner self-collapses to one task_family
        # (round-1 cs30b: 862/919 flight_change). macro is a STRUCTURED direction-
        # picking task that does NOT need deep reasoning. deterministic_json makes
        # the macro call temperature=0.0 AND disables thinking on the served model
        # (chat_template_kwargs.enable_thinking=False). EMPIRICALLY (2026-07-14,
        # probe_macro_thinkfix_cs30b): think-off ALONE at temp=1.0 still diverges;
        # think-off + temp=0.0 TOGETHER converges -> clean 6-family 250x250 spread.
        # Off by default so base/Opus macro paths are byte-identical to before.
        self.deterministic_json = deterministic_json
        # axes the reflector promoted LAST round -> macro tilts budget toward them.
        self.newly_added_axes = newly_added_axes or []
        # Surfaced for downstream logging / feedback_sample lookup. Populated by
        # next_conditions(); empty when macro fell through to None-slots.
        self.last_valid_conditions: List[MacroCondition] = []

    def cid_to_dict(self) -> Dict[str, Dict[str, Any]]:
        """condition_id -> full MacroCondition.to_dict() (for intended_condition lookup)."""
        return {c.condition_id: c.to_dict() for c in self.last_valid_conditions}

    def next_conditions(self, n: int) -> List[Optional[Dict[str, Any]]]:
        from .prompts.macro_planner import build_macro_prompt
        system, user = build_macro_prompt(
            domain=self.dims.domain,
            context_summary=self.context.context_summary(),
            tool_schema_summary=self.context.tool_schema_summary(),
            policy_summary=self.context.policy[: self.policy_chars],
            dimension_values_json=self.dims.to_planner_json(),
            n=n,
            feedback=self.feedback,
            prior_strength=self.prior_strength,
            newly_added_axes=self.newly_added_axes,
        )
        # The macro proposal is a SINGLE large bedrock call (max_tokens=8000,
        # temperature=1.0) on the MAIN thread -- the fork-watchdog does NOT cover
        # it, so a wedged SSL recv hangs the whole run forever (observed: n=700
        # stalled >20min at 0 cpu, 0 output). Bound each attempt with a thread-
        # level timeout and retry a couple of times before giving up.
        #
        # deterministic_json (always-thinking backbones): THREE things together,
        # each necessary (empirically 2026-07-14, probe_macro_variants_cs30b):
        #   * temperature=0.0            -- kill sampling divergence;
        #   * enable_thinking=False      -- stop the unbounded <think> that eats
        #                                   the whole budget before any JSON;
        #   * guided_json (grammar)      -- force a complete schema-valid
        #                                   {"conditions":[...]} from token 1
        #                                   (think-off+temp0 ALONE is flaky: one
        #                                   rep truncated at 8k -> length ->
        #                                   invalid JSON; guided makes every rep
        #                                   converge and also compacts output).
        # extra_body / chat_template_kwargs / guided_json pass through
        # QwenLocalClient.complete -> litellm -> vLLM; Bedrock ignores unknown
        # kwargs, so base/Opus are unaffected. A generous token floor guards the
        # remaining truncation risk.
        macro_tokens = self.max_tokens
        call_extra: Dict[str, Any] = {}
        if self.deterministic_json:
            call_extra["extra_body"] = {
                "chat_template_kwargs": {"enable_thinking": False},
                "guided_json": MACRO_CONDITIONS_JSON_SCHEMA,
            }
            macro_tokens = max(self.max_tokens, 16000)
        from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FTimeout
        # An attempt fails NOT ONLY on timeout/exception but ALSO when the call
        # returns a body we cannot turn into >=1 valid condition. Parse+validate
        # therefore run INSIDE the loop so a bad body is retryable instead of an
        # instant collapse to [None]*n (which recreates the round-1 family
        # collapse). The DOMINANT failure for the always-thinking backbone
        # (Qwen3-*-Thinking-2507, diagnosed 2026-07-16 by dumping the raw body):
        # it IGNORES enable_thinking=False and reasons 40-54k chars BEFORE the
        # JSON, so with a large feedback-laden macro prompt it hits
        # finish_reason=length mid-array -> the trailing condition + array close
        # are missing -> strict json.loads fails at the very end. But the LEADING
        # conditions are complete and valid, and guided_json cannot prevent this
        # (the qwen3 reasoning parser keeps <think> outside the grammar, and
        # raising max_tokens only makes the think expand to eat it). So on a
        # strict-parse miss we SALVAGE the complete conditions from the truncated
        # array (_salvage_conditions) rather than throw away a good 5-condition
        # plan; we only fall through to a retry when salvage yields nothing
        # usable. (Retries still perturb temp on the det path as a cheap
        # tie-breaker, but salvage is what actually rescues the round-2 macro.)
        # Coverage floor for a SALVAGED plan: macro is called ONCE and its plan
        # steers all n blueprint slots, so accepting a too-thin salvage (e.g. the
        # truncation hit after only 1-2 conditions) would silently narrow the
        # whole round. A CLEAN strict parse is trusted at any count (the model
        # finished on purpose); a salvaged plan must clear this floor or we retry
        # and keep the best-seen. Floor tracks the newly-added axis cardinality
        # (so every new-axis bucket can get its own condition), min 4.
        salvage_floor = 4
        for ax in self.newly_added_axes:
            salvage_floor = max(salvage_floor, len(ax.get("values") or []))
        valid: List[MacroCondition] = []
        best_valid: List[MacroCondition] = []   # most conditions seen across attempts
        for attempt in range(1, self._macro_call_attempts + 1):
            if self.deterministic_json:
                macro_temp = 0.0 if attempt == 1 else 0.5
            else:
                macro_temp = 1.0
            ex = ThreadPoolExecutor(max_workers=1)
            fut = ex.submit(
                self.llm.complete_prompt, system, user,
                max_tokens=macro_tokens, temperature=macro_temp, **call_extra)
            resp = None
            try:
                resp = fut.result(timeout=self._macro_call_timeout)
                ex.shutdown(wait=False)
            except _FTimeout:
                print(f"[macro] proposal call timed out "
                      f"({self._macro_call_timeout}s) attempt {attempt}"
                      f"/{self._macro_call_attempts}")
                ex.shutdown(wait=False)  # leak the wedged thread, retry fresh
                continue
            except Exception as exc:  # noqa: BLE001
                print(f"[macro] proposal call failed attempt {attempt}: {exc}")
                ex.shutdown(wait=False)
                continue
            obj = _parse_json_obj(resp.text)
            if obj and isinstance(obj.get("conditions"), list):
                raw_conditions = obj["conditions"]
                salvaged = False
            else:
                # strict parse failed -> recover complete conditions from a
                # truncated array (dominant always-thinking failure).
                raw_conditions = _salvage_conditions(resp.text)
                salvaged = True
                print(f"[macro] strict parse failed "
                      f"(raw_len={len(resp.text or '')}, temp={macro_temp}); "
                      f"salvaged {len(raw_conditions)} complete conditions "
                      f"attempt {attempt}/{self._macro_call_attempts}")
                if not raw_conditions:
                    continue
            valid = []
            for raw in raw_conditions:
                if not isinstance(raw, dict):
                    continue
                c = MacroCondition.from_dict(raw)
                if validate_condition(c, self.dims.shared_keys):
                    continue
                valid.append(c)
            if len(valid) > len(best_valid):
                best_valid = valid
            # accept immediately on a clean parse (any count), or a salvage that
            # clears the coverage floor; otherwise keep the best and retry.
            if valid and (not salvaged or len(valid) >= salvage_floor):
                if salvaged:
                    print(f"[macro] using {len(valid)} salvaged valid conditions "
                          f"(floor {salvage_floor})")
                break
            if valid:
                print(f"[macro] salvaged only {len(valid)} < floor {salvage_floor} "
                      f"attempt {attempt}/{self._macro_call_attempts} -> retry")
            else:
                print(f"[macro] parsed but 0 valid conditions "
                      f"attempt {attempt}/{self._macro_call_attempts} -> retry")
        else:
            # loop exhausted without an accept -> fall back to the best attempt
            # (thin but real) rather than collapsing to None slots.
            valid = best_valid
            if valid:
                print(f"[macro] attempts exhausted; using best-seen "
                      f"{len(valid)} conditions (below floor {salvage_floor})")
        self.last_valid_conditions = valid
        if not valid:
            print("[macro] all proposal attempts exhausted -> None slots")
            return [None] * n
        return expand_by_budget(valid, n)
