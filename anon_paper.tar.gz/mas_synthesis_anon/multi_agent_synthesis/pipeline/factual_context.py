"""build_synthesis_context: the ONLY domain knowledge the v0 agents are allowed to see.

The v0 paradigm forbids white-box environment information. The Planner, Task
Synthesis, Feasibility, and Trajectory agents may only consume what a real
operator could obtain from the system surface:

  * tool schemas       : names, actor, read/write type, parameters, descriptions
  * db field surface   : table -> {fields, primary_key, mutable_fields, enums}
  * policy text         : the domain policy document (verbatim)

Explicitly EXCLUDED (per the v0 design decisions):
  * env assertion function names (assert_*). Retail/airline have none, telecom
    does -- to keep the seam uniform AND honor "no white-box", we never expose
    them. The deterministic DB-hash / replay reward is the hidden bar.
  * pinned skeletons, archetype tokens, gold actions, hidden ground-truth state.

This module reuses the generic introspection helpers from the v1 domain_card
(``introspect_db_schema``, ``_tool_specs``) -- those are mechanical env readers,
not v1 paradigm logic -- but builds its OWN tolerant card so it works for
domains without user_tools (airline/retail) where v1's telecom-shaped
``build_factual_card`` raises.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..domains.tau2.domain_card import _resolve_type, _tool_specs, render_param_schema


@dataclass
class SynthesisContext:
    """The obtainable-only domain surface fed to every v0 agent."""

    domain: str
    policy: str
    tools: Dict[str, Dict[str, Any]]  # name -> {actor, tool_type, parameters, description}
    tables: Dict[str, Dict[str, Any]]  # table -> {item_model, primary_key, fields, mutable_fields}
    enums: Dict[str, List[str]]

    # ---- prompt-facing renderings (compact strings the agents inject) -------
    def tool_schema_summary(self, include_args: bool = True) -> str:
        lines: List[str] = []
        for name in sorted(self.tools):
            spec = self.tools[name]
            actor = spec.get("actor", "assistant")
            ttype = spec.get("tool_type", "read")
            desc = (spec.get("description") or "").replace("\n", " ").strip()
            head = f"- [{actor}/{ttype}] {name}: {desc}"
            if include_args:
                # Prefer the full nested schema (object/enum structure); fall
                # back to bare top-level names when no schema was captured.
                psch = spec.get("param_schema")
                if psch:
                    rendered = render_param_schema(psch)
                    if rendered:
                        head += f"  (args: {rendered})"
                elif spec.get("parameters"):
                    head += f"  (args: {', '.join(spec['parameters'])})"
            lines.append(head)
        return "\n".join(lines)

    def database_summary(self) -> str:
        lines: List[str] = []
        for tname in sorted(self.tables):
            t = self.tables[tname]
            pk = t.get("primary_key")
            fields = t.get("fields") or {}
            field_str = ", ".join(f"{f}:{ty}" for f, ty in fields.items())
            lines.append(f"- {tname} (pk={pk}): {field_str}")
        if self.enums:
            lines.append("ENUMS:")
            for ename, vals in sorted(self.enums.items()):
                lines.append(f"  - {ename}: {vals}")
        return "\n".join(lines)

    def context_summary(self) -> str:
        """A short natural-language framing for the Planner's domain summary."""
        wtools = [n for n, s in self.tools.items() if s.get("tool_type") == "write"]
        rtools = [n for n, s in self.tools.items() if s.get("tool_type") == "read"]
        return (
            f"Domain '{self.domain}'. {len(self.tables)} entity tables, "
            f"{len(rtools)} read tools, {len(wtools)} write tools. "
            f"Tasks require genuine multi-step tool use against this environment."
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "tools": self.tools,
            "tables": self.tables,
            "enums": self.enums,
        }


# heuristic primary keys per table (the *_id field a record is keyed by).
_PK_HINT: Dict[str, str] = {
    "customers": "customer_id",
    "lines": "line_id",
    "bills": "bill_id",
    "devices": "device_id",
    "plans": "plan_id",
    "users": "user_id",
    "reservations": "reservation_id",
    "flights": "flight_number",
    "orders": "order_id",
    "products": "product_id",
}


def _introspect_tables(db) -> "tuple[Dict[str, Dict[str, Any]], Dict[str, List[str]]]":
    """Extract table field surfaces + enums from any tau2 DB pydantic model.

    Handles BOTH table shapes seen across domains:
      * array-of-$ref   (telecom: ``"items": {"$ref": ...}``)
      * dict-of-$ref    (airline/retail: ``"additionalProperties": {"$ref": ...}``)
    """
    schema = db.model_json_schema()
    defs = schema.get("$defs", {})

    enums: Dict[str, List[str]] = {
        name: list(d["enum"]) for name, d in defs.items() if "enum" in d
    }

    tables: Dict[str, Dict[str, Any]] = {}
    for table_name, finfo in (schema.get("properties") or {}).items():
        item_ref = (finfo.get("items") or {}).get("$ref")
        if not item_ref:
            ap = finfo.get("additionalProperties")
            if isinstance(ap, dict):
                item_ref = ap.get("$ref")
        if not item_ref:
            continue
        model = item_ref.split("/")[-1]
        props = defs.get(model, {}).get("properties", {})
        fields = {p: _resolve_type(pi) for p, pi in props.items()}
        pk = _PK_HINT.get(table_name)
        tables[table_name] = {
            "item_model": model,
            "primary_key": pk,
            "fields": fields,
            "mutable_fields": [f for f in fields if f != pk],
        }
    return tables, enums


def build_synthesis_context(adapter) -> SynthesisContext:
    """Build the obtainable-only domain surface for v0 from a live tau2 env.

    ``adapter`` is any Tau2*Adapter (gives ``make_environment``, ``domain``,
    ``load_policy``). Tolerant of domains without user_tools (airline/retail).
    """
    env = adapter.make_environment()
    db = env.tools.db
    tables, enums = _introspect_tables(db)

    # assistant tools (always present)
    assistant = _tool_specs(env.tools, env.get_tools(), "assistant")
    # user tools (telecom only); airline/retail have none.
    user: Dict[str, Any] = {}
    user_kit = getattr(env, "user_tools", None)
    if user_kit is not None:
        try:
            user_objs = env.get_user_tools() or []
        except (ValueError, AttributeError):
            user_objs = []
        if user_objs:
            user = _tool_specs(user_kit, user_objs, "user")

    tools: Dict[str, Dict[str, Any]] = {}
    for name, s in {**assistant, **user}.items():
        # Never expose assert_* (the hidden scoring bar) to v0 agents.
        if name.startswith("assert_"):
            continue
        tools[name] = {
            "actor": s.actor,
            "tool_type": s.tool_type,
            "parameters": s.parameters,
            "param_schema": s.param_schema,
            "description": s.description,
        }

    return SynthesisContext(
        domain=adapter.domain,
        policy=adapter.load_policy(),
        tools=tools,
        tables=tables,
        enums=enums,
    )
