"""ReplayVerifier: deterministic replay gate + LLM repair (DB-reward).

Stage 4 of the v0 pipeline -- the SOLE arbiter of correctness. It replays a
candidate's pseudo-GT actions against a fresh env via the adapter's deterministic
``replay_gt_actions`` (tau2 EnvironmentEvaluator, db-hash; NO LLM judge). If
reward < 1.0 and repair is enabled, it asks the LLM to PROPOSE a corrected
sequence (up to ``max_repair_attempts``), re-replaying each. A repair is accepted
only if it actually replays to reward==1.

This mirrors v1's TrajectoryVerifier but swaps the assertion-targeted repair
prompt for the DB-reward / in-place-write prompt (repair). The deterministic
replay core is reused verbatim through the adapter.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from ..llm.base import BaseLLMClient
from ..prompts.repair import REPAIR_PROMPT_VERSION, build_repair_prompt
from ..schemas import GTAction, TaskCandidate
from ..schemas.report_schema import TrajectoryVerificationReport


class ReplayVerifier:
    def __init__(
        self,
        adapter,
        llm: Optional[BaseLLMClient] = None,
        max_repair_attempts: int = 2,
        repair_max_tokens: int = 4000,
    ):
        self.adapter = adapter
        self.llm = llm
        self.max_repair_attempts = max_repair_attempts
        self.repair_max_tokens = repair_max_tokens

    # ------------------------------------------------------------------ public
    def verify(
        self, candidate: TaskCandidate, allow_repair: bool = True
    ) -> TrajectoryVerificationReport:
        report = TrajectoryVerificationReport()

        actions = list(candidate.effective_gt_actions())
        res = self.adapter.replay_gt_actions(candidate, actions)
        report.final_reward = float(res.get("final_reward", 0.0))
        report.replay_trajectory = res.get("replay_log", [])
        report.final_gt_actions = actions

        # Require reward==1.0, not just success. Some adapter/evaluator paths return
        # success=True while final_reward=0.0 (e.g. a GT `calculate` with an invalid
        # expression, or a payment-amount mismatch -- the "Error in golden actions"
        # warnings). Trusting success alone leaked a reward-0 task into accepted;
        # gating on reward==1 keeps the GT honest (the trajectory truly solves it).
        if res.get("success") and report.final_reward >= 1.0:
            report.passed = True
            return report

        report.failure_reasons = list(res.get("failure_reasons", []))

        # A refusal task is judged by action-absence (DB unchanged). The repair
        # prompt proposes WRITE sequences to reach reward==1, which is the wrong
        # objective here -- "fixing" a failed refusal would mean adding writes.
        # So never repair refusals: a failed refusal is a genuine reject.
        if candidate.blueprint.is_refusal():
            return report

        if not (allow_repair and self.llm is not None and self.max_repair_attempts > 0):
            return report

        for attempt in range(1, self.max_repair_attempts + 1):
            report.num_repair_attempts = attempt
            proposed = self._propose_repair(candidate, res)
            if not proposed:
                report.failure_reasons.append(f"repair attempt {attempt}: no actions parsed")
                continue
            res = self.adapter.replay_gt_actions(candidate, proposed)
            report.final_reward = float(res.get("final_reward", 0.0))
            report.replay_trajectory = res.get("replay_log", [])
            report.final_gt_actions = proposed
            if res.get("success") and report.final_reward >= 1.0:
                candidate.repaired_gt_actions = proposed
                report.passed = True
                report.repaired = True
                return report
            report.failure_reasons.append(
                f"repair attempt {attempt}: reward={report.final_reward}"
            )

        return report

    # ----------------------------------------------------------------- repair
    def _propose_repair(
        self, candidate: TaskCandidate, last_res: Dict[str, Any]
    ) -> List[GTAction]:
        assert self.llm is not None
        tools = self.adapter.load_tools()
        current = [
            {"actor": a.actor, "name": a.name, "arguments": a.arguments}
            for a in candidate.effective_gt_actions()
        ]
        hidden = candidate.generation_metadata.extra.get("hidden_task_spec") or {}
        system, user = build_repair_prompt(
            task_body=candidate.task,
            hidden_task_spec=hidden,
            current_actions=current,
            replay_log=last_res.get("replay_log", []),
            failure_reasons=last_res.get("failure_reasons", []),
            tools=tools,
        )
        resp = self.llm.complete_prompt(system, user, max_tokens=self.repair_max_tokens)
        return self._parse_actions(resp.text)

    @staticmethod
    def _parse_actions(text: str) -> List[GTAction]:
        text = (text or "").strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
        obj: Any = None
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            start, end = text.find("{"), text.rfind("}")
            if start != -1 and end > start:
                try:
                    obj = json.loads(text[start : end + 1])
                except json.JSONDecodeError:
                    return []
        if not isinstance(obj, dict):
            return []
        raw = obj.get("gt_actions") or []
        out: List[GTAction] = []
        for a in raw:
            if isinstance(a, dict) and a.get("name"):
                out.append(
                    GTAction(
                        actor=str(a.get("actor", "assistant")),
                        name=str(a["name"]),
                        arguments=dict(a.get("arguments") or {}),
                    )
                )
        return out

    @property
    def prompt_version(self) -> str:
        return REPAIR_PROMPT_VERSION
