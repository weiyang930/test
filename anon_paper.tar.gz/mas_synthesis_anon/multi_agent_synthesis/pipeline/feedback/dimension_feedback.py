"""Dimension-value-granularity feedback (spec §5). NO pairwise / joint keys.
Data feedback = synthetic distribution per (dimension, value). Performance
feedback = before/after-full-update success per (dimension, value) over the
held-out valid pool. Iterates only active dimensions; multi-value dims explode."""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List, Optional

from ..ontology.ontology_schema import Ontology


def _values_of(micro_plan: Dict[str, Any], dim: str) -> List[str]:
    raw = micro_plan.get(dim)
    if raw is None or raw == "":
        return []
    if isinstance(raw, (list, tuple)):
        return [str(x) for x in raw]
    return [str(raw)]


def _coverage_status(share: float, n_values: int,
                     under: float, over: float) -> str:
    if n_values <= 0:
        return "normal"
    uniform = 1.0 / n_values
    ratio = share / uniform if uniform else 0.0
    if ratio < under:
        return "undercovered"
    if ratio > over:
        return "overcovered"
    return "normal"


def _perf_status(before: float, after: float, valid_count: int) -> str:
    if valid_count < 10:
        return "insufficient_support"
    delta = after - before
    if after >= 0.8:
        return "mastered"
    if delta <= -0.05:
        return "regressed"
    if delta >= 0.05:
        return "weak_but_improving" if after < 0.6 else "improving"
    return "weak_and_stagnant"


def build_dimension_feedback(
    samples: List[Dict[str, Any]],
    valid_pool: List[Dict[str, Any]],
    eval_before: Optional[Dict[str, float]],
    eval_after: Optional[Dict[str, float]],
    ontology: Ontology,
    undercover_ratio: float = 0.5,
    over_ratio: float = 1.5,
) -> Dict[str, Any]:
    active = ontology.active_dimensions()
    n_round = len(samples) or 1
    n_cum = len(valid_pool) or 1

    data_feedback: List[Dict[str, Any]] = []
    for dim in active:
        round_counts: Dict[str, int] = defaultdict(int)
        cum_counts: Dict[str, int] = defaultdict(int)
        for s in samples:
            for v in _values_of(s.get("micro_plan", {}), dim.name):
                round_counts[v] += 1
        for s in valid_pool:
            for v in _values_of(s.get("micro_plan", {}), dim.name):
                cum_counts[v] += 1
        for v in dim.values:
            rc = round_counts.get(v, 0)
            cc = cum_counts.get(v, 0)
            share = rc / n_round
            data_feedback.append({
                "dimension": dim.name,
                "value": v,
                "round_count": rc,
                "round_ratio": round(share, 4),
                "cumulative_count": cc,
                "cumulative_ratio": round(cc / n_cum, 4),
                "coverage_status": _coverage_status(
                    share, len(dim.values), undercover_ratio, over_ratio),
            })

    performance_feedback: List[Dict[str, Any]] = []
    if eval_before is not None and eval_after is not None:
        for dim in active:
            bucket_before: Dict[str, List[float]] = defaultdict(list)
            bucket_after: Dict[str, List[float]] = defaultdict(list)
            for s in valid_pool:
                sid = s.get("sample_id")
                if sid not in eval_before or sid not in eval_after:
                    continue
                for v in _values_of(s.get("micro_plan", {}), dim.name):
                    bucket_before[v].append(float(eval_before[sid]))
                    bucket_after[v].append(float(eval_after[sid]))
            for v in dim.values:
                b = bucket_before.get(v, [])
                a = bucket_after.get(v, [])
                if not b:
                    continue
                br = sum(b) / len(b)
                ar = sum(a) / len(a)
                performance_feedback.append({
                    "dimension": dim.name,
                    "value": v,
                    "valid_count": len(b),
                    "before_success_rate": round(br, 4),
                    "after_success_rate": round(ar, 4),
                    "delta_success_rate": round(ar - br, 4),
                    "performance_status": _perf_status(br, ar, len(b)),
                })

    return {"data_feedback": data_feedback,
            "performance_feedback": performance_feedback}
