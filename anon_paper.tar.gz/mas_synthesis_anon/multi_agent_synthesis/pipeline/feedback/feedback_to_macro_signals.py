"""Bridge: dimension `feedback_report` -> macro `recommended_macro_signals`.

`build_dimension_feedback` (feedback/dimension_feedback.py) emits a per-(dimension,
value) report with a coverage_status and a performance_status. The MACRO planner
(prompts/macro_planner.py) consumes a DIFFERENT shape -- ``recommended_macro_signals``,
five priority buckets of key-refs (INVEST / SUPPLEMENT / SATURATED / PAUSE / EXPLORE).

Nothing connected the two: the reflector consumed feedback_report (to evolve the
ontology) but the macro planner never received the SAME performance/coverage signal,
so on an axis-promotion round the macro flew blind and fell back to the cold-start
balanced prior. This module is that missing bridge.

Mapping (one (dimension, value) -> at most one bucket; performance dominates
coverage because "the model is weak/regressed here" is a stronger steer than
"we sampled it a lot"):

  performance_status == "regressed"          -> zero_or_pause_keys  (PAUSE: diagnose, don't flood)
  performance_status == "weak_and_stagnant"  -> explore_keys        (EXPLORE: probe a new angle)
  performance_status == "mastered"           -> low_priority_keys   (SATURATED: stop investing)
  performance weak (weak_but_improving/improving/insufficient_support) AND undercovered
                                             -> high_priority_keys  (INVEST: weak AND thin)
  performance weak (as above) but not undercovered
                                             -> medium_priority_keys(SUPPLEMENT)
  no performance signal, coverage undercovered -> high_priority_keys(INVEST: thin, unknown perf)
  no performance signal, coverage overcovered  -> low_priority_keys (SATURATED)
  otherwise (normal/normal, no signal)         -> dropped

The output is exactly what ``format_feedback_signals`` / ``MacroPlanner(feedback=...)``
expect: {bucket_name: [ {key_type:'marginal', dimensions:[dim], values:[val]} ]}.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

_BUCKETS = (
    "high_priority_keys",
    "medium_priority_keys",
    "low_priority_keys",
    "zero_or_pause_keys",
    "explore_keys",
)

# performance_status values that mean "the model is still weak here" (as opposed
# to mastered/regressed/stagnant which have their own dedicated bucket).
_WEAK_PERF = {"weak_but_improving", "improving", "insufficient_support"}


def _marginal(dim: str, val: str) -> Dict[str, Any]:
    return {"key_type": "marginal", "dimensions": [dim], "values": [str(val)]}


def _classify(perf_status: Optional[str], cov_status: Optional[str]) -> Optional[str]:
    """One (dimension,value)'s (perf, coverage) status -> a bucket name (or None)."""
    # Performance signals dominate -- they are a stronger steer than raw volume.
    if perf_status == "regressed":
        return "zero_or_pause_keys"
    if perf_status == "weak_and_stagnant":
        return "explore_keys"
    if perf_status == "mastered":
        return "low_priority_keys"
    if perf_status in _WEAK_PERF:
        # Weak model here: invest if we're ALSO under-sampling it, else supplement.
        return "high_priority_keys" if cov_status == "undercovered" else "medium_priority_keys"
    # No usable performance signal -> fall back to coverage alone.
    if cov_status == "undercovered":
        return "high_priority_keys"
    if cov_status == "overcovered":
        return "low_priority_keys"
    return None


def feedback_report_to_macro_signals(
    feedback_report: Dict[str, Any],
) -> Dict[str, List[Dict[str, Any]]]:
    """Convert a ``build_dimension_feedback`` report into ``recommended_macro_signals``.

    ``feedback_report`` = {"data_feedback": [...], "performance_feedback": [...]}.
    Returns the 5-bucket dict (every bucket present, possibly empty) so a caller
    can treat an all-empty result as "no signal" (identical to cold start).
    """
    data = feedback_report.get("data_feedback") or []
    perf = feedback_report.get("performance_feedback") or []

    # index coverage + performance status by (dimension, value)
    cov_by_key: Dict[tuple, str] = {}
    for row in data:
        cov_by_key[(row.get("dimension"), str(row.get("value")))] = row.get("coverage_status")
    perf_by_key: Dict[tuple, str] = {}
    for row in perf:
        perf_by_key[(row.get("dimension"), str(row.get("value")))] = row.get("performance_status")

    signals: Dict[str, List[Dict[str, Any]]] = {b: [] for b in _BUCKETS}
    # union of all keys seen in either feedback stream
    for key in {*cov_by_key, *perf_by_key}:
        dim, val = key
        bucket = _classify(perf_by_key.get(key), cov_by_key.get(key))
        if bucket:
            signals[bucket].append(_marginal(dim, val))
    return signals
