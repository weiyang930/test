"""DimensionPlanner: the LLM-driven Planner Agent (dimension-value paradigm).

This is the MICRO planner: given a ``condition`` (a partial ``selected_dimensions``
dict supplied by the macro layer), it SELECTS the remaining dimension values from
the fixed, swappable dimension schema and emits one standard
:class:`TaskBlueprint`. Each plan is validated deterministically against the
schema's selection_rules + value lists -- a hallucinated value (or a tampered
fixed dimension) is rejected and retried, so a malformed plan never reaches the
rest of the pipeline.

Two properties make this RL-ready:

* **Stateless given its condition.** There is NO coverage history / previous-plans
  steering. A batch of calls under the SAME condition is a clean i.i.d. sampling
  group (diversity from temperature, coverage from the condition). This is exactly
  a GRPO group: same state -> N independent actions -> one advantage each.
* **Parallel.** ``plan`` fans the per-blueprint calls out through a runner in
  bounded batches, so 200 blueprints = 5 batches of 40 (concurrency itself is
  capped by the runner's ``max_workers``).

This module is v0-only; it does not import or touch the v1 planner.
"""

from __future__ import annotations

import json
import re
import uuid
from typing import Any, Dict, List, Optional

from ..dimensions.loader import DomainDimensions
from ..llm.base import BaseLLMClient
from .prompts.planner import PROMPT_VERSION, build_planner_prompt
from ..schemas import TaskBlueprint
from ..synthesis.runner import get_runner
from .factual_context import SynthesisContext


def _parse_json_obj(text: str) -> Optional[Dict[str, Any]]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            obj = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return obj if isinstance(obj, dict) else None


def _norm_single(raw: Any) -> str:
    if isinstance(raw, list):
        return str(raw[0]) if raw else ""
    return str(raw or "")


def _norm_list(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw]
    if isinstance(raw, list):
        return [str(x) for x in raw]
    return [str(raw)]


class DimensionPlanner:
    """LLM Planner Agent over a fixed dimension-value schema (micro layer)."""

    def __init__(
        self,
        domain: str,
        dims: DomainDimensions,
        context: SynthesisContext,
        llm: BaseLLMClient,
        max_tokens: int = 2000,
        max_attempts: int = 3,
        policy_chars: int = 6000,
    ):
        self.domain = domain
        self.dims = dims
        self.context = context
        self.llm = llm
        self.max_tokens = max_tokens
        self.max_attempts = max_attempts
        self.policy_chars = policy_chars

    # ------------------------------------------------------------------ public
    def plan(
        self,
        conditions: List[Optional[Dict[str, Any]]],
        runner_backend: str = "thread",
        max_workers: int = 8,
        batch_size: int = 40,
        task_timeout: Optional[float] = 180.0,
    ) -> List[TaskBlueprint]:
        """Generate one blueprint per entry in ``conditions`` (best-effort).

        ``conditions`` is a list of partial ``selected_dimensions`` dicts (or
        ``None`` for a fully-free plan); its length is the number of blueprints
        requested. The list is processed in ``batch_size`` chunks, each fanned out
        through the runner. A call that fails schema validation after
        ``max_attempts`` -- or that exceeds ``task_timeout`` (a wedged Bedrock
        call; see note below) -- is skipped, so the returned list may be shorter
        than ``conditions``; the caller logs the shortfall.

        Note: the bedrock client's fork+SIGKILL hard-timeout watchdog only fires on
        the MAIN thread. Here the calls run on runner worker threads, so they take
        the direct (un-watchdogged) path; ``task_timeout`` on the runner is what
        bounds a wedged SSL recv from stalling the whole batch (the timed-out plan
        is dropped; its worker thread leaks but the batch proceeds).
        """
        runner = get_runner(runner_backend, max_workers)
        out: List[TaskBlueprint] = []
        for start in range(0, len(conditions), max(1, batch_size)):
            chunk = conditions[start : start + max(1, batch_size)]
            work = [(start + j, cond) for j, cond in enumerate(chunk)]
            results: List[Optional[TaskBlueprint]] = runner.map(
                self._plan_one_item, work, task_timeout=task_timeout
            )
            out.extend(bp for bp in results if bp is not None)
        return out

    # ----------------------------------------------------------------- one plan
    def _plan_one_item(self, item) -> Optional[TaskBlueprint]:
        index, condition = item
        return self._plan_one(index=index, condition=condition)

    def _plan_one(
        self, index: int, condition: Optional[Dict[str, Any]] = None
    ) -> Optional[TaskBlueprint]:
        system, user = build_planner_prompt(
            domain=self.domain,
            context_summary=self.context.context_summary(),
            tool_schema_summary=self.context.tool_schema_summary(),
            database_summary=self.context.database_summary(),
            policy_summary=self.context.policy[: self.policy_chars],
            dimension_values_json=self.dims.to_planner_json(),
            condition=condition,
            selection_rules=self.dims.selection_rules,
        )
        for _attempt in range(1, self.max_attempts + 1):
            try:
                resp = self.llm.complete_prompt(
                    system, user, max_tokens=self.max_tokens, temperature=1.0
                )
            except Exception as exc:  # noqa: BLE001
                # Skip this plan rather than let one failed/wedged request crash
                # the batch. (The client already retried internally.)
                print(f"[planner] plan {index} attempt {_attempt} failed: {exc}")
                continue
            obj = _parse_json_obj(resp.text)
            if obj is None:
                continue
            sel = obj.get("selected_dimensions") or {}
            # A thinking backbone (Qwen3-*-Thinking-2507) reliably augments its
            # selection with generic task-design axes it carries as a prior
            # (policy_or_constraint_focus / tool_use_pattern / interaction_challenge)
            # even when THIS ontology's shared_keys does not list them. For
            # airline/retail those axes ARE in shared_keys, so nothing is dropped;
            # for telecom's re-cut O_0 (only 6 dims) they are "unknown" and would
            # otherwise trip validate_selection -> None -> family collapse. Drop
            # keys outside shared_keys before validating: this tolerates the prior
            # bleed-through without weakening the count/cross-rule gates or the real
            # arbiter (replay reward==1). _to_blueprint reads every canonical axis
            # via .get(), so a dropped-then-absent key defaults to empty -- exactly
            # right for telecom, and byte-for-byte unchanged for opus (which emits
            # only the ontology's keys) and for airline/retail.
            known = set(self.dims.shared_keys)
            dropped = [k for k in sel if k not in known]
            if dropped:
                sel = {k: v for k, v in sel.items() if k in known}
                obj["selected_dimensions"] = sel
                print(
                    f"[planner] plan {index}: dropped non-ontology keys "
                    f"{sorted(dropped)} (kept {sorted(sel)})"
                )
            problems = self.dims.validate_selection(sel)
            if problems:
                # tighten the next attempt with explicit feedback.
                user = user + (
                    f"\n\nYOUR PREVIOUS OUTPUT WAS INVALID:\n{problems}\n"
                    "Fix it and return corrected strict JSON."
                )
                continue
            return self._to_blueprint(obj, index)
        return None

    def _to_blueprint(self, plan: Dict[str, Any], index: int) -> TaskBlueprint:
        sel = plan.get("selected_dimensions") or {}
        # pipeline is SINGLE-INTENT: exactly one task_family. The dimension_plan
        # keeps task_family as a 1-element LIST; composition/entity_scope are pinned
        # to the validated single shape (the deprecated multi-intent axes are gone).
        # The blueprint's flat ``task_family`` field is the bare family name.
        families = _norm_list(sel.get("task_family"))[:1]
        composition = "single"
        entity_scope = "single_entity"
        family_id = "+".join(sorted(families)) if families else ""
        difficulty = _norm_single(sel.get("difficulty_profile")) or "easy"
        outcome = _norm_single(sel.get("expected_outcome")) or "fulfill"
        focus = _norm_list(sel.get("policy_or_constraint_focus"))
        patterns = _norm_list(sel.get("tool_use_pattern"))
        challenges = _norm_list(sel.get("interaction_challenge"))

        # normalize the stored plan so downstream cell/coverage is stable. v5
        # dropped the fail-set axes; the two keys are pinned to "none" so the
        # shared FeedbackSample / blueprint schema (which reads ALL_KEYS) stays
        # stable without ever sampling them.
        normalized = {
            "task_family": families,
            "task_composition": composition,
            "entity_scope": entity_scope,
            "expected_outcome": outcome,
            "policy_or_constraint_focus": focus,
            "tool_use_pattern": patterns,
            "interaction_challenge": challenges,
            "difficulty_profile": difficulty,
            "solution_search": "none",
            "answer_obligation": "none",
        }
        # Preserve any reflector-added axis (e.g. num_write) the planner emitted:
        # carry every selected key that isn't one of the fixed keys above, bounded
        # to that axis's selection_rules (single-value axes -> str, else list). This
        # is what lets a promoted ontology dimension actually reach the blueprint /
        # feedback instead of being silently dropped by a fixed schema.
        for key, raw in sel.items():
            if key in normalized:
                continue
            lo, hi = self.dims.selection_bounds(key)
            if hi <= 1:
                normalized[key] = _norm_single(raw)
            else:
                normalized[key] = _norm_list(raw)[:hi]
        plan["selected_dimensions"] = normalized
        controls = self.dims.difficulty_controls(difficulty)
        # A pure refusal never mutates state, so the fulfill-path knob is forced
        # off regardless of difficulty. A "mixed" task DOES write (its compliant
        # part), so it keeps requires_state_change as-is.
        if outcome == "refuse":
            controls = {**controls, "requires_state_change": False}
        plan.setdefault("expected_difficulty_controls", controls)

        bp_id = f"v0_{self.domain}_{index:04d}_{uuid.uuid4().hex[:6]}"
        # target_skill_pattern: a compact, deterministic summary used by legacy
        # coverage hooks (the real coverage axis is dimension_plan).
        skill = "+".join(patterns) or "tool_use"
        return TaskBlueprint(
            blueprint_id=bp_id,
            domain=self.domain,
            task_family=family_id,
            target_skill_pattern=skill,
            difficulty_level=difficulty,
            generation_intent=str(plan.get("generation_intent") or ""),
            dimension_plan=plan,
        )

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION
