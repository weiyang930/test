"""TaskSynthesisAgent: dimension_plan -> concrete TaskCandidate (real entities).

Stage 2 of the v0 pipeline. For each validated :class:`TaskBlueprint` (carrying
a ``dimension_plan``) it:

  1. samples REAL entities from the live DB (so the agent binds concrete ids,
     never invents them);
  2. renders the synthesis prompt (plan + obtainable surface + entity sample +
     a domain determinism note);
  3. calls the LLM;
  4. parses the strict-JSON output into a tau2-shaped :class:`TaskCandidate`,
     folding the candidate pseudo-GT actions into evaluation_criteria.

The pseudo-GT here is a DRAFT only -- the downstream deterministic replay gate
is the sole arbiter of correctness. The agent never sees scoring internals.

Airline grounding: tasks run on the STOCK db (no fault injection), so
``initial_state`` carries no initialization_actions; the gt is one or more
in-place writes against an EXISTING reservation, and reward_basis is ["DB"].
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from ..llm.base import BaseLLMClient
from .prompts.synthesis import (
    PROMPT_VERSION,
    _AIRLINE_DETERMINISM,
    build_synthesis_prompt,
)
from ..schemas import GenerationMetadata, GTAction, TaskBlueprint, TaskCandidate
from .entity_sampler import sample_entities
from .factual_context import SynthesisContext

# Per-domain determinism guidance injected into the synthesis prompt. v5 uses the
# validated v3 PURE-DB generator, which permits deterministic booking + multi-write
# chains + the computation semantic axis (env mints reservation ids from a fixed
# pool, so DB-hash stays reproducible). This is what lets the generator realize a
# promoted `computation` axis, which the bare v0 single-write prompt could not.
_DETERMINISM_NOTES_DB: Dict[str, str] = {"airline": _AIRLINE_DETERMINISM}


def _parse_json_obj(text: str) -> Optional[Dict[str, Any]]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            obj = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return obj if isinstance(obj, dict) else None


def _stringify(value: Any) -> str:
    """Fold a stray dict/list into readable prose (tau2 prose fields are str)."""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return "; ".join(f"{k.replace('_', ' ')}: {_stringify(v)}" for k, v in value.items())
    if isinstance(value, list):
        return "; ".join(_stringify(v) for v in value)
    return str(value)


class SynthesisError(Exception):
    """Raised when the synthesis LLM response cannot be parsed."""


class TaskSynthesisAgent:
    """LLM agent that instantiates one dimension_plan into one TaskCandidate."""

    def __init__(
        self,
        adapter,
        context: SynthesisContext,
        llm: BaseLLMClient,
        max_tokens: int = 6000,
        entity_sample_size: int = 4,
        policy_chars: int = 12000,
        parse_retries: int = 3,
    ):
        self.adapter = adapter
        self.context = context
        self.llm = llm
        self.max_tokens = max_tokens
        self.entity_sample_size = entity_sample_size
        self.policy_chars = policy_chars
        # A multi-write (3-4/5+) task yields a long, complex JSON; at temp=1.0 the
        # generator occasionally emits stray prose or a malformed object even when
        # it CAN produce a valid one (verified: a rejected 3-4 blueprint re-run
        # once parses fine). One-shot parsing therefore silently drops recoverable
        # high-write candidates. Retry a few times before giving up.
        self.parse_retries = parse_retries

    # ------------------------------------------------------------------ public
    def synthesize(
        self, blueprint: TaskBlueprint, candidate_index: int
    ) -> Optional[TaskCandidate]:
        """Instantiate one task. Returns None if the LLM output is unparseable."""
        plan = blueprint.dimension_plan or {}
        seed = f"{blueprint.blueprint_id}:{candidate_index}"
        entities = sample_entities(
            self.adapter, self.context.domain, seed, self.entity_sample_size
        )
        system, user = build_synthesis_prompt(
            domain=self.context.domain,
            plan=plan,
            tool_schema_summary=self.context.tool_schema_summary(),
            database_summary=self.context.database_summary(),
            policy_text=self.context.policy[: self.policy_chars],
            entity_sample=entities,
            determinism_note=_DETERMINISM_NOTES_DB.get(self.context.domain, ""),
        )
        parsed = None
        model = ""
        for _ in range(max(1, self.parse_retries)):
            resp = self.llm.complete_prompt(
                system, user, max_tokens=self.max_tokens, temperature=1.0
            )
            model = resp.model
            parsed = _parse_json_obj(resp.text)
            if parsed is not None:
                break
        if parsed is None:
            return None
        return self._to_candidate(
            blueprint, parsed, candidate_index, model, entities
        )

    def synthesize_many(
        self, blueprints: List[TaskBlueprint], start_index: int = 0
    ) -> List[TaskCandidate]:
        out: List[TaskCandidate] = []
        for i, bp in enumerate(blueprints):
            cand = self.synthesize(bp, start_index + i)
            if cand is not None:
                out.append(cand)
        return out

    # ----------------------------------------------------------------- parsing
    def _to_candidate(
        self,
        blueprint: TaskBlueprint,
        parsed: Dict[str, Any],
        candidate_index: int,
        model: str,
        entities: List[Dict[str, Any]],
    ) -> TaskCandidate:
        candidate_id = f"candidate_{candidate_index:06d}"
        task_id = str(parsed.get("task_id") or
                      f"{blueprint.domain}_{blueprint.task_family}_{candidate_index:06d}")

        gt_actions = self._parse_gt_actions(parsed)
        parsed = {**parsed}
        sol = dict(parsed.get("candidate_solution_plan") or {})
        # Route by DATA SHAPE, not domain name: a task that AUTHORED a fault
        # script (non-empty initialization_actions) + env_assertions is a telecom
        # ENV_ASSERTION/ACTION task and must keep that basis + those fields. Every
        # airline/retail task has empty authoring fields -> the historical
        # DB/COMMUNICATE path runs byte-for-byte unchanged.
        if self._is_authored_fault_task(parsed):
            declared = sol.get("reward_basis")
            if isinstance(declared, list):
                kept = [b for b in declared
                        if b in ("DB", "COMMUNICATE", "ENV_ASSERTION", "ACTION")]
                sol["reward_basis"] = kept or ["ENV_ASSERTION"]
            else:
                sol["reward_basis"] = ["ENV_ASSERTION"]
        else:
            # v5 discovery path (airline/retail) is DB-hash single-write only: drop
            # any compare_args and strip ACTION/ENV_ASSERTION from the declared
            # basis (keeping COMMUNICATE for report tasks). _install_evaluation_
            # criteria then resolves to ["DB"] (+ COMMUNICATE if present).
            for a in gt_actions:
                a.compare_args = None
            declared = sol.get("reward_basis")
            if isinstance(declared, list):
                kept = [b for b in declared if b in ("DB", "COMMUNICATE")]
                sol["reward_basis"] = kept or ["DB"]
            else:
                sol.pop("reward_basis", None)
        parsed["candidate_solution_plan"] = sol
        task_body = self._build_task_body(parsed, task_id, gt_actions)

        hidden = parsed.get("hidden_task_spec") or {}
        solution = parsed.get("candidate_solution_plan") or {}
        quality = parsed.get("task_quality_notes") or {}

        return TaskCandidate(
            candidate_id=candidate_id,
            task_id=task_id,
            blueprint=blueprint,
            task=task_body,
            gt_actions=gt_actions,
            expected_final_state=dict(solution.get("expected_final_state") or {}),
            expected_solution_outline=[
                _stringify(s) for s in (solution.get("high_level_steps") or [])
            ],
            skill_necessity_rationale=_stringify(quality.get("why_requires_tool_use") or ""),
            generation_metadata=GenerationMetadata(
                generator_model=model,
                prompt_version=PROMPT_VERSION,
                extra={
                    "blueprint_id": blueprint.blueprint_id,
                    "source_plan_id": str(parsed.get("source_plan_id") or ""),
                    "hidden_task_spec": hidden,
                    "candidate_pseudo_gt": solution.get("candidate_pseudo_gt_actions") or [],
                    "task_quality_notes": quality,
                    "entity_sample": entities,
                },
            ),
        )

    @staticmethod
    def _authored_init_actions(parsed: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Fault-injection script the generator authored (telecom). Accepts it at
        the top level or nested under initial_state; [] for airline/retail."""
        ia = parsed.get("initialization_actions")
        if not ia:
            ia = (parsed.get("initial_state") or {}).get("initialization_actions")
        return [a for a in (ia or []) if isinstance(a, dict) and a.get("func_name")]

    @staticmethod
    def _authored_env_assertions(parsed: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Success-bar assertions the generator authored (telecom). Accepts top
        level or nested under evaluation_criteria; [] for airline/retail."""
        ea = parsed.get("env_assertions")
        if not ea:
            ea = (parsed.get("evaluation_criteria") or {}).get("env_assertions")
        return [a for a in (ea or []) if isinstance(a, dict) and a.get("func_name")]

    @classmethod
    def _is_authored_fault_task(cls, parsed: Dict[str, Any]) -> bool:
        """A telecom-style authoring task = it scripted a fault AND declared the
        symptom-cleared assertion. Detected purely by data shape (never by domain
        name), so airline/retail (empty authoring fields) always route to the
        untouched discovery path."""
        return bool(cls._authored_init_actions(parsed)) and bool(
            cls._authored_env_assertions(parsed)
        )

    @staticmethod
    def _parse_gt_actions(parsed: Dict[str, Any]) -> List[GTAction]:
        solution = parsed.get("candidate_solution_plan") or {}
        raw = solution.get("candidate_pseudo_gt_actions") or []
        out: List[GTAction] = []
        for a in raw:
            if not isinstance(a, dict) or not a.get("tool_name"):
                continue
            ca = a.get("compare_args")
            out.append(
                GTAction(
                    actor=str(a.get("actor", "assistant")),
                    name=str(a["tool_name"]),
                    arguments=dict(a.get("arguments") or {}),
                    compare_args=[str(x) for x in ca] if isinstance(ca, list) else None,
                )
            )
        return out

    # tau2 reward modes we let the generator pick from (see synthesis_base JUDGING MODE).
    _VALID_REWARD_BASIS = {"DB", "ACTION", "ENV_ASSERTION", "NL_ASSERTION", "COMMUNICATE"}

    @classmethod
    def _resolve_reward_basis(
        cls, parsed: Dict[str, Any], gt_actions: List[GTAction]
    ) -> List[str]:
        """Honor the generator's declared reward_basis when valid; otherwise infer.

        Inference rule: a task is ACTION-judged iff any GT action declares
        compare_args (the generator sets compare_args exactly when an arg -- e.g. a
        freshly-minted reservation_id -- must be excluded from the match). With no
        compare_args anywhere we keep the historical DB-hash default.
        """
        solution = parsed.get("candidate_solution_plan") or {}
        raw = solution.get("reward_basis")
        if isinstance(raw, list) and raw and all(x in cls._VALID_REWARD_BASIS for x in raw):
            return [str(x) for x in raw]
        # Telecom authoring task with no explicit basis -> ENV_ASSERTION (the
        # symptom-cleared bar it authored). Empty for airline/retail.
        if cls._authored_env_assertions(parsed):
            return ["ENV_ASSERTION"]
        if any(a.compare_args is not None for a in gt_actions):
            return ["ACTION"]
        return ["DB"]

    def _build_task_body(
        self,
        parsed: Dict[str, Any],
        task_id: str,
        gt_actions: List[GTAction],
    ) -> Dict[str, Any]:
        """Assemble the canonical tau2 task body (DB-reward, no fault injection)."""
        hidden = parsed.get("hidden_task_spec") or {}
        solution = parsed.get("candidate_solution_plan") or {}
        user_instruction = _stringify(parsed.get("user_instruction") or "")
        scenario = _stringify(hidden.get("scenario_context") or "")
        private = hidden.get("user_private_info") or {}

        instructions = {
            "domain": self.context.domain,
            "reason_for_call": user_instruction,
            "known_info": _stringify(private) if private else "",
            "task_instructions": _stringify(
                solution.get("expected_user_visible_resolution") or user_instruction
            ),
        }
        # Airline/retail DB-reward tasks run on the stock db (no fault inject ->
        # empty init). A telecom authoring task carries its fault script here; the
        # env replays it at task start to break the device before the agent acts.
        init_actions = self._authored_init_actions(parsed)
        task_body: Dict[str, Any] = {
            "id": task_id,
            "description": {"purpose": scenario or user_instruction},
            "user_scenario": {"instructions": instructions},
            "ticket": user_instruction,
            "initial_state": {
                "initialization_data": None,
                "initialization_actions": init_actions,
            },
        }
        self._install_evaluation_criteria(task_body, gt_actions, parsed=parsed)
        return task_body

    @classmethod
    def _install_evaluation_criteria(
        cls,
        task_body: Dict[str, Any],
        gt_actions: List[GTAction],
        parsed: Optional[Dict[str, Any]] = None,
    ) -> None:
        ec: Dict[str, Any] = dict(task_body.get("evaluation_criteria") or {})
        if gt_actions and not ec.get("actions"):
            ec["actions"] = [cls._action_dict(a, i) for i, a in enumerate(gt_actions)]
        # Telecom authoring tasks carry the symptom-cleared bar as env_assertions;
        # install them (verbatim from the generator's catalog copy) so the tau2
        # ENV_ASSERTION evaluator can score "did the fault clear". Empty for
        # airline/retail, so this is a no-op there.
        env_assertions = cls._authored_env_assertions(parsed or {})
        if env_assertions and not ec.get("env_assertions"):
            ec["env_assertions"] = env_assertions
        # answer_obligation=exact_value tasks: the generator emits communicate_info
        # (the exact figure(s) the agent must state back). Carry it onto the task
        # and add COMMUNICATE to the basis so reward = DB x COMMUNICATE -- the
        # rollout reward==1 filter then keeps only trajectories that report it right.
        solution = (parsed or {}).get("candidate_solution_plan") or {}
        comm = (parsed or {}).get("communicate_info") or solution.get("communicate_info")
        if comm and not ec.get("communicate_info"):
            ec["communicate_info"] = [str(x) for x in comm] if isinstance(comm, list) else [str(comm)]
        if not ec.get("reward_basis"):
            basis = cls._resolve_reward_basis(parsed or {}, gt_actions)
            if ec.get("communicate_info") and "COMMUNICATE" not in basis:
                basis = basis + ["COMMUNICATE"]
            ec["reward_basis"] = basis
        task_body["evaluation_criteria"] = ec

    @staticmethod
    def _action_dict(a: GTAction, i: int) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "action_id": f"{a.name}_{i}",
            "requestor": a.actor,
            "name": a.name,
            "arguments": dict(a.arguments),
        }
        # Only emit compare_args for ACTION-basis actions (None => tau2 compares all
        # args, the DB-basis default). An explicit [] means "any call to this tool".
        if a.compare_args is not None:
            d["compare_args"] = list(a.compare_args)
        return d

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION
