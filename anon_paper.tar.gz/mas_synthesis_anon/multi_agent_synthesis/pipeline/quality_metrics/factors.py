"""Deterministic extraction of OBSERVED factors + abstract trajectories.

Everything here is computed from the verified task's ground-truth actions (the
`actions` the environment checked to award reward==1) plus tool classification.
Nothing is read from the planner's `dimension_plan` / blueprint — planned
metadata is kept only for diagnostics elsewhere (evaluate.py), never for scoring.

Two public entry points:
    extract_observed_factors(sample, adapter) -> dict of categorical factors
    abstract_trajectory(sample)               -> (raw_pattern, collapsed_pattern)
"""
from __future__ import annotations

from typing import Any, Dict, List, Tuple

from .tool_ontology import classify_tool, write_bucket, iter_actions

# Entity-id argument keys across all four domains. Used to tell a multi-field
# change (>=2 writes on ONE entity) from a multi-entity change (touching >=2).
_ENTITY_ID_KEYS = (
    "reservation_id", "user_id", "order_id", "product_id", "flight_number",
    "customer_id", "phone_number", "line_id", "bill_id", "account_id",
)
# argument keys that signal exact arithmetic was required (fee/refund/amount...)
_MONEY_KEYS = ("amount", "refund", "fee", "payment_methods", "total", "price")


def _requires_computation(acts: List[Dict[str, Any]], n_compute: int) -> bool:
    """Action-derived only (no planned metadata): an explicit compute tool, or a
    write whose args carry money/split-payment fields (exact-arithmetic tasks)."""
    if n_compute > 0:
        return True
    for a in acts:
        args = a.get("arguments") or {}
        pm = args.get("payment_methods")
        if isinstance(pm, list) and len(pm) >= 2:
            return True
        if any(k in args for k in _MONEY_KEYS):
            return True
    return False


def _has_env_assertion(sample: Dict[str, Any]) -> bool:
    """True if the verifier's reward basis is an environment-state assertion
    (telecom's ENV_ASSERTION) or the task carries explicit assertion criteria."""
    prov = sample.get("provenance") or {}
    ec = (sample.get("task") or {}).get("evaluation_criteria") or {}
    # reward_basis lives under task.evaluation_criteria (telecom = ENV_ASSERTION)
    rb = str(ec.get("reward_basis") or sample.get("reward_basis")
             or prov.get("reward_basis") or "").upper()
    if "ASSERTION" in rb:
        return True
    for k in ("env_assertions", "nl_assertions", "assertions"):
        v = ec.get(k)
        if isinstance(v, list) and v:
            return True
    return False


def _entities_touched(acts: List[Dict[str, Any]]) -> int:
    ents = set()
    for a in acts:
        args = a.get("arguments") or {}
        for k in _ENTITY_ID_KEYS:
            v = args.get(k)
            if isinstance(v, (str, int)):
                ents.add(f"{k}={v}")
    return len(ents)


def raw_features(sample: Dict[str, Any]) -> Dict[str, Any]:
    """Low-level counts every factor/complexity derivation builds on."""
    acts = iter_actions(sample)
    cats = [classify_tool(a["name"]) for a in acts]
    n_write = cats.count("WRITE")
    n_read = cats.count("READ")
    n_compute = cats.count("COMPUTE")
    n_transfer = cats.count("TRANSFER")
    return {
        "actions": acts,
        "categories": cats,
        "n_tool_calls": len(acts),
        "n_distinct_tools": len({a["name"] for a in acts}),
        "n_write": n_write,
        "n_read": n_read,
        "n_compute": n_compute,
        "n_transfer": n_transfer,
        "n_entities": _entities_touched(acts),
        "requires_computation": _requires_computation(acts, n_compute),
        "has_env_assertion": _has_env_assertion(sample),
    }


# ---------------------------------------------------------------------------
# categorical factor derivations (all deterministic from raw_features)
# ---------------------------------------------------------------------------
def _tool_pattern(f: Dict[str, Any]) -> str:
    nw, nr, nc = f["n_write"], f["n_read"], f["n_compute"]
    if nc > 0 and nw > 0:
        return "read_compute_write"
    if nw >= 2:
        return "multi_write"
    if nw == 1 and nr > 0:
        return "read_write"
    if nw == 1:
        return "single_write"
    return "read_only"  # includes the degenerate 0-action / read+compute-only case


def _expected_outcome(f: Dict[str, Any]) -> str:
    if f["n_write"] == 0:
        return "policy_denial" if f["n_transfer"] > 0 else "information_only"
    return "state_update"


def _state_change_type(f: Dict[str, Any]) -> str:
    if f["n_write"] == 0:
        return "no_change"
    if f["n_entities"] >= 2:
        return "multi_entity_change"
    if f["n_write"] >= 2:
        return "multi_field_change"
    return "single_field_change"


def _computation(f: Dict[str, Any]) -> str:
    if f["n_compute"] >= 2:
        return "multi_step"
    if f["n_compute"] == 1 or f["requires_computation"]:
        return "simple"
    return "none"


def _policy_constraint(f: Dict[str, Any]) -> str:
    # coarse OBSERVED proxy: escalation or an environment-assertion reward basis
    # indicates the task exercised a policy/eligibility gate. Fine-grained policy
    # names would need the domain wiki / an LLM judge, which we deliberately avoid.
    return "policy_gated" if (f["n_transfer"] > 0 or f["has_env_assertion"]) else "none"


def extract_observed_factors(sample: Dict[str, Any], adapter) -> Dict[str, str]:
    """Return the 8 categorical observed factors for one verified sample.

    Any factor that cannot be determined for a sample is set to "unknown" and is
    excluded from coverage/balance (it never matches a reference value)."""
    f = raw_features(sample)
    return {
        "task_family": adapter.derive_task_family(f, sample) or "unknown",
        "tool_pattern": _tool_pattern(f),
        "expected_outcome": _expected_outcome(f),
        "state_change_type": _state_change_type(f),
        "computation": _computation(f),
        "num_write_actions": write_bucket(f["n_write"]),
        "num_read_actions": write_bucket(f["n_read"]),
        "policy_constraint": _policy_constraint(f),
    }


def extract_complexity_bins(sample: Dict[str, Any]) -> Dict[str, str]:
    """Structural-complexity bins for Complexity Coverage. A dimension whose bin
    is not defined for this sample (e.g. state_scope on a no-write task) is
    omitted, so it simply does not contribute a represented bin."""
    f = raw_features(sample)
    out: Dict[str, str] = {}

    n = f["n_tool_calls"]
    out["trajectory_length"] = "short" if n <= 2 else ("medium" if n <= 5 else "long")
    out["tool_breadth"] = "single_tool" if f["n_distinct_tools"] <= 1 else "multi_tool"

    if f["n_write"] == 0:
        out["state_change"] = "no_write"
    elif f["n_write"] == 1:
        out["state_change"] = "single_write"
    else:
        out["state_change"] = "multi_write"

    # state_scope only defined for state-changing tasks
    sct = _state_change_type(f)
    scope = {
        "single_field_change": "single_field",
        "multi_field_change": "multi_field",
        "multi_entity_change": "multi_entity",
    }.get(sct)
    if scope:
        out["state_scope"] = scope

    # reasoning_requirement: single label by priority
    if f["requires_computation"] or f["n_compute"] > 0:
        out["reasoning_requirement"] = "computation_required"
    elif f["n_transfer"] > 0 or f["has_env_assertion"]:
        out["reasoning_requirement"] = "policy_constrained"
    elif f["n_read"] > 0 and f["n_write"] > 0:
        out["reasoning_requirement"] = "state_dependent"
    else:
        out["reasoning_requirement"] = "direct"
    return out


# ---------------------------------------------------------------------------
# trajectory abstraction
# ---------------------------------------------------------------------------
_CAT_SYMBOL = {"READ": "R", "WRITE": "W", "COMPUTE": "C", "TRANSFER": "T"}


def abstract_trajectory(sample: Dict[str, Any]) -> Tuple[str, str]:
    """Map GT actions -> an abstract execution pattern over {R,W,C,T} + trailing F.

    Returns (raw_pattern, collapsed_pattern):
      raw       -> one symbol per action, in order, then 'F' (final response)
      collapsed -> consecutive duplicate symbols merged (shape, not length)
    Symbols are '-'-joined so patterns are hashable/printable. 'OTHER'-category
    tools are dropped from the shape (they carry no functional meaning here).
    VERIFY is not derivable from GT actions (assertions are evaluator-side), so
    it never appears — noted for parity with the spec's alphabet.
    """
    acts = iter_actions(sample)
    syms = [_CAT_SYMBOL[c] for c in
            (classify_tool(a["name"]) for a in acts) if c in _CAT_SYMBOL]
    raw = syms + ["F"]
    collapsed: List[str] = []
    for s in raw:
        if not collapsed or collapsed[-1] != s:
            collapsed.append(s)
    return "-".join(raw), "-".join(collapsed)


__all__ = [
    "extract_observed_factors",
    "extract_complexity_bins",
    "abstract_trajectory",
    "raw_features",
]
