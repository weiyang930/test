"""Domain-agnostic tool classification for the quality-metrics engine.

Every ground-truth action in a verified task calls a tool. We map each tool to a
functional CATEGORY so that downstream factor/pattern extraction is uniform
across all four domains:

    WRITE     -> mutates environment/database state (state-changing action)
    READ      -> queries state, no mutation
    COMPUTE   -> deterministic calculation helper (no state change, no DB read)
    TRANSFER  -> escalation / hand-off to a human agent (terminal, no DB write)
    OTHER     -> uncategorized (should be rare; logged for ontology growth)

We REUSE probe_extractor's frozensets (airline/retail/car write/read + compute)
so num_write buckets stay identical to the Reflector's ontology, and EXTEND them
with telecom (which probe_extractor lacks). An explicit-set lookup runs first; a
conservative name-prefix fallback catches any tool not yet enumerated, so the
classifier degrades gracefully instead of silently dropping actions.
"""
from __future__ import annotations

# --- reuse probe_extractor's canonical sets (keeps num_write aligned w/ ontology) ---
from ..probes.probe_extractor import (
    AIRLINE_WRITE_TOOLS,
    AIRLINE_READ_TOOLS,
    RETAIL_WRITE_TOOLS,
    RETAIL_READ_TOOLS,
    CAR_WRITE_TOOLS,
    CAR_READ_TOOLS,
    COMPUTATION_TOOLS,
    write_bucket,   # re-exported for factors.py (identical bucketing to ontology)
    iter_actions,   # re-exported: normalized GT-action iterator
)

# --- telecom (absent from probe_extractor). agent-side + user-device tools. ---
# agent tools (requestor="assistant") that mutate account/line state
TELECOM_AGENT_WRITE = frozenset({
    "suspend_line", "resume_line", "send_payment_request",
    "enable_roaming", "disable_roaming", "refuel_data",
})
# user-device tools (requestor="user") — the sim executes them on the handset;
# they change device/network state, so they count as WRITE (state-changing).
TELECOM_USER_WRITE = frozenset({
    "set_network_mode_preference", "toggle_airplane_mode", "reseat_sim_card",
    "toggle_data", "toggle_roaming", "toggle_data_saver_mode",
    "set_apn_settings", "reset_apn_settings", "toggle_wifi", "toggle_wifi_calling",
    "connect_vpn", "disconnect_vpn", "grant_app_permission", "reboot_device",
    "make_payment",
})
TELECOM_WRITE_TOOLS = TELECOM_AGENT_WRITE | TELECOM_USER_WRITE
TELECOM_READ_TOOLS = frozenset({
    # agent read tools
    "get_customer_by_phone", "get_customer_by_id", "get_customer_by_name",
    "get_details_by_id", "get_bills_for_customer", "get_data_usage",
    # user-device diagnostics (read-only status checks)
    "check_status_bar", "check_network_status", "run_speed_test", "check_sim_status",
    "check_apn_settings", "can_send_mms", "check_wifi_status", "check_vpn_status",
    "check_app_status",
})

# --- escalation / hand-off (all tau2 domains). NOT a DB write. ---
TRANSFER_TOOLS = frozenset({"transfer_to_human_agents"})

# --- unions across every supported domain ---
WRITE_TOOLS = AIRLINE_WRITE_TOOLS | RETAIL_WRITE_TOOLS | CAR_WRITE_TOOLS | TELECOM_WRITE_TOOLS
READ_TOOLS = AIRLINE_READ_TOOLS | RETAIL_READ_TOOLS | CAR_READ_TOOLS | TELECOM_READ_TOOLS

# per-domain views (used by adapters to derive task_family from observed tools)
DOMAIN_WRITE = {
    "airline": AIRLINE_WRITE_TOOLS,
    "retail": RETAIL_WRITE_TOOLS,
    "telecom": TELECOM_WRITE_TOOLS,
    "car": CAR_WRITE_TOOLS,
}
DOMAIN_READ = {
    "airline": AIRLINE_READ_TOOLS,
    "retail": RETAIL_READ_TOOLS,
    "telecom": TELECOM_READ_TOOLS,
    "car": CAR_READ_TOOLS,
}

# name-prefix fallback for tools not yet enumerated (conservative, transparent).
_WRITE_PREFIXES = (
    "set_", "open_close_", "toggle_", "reset_", "reseat_", "reboot_",
    "connect_", "disconnect_", "grant_", "enable_", "disable_", "suspend_",
    "resume_", "refuel_", "book_", "cancel_", "update_", "modify_", "return_",
    "exchange_", "send_", "make_", "start_", "stop_", "add_", "delete_",
    "navigation_", "replace_",
)
_READ_PREFIXES = ("get_", "search_", "find_", "list_", "check_", "run_", "can_", "lookup_")
_COMPUTE_PREFIXES = ("calculate", "convert_", "compute_")


def classify_tool(name: str) -> str:
    """Map a tool name to WRITE | READ | COMPUTE | TRANSFER | OTHER.

    Explicit sets win first (so telecom user-tools and any ambiguous names are
    pinned), then a conservative prefix fallback, else OTHER.
    """
    if not name:
        return "OTHER"
    if name in TRANSFER_TOOLS:
        return "TRANSFER"
    if name in COMPUTATION_TOOLS:
        return "COMPUTE"
    if name in WRITE_TOOLS:
        return "WRITE"
    if name in READ_TOOLS:
        return "READ"
    # ---- prefix fallback (never silently drop an unseen tool) ----
    if name.startswith(_COMPUTE_PREFIXES):
        return "COMPUTE"
    if name.startswith(_READ_PREFIXES):
        return "READ"
    if name.startswith(_WRITE_PREFIXES):
        return "WRITE"
    return "OTHER"


__all__ = [
    "classify_tool",
    "write_bucket",
    "iter_actions",
    "WRITE_TOOLS",
    "READ_TOOLS",
    "COMPUTATION_TOOLS",
    "TRANSFER_TOOLS",
    "TELECOM_WRITE_TOOLS",
    "TELECOM_READ_TOOLS",
    "DOMAIN_WRITE",
    "DOMAIN_READ",
]
