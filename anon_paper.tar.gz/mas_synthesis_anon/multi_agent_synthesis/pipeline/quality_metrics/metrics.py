"""The five intrinsic quality metrics — pure, deterministic functions.

All return values in [0, 1]. Each function returns a dict with an `overall`
scalar plus a per-component breakdown for diagnostics. Reference spaces are
passed in (fixed union spaces from adapters.py) so results are comparable across
rounds. Entropy uses natural log; the normalizer cancels the base.

Conventions:
  * Each factor is single-valued per sample. A value of "unknown" — or any
    observed value NOT in the reference set (a "novel" value) — is excluded from
    coverage and balance (it matches no reference value). Novel values are
    reported separately by evaluate.py as a signal to grow the space.
  * Factor Balance is DESCRIPTIVE: 1.0 = uniform over the full reference set,
    0.0 = a single value. Higher = more even, which is only "better" if a
    uniform target is assumed. The other four: higher = broader / richer.
"""
from __future__ import annotations

import math
from collections import Counter
from typing import Dict, List, Sequence, Tuple


def _entropy_normalized(counts: Sequence[int], ref_size: int) -> float:
    """H(counts)/log(ref_size), clamped to [0,1]. 0 when <2 reference states."""
    total = sum(counts)
    if total <= 0 or ref_size <= 1:
        return 0.0
    h = 0.0
    for c in counts:
        if c > 0:
            p = c / total
            h -= p * math.log(p)
    return max(0.0, min(1.0, h / math.log(ref_size)))


# ---------------------------------------------------------------------------
# 1. Factor Coverage
# ---------------------------------------------------------------------------
def factor_coverage(sample_factors: List[Dict[str, str]],
                    factor_space: Dict[str, List[str]]) -> Dict:
    per: Dict[str, Dict] = {}
    scores: List[float] = []
    for k, values in factor_space.items():
        vset = set(values)
        if not vset:
            continue
        observed = Counter(sf[k] for sf in sample_factors if sf.get(k) in vset)
        cov = len(observed) / len(vset)
        scores.append(cov)
        per[k] = {
            "coverage": cov,
            "observed": sorted(observed),
            "missing": sorted(vset - set(observed)),
            "ref_size": len(vset),
        }
    return {"overall": sum(scores) / len(scores) if scores else 0.0, "per_factor": per}


def combinatorial_factor_coverage(sample_factors: List[Dict[str, str]],
                                  factor_space: Dict[str, List[str]],
                                  cell_union: Sequence[Tuple]) -> Dict:
    """Factor Coverage over the JOINT factor-configuration space.

    A "cell" is the full tuple of factor values across every reference factor (in
    a fixed key order). Coverage = (# distinct cells observed this round) /
    |cell_union|, where `cell_union` is the set of cells observed across ALL
    compared rounds in the same evaluate() call. This is a Hill q=0 (richness)
    measure normalized by the observed union — the SAME convention already used by
    trajectory richness — so it is absolute, monotone under cumulation, and
    comparable across the rounds sharing one union.

    Used only when a domain sets factor_coverage_mode="combinatorial" (car): its
    small env saturates every MARGINAL factor value identically across methods, so
    the standard marginal coverage is flat and cannot separate static-multiround
    from EvoSynth; the joint configuration space is where the difference lives.

    The standard marginal per-factor coverage is retained as a diagnostic
    (`marginal_overall` / `per_factor`) but does NOT drive `overall`."""
    keys = list(factor_space.keys())
    observed = {tuple(sf.get(k) for k in keys) for sf in sample_factors}
    ref = len(set(cell_union))
    cov = len(observed) / ref if ref else 0.0
    marg = factor_coverage(sample_factors, factor_space)   # diagnostic only
    return {
        "overall": cov,
        "mode": "combinatorial",
        "n_cells_observed": len(observed),
        "cell_union_size": ref,
        "marginal_overall": marg["overall"],
        "per_factor": marg["per_factor"],
    }


# ---------------------------------------------------------------------------
# 2. Factor Balance
# ---------------------------------------------------------------------------
def factor_balance(sample_factors: List[Dict[str, str]],
                   factor_space: Dict[str, List[str]]) -> Dict:
    per: Dict[str, Dict] = {}
    scores: List[float] = []
    for k, values in factor_space.items():
        vset = set(values)
        if len(vset) <= 1:
            continue
        counts = Counter(sf[k] for sf in sample_factors if sf.get(k) in vset)
        bal = _entropy_normalized(list(counts.values()), len(vset))
        scores.append(bal)
        per[k] = {"balance": bal, "distribution": dict(counts), "ref_size": len(vset)}
    return {"overall": sum(scores) / len(scores) if scores else 0.0, "per_factor": per}


# ---------------------------------------------------------------------------
# 3. Interaction Coverage
# ---------------------------------------------------------------------------
def interaction_coverage(sample_factors: List[Dict[str, str]],
                         templates: List[Tuple[str, str]],
                         factor_space: Dict[str, List[str]]) -> Dict:
    """Coverage of the full cartesian product per template. Denominators are NOT
    pruned of structurally-impossible combos, so absolute values read low but
    cross-round deltas are valid (same fixed denominator every round)."""
    per: Dict[str, Dict] = {}
    scores: List[float] = []
    for a, b in templates:
        va, vb = set(factor_space.get(a, [])), set(factor_space.get(b, []))
        if not va or not vb:
            continue
        denom = len(va) * len(vb)
        observed = {(sf[a], sf[b]) for sf in sample_factors
                    if sf.get(a) in va and sf.get(b) in vb}
        cov = len(observed) / denom
        scores.append(cov)
        per[f"{a}*{b}"] = {
            "coverage": cov,
            "observed_combos": len(observed),
            "total_combos": denom,
        }
    return {"overall": sum(scores) / len(scores) if scores else 0.0,
            "per_interaction": per}


# ---------------------------------------------------------------------------
# 4. Complexity (HARD-REGION REACH — an evaluative, higher-is-better metric)
# ---------------------------------------------------------------------------
def complexity(sample_bins: List[Dict[str, str]],
               complexity_dims: Dict[str, List[str]],
               complexity_levels: Dict[str, Dict[str, float]]) -> Dict:
    """Hard-region reach of the verified data — the SHARE that lands in the
    hardest bins of each complexity dimension.

    Each dimension's bins form an ascending difficulty ladder; its HARD region is
    the top-k bins with k = min(2, n-1) — the two hardest, but never the whole
    ladder, so a 2-bin dimension uses only its single hardest bin. Per dimension
    we take the fraction of samples that fall in the hard region, then average
    dimensions with equal weight.

    Why this direction is meaningful (unlike a mean central-tendency, which has no
    "good" direction): only VERIFIED (solvable, reward==1) samples are scored, so
    there is NO "too hard" failure mode in the measured set — unlearnable tasks
    never pass the verifier and are already filtered out. Within verified data,
    reaching a larger hard-region share is unambiguously better: it means the
    pipeline verifiably produces harder tasks, which is exactly what the
    Reflector/Designer loop targets (filling the empty high-write / computation /
    high-read buckets). Higher = better.

    Diagnostics retained per dimension and at top level: `mean_level` (mean
    normalized difficulty level — descriptive central tendency, no good direction)
    and `mean_coverage` (old set-coverage breadth: were all bins reached).
    """
    per: Dict[str, Dict] = {}
    hard_scores: List[float] = []
    level_scores: List[float] = []
    cov_scores: List[float] = []
    for dim, bins in complexity_dims.items():
        bset = set(bins)
        if not bset:
            continue
        n = len(bins)
        k = min(2, n - 1) if n > 1 else 1        # hard = top-k, never the whole ladder
        hard_bins = set(bins[-k:]) if k > 0 else set()
        lvl_map = complexity_levels.get(dim, {})
        vals = [sb[dim] for sb in sample_bins if sb.get(dim) in bset]
        if vals:
            hard_share = sum(1 for v in vals if v in hard_bins) / len(vals)
            mean_level = sum(lvl_map.get(v, 0.0) for v in vals) / len(vals)
        else:
            hard_share = mean_level = 0.0
        observed = set(vals)
        cov = len(observed) / len(bset)
        hard_scores.append(hard_share)
        level_scores.append(mean_level)
        cov_scores.append(cov)
        per[dim] = {
            "hard_share": hard_share,
            "hard_bins": sorted(hard_bins),
            "mean_level": mean_level,
            "coverage": cov,
            "distribution": dict(Counter(vals)),
            "observed": sorted(observed),
            "missing": sorted(bset - observed),
            "ref_size": len(bset),
            "max_reachable_level": max(lvl_map.values()) if lvl_map else 0.0,
        }
    return {"overall": sum(hard_scores) / len(hard_scores) if hard_scores else 0.0,
            "mean_hard_share": sum(hard_scores) / len(hard_scores) if hard_scores else 0.0,
            "mean_level": sum(level_scores) / len(level_scores) if level_scores else 0.0,
            "mean_coverage": sum(cov_scores) / len(cov_scores) if cov_scores else 0.0,
            "per_dimension": per}


# ---------------------------------------------------------------------------
# 5. Trajectory Pattern Diversity
# ---------------------------------------------------------------------------
def trajectory_pattern_diversity(patterns: List[str],
                                 union_patterns: Sequence[str]) -> Dict:
    """Two complementary views of trajectory-pattern diversity, both referenced
    to the shared union pattern space across all rounds (|P_union|):
      - richness (Hill q=0) = #distinct patterns / |P_union|  -> ABSOLUTE
        diversity: how many different shapes were explored. Monotone under
        cumulation, immune to how mass is distributed.
      - overall = H(distribution) / log|P_union| (normalized Shannon entropy)
        -> EVENNESS: how uniformly mass is spread. Can move opposite to richness
        (a round can explore MORE shapes yet be MORE skewed -> lower entropy).
    Both 0 when the union has <2 patterns or this round is empty."""
    counts = Counter(patterns)
    ref_size = len(set(union_patterns))
    tpd = _entropy_normalized(list(counts.values()), ref_size)
    n = len(patterns)
    ordered = counts.most_common()
    top1 = ordered[0][1] / n if n else 0.0
    top5 = sum(c for _, c in ordered[:5]) / n if n else 0.0
    return {
        "overall": tpd,
        # richness (Hill q=0): absolute #distinct shapes, normalized by the
        # shared observed pattern space |P_union|. Monotone under cumulation,
        # not diluted by sample count -> the "absolute diversity" reading.
        "richness": len(counts) / ref_size if ref_size else 0.0,
        "n_unique_patterns": len(counts),
        "unique_rate": len(counts) / n if n else 0.0,
        "union_size": ref_size,
        "top1_freq": top1,
        "top5_freq": top5,
        "top_patterns": ordered[:10],
    }


__all__ = [
    "factor_coverage",
    "combinatorial_factor_coverage",
    "factor_balance",
    "interaction_coverage",
    "complexity",
    "trajectory_pattern_diversity",
]
