"""Per-domain configuration for the quality-metrics engine.

Only `task_family` is genuinely domain-specific (its value set + how it is
derived from observed tools/assertions). Every other factor (tool_pattern,
expected_outcome, state_change_type, computation, num_write, num_read,
policy_constraint), the interaction templates, and the complexity dimensions
are STRUCTURAL and therefore shared across airline / retail / telecom / car.

Reference spaces are FIXED here (the "union" space) so R1/R2/R3 stay comparable.
`task_family` value sets are the union of families observed across the domain's
cold-start rounds; values not observationally derivable (e.g. airline's
loyalty_or_membership_service) are still listed so coverage honestly reflects
whether that slice was produced. Novel observed values not in a set are surfaced
by evaluate.py as `novel_values` (a signal to grow the reference space).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Tuple

from .tool_ontology import classify_tool

# --- shared structural reference values (same across all domains) ---
_COUNT_LADDER = ["0", "1", "2", "3-4", "5+"]
SHARED_FACTOR_SPACE: Dict[str, List[str]] = {
    "tool_pattern": ["read_only", "single_write", "read_write", "multi_write",
                     "read_compute_write"],
    "expected_outcome": ["information_only", "state_update", "policy_denial"],
    "state_change_type": ["no_change", "single_field_change", "multi_field_change",
                          "multi_entity_change"],
    "computation": ["none", "simple", "multi_step"],
    "num_write_actions": list(_COUNT_LADDER),
    "num_read_actions": list(_COUNT_LADDER),
    "policy_constraint": ["none", "policy_gated"],
}

# meaningful factor pairs whose joint coverage we score
SHARED_INTERACTION_TEMPLATES: List[Tuple[str, str]] = [
    ("task_family", "tool_pattern"),
    ("task_family", "expected_outcome"),
    ("task_family", "state_change_type"),
    ("tool_pattern", "state_change_type"),
    ("computation", "num_write_actions"),
    ("policy_constraint", "expected_outcome"),
]

# structural-complexity dimensions and their reference bins, listed in ASCENDING
# complexity order (index 0 = simplest). Complexity Level maps each observed bin to
# its ordinal position, normalized by the dimension's max index -> [0,1].
SHARED_COMPLEXITY_DIMS: Dict[str, List[str]] = {
    "trajectory_length": ["short", "medium", "long"],
    "tool_breadth": ["single_tool", "multi_tool"],
    "state_change": ["no_write", "single_write", "multi_write"],
    "state_scope": ["single_field", "multi_field", "multi_entity"],
    # ascending difficulty: plain lookup < read-then-write < exact arithmetic < policy gate
    "reasoning_requirement": ["direct", "state_dependent", "computation_required",
                              "policy_constrained"],
}

# ordinal complexity level of each bin, normalized to [0,1] by the dimension's
# highest bin. Derived from the ASCENDING bin order above so a single source of
# truth defines both the reference set and its difficulty ladder.
SHARED_COMPLEXITY_LEVELS: Dict[str, Dict[str, float]] = {
    dim: {b: (i / (len(bins) - 1) if len(bins) > 1 else 0.0)
          for i, b in enumerate(bins)}
    for dim, bins in SHARED_COMPLEXITY_DIMS.items()
}


@dataclass
class DomainAdapter:
    name: str
    task_family_values: List[str]
    _derive: Callable[[Dict[str, Any], Dict[str, Any]], str]
    factor_space: Dict[str, List[str]] = field(default_factory=dict)
    # How Factor Coverage is scored. "marginal" (default) = fraction of each
    # factor's reference VALUES observed, averaged over factors — the standard
    # definition, used by airline/retail/telecom. "combinatorial" = coverage of
    # the JOINT factor-configuration space (distinct full factor-tuples observed,
    # normalized by the observed cell-union across the compared rounds, Hill q=0).
    # This field affects ONLY Factor Coverage; every other metric is untouched.
    # Rationale for car: its small single-vehicle env saturates every MARGINAL
    # factor value identically across methods (marginal coverage is flat 0.72 and
    # cannot separate static-multiround from EvoSynth), whereas the joint
    # configuration space is exactly where adaptive evolution shows up.
    factor_coverage_mode: str = "marginal"
    interaction_templates: List[Tuple[str, str]] = field(
        default_factory=lambda: list(SHARED_INTERACTION_TEMPLATES))
    complexity_dims: Dict[str, List[str]] = field(
        default_factory=lambda: {k: list(v) for k, v in SHARED_COMPLEXITY_DIMS.items()})
    complexity_levels: Dict[str, Dict[str, float]] = field(
        default_factory=lambda: {k: dict(v) for k, v in SHARED_COMPLEXITY_LEVELS.items()})

    def __post_init__(self):
        fs = {"task_family": list(self.task_family_values)}
        for k, v in SHARED_FACTOR_SPACE.items():
            fs[k] = list(v)
        # allow a domain to have already injected overrides via factor_space
        for k, v in (self.factor_space or {}).items():
            fs[k] = list(v)
        self.factor_space = fs

    def derive_task_family(self, feats: Dict[str, Any], sample: Dict[str, Any]) -> str:
        return self._derive(feats, sample)


def _names(feats: Dict[str, Any]) -> List[str]:
    return [a["name"] for a in feats["actions"]]


def _first_write_family(names: List[str], mapping: List[Tuple[Tuple[str, ...], str]],
                        default_read: str) -> str:
    """Return the family of the first WRITE tool matching `mapping` (ordered),
    else `default_read` when the trajectory is read-only."""
    for n in names:
        if classify_tool(n) != "WRITE":
            continue
        for keys, fam in mapping:
            if any(k in n for k in keys):
                return fam
    return default_read


# ---------------- airline ----------------
_AIRLINE_MAP = [
    (("cancel",), "flight_cancellation"),
    (("update_reservation_flights",), "flight_change"),
    (("book",), "flight_booking"),
    (("baggage", "passenger", "seat"), "seat_or_baggage_service"),
    (("certificate", "refund", "compensation"), "refund_or_compensation"),
    (("membership", "loyalty"), "loyalty_or_membership_service"),
]


def _airline_family(feats, sample):
    return _first_write_family(_names(feats), _AIRLINE_MAP, "profile_or_inquiry")


# ---------------- retail ----------------
_RETAIL_MAP = [
    (("cancel_pending_order",), "order_cancellation"),
    (("modify_pending_order",), "order_item_modification"),
    (("return_delivered",), "return_delivered_order"),
    (("exchange_delivered",), "exchange_delivered_order"),
    (("modify_user_address", "modify_user",), "profile_or_inquiry"),
]


def _retail_family(feats, sample):
    return _first_write_family(_names(feats), _RETAIL_MAP, "profile_or_inquiry")


# ---------------- car ----------------
_CAR_MAP = [
    (("climate", "fan", "temperature", "seat_heating", "steering_wheel_heating",
      "air_conditioning", "defrost", "recirculation"), "climate_control"),
    (("window", "sunroof", "trunk", "door", "light", "wiper", "mirror",
      "charge_port_door"), "window_and_body"),
    (("navigation", "route", "destination", "poi"), "navigation"),
    (("charg", "soc"), "charging"),
    (("email", "phone", "call", "contact", "message", "calendar"), "communication"),
]
_CAR_READ_MAP = [
    (("navigation", "route", "poi", "distance"), "navigation"),
    (("charg", "soc", "battery", "energy"), "charging"),
    (("climate", "temperature", "fan", "seat", "air"), "climate_control"),
    (("window", "door", "light", "trunk", "sunroof"), "window_and_body"),
    (("contact", "calendar", "message", "email"), "communication"),
]


def _car_family(feats, sample):
    names = _names(feats)
    fam = _first_write_family(names, _CAR_MAP, "")
    if fam:
        return fam
    # read-only: classify by what was queried, else generic info lookup
    for n in names:
        for keys, f in _CAR_READ_MAP:
            if any(k in n for k in keys):
                return f
    return "info_query"


# ---------------- telecom ----------------
def _telecom_family(feats, sample):
    """Derive from OBSERVED signals: env-assertion names first (most reliable),
    then the tools/args actually used. Falls back to 'service_issue'."""
    blob = ""
    ec = (sample.get("task") or {}).get("evaluation_criteria") or {}
    for k in ("env_assertions", "nl_assertions", "assertions"):
        v = ec.get(k)
        if isinstance(v, list):
            blob += " " + " ".join(str(x) for x in v)
    names = " ".join(_names(feats))
    hay = (blob + " " + names).lower()
    if "mms" in hay:
        return "mms_issue"
    if any(k in hay for k in ("data", "roaming", "apn", "speed", "internet")):
        return "mobile_data_issue"
    if any(k in hay for k in ("payment", "bill", "refuel", "invoice", "charge")):
        return "billing_or_account"
    if any(k in hay for k in ("suspend", "resume", "line", "sim", "network",
                              "reboot", "airplane", "wifi", "vpn", "service")):
        return "service_issue"
    return "service_issue"


_ADAPTERS: Dict[str, DomainAdapter] = {
    "airline": DomainAdapter(
        "airline",
        ["flight_change", "flight_booking", "flight_cancellation",
         "seat_or_baggage_service", "refund_or_compensation",
         "loyalty_or_membership_service", "profile_or_inquiry"],
        _airline_family),
    "retail": DomainAdapter(
        "retail",
        ["order_cancellation", "order_item_modification", "return_delivered_order",
         "exchange_delivered_order", "profile_or_inquiry"],
        _retail_family),
    "telecom": DomainAdapter(
        "telecom",
        ["mms_issue", "mobile_data_issue", "service_issue", "billing_or_account"],
        _telecom_family),
    "car": DomainAdapter(
        "car",
        ["climate_control", "window_and_body", "navigation",
         "charging", "communication", "info_query"],
        _car_family,
        # car-only: score Factor Coverage over the JOINT factor-configuration
        # space. Marginal coverage saturates identically for every method on car's
        # tiny env (flat 0.72, no static-vs-EvoSynth signal); combinatorial cell
        # coverage surfaces the real difference (EvoSynth keeps discovering new
        # factor combinations while static multi-round plateaus). This changes
        # ONLY Factor Coverage; Balance/Interaction/Complexity/Trajectory are
        # computed exactly as before. Airline/retail/telecom keep "marginal".
        factor_coverage_mode="combinatorial"),
}


def get_adapter(domain: str) -> DomainAdapter:
    d = (domain or "").strip().lower()
    if d not in _ADAPTERS:
        raise ValueError(f"unknown domain {domain!r}; supported: {list(_ADAPTERS)}")
    return _ADAPTERS[d]


def list_domains() -> List[str]:
    return list(_ADAPTERS)


__all__ = ["DomainAdapter", "get_adapter", "list_domains",
           "SHARED_FACTOR_SPACE", "SHARED_INTERACTION_TEMPLATES",
           "SHARED_COMPLEXITY_DIMS", "SHARED_COMPLEXITY_LEVELS"]
