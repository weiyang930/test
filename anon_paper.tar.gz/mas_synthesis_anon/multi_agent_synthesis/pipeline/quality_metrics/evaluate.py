"""Orchestrator + CLI for the intrinsic quality metrics.

Pipeline per invocation:
  1. load  : read JSONL round file(s), FILTER to verified samples
             (provenance.verified_reward == 1.0). Nothing unverified is scored.
  2. extract: per sample -> observed factors, complexity bins, abstract patterns
             (all deterministic; planned metadata untouched).
  3. union : build |P_union| = union of abstract patterns across ALL given rounds
             so Trajectory Pattern Diversity is comparable round-to-round.
  4. score : the five metrics per round, against the FIXED domain reference space.
  5. report: JSON (machine) + a compact text table (human).

CLI:
  python -m quality_metrics.evaluate --domain car \
      --round R1:path1.jsonl --round R2:path2.jsonl [--round R3:path3.jsonl] \
      --out report.json
  # or a single file (round auto-named "R1"):
  python -m quality_metrics.evaluate --domain airline data.jsonl
  # or a JSON mapping {"R1":"p1","R2":"p2"}:
  python -m quality_metrics.evaluate --domain retail --rounds-json rounds.json
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from typing import Any, Dict, List, Tuple

from .adapters import get_adapter
from .factors import (
    extract_observed_factors,
    extract_complexity_bins,
    abstract_trajectory,
)
from .metrics import (
    factor_coverage,
    combinatorial_factor_coverage,
    factor_balance,
    interaction_coverage,
    complexity,
    trajectory_pattern_diversity,
)

REWARD_KEYS = ("verified_reward", "verifier_reward", "reward")


def _reward_of(sample: Dict[str, Any]):
    prov = sample.get("provenance") or {}
    for src in (prov, sample):
        for k in REWARD_KEYS:
            if k in src and src[k] is not None:
                try:
                    return float(src[k])
                except (TypeError, ValueError):
                    return None
    return None


def load_verified_samples(path: str, require_reward: bool = True
                          ) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """Read a JSONL file and keep only verified samples (reward == 1.0).

    If a file carries NO reward field at all and require_reward is True, the
    samples are kept but flagged (n_no_reward) — such files are assumed to be
    pre-filtered accepted sets. Set require_reward=False to skip filtering."""
    total = kept = dropped = no_reward = bad = 0
    out: List[Dict[str, Any]] = []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            total += 1
            try:
                s = json.loads(line)
            except json.JSONDecodeError:
                bad += 1
                continue
            r = _reward_of(s)
            if r is None:
                no_reward += 1
                out.append(s)  # no gate available -> assume pre-filtered accepted
                kept += 1
                continue
            if (not require_reward) or r >= 1.0:
                out.append(s)
                kept += 1
            else:
                dropped += 1
    return out, {"n_input": total, "n_verified": kept, "n_dropped": dropped,
                 "n_no_reward_field": no_reward, "n_bad_json": bad}


def _round_view(samples: List[Dict[str, Any]], adapter):
    """Precompute per-sample factors / complexity bins / patterns for a round."""
    factors, bins, raw_pat, col_pat, novel = [], [], [], [], Counter()
    fspace = adapter.factor_space
    for s in samples:
        fac = extract_observed_factors(s, adapter)
        factors.append(fac)
        for k, v in fac.items():
            if v != "unknown" and v not in set(fspace.get(k, [])):
                novel[f"{k}={v}"] += 1
        bins.append(extract_complexity_bins(s))
        rp, cp = abstract_trajectory(s)
        raw_pat.append(rp)
        col_pat.append(cp)
    return {"factors": factors, "bins": bins, "raw_patterns": raw_pat,
            "collapsed_patterns": col_pat, "novel_values": dict(novel)}


def evaluate_rounds(domain: str, round_paths: Dict[str, str],
                    require_reward: bool = True,
                    pattern_kind: str = "collapsed") -> Dict[str, Any]:
    """Score one or more rounds for a domain. Returns the full report dict."""
    adapter = get_adapter(domain)
    pat_key = "collapsed_patterns" if pattern_kind == "collapsed" else "raw_patterns"

    loaded, views, load_stats = {}, {}, {}
    for rname, path in round_paths.items():
        samples, stats = load_verified_samples(path, require_reward=require_reward)
        loaded[rname] = samples
        load_stats[rname] = stats
        views[rname] = _round_view(samples, adapter)

    # union pattern space across ALL rounds (for comparable TPD)
    union_patterns = set()
    for rname in round_paths:
        union_patterns.update(views[rname][pat_key])

    # combinatorial Factor-Coverage mode (car only): build the observed cell-union
    # across ALL rounds so joint-configuration coverage is comparable, exactly the
    # way |P_union| makes trajectory richness comparable. Untouched for domains in
    # the default "marginal" mode.
    cov_mode = getattr(adapter, "factor_coverage_mode", "marginal")
    cell_union = set()
    if cov_mode == "combinatorial":
        _ckeys = list(adapter.factor_space.keys())
        for rname in round_paths:
            for sf in views[rname]["factors"]:
                cell_union.add(tuple(sf.get(k) for k in _ckeys))

    rounds_report: Dict[str, Any] = {}
    for rname in round_paths:
        v = views[rname]
        if cov_mode == "combinatorial":
            fc = combinatorial_factor_coverage(v["factors"], adapter.factor_space,
                                               cell_union)
        else:
            fc = factor_coverage(v["factors"], adapter.factor_space)
        fb = factor_balance(v["factors"], adapter.factor_space)
        ic = interaction_coverage(v["factors"], adapter.interaction_templates,
                                  adapter.factor_space)
        cc = complexity(v["bins"], adapter.complexity_dims, adapter.complexity_levels)
        tpd = trajectory_pattern_diversity(v[pat_key], union_patterns)
        rounds_report[rname] = {
            "load": load_stats[rname],
            "metrics": {
                "factor_coverage": round(fc["overall"], 4),
                "factor_balance": round(fb["overall"], 4),
                "interaction_coverage": round(ic["overall"], 4),
                "complexity": round(cc["overall"], 4),
                "complexity_mean_level": round(cc["mean_level"], 4),
                "complexity_coverage": round(cc["mean_coverage"], 4),
                "trajectory_richness": round(tpd["richness"], 4),
                "trajectory_n_unique": tpd["n_unique_patterns"],
                "trajectory_pattern_diversity": round(tpd["overall"], 4),
            },
            "detail": {
                "factor_coverage": fc,
                "factor_balance": fb,
                "interaction_coverage": ic,
                "complexity": cc,
                "trajectory_pattern_diversity": tpd,
            },
            "novel_values_outside_reference_space": v["novel_values"],
        }

    return {
        "domain": domain,
        "pattern_kind": pattern_kind,
        "trajectory_pattern_union_size": len(union_patterns),
        "reference_space": {
            "factors": adapter.factor_space,
            "interaction_templates": [f"{a}*{b}" for a, b in adapter.interaction_templates],
            "complexity_dims": adapter.complexity_dims,
        },
        "rounds": rounds_report,
    }


# ---------------------------------------------------------------------------
# pretty text table
# ---------------------------------------------------------------------------
_METRIC_ORDER = [
    ("factor_coverage", "FactorCov"),
    ("factor_balance", "FactorBal"),
    ("interaction_coverage", "InteractCov"),
    ("complexity", "Complexity"),
    ("complexity_coverage", "ComplexCov"),
    ("trajectory_richness", "TrajRich"),
    ("trajectory_pattern_diversity", "TrajDiv"),
]


def format_report(report: Dict[str, Any]) -> str:
    rounds = list(report["rounds"])
    lines = []
    lines.append(f"=== Intrinsic Quality Metrics — domain={report['domain']} "
                 f"(patterns={report['pattern_kind']}, "
                 f"|P_union|={report['trajectory_pattern_union_size']}) ===")
    # header
    hdr = f"{'metric':<14}" + "".join(f"{r:>12}" for r in rounds)
    lines.append(hdr)
    lines.append("-" * len(hdr))
    lines.append(f"{'n_verified':<14}" +
                 "".join(f"{report['rounds'][r]['load']['n_verified']:>12}" for r in rounds))
    for key, label in _METRIC_ORDER:
        row = f"{label:<14}"
        for r in rounds:
            row += f"{report['rounds'][r]['metrics'][key]:>12.4f}"
        lines.append(row)
    lines.append("")
    lines.append("(FactorBalance: 1.0=uniform over reference set, higher=more even. "
                 "Complexity=hard-region reach: share of verified data in the top-2 "
                 "hardest bins per dimension, higher=better (verified-only, so no "
                 "'too hard' regime). ComplexCov=old breadth diagnostic (which bins "
                 "reached). Coverage/Diversity: higher=broader/richer.)")
    # novel-value warnings
    for r in rounds:
        nv = report["rounds"][r]["novel_values_outside_reference_space"]
        if nv:
            lines.append(f"[!] {r} observed values outside reference space "
                         f"(consider growing it): {nv}")
    return "\n".join(lines)


def _parse_rounds(args) -> Dict[str, str]:
    rounds: Dict[str, str] = {}
    if args.rounds_json:
        with open(args.rounds_json) as fh:
            rounds.update(json.load(fh))
    for spec in args.round or []:
        if ":" not in spec:
            raise SystemExit(f"--round expects NAME:path, got {spec!r}")
        name, path = spec.split(":", 1)
        rounds[name] = path
    for i, path in enumerate(args.files or [], 1):
        rounds[f"R{i}" if not rounds else f"R{len(rounds)+1}"] = path
    if not rounds:
        raise SystemExit("no input: pass --round NAME:path, --rounds-json, or files")
    return rounds


def main(argv=None):
    ap = argparse.ArgumentParser(description="Intrinsic quality metrics for "
                                             "verified agentic synthetic data")
    ap.add_argument("--domain", required=True,
                    help="airline | retail | telecom | car")
    ap.add_argument("--round", action="append", default=[],
                    help="NAME:path.jsonl (repeatable, e.g. R1:r1.jsonl)")
    ap.add_argument("--rounds-json", help="JSON file mapping {name: path}")
    ap.add_argument("files", nargs="*", help="bare jsonl file(s), auto-named R1..")
    ap.add_argument("--out", help="write full JSON report here")
    ap.add_argument("--pattern-kind", choices=["collapsed", "raw"], default="collapsed",
                    help="trajectory abstraction granularity (default collapsed)")
    ap.add_argument("--no-require-reward", action="store_true",
                    help="do NOT filter by verified_reward==1 (score all rows)")
    args = ap.parse_args(argv)

    rounds = _parse_rounds(args)
    report = evaluate_rounds(args.domain, rounds,
                             require_reward=not args.no_require_reward,
                             pattern_kind=args.pattern_kind)
    print(format_report(report))
    if args.out:
        with open(args.out, "w") as fh:
            json.dump(report, fh, indent=2, ensure_ascii=False)
        print(f"\n[wrote full JSON report -> {args.out}]", file=sys.stderr)
    return report


if __name__ == "__main__":
    main()
