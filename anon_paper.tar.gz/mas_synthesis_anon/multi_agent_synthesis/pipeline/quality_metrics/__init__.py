"""Intrinsic Quality Metrics for Verified Agentic Synthetic Data (EvoSynth).

Measures the intrinsic quality / structural properties of the FINAL VERIFIED
synthetic dataset — independent of pipeline acceptance rate and downstream
task-agent performance. Five metrics, all normalized to [0, 1]:

    1. Factor Coverage             (breadth of observed factor values)
    2. Factor Balance              (evenness of factor value distribution)
    3. Interaction Coverage        (coverage of meaningful factor combinations)
    4. Complexity                  (hard-region reach: share of verified data in
                                    the top-2 hardest bins per complexity dim;
                                    higher=better — verified-only so no "too hard"
                                    regime. Diagnostics kept: `complexity_mean_level`
                                    (mean difficulty level) and `complexity_coverage`
                                    (old set-coverage breadth))
    5. Trajectory Pattern Diversity(entropy over abstract execution patterns)

Design principles (see the task spec):
  * Only verified/accepted samples (verifier_reward == 1) are scored.
  * No Valid Rate, no downstream/learner-dependent signal.
  * Metrics are computed from OBSERVED factors extracted deterministically from
    the verified task's ground-truth actions + tool classification — NOT from
    the planner's requested `dimension_plan` (planned metadata is diagnostics
    only).
  * Deterministic / reproducible; no LLM-as-judge.
  * A fixed reference space (the "union" space) is used across rounds so that
    R1, R2, R3 ... are directly comparable.

Supported domains: tau-bench (airline, retail, telecom) and car-bench (car).
The metric engine is domain-agnostic; per-domain specifics live in adapters.py.
"""
from .metrics import (
    factor_coverage,
    factor_balance,
    interaction_coverage,
    complexity,
    trajectory_pattern_diversity,
)
from .factors import extract_observed_factors, abstract_trajectory
from .adapters import get_adapter, list_domains

# NB: evaluate_rounds / load_verified_samples live in .evaluate. They are not
# imported here so that `python -m quality_metrics.evaluate` does not double-load
# the module. Import them explicitly: `from quality_metrics.evaluate import ...`.

__all__ = [
    "factor_coverage",
    "factor_balance",
    "interaction_coverage",
    "complexity",
    "trajectory_pattern_diversity",
    "extract_observed_factors",
    "abstract_trajectory",
    "get_adapter",
    "list_domains",
]
