"""DimensionFilter: the v0 final quality/coverage gate (dimension-cell based).

Structurally the twin of v1's TaskFilter, but the coverage axis is the v0
DIMENSION cell (``blueprint.dimension_cell()`` = sorted task_family join |
expected_outcome | sorted policy focus | difficulty) rather than the archetype
cell. Kept separate so the v0
filter can evolve without touching the v1 hot path.

Stateful across a batch (dedup sets + per-cell counts); call :meth:`filter` once
per candidate in batch order. Dedup/near-dup reuse the adapter signatures (they
are paradigm-agnostic: they hash the gt actions + entities).
"""

from __future__ import annotations

from collections import Counter
from typing import List

from ..schemas import TaskCandidate
from ..schemas.report_schema import FilterReport


class DimensionFilter:
    def __init__(
        self,
        adapter,
        max_per_cell: int = 200,
        min_actions: int = 1,
        max_actions: int = 12,
        enable_near_duplicate: bool = True,
    ):
        self.adapter = adapter
        self.max_per_cell = max_per_cell
        self.min_actions = min_actions
        self.max_actions = max_actions
        self.enable_near_duplicate = enable_near_duplicate

        self._seen_exact: set = set()
        self._seen_entity: set = set()
        self._cell_counts: Counter = Counter()

    def filter(self, candidate: TaskCandidate) -> FilterReport:
        report = FilterReport()

        sig = self.adapter.dedup_signature(candidate)
        is_dup = sig in self._seen_exact
        report.filters["not_duplicate"] = not is_dup
        if is_dup:
            report.rejection_reasons.append("exact duplicate of an accepted candidate")

        esig = None
        if self.enable_near_duplicate:
            esig = self.adapter.entity_signature(candidate)
            is_near = esig in self._seen_entity
            report.filters["not_near_duplicate"] = not is_near
            if is_near:
                report.rejection_reasons.append(
                    "near-duplicate (same entities + write args)"
                )

        n = len(candidate.effective_gt_actions())
        # A refusal's correct gt is read-only / empty, so the minimum-length floor
        # does not apply; only cap the upper bound (a refusal that needs many read
        # calls is fine, but it should still not be unbounded).
        lo = 0 if candidate.blueprint.is_refusal() else self.min_actions
        len_ok = lo <= n <= self.max_actions
        report.filters["trajectory_length"] = len_ok
        if not len_ok:
            report.rejection_reasons.append(
                f"trajectory length {n} outside [{lo},{self.max_actions}]"
            )

        cell = candidate.blueprint.dimension_cell()
        under_cap = self._cell_counts[cell] < self.max_per_cell
        report.filters["coverage_cap"] = under_cap
        if not under_cap:
            report.rejection_reasons.append(
                f"dimension cell '{cell}' already has {self.max_per_cell} accepted"
            )

        report.finalize()

        if report.kept:
            self._seen_exact.add(sig)
            if esig is not None:
                self._seen_entity.add(esig)
            self._cell_counts[cell] += 1

        report.details["dedup_signature"] = sig
        report.details["dimension_cell"] = cell
        return report

    def filter_batch(self, candidates: List[TaskCandidate]) -> List[FilterReport]:
        return [self.filter(c) for c in candidates]

    def coverage_counts(self) -> dict:
        return dict(self._cell_counts)
