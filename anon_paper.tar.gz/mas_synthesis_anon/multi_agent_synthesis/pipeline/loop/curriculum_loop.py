"""Curriculum evolution loop (spec §11). Deterministically orchestrates
synth -> (train/eval hooks) -> feedback -> probes -> reflector -> safety -> apply.
train/eval are injectable hooks (SFT-only recipe; RL deferred). Every step's
artifacts are persisted under work_dir for reproducibility."""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from ..ontology.ontology_schema import Ontology
from ..ontology.ontology_store import save_ontology
from ..ontology.ontology_update import apply_ontology_updates
from ..ontology.schema_safety_check import schema_safety_check
from ..probes.probe_extractor import extract_sample_probes
from ..probes.probe_report_builder import extract_diagnostic_probes
from ..feedback.dimension_feedback import build_dimension_feedback
from ..reflector.reflector_prompt import build_ontology_audit_package
from ..reflector.ontology_reflector import run_reflector

import json

# probe field each promotable dimension backfills from.
_BACKFILL_PROBE_FIELD = {
    "num_write": "num_write_bucket",
    "computation": "requires_computation",
}


def _dump(work_dir: str, subdir: str, name: str, obj: Any) -> None:
    d = os.path.join(work_dir, subdir)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, name), "w") as fh:
        json.dump(obj, fh, indent=2)


def backfill_valid_pool(valid_pool: List[Dict[str, Any]],
                        new_dimension_names: List[str]) -> None:
    for s in valid_pool:
        feats = extract_sample_probes(s)
        mp = s.setdefault("micro_plan", {})
        for dim in new_dimension_names:
            field = _BACKFILL_PROBE_FIELD.get(dim)
            mp[dim] = str(feats[field]) if field and field in feats else "unknown"


@dataclass
class CurriculumConfig:
    domain: str = "airline"
    work_dir: str = ""
    max_rounds: int = 3
    no_update_patience: int = 2
    max_new_dimensions_per_round: int = 1


def run_curriculum_round(
    round_id: str,
    ontology: Ontology,
    *,
    synth_hook: Callable[[Ontology, str], Dict[str, Any]],
    train_hook: Callable[[str, List[Dict[str, Any]]], Dict[str, str]],
    eval_hook: Callable[[str, List[Dict[str, Any]]], Optional[Dict[str, float]]],
    reflector_llm: Any,
    work_dir: str,
    previous_feedback: Optional[Dict[str, Any]] = None,
    history: Optional[List[Dict[str, Any]]] = None,
    max_new_dimensions_per_round: int = 1,
    cumulative_valid_pool: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    history = history or []
    _dump(work_dir, "ontology_versions", f"{ontology.ontology_version}.json",
          ontology.model_dump())

    # 1-6: synthesize + split
    round_synth = synth_hook(ontology, round_id)
    samples = round_synth["samples"]
    round_valid_pool = round_synth["valid_pool"]

    # Build effective cumulative valid pool
    effective_valid_pool = (cumulative_valid_pool or []) + round_valid_pool

    train_samples = [s for s in samples if s.get("split") != "valid"]

    # 7-8: train + eval (hooks)
    ckpts = train_hook(round_id, train_samples)
    eval_before = eval_hook(ckpts.get("before_ckpt", ""), effective_valid_pool)
    eval_after = eval_hook(ckpts.get("after_ckpt", ""), effective_valid_pool)

    # 9: dimension-value feedback
    feedback_report = build_dimension_feedback(
        samples, effective_valid_pool, eval_before, eval_after, ontology)
    _dump(work_dir, "reports", f"{round_id}_feedback_report.json", feedback_report)

    # 10: probes
    probe_report = extract_diagnostic_probes(samples, round_id=round_id)
    _dump(work_dir, "reports", f"{round_id}_probe_report.json", probe_report)

    # 11: audit package
    audit = build_ontology_audit_package(
        ontology, feedback_report, probe_report, history,
        max_new_dimensions_per_round=max_new_dimensions_per_round)
    _dump(work_dir, "reports", f"{round_id}_audit_package.json", audit)

    # 12: reflector
    reflector_output = run_reflector(audit, reflector_llm)
    _dump(work_dir, "reflector_outputs", f"{round_id}_reflector_output.json",
          reflector_output)

    # 13: safety
    safety_report = schema_safety_check(reflector_output, ontology, probe_report)

    # 14: apply -> O_{r+1}
    next_ontology, update_report = apply_ontology_updates(
        ontology, reflector_output, safety_report,
        max_new_dimensions_per_round=max_new_dimensions_per_round)
    _dump(work_dir, "ontology_update_reports", f"{round_id}_ontology_update_report.json",
          update_report)
    save_ontology(next_ontology,
                  os.path.join(work_dir, "ontology_versions",
                               f"{next_ontology.ontology_version}.json"))

    # backfill valid pool for any newly added dimensions
    new_dims = [a["dimension"] for a in update_report["applied"]
                if a.get("action") == "promote_probe_to_dimension"
                and a.get("dimension")]
    if new_dims:
        backfill_valid_pool(effective_valid_pool, new_dims)

    # Persist the cumulative valid pool
    valid_pool_dir = os.path.join(work_dir, "valid_pool")
    os.makedirs(valid_pool_dir, exist_ok=True)
    with open(os.path.join(valid_pool_dir, f"{round_id}_valid_pool.jsonl"), "w") as fh:
        for sample in effective_valid_pool:
            fh.write(json.dumps(sample) + "\n")

    return {
        "round_id": round_id,
        "ontology_in": ontology.ontology_version,
        "ontology_out": next_ontology.ontology_version,
        "feedback_report": feedback_report,
        "probe_report": probe_report,
        "reflector_output": reflector_output,
        "safety_report": safety_report,
        "update_report": update_report,
        "next_ontology": next_ontology,
        "valid_pool": effective_valid_pool,
    }


def run_curriculum_loop(
    cfg: CurriculumConfig,
    initial_ontology: Ontology,
    *,
    synth_hook: Callable,
    train_hook: Callable,
    eval_hook: Callable,
    reflector_llm: Any,
) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    history: List[Dict[str, Any]] = []
    ontology = initial_ontology
    no_update_streak = 0
    cumulative = []

    for r in range(1, cfg.max_rounds + 1):
        round_id = f"round_{r}"
        res = run_curriculum_round(
            round_id, ontology,
            synth_hook=synth_hook, train_hook=train_hook, eval_hook=eval_hook,
            reflector_llm=reflector_llm, work_dir=cfg.work_dir,
            history=history,
            max_new_dimensions_per_round=cfg.max_new_dimensions_per_round,
            cumulative_valid_pool=cumulative)
        results.append(res)
        history.append(res["reflector_output"])
        cumulative = res["valid_pool"]

        if res["update_report"]["applied"]:
            no_update_streak = 0
        else:
            no_update_streak += 1
        ontology = res["next_ontology"]
        if no_update_streak >= cfg.no_update_patience:
            break

    return results
