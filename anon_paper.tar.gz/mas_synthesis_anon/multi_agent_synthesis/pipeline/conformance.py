"""pipeline-private realization gates for reflector-added axes.

A promoted axis (e.g. num_numeric_fields, num_write) is only meaningful if the
GENERATOR actually realizes the declared bucket. The macro/micro planners can
declare "num_numeric_fields=3+", but if the generator emits a task whose GT has
1 numeric field, that sample would be filed into the 3+ coverage cell while being
trivial -- the classic declared-vs-realized collapse. These gates recompute the
realized value from the GT (via the v5 probe extractor) and reject a sample whose
realization contradicts its declared bucket.

This is the v5-private analogue of verifiers/task_verifier.check_write_count_conformance
(which we do NOT touch -- it is shared with v3). The gate is generic over any
count axis whose values are the 0/1/2/3+ ladder.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from .probes.probe_extractor import extract_sample_probes, write_bucket

# count axis name -> the probe field that realizes it.
_COUNT_AXIS_PROBE = {
    "num_numeric_fields": "num_numeric_fields",
    "num_write": "num_write_actions",
    "num_write_actions": "num_write_actions",
    "num_state_changes": "num_state_changes",
    "trajectory_length": "trajectory_length",
}

# Semantic axes whose realization is NOT a 0/1/2/3+ count but a structural
# property of the GT. The generator routinely DECLARES `computation=aggregate`
# / `conditional_threshold` (planner intent is correct) yet emits a GT that
# collapses the arithmetic away -- no `calculate` step, no number communicated
# -- so the task degenerates into a plain write/refuse. These gates recompute
# the realized computation signal from the GT and reject the declared-vs-
# realized collapse (round1 diagnosis: conditional_threshold realized only
# ~30% while aggregate realized ~86%). `none` needs no arithmetic (skip);
# `constrained_optimization` has no clean GT signal and never survives synthesis
# anyway, so we do not gate it here.
_COMPUTATION_MUST_REALIZE = frozenset({"aggregate", "conditional_threshold"})


def _computation_realized(candidate: Any) -> Tuple[bool, str]:
    """Does the GT actually carry arithmetic? True if there is a `calculate`
    action OR a communicated value containing a digit (fee/total/threshold
    result reported to the user). Returns (realized, detail)."""
    n_calc = sum(
        1 for a in candidate.effective_gt_actions() if a.name == "calculate"
    )
    ec = (getattr(candidate, "task", {}) or {}).get("evaluation_criteria", {}) or {}
    ci = ec.get("communicate_info") or []
    n_ci_num = sum(1 for x in ci if re.search(r"\d", str(x)))
    realized = (n_calc > 0) or (n_ci_num > 0)
    return realized, f"calculate={n_calc}, communicate_info_with_number={n_ci_num}"


def _declared_bucket(candidate: Any, axis: str) -> str:
    sel = ((candidate.blueprint.dimension_plan or {})
           .get("selected_dimensions", {}) or {})
    raw = sel.get(axis)
    if isinstance(raw, (list, tuple)):
        return str(raw[0]) if raw else ""
    return "" if raw is None else str(raw)


def check_count_axis_conformance(
    candidate: Any, axes: List[str]
) -> Tuple[bool, List[str]]:
    """For each declared count axis, reject if the realized GT bucket != declared.

    Buckets are the 0/1/2/3+ ladder (write_bucket). An axis the blueprint does not
    declare (empty) is a no-op for that axis. Returns (ok, reasons)."""
    # build the realized-feature view once from the candidate's task GT.
    sample = {"task": getattr(candidate, "task", {}) or {},
              "gt_actions": [
                  {"name": a.name, "arguments": a.arguments,
                   "actor": getattr(a, "actor", "assistant")}
                  for a in candidate.effective_gt_actions()
              ]}
    feats = extract_sample_probes(sample)
    reasons: List[str] = []
    for axis in axes:
        probe_field = _COUNT_AXIS_PROBE.get(axis)
        if probe_field is None:
            continue
        declared = _declared_bucket(candidate, axis)
        if not declared:  # axis not declared on this blueprint -> skip
            continue
        realized = write_bucket(int(feats[probe_field]))
        if realized != declared:
            reasons.append(
                f"{axis} declared bucket '{declared}' but realized GT is "
                f"'{realized}' (probe {probe_field}={feats[probe_field]})")
    return (not reasons), reasons


def check_semantic_axis_conformance(
    candidate: Any, axes: List[str]
) -> Tuple[bool, List[str]]:
    """Realization gate for semantic (non-count) reflector axes.

    Currently handles `computation`: a blueprint that declares aggregate /
    conditional_threshold must emit a GT that actually computes (a `calculate`
    action or a numeric value in communicate_info). Otherwise the sample is a
    shell -- filed into the computation cell while teaching no arithmetic -- and
    is rejected. Axes/values not covered here are a no-op. Returns (ok, reasons).
    """
    reasons: List[str] = []
    if "computation" in axes:
        declared = _declared_bucket(candidate, "computation")
        if declared in _COMPUTATION_MUST_REALIZE:
            realized, detail = _computation_realized(candidate)
            if not realized:
                reasons.append(
                    f"computation declared '{declared}' but GT realizes no "
                    f"arithmetic ({detail})")
    return (not reasons), reasons


def realized_axis_values(candidate: Any, axes: List[str]) -> Dict[str, str]:
    """The REALIZED bucket per count axis (for feedback_sample backfill / audit)."""
    sample = {"task": getattr(candidate, "task", {}) or {},
              "gt_actions": [
                  {"name": a.name, "arguments": a.arguments,
                   "actor": getattr(a, "actor", "assistant")}
                  for a in candidate.effective_gt_actions()
              ]}
    feats = extract_sample_probes(sample)
    out: Dict[str, str] = {}
    for axis in axes:
        probe_field = _COUNT_AXIS_PROBE.get(axis)
        if probe_field is not None:
            out[axis] = write_bucket(int(feats[probe_field]))
    return out
