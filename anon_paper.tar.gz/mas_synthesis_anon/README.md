# Multi-Agent Synthesis

Reference implementation accompanying the paper submission.

## Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export PYTHONPATH=$PWD:$PYTHONPATH
```

Two environment suites are external dependencies (not vendored). Point the code
at local checkouts via environment variables:

```bash
export TAU2_BENCH_SRC=/path/to/tau2-bench/src   # airline / retail / telecom
export CAR_BENCH_SRC=/path/to/car_bench         # car domain
```

`TAU2_BENCH_SRC` is required for the `airline`/`retail`/`telecom` domains;
`CAR_BENCH_SRC` only for `car`. The `mock` backend needs neither.

## Run one synthesis round

```python
from multi_agent_synthesis.pipeline.orchestrator import run_synthesis, SynthesisConfig

cfg = SynthesisConfig(
    domain="retail",           # airline | retail | telecom | car
    llm_backend="bedrock",     # mock | bedrock | qwen (local vLLM)
    model="<teacher-model-id>",
    num_blueprints=200,        # tasks to attempt this round
    seed=0,
    runs_base_dir="runs",      # artifacts written to runs/<timestamp>_<run_tag>/
    run_tag="retail_r1",
)
result = run_synthesis(cfg)
print(result.run_dir)          # accepted tasks + SFT/RL exports live here
```

Backends: `mock` (deterministic, no external LLM — use it to read the control
flow), `bedrock` (Anthropic models via Amazon Bedrock), `qwen` (open-weight
generator on a local vLLM OpenAI-compatible endpoint — set `qwen_api_base`).

To continue from a previous round, pass its evolved ontology and feedback:

```python
cfg = SynthesisConfig(
    domain="retail",
    ontology_path="runs/<prev_run>/ontology/O_1.json",
    feedback_from="runs/<prev_run>/feedback/macro_feedback.json",
    # ... same backend/model fields as above
)
```

## Run the multi-round loop

```python
from multi_agent_synthesis.pipeline.loop.curriculum_loop import run_curriculum_loop
```

`run_curriculum_loop` chains rounds of `synth → train → eval → feedback →
Reflector → apply`. Supply your own `train_hook` and `eval_hook` (they fine-tune
and evaluate the student model); the loop is training-framework agnostic.

## Score a synthesized dataset

```bash
python -m multi_agent_synthesis.pipeline.quality_metrics.evaluate \
    --domain retail --round r1:runs/<run>/accepted.jsonl
```

Deterministic intrinsic-quality metrics (factor coverage/balance, interaction &
complexity coverage, trajectory diversity) over `reward==1` tasks — no LLM.

## Layout

```
multi_agent_synthesis/
├── env_bootstrap.py     # adds the external tau2-bench src to sys.path
├── pipeline/            # orchestrator, agents, verifier, loop, ontology, reflector
├── dimensions/          # seed dimension schemas (YAML)
├── domains/             # domain adapters: tau2/ (airline,retail,telecom), car/
├── schemas/  llm/  verifiers/  exporters/  feedback/  synthesis/  logging_utils/
```

All absolute paths and author-identifying strings have been removed; no
credentials or account identifiers are present.
