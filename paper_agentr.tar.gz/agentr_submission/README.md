# Agent-R: Residual Agency Allocation for Multi-Route Recommendation

Code for **Agent-R**, a multi-agent recommender that coordinates heterogeneous recommendation routes and
allocates LLM reasoning as a bounded residual correction over a recommendation prior.

Pipeline (per dataset):

```
heterogeneous route bank (NCL / DiffRec / Qwen3-Embedding / Mem-Ret / Popularity)
  → Memory Agent (LLM STM/LTM user state, offline)
  → Planning Agent (LLM, bounded per-user channel policy, offline)
  → candidate adaptation executor (calibrated, deterministic) → frozen top-50 slate
  → Residual Ranking Agent (LLM cross-encoder):  s = p + α · tanh(head(h))
```

Datasets, trained models and experiment outputs are **not** included.

## Repository layout

| Path | Content |
|---|---|
| `src/` | core library: dataset loader, configs, artifacts, metrics, LLM backend, Memory Agent |
| `scripts/build_llm_user_memory.py` | builds the LLM STM/LTM memory for all users (Memory Agent) |
| `pipeline/route_bank/` | route training (RecBole NCL/DiffRec/LightGCN, SASRec/BERT4Rec baselines), Qwen3-Embedding semantic route, route-cache assembly, base-route selection, full-test-population evaluator, fusion baselines (RRF, CombMNZ, Val-Weighted, Logistic, LambdaMART, Direct LLM Fusion), end-to-end driver scripts and `DOWNSTREAM_RUNBOOK.md` |
| `pipeline/planning/` | executor evidence channels and calibration (`pcr_common.py`, `run_offline.py`), planner contexts and the Planning Agent (`stage_planner_build.py`, `stage_planner_llm.py`) |
| `pipeline/candidate_adaptation/` | planner-conditioned frozen top-50 slate builder (`stage1_build_planner.py`) |
| `pipeline/residual_ranker/` | Residual Ranking Agent: data building, training (`train_residual.py`), DEV selection / TEST evaluation (`eval_residual.py`) |
| `pipeline/ranking_common/`, `pipeline/substrate_common/` | shared metrics, bootstrap and substrate loaders |
| `baselines/` | multi-route fusion helpers |
| `configs/` | per-dataset configs |
| `experiments/rq2_*` … `experiments/rq10_*` | analysis experiments (component ablation, route complementarity, agency allocation, failure analysis, memory, planner behaviour, residual behaviour, route robustness, efficiency) and figure scripts |

## Setup

```bash
bash setup_paths.sh "$(pwd)"            # point absolute paths in the scripts to this checkout
```
Two Python environments were used (see `requirements_llm.txt`, `requirements_recbole.txt`):
* **LLM env** – Memory/Planning agents (vLLM), residual ranker training/inference (PyTorch DDP + PEFT).
* **RecBole env** – route training and all CPU stages (executor, evaluation, analyses).

Shell launchers use `PY_LLM` / `PY_RECBOLE` (python interpreters) and `HF_HOME`; SLURM launchers take
`JOBID` / node names as placeholders (`JOBID`, `node01`, …) — adapt them to your cluster.

Models (Hugging Face): `Qwen/Qwen2.5-7B-Instruct` (memory, planning and ranking agents),
`Qwen/Qwen3-Embedding-4B` (semantic route).

## Data format

`data/<dataset>/interaction.csv` with columns `userid,itemid,label[,timestamp]`, where label 0 = train,
1 = validation, 2 = test; plus an item profile with title / description / brand / category fields.
Datasets: Amazon Software / Video Games / CDs & Music / Industrial (`*_10_80_r811`: ≥10 and ≤80
interactions per user, per-user chronological 8:1:1 split), DoubanBook, DoubanMusic, KuaiRec, MicroLens
(`*_dg`: leave-last-out).

## Running the pipeline (per dataset `<DS>`)

1. Route bank: `pipeline/route_bank/scripts/build_recbole_atomic.py` → `launch_route.sh` (NCL / DiffRec / LightGCN)
   and `build_semantic_route.py` (Qwen3-Embedding) → `assemble_modern_cache.py` (DEV base-route selection).
2. Memory Agent: `scripts/build_llm_user_memory.py --dataset-config configs/<ds>_tool_only.yaml` (see `launch_all_memory_expansion.sh`).
3. Stages 2–6 (executor calibration, planner contexts, Planning Agent, frozen slate, ranker data): `pipeline/route_bank/scripts/downstream_one_ds.sh`.
4. Residual ranker training: `pipeline/residual_ranker/scripts/launch_train.sh` (OBJ=A, PRIOR=A).
5. DEV selection → TEST once → full-test-population evaluation: `pipeline/route_bank/scripts/stage8_10_one_ds.sh`
   (details and exact commands in `pipeline/route_bank/scripts/DOWNSTREAM_RUNBOOK.md`).

Evaluation: every official test user is scored (users whose target is not retrieved contribute 0);
metrics NDCG@{10,50} and Recall@{10,50}; paired bootstrap (10k resamples) for significance.
Model selection uses the validation split only; the test split is evaluated once with the pinned configuration.

## Experiments

| Directory | Analysis |
|---|---|
| `experiments/rq2_component_ablation` | component ablation (memory, planning, ranking, prior anchor), planner-replacement policies, candidate adaptation and rescue-budget sensitivity |
| `experiments/rq3_route_complementarity` | route overlap, base-miss recovery, oracle union coverage |
| `experiments/rq4_agency_allocation` | prior / residual decomposition, strict Direct LLM Fusion |
| `experiments/rq5_failure_analysis` | consideration vs. prioritization failures |
| `experiments/rq6_memory_analysis` | memory contribution by history length |
| `experiments/rq7_planner_analysis` | planner policy diversity and channel adjustments |
| `experiments/rq8_residual_analysis` | residual behaviour (correction vs. replacement) |
| `experiments/rq9_route_robustness` | leave-one-route-out robustness |
| `experiments/rq10_efficiency` | LLM calls, tokens and GPU time per component |
