#!/usr/bin/env bash
# Replace the /path/to/agentr placeholder in all scripts with the absolute path of this checkout.
# Usage: bash setup_paths.sh /abs/path/to/this/repo
set -euo pipefail
ROOT="${1:?usage: bash setup_paths.sh /abs/path/to/repo}"
grep -rlI "/path/to/agentr" --exclude=setup_paths.sh --exclude=README.md . | xargs -r sed -i "s|/path/to/agentr|${ROOT}|g"
echo "paths set to ${ROOT}"
