from __future__ import annotations

import math
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

from src.pipelines.metrics import ndcg_at_k, recall_at_k


TOOLS = ["graph", "collab", "semantic", "mem", "popularity", "keyword"]
EVAL_KS = [5, 10, 20, 50]


def targets(targets_map: Dict[str, Iterable[str]], uid: str) -> List[str]:
    values = targets_map.get(uid, [])
    return list(values) if values is not None else []


def dedup(items: Iterable[str], k: int) -> List[str]:
    out: List[str] = []
    seen = set()
    for iid in items:
        if iid in seen:
            continue
        out.append(str(iid))
        seen.add(iid)
        if len(out) >= k:
            break
    return out


def inv_rank(rank0: int | None) -> float:
    return 0.0 if rank0 is None else 1.0 / float(rank0 + 1)


def rank_maps(cached: Dict[str, Dict[str, List[str]]], uid: str, tools: Sequence[str], top_k: int) -> Dict[str, Dict[str, int]]:
    out: Dict[str, Dict[str, int]] = {}
    for tool in tools:
        out[tool] = {str(iid): rank0 for rank0, iid in enumerate(cached.get(tool, {}).get(uid, [])[:top_k])}
    return out


def candidate_union(cached: Dict[str, Dict[str, List[str]]], uid: str, tools: Sequence[str], top_k: int) -> List[str]:
    return dedup((iid for tool in tools for iid in cached.get(tool, {}).get(uid, [])[:top_k]), top_k * len(tools))


def eval_predictions(
    user_preds: Dict[str, List[str]],
    user_ids: Sequence[str],
    targets_map: Dict[str, Iterable[str]],
    ks: Sequence[int] = EVAL_KS,
) -> Dict[str, float]:
    rows: Dict[str, List[float]] = {f"{m}@{k}": [] for k in ks for m in ("Recall", "NDCG")}
    for uid in user_ids:
        y = targets(targets_map, uid)
        if not y:
            continue
        pred = user_preds.get(uid, [])
        for k in ks:
            rows[f"Recall@{k}"].append(recall_at_k(pred, y, k))
            rows[f"NDCG@{k}"].append(ndcg_at_k(pred, y, k))
    return {key: round(sum(vals) / max(len(vals), 1), 6) for key, vals in rows.items()}


def single_tool_metrics(cached: Dict[str, Dict[str, List[str]]], user_ids: Sequence[str], targets_map: Dict[str, Iterable[str]]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, Dict[str, float]] = {}
    for tool in TOOLS:
        preds = {uid: cached.get(tool, {}).get(uid, [])[:50] for uid in user_ids}
        out[tool] = eval_predictions(preds, user_ids, targets_map)
    return out


def equal_round_robin(cached: Dict[str, Dict[str, List[str]]], uid: str, tools: Sequence[str], final_k: int = 50) -> List[str]:
    pointers = {tool: 0 for tool in tools}
    out: List[str] = []
    seen = set()
    while len(out) < final_k:
        progressed = False
        for tool in tools:
            items = cached.get(tool, {}).get(uid, [])
            while pointers[tool] < len(items) and items[pointers[tool]] in seen:
                pointers[tool] += 1
            if pointers[tool] < len(items):
                iid = str(items[pointers[tool]])
                pointers[tool] += 1
                if iid not in seen:
                    out.append(iid)
                    seen.add(iid)
                    progressed = True
                if len(out) >= final_k:
                    break
        if not progressed:
            break
    return out


def fixed_quota_fusion(
    cached: Dict[str, Dict[str, List[str]]],
    uid: str,
    quotas: Sequence[Tuple[str, int]],
    final_k: int = 50,
) -> List[str]:
    out: List[str] = []
    seen = set()
    for tool, quota in quotas:
        added = 0
        for iid in cached.get(tool, {}).get(uid, []):
            if iid in seen:
                continue
            out.append(str(iid))
            seen.add(str(iid))
            added += 1
            if added >= quota or len(out) >= final_k:
                break
        if len(out) >= final_k:
            break
    if len(out) < final_k:
        for iid in cached.get("graph", {}).get(uid, []):
            if iid not in seen:
                out.append(str(iid))
                seen.add(str(iid))
            if len(out) >= final_k:
                break
    return out[:final_k]


def strongest_route_first_cascade(
    cached: Dict[str, Dict[str, List[str]]],
    uid: str,
    route_order: Sequence[str],
    final_k: int = 50,
) -> List[str]:
    out: List[str] = []
    seen = set()
    for tool in route_order:
        for iid in cached.get(tool, {}).get(uid, []):
            iid = str(iid)
            if iid in seen:
                continue
            out.append(iid)
            seen.add(iid)
            if len(out) >= final_k:
                return out
    return out


def load_item_meta(dataset_dir) -> Dict[str, Dict[str, Any]]:
    raw_path = dataset_dir / "item_profile_raw.csv"
    if not raw_path.exists():
        return {}
    df = pd.read_csv(raw_path)
    out: Dict[str, Dict[str, Any]] = {}
    for row in df.to_dict(orient="records"):
        iid = str(row.get("itemid"))
        brand = str(row.get("brand", "")).strip().lower()
        cats = str(row.get("categories", "")).lower().replace(">", "|").split("|")
        out[iid] = {
            "brand": brand if brand != "nan" else "",
            "categories": {c.strip() for c in cats if c.strip() and c.strip() != "nan"},
        }
    return out


def build_user_meta(dataset, item_meta: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for uid, items in dataset.user_train_items.items():
        brands: Counter[str] = Counter()
        cats: Counter[str] = Counter()
        for iid in items:
            row = item_meta.get(str(iid), {})
            brand = row.get("brand", "")
            if brand:
                brands[brand] += 1
            cats.update(row.get("categories", set()))
        out[str(uid)] = {
            "history_len": len(items),
            "brands": set(brands),
            "top_brands": {b for b, _ in brands.most_common(5)},
            "categories": set(cats),
            "top_categories": {c for c, _ in cats.most_common(8)},
        }
    return out


def candidate_features(
    iid: str,
    uid: str,
    ranks: Dict[str, Dict[str, int]],
    item_meta: Dict[str, Dict[str, Any]],
    user_meta: Dict[str, Dict[str, Any]],
    tools: Sequence[str] = TOOLS,
    top_k: int = 100,
) -> List[float]:
    values: List[float] = []
    present_count = 0
    invs: List[float] = []
    best_rank = top_k + 1
    for tool in tools:
        rank0 = ranks.get(tool, {}).get(iid)
        present = rank0 is not None
        present_count += int(present)
        inv = inv_rank(rank0)
        invs.append(inv)
        best_rank = min(best_rank, rank0 if rank0 is not None else top_k + 1)
        values.extend([
            float(present),
            inv,
            0.0 if rank0 is None else 1.0 - min(rank0 + 1, top_k) / float(top_k),
        ])
    row = item_meta.get(str(iid), {})
    um = user_meta.get(str(uid), {})
    brand = row.get("brand", "")
    cats = row.get("categories", set())
    user_cats = um.get("categories", set())
    values.extend([
        float(present_count),
        float(present_count >= 2),
        float(present_count >= 3),
        max(invs) if invs else 0.0,
        sum(invs) / max(len([x for x in invs if x > 0]), 1),
        math.log1p(float(um.get("history_len", 0))),
        float(bool(brand) and brand in um.get("brands", set())),
        float(bool(brand) and brand in um.get("top_brands", set())),
        float(len(cats & user_cats)),
        float(len(cats & um.get("top_categories", set()))),
        float(len(cats & user_cats) / max(len(cats | user_cats), 1)),
        float(best_rank),
    ])
    return values


def user_features(uid: str, user_meta: Dict[str, Dict[str, Any]], valid_single: Dict[str, Dict[str, float]] | None = None) -> List[float]:
    um = user_meta.get(str(uid), {})
    return [
        math.log1p(float(um.get("history_len", 0))),
        float(len(um.get("brands", set()))),
        float(len(um.get("top_brands", set()))),
        float(len(um.get("categories", set()))),
        float(len(um.get("top_categories", set()))),
    ]


@dataclass
class CandidateDataset:
    X: np.ndarray
    y: np.ndarray
    groups: List[int]
    rows: List[Tuple[str, str]]
    feature_names: List[str]


def build_candidate_dataset(
    cached: Dict[str, Dict[str, List[str]]],
    user_ids: Sequence[str],
    targets_map: Dict[str, Iterable[str]],
    item_meta: Dict[str, Dict[str, Any]],
    user_meta: Dict[str, Dict[str, Any]],
    tools: Sequence[str] = TOOLS,
    top_k: int = 100,
    negative_limit: int = 180,
) -> CandidateDataset:
    X: List[List[float]] = []
    y: List[int] = []
    groups: List[int] = []
    rows: List[Tuple[str, str]] = []
    for uid in user_ids:
        tgt = set(targets(targets_map, uid))
        if not tgt:
            continue
        ranks = rank_maps(cached, uid, tools, top_k)
        cands = candidate_union(cached, uid, tools, top_k)
        cands = sorted(
            cands,
            key=lambda iid: (
                -sum(1 for t in tools if iid in ranks[t]),
                min((ranks[t].get(iid, top_k + 1) for t in tools), default=top_k + 1),
                iid,
            ),
        )
        selected = cands[:negative_limit]
        for iid in cands[negative_limit:]:
            if iid in tgt and iid not in selected:
                selected.append(iid)
        if not selected:
            continue
        for iid in selected:
            X.append(candidate_features(iid, uid, ranks, item_meta, user_meta, tools, top_k))
            y.append(int(iid in tgt))
            rows.append((uid, iid))
        groups.append(len(selected))
    feature_names = [
        part
        for tool in tools
        for part in (f"{tool}_present", f"{tool}_inv_rank", f"{tool}_norm_rank")
    ] + [
        "present_count", "present_ge2", "present_ge3", "best_inv_rank", "mean_inv_rank",
        "log_history_len", "brand_overlap", "top_brand_overlap", "category_overlap",
        "top_category_overlap", "category_jaccard", "best_rank",
    ]
    return CandidateDataset(
        X=np.asarray(X, dtype=np.float32),
        y=np.asarray(y, dtype=np.int32),
        groups=groups,
        rows=rows,
        feature_names=feature_names,
    )


class MLPFusion:
    def __init__(self) -> None:
        self.scaler = StandardScaler()
        self.model = MLPClassifier(
            hidden_layer_sizes=(64, 32),
            activation="relu",
            alpha=1e-4,
            learning_rate_init=1e-3,
            max_iter=120,
            early_stopping=True,
            random_state=42,
        )

    def fit(self, X: np.ndarray, y: np.ndarray) -> "MLPFusion":
        pos_idx = np.where(y == 1)[0]
        neg_idx = np.where(y == 0)[0]
        if len(pos_idx) and len(neg_idx):
            repeat = max(1, min(40, int(len(neg_idx) / max(len(pos_idx), 1) / 2)))
            train_idx = np.concatenate([neg_idx, np.repeat(pos_idx, repeat)])
            X_train, y_train = X[train_idx], y[train_idx]
        else:
            X_train, y_train = X, y
        Xs = self.scaler.fit_transform(X_train)
        self.model.fit(Xs, y_train)
        return self

    def predict_score(self, X: np.ndarray) -> np.ndarray:
        Xs = self.scaler.transform(X)
        return self.model.predict_proba(Xs)[:, 1]


class UserAdaptiveGatingFusion:
    def __init__(self, tools: Sequence[str] = TOOLS) -> None:
        self.tools = list(tools)
        self.scaler = StandardScaler()
        self.model = MLPClassifier(
            hidden_layer_sizes=(32,),
            activation="relu",
            alpha=1e-3,
            learning_rate_init=1e-3,
            max_iter=150,
            early_stopping=True,
            random_state=42,
        )
        self.global_weights = np.ones(len(self.tools), dtype=np.float32) / max(len(self.tools), 1)

    def fit(
        self,
        cached: Dict[str, Dict[str, List[str]]],
        user_ids: Sequence[str],
        targets_map: Dict[str, Iterable[str]],
        user_meta: Dict[str, Dict[str, Any]],
    ) -> "UserAdaptiveGatingFusion":
        X: List[List[float]] = []
        y: List[int] = []
        route_hits = np.zeros(len(self.tools), dtype=np.float32)
        for uid in user_ids:
            tgt = set(targets(targets_map, uid))
            if not tgt:
                continue
            recalls = []
            for idx, tool in enumerate(self.tools):
                pred = cached.get(tool, {}).get(uid, [])[:50]
                hit = len(set(pred) & tgt) / max(len(tgt), 1)
                recalls.append(hit)
                route_hits[idx] += hit
            best = int(np.argmax(recalls))
            X.append(user_features(uid, user_meta))
            y.append(best)
        if route_hits.sum() > 0:
            self.global_weights = route_hits / route_hits.sum()
        if len(set(y)) > 1:
            self.scaler.fit(np.asarray(X, dtype=np.float32))
            self.model.fit(self.scaler.transform(np.asarray(X, dtype=np.float32)), np.asarray(y, dtype=np.int32))
        return self

    def weights(self, uid: str, user_meta: Dict[str, Dict[str, Any]]) -> np.ndarray:
        try:
            x = self.scaler.transform(np.asarray([user_features(uid, user_meta)], dtype=np.float32))
            probs = self.model.predict_proba(x)[0]
            out = np.zeros(len(self.tools), dtype=np.float32)
            for cls, prob in zip(self.model.classes_, probs):
                out[int(cls)] = float(prob)
            if out.sum() > 0:
                return out / out.sum()
        except Exception:
            pass
        return self.global_weights


def score_fusion_predictions(
    cached: Dict[str, Dict[str, List[str]]],
    user_ids: Sequence[str],
    scorer,
    item_meta: Dict[str, Dict[str, Any]],
    user_meta: Dict[str, Dict[str, Any]],
    tools: Sequence[str] = TOOLS,
    top_k: int = 100,
    final_k: int = 50,
) -> Dict[str, List[str]]:
    preds: Dict[str, List[str]] = {}
    for uid in user_ids:
        ranks = rank_maps(cached, uid, tools, top_k)
        cands = candidate_union(cached, uid, tools, top_k)
        if not cands:
            preds[uid] = []
            continue
        X = np.asarray([candidate_features(iid, uid, ranks, item_meta, user_meta, tools, top_k) for iid in cands], dtype=np.float32)
        scores = scorer.predict_score(X)
        preds[uid] = [iid for iid, _ in sorted(zip(cands, scores), key=lambda p: (-float(p[1]), p[0]))][:final_k]
    return preds


def gated_predictions(
    cached: Dict[str, Dict[str, List[str]]],
    user_ids: Sequence[str],
    gate: UserAdaptiveGatingFusion,
    user_meta: Dict[str, Dict[str, Any]],
    tools: Sequence[str] = TOOLS,
    top_k: int = 100,
    final_k: int = 50,
) -> Dict[str, List[str]]:
    preds: Dict[str, List[str]] = {}
    for uid in user_ids:
        weights = gate.weights(uid, user_meta)
        scores: Dict[str, float] = defaultdict(float)
        best_rank: Dict[str, int] = {}
        for t_idx, tool in enumerate(tools):
            for rank0, iid in enumerate(cached.get(tool, {}).get(uid, [])[:top_k]):
                iid = str(iid)
                scores[iid] += float(weights[t_idx]) * inv_rank(rank0)
                best_rank[iid] = min(best_rank.get(iid, 10**9), rank0)
        preds[uid] = [iid for iid, _ in sorted(scores.items(), key=lambda kv: (-kv[1], best_rank.get(kv[0], 10**9), kv[0]))][:final_k]
    return preds
