#!/usr/bin/env python3
"""Planner stage 1: build per-user deterministic coordination diagnostics (NO labels).

The Planner is a low-dim coordination-policy generator. It sees ONLY:
  - user history summary (length, category focus)
  - current retrieval outputs / overlap statistics for THIS user (per-tool pool coverage,
    mean route rank quality, cross-path agreement distribution, base-slate coherence)
  - validation-level tool diagnostics (global single-tool Recall@50) -- same for all users
It never sees held-out targets. Output: artifacts/planner_ctx_<ds>.pkl = list of
{userid, split, ctx(dict)}. Both valid + test users (valid only used if a hybrid beta
is ever tuned; planner_conditioned eval uses test).
"""
from __future__ import annotations
import argparse, json, pickle, sys
from collections import Counter
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pcr_common import (ROOT, AUX_TOOLS, AUX_K, DATASETS, load_dataset, build_pool,
                        single_tool_metrics)


def user_ctx(cached, uid, keep, item_meta, user_meta, tool_valid):
    gi, pool, sources, ranks = build_pool(cached, uid, keep)
    um = user_meta.get(str(uid), {})
    hist_len = int(um.get("history_len", 0))
    ucats = um.get("categories", set())
    # per-tool coverage of this user's pool + mean route inv-rank
    tool_cov = {}
    for m in AUX_TOOLS:
        invs = [1.0 / (ranks[i][m] + 1.0) for i in pool if m in ranks.get(i, {})]
        tool_cov[m] = {"n_in_pool": len(invs),
                       "mean_inv_rank": round(float(np.mean(invs)), 4) if invs else 0.0}
    supp = [len(sources.get(i, [])) for i in pool]
    agr_ge3 = float(np.mean([s >= 3 for s in supp])) if supp else 0.0
    # base slate coherence: mean cat-jaccard of graph top-10 with history categories
    coh = []
    for i in gi[:10]:
        cats = item_meta.get(str(i), {}).get("categories", set())
        coh.append(len(cats & ucats) / max(len(cats | ucats), 1))
    base_coh = round(float(np.mean(coh)), 4) if coh else 0.0
    return {
        "history_len": hist_len,
        "pool_size": len(pool),
        "cross_path_support_ge3_frac": round(agr_ge3, 4),
        "base_slate_category_coherence": base_coh,
        "per_tool": tool_cov,
        "validation_tool_recall50": {m: round(tool_valid[m], 5) for m in AUX_TOOLS},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    ds = args.dataset
    D = load_dataset(ds); keep = D["spec"]["keep"]
    cached, item_meta, user_meta, dataset = D["cached"], D["item_meta"], D["user_meta"], D["dataset"]
    valid_users = sorted(dataset.user_valid_items)
    test_users = sorted(dataset.user_test_items)
    vmet = single_tool_metrics(cached, valid_users, dataset.user_valid_items)
    tool_valid = {t: vmet.get(t, {}).get("Recall@50", 0.0) for t in AUX_TOOLS}
    rows = []
    for split, users in (("test", test_users), ("valid", valid_users)):
        for uid in users:
            rows.append({"userid": uid, "split": split,
                         "ctx": user_ctx(cached, uid, keep, item_meta, user_meta, tool_valid)})
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    pickle.dump(rows, open(args.out, "wb"))
    print(f"[{ds}] built {len(rows)} planner contexts -> {args.out}")


if __name__ == "__main__":
    main()
