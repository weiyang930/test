#!/usr/bin/env python3
"""Offline (CPU) stage: original + prior_only + static baselines + calibration study.

For each dataset produces per-user Recall/NDCG arrays for every deterministic mode,
plus diagnostics. Validation is used ONLY to (a) fit per-channel isotonic calibrators,
(b) derive validation single-tool strength, (c) select the prior_only weight variant.
Test labels are never used for any tuning. Writes artifacts/offline_<ds>.pkl + json.
"""
from __future__ import annotations
import argparse, json, pickle, sys
from collections import Counter
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pcr_common import (  # noqa
    ROOT, AUX_TOOLS, AUX_K, K, FINAL_K, CHANNELS, CH_ROUTE, DATASETS, REPRO_ANCHOR,
    load_dataset, logreg_score, build_pool, build_soft_pool, evidence_matrix,
    fit_calibrators, apply_calibrators, paired_bootstrap, recall_at_k, ndcg_at_k,
    feature_vector, compose_final, single_tool_metrics,
)


def make_state(cached, uid, keep, sources_fn, item_meta, user_meta, blob):
    gi, pool, sources, ranks = sources_fn(cached, uid, keep)
    E = evidence_matrix(pool, uid, gi, sources, ranks, item_meta, user_meta)
    # logreg features (30-d) for the ORIGINAL scorer, aligned to pool
    if pool and blob is not None:
        Xf = np.asarray([feature_vector(i, uid, gi, sources, ranks, AUX_TOOLS, AUX_K,
                                        keep, item_meta, user_meta) for i in pool], dtype=np.float32)
        lg = logreg_score(blob, Xf)
    else:
        # blob is None for new _dg datasets (no legacy logreg): the "original" mode is skipped in main.
        lg = np.zeros(len(pool))
    return dict(gi=gi, pool=pool, sources=sources, ranks=ranks, E=E, lg=lg)


def rank_by_score(pool, scores):
    return [i for i, _ in sorted(zip(pool, scores), key=lambda p: (-float(p[1]), p[0]))]


def eval_mode(states, users, tmap, keep, budget, score_fn):
    """score_fn(state)->scores over state['pool']; returns arrays + diagnostics."""
    RA5, NA5, RA10, NA10 = [], [], [], []
    n_rescued, src_sel, src_hit = [], Counter(), Counter()
    base_hit_users = base_hit_preserved = 0
    recoverable_users = recovered = 0
    for uid in users:
        tg = [str(t) for t in tmap.get(uid, [])]
        if not tg:
            continue
        st = states[uid]; gi, pool = st["gi"], st["pool"]
        tset = set(tg)
        base_top = gi[:K]
        base_hit = any(t in tset for t in base_top)
        pool_has_target = any(i in tset for i in pool)
        if budget <= 0 or not pool:
            ranked = []
        else:
            ranked = rank_by_score(pool, score_fn(st))
        preds = compose_final(gi, ranked, keep, budget, FINAL_K)
        pset = set(preds)
        RA5.append(recall_at_k(preds, tg, 50)); NA5.append(ndcg_at_k(preds, tg, 50))
        RA10.append(recall_at_k(preds, tg, 10)); NA10.append(ndcg_at_k(preds, tg, 10))
        sel = [i for i in ranked[:budget]] if (budget > 0 and pool) else []
        n_rescued.append(len(sel))
        for i in sel:
            key = "+".join(st["sources"].get(i, [])) or "none"
            src_sel[key] += 1
            if i in tset:
                src_hit[key] += 1
        if base_hit:
            base_hit_users += 1
            if any(t in pset for t in tg):
                base_hit_preserved += 1
        if (not base_hit) and pool_has_target:
            recoverable_users += 1
            if any(t in pset for t in tg):
                recovered += 1
    return dict(
        R50=np.asarray(RA5), N50=np.asarray(NA5), R10=np.asarray(RA10), N10=np.asarray(NA10),
        mean_rescued=float(np.mean(n_rescued)) if n_rescued else 0.0,
        base_hit_preservation=(base_hit_preserved / base_hit_users) if base_hit_users else 1.0,
        recoverable_recovery=(recovered / recoverable_users) if recoverable_users else 0.0,
        recoverable_users=recoverable_users, base_hit_users=base_hit_users,
        src_selected=dict(src_sel.most_common(20)), src_hit=dict(src_hit.most_common(20)),
    )


def weighted_scorer(w, calibrated, cals=None):
    w = np.asarray(w, dtype=np.float64)
    def _fn(st):
        E = st["E"]
        if E.shape[0] == 0:
            return np.zeros(0)
        H = apply_calibrators(E, cals) if calibrated else E
        return H @ w
    return _fn


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    ds = args.dataset
    D = load_dataset(ds)
    spec = D["spec"]; keep, budget = spec["keep"], spec["budget"]
    cached, blob = D["cached"], D["blob"]
    item_meta, user_meta = D["item_meta"], D["user_meta"]
    dataset = D["dataset"]
    valid_users = sorted(dataset.user_valid_items)
    test_users = sorted(dataset.user_test_items)
    vmap = {u: [str(x) for x in v] for u, v in dataset.user_valid_items.items()}
    tmap = {u: [str(x) for x in v] for u, v in dataset.user_test_items.items()}

    # validation single-tool strength (for val_strength weights)
    vmet = single_tool_metrics(cached, valid_users, dataset.user_valid_items)
    tool_valid = {t: vmet.get(t, {}).get("Recall@50", 0.0) for t in AUX_TOOLS}

    # ---- build states (HARD pool = original) for valid+test ----
    print(f"[{ds}] building HARD-pool states...", flush=True)
    hv = {u: make_state(cached, u, keep, build_pool, item_meta, user_meta, blob) for u in valid_users}
    ht = {u: make_state(cached, u, keep, build_pool, item_meta, user_meta, blob) for u in test_users}

    # ---- fit isotonic calibrators on VALIDATION hard pool ----
    E_list, y_list = [], []
    for u in valid_users:
        st = hv[u]; tg = set(vmap.get(u, []))
        if not st["pool"] or not tg:
            continue
        E_list.append(st["E"]); y_list.append(np.array([float(i in tg) for i in st["pool"]]))
    cals = fit_calibrators(E_list, y_list)

    # ---- weight variants ----
    nch = len(CHANNELS)
    w_equal = np.ones(nch)
    # val_strength: scale route channels by normalized valid recall (mean->1), rest =1
    rvals = np.array([tool_valid[t] for t in AUX_TOOLS])
    rscale = rvals / (rvals.mean() + 1e-9)
    w_valstr = np.ones(nch); w_valstr[:len(AUX_TOOLS)] = rscale

    def logreg_fn(st):
        return st["lg"]

    has_lg = blob is not None      # legacy learned-rescue logreg present? (False for new _dg datasets)
    modes = {
        "no_rescue":       ("hard", lambda st: np.zeros(len(st["pool"])), 0),
        **({"original":    ("hard", logreg_fn, budget)} if has_lg else {}),
        "prior_equal_raw": ("hard", weighted_scorer(w_equal, calibrated=False), budget),
        "prior_equal_cal": ("hard", weighted_scorer(w_equal, calibrated=True, cals=cals), budget),
        "prior_valstr_cal":("hard", weighted_scorer(w_valstr, calibrated=True, cals=cals), budget),
        "equal_weights":   ("hard", weighted_scorer(w_equal, calibrated=False), budget),  # section 9 static
        "val_strength":    ("hard", weighted_scorer(w_valstr, calibrated=False), budget),
    }

    results = {"dataset": ds, "policy": dict(keep=keep, budget=budget, aux=AUX_TOOLS),
               "tool_valid_recall50": tool_valid, "channels": CHANNELS,
               "calibrated_prior_weights": {"equal": w_equal.tolist(), "valstr": w_valstr.tolist()},
               "valid": {}, "test": {}, "per_user_R50": {}}

    for name, (pool_kind, fn, bud) in modes.items():
        sv = hv; st_test = ht
        ev = eval_mode(sv, valid_users, vmap, keep, bud, fn)
        et = eval_mode(st_test, test_users, tmap, keep, bud, fn)
        results["valid"][name] = {"R50": float(ev["R50"].mean()), "R10": float(ev["R10"].mean()),
                                  "N50": float(ev["N50"].mean())}
        results["test"][name] = {
            "R50": float(et["R50"].mean()), "N50": float(et["N50"].mean()),
            "R10": float(et["R10"].mean()), "N10": float(et["N10"].mean()),
            "mean_rescued": et["mean_rescued"],
            "base_hit_preservation": et["base_hit_preservation"],
            "recoverable_recovery": et["recoverable_recovery"],
            "recoverable_users": et["recoverable_users"], "base_hit_users": et["base_hit_users"],
            "src_selected": et["src_selected"], "src_hit": et["src_hit"],
        }
        results["per_user_R50"][name] = et["R50"].tolist()
        print(f"[{ds}] {name:18s} validR50={results['valid'][name]['R50']:.6f} "
              f"testR50={results['test'][name]['R50']:.6f} "
              f"prsv={et['base_hit_preservation']:.3f} rec={et['recoverable_recovery']:.3f}", flush=True)

    # ---- reproduction gate (legacy: only when the logreg "original" mode exists) ----
    if has_lg:
        anchor = REPRO_ANCHOR[ds]
        got = results["test"]["original"]["R50"]
        results["reproduction_gate"] = {"recomputed_R50": got, "anchor_R50": anchor,
                                        "abs_err": abs(got - anchor), "pass_5e-3": abs(got - anchor) <= 5e-3}
    else:
        results["reproduction_gate"] = {"skipped": "no legacy logreg scorer (new _dg dataset)"}

    # ---- select best prior_only variant by VALIDATION R50 ----
    prior_variants = ["prior_equal_raw", "prior_equal_cal", "prior_valstr_cal"]
    best = max(prior_variants, key=lambda m: results["valid"][m]["R50"])
    results["prior_only_selected"] = best

    # ---- retention (test): only meaningful relative to the legacy original scorer ----
    nr = results["test"]["no_rescue"]["R50"]
    if has_lg:
        og = results["test"]["original"]["R50"]
        def retention(m):
            g = results["test"][m]["R50"] - nr
            return g / (og - nr) if (og - nr) != 0 else float("nan")
        results["retention_test"] = {m: retention(m) for m in
                                     prior_variants + ["equal_weights", "val_strength"]}
    else:
        results["retention_test"] = {"skipped": "no legacy logreg scorer (new _dg dataset)"}

    # ---- paired bootstrap vs original (if present) & vs no_rescue for prior variants ----
    R_orig = np.asarray(results["per_user_R50"]["original"]) if has_lg else None
    R_nr = np.asarray(results["per_user_R50"]["no_rescue"])
    results["bootstrap_test"] = {}
    for m in prior_variants + ["equal_weights", "val_strength"]:
        Rm = np.asarray(results["per_user_R50"][m])
        dvn = Rm - R_nr
        mn, lon, hin = paired_bootstrap(dvn)
        entry = {"vs_no_rescue": {"delta": mn, "ci": [lon, hin], "sig": bool(lon > 0 or hin < 0)}}
        if has_lg:
            dvo = Rm - R_orig
            mo, lo, hi = paired_bootstrap(dvo)
            entry["vs_original"] = {"delta": mo, "ci": [lo, hi], "sig": bool(lo > 0 or hi < 0)}
        results["bootstrap_test"][m] = entry

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w") as fh:
        json.dump(results, fh, indent=2)
    g = results["reproduction_gate"]
    if has_lg:
        print(f"[{ds}] GATE original={g['recomputed_R50']:.6f} anchor={g['anchor_R50']} "
              f"err={g['abs_err']:.2e} pass={g['pass_5e-3']}")
        print(f"[{ds}] prior_only_selected={best} retention="
              f"{results['retention_test'][best]:.3f}  wrote {args.out}")
    else:
        print(f"[{ds}] GATE skipped (no legacy logreg scorer) | "
              f"prior_only_selected={best}  wrote {args.out}")


if __name__ == "__main__":
    main()
