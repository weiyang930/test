#!/usr/bin/env python3
"""Planner-Conditioned Rescue -- shared library (offline, CPU).

Conceptual goal (see task spec): replace the *independent learned* rescue scorer
g_theta with a **deterministic executor** whose score is specified by a low-dim
coordination policy pi_u = (base, aux, keep, aux_depth, budget, alpha_u, lambda_u).

The candidate POOL, retrieval evidence, budget and downstream compose() are held
BYTE-IDENTICAL to the original Agent-R rescue operator (imported verbatim from
scripts/eval_learned_rescue_controller.py). Only the per-candidate *scoring* rule
changes between rescue modes:

  rescue_mode = original            -> frozen logreg g_theta  (linear, reproduces paper)
  rescue_mode = prior_only          -> additive s(i)=sum_j w_j h_j(e_j), fixed validated prior
  rescue_mode = planner_conditioned -> same executor, w_u = Normalize(prior (x) delta_u), delta from LLM
  rescue_mode = equal_weights       -> additive, uniform weights (static baseline)
  rescue_mode = val_strength        -> additive, weights (x) validation single-tool strength

Evidence channels e_j (all already available to original g_theta):
  q_m(i)   route evidence per aux tool m   = inv_rank 1/(rank0+1)   (0 if tool m didn't retrieve i)
  a(i)     cross-path support              = n_aux_sources(i)/|A_u|
  p_u(i)   user-preference compatibility   = category_jaccard(item, user history)   (+ brand match)

Per-channel calibration h_j (Stage A / section 7): each channel is mapped, INDEPENDENTLY,
to its empirical positive rate on VALIDATION via isotonic regression. This is a univariate
statistic per channel -- NOT a multivariate classifier -- so it stays within the conceptual
boundary. Prior weights are validation-derived, low-dimensional, and NOT jointly optimised
against labels the way g_theta is.
"""
from __future__ import annotations

import os
import sys
import pickle
import warnings
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

warnings.filterwarnings("ignore")

ROOT = Path("/path/to/agentr")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.common.artifacts import ArtifactManager
from src.common.config import load_config
from src.data.dataset import DatasetLoader
from src.pipelines.metrics import recall_at_k, ndcg_at_k
from scripts.eval_learned_rescue_controller import (
    candidate_sources, feature_vector, compose_final, load_item_meta, build_user_meta,
)
from baselines.multiroute_fusion import single_tool_metrics

# ------------------------------------------------------------------ deployed policy
AUX_TOOLS = ["semantic", "mem", "collab", "popularity"]  # deployed Agent-R aux set
AUX_K = 100
MIN_AUX_SOURCES = 2       # HARD agreement gate in the ORIGINAL pool construction
POOL_LIMIT = 160
FINAL_K = 50
K = 50

# deployed per-dataset policy (from exp7/exp9/reproduce_table1)
DATASETS = {
    "Music_10_80_r811":      dict(cfg="configs/music_10_80_r811_tool_only.yaml",      keep=35, budget=15,
                                  scorer="learned_rescue_all_no_keyword_keep35_rescue15_minsrc2_logreg.pkl"),
    "Game_10_80_r811":       dict(cfg="configs/game_10_80_r811_tool_only.yaml",       keep=40, budget=10,
                                  scorer="learned_rescue_all_no_keyword_keep40_rescue10_minsrc2_logreg.pkl"),
    "Software_10_80_r811":   dict(cfg="configs/software_10_80_r811_tool_only.yaml",   keep=40, budget=10,
                                  scorer="learned_rescue_all_no_keyword_keep40_rescue10_minsrc2_logreg.pkl"),
    "Industrial_10_80_r811": dict(cfg="configs/industrial_10_80_r811_tool_only.yaml", keep=40, budget=10,
                                  scorer="learned_rescue_all_no_keyword_keep40_rescue10_minsrc2_logreg.pkl"),
    # --- 2026-09-25 fulltest all-dataset sweep: new _dg datasets. No legacy learned-rescue logreg
    #     scorer exists for these (they never went through the original paper pipeline), so scorer=None
    #     -> load_dataset sets blob=None and run_offline skips the legacy "original"/repro-gate modes.
    #     The MODERN pipeline (prior_only / planner_conditioned executor) never uses the logreg. Policy
    #     keep=40/budget=10 is the deployed default (3/4 finalized datasets); NOT tuned per-dataset.
    "Adressa_dg":     dict(cfg="configs/adressa_dg_tool_only.yaml",     keep=40, budget=10, scorer=None),
    "DoubanBook_dg":  dict(cfg="configs/doubanbook_dg_tool_only.yaml",  keep=40, budget=10, scorer=None),
    "DoubanMusic_dg": dict(cfg="configs/doubanmusic_dg_tool_only.yaml", keep=40, budget=10, scorer=None),
    "KuaiRec_dg":     dict(cfg="configs/kuairec_dg_tool_only.yaml",     keep=40, budget=10, scorer=None),
    "MicroLens_dg":   dict(cfg="configs/microlens_dg_tool_only.yaml",   keep=40, budget=10, scorer=None),
}

# candidate-set repro anchors (exp7 matched-budget P4) + paper Table-1 for reference
REPRO_ANCHOR = {  # candidate-set Recall@50 of on-disk Agent-R (exp7 P4)
    "Music_10_80_r811": 0.09513, "Game_10_80_r811": 0.12111,
    "Software_10_80_r811": 0.29527, "Industrial_10_80_r811": 0.08399,
}

# evidence channel names (additive executor)
CH_ROUTE = [f"q_{m}" for m in AUX_TOOLS]      # per-aux-tool inv-rank
CH_AGR = "agr"                                 # normalized cross-path support
CH_PREF = "pref"                               # category jaccard
CH_PREF2 = "pref_topcat"                       # top-category overlap (count)
CH_GRAPHTAIL = "graphtail"                     # candidate's inv-rank in base(graph) tail (Stage-C)
CH_BRAND = "brand"                             # item brand in user history brands (Stage-C)
CHANNELS = CH_ROUTE + [CH_AGR, CH_PREF, CH_PREF2, CH_GRAPHTAIL, CH_BRAND]

# planner delta maps each CHANNEL group; the LLM addresses these keys:
#   source_trust: one of the 4 aux tools -> scales q_<tool>
#   evidence_weights.cross_path_support -> scales agr
#   evidence_weights.user_preference_match -> scales pref, pref_topcat, brand
#   (graphtail is a fixed prior channel, not planner-controlled)
PLANNER_KEYS = AUX_TOOLS + ["cross_path_support", "user_preference_match"]


# ------------------------------------------------------------------ data loading
def load_dataset(ds):
    spec = DATASETS[ds]
    cfg = load_config(spec["cfg"])
    art = ArtifactManager(project_root=ROOT, dataset_name=ds)
    dataset = DatasetLoader(cfg.dataset, art).load()
    # AGENTR_TOOLCACHE_SUFFIX (default "") selects an ALTERNATE combined route cache without touching
    # the default one -- exp16 sets it to "_modern" to feed the modern heterogeneous route bank
    # (precomputed_tool_cache_modern.pkl: graph<-DEV-winner of {NCL,DiffRec}, collab<-other,
    # semantic<-Qwen3-Embedding, mem/popularity<-reused). Mirrors AGENTR_FROZEN_SUFFIX. Same schema
    # (dict{route: {uid(str): [item_id str]}}) so nothing downstream changes structurally.
    _tc_suffix = os.environ.get("AGENTR_TOOLCACHE_SUFFIX", "")
    cached = pickle.load(open(ROOT / f"outputs/results/{ds}/precomputed_tool_cache{_tc_suffix}.pkl", "rb"))
    # legacy learned-rescue logreg scorer is OPTIONAL: new _dg datasets have scorer=None (never went
    # through the original paper pipeline). The modern prior_only/planner_conditioned executor never
    # uses it; run_offline guards the legacy "original" mode when blob is None.
    _scorer = spec.get("scorer")
    blob = pickle.load(open(ROOT / f"outputs/results/{ds}/{_scorer}", "rb")) if _scorer else None
    item_meta = load_item_meta(Path(cfg.dataset.data_dir) / ds)
    user_meta = build_user_meta(dataset, item_meta)
    return dict(spec=spec, cfg=cfg, dataset=dataset, cached=cached, blob=blob,
                item_meta=item_meta, user_meta=user_meta)


def logreg_score(blob, X):
    """Reproduce the frozen LogisticRegression ranking via raw logit (sklearn-version safe).
    sigmoid is monotonic so ordering == predict_proba ordering, ties identical."""
    m = blob["model"]
    return X.astype(np.float64) @ m.coef_[0] + float(m.intercept_[0])


# ------------------------------------------------------------------ per-user state
def build_pool(cached, uid, graph_keep):
    """EXACTLY the original pool: min_aux_sources>=2 gate, deterministic sort, POOL_LIMIT."""
    gi = cached.get("graph", {}).get(uid, [])
    cands, sources, ranks = candidate_sources(cached, uid, gi, graph_keep,
                                              AUX_TOOLS, AUX_K, MIN_AUX_SOURCES)
    cands = sorted(cands, key=lambda i: (-len(sources.get(i, [])),
                                         min(ranks.get(i, {}).values(), default=10**9), i))[:POOL_LIMIT]
    return gi, cands, sources, ranks


def build_soft_pool(cached, uid, graph_keep):
    """SOFT-agreement pool for the new mode: union of aux top-K minus base, NO min_src gate.
    (agreement becomes a soft evidence channel, not a hard filter -- section 5)."""
    gi = cached.get("graph", {}).get(uid, [])
    cands, sources, ranks = candidate_sources(cached, uid, gi, graph_keep,
                                              AUX_TOOLS, AUX_K, 1)  # min_src=1 => no hard gate
    cands = sorted(cands, key=lambda i: (-len(sources.get(i, [])),
                                         min(ranks.get(i, {}).values(), default=10**9), i))[:POOL_LIMIT]
    return gi, cands, sources, ranks


def evidence_matrix(pool, uid, gi, sources, ranks, item_meta, user_meta):
    """Return (n_pool, n_channels) raw evidence matrix aligned to `pool`."""
    um = user_meta.get(str(uid), {})
    ucats = um.get("categories", set()); utopcats = um.get("top_categories", set())
    ubrands = um.get("brands", set())
    graph_rank = {iid: r for r, iid in enumerate(gi)}
    na = len(AUX_TOOLS)
    E = np.zeros((len(pool), len(CHANNELS)), dtype=np.float64)
    for r, iid in enumerate(pool):
        rk = ranks.get(iid, {})
        for c, m in enumerate(AUX_TOOLS):
            if m in rk:
                E[r, c] = 1.0 / (rk[m] + 1.0)          # q_m inv-rank
        E[r, na] = len(sources.get(iid, [])) / na       # a(i) cross-path support
        im = item_meta.get(str(iid), {})
        cats = im.get("categories", set())
        E[r, na + 1] = len(cats & ucats) / max(len(cats | ucats), 1)   # cat jaccard
        E[r, na + 2] = float(len(cats & utopcats))                     # top-cat overlap count
        gr = graph_rank.get(iid)
        E[r, na + 3] = 1.0 / (gr + 1.0) if gr is not None else 0.0     # graph-tail inv-rank
        brand = im.get("brand", "unknown")
        E[r, na + 4] = float(brand in ubrands and brand != "unknown")  # brand match
    return E


# ------------------------------------------------------------------ isotonic calibration
def fit_calibrators(E_list, y_list):
    """Per-channel isotonic h_j: value -> P(pos), fit on VALIDATION pooled candidates."""
    from sklearn.isotonic import IsotonicRegression
    E = np.vstack(E_list) if E_list else np.zeros((0, len(CHANNELS)))
    y = np.concatenate(y_list) if y_list else np.zeros(0)
    cals = []
    for c in range(len(CHANNELS)):
        col = E[:, c]
        if len(col) == 0 or col.max() == col.min():
            cals.append(None); continue
        ir = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        ir.fit(col, y)
        cals.append(ir)
    return cals


def apply_calibrators(E, cals):
    H = np.zeros_like(E)
    for c in range(E.shape[1]):
        if cals[c] is None:
            H[:, c] = E[:, c]
        else:
            H[:, c] = cals[c].predict(E[:, c])
    return H


# ------------------------------------------------------------------ metrics helpers
def paired_bootstrap(d, seed=42, n_boot=10000):
    d = np.asarray(d, dtype=np.float64)
    n = len(d)
    if n == 0:
        return 0.0, 0.0, 0.0
    rng = np.random.default_rng(seed)
    means = np.array([d[rng.integers(0, n, n)].mean() for _ in range(n_boot)])
    lo, hi = np.percentile(means, [2.5, 97.5])
    return float(d.mean()), float(lo), float(hi)
