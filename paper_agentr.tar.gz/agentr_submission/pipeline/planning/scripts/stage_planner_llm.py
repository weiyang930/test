#!/usr/bin/env python
"""Planner stage 2: LLM coordination-policy generator (vLLM Qwen2.5-7B, sharded).

For each user the Planner reads deterministic coordination diagnostics and returns a
CONSTRAINED intervention policy: discrete {down,neutral,up} trust for each aux route and
for two evidence channels. It does NOT select items and does NOT emit continuous numbers.

Parse failure / invalid -> neutral policy (== validated prior, section 15).
Sharded across GPUs: CUDA pinned to SLURM_LOCALID; shard=SLURM_PROCID/SLURM_NTASKS.
Writes one pkl per shard: list of {userid, split, delta(dict), parse_ok}.
"""
import os, sys, json, pickle, argparse, re

def env_int(k, d):
    try: return int(os.environ.get(k, d))
    except: return d

local_id = env_int("SLURM_LOCALID", env_int("LOCAL_ID", 0))
if "CUDA_VISIBLE_DEVICES" not in os.environ or os.environ.get("PIN_LOCAL", "1") == "1":
    os.environ["CUDA_VISIBLE_DEVICES"] = str(local_id)
proc_id = env_int("SLURM_PROCID", env_int("SHARD", 0))
ntasks = env_int("SLURM_NTASKS", env_int("NSHARDS", 1))

AUX_TOOLS = ["semantic", "mem", "collab", "popularity"]
LEVELS = {"down", "neutral", "up"}

SYS = (
    "You are the Coordination Planner in a multi-route recommender system. You are NOT "
    "selecting recommendation items. You define a constrained INTERVENTION POLICY that a "
    "deterministic executor will apply to a large candidate pool built from several "
    "auxiliary retrieval routes on top of a strong base retriever.\n\n"
    "Your job: decide how much to TRUST each auxiliary route and each evidence channel for "
    "THIS user, given the diagnostics. A validated default policy already exists (all "
    "'neutral'); you only output bounded adjustments. Raise a route/channel to 'up' when the "
    "diagnostics suggest it is especially reliable/complementary for this user; lower it to "
    "'down' when it looks noisy or redundant; otherwise 'neutral'. Be conservative -- prefer "
    "'neutral' unless the diagnostics clearly justify a change.\n\n"
    "Guidance:\n"
    "- A route with high validation_tool_recall50 and strong per-user mean_inv_rank is more trustworthy.\n"
    "- cross_path_support (agreement across routes) is more reliable when many pool items are "
    "supported by 3+ routes.\n"
    "- user_preference_match (category/brand compatibility) matters more when the base slate is "
    "already category-coherent and history is rich.\n"
    "- Down-weight a route that contributes few pool items or has weak validation strength.\n\n"
    "Return ONLY a compact JSON object, nothing else:\n"
    '{"source_trust":{"semantic":"neutral","mem":"neutral","collab":"neutral","popularity":"neutral"},'
    '"evidence_weights":{"cross_path_support":"neutral","user_preference_match":"neutral"}}'
)

def build_user_prompt(ctx):
    return ("User coordination diagnostics:\n" + json.dumps(ctx, ensure_ascii=False) +
            "\n\nReturn the intervention policy JSON only.")

def parse_delta(text):
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None, False
    try:
        o = json.loads(m.group(0))
    except Exception:
        return None, False
    st = o.get("source_trust", {}); ew = o.get("evidence_weights", {})
    delta = {}
    ok = True
    for t in AUX_TOOLS:
        v = str(st.get(t, "neutral")).lower()
        if v not in LEVELS: v = "neutral"; ok = False
        delta[t] = v
    for c in ("cross_path_support", "user_preference_match"):
        v = str(ew.get(c, "neutral")).lower()
        if v not in LEVELS: v = "neutral"; ok = False
        delta[c] = v
    return delta, ok

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ctx", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--split", default="test", choices=["test", "valid", "both"])
    ap.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--max-model-len", type=int, default=4096)
    ap.add_argument("--gpu-mem", type=float, default=0.90)
    args = ap.parse_args()

    rows = pickle.load(open(args.ctx, "rb"))
    if args.split != "both":
        rows = [r for r in rows if r["split"] == args.split]
    rows = [r for i, r in enumerate(rows) if i % ntasks == proc_id]
    print(f"[shard {proc_id}/{ntasks}] CUDA={os.environ.get('CUDA_VISIBLE_DEVICES')} "
          f"n={len(rows)} split={args.split}", flush=True)

    from vllm import LLM, SamplingParams
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(args.model)
    llm = LLM(model=args.model, dtype="bfloat16", max_model_len=args.max_model_len,
              gpu_memory_utilization=args.gpu_mem, enforce_eager=True, disable_log_stats=True)
    sp = SamplingParams(temperature=0.0, max_tokens=160)

    prompts = []
    for r in rows:
        msg = [{"role": "system", "content": SYS},
               {"role": "user", "content": build_user_prompt(r["ctx"])}]
        prompts.append(tok.apply_chat_template(msg, tokenize=False, add_generation_prompt=True))
    outs = llm.generate(prompts, sp)
    res = []
    for r, o in zip(rows, outs):
        txt = o.outputs[0].text
        delta, ok = parse_delta(txt)
        if delta is None:
            delta = {k: "neutral" for k in AUX_TOOLS + ["cross_path_support", "user_preference_match"]}
            ok = False
        res.append({"userid": r["userid"], "split": r["split"], "delta": delta, "parse_ok": bool(ok)})
    outp = f"{args.out}.shard{proc_id}.pkl"
    pickle.dump(res, open(outp, "wb"))
    pk = sum(x["parse_ok"] for x in res)
    print(f"[shard {proc_id}] parse_ok={pk}/{len(res)} -> {outp}", flush=True)

if __name__ == "__main__":
    main()
