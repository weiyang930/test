#!/usr/bin/env python3
"""exp16 -- Qwen3-Embedding semantic retrieval route -> toolcache_semantic_qwen3.pkl (recbole_cache_v2).

Modern semantic route replacing the e5-base-v2 route. Items are DOCUMENTS (title+category+brand);
each user is a QUERY built from their recent train-history titles + the retrieval instruction (Qwen3
is an instruction embedding model with query/doc asymmetry). Cosine top-200 over all items, masking
ONLY train-seen items (same convention as the RecBole routes -> valid & test both rankable).

Pooling: Qwen3-Embedding uses LEFT padding + last-token (EOS) pooling, then L2 normalize (official
recipe). Output schema matches the RecBole toolcaches so assemble_modern_cache.py treats it uniformly.

Usage:
  python build_semantic_route.py --ds Software_10_80_r811 \
    --model Qwen/Qwen3-Embedding-4B --tool semantic_qwen3 --gpu 0
"""
from __future__ import annotations
import argparse, csv, json, math, pickle, sys, time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

csv.field_size_limit(sys.maxsize)   # item_profile_raw.csv descriptions can exceed the 128KB default

REPO = Path(__file__).resolve().parents[3]
DEFAULT_OUT = Path(__file__).resolve().parents[1] / "artifacts" / "route_cache"
INSTRUCT = ("Given a user's recent interaction history, retrieve items the user will interact with next")


def item_text(row):
    t = (row.get("title") or "").strip()
    cat = (row.get("categories") or "").strip()
    brand = (row.get("brand") or "").strip()
    parts = [f"Title: {t}" if t else ""]
    if cat and cat.lower() != "unknown":
        parts.append(f"Category: {cat}")
    if brand and brand.lower() != "unknown":
        parts.append(f"Brand: {brand}")
    return ". ".join(p for p in parts if p) or f"item {row.get('itemid')}"


def load_meta(ds):
    meta = {}
    with open(REPO / "data" / ds / "item_profile_raw.csv") as f:
        for row in csv.DictReader(f):
            meta[str(row["itemid"])] = item_text(row)
    return meta


def load_splits(ds, max_hist):
    """train history (ordered by time) per user, valid/test targets."""
    rows = []
    with open(REPO / "data" / ds / "interaction.csv") as f:
        for row in csv.DictReader(f):
            rows.append((str(row["userid"]), str(row["itemid"]), float(row["timestamp"]), str(row["label"])))
    hist = defaultdict(list)
    valid, test = {}, {}
    for u, i, ts, lab in rows:
        if lab == "0":
            hist[u].append((ts, i))
        elif lab == "1":
            valid[u] = i
        elif lab == "2":
            test[u] = i
    hist = {u: [i for _, i in sorted(v)][-max_hist:] for u, v in hist.items()}
    return hist, valid, test


@torch.no_grad()
def encode(texts, tok, model, device, max_len, batch, is_query):
    """Qwen3-Embedding: left-pad, last-token pool, L2-norm. Queries get the instruct prefix."""
    if is_query:
        texts = [f"Instruct: {INSTRUCT}\nQuery: {t}" for t in texts]
    embs = []
    t0 = time.time()
    for s in range(0, len(texts), batch):
        chunk = texts[s:s + batch]
        enc = tok(chunk, padding=True, truncation=True, max_length=max_len, return_tensors="pt").to(device)
        out = model(**enc)
        h = out.last_hidden_state
        # left padding -> last token is at position -1
        emb = h[:, -1]
        emb = torch.nn.functional.normalize(emb.float(), p=2, dim=1)
        embs.append(emb.cpu())
        if (s // batch) % 20 == 0:
            print(f"  enc {'Q' if is_query else 'D'} {s+len(chunk)}/{len(texts)} ({time.time()-t0:.0f}s)",
                  flush=True)
    return torch.cat(embs, 0)


def route_metrics(users_pred, tgt, ks=(10, 20, 50)):
    out = {}
    for k in ks:
        rec = ndcg = 0.0
        for u, g in tgt.items():
            lst = users_pred.get(u, {}).get("items", [])[:k]
            if g in lst:
                rec += 1.0
                ndcg += 1.0 / math.log2(lst.index(g) + 2)
        out[f"recall@{k}"] = rec / max(len(tgt), 1)
        out[f"ndcg@{k}"] = ndcg / max(len(tgt), 1)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--model", required=True)          # local snapshot dir
    ap.add_argument("--tool", default="semantic_qwen3")
    ap.add_argument("--max_hist", type=int, default=20)
    ap.add_argument("--max_len", type=int, default=256)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--topn", type=int, default=200)
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--out_dir", default=None)
    args = ap.parse_args()

    from transformers import AutoModel, AutoTokenizer
    torch.cuda.set_device(args.gpu)
    device = torch.device("cuda", args.gpu)
    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True, padding_side="left")
    model = AutoModel.from_pretrained(args.model, torch_dtype=torch.bfloat16,
                                      trust_remote_code=True).to(device).eval()

    meta = load_meta(args.ds)
    hist, valid, test = load_splits(args.ds, args.max_hist)
    # item id universe = union of metadata + any interacted item (keep repo id space)
    item_ids = sorted(set(meta.keys()), key=lambda x: int(x))
    item_texts = [meta[i] for i in item_ids]
    iid_pos = {i: p for p, i in enumerate(item_ids)}
    print(f"[semantic] {args.ds}: items={len(item_ids)} users={len(hist)}")

    I = encode(item_texts, tok, model, device, args.max_len, args.batch, is_query=False).to(device)  # [n_items,d]

    users = sorted(hist.keys(), key=lambda x: int(x))
    # query = user's recent items NEWEST-FIRST (so tail-truncation drops the oldest), full item text
    # (title+category+brand) to match the document representation and maximize signal.
    user_query = ["User's recently interacted items (most recent first): "
                  + " | ".join(meta.get(i, f"item {i}") for i in reversed(hist[u])) for u in users]
    U = encode(user_query, tok, model, device, args.max_len, args.batch, is_query=True)  # cpu [n_users,d]

    preds = {}
    t0 = time.time()
    bs = 256
    for s in range(0, len(users), bs):
        chunk = users[s:s + bs]
        Ub = U[s:s + bs].to(device)
        scores = Ub @ I.T                                   # [B, n_items]
        for r, u in enumerate(chunk):
            for i in hist[u]:                               # mask train-seen
                p = iid_pos.get(i)
                if p is not None:
                    scores[r, p] = -1e9
        vals, idx = torch.topk(scores, args.topn, dim=1)
        idx = idx.cpu().numpy(); vals = vals.float().cpu().numpy()
        for r, u in enumerate(chunk):
            preds[u] = {"items": [item_ids[j] for j in idx[r]], "scores": [float(x) for x in vals[r]]}
        if (s // bs) % 10 == 0:
            print(f"  rank {s+len(chunk)}/{len(users)} ({time.time()-t0:.0f}s)", flush=True)

    mv = route_metrics(preds, valid)
    mt = route_metrics(preds, test)
    print(f"[route] {args.tool} VALID {mv}")
    print(f"[route] {args.tool} TEST  {mt}")

    blob = {"schema": "recbole_cache_v2", "dataset": args.ds, "tool": args.tool,
            "model": Path(args.model).parts[-3] if "snapshots" in args.model else args.model,
            "model_version": "qwen3emb", "split_version": "loo", "topn": args.topn,
            "users": preds, "metrics_valid": mv, "metrics_test_reported": mt,
            "config": {"max_hist": args.max_hist, "max_len": args.max_len, "instruct": INSTRUCT}}
    out_dir = Path(args.out_dir) if args.out_dir else DEFAULT_OUT / args.ds
    out_dir.mkdir(parents=True, exist_ok=True)
    out_f = out_dir / f"toolcache_{args.tool}.pkl"
    pickle.dump(blob, open(out_f, "wb"))
    print(f"[write] {out_f}  ({len(preds)} users, depth {args.topn})")


if __name__ == "__main__":
    main()
