#!/usr/bin/env python3
"""Shared loaders/utilities for the multi-route FUSION baselines (2026-09-25).

All fusion methods consume EXACTLY the five route outputs Agent-R fuses:
  NCL, DiffRec, Qwen3-Embedding  -> route_cache/<ds>/toolcache_{ncl,diffrec,semantic_qwen3}.pkl
                                    (schema: users[uid_token] = {items:[tok x200], scores:[...]} )
  Mem-Ret, Popularity            -> outputs/results/<ds>/precomputed_tool_cache_modern.pkl
                                    (keys 'mem'/'popularity' = uid_token -> [item_tok] ranked list)

Evidence is RANK-based and uniform across routes (raw route scores are not comparable across
heterogeneous routes, and Mem-Ret/Popularity expose no scores), so every fusion method sees the
same normalized-rank evidence. This is the fair, standard convention (Cormack et al. 2009).

Population / GT / metrics identical to baseline_fulltest.py:
  population = frozen[<split>] keys ; TEST GT = interaction.csv label==2 ; VALID GT = label==1
  metric defs = gw.all_metrics ; final cutoff = top-50 ; GT missing -> 0 ; full population mean.
"""
from __future__ import annotations
import os, pickle, sys
from pathlib import Path
import numpy as np

os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern")
os.environ.setdefault("AGENTR_DATA_DIR",
                      "/path/to/agentr/pipeline/"
                      "residual_ranker/data_planner_modern_mem")
os.environ.setdefault("AGENTR_USER_MEMORY", "llm")

REPO = Path("/path/to/agentr")
RES = REPO / "pipeline/residual_ranker"
MRB = REPO / "pipeline/route_bank"
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                                    # noqa: E402
import gw_eval as ge                                      # noqa: E402
all_metrics = ge.gw.all_metrics

MAIN_KS = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
FINAL_K = 50
RRF_K = 60
ROUTES = ["NCL", "DiffRec", "Qwen3-Emb", "Mem-Ret", "Popularity"]
_ROUTE_TC = {"NCL": "ncl", "DiffRec": "diffrec", "Qwen3-Emb": "semantic_qwen3"}
_MODERN = {"Mem-Ret": "mem", "Popularity": "popularity"}


def load_targets(ds, label):
    import pandas as pd
    csv = REPO / "data" / ds / "interaction.csv"
    df = pd.read_csv(csv, dtype={"userid": str, "itemid": str})
    v = df[df["label"] == label]
    return {u: [str(x) for x in g["itemid"].tolist()] for u, g in v.groupby("userid")}


def load_routes(ds):
    """Return {route_name: {uid_token: [item_token ranked]}} for the 5 shared routes."""
    routes = {}
    rc = MRB / "artifacts" / "route_cache" / ds
    for name, tc in _ROUTE_TC.items():
        blob = pickle.load(open(rc / f"toolcache_{tc}.pkl", "rb"))
        routes[name] = {u: rec["items"] for u, rec in blob["users"].items()}
    mc = pickle.load(open(REPO / "outputs" / "results" / ds / "precomputed_tool_cache_modern.pkl", "rb"))
    for name, key in _MODERN.items():
        routes[name] = {u: list(v) for u, v in mc[key].items()}
    return routes


def user_rankmaps(routes, uid):
    """For one user: list of (route_name, {item: rank(1-based)}, K_route). Absent route -> empty."""
    out = []
    for r in ROUTES:
        lst = routes[r].get(uid, [])
        rm = {it: i + 1 for i, it in enumerate(lst)}
        out.append((r, rm, len(lst)))
    return out


def candidate_union(rankmaps):
    cands = set()
    for _, rm, _ in rankmaps:
        cands.update(rm.keys())
    return list(cands)


def norm_rank(rank, K):
    """s~ = 1 - (rank-1)/(K-1) in (0,1] for a PRESENT item (rank>=1, K>=1)."""
    if K <= 1:
        return 1.0
    return 1.0 - (rank - 1) / (K - 1)


def feature_matrix(rankmaps, cands):
    """[n_cand x 16] : per route (norm_rank, recip_rank, presence) + support. Also returns
    the per-route norm_rank matrix [n_cand x 5] (for RRF/CombMNZ/Val-Weighted) and support vec."""
    n = len(cands)
    idx = {c: i for i, c in enumerate(cands)}
    S = np.zeros((n, 5), dtype=np.float64)   # normalized-rank score per route
    RR = np.zeros((n, 5), dtype=np.float64)  # reciprocal rank per route
    P = np.zeros((n, 5), dtype=np.float64)   # presence
    for m, (r, rm, K) in enumerate(rankmaps):
        for it, rk in rm.items():
            i = idx[it]
            S[i, m] = norm_rank(rk, K)
            RR[i, m] = 1.0 / (RRF_K + rk)
            P[i, m] = 1.0
    support = P.sum(1, keepdims=True)
    feats = np.hstack([S, RR, P, support])   # 5+5+5+1 = 16
    return feats, S, RR, P, support.ravel()


def topk_from_scores(cands, scores, k=FINAL_K):
    if len(cands) == 0:
        return []
    order = np.argsort(-scores, kind="stable")[:k]
    return [cands[i] for i in order]


def eval_pop(pred_lists, pop, tmap):
    """pred_lists: {uid: [items]}. Full-population mean of MAIN_KS; missing/empty -> 0."""
    zero = {k: 0.0 for k in MAIN_KS}
    pum = {}
    for u in pop:
        lst = pred_lists.get(u, [])[:FINAL_K]
        pum[u] = all_metrics(lst, tmap.get(u, [])) if lst else zero
    return {k: float(np.mean([pum[u][k] for u in pop])) for k in MAIN_KS}
