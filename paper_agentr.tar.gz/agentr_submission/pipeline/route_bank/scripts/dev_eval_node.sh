#!/usr/bin/env bash
# exp16 -- DEV-eval ALL ckpts of one dataset in parallel on ONE node (each ckpt on its own GPU).
# Modern substrate env is threaded through. Each ckpt -> artifacts/res_<ds>_modern_s<step>/eval.json
# (alpha x prior{A,B} sweep, dev-select best alpha>0). Read those to pick the winning ckpt/prior/alpha.
#
# Usage: JOBID=JOBID NODE=node01 DS=Software_10_80_r811 TAG=res_software_modern \
#        STEPS="63 127 254" bash dev_eval_node.sh
set -uo pipefail
RR=/path/to/agentr/pipeline/residual_ranker
PY=${PY_LLM:-python}
JOBID="${JOBID:?}"; NODE="${NODE:?}"; DS="${DS:?}"; TAG="${TAG:?}"; STEPS="${STEPS:?}"
mkdir -p "$RR/logs"
echo "=== DEV-eval $TAG steps=[$STEPS] node=$NODE ==="
srun --overlap --jobid="$JOBID" --nodelist="$NODE" --nodes=1 --ntasks=1 --gres=gpu:8 \
     --gpu-bind=none --cpus-per-task=80 --time=01:30:00 --job-name=dev_${TAG} \
     bash -c '
       export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
       export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
       export AGENTR_USER_MEMORY=llm
       export AGENTR_FROZEN_SUFFIX=_planner_modern
       export AGENTR_DATA_DIR='"$RR"'/data_planner_modern_mem
       export AGENTR_LOCAL_SPLIT=1
       cd '"$RR"'/scripts
       g=0
       for st in '"$STEPS"'; do
         CUDA_VISIBLE_DEVICES=$g TRITON_CACHE_DIR=/tmp/tr_dev_'"$TAG"'_$st \
           '"$PY"' eval_residual.py --ds '"$DS"' --split dev --batch 128 \
             --ckpt ../checkpoints/'"$TAG"'/step_$st --tag '"$TAG"'_s${st}_dev \
             > '"$RR"'/logs/dev_'"$TAG"'_s${st}.log 2>&1 &
         g=$((g+1))
       done
       wait
       echo "ALL DEV EVALS DONE for '"$TAG"'"
     ' 2>&1 | tee "$RR/logs/deveval_${TAG}.log"
echo "=== dev-eval srun exit=$? tag=$TAG ==="
