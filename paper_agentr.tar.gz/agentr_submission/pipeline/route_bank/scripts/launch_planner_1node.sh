#!/usr/bin/env bash
# exp16 -- planner LLM on ONE node (8 GPUs, 8 shards) so two datasets can run in parallel across the
# two P6 single-node jobs. Modern substrate: ctx + delta paths carry the _modern suffix (isolated).
# Usage: JOBID=JOBID NODE=node01 DS=Software_10_80_r811 [SPLIT=both] bash launch_planner_1node.sh
set -uo pipefail
REPO=/path/to/agentr
D=$REPO/pipeline/planning
MRB=$REPO/pipeline/route_bank
PY=${PY_LLM:-python}
JOBID="${JOBID:?}"; NODE="${NODE:?}"; DS="${DS:?}"; SPLIT="${SPLIT:-both}"
export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface}
export HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
export TOKENIZERS_PARALLELISM=false
mkdir -p "$MRB/logs"
echo "=== planner LLM (1 node/8 shards) job=$JOBID node=$NODE ds=$DS split=$SPLIT ==="
srun --overlap --jobid="$JOBID" --nodelist="$NODE" --nodes=1 --ntasks=8 --ntasks-per-node=8 \
     --gres=gpu:8 --gpu-bind=none --cpus-per-task=12 --time=03:00:00 --job-name=pl_${DS} \
     bash -c '
       export VLLM_ENABLE_V1_MULTIPROCESSING=0
       export VLLM_WORKER_MULTIPROC_METHOD=spawn
       export PIN_LOCAL=1
       export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
       export VLLM_CACHE_ROOT=/tmp/vllm_pl_${SLURM_PROCID}
       export TORCHINDUCTOR_CACHE_DIR=/tmp/ti_pl_${SLURM_PROCID}
       export TRITON_CACHE_DIR=/tmp/tr_pl_${SLURM_PROCID}
       rm -rf "$VLLM_CACHE_ROOT" "$TORCHINDUCTOR_CACHE_DIR" "$TRITON_CACHE_DIR"
       '"$PY"' '"$D"'/scripts/stage_planner_llm.py \
         --ctx '"$MRB"'/../planning/artifacts/planner_ctx_'"$DS"'_modern.pkl \
         --split '"$SPLIT"' \
         --out '"$D"'/artifacts/planner_delta_'"$DS"'_modern
     ' 2>&1 | tee "$MRB/logs/planner_${DS}_modern.log"
echo "=== planner srun exit=$? ds=$DS ==="
