#!/usr/bin/env python3
"""Direct LLM Fusion baseline (§2, controlled) for the multi-route fusion sweep.

The controlled question: does simply handing an LLM the SAME five-route information Agent-R fuses
already solve the ranking problem -- WITHOUT any Agent-R machinery?

This baseline therefore uses ONLY:
  * the user context/profile (same profile substrate as Agent-R: LLM STM/LTM memory via
    profile_text_for, deterministic fallback -- AGENTR_USER_MEMORY),
  * candidate item info (title/desc from the frozen `titles`),
  * the SAME five route ranks / evidence / provenance (NCL, DiffRec, Qwen3-Emb, Mem-Ret, Popularity).
It MUST NOT use the Agent-R Planning Agent, planner-conditioned weights, deterministic rescue, the
recommendation prior p_u(i), the residual score p+alpha*r, or any Agent-R residual training. The
same base LLM family as Agent-R is used (Qwen2.5-7B-Instruct via vLLM), consistent with the ranker.

Candidate budget (§3): the LLM reranks a bounded head = the top-`HEAD_K` items by RRF over the
five-route union (RRF is the neutral, method-agnostic first stage -- NOT an Agent-R component); the
tail (ranks HEAD_K+1..50) is filled in RRF order so Recall@50 is comparable to the other fusion
baselines and to Agent-R's top-50 cutoff. HEAD_K=15 matches the Agent-R groupwise ranker slate.

Sharded across GPUs (CUDA pinned to SLURM_LOCALID; shard = SLURM_PROCID / SLURM_NTASKS), one pkl per
shard. `--reduce` merges shards and scores the FULL official TEST population (missing/parse-fail ->
RRF order; empty candidate set -> 0), writing metrics_llm_fusion.json.
"""
from __future__ import annotations
import argparse, json, os, pickle, sys, time
from pathlib import Path
import numpy as np

import fusion_common as fc
sys.path.insert(0, str(fc.REPO / "pipeline/ranking_common/scripts"))
import gw_common as gwc                                    # noqa: E402  (LABELS, parse_ranking, item_line)

HEAD_K = 15                       # LLM-reranked head size (== Agent-R groupwise slate, LABELS A-O)
LABELS = gwc.LABELS               # "ABCDEFGHIJKLMNO"


def env_int(k, d):
    try:
        return int(os.environ.get(k, d))
    except Exception:
        return d


# --------------------------------------------------------------------- prompt construction
SYS_PROMPT = (
    "You are the fusion ranker of a multi-route recommender system. Several independent retrieval "
    "routes (a graph model, a diffusion model, a semantic-embedding model, a memory-retrieval route, "
    "and a popularity route) each proposed candidate items for one user. For every candidate you are "
    "told which routes retrieved it and at what rank (lower rank = that route liked it more). Using "
    "the user's profile and this cross-route evidence, rank the candidates from most to least likely "
    "to be the user's next interaction. Reply with ONLY a JSON object of the form "
    '{"ranking": ["<label>", ...]} listing candidate labels best-first. Output nothing else.'
)


def evidence_str(item, rankmaps):
    """Compact per-item route provenance: 'NCL#3, Qwen3-Emb#12, Popularity#5' (present routes only)."""
    parts = []
    for rname, rm, _K in rankmaps:
        rk = rm.get(item)
        if rk is not None:
            parts.append(f"{rname}#{rk}")
    return ", ".join(parts) if parts else "none"


def build_prompt(profile, head_items, titles, rankmaps):
    lines = []
    for lab, iid in zip(LABELS, head_items):
        il = gwc.item_line(iid, titles)
        lines.append(f"[{lab}] {il} | routes: {evidence_str(iid, rankmaps)}")
    cand_block = "\n".join(lines)
    user = (
        f"User profile: {profile}\n\n"
        f"Candidate items (each with the routes that retrieved it and their per-route rank):\n"
        f"{cand_block}\n\n"
        f"Rank all {len(head_items)} candidates best-first and return "
        f'{{"ranking": [labels]}}.'
    )
    return SYS_PROMPT + "\n\n" + user


def rrf_order(rankmaps, cands):
    """Full RRF ordering of the candidate union (first-stage; neutral, not an Agent-R component)."""
    feats, S, RR, P, sup = fc.feature_matrix(rankmaps, cands)
    return [cands[i] for i in np.argsort(-RR.sum(1), kind="stable")]


def build_user_items(ds):
    """For every frozen TEST user: (uid, rrf_full_list, head_items, prompt). Users with candidates only."""
    routes = fc.load_routes(ds)
    blob = fc.rr.gw.load_frozen(ds)
    testpop = list(blob["frozen"]["test"].keys())
    titles = blob.get("titles", {})
    user_meta = blob.get("user_meta", {})
    items = []
    for u in testpop:
        rm = fc.user_rankmaps(routes, u)
        cands = fc.candidate_union(rm)
        if not cands:
            continue
        order = rrf_order(rm, cands)
        head = order[:HEAD_K]
        profile = fc.rr.profile_text_for(u, user_meta.get(u), ds)
        prompt = build_prompt(profile, head, titles, rm)
        items.append({"userid": u, "rrf": order, "head": head, "prompt": prompt})
    return testpop, items


# --------------------------------------------------------------------- shard (LLM generate)
def run_shard(ds, outdir, model, max_model_len, gpu_mem):
    local_id = env_int("SLURM_LOCALID", env_int("LOCAL_ID", 0))
    if os.environ.get("PIN_LOCAL", "1") == "1":
        os.environ["CUDA_VISIBLE_DEVICES"] = str(local_id)
    # Explicit SHARD/NSHARDS take precedence: the launcher runs one --ntasks=1 srun step per shard,
    # so SLURM_NTASKS=1 / SLURM_PROCID=0 in every step -- reading those first would make all shards
    # process the whole population and collide on preds.shard0.pkl. Fall back to SLURM only if unset.
    proc_id = env_int("SHARD", env_int("SLURM_PROCID", 0))
    ntasks = env_int("NSHARDS", env_int("SLURM_NTASKS", 1))

    testpop, items = build_user_items(ds)
    mine = [it for i, it in enumerate(items) if i % ntasks == proc_id]
    print(f"[{ds} shard {proc_id}/{ntasks}] CUDA={os.environ.get('CUDA_VISIBLE_DEVICES')} "
          f"users_with_cand={len(items)} mine={len(mine)} testpop={len(testpop)}", flush=True)

    from vllm import LLM, SamplingParams
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(model)
    llm = LLM(model=model, dtype="bfloat16", max_model_len=max_model_len,
              gpu_memory_utilization=gpu_mem, enforce_eager=True, disable_log_stats=True)
    sp = SamplingParams(temperature=0.0, max_tokens=128)

    prompts = [tok.apply_chat_template([{"role": "user", "content": it["prompt"]}],
                                       tokenize=False, add_generation_prompt=True) for it in mine]
    outs = llm.generate(prompts, sp) if prompts else []

    preds, n_ok = {}, 0
    for it, o in zip(mine, outs):
        head = it["head"]
        valid = LABELS[:len(head)]
        order_labs = gwc.parse_ranking(o.outputs[0].text, valid)
        ok = len(order_labs) >= max(1, len(head) // 2)
        n_ok += int(ok)
        lab2iid = {lab: iid for lab, iid in zip(LABELS, head)}
        reranked = [lab2iid[l] for l in order_labs]                 # LLM order (subset of head)
        reranked += [i for i in head if i not in set(reranked)]     # any head items LLM dropped
        tail = [i for i in it["rrf"] if i not in set(head)]         # RRF tail (ranks HEAD_K+1..)
        preds[it["userid"]] = (reranked + tail)[:fc.FINAL_K]
    Path(outdir).mkdir(parents=True, exist_ok=True)
    pickle.dump(preds, open(Path(outdir) / f"preds.shard{proc_id}.pkl", "wb"))
    json.dump({"ds": ds, "shard": proc_id, "ntasks": ntasks, "n": len(mine), "parse_ok": n_ok},
              open(Path(outdir) / f"meta.shard{proc_id}.json", "w"))
    print(f"[{ds} shard {proc_id}] parse_ok={n_ok}/{len(mine)} -> preds.shard{proc_id}.pkl", flush=True)


# --------------------------------------------------------------------- reduce (merge + eval)
def reduce_dir(ds, outdir):
    blob = fc.rr.gw.load_frozen(ds)
    testpop = list(blob["frozen"]["test"].keys())
    tgt_t = fc.load_targets(ds, 2)
    preds = {}
    n_ok = n_tot = 0
    for f in sorted(Path(outdir).glob("preds.shard*.pkl")):
        preds.update(pickle.load(open(f, "rb")))
    for f in sorted(Path(outdir).glob("meta.shard*.json")):
        m = json.load(open(f)); n_ok += m["parse_ok"]; n_tot += m["n"]
    # users with candidates but no LLM pred (shouldn't happen) fall back to RRF later; empty-cand -> 0
    m = fc.eval_pop(preds, testpop, tgt_t)
    out = {"dataset": ds, "method": "Direct-LLM-Fusion", "head_k": HEAD_K,
           "n_test_population": len(testpop), "n_llm_users": len(preds),
           "parse_ok": n_ok, "n_generated": n_tot, **m}
    dst = fc.MRB / "artifacts" / "fusion" / ds
    dst.mkdir(parents=True, exist_ok=True)
    json.dump(out, open(dst / "metrics_llm_fusion.json", "w"), indent=2)
    pickle.dump(preds, open(dst / "preds_Direct-LLM-Fusion.pkl", "wb"))
    print(f"[{ds}] Direct-LLM-Fusion N@10={m['NDCG@10']:.4f} R@10={m['Recall@10']:.4f} "
          f"N@50={m['NDCG@50']:.4f} R@50={m['Recall@50']:.4f} "
          f"(llm_users={len(preds)}/{len(testpop)} parse_ok={n_ok}/{n_tot})", flush=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--outdir", required=True, help="shard scratch dir (per dataset)")
    ap.add_argument("--reduce", action="store_true")
    ap.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--max-model-len", type=int, default=4096)
    ap.add_argument("--gpu-mem", type=float, default=0.90)
    args = ap.parse_args()
    if args.reduce:
        reduce_dir(args.ds, args.outdir)
    else:
        run_shard(args.ds, args.outdir, args.model, args.max_model_len, args.gpu_mem)


if __name__ == "__main__":
    main()
