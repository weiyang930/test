#!/usr/bin/env python3
"""Full-TEST-population eval of the CF baselines (BPR / LightGCN / SASRec / BERT4Rec) for ONE dataset,
using EXACTLY the canonical Agent-R protocol (identical to fulltest_eval.py / single_route_fulltest.py):

  population   = frozen[test] keys (every official label==2 test user)
  GT           = load_test_targets(ds)  (full official target set)
  metric defs  = gw.all_metrics (NDCG/Recall@{10,50})
  per user     = model's top-50 from toolcache['users'][uid]['items']; missing user -> 0
  aggregate    = plain mean over the complete population

BPR/SASRec/BERT4Rec toolcaches come from artifacts/baseline_cache/<ds> (this sweep). LightGCN is
REUSED from artifacts/route_cache/<ds>/toolcache_lightgcn.pkl (already trained for the route bank).
Reads only; writes artifacts/baseline_fulltest_<ds>.json.
"""
from __future__ import annotations
import argparse, json, os, pickle, sys
from pathlib import Path
import numpy as np

os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern")
os.environ.setdefault("AGENTR_DATA_DIR",
                      "/path/to/agentr/pipeline/"
                      "residual_ranker/data_planner_modern_mem")
os.environ.setdefault("AGENTR_USER_MEMORY", "llm")

REPO = Path("/path/to/agentr")
RES = REPO / "pipeline/residual_ranker"
MRB = REPO / "pipeline/route_bank"
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                                    # noqa: E402
import gw_eval as ge                                      # noqa: E402
from build_test_data import load_test_targets             # noqa: E402
all_metrics = ge.gw.all_metrics

MAIN_KS = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
# model label -> (tool cache filename, source dir kind)
MODELS = [("BPR", "bpr", "baseline"),
          ("LightGCN", "lightgcn", "route"),      # reused from the route bank
          ("SGL", "sgl", "baseline"),             # SIGIR'21 graph contrastive (extra sweep)
          ("SASRec", "sasrec", "baseline"),
          ("BERT4Rec", "bert4rec", "baseline"),
          ("CORE", "core", "baseline")]           # SIGIR'22 sequential (extra sweep)


def route_metrics(users, pop, tmap):
    zero = {k: 0.0 for k in MAIN_KS}
    pum = {}
    for u in pop:
        rec = users.get(u)
        lst = rec["items"][:50] if rec else []
        pum[u] = all_metrics(lst, tmap.get(u, [])) if lst else zero
    return {k: float(np.mean([pum[u][k] for u in pop])) for k in MAIN_KS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    args = ap.parse_args()
    ds = args.ds

    pop = list(rr.gw.load_frozen(ds)["frozen"]["test"].keys())
    tmap = load_test_targets(ds)
    out = {"dataset": ds, "n_test_population": len(pop), "models": {}}
    for name, tool, kind in MODELS:
        f = (MRB / "artifacts" / "baseline_cache" / ds / f"toolcache_{tool}.pkl" if kind == "baseline"
             else MRB / "artifacts" / "route_cache" / ds / f"toolcache_{tool}.pkl")
        if not f.exists():
            out["models"][name] = {"toolcache": str(f), "error": "missing"}
            print(f"[{ds}] {name:10s} MISSING {f}")
            continue
        blob = pickle.load(open(f, "rb"))
        m = route_metrics(blob["users"], pop, tmap)
        out["models"][name] = {"toolcache": tool, "source": kind, "model": blob.get("model", name), **m}
        print(f"[{ds}] {name:10s} N@10={m['NDCG@10']:.4f} R@10={m['Recall@10']:.4f} "
              f"N@50={m['NDCG@50']:.4f} R@50={m['Recall@50']:.4f}")

    outp = MRB / "artifacts" / f"baseline_fulltest_{ds}.json"
    json.dump(out, open(outp, "w"), indent=2)
    print(f"[write] {outp}")


if __name__ == "__main__":
    main()
