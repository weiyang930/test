#!/usr/bin/env python3
"""exp16 -- assemble the MODERN combined route cache the offline Agent-R pipeline consumes, from the
per-route depth-200 toolcache_*.pkl, WITHOUT overwriting any existing artifact.

Slot mapping (minimal-change; AUX_TOOLS/base="graph" schema unchanged -- only CONTENTS modernize):
  graph      <- DEV-winner of {NCL, DiffRec} by VALID Recall@50   (frozen base / residual prior)
  collab     <- the OTHER of {NCL, DiffRec}
  semantic   <- Qwen3-Embedding route
  mem        <- existing precomputed_tool_cache.pkl['mem']        (reused, unchanged)
  popularity <- existing ['popularity']                           (reused, unchanged)
  keyword    <- existing ['keyword']                              (kept for schema completeness; not in AUX)

Output: outputs/results/<ds>/precomputed_tool_cache_modern.pkl  (schema B: {route:{uid(str):[iid str x100]}})
plus artifacts/base_selection_<ds>.json (which route won base, VALID metrics of both). The offline
pipeline reads this by setting AGENTR_TOOLCACHE_SUFFIX=_modern (pcr_common load_dataset).

Base selection is on DEV only (Recall@50 primary, NDCG@10 tiebreak) and is frozen before any TEST use.

Usage: python assemble_modern_cache.py --ds Software_10_80_r811 \
         [--semantic_tool semantic_qwen3] [--route_dir <artifacts/route_cache/<ds>>] [--depth 100]
"""
from __future__ import annotations
import argparse, json, pickle
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
ART = Path(__file__).resolve().parents[1] / "artifacts"
DEFAULT_ROUTE_DIR = ART / "route_cache"


def load_route(route_dir: Path, tool: str):
    p = route_dir / f"toolcache_{tool}.pkl"
    if not p.exists():
        raise SystemExit(f"[assemble] missing route cache: {p}")
    return pickle.load(open(p, "rb"))


def to_bare(users: dict, depth: int):
    """recbole_cache_v2 users {uid:{items,scores}} -> combined-schema {uid(str):[iid str x depth]}."""
    return {str(u): [str(x) for x in rec["items"][:depth]] for u, rec in users.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--ncl_tool", default="ncl")
    ap.add_argument("--diffrec_tool", default="diffrec")
    ap.add_argument("--semantic_tool", default="semantic_qwen3")
    ap.add_argument("--route_dir", default=None)
    ap.add_argument("--depth", type=int, default=100)   # combined cache depth (existing = 100)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    route_dir = Path(args.route_dir) if args.route_dir else DEFAULT_ROUTE_DIR / args.ds
    ncl = load_route(route_dir, args.ncl_tool)
    diff = load_route(route_dir, args.diffrec_tool)
    sem = load_route(route_dir, args.semantic_tool)

    # ---- base selection on DEV (VALID) Recall@50, NDCG@10 tiebreak
    def key(m):
        return (m["metrics_valid"]["recall@50"], m["metrics_valid"]["ndcg@10"])
    ncl_k, diff_k = key(ncl), key(diff)
    if ncl_k >= diff_k:
        base_model, base_tc, aux_model, aux_tc = "NCL", ncl, "DiffRec", diff
    else:
        base_model, base_tc, aux_model, aux_tc = "DiffRec", diff, "NCL", ncl
    print(f"[base] {args.ds}: base={base_model} (VALID R@50 NCL={ncl_k[0]:.4f} DiffRec={diff_k[0]:.4f}) "
          f"-> graph<-{base_model}, collab<-{aux_model}")

    # ---- reuse existing mem / popularity / keyword from the DEFAULT combined cache
    existing = pickle.load(open(REPO / f"outputs/results/{args.ds}/precomputed_tool_cache.pkl", "rb"))

    modern = {
        "graph":      to_bare(base_tc["users"], args.depth),
        "collab":     to_bare(aux_tc["users"], args.depth),
        "semantic":   to_bare(sem["users"], args.depth),
        "mem":        existing["mem"],
        "popularity": existing["popularity"],
        "keyword":    existing.get("keyword", {}),
    }
    # sanity: uid coverage of the modern routes should match the existing cache's user set
    n_users = {k: len(v) for k, v in modern.items()}
    print(f"[assemble] route user counts: {n_users}")

    out = Path(args.out) if args.out else REPO / f"outputs/results/{args.ds}/precomputed_tool_cache_modern.pkl"
    pickle.dump(modern, open(out, "wb"))
    sel = {
        "ds": args.ds, "base_route_model": base_model, "aux_collab_model": aux_model,
        "semantic_tool": args.semantic_tool,
        "valid_metrics": {"NCL": ncl["metrics_valid"], "DiffRec": diff["metrics_valid"],
                          "semantic": sem["metrics_valid"]},
        "test_metrics_reported": {"NCL": ncl["metrics_test_reported"],
                                  "DiffRec": diff["metrics_test_reported"],
                                  "semantic": sem["metrics_test_reported"]},
        "depth": args.depth, "out": str(out),
    }
    ART.mkdir(parents=True, exist_ok=True)
    json.dump(sel, open(ART / f"base_selection_{args.ds}.json", "w"), indent=2)
    print(f"[write] {out}\n[write] {ART / f'base_selection_{args.ds}.json'}")


if __name__ == "__main__":
    main()
