#!/usr/bin/env python3
"""Generate the multi-route fusion deliverable log from the saved artifacts.

Re-runnable: reads artifacts/fusion/<ds>/metrics_<ds>.json (5 classical/learned methods) and
metrics_llm_fusion.json (Direct LLM Fusion) for every dataset, plus the finalized Agent-R reference
row, and writes develop/2026-09-25_04_multiroute_fusion_baselines.md. Methods still running show as
"running". Rerun any time to refresh the numbers.
"""
from __future__ import annotations
import json
from pathlib import Path

MRB = Path("/path/to/agentr/pipeline/route_bank")
OUT = Path("/path/to/agentr/develop/2026-09-25_04_multiroute_fusion_baselines.md")
KS = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
CLASSICAL = ["RRF", "CombMNZ", "Val-Weighted", "Logistic", "LambdaMART"]
METHODS = CLASSICAL + ["Direct-LLM-Fusion"]

# dataset id -> (display name, dagger)
DS = [("Software_10_80_r811", "Software", ""),
      ("Game_10_80_r811", "Game", ""),
      ("Industrial_10_80_r811", "Industrial", ""),
      ("Music_10_80_r811", "Music", ""),
      ("KuaiRec_dg", "KuaiRec", ""),
      ("MicroLens_dg", "MicroLens", ""),
      ("DoubanBook_dg", "DoubanBook", "†"),
      ("DoubanMusic_dg", "DoubanMusic", "†")]

# Finalized Agent-R full-test-population numbers (from 2026-09-25_01 §2b, reused in _03 §4).
AGENTR = {
    "Software_10_80_r811":   [0.0845, 0.1506, 0.1215, 0.3095],
    "Game_10_80_r811":       [0.0333, 0.0590, 0.0525, 0.1437],
    "Industrial_10_80_r811": [0.0224, 0.0418, 0.0366, 0.1045],
    "Music_10_80_r811":      [0.0198, 0.0354, 0.0308, 0.0852],
    "KuaiRec_dg":            [0.0604, 0.0962, 0.0677, 0.1290],
    "MicroLens_dg":          [0.0176, 0.0371, 0.0276, 0.0824],
    "DoubanBook_dg":         [0.0115, 0.0231, 0.0207, 0.0653],
    "DoubanMusic_dg":        [0.0100, 0.0193, 0.0170, 0.0517],
}


def load(ds):
    """Return {method: [4 metrics] or None}, plus meta (populations, weights, llm parse)."""
    out = {m: None for m in METHODS}
    meta = {}
    f = MRB / "artifacts" / "fusion" / ds / f"metrics_{ds}.json"
    if f.exists():
        blob = json.load(open(f))
        meta["test_pop"] = blob.get("n_test_population")
        meta["valid_pop"] = blob.get("n_valid_population")
        meta["weights"] = {}
        for m, v in blob["methods"].items():
            if all(k in v for k in KS):
                out[m] = [v[k] for k in KS]
            if "weights" in v:
                meta["weights"][m] = v["weights"]
    fl = MRB / "artifacts" / "fusion" / ds / "metrics_llm_fusion.json"
    if fl.exists():
        v = json.load(open(fl))
        if all(k in v for k in KS):
            out["Direct-LLM-Fusion"] = [v[k] for k in KS]
        meta["llm"] = {"parse_ok": v.get("parse_ok"), "n": v.get("n_generated"),
                       "users": v.get("n_llm_users"), "head_k": v.get("head_k")}
    return out, meta


def cell(x):
    return f"{x:.4f}" if x is not None else "—"


def row(name, vals, bold=False):
    if vals is None:
        cells = "running | running | running | running"
    else:
        cells = " | ".join(cell(x) for x in vals)
    nm = f"**{name}**" if bold else name
    return f"| {nm} | {cells} |"


def main():
    data = {ds: load(ds) for ds, _, _ in DS}

    L = []
    L.append("# 2026-09-25 — Multi-Route Fusion Baseline Sweep (RRF / CombMNZ / Val-Weighted / "
             "Logistic / LambdaMART / Direct-LLM-Fusion)\n")
    L.append("**Goal.** Answer, under the identical full-TEST-population protocol, whether standard "
             "multi-route fusion baselines — given EXACTLY the five route outputs Agent-R fuses — "
             "match Agent-R, and in particular whether simply handing an LLM the same multi-route "
             "evidence already solves the ranking problem. Six fusion methods per dataset; no extra "
             "information vs Agent-R, no selective removal of weak routes.\n")

    # ---- §1 shared routes / protocol
    L.append("## 1. Shared input routes (identical to Agent-R) & protocol\n")
    L.append("All six methods consume EXACTLY the five routes Agent-R fuses, from the existing saved "
             "caches (no route retraining):\n")
    L.append("- **NCL, DiffRec, Qwen3-Embedding** — `artifacts/route_cache/<ds>/toolcache_"
             "{ncl,diffrec,semantic_qwen3}.pkl` (per-user depth-200 ranked lists).")
    L.append("- **Mem-Ret, Popularity** — `outputs/results/<ds>/precomputed_tool_cache_modern.pkl` "
             "(keys `mem`/`popularity`, per-user ranked lists).\n")
    L.append("Because raw route scores are not comparable across these heterogeneous routes (and "
             "Mem-Ret/Popularity expose no scores), every method uses **rank-derived evidence** — the "
             "fair, standard convention. Per route _m_ and item _i_: normalized rank "
             "s̃ₘ(i)=1−(rankₘ(i)−1)/(Kₘ−1), reciprocal rank 1/(60+rankₘ(i)), a presence indicator, "
             "and cross-route support |{m : i∈Lₘ}|.\n")
    L.append("**Protocol (identical to the Agent-R full-test-population table, "
             "`baseline_fulltest.py` internals).** Population = every official TEST user "
             "(`frozen[test]` keys, no rankable filtering). GT: TEST = interaction label==2, "
             "VALID = label==1. Metrics = `gw.all_metrics` → NDCG@{10,50}, Recall@{10,50}. Final "
             "cutoff = top-50; GT missing → 0; aggregate = plain mean over the full population. "
             "Learned methods (Val-Weighted / Logistic / LambdaMART) are fit and selected on VALID "
             "only (the sole labeled fitting split — train items are the masked history); TEST is "
             "scored once, no TEST-driven selection.\n")

    # ---- §2 methods
    L.append("## 2. Methods (as implemented)\n")
    L.append("1. **RRF** — Σₘ 1/(60+rankₘ(i)); missing route → contributes 0. `k=60`.")
    L.append("2. **CombMNZ** — Σₘ s̃ₘ(i) multiplied by the cross-route support count.")
    L.append("3. **Val-Weighted** — one GLOBAL non-negative simplex weight vector over the 5 routes "
             "(126-point grid, step 0.2), chosen to maximize mean VALID NDCG@10; s(i)=Σ wₘ s̃ₘ(i); "
             "frozen before TEST. Global route-reliability weighting, not per-user gating.")
    L.append("4. **Logistic Fusion** — per-(user,candidate) features [5×(normrank, recip, presence) "
             "+ support = 16], `sklearn` LogisticRegression (`C=1.0`, `class_weight=balanced`, "
             "standardized), trained on the full VALID candidate union, no hyperparameter search.")
    L.append("5. **LambdaMART** — SAME 16 features, `LGBMRanker` (`objective=lambdarank`, "
             "300 trees, lr 0.05, 31 leaves), grouped by user, relevance = held-out positive 1 / "
             "others 0. Trained on the full VALID union (training on the RRF-top-N head only makes "
             "the trees extrapolate arbitrarily on the unseen tail at TEST and collapses ranking; "
             "full-union training fixes this).")
    L.append("6. **Direct-LLM-Fusion** — the controlled LLM baseline. Qwen2.5-7B-Instruct (same base "
             "family as Agent-R) is given the user profile (same LLM STM/LTM memory substrate), the "
             "candidate item title/description, and the SAME five route ranks/provenance per "
             "candidate, and directly reranks. It reranks the top-15 candidates by RRF over the "
             "5-route union (RRF is the neutral first stage, not an Agent-R component); the tail "
             "(ranks 16–50) is filled in RRF order for Recall@50 comparability. **It uses NO Agent-R "
             "Planning Agent, planner-conditioned weights, deterministic rescue, recommendation prior "
             "pᵤ(i), residual score p+αr, or residual training.** Parse failure → RRF order.\n")

    # ---- §3 parallel exec
    L.append("## 3. Parallel execution\n")
    L.append("Classical/learned methods (CPU) ran all 8 datasets concurrently on the head node "
             "(`run_fusion_classical.py`, ~10–200 s each). Direct-LLM-Fusion sharded 4 ways per "
             "dataset across the 4 nodes / 32 GPUs (2×P6 B200, 2×P5 H100) via vLLM "
             "(`run_llm_fusion.py` + `launch_llm_fusion.sh`); each shard covers the full TEST "
             "population slice and writes `artifacts/fusion/<ds>/llm_shards/preds.shard*.pkl`, "
             "reduced to `metrics_llm_fusion.json`.\n")

    # ---- §4 per-dataset full tables
    L.append("## 4. Results — full test population (per dataset)\n")
    L.append("Column order: NDCG@10 / Recall@10 / NDCG@50 / Recall@50. The **Agent-R (ours)** row is "
             "the finalized full-test-population number for reference (same protocol).\n")
    for ds, disp, dag in DS:
        d, meta = data[ds]
        tp = meta.get("test_pop")
        llm = meta.get("llm", {})
        pk = f", LLM parse_ok {llm['parse_ok']}/{llm['n']}" if llm.get("n") else ""
        L.append(f"### {disp}{dag}  (test population = {tp}{pk})\n")
        L.append("| Method | N@10 | R@10 | N@50 | R@50 |")
        L.append("|---|---|---|---|---|")
        for m in METHODS:
            L.append(row(m, d[m]))
        L.append(row("Agent-R (ours)", AGENTR[ds], bold=True))
        w = meta.get("weights", {}).get("Val-Weighted")
        if w:
            ws = ", ".join(f"{r}={x:.1f}" for r, x in w.items() if x > 0)
            L.append(f"\n_Val-Weighted simplex weights: {ws}._")
        L.append("")

    # ---- §5 clean summary table + best per dataset
    L.append("## 5. Final clean table & best fusion method per dataset\n")
    L.append("| Dataset | Method | N@10 | R@10 | N@50 | R@50 |")
    L.append("|---|---|---|---|---|---|")
    best = {}
    for ds, disp, dag in DS:
        d, _ = data[ds]
        first = True
        # best fusion method by N@10 among available
        avail = [(m, d[m]) for m in METHODS if d[m] is not None]
        bm = max(avail, key=lambda kv: kv[1][0]) if avail else None
        best[ds] = bm
        for m in METHODS:
            lead = f"{disp}{dag}" if first else ""
            first = False
            star = " ⭐" if (bm and m == bm[0]) else ""
            v = d[m]
            cells = " | ".join(cell(x) for x in v) if v else "running | running | running | running"
            L.append(f"| {lead} | {m}{star} | {cells} |")
        av = AGENTR[ds]
        L.append(f"|  | **Agent-R (ours)** | **{av[0]:.4f}** | **{av[1]:.4f}** | "
                 f"**{av[2]:.4f}** | **{av[3]:.4f}** |")
    L.append("\n⭐ = best fusion baseline on that dataset by NDCG@10.\n")

    L.append("### Best fusion method per dataset (by NDCG@10)\n")
    L.append("| Dataset | Best fusion | N@10 | R@10 | N@50 | R@50 | vs Agent-R N@10 |")
    L.append("|---|---|---|---|---|---|---|")
    for ds, disp, dag in DS:
        bm = best[ds]
        if not bm:
            L.append(f"| {disp}{dag} | (running) | — | — | — | — | — |")
            continue
        m, v = bm
        delta = v[0] - AGENTR[ds][0]
        sign = "+" if delta >= 0 else "−"
        L.append(f"| {disp}{dag} | {m} | {v[0]:.4f} | {v[1]:.4f} | {v[2]:.4f} | {v[3]:.4f} | "
                 f"{sign}{abs(delta):.4f} |")
    L.append("")

    # ---- artifacts
    L.append("## 6. Preserved artifacts\n")
    L.append("Per dataset under `pipeline/route_bank/artifacts/fusion/<ds>/`:")
    L.append("- `metrics_<ds>.json` — aggregate TEST (+VALID for learned) metrics, 5 classical methods.")
    L.append("- `metrics_llm_fusion.json` — Direct-LLM-Fusion aggregate + parse stats + head_k.")
    L.append("- `weights_val_weighted.json` — frozen simplex weights; `logistic.pkl`; `lambdamart.txt`.")
    L.append("- `preds_<method>.pkl` — per-user TEST top-50 lists (all 6 methods); "
             "`llm_shards/` raw LLM shard preds.")
    L.append("- Scripts: `fusion_common.py`, `run_fusion_classical.py`, `run_llm_fusion.py`, "
             "`launch_llm_fusion.sh`, `make_fusion_report.py` (this generator). No Agent-R artifacts "
             "overwritten.\n")

    OUT.write_text("\n".join(L))
    print(f"[write] {OUT}  ({len(L)} lines)")
    done = sum(1 for ds, _, _ in DS if data[ds][0]["Direct-LLM-Fusion"] is not None)
    print(f"LLM fusion complete: {done}/8 datasets")


if __name__ == "__main__":
    main()
