# DOWNSTREAM_RUNBOOK — modern-substrate residual ranker (stages 7-10)

2026-09-25 fulltest all-dataset sweep. `downstream_one_ds.sh` builds stages 1-6 (assemble → offline →
planner ctx → planner LLM deltas → frozen slate → residual train/dev/test data) for one dataset. This
runbook covers the remaining GPU-heavy stages that turn that data into a dev-selected, TEST-once,
full-population result. **No TEST-driven tuning:** dev-select ckpt/prior/alpha on VALID/DEV only; run
TEST exactly once after the config is frozen.

## Prerequisites (per dataset `<DS>`)
`downstream_one_ds.sh` finished → these exist:
- `candidate_adaptation/artifacts/frozen_<DS>_planner_modern.pkl`
- `residual_ranker/data_planner_modern_mem/<DS>/{residual_users.pkl, priorB.json, ...}`
- `outputs/indexes/<DS>/user_memory_llm_agent_qwen2p5_7b_instruct.json` (LLM STM/LTM memory)

## Common environment (ALL of stages 7-10)
Train/serve representations must match — export the SAME modern-substrate env everywhere:
```bash
export AGENTR_TOOLCACHE_SUFFIX=_modern
export AGENTR_FROZEN_SUFFIX=_planner_modern
export AGENTR_DATA_DIR=/path/to/agentr/pipeline/residual_ranker/data_planner_modern_mem
export AGENTR_USER_MEMORY=llm
export AGENTR_LOCAL_SPLIT=1
```
Do NOT fall back to `_planner` / `data_planner` / deterministic memory / old checkpoints — those were
trained on incompatible inputs. `rr_common.SHIPPED_RANKER` only registers the OLD Software/Game ckpts for
`("llm","_planner",...)`; modern runs must pass explicit `--ckpt/--fixed_prior/--fixed_alpha` (never rely
on `resolve_shipped_ranker`).

Venvs:
- CPU stages (eval sweeps, fulltest): `${PY_RECBOLE:-python}`
- GPU training (stage 7): `${PY_LLM:-python}` (via `launch_train.sh`).

`launch_train.sh` already forwards `AGENTR_FROZEN_SUFFIX / AGENTR_DATA_DIR / AGENTR_LOCAL_SPLIT` into the
srun — export them (as above) in the shell that calls it. `AGENTR_USER_MEMORY=llm` is read from the data
that was already baked at stage 6, so training reads it from `AGENTR_DATA_DIR`.

---

## Stage 7 — train the residual ranker (8×GPU, one node)
Plain PyTorch DDP (no verl). Base = Qwen2.5-7B + LoRA + regression head; base-anchored residual
`s = prior + alpha*tanh(head)`.

`step_N` naming: `N = int(save_frac * steps_per_epoch)`, `steps_per_epoch = ceil(|train| / batch / accum)`.
So the exact step numbers differ per dataset (the finalized 4 landed at 254/80/260/72). **Choose EPOCHS +
save_frac to give dev-select several candidate checkpoints spanning the run:**

- Target ≈ 400–800 optimizer steps total. `EPOCHS ≈ max(2, ceil(600 / steps_per_epoch))`.
  Small-user datasets (DoubanBook_dg ≈1.7k users, DoubanMusic_dg ≈1.3k users) have tiny
  `steps_per_epoch` → bump EPOCHS (e.g. 6–10) so there are real checkpoints to select among.
- Sample multiple save points via `XARGS="--save_frac 0.5 1 1.5 2 3 4"` (fractions of an epoch; each
  produces a `step_N`). Larger datasets can keep the default `--save_frac 0.5 1 2`.

```bash
cd /path/to/agentr/pipeline/residual_ranker/scripts
# export the common env block first (see above)
JOBID=<J> NODE=<N> DS=<DS> TAG=res_<ds>_modern OBJ=A PRIOR=A EPOCHS=<E> \
  XARGS="--save_frac 0.5 1 1.5 2 3 4" bash launch_train.sh
```
- `OBJ`/`PRIOR`: the finalized runs used prior A (rank-decay) for SW/Game/Industrial and prior B for
  Music — but prior is re-selected on DEV at stage 8 (both A and B are swept there), so OBJ just sets the
  training objective. Train with `OBJ=A PRIOR=A` as the default; only add a `PRIOR=B` run if a dataset's
  DEV sweep clearly prefers B.
- Checkpoints land in `checkpoints/res_<ds>_modern/step_*`. Log: `logs/train_res_<ds>_modern.log`.

## Stage 8 — DEV selection (CPU, no GPU)
For EACH saved `step_N`, sweep prior∈{A,B} × `rr.ALPHA_GRID` and select the (step, prior, alpha) with the
best **DEV NDCG@10** (`alpha>0` required to count as a win; `alpha=0` reproduces no_ranking exactly and is
asserted). This is the ONLY selection step — TEST is untouched.
```bash
cd .../residual_ranker/scripts
for STEP in $(ls -d ../checkpoints/res_<ds>_modern/step_* | sort -t_ -k2 -n); do
  python eval_residual.py --ds <DS> --split dev \
    --ckpt "$STEP" --tag devsel_<ds>_$(basename "$STEP") --priors A B
done
# read artifacts/devsel_<ds>_step_*/alpha_sweep.csv ; pick max DEV NDCG@10 (alpha>0)
```
Writes per tag: `artifacts/<tag>/alpha_sweep.csv`, `residual_cache_dev.pkl`, `residual_stats.json`.
Record the winning **ckpt step, prior (A|B), alpha** — these are frozen for TEST.

## Stage 9 — TEST once (CPU, no GPU)
Pin the DEV-selected config; do NOT re-select on test. Produces `residual_cache_test.pkl` under the tag
that `fulltest_eval.py` will read.
```bash
python eval_residual.py --ds <DS> --split test \
  --ckpt ../checkpoints/res_<ds>_modern/step_<SEL> \
  --tag res_<ds>_modern \
  --fixed_prior <A|B> --fixed_alpha <ALPHA>
# -> artifacts/res_<ds>_modern/residual_cache_test.pkl
```

## Stage 10 — full-test-population eval (CPU) → paper table
Score EVERY official TEST user on the produced depth-50 list (rankable → residual reorder; others →
frozen planner order, contributing 0). R@50 is the genuine full-population coverage, NOT 1.0.
```bash
cd /path/to/agentr
python pipeline/route_bank/scripts/fulltest_eval.py \
  --ds <DS> --tag res_<ds>_modern \
  --prior <A|B> --alpha <ALPHA> \
  --base_route <graph|collab>     # from base_selection_<ds>.json: DiffRec/NCL winner -> graph
# -> pipeline/route_bank/artifacts/fulltest_<ds>.{json, per_user.csv}
```
`--base_route` is a label only (graph if the DEV base winner is the NCL/DiffRec graph slot, collab
otherwise) — take it from `artifacts/base_selection_<ds>.json`.

### Record in the log
Append to `develop/2026-09-25_01_fulltest_all_dataset_final.md` §2/§4 the row:
`Dataset | Base route | Ckpt step | Prior | α | N@10 | R@10 | N@50 | R@50 | Status`, using the FULL-POP
`fulltest_agentr` numbers from `fulltest_<ds>.json` and the `fulltest_vs_no_ranking_bootstrap` sig flags.

### Sanity checks (must all pass, per fulltest_<ds>.json)
- `n_test_population` == full official label==2 population (no rankable filtering).
- `coverage_gt_in_top50` < 1 and `Recall@50` is NOT 1.0 (rankable artifact avoided).
- GT-missing users contribute 0 (they get the frozen planner order, GT∉slate).
- Planner-conditioned substrate (`frozen_<ds>_planner_modern`) + LLM STM/LTM memory used.
- prior/alpha/ckpt were fixed from DEV; TEST not used for selection.

---

## Notes / gotchas (fork report)
- **`--known-planner-r50` is OPTIONAL** (`default=None`). New datasets have no prior exp10
  planner_conditioned number, so `downstream_one_ds.sh` omits it — stage1 still prints the reproduced
  `planner_conditioned frozen test R@50` vs `prior_only(exp10)` for eyeballing; it only asserts the
  `abs_err<=2e-3` gate when a known value is supplied. (Existing SW/Game/Music/Industrial pass it.)
  Source of the known value for the finalized 4: their exp16 stage1 log line, not a stored field.
- **stage 3 (planner_ctx) is CPU** — `stage_planner_build.py` imports only `pcr_common`/`numpy`, no
  torch/cuda/encoder. Only **stage 4 (planner LLM deltas)** needs GPUs (8 shards via vLLM).
- **`run_offline` / `stage_planner_build` honor `AGENTR_TOOLCACHE_SUFFIX=_modern`** → they read/write the
  `_modern` cache and `offline_<ds>_modern.json`; `load_prior_weights` (pr_common) reads the same
  `_modern` offline. Export the suffix (downstream_one_ds.sh does).
- **Legacy cache dependency:** `assemble_modern_cache.py` copies the `mem/pop/keyword` slots from the
  pre-existing `outputs/results/<ds>/precomputed_tool_cache.pkl` — it must be present (all 5 new datasets
  have it). Missing → stage 1 aborts (guarded).
- **Tiny-user datasets:** DoubanBook_dg (~1.7k users) and DoubanMusic_dg (~1.3k users) give very small
  residual splits → few steps/epoch. Raise EPOCHS (stage 7) so dev-select has ≥3 real checkpoints.
- **`_dg` profiles:** brand/category user-profile signal is weaker on the `_dg` datasets than on the core
  4; expect lower coverage / smaller residual lift — this is expected, not a bug.
- **MIND_dg is BLOCKED:** zero label==2 rows (impression-ranking test format) — out of scope, do not run.
- **Do not reuse old `_planner` checkpoints or `resolve_shipped_ranker`** for modern runs (input mismatch).
  Always pass explicit `--ckpt/--fixed_prior/--fixed_alpha`.
