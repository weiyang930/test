#!/usr/bin/env bash
# Direct LLM Fusion baseline -- all 8 datasets, sharded across all 4 nodes / 32 GPUs.
# Each dataset = 4 shards (4 GPUs); 2 datasets per node (g0-3, g4-7). Qwen2.5-7B-Instruct via vLLM.
# Uses SHARD/NSHARDS env for sharding + explicit CUDA_VISIBLE_DEVICES (PIN_LOCAL=0). Reduce after.
set -uo pipefail
REPO=/path/to/agentr
D=$REPO/pipeline/route_bank
PY=${PY_LLM:-python}
MODEL=Qwen/Qwen2.5-7B-Instruct
NSHARDS=4
mkdir -p "$D/logs/llm_fusion"

shard () {  # ds jobid node gpu shard
  local ds=$1 jobid=$2 node=$3 gpu=$4 sh=$5
  local out=$D/artifacts/fusion/$ds/llm_shards
  srun --overlap --jobid="$jobid" --nodelist="$node" --nodes=1 --ntasks=1 --gres=gpu:1 \
       --gpu-bind=none --cpus-per-task=12 --time=6:00:00 --job-name=lf_${ds}_${sh} \
       bash -c "export CUDA_VISIBLE_DEVICES=$gpu PIN_LOCAL=0 SHARD=$sh NSHARDS=$NSHARDS \
                 TRITON_CACHE_DIR=/tmp/tr_lf_${ds}_${sh} HF_HUB_OFFLINE=1; cd $D/scripts; \
         $PY run_llm_fusion.py --ds $ds --outdir $out --model $MODEL" \
       > "$D/logs/llm_fusion/${ds}_shard${sh}.log" 2>&1 &
}

launch_ds () {  # ds jobid node gpu_base(0 or 4)
  local ds=$1 jobid=$2 node=$3 base=$4
  for s in 0 1 2 3; do shard "$ds" "$jobid" "$node" $((base + s)) "$s"; done
}

echo "=== launching Direct LLM Fusion (8 ds x 4 shards) $(date) ==="
launch_ds Software_10_80_r811   JOBID node01 0
launch_ds Game_10_80_r811       JOBID node01 4
launch_ds Industrial_10_80_r811 JOBID node02 0
launch_ds Music_10_80_r811      JOBID node02 4
launch_ds KuaiRec_dg            JOBID node03 0
launch_ds MicroLens_dg          JOBID node03 4
launch_ds DoubanBook_dg         JOBID node04  0
launch_ds DoubanMusic_dg        JOBID node04  4
echo "=== 32 shard steps backgrounded; waiting ==="
wait
echo "=== ALL LLM-FUSION SHARDS EXITED $(date) ==="
