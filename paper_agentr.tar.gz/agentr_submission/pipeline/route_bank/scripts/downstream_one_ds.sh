#!/usr/bin/env bash
# =============================================================================
# downstream_one_ds.sh  --  2026-09-25 fulltest all-dataset sweep (modern substrate)
#
# Drives the finalized Agent-R downstream chain (stages 1-6) for ONE dataset,
# starting from an ALREADY-BUILT modern route bank (route_cache/<ds>/toolcache_*.pkl
# produced by launch_all_routes_expansion.sh) and an ALREADY-BUILT LLM STM/LTM memory
# (outputs/indexes/<ds>/user_memory_llm_agent_qwen2p5_7b_instruct.json produced by
# launch_all_memory_expansion.sh). It STOPS after building the residual train/dev/test
# data; residual training + dev-select + TEST-once + full-pop eval are stages 7-10 in
# DOWNSTREAM_RUNBOOK.md (they need the 8-GPU trainer and are driven per node).
#
#   stage 1  assemble_modern_cache.py      CPU   -> precomputed_tool_cache_modern.pkl + base_selection_<ds>.json
#   stage 2  run_offline.py                CPU   -> artifacts/offline_<ds>_modern.{pkl,json}   (prior weights)
#   stage 3  stage_planner_build.py        CPU   -> artifacts/planner_ctx_<ds>_modern.pkl      (planner contexts)
#   stage 4  stage_planner_llm.py          GPU   -> artifacts/planner_delta_<ds>_modern.shard*.pkl (LLM deltas, split=both)
#   stage 5  stage1_build_planner.py       CPU   -> artifacts/frozen_<ds>_planner_modern.pkl   (planner-conditioned frozen slate)
#   stage 6  build_splits/residual_data/test_data  CPU -> data_planner_modern_mem/<ds>/{residual_users,...}.pkl
#
# All stages are IDEMPOTENT: an existing final artifact is skipped unless FORCE=1.
# Only stage 4 needs GPUs -> pass a live JOBID+NODE (8 GPUs, 8 shards). The CPU stages
# run locally in this shell.
#
# Usage:
#   DS=DoubanBook_dg JOBID=JOBID NODE=node01 bash downstream_one_ds.sh
#   FORCE=1 DS=... JOBID=... NODE=... bash downstream_one_ds.sh    # rebuild everything
#   SKIP_PLANNER_LLM=1 DS=... bash downstream_one_ds.sh            # stages 1-3,5-6 only (deltas already built)
# =============================================================================
set -uo pipefail

DS="${DS:?set DS (e.g. DoubanBook_dg)}"
JOBID="${JOBID:-}"
NODE="${NODE:-}"
FORCE="${FORCE:-0}"
SKIP_PLANNER_LLM="${SKIP_PLANNER_LLM:-0}"

REPO=/path/to/agentr
MRB=$REPO/pipeline/route_bank
EXP10=$REPO/pipeline/planning        # offline_/planner_ctx_/planner_delta_ live here
PROM=$REPO/pipeline/candidate_adaptation                   # frozen_<ds>_planner_modern.pkl lands here
RES=$REPO/pipeline/residual_ranker                 # build_splits/residual_data/test_data
DATA_DIR=$RES/data_planner_modern_mem                           # residual data root (modern + LLM memory)

PYRB=${PY_RECBOLE:-python}          # CPU stages (RecBole/pcr/pr/rr_common)
ROUTE_DIR=$MRB/artifacts/route_cache/$DS
MEM_JSON=$REPO/outputs/indexes/$DS/user_memory_llm_agent_qwen2p5_7b_instruct.json
LOGD=$MRB/logs; mkdir -p "$LOGD"

# ---- modern-substrate env (train/serve representations MUST match) -----------
export AGENTR_TOOLCACHE_SUFFIX=_modern         # load_dataset + load_prior_weights -> *_modern cache/offline
export AGENTR_FROZEN_SUFFIX=_planner_modern    # frozen_<ds>_planner_modern.pkl
export AGENTR_DATA_DIR=$DATA_DIR               # residual data isolated dir
export AGENTR_USER_MEMORY=llm                  # LLM STM/LTM memory profile (not deterministic)
export AGENTR_LOCAL_SPLIT=1
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface}
export HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub

say () { echo "[$(date +%H:%M:%S)] [$DS] $*"; }
have () { [ "$FORCE" = "0" ] && [ -e "$1" ]; }         # skip-if-exists (unless FORCE=1)

say "downstream start  route_dir=$ROUTE_DIR  data_dir=$DATA_DIR  force=$FORCE"

# ---- preconditions -----------------------------------------------------------
for t in ncl diffrec semantic_qwen3; do
  [ -e "$ROUTE_DIR/toolcache_${t}.pkl" ] || { say "MISSING route toolcache_${t}.pkl -- run launch_all_routes_expansion.sh first"; exit 2; }
done
[ -e "$REPO/outputs/results/$DS/precomputed_tool_cache.pkl" ] || { say "MISSING legacy precomputed_tool_cache.pkl (assemble copies mem/pop/keyword slots from it)"; exit 2; }

# =============================================================================
# stage 1 -- assemble modern combined tool cache + DEV base selection  (CPU)
# =============================================================================
OUT1=$REPO/outputs/results/$DS/precomputed_tool_cache_modern.pkl
if have "$OUT1"; then say "stage1 skip (have $OUT1)"; else
  say "stage1 assemble_modern_cache.py"
  $PYRB $MRB/scripts/assemble_modern_cache.py --ds "$DS" --route_dir "$ROUTE_DIR" \
        > "$LOGD/dl1_assemble_${DS}.log" 2>&1 \
    || { say "stage1 FAILED -> $LOGD/dl1_assemble_${DS}.log"; exit 1; }
  say "stage1 done -> base_selection_${DS}.json:"; cat "$MRB/artifacts/base_selection_${DS}.json" 2>/dev/null
fi

# =============================================================================
# stage 2 -- offline prior-weight fit on the modern cache  (CPU)
#   load_prior_weights honors AGENTR_TOOLCACHE_SUFFIX=_modern -> reads offline_<ds>_modern.json
# =============================================================================
OUT2=$EXP10/artifacts/offline_${DS}_modern.json
if have "$OUT2"; then say "stage2 skip (have $OUT2)"; else
  say "stage2 run_offline.py"
  $PYRB $EXP10/scripts/run_offline.py --dataset "$DS" --out "$OUT2" \
        > "$LOGD/dl2_offline_${DS}.log" 2>&1 \
    || { say "stage2 FAILED -> $LOGD/dl2_offline_${DS}.log"; exit 1; }
  say "stage2 done -> $OUT2"
fi

# =============================================================================
# stage 3 -- build planner contexts (no held-out targets seen)  (CPU)
#   MUST write planner_ctx_<ds>_modern.pkl -- launch_planner_1node.sh reads exactly that name
# =============================================================================
OUT3=$EXP10/artifacts/planner_ctx_${DS}_modern.pkl
if have "$OUT3"; then say "stage3 skip (have $OUT3)"; else
  say "stage3 stage_planner_build.py"
  $PYRB $EXP10/scripts/stage_planner_build.py --dataset "$DS" --out "$OUT3" \
        > "$LOGD/dl3_plannerctx_${DS}.log" 2>&1 \
    || { say "stage3 FAILED -> $LOGD/dl3_plannerctx_${DS}.log"; exit 1; }
  say "stage3 done -> $OUT3"
fi

# =============================================================================
# stage 4 -- planner LLM deltas (split=both)  (GPU: 8 shards on one node)
#   delegated to launch_planner_1node.sh (srun, venv_verl_megatron, Qwen2.5-7B via vLLM)
# =============================================================================
# a full shard set is 8 files; treat as present only if all 8 exist
n_shards=$(ls "$EXP10"/artifacts/planner_delta_${DS}_modern.shard*.pkl 2>/dev/null | wc -l)
if [ "$SKIP_PLANNER_LLM" = "1" ]; then
  say "stage4 skip (SKIP_PLANNER_LLM=1, found ${n_shards} shards)"
elif [ "$FORCE" = "0" ] && [ "$n_shards" -ge 8 ]; then
  say "stage4 skip (have ${n_shards} planner_delta shards)"
else
  [ -n "$JOBID" ] && [ -n "$NODE" ] || { say "stage4 needs JOBID + NODE (8-GPU node) -- set them or SKIP_PLANNER_LLM=1"; exit 2; }
  say "stage4 planner LLM (launch_planner_1node.sh) jobid=$JOBID node=$NODE split=both"
  JOBID="$JOBID" NODE="$NODE" DS="$DS" SPLIT=both bash "$MRB/scripts/launch_planner_1node.sh" \
    || { say "stage4 FAILED -> $LOGD/planner_${DS}_modern.log"; exit 1; }
  n_shards=$(ls "$EXP10"/artifacts/planner_delta_${DS}_modern.shard*.pkl 2>/dev/null | wc -l)
  say "stage4 done -> ${n_shards} planner_delta shards"
fi

# =============================================================================
# stage 5 -- planner-conditioned frozen depth-50 slate  (CPU)
#   --delta-suffix _modern reads the combined-split shards; --frozen-suffix _planner_modern isolates.
#   --known-planner-r50 OMITTED for new datasets (no prior exp10 number -> sanity gate is optional,
#   stage1 only prints repro vs prior_only when known value is absent). Existing 4 datasets pass it.
# =============================================================================
OUT5=$PROM/artifacts/frozen_${DS}_planner_modern.pkl
if have "$OUT5"; then say "stage5 skip (have $OUT5)"; else
  say "stage5 stage1_build_planner.py (delta=_modern frozen=_planner_modern)"
  $PYRB $PROM/scripts/stage1_build_planner.py --dataset "$DS" \
        --delta-suffix _modern --frozen-suffix _planner_modern \
        > "$LOGD/dl5_frozen_${DS}.log" 2>&1 \
    || { say "stage5 FAILED -> $LOGD/dl5_frozen_${DS}.log"; exit 1; }
  say "stage5 done -> $OUT5 (grep for 'planner_conditioned frozen test R@50' in log)"
  grep -h "frozen test R@50\|fallback_rate" "$LOGD/dl5_frozen_${DS}.log" || true
fi

# =============================================================================
# stage 6 -- residual train/dev/test data on the frozen slate + LLM memory  (CPU)
#   requires the LLM STM/LTM memory json (AGENTR_USER_MEMORY=llm). Writes into $DATA_DIR/<ds>/.
# =============================================================================
[ -e "$MEM_JSON" ] || { say "MISSING LLM memory $MEM_JSON -- run launch_all_memory_expansion.sh first"; exit 2; }
DSDIR=$DATA_DIR/$DS
if have "$DSDIR/residual_users.pkl" && have "$DSDIR/priorB.json"; then
  say "stage6 skip (have $DSDIR/residual_users.pkl + priorB.json)"
else
  say "stage6a build_splits.py"
  $PYRB $RES/scripts/build_splits.py --ds "$DS"        > "$LOGD/dl6a_splits_${DS}.log"   2>&1 || { say "stage6a FAILED -> $LOGD/dl6a_splits_${DS}.log"; exit 1; }
  say "stage6b build_residual_data.py"
  $PYRB $RES/scripts/build_residual_data.py --ds "$DS" > "$LOGD/dl6b_resdata_${DS}.log"  2>&1 || { say "stage6b FAILED -> $LOGD/dl6b_resdata_${DS}.log"; exit 1; }
  say "stage6c build_test_data.py"
  $PYRB $RES/scripts/build_test_data.py --ds "$DS"     > "$LOGD/dl6c_testdata_${DS}.log" 2>&1 || { say "stage6c FAILED -> $LOGD/dl6c_testdata_${DS}.log"; exit 1; }
  say "stage6 done -> $DSDIR/"
  ls -1 "$DSDIR" 2>/dev/null
fi

say "downstream COMPLETE (stages 1-6). Next: residual train + dev-select + TEST + fulltest (DOWNSTREAM_RUNBOOK.md stages 7-10)."
