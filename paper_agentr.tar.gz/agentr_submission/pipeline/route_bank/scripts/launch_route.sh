#!/usr/bin/env bash
# exp16 -- train ONE RecBole route on ONE GPU of an allocated node (via srun --overlap).
# Usage: DS=Software_10_80_r811 MODEL=NCL TOOL=ncl JOBID=JOBID NODE=node01 GPU=0 \
#        [EPOCHS=300] bash launch_route.sh
set -uo pipefail
REPO=/path/to/agentr
D=$REPO/pipeline/route_bank
PY=${PY_RECBOLE:-python}
DS=${DS:?}; MODEL=${MODEL:?}; TOOL=${TOOL:?}; JOBID=${JOBID:?}; NODE=${NODE:?}; GPU=${GPU:?}
EPOCHS=${EPOCHS:-300}
OUT=$D/artifacts/route_cache/$DS
mkdir -p "$D/logs" "$OUT"
echo "=== launch route DS=$DS MODEL=$MODEL TOOL=$TOOL node=$NODE gpu=$GPU epochs=$EPOCHS ==="
srun --overlap --jobid="$JOBID" --nodelist="$NODE" --nodes=1 --ntasks=1 --gres=gpu:1 \
     --gpu-bind=none --cpus-per-task=16 --time=06:00:00 --job-name=rb_${DS}_${TOOL} \
     bash -c "
       export CUDA_VISIBLE_DEVICES=$GPU HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
       export TRITON_CACHE_DIR=/tmp/tr_rb_${DS}_${TOOL}
       cd $REPO
       $PY $D/scripts/recbole_producer.py --ds $DS --model $MODEL --tool $TOOL \
           --epochs $EPOCHS --gpu 0 --out_dir $OUT
     " 2>&1 | tee "$D/logs/rb_${DS}_${TOOL}.log"
echo "=== done DS=$DS TOOL=$TOOL exit=$? ==="
