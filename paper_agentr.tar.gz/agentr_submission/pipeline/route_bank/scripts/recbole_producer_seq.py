#!/usr/bin/env python3
"""Baseline sweep -- SEQUENTIAL companion to recbole_producer.py (SASRec / BERT4Rec).

Sequential models need the user's item sequence, which the benchmark_filename=[train,valid,test]
mode cannot build (valid/test atomic files hold 1 interaction/user). So we:

  1. TRAIN with RecBole's native leave-one-out (eval_args.split.LS='valid_and_test', order='TO') on
     the combined `<ds>.inter`. This is the canonical sequential protocol and reproduces the SAME
     temporal-LOO split as the atomic files (train = i1..i_{n-2}, valid = i_{n-1}, test = i_n), giving
     a correct valid-metric for early stopping / best-checkpoint selection (DEV discipline).
  2. RANK every user by building their input sequence from the TRAIN-history atomic file (i1..i_{n-2},
     time-ordered, last MAX_ITEM_LIST_LENGTH), calling full_sort_predict, masking ONLY train-seen items,
     top-200. This is IDENTICAL treatment/masking to recbole_producer.py's rank_all_users, so the
     resulting toolcache is scored by single_route_fulltest.py against load_test_targets(ds) on the
     full test population -- fully comparable to the Agent-R table and the other baselines.

Output: toolcache_<tool>.pkl in the same recbole_cache_v2 schema. Does not overwrite existing artifacts.

Usage:
  python recbole_producer_seq.py --ds Software_10_80_r811 --model SASRec   --tool sasrec   [--gpu 0]
  python recbole_producer_seq.py --ds Software_10_80_r811 --model BERT4Rec --tool bert4rec [--gpu 0]
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, pickle, time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

_ORIG_TORCH_LOAD = torch.load
def _torch_load_compat(*a, **k):
    k.setdefault("weights_only", False)
    return _ORIG_TORCH_LOAD(*a, **k)
torch.load = _torch_load_compat

REPO = Path(__file__).resolve().parents[3]
RB_ROOT = REPO / "outputs" / "recbole_data"
DEFAULT_OUT = Path(__file__).resolve().parents[1] / "artifacts" / "route_cache"


def build_config_dict(ds, epochs, gpu, tool, extra=None):
    cd = {
        "data_path": str(RB_ROOT),
        "USER_ID_FIELD": "user_id",
        "ITEM_ID_FIELD": "item_id",
        "TIME_FIELD": "timestamp",
        "load_col": {"inter": ["user_id", "item_id", "timestamp"]},
        # native leave-one-out on the combined <ds>.inter (temporal), builds sequences + valid metric
        "eval_args": {"split": {"LS": "valid_and_test"}, "group_by": "user",
                      "order": "TO", "mode": "full"},
        "MAX_ITEM_LIST_LENGTH": 50,
        "train_neg_sample_args": None,   # SASRec/BERT4Rec use CE / masked-LM loss (no neg sampling)
        "metrics": ["Recall", "NDCG"],
        "topk": [10, 20, 50],
        "valid_metric": "Recall@50",
        "eval_batch_size": 4096,
        "train_batch_size": 2048,
        "epochs": epochs,
        "stopping_step": 10,
        "seed": 2020,
        "reproducibility": True,
        "show_progress": False,
        "save_dataset": False,
        "save_dataloaders": False,
        "gpu_id": str(gpu),
        # unique ckpt dir per run (shared filesystem; RecBole names by wall-clock second -> collisions)
        "checkpoint_dir": str(REPO / "outputs" / "recbole_saved" / f"{ds}_{tool}_{os.getpid()}"),
    }
    if extra:
        cd.update(extra)
    return cd


def load_train_history_tokens(ds):
    """{user_token(str): [item_token(str) in train time-order]} from the train atomic file."""
    p = RB_ROOT / ds / f"{ds}.train.inter"
    rows = defaultdict(list)  # uid -> [(ts, iid)]
    with open(p) as f:
        r = csv.reader(f, delimiter="\t")
        next(r)  # header
        for row in r:
            if len(row) < 3:
                continue
            u, i, ts = row[0], row[1], float(row[2])
            rows[u].append((ts, i))
    return {u: [i for _, i in sorted(v)] for u, v in rows.items()}


@torch.no_grad()
def rank_all_users_seq(model, dataset, device, ds, max_len, topn=200, batch=512):
    """Rank ALL users from their TRAIN-history sequence, masking train-seen items (matches
    recbole_producer.rank_all_users). Returns {uid_token: {items:[...], scores:[...]}}."""
    uid_field, iid_field = dataset.uid_field, dataset.iid_field
    n_items = dataset.item_num
    ITEM_SEQ = "item_id_list"
    ITEM_SEQ_LEN = "item_length"
    from recbole.data.interaction import Interaction

    hist_tokens = load_train_history_tokens(ds)
    # keep only users the RecBole dataset knows (token in item/user vocab)
    def tok2iid(tok):
        try:
            return int(dataset.token2id(iid_field, tok))
        except Exception:
            return None

    users = []
    seqs = []          # list of internal-id lists (train history, chrono)
    for ut, toks in hist_tokens.items():
        try:
            _ = dataset.token2id(uid_field, ut)
        except Exception:
            continue
        iids = [x for x in (tok2iid(t) for t in toks) if x is not None and x != 0]
        if not iids:
            continue
        users.append(ut)
        seqs.append(iids)

    model.eval()
    out = {}
    t0 = time.time()
    for s in range(0, len(users), batch):
        chunk_u = users[s:s + batch]
        chunk_s = seqs[s:s + batch]
        B = len(chunk_u)
        seq_tensor = torch.zeros((B, max_len), dtype=torch.long)
        seq_len = torch.zeros(B, dtype=torch.long)
        for r, iids in enumerate(chunk_s):
            trunc = iids[-max_len:]
            L = len(trunc)
            seq_tensor[r, :L] = torch.tensor(trunc, dtype=torch.long)  # left-aligned (RecBole convention)
            seq_len[r] = L
        interaction = Interaction({
            ITEM_SEQ: seq_tensor, ITEM_SEQ_LEN: seq_len,
            uid_field: torch.tensor([int(dataset.token2id(uid_field, u)) for u in chunk_u],
                                    dtype=torch.long),
        }).to(device)
        scores = model.full_sort_predict(interaction).view(B, -1)
        assert scores.shape[1] == n_items, (scores.shape, n_items)
        scores[:, 0] = -np.inf
        for r, iids in enumerate(chunk_s):
            scores[r, iids] = -np.inf                  # mask ALL train-seen items
        vals, idx = torch.topk(scores, topn, dim=1)
        idx_np = idx.cpu().numpy(); vals_np = vals.float().cpu().numpy()
        for r, ut in enumerate(chunk_u):
            it_tokens = dataset.id2token(iid_field, idx_np[r])
            out[str(ut)] = {"items": [str(x) for x in it_tokens],
                            "scores": [float(x) for x in vals_np[r]]}
        if (s // batch) % 10 == 0:
            print(f"  ranked {s + B}/{len(users)} users ({time.time()-t0:.0f}s)", flush=True)
    return out


def route_metrics(users_pred, ds, split_label, ks=(10, 20, 50)):
    tgt = {}
    with open(REPO / "data" / ds / "interaction.csv") as f:
        for row in csv.DictReader(f):
            if str(row["label"]) == str(split_label):
                tgt[str(row["userid"])] = str(row["itemid"])
    out = {}
    for k in ks:
        rec = ndcg = 0.0; n = 0
        for u, g in tgt.items():
            lst = users_pred.get(u, {}).get("items", [])
            n += 1
            if g in lst[:k]:
                rank = lst.index(g)
                rec += 1.0; ndcg += 1.0 / math.log2(rank + 2)
        out[f"recall@{k}"] = rec / max(n, 1)
        out[f"ndcg@{k}"] = ndcg / max(n, 1)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--model", required=True)     # SASRec / BERT4Rec
    ap.add_argument("--tool", required=True)       # sasrec / bert4rec
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--topn", type=int, default=200)
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--out_dir", default=None)
    ap.add_argument("--extra_json", default=None)
    args = ap.parse_args()

    torch.cuda.set_device(args.gpu)
    from recbole.config import Config
    from recbole.data import create_dataset, data_preparation
    from recbole.utils import init_seed, get_model, get_trainer

    extra = json.loads(args.extra_json) if args.extra_json else {}
    cd = build_config_dict(args.ds, args.epochs, args.gpu, args.tool, extra)
    config = Config(model=args.model, dataset=args.ds, config_dict=cd)
    init_seed(config["seed"], config["reproducibility"])
    dataset = create_dataset(config)
    max_len = config["MAX_ITEM_LIST_LENGTH"]
    print(f"[recbole-seq] {args.ds}/{args.model}: users={dataset.user_num-1} "
          f"items={dataset.item_num-1} max_len={max_len}")
    train_data, valid_data, test_data = data_preparation(config, dataset)
    device = config["device"]
    model = get_model(config["model"])(config, train_data._dataset).to(device)
    trainer = get_trainer(config["MODEL_TYPE"], config["model"])(config, model)
    t0 = time.time()
    best_valid_score, best_valid_result = trainer.fit(train_data, valid_data, saved=True,
                                                      show_progress=False)
    test_result = trainer.evaluate(test_data, show_progress=False)
    print(f"[recbole-seq] fit+eval {time.time()-t0:.0f}s; best_valid={best_valid_result}")
    ckpt = trainer.saved_model_file
    trainer.model.load_state_dict(torch.load(ckpt, map_location=device)["state_dict"])

    preds = rank_all_users_seq(trainer.model, dataset, device, args.ds, max_len, topn=args.topn)
    mv = route_metrics(preds, args.ds, 1)
    mt = route_metrics(preds, args.ds, 2)
    print(f"[route] {args.tool} VALID {mv}")
    print(f"[route] {args.tool} TEST  {mt}")

    mver = hashlib.md5((args.model + str(config["seed"])).encode()).hexdigest()[:12]
    sver = hashlib.md5(("LS_valid_and_test").encode()).hexdigest()[:12]
    blob = {
        "schema": "recbole_cache_v2", "dataset": args.ds, "tool": args.tool,
        "model": args.model, "model_version": mver, "split_version": sver, "topn": args.topn,
        "users": preds, "metrics_valid": mv, "metrics_test_reported": mt,
        "recbole_valid_result": dict(best_valid_result), "recbole_test_result": dict(test_result),
        "config": {"checkpoint_dir": str(config["checkpoint_dir"]), "epochs": args.epochs,
                   "max_item_list_length": max_len, "saved_model_file": str(ckpt),
                   "train_protocol": "LS_valid_and_test", "rank_protocol": "train_history_seq"},
    }
    out_dir = Path(args.out_dir) if args.out_dir else DEFAULT_OUT / args.ds
    out_dir.mkdir(parents=True, exist_ok=True)
    out_f = out_dir / f"toolcache_{args.tool}.pkl"
    pickle.dump(blob, open(out_f, "wb"))
    print(f"[write] {out_f}  ({len(preds)} users, depth {args.topn})")


if __name__ == "__main__":
    main()
