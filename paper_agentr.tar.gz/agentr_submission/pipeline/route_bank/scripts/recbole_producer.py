#!/usr/bin/env python3
"""exp16 -- train ONE RecBole model on a dataset's pre-split atomic files and dump a
`toolcache_<tool>.pkl` in the repo's existing `recbole_cache_v2` schema (verified 2026-09-24):

  { schema:'recbole_cache_v2', dataset, tool, model, model_version, split_version, topn:200,
    users:{ uid_token(str): {items:[iid_token str x200], scores:[float x200]} },
    metrics_valid:{recall@k,ndcg@k...}, metrics_test_reported:{...}, config:{...} }

Key correctness (matches the existing toolcache_*.pkl exactly):
 * ids are the repo's own integer ids (RecBole token space == repo id space) -> NO remapping.
 * ranking masks ONLY train-seen items per user (so a SINGLE top-200 list scores BOTH the valid and
   test targets; verified graph route has valid-recall@200=0.55, test=0.47, zero train leakage).
 * top-n = 200 depth (existing caches are depth-200; the combined precomputed cache truncates to 100).

This does NOT write the combined precomputed_tool_cache*.pkl (that is assembled later by
assemble_modern_cache.py). It does NOT overwrite any existing artifact: output name is
`toolcache_<tool>.pkl` under a caller-chosen results dir (default outputs/results/<ds>, but for
exp16 we write under artifacts/route_cache/<ds> to stay fully isolated).

Usage:
  python recbole_producer.py --ds Software_10_80_r811 --model NCL --tool ncl [--epochs 300] [--gpu 0]
  python recbole_producer.py --ds Software_10_80_r811 --model DiffRec --tool diffrec
"""
from __future__ import annotations
import argparse, hashlib, json, os, pickle, time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

# PyTorch>=2.6 defaults torch.load(weights_only=True), which RecBole's checkpoint reload cannot parse.
# Our checkpoints are locally produced/trusted -> restore the pre-2.6 behaviour globally.
_ORIG_TORCH_LOAD = torch.load
def _torch_load_compat(*a, **k):
    k.setdefault("weights_only", False)
    return _ORIG_TORCH_LOAD(*a, **k)
torch.load = _torch_load_compat

REPO = Path(__file__).resolve().parents[3]
RB_ROOT = REPO / "outputs" / "recbole_data"
DEFAULT_OUT = Path(__file__).resolve().parents[1] / "artifacts" / "route_cache"

# RecBole model type -> whether it is a full-batch (no neg sampling) generative/graph model.
# We keep RecBole's own defaults for each model and only override data/eval/epochs so the routes are
# "strong modern" out-of-the-box; NCL and DiffRec both implement full_sort_predict.
NO_NEG = {"DiffRec", "LDiffRec", "MultiVAE", "MultiDAE", "RecVAE", "MacridVAE", "EASE", "SLIMElastic"}


def build_config_dict(ds, model, epochs, extra=None):
    cd = {
        "data_path": str(RB_ROOT),
        "benchmark_filename": ["train", "valid", "test"],
        "USER_ID_FIELD": "user_id",
        "ITEM_ID_FIELD": "item_id",
        "TIME_FIELD": "timestamp",
        "load_col": {"inter": ["user_id", "item_id", "timestamp"]},
        "eval_args": {"split": {"RS": [1, 0, 0]},  # ignored under benchmark_filename; files define split
                      "group_by": "user", "order": "TO", "mode": "full"},
        "metrics": ["Recall", "NDCG"],
        "topk": [10, 20, 50],
        "valid_metric": "Recall@50",
        "eval_batch_size": 4096,
        "train_batch_size": 4096,
        "epochs": epochs,
        "stopping_step": 10,
        "seed": 2020,
        "reproducibility": True,
        "checkpoint_dir": str(REPO / "outputs" / "recbole_saved"),
        "show_progress": False,
        "save_dataset": False,
        "save_dataloaders": False,
    }
    if model in NO_NEG:
        cd["train_neg_sample_args"] = None          # generative models: no negative sampling
    if extra:
        cd.update(extra)
    return cd


@torch.no_grad()
def rank_all_users(model, dataset, train_data, device, topn=200, batch=512):
    """Return {uid_token: (item_tokens[topn], scores[topn])} ranking ALL items, masking ONLY
    each user's TRAIN-seen items (matches existing route caches)."""
    uid_field, iid_field = dataset.uid_field, dataset.iid_field
    n_items = dataset.item_num                      # includes [PAD]=0
    # train history in INTERNAL ids
    inter = train_data._dataset.inter_feat
    u_arr = inter[uid_field].numpy()
    i_arr = inter[iid_field].numpy()
    train_hist = defaultdict(list)
    for u, i in zip(u_arr, i_arr):
        train_hist[int(u)].append(int(i))
    model.eval()
    internal_uids = list(range(1, dataset.user_num))   # skip [PAD]=0
    out = {}
    t0 = time.time()
    from recbole.data.interaction import Interaction
    for s in range(0, len(internal_uids), batch):
        chunk = internal_uids[s:s + batch]
        interaction = Interaction({uid_field: torch.tensor(chunk, dtype=torch.long)}).to(device)
        scores = model.full_sort_predict(interaction)
        scores = scores.view(len(chunk), -1)           # -> [B, n_items]
        assert scores.shape[1] == n_items, (scores.shape, n_items)
        scores[:, 0] = -np.inf                          # mask [PAD] item
        for r, u in enumerate(chunk):
            h = train_hist.get(u)
            if h:
                scores[r, h] = -np.inf
        vals, idx = torch.topk(scores, topn, dim=1)     # internal iids
        idx_np = idx.cpu().numpy()
        vals_np = vals.float().cpu().numpy()
        u_tokens = dataset.id2token(uid_field, np.array(chunk))
        for r, ut in enumerate(u_tokens):
            it_tokens = dataset.id2token(iid_field, idx_np[r])
            out[str(ut)] = {"items": [str(x) for x in it_tokens],
                            "scores": [float(x) for x in vals_np[r]]}
        if (s // batch) % 10 == 0:
            print(f"  ranked {s + len(chunk)}/{len(internal_uids)} users ({time.time()-t0:.0f}s)",
                  flush=True)
    return out


def route_metrics(users_pred, ds, split_label, ks=(10, 20, 50)):
    """Recall@k / NDCG@k of a route's top-list against the leave-one-out target for a split.
    split_label: 1=valid, 2=test. Single target/user -> Recall@k in {0,1}, NDCG@k = 1/log2(rank+1)."""
    import csv, math
    tgt = {}
    with open(REPO / "data" / ds / "interaction.csv") as f:
        for row in csv.DictReader(f):
            if str(row["label"]) == str(split_label):
                tgt[str(row["userid"])] = str(row["itemid"])
    out = {}
    for k in ks:
        rec = ndcg = 0.0
        n = 0
        for u, g in tgt.items():
            lst = users_pred.get(u, {}).get("items", [])
            n += 1
            if g in lst[:k]:
                rank = lst.index(g)          # 0-based
                rec += 1.0
                ndcg += 1.0 / math.log2(rank + 2)
        out[f"recall@{k}"] = rec / max(n, 1)
        out[f"ndcg@{k}"] = ndcg / max(n, 1)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--model", required=True)        # NCL / DiffRec / LightGCN ...
    ap.add_argument("--tool", required=True)         # cache key: ncl / diffrec / lightgcn
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--topn", type=int, default=200)
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--out_dir", default=None)       # default: artifacts/route_cache/<ds>
    ap.add_argument("--extra_json", default=None)    # optional hyperparam overrides as JSON string
    args = ap.parse_args()

    torch.cuda.set_device(args.gpu)
    from recbole.config import Config
    from recbole.data import create_dataset, data_preparation
    from recbole.utils import init_seed, get_model, get_trainer

    extra = json.loads(args.extra_json) if args.extra_json else {}
    extra["gpu_id"] = str(args.gpu)
    # UNIQUE checkpoint dir per run: RecBole names checkpoints {model}-{local_time_to_the_second}.pth,
    # so concurrent runs on the shared-filesystem checkpoint_dir can collide (proven: Industrial DiffRec
    # reloaded Music's 19699-item checkpoint). Isolate every run to prevent silent weight corruption.
    extra["checkpoint_dir"] = str(REPO / "outputs" / "recbole_saved" /
                                  f"{args.ds}_{args.tool}_{os.getpid()}")
    cd = build_config_dict(args.ds, args.model, args.epochs, extra)
    config = Config(model=args.model, dataset=args.ds, config_dict=cd)
    init_seed(config["seed"], config["reproducibility"])
    dataset = create_dataset(config)
    print(f"[recbole] {args.ds}/{args.model}: users={dataset.user_num-1} items={dataset.item_num-1}")
    train_data, valid_data, test_data = data_preparation(config, dataset)
    device = config["device"]
    model = get_model(config["model"])(config, train_data._dataset).to(device)
    trainer = get_trainer(config["MODEL_TYPE"], config["model"])(config, model)
    t0 = time.time()
    best_valid_score, best_valid_result = trainer.fit(train_data, valid_data, saved=True,
                                                      show_progress=False)
    test_result = trainer.evaluate(test_data, show_progress=False)
    print(f"[recbole] fit+eval done in {time.time()-t0:.0f}s; best_valid={best_valid_result}")
    # load best checkpoint before ranking
    ckpt = trainer.saved_model_file
    trainer.model.load_state_dict(torch.load(ckpt, map_location=device)["state_dict"])
    preds = rank_all_users(trainer.model, dataset, train_data, device, topn=args.topn)

    mv = route_metrics(preds, args.ds, 1)
    mt = route_metrics(preds, args.ds, 2)
    print(f"[route] {args.tool} VALID {mv}")
    print(f"[route] {args.tool} TEST  {mt}")

    mver = hashlib.md5((args.model + str(config["seed"])).encode()).hexdigest()[:12]
    sver = hashlib.md5(str(sorted(cd["benchmark_filename"])).encode()).hexdigest()[:12]
    blob = {
        "schema": "recbole_cache_v2", "dataset": args.ds, "tool": args.tool,
        "model": args.model, "model_version": mver, "split_version": sver, "topn": args.topn,
        "users": preds, "metrics_valid": mv, "metrics_test_reported": mt,
        "recbole_valid_result": dict(best_valid_result), "recbole_test_result": dict(test_result),
        "config": {"checkpoint_dir": str(config["checkpoint_dir"]), "epochs": args.epochs,
                   "saved_model_file": str(ckpt)},
    }
    out_dir = Path(args.out_dir) if args.out_dir else DEFAULT_OUT / args.ds
    out_dir.mkdir(parents=True, exist_ok=True)
    out_f = out_dir / f"toolcache_{args.tool}.pkl"
    pickle.dump(blob, open(out_f, "wb"))
    print(f"[write] {out_f}  ({len(preds)} users, depth {args.topn})")


if __name__ == "__main__":
    main()
