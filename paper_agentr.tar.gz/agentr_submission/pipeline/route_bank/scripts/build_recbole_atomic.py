#!/usr/bin/env python3
"""exp16 -- build RecBole atomic files from the repo's interaction.csv, EXACTLY reproducing the
split convention already used for Software (verified 2026-09-24):

  interaction.csv cols: userid,itemid,timestamp,label  (label 0=train, 1=valid, 2=test; leave-one-out)
    -> <ds>.train.inter : all label==0 rows          (history)
    -> <ds>.valid.inter : label==1 rows (1 target/user)
    -> <ds>.test.inter  : label==2 rows (1 target/user)
    -> <ds>.inter       : all rows (combined; RecBole builds the id map from this in benchmark mode)

Atomic header: `user_id:token\titem_id:token\ttimestamp:float` — ids are the repo's own integer ids
(token space == repo id space), so RecBole full_sort_topk outputs map DIRECTLY back to repo item ids
with NO remapping. Idempotent: skips a dataset whose 4 atomic files already exist and match row counts
(so Software's pre-existing files are left untouched).

Usage: python build_recbole_atomic.py --ds Game_10_80_r811 [--force]
"""
from __future__ import annotations
import argparse, csv, sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]              # .../AgentRec-main
RB_ROOT = REPO / "outputs" / "recbole_data"
HEADER = "user_id:token\titem_id:token\ttimestamp:float\n"
LABEL_TO_SPLIT = {"0": "train", "1": "valid", "2": "test"}


def build(ds: str, force: bool = False):
    src = REPO / "data" / ds / "interaction.csv"
    if not src.exists():
        raise SystemExit(f"[atomic] missing interaction.csv: {src}")
    out_dir = RB_ROOT / ds
    out_dir.mkdir(parents=True, exist_ok=True)
    files = {s: out_dir / f"{ds}.{s}.inter" for s in ("train", "valid", "test")}
    comb = out_dir / f"{ds}.inter"
    if not force and comb.exists() and all(f.exists() for f in files.values()):
        counts = {s: sum(1 for _ in open(f)) - 1 for s, f in files.items()}
        print(f"[atomic] {ds} already built (rows train/valid/test = "
              f"{counts['train']}/{counts['valid']}/{counts['test']}); skip (use --force to rebuild)")
        return counts

    rows = {"train": [], "valid": [], "test": []}
    all_rows = []
    with open(src) as f:
        r = csv.DictReader(f)
        for row in r:
            line = f"{row['userid']}\t{row['itemid']}\t{row['timestamp']}\n"
            all_rows.append(line)
            sp = LABEL_TO_SPLIT.get(str(row["label"]))
            if sp is None:
                raise SystemExit(f"[atomic] unexpected label {row['label']!r} in {src}")
            rows[sp].append(line)

    for s, f in files.items():
        with open(f, "w") as fh:
            fh.write(HEADER)
            fh.writelines(rows[s])
    with open(comb, "w") as fh:
        fh.write(HEADER)
        fh.writelines(all_rows)
    counts = {s: len(rows[s]) for s in rows}
    print(f"[atomic] {ds}: wrote train/valid/test = "
          f"{counts['train']}/{counts['valid']}/{counts['test']} (combined {len(all_rows)}) -> {out_dir}")
    return counts


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--force", action="store_true")
    build(ap.parse_args().ds, ap.parse_args().force)
