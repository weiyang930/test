#!/usr/bin/env python3
"""Canonical FULL-TEST-POPULATION evaluator for the finalized Agent-R pipeline.

Motivation: the residual-ranker eval (eval_residual.py) restricts to *rankable* test users
(held-out GT already inside the frozen depth-50 slate) -> Recall@50 is 1.0 by construction. That
number is an analysis artifact, NOT a full-population recall. This evaluator scores EVERY official
TEST user (interaction.csv label==2) on the produced depth-50 recommendation list:

  * rankable users        -> the residual-reordered final-50 (dev-selected prior/alpha, from the
                             saved residual_cache_test.pkl -- NO model reload, NO re-tuning);
  * all other test users  -> the frozen planner-conditioned order (exp10_order); their GT is not in
                             the depth-50 slate, so they contribute 0 to every @k<=50 metric.

Aggregation is a plain mean over the COMPLETE test population (denominator = |frozen[test]| =
all label==2 users). Metric defs / GT are reused verbatim from the pipeline (all_metrics, single
held-out gt_id for the pipeline-canonical number; full label==2 target set for the strict variant).

TEST-once discipline: this reads ALREADY-FROZEN artifacts and re-normalizes; it does not re-select
prior/alpha/ckpt. Set them to the dev-selected values via CLI.

Writes pipeline/route_bank/artifacts/fulltest_<ds>.json + per_user CSV.
"""
from __future__ import annotations
import argparse, csv, json, os, pickle, sys
from pathlib import Path
import numpy as np

os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern")
os.environ.setdefault("AGENTR_DATA_DIR",
                      "/path/to/agentr/pipeline/"
                      "residual_ranker/data_planner_modern_mem")
os.environ.setdefault("AGENTR_USER_MEMORY", "llm")

REPO = Path("/path/to/agentr")
RES = REPO / "pipeline/residual_ranker"
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                                    # noqa: E402
import gw_eval as ge                                      # noqa: E402
from build_test_data import load_test_targets             # noqa: E402
all_metrics = ge.gw.all_metrics                            # pipeline metric defs, verbatim

MAIN_KS = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]


def build_finals(recs, residuals, which, priorB, alpha):
    out = {}
    for rec in recs:
        pv = (np.array([rr.prior_A(rk) for rk in rec["base_rank"]], float) if which == "A"
              else np.array([priorB.score(rk) for rk in rec["base_rank"]], float))
        out[rec["uid"]] = rr.fused_order(rec["cand_ids"], pv, residuals[rec["uid"]], alpha)
    return out


def agg_over(pop, pum):
    """mean of each MAIN_K over the full population `pop` (missing user -> all-zero)."""
    zero = {k: 0.0 for k in MAIN_KS}
    return {k: float(np.mean([pum.get(u, zero)[k] for u in pop])) for k in MAIN_KS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--tag", required=True, help="artifacts/<tag> holding residual_cache_test.pkl")
    ap.add_argument("--prior", required=True, choices=["A", "B"])
    ap.add_argument("--alpha", type=float, required=True)
    ap.add_argument("--base_route", default="graph")
    args = ap.parse_args()

    blob = rr.gw.load_frozen(args.ds)
    frozen_t = blob["frozen"]["test"]
    pop = list(frozen_t.keys())                            # COMPLETE test population
    tmap = load_test_targets(args.ds)                      # {uid: [label==2 items]}
    n_pop = len(pop)
    n_with_tgt = sum(1 for u in pop if tmap.get(u))

    recs = pickle.load(open(rr.DATA_DIR / args.ds / "residual_users.pkl", "rb"))["test"]
    rankable = [r["uid"] for r in recs]
    gt_single = {r["uid"]: r["gt_id"] for r in recs}       # pipeline-canonical held-out GT

    cache_f = RES / "artifacts" / args.tag / "residual_cache_test.pkl"
    residuals = pickle.load(open(cache_f, "rb"))
    priorB = rr.PriorB(json.load(open(rr.DATA_DIR / args.ds / "priorB.json"))["score_by_rank"])
    finals = build_finals(recs, residuals, args.prior, priorB, args.alpha)

    # final list per user: reordered for rankable, frozen planner order otherwise
    def final_list(u):
        return finals[u] if u in finals else list(frozen_t[u]["exp10_order"])

    # ---- (canonical) full label==2 target set, full population
    pum_full = {u: all_metrics(final_list(u), tmap.get(u, [])) for u in pop}
    agg_full = agg_over(pop, pum_full)
    # no_ranking (planner-conditioned, no residual head) on the SAME full population
    pum_nr = {u: all_metrics(list(frozen_t[u]["exp10_order"]), tmap.get(u, [])) for u in pop}
    agg_nr = agg_over(pop, pum_nr)

    # ---- (sanity) single-gt on rankable subset -> must reproduce eval.json / §15.1
    pum_rank_single = {u: all_metrics(finals[u], [gt_single[u]]) for u in rankable}
    agg_rank_single = {k: float(np.mean([pum_rank_single[u][k] for u in rankable])) for k in MAIN_KS}
    pum_nr_rank_single = {u: all_metrics(list(frozen_t[u]["exp10_order"]), [gt_single[u]])
                          for u in rankable}
    agg_nr_rank_single = {k: float(np.mean([pum_nr_rank_single[u][k] for u in rankable]))
                          for k in MAIN_KS}

    # full-population significance: paired bootstrap Agent-R vs no_ranking (same users, seed 42)
    bs = ge.bootstrap_cmp(pop, pum_full, pum_nr, metrics=MAIN_KS)

    # coverage: fraction of full population with GT in the depth-50 slate
    cov = len(rankable) / n_pop

    out = {
        "dataset": args.ds, "tag": args.tag, "base_route": args.base_route,
        "prior": args.prior, "alpha": args.alpha,
        "n_test_population": n_pop, "n_with_label2_target": n_with_tgt,
        "n_rankable": len(rankable), "coverage_gt_in_top50": cov,
        "fulltest_agentr": agg_full, "fulltest_no_ranking": agg_nr,
        "fulltest_vs_no_ranking_bootstrap": bs,
        "rankable_single_gt_agentr": agg_rank_single,
        "rankable_single_gt_no_ranking": agg_nr_rank_single,
    }
    outd = REPO / "pipeline/route_bank/artifacts"
    outd.mkdir(parents=True, exist_ok=True)
    json.dump(out, open(outd / f"fulltest_{args.ds}.json", "w"), indent=2)
    with open(outd / f"fulltest_{args.ds}_per_user.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["uid", "rankable"] + [f"{k}" for k in MAIN_KS])
        for u in pop:
            w.writerow([u, int(u in finals)] + [f"{pum_full[u][k]:.6f}" for k in MAIN_KS])

    print(f"===== FULL-TEST-POPULATION  ds={args.ds}  (prior {args.prior}, alpha {args.alpha}) =====")
    print(f" test population = {n_pop}  | with label2 target = {n_with_tgt} "
          f"| rankable (GT in top50) = {len(rankable)}  coverage = {cov:.4f}")
    print(" FULL-POP (official label==2 targets, mean over ALL test users):")
    print(f"   Agent-R      N@10={agg_full['NDCG@10']:.4f}  R@10={agg_full['Recall@10']:.4f}  "
          f"N@50={agg_full['NDCG@50']:.4f}  R@50={agg_full['Recall@50']:.4f}")
    print(f"   no_ranking   N@10={agg_nr['NDCG@10']:.4f}  R@10={agg_nr['Recall@10']:.4f}  "
          f"N@50={agg_nr['NDCG@50']:.4f}  R@50={agg_nr['Recall@50']:.4f}")
    print(f"   vs no_ranking: N@10 d={bs['NDCG@10']['delta']:+.4f} sig={bs['NDCG@10']['sig']} | "
          f"R@10 d={bs['Recall@10']['delta']:+.4f} sig={bs['Recall@10']['sig']} | "
          f"N@50 d={bs['NDCG@50']['delta']:+.4f} sig={bs['NDCG@50']['sig']}")
    print(" SANITY (rankable subset, single held-out gt -> should match §15.1 / eval.json):")
    print(f"   Agent-R      N@10={agg_rank_single['NDCG@10']:.4f}  R@10={agg_rank_single['Recall@10']:.4f}"
          f"  R@50={agg_rank_single['Recall@50']:.4f}")
    print(f"   no_ranking   N@10={agg_nr_rank_single['NDCG@10']:.4f}  "
          f"R@10={agg_nr_rank_single['Recall@10']:.4f}  R@50={agg_nr_rank_single['Recall@50']:.4f}")
    print(f"[write] {outd}/fulltest_{args.ds}.json")


if __name__ == "__main__":
    main()
