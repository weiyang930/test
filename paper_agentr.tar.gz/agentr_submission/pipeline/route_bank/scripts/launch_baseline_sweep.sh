#!/usr/bin/env bash
# 2026-09-25 CF baseline sweep -- BPR / SASRec / BERT4Rec on all 8 Agent-R main-table datasets,
# parallel across the 4 allocated nodes (2 P6 = B200, 2 P5 = H100). LightGCN is REUSED from the
# existing route bank (artifacts/route_cache/<ds>/toolcache_lightgcn.pkl) -> not retrained.
#   BPR      -> recbole_producer.py      (general, epochs 300)
#   SASRec   -> recbole_producer_seq.py  (sequential LOO train + train-history ranking, epochs 200)
#   BERT4Rec -> recbole_producer_seq.py
# Each producer sets a UNIQUE per-run checkpoint_dir -> safe concurrent on a shared filesystem.
# Output: artifacts/baseline_cache/<ds>/toolcache_<tool>.pkl  (isolated; never overwrites route_cache).
set -uo pipefail
REPO=/path/to/agentr
D=$REPO/pipeline/route_bank
PYRB=${PY_RECBOLE:-python}
mkdir -p "$D/logs/baseline"

job () {  # ds jobid node gpu model tool producer epochs
  local ds=$1 jobid=$2 node=$3 gpu=$4 model=$5 tool=$6 prod=$7 ep=$8
  local out=$D/artifacts/baseline_cache/$ds; mkdir -p "$out"
  srun --overlap --jobid="$jobid" --nodelist="$node" --nodes=1 --ntasks=1 --gres=gpu:1 \
       --gpu-bind=none --cpus-per-task=12 --time=10:00:00 --job-name=bl_${tool}_${ds} \
       bash -c "export CUDA_VISIBLE_DEVICES=$gpu TRITON_CACHE_DIR=/tmp/tr_bl_${tool}_${ds}; cd $D/scripts; \
         $PYRB $prod --ds $ds --model $model --tool $tool --epochs $ep --gpu 0 --out_dir $out" \
       > "$D/logs/baseline/${ds}_${tool}.log" 2>&1 &
}

launch_ds () {  # ds jobid node gpubase  -> BPR(g), SASRec(g+1), BERT4Rec(g+2)
  local ds=$1 jobid=$2 node=$3 g=$4
  job "$ds" "$jobid" "$node" "$g"       BPR      bpr      recbole_producer.py     300
  job "$ds" "$jobid" "$node" "$((g+1))" SASRec   sasrec   recbole_producer_seq.py 200
  job "$ds" "$jobid" "$node" "$((g+2))" BERT4Rec bert4rec recbole_producer_seq.py 200
}

echo "=== launching baseline sweep $(date) ==="
# P6-1 = B200 132-139 (JOBID): Software + Game
launch_ds Software_10_80_r811   JOBID node01 0
launch_ds Game_10_80_r811       JOBID node01 3
# P6-2 = B200 129-223 (JOBID): Industrial + Music
launch_ds Industrial_10_80_r811 JOBID node02 0
launch_ds Music_10_80_r811      JOBID node02 3
# P5-1 = H100 207-177 (JOBID): KuaiRec + MicroLens
launch_ds KuaiRec_dg            JOBID node03 0
launch_ds MicroLens_dg          JOBID node03 3
# P5-2 = H100 213-56 (JOBID): DoubanBook + DoubanMusic
launch_ds DoubanBook_dg         JOBID node04  0
launch_ds DoubanMusic_dg        JOBID node04  3
echo "=== all 24 baseline srun steps backgrounded; waiting ==="
wait
echo "=== ALL BASELINE JOBS EXITED $(date) ==="
