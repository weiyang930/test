#!/usr/bin/env bash
# 2026-09-25 fulltest expansion -- build LLM STM/LTM user memory (Qwen2.5-7B-Instruct via vLLM) for
# the 5 runnable new datasets. Independent of route training -> run NOW on the free GPUs. Output goes
# to outputs/indexes/<ds>/user_memory_llm_agent_qwen2p5_7b_instruct.json (the exact filename the
# residual ranker's rr_common expects for AGENTR_USER_MEMORY=llm). TP=2 (28 heads divisible).
set -uo pipefail
REPO=/path/to/agentr
PY=${PY_LLM:-python}
MODEL=Qwen/Qwen2.5-7B-Instruct
LOGD=$REPO/pipeline/route_bank/logs
mkdir -p "$LOGD"

mem () {  # ds cfg jobid node gpus(csv)
  local ds=$1 cfg=$2 jobid=$3 node=$4 gpus=$5
  srun --overlap --jobid="$jobid" --nodelist="$node" --nodes=1 --ntasks=1 --gres=gpu:2 \
       --gpu-bind=none --cpus-per-task=16 --time=06:00:00 --job-name=mem_${ds} \
       bash -c "export CUDA_VISIBLE_DEVICES=$gpus HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
                       HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} \
                       HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub \
                       VLLM_ENABLE_V1_MULTIPROCESSING=0 VLLM_WORKER_MULTIPROC_METHOD=spawn \
                       VLLM_CACHE_ROOT=/tmp/vllm_mem_${ds} TRITON_CACHE_DIR=/tmp/tr_mem_${ds} \
                       TORCHINDUCTOR_CACHE_DIR=/tmp/ti_mem_${ds}; \
                rm -rf /tmp/vllm_mem_${ds}; cd $REPO; \
         $PY scripts/build_llm_user_memory.py --dataset-config $cfg \
             --llm-backend vllm --llm-model-name $MODEL --tensor-parallel-size 2 \
             --gpu-memory-utilization 0.9 --max-model-len 8192 --llm-temperature 0.0" \
       > "$LOGD/mem_${ds}.log" 2>&1 &
}

echo "=== launching LLM memory jobs $(date) ==="
mem Adressa_dg     configs/adressa_dg_tool_only.yaml     JOBID node04  0,1
mem DoubanBook_dg  configs/doubanbook_dg_tool_only.yaml  JOBID node04  2,3
mem DoubanMusic_dg configs/doubanmusic_dg_tool_only.yaml JOBID node04  4,5
mem KuaiRec_dg     configs/kuairec_dg_tool_only.yaml     JOBID node04  6,7
mem MicroLens_dg   configs/microlens_dg_tool_only.yaml   JOBID node03 4,5
echo "=== 5 memory srun steps backgrounded; waiting ==="
wait
echo "=== ALL MEMORY JOBS EXITED $(date) ==="
