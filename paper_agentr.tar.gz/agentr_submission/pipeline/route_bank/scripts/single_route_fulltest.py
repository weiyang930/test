#!/usr/bin/env python3
"""Single-route FULL-TEST-POPULATION eval -- companion to fulltest_eval.py.

For each recommendation route that FEEDS the Agent-R pipeline (the modern route bank slots:
graph=base_route_model, collab=aux_collab_model, semantic=semantic_tool), score that route's
OWN ranked list on EXACTLY the same population + GT + metric defs as fulltest_eval.py, so the
single-route numbers are directly comparable to `fulltest_agentr` / `fulltest_no_ranking`.

  population   = frozen[test] keys (every official label==2 test user)          [identical]
  GT           = load_test_targets(ds)  (full label==2 target set)              [identical]
  metric defs  = gw.all_metrics (NDCG/Recall@{10,50})                           [identical]
  per user     = route's top-50 items from route_cache/<ds>/toolcache_<r>.pkl['users'][uid]['items']
  missing user = route did not rank uid -> empty list -> contributes 0          [identical policy]
  aggregate    = plain mean over the COMPLETE population                        [identical]

Reads only; writes pipeline/route_bank/artifacts/single_route_fulltest_<ds>.json.
"""
from __future__ import annotations
import argparse, json, os, pickle, sys
from pathlib import Path
import numpy as np

os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern")
os.environ.setdefault("AGENTR_DATA_DIR",
                      "/path/to/agentr/pipeline/"
                      "residual_ranker/data_planner_modern_mem")
os.environ.setdefault("AGENTR_USER_MEMORY", "llm")

REPO = Path("/path/to/agentr")
RES = REPO / "pipeline/residual_ranker"
MRB = REPO / "pipeline/route_bank"
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                                    # noqa: E402
import gw_eval as ge                                      # noqa: E402
from build_test_data import load_test_targets             # noqa: E402
all_metrics = ge.gw.all_metrics

MAIN_KS = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
# toolcache filename per route-model label used in base_selection
MODEL_TO_TOOLCACHE = {"NCL": "ncl", "DiffRec": "diffrec", "LightGCN": "lightgcn"}


def route_metrics(route_users, pop, tmap):
    zero = {k: 0.0 for k in MAIN_KS}
    pum = {}
    for u in pop:
        rec = route_users.get(u)
        lst = rec["items"][:50] if rec else []
        pum[u] = all_metrics(lst, tmap.get(u, [])) if lst else zero
    return {k: float(np.mean([pum[u][k] for u in pop])) for k in MAIN_KS}


def list_route_metrics(uid2list, pop, tmap):
    """For routes stored as uid -> ranked item list (modern tool cache: mem, popularity)."""
    zero = {k: 0.0 for k in MAIN_KS}
    pum = {}
    for u in pop:
        lst = uid2list.get(u, [])[:50]
        pum[u] = all_metrics(lst, tmap.get(u, [])) if lst else zero
    return {k: float(np.mean([pum[u][k] for u in pop])) for k in MAIN_KS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    args = ap.parse_args()
    ds = args.ds

    blob = rr.gw.load_frozen(ds)
    pop = list(blob["frozen"]["test"].keys())              # identical population
    tmap = load_test_targets(ds)                           # identical GT

    sel = json.load(open(MRB / "artifacts" / f"base_selection_{ds}.json"))
    # every candidate route in the bank, BY MODEL NAME (these are the single-route inputs the
    # Agent-R pipeline fuses). Slot roles from base_selection are recorded for reference.
    role = {}
    role[MODEL_TO_TOOLCACHE.get(sel["base_route_model"])] = "graph/base"
    role[MODEL_TO_TOOLCACHE.get(sel["aux_collab_model"])] = "collab"
    role["semantic_qwen3"] = "semantic"
    ROUTES = [("NCL", "ncl"), ("DiffRec", "diffrec"),
              ("LightGCN", "lightgcn"), ("semantic_qwen3", "semantic_qwen3")]
    rc = MRB / "artifacts" / "route_cache" / ds

    out = {"dataset": ds, "n_test_population": len(pop),
           "base_route_model": sel["base_route_model"],
           "aux_collab_model": sel["aux_collab_model"],
           "semantic_tool": sel.get("semantic_tool", "semantic_qwen3"),
           "routes": {}}
    for name, tc in ROUTES:
        f = rc / f"toolcache_{tc}.pkl"
        if not f.exists():
            out["routes"][name] = {"toolcache": tc, "error": "missing"}
            continue
        users = pickle.load(open(f, "rb"))["users"]
        m = route_metrics(users, pop, tmap)
        out["routes"][name] = {"toolcache": tc, "role": role.get(tc, "candidate(not selected)"), **m}
        print(f"[{ds}] {name:14s} [{role.get(tc,'candidate'):24s}] "
              f"N@10={m['NDCG@10']:.4f} R@10={m['Recall@10']:.4f} "
              f"N@50={m['NDCG@50']:.4f} R@50={m['Recall@50']:.4f}")

    # reused non-learned routes (mem retrieval, popularity prior): stored as uid -> ranked list in
    # the assembled modern tool cache. Same population/GT/metric defs; same item-id space (the modern
    # cache's 'graph' tool reproduces base_selection byte-for-byte).
    mc_path = REPO / "outputs" / "results" / ds / "precomputed_tool_cache_modern.pkl"
    if mc_path.exists():
        mc = pickle.load(open(mc_path, "rb"))
        for name, tool, r in [("mem-ret", "mem", "memory (reused)"),
                              ("popularity", "popularity", "popularity (reused)")]:
            if tool not in mc:
                out["routes"][name] = {"toolcache": f"{tool}(modern_cache)", "error": "missing"}
                continue
            m = list_route_metrics(mc[tool], pop, tmap)
            out["routes"][name] = {"toolcache": f"{tool}(modern_cache)", "role": r, **m}
            print(f"[{ds}] {name:14s} [{r:24s}] "
                  f"N@10={m['NDCG@10']:.4f} R@10={m['Recall@10']:.4f} "
                  f"N@50={m['NDCG@50']:.4f} R@50={m['Recall@50']:.4f}")

    outp = MRB / "artifacts" / f"single_route_fulltest_{ds}.json"
    json.dump(out, open(outp, "w"), indent=2)
    print(f"[write] {outp}")


if __name__ == "__main__":
    main()
