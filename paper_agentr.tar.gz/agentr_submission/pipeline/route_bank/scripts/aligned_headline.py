#!/usr/bin/env python3
"""exp16 -- ALIGNED headline comparison: Full Agent-R vs strongest single modern route vs
strongest same-information fusion, on the EXACT ranker TEST users (same uids, same TEST GT).

Why a dedicated script: modern_fusion.py bootstraps each fuser vs the base route only. The reviewer
headline needs paired significance of *Agent-R* against (a) the strongest single modern route and
(b) the strongest same-info fusion, computed on IDENTICAL users. So we:
  1. read the residual ranker's per_user_results.csv  -> uid -> Agent-R per-user N@10 (N@10_sel) and
     gt_rank_sel (1-indexed GT rank after the selected ranker order; R@10 = gt_rank_sel<=10);
     N@10_base = the planner-conditioned frozen "no_ranking" base order.
  2. read interaction.csv label=2 -> uid -> TEST GT (aligns exactly with those users).
  3. from the MODERN combined cache, build, per user: each single route order and each fusion order
     (RRF / val-weighted / zscore / learned-logreg). Fusion params are fit ONLY on FIT(80%) users'
     VALID targets -- identical no-leakage protocol to modern_fusion.py.
  4. pick strongest single route and strongest fusion by mean N@10 on the aligned users.
  5. paired bootstrap (pcr_common, seed 42, 10k) of Agent-R minus each competitor.

Discipline: this is analysis-only on the ALREADY-FROZEN test predictions; no tuning, no re-selection.

Usage: python aligned_headline.py --ds Software_10_80_r811 --ranker_dir <res_*_modern_TEST>
"""
from __future__ import annotations
import argparse, csv, json, math, pickle, sys
from pathlib import Path
import numpy as np

REPO = Path(__file__).resolve().parents[3]
ART = Path(__file__).resolve().parents[1] / "artifacts"
SCR = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / "pipeline" / "planning" / "scripts"))
sys.path.insert(0, str(SCR))
from pcr_common import paired_bootstrap  # noqa: E402
import modern_fusion as mf  # reuse load_targets, uid_in_fit, rr_vectors, fuse_*, feat, metrics_user

SINGLE_ROUTES = ["graph", "collab", "semantic", "mem", "popularity"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--ranker_dir", required=True, help="residual ranker artifacts dir (has per_user_results.csv)")
    ap.add_argument("--cache", default="precomputed_tool_cache_modern.pkl")
    ap.add_argument("--base", default="graph")
    args = ap.parse_args()

    # ---- 1. Agent-R per-user results (the frozen selected config)
    def ndcg_at(rank, k):  # 1-indexed rank; N@k=1/log2(rank+1) if rank<=k else 0
        return (1.0 / math.log2(rank + 1.0)) if rank <= k else 0.0

    ar = {}  # uid -> full Agent-R metrics (from gt_rank_sel) + planner no_ranking (from gt_base_rank)
    with open(Path(args.ranker_dir) / "per_user_results.csv") as f:
        for row in csv.DictReader(f):
            u = str(row["uid"])
            grs = int(row["gt_rank_sel"]); grb = int(row["gt_base_rank"])
            ar[u] = {"n10": float(row["N@10_sel"]),
                     "r10": 1.0 if grs <= 10 else 0.0,
                     "n50": ndcg_at(grs, 50), "r50": 1.0 if grs <= 50 else 0.0,
                     "n10_base": float(row["N@10_base"]),
                     "r10_base": 1.0 if grb <= 10 else 0.0,
                     "n50_base": ndcg_at(grb, 50), "r50_base": 1.0 if grb <= 50 else 0.0}
    users = list(ar.keys())

    # ---- 2. TEST GT (label 2) for those exact users
    test_tgt = mf.load_targets(args.ds, "2")
    valid_tgt = mf.load_targets(args.ds, "1")
    missing_gt = [u for u in users if u not in test_tgt]
    users = [u for u in users if u in test_tgt]

    # ---- 3. modern cache + FIT-fitted fusion params (same protocol as modern_fusion)
    cache = pickle.load(open(REPO / f"outputs/results/{args.ds}/{args.cache}", "rb"))
    routes = [r for r in SINGLE_ROUTES if r in cache]
    missing_cache = [u for u in users if u not in cache.get(args.base, {})]
    fit_users = [u for u in valid_tgt if mf.uid_in_fit(u)]

    w = {}
    for r in routes:
        hit = sum(valid_tgt[u] in cache[r].get(u, [])[:mf.FINAL_K] for u in fit_users)
        w[r] = hit / max(len(fit_users), 1)
    zst = {}
    for r in routes:
        vals = []
        for u in fit_users:
            vals.extend(1.0 / (rk + 1.0) for rk in range(min(mf.DEPTH, len(cache[r].get(u, [])))))
        a = np.asarray(vals) if vals else np.zeros(1)
        zst[r] = (float(a.mean()), float(a.std()))
    from sklearn.linear_model import LogisticRegression
    X, y = [], []
    for u in fit_users:
        rrmap = mf.rr_vectors(cache, routes, u)
        g = valid_tgt[u]
        for it, d in rrmap.items():
            X.append(mf.feat(d, routes)); y.append(1 if it == g else 0)
    lr = LogisticRegression(max_iter=1000, class_weight="balanced")
    if len(set(y)) > 1:
        lr.fit(np.asarray(X), np.asarray(y))

    def fuse_learned(rrmap):
        its = list(rrmap.keys())
        if not its:
            return []
        F = np.asarray([mf.feat(rrmap[it], routes) for it in its])
        s = F @ lr.coef_[0] + lr.intercept_[0]
        return [its[i] for i in np.argsort(-s)]

    # ---- per-user metrics for every single route and every fusion, on aligned users
    single_pu = {r: {} for r in routes}
    fusion_names = ["rrf", "val_weighted_linear", "zscore_avg", "learned_logreg"]
    fus_pu = {m: {} for m in fusion_names}
    for u in users:
        g = test_tgt[u]
        for r in routes:
            single_pu[r][u] = mf.metrics_user(cache[r].get(u, []), g)
        rrmap = mf.rr_vectors(cache, routes, u)
        orders = {"rrf": mf.fuse_rrf(rrmap),
                  "val_weighted_linear": mf.fuse_weighted(rrmap, w),
                  "zscore_avg": mf.fuse_zscore(rrmap, routes, zst),
                  "learned_logreg": fuse_learned(rrmap)}
        for m in fusion_names:
            fus_pu[m][u] = mf.metrics_user(orders[m], g)

    METR = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]

    def agg_all(pu):
        return {k: float(np.mean([pu[u][k] for u in users])) for k in METR}

    def mean_n10(pu):
        return float(np.mean([pu[u]["NDCG@10"] for u in users]))

    single_full = {r: agg_all(single_pu[r]) for r in routes}
    fusion_full = {m: agg_all(fus_pu[m]) for m in fusion_names}
    single_mean = {r: single_full[r]["NDCG@10"] for r in routes}
    fusion_mean = {m: fusion_full[m]["NDCG@10"] for m in fusion_names}
    best_single = max(routes, key=lambda r: single_mean[r])
    best_fusion = max(fusion_names, key=lambda m: fusion_mean[m])

    # ---- Agent-R aggregate + paired bootstrap vs each competitor (Agent-R minus competitor)
    agentr_n10 = float(np.mean([ar[u]["n10"] for u in users]))
    agentr_r10 = float(np.mean([ar[u]["r10"] for u in users]))

    def boot_vs(comp_pu, metric_ar_key, comp_key):
        d = [ar[u][metric_ar_key] - comp_pu[u][comp_key] for u in users]
        mean, lo, hi = paired_bootstrap(d)
        return {"delta": mean, "lo": lo, "hi": hi, "sig": (lo > 0 or hi < 0)}

    comparisons = {
        "vs_strongest_single_route": {
            "route": best_single, "n10": single_mean[best_single],
            "r10": float(np.mean([single_pu[best_single][u]["Recall@10"] for u in users])),
            "N@10": boot_vs(single_pu[best_single], "n10", "NDCG@10"),
            "R@10": boot_vs(single_pu[best_single], "r10", "Recall@10")},
        "vs_strongest_fusion": {
            "fusion": best_fusion, "n10": fusion_mean[best_fusion],
            "r10": float(np.mean([fus_pu[best_fusion][u]["Recall@10"] for u in users])),
            "N@10": boot_vs(fus_pu[best_fusion], "n10", "NDCG@10"),
            "R@10": boot_vs(fus_pu[best_fusion], "r10", "Recall@10")},
    }
    # also Agent-R vs the planner-conditioned no_ranking base (sanity: should match ranker eval)
    d_base = [ar[u]["n10"] - ar[u]["n10_base"] for u in users]
    m_b, lo_b, hi_b = paired_bootstrap(d_base)

    out = {"ds": args.ds, "n_aligned_users": len(users),
           "n_missing_gt": len(missing_gt), "n_missing_cache": len(missing_cache),
           "agent_r": {"NDCG@10": agentr_n10, "Recall@10": agentr_r10,
                       "NDCG@50": float(np.mean([ar[u]["n50"] for u in users])),
                       "Recall@50": float(np.mean([ar[u]["r50"] for u in users]))},
           "planner_no_ranking": {"NDCG@10": float(np.mean([ar[u]["n10_base"] for u in users])),
                                   "Recall@10": float(np.mean([ar[u]["r10_base"] for u in users])),
                                   "NDCG@50": float(np.mean([ar[u]["n50_base"] for u in users])),
                                   "Recall@50": float(np.mean([ar[u]["r50_base"] for u in users]))},
           "single_route_n10": single_mean, "fusion_n10": fusion_mean,
           "single_route_full": single_full, "fusion_full": fusion_full,
           "best_single": best_single, "best_fusion": best_fusion,
           "val_weights": w, "comparisons": comparisons,
           "agent_r_vs_planner_no_ranking_N@10": {"delta": m_b, "lo": lo_b, "hi": hi_b,
                                                   "sig": (lo_b > 0 or hi_b < 0)}}
    ART.mkdir(parents=True, exist_ok=True)
    json.dump(out, open(ART / f"aligned_headline_{args.ds}.json", "w"), indent=2)

    print(f"\n===== ALIGNED HEADLINE {args.ds}  n={len(users)} "
          f"(missing_gt={len(missing_gt)}, missing_cache={len(missing_cache)}) =====")
    print("  single routes N@10: " + ", ".join(f"{r}={single_mean[r]:.4f}" for r in routes))
    print("  fusions      N@10: " + ", ".join(f"{m}={fusion_mean[m]:.4f}" for m in fusion_names))
    print(f"  planner no_ranking  N@10={out['planner_no_ranking']['NDCG@10']:.4f} R@10={out['planner_no_ranking']['Recall@10']:.4f}")
    print(f"  >> FULL AGENT-R     N@10={agentr_n10:.4f} R@10={agentr_r10:.4f}")
    c = comparisons["vs_strongest_single_route"]
    print(f"  vs strongest SINGLE route [{c['route']}] N@10={c['n10']:.4f}: "
          f"ΔN@10={c['N@10']['delta']:+.4f} [{c['N@10']['lo']:+.4f},{c['N@10']['hi']:+.4f}] sig={c['N@10']['sig']} | "
          f"ΔR@10={c['R@10']['delta']:+.4f} sig={c['R@10']['sig']}")
    c = comparisons["vs_strongest_fusion"]
    print(f"  vs strongest FUSION [{c['fusion']}]  N@10={c['n10']:.4f}: "
          f"ΔN@10={c['N@10']['delta']:+.4f} [{c['N@10']['lo']:+.4f},{c['N@10']['hi']:+.4f}] sig={c['N@10']['sig']} | "
          f"ΔR@10={c['R@10']['delta']:+.4f} sig={c['R@10']['sig']}")
    b = out["agent_r_vs_planner_no_ranking_N@10"]
    print(f"  vs planner no_ranking       ΔN@10={b['delta']:+.4f} [{b['lo']:+.4f},{b['hi']:+.4f}] sig={b['sig']} (sanity vs ranker eval)")
    print(f"[write] artifacts/aligned_headline_{args.ds}.json")


if __name__ == "__main__":
    main()
