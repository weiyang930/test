#!/usr/bin/env bash
# =============================================================================
# stage8_10_one_ds.sh -- 2026-09-25 fulltest sweep: DEV-select -> TEST-once -> fulltest
# for ONE dataset whose residual checkpoints (stage 7) already exist.
#
#   stage 8  DEV sweep per checkpoint (eval_residual.py --split dev --priors A B; internal
#            prior x alpha sweep, selects best by DEV NDCG@10, alpha>0). Read each eval.json,
#            pick the (step, prior, alpha) with the global max DEV NDCG@10.
#   stage 9  TEST once, config pinned (eval_residual.py --split test --fixed_prior --fixed_alpha).
#   stage 10 full-test-population eval (fulltest_eval.py) -> paper-table row.
#
# TEST-once discipline: selection uses DEV only; TEST runs exactly once on the frozen config.
# Each eval is single-GPU and cheap; wrapped in srun --gres=gpu:1 on the given JOBID/NODE/GPU.
#
# Usage: DS=KuaiRec_dg JOBID=JOBID NODE=node01 GPU=4 bash stage8_10_one_ds.sh
#   (BASE_ROUTE auto-read from base_selection_<ds>.json; override with BASE_ROUTE=graph|collab)
# =============================================================================
set -uo pipefail
DS="${DS:?set DS}"
JOBID="${JOBID:?set JOBID}"; NODE="${NODE:?set NODE}"; GPU="${GPU:?set GPU (single index)}"

REPO=/path/to/agentr
MRB=$REPO/pipeline/route_bank
RES=$REPO/pipeline/residual_ranker
PYGPU=${PY_LLM:-python}   # eval_residual (torch/transformers)
PYCPU=${PY_RECBOLE:-python}     # fulltest_eval (numpy only)
CKDIR=$RES/checkpoints/res_${DS}_modern
LOGD=$MRB/logs; mkdir -p "$LOGD"

export AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_FROZEN_SUFFIX=_planner_modern
export AGENTR_DATA_DIR=$RES/data_planner_modern_mem AGENTR_USER_MEMORY=llm AGENTR_LOCAL_SPLIT=1
export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub

# base-route label for the paper table: graph if DEV base winner is the NCL/DiffRec graph slot
BASE_ROUTE="${BASE_ROUTE:-}"
if [ -z "$BASE_ROUTE" ]; then
  BASE_ROUTE=$($PYCPU - "$MRB/artifacts/base_selection_${DS}.json" <<'PY' 2>/dev/null
import json,sys
d=json.load(open(sys.argv[1]))
# label = the DEV-winning graph-slot model (NCL|DiffRec), matching the paper table's "Base route"
print(d.get("base_route_model","graph"))
PY
)
fi
say () { echo "[$(date +%H:%M:%S)] [$DS] $*"; }

srun_eval () {  # tag-suffix extra-args...  -> runs eval_residual on one GPU
  local jn=$1; shift
  srun --overlap --jobid="$JOBID" --nodelist="$NODE" --nodes=1 --ntasks=1 --gres=gpu:1 \
       --gpu-bind=none --cpus-per-task=12 --time=02:00:00 --job-name="$jn" \
       bash -c "export CUDA_VISIBLE_DEVICES=$GPU HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
                       TRITON_CACHE_DIR=/tmp/tr_$jn; cd $RES/scripts; $PYGPU eval_residual.py $*"
}

[ -d "$CKDIR" ] || { say "no checkpoint dir $CKDIR (run stage 7 first)"; exit 2; }
STEPS=$(ls -d "$CKDIR"/step_* 2>/dev/null | sort -t_ -k2 -n)
[ -n "$STEPS" ] || { say "no step_* checkpoints in $CKDIR"; exit 2; }
say "checkpoints: $(echo $STEPS | sed 's#[^ ]*/##g')"

# ---- stage 8: DEV sweep per checkpoint --------------------------------------
for STEP in $STEPS; do
  n=$(basename "$STEP" | sed 's/step_//')
  tag=devsel_${DS}_s${n}
  if [ -e "$RES/artifacts/$tag/eval.json" ]; then say "dev s$n skip (have eval.json)"; continue; fi
  say "dev sweep s$n"
  srun_eval "de_${DS}_$n" --ds "$DS" --split dev --ckpt "$STEP" --tag "$tag" --priors A B \
        > "$LOGD/s8_dev_${DS}_s${n}.log" 2>&1 \
    || { say "dev s$n FAILED -> $LOGD/s8_dev_${DS}_s${n}.log"; }
done

# ---- pick best (step, prior, alpha) by DEV NDCG@10 --------------------------
read SEL_STEP SEL_PRIOR SEL_ALPHA SEL_N10 < <($PYCPU - "$RES/artifacts" "$DS" <<'PY'
import json,sys,glob,os
art, ds = sys.argv[1], sys.argv[2]
best=None
for f in glob.glob(os.path.join(art, f"devsel_{ds}_s*/eval.json")):
    d=json.load(open(f)); s=d.get("selected") or {}
    a=s.get("agg",{}).get("NDCG@10")
    if a is None: continue
    step=os.path.basename(os.path.dirname(f)).split("_s")[-1]
    if best is None or a>best[3]:
        best=(step, s["prior"], s["alpha"], a)
assert best, f"no dev eval.json for {ds}"
print(best[0], best[1], best[2], f"{best[3]:.6f}")
PY
)
say "DEV-SELECTED step=$SEL_STEP prior=$SEL_PRIOR alpha=$SEL_ALPHA (DEV N@10=$SEL_N10)"

# ---- stage 9: TEST once, pinned ---------------------------------------------
TESTTAG=res_${DS}_modern
if [ -e "$RES/artifacts/$TESTTAG/residual_cache_test.pkl" ]; then
  say "TEST skip (have $TESTTAG/residual_cache_test.pkl)"
else
  say "TEST once (pinned step=$SEL_STEP prior=$SEL_PRIOR alpha=$SEL_ALPHA)"
  srun_eval "te_${DS}" --ds "$DS" --split test --ckpt "$CKDIR/step_${SEL_STEP}" \
        --tag "$TESTTAG" --fixed_prior "$SEL_PRIOR" --fixed_alpha "$SEL_ALPHA" \
        > "$LOGD/s9_test_${DS}.log" 2>&1 \
    || { say "TEST FAILED -> $LOGD/s9_test_${DS}.log"; exit 1; }
fi

# ---- stage 10: full-test-population eval -------------------------------------
say "fulltest_eval (base_route=$BASE_ROUTE)"
$PYCPU $MRB/scripts/fulltest_eval.py --ds "$DS" --tag "$TESTTAG" \
      --prior "$SEL_PRIOR" --alpha "$SEL_ALPHA" --base_route "$BASE_ROUTE" \
      2>&1 | tee "$LOGD/s10_fulltest_${DS}.log"
say "DONE. Selected: step=$SEL_STEP prior=$SEL_PRIOR alpha=$SEL_ALPHA base=$BASE_ROUTE"
say "artifact: $MRB/artifacts/fulltest_${DS}.json"
