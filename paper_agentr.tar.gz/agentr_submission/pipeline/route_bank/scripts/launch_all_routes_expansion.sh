#!/usr/bin/env bash
# 2026-09-25 fulltest expansion -- launch ALL modern route jobs for the 5 runnable new datasets,
# parallel across the 4 allocated nodes (32 GPUs). Each dataset uses 4 GPUs:
#   NCL, DiffRec, LightGCN (RecBole, recbole_producer.py) + Qwen3-Embedding-4B semantic.
# recbole_producer sets a UNIQUE per-run checkpoint_dir (post exp16 collision fix) -> safe concurrent.
set -uo pipefail
REPO=/path/to/agentr
D=$REPO/pipeline/route_bank
PYRB=${PY_RECBOLE:-python}
QWEN=Qwen/Qwen3-Embedding-4B
EPOCHS=${EPOCHS:-300}
mkdir -p "$D/logs"

rb () {  # ds jobid node gpu model tool
  local ds=$1 jobid=$2 node=$3 gpu=$4 model=$5 tool=$6
  local out=$D/artifacts/route_cache/$ds; mkdir -p "$out"
  srun --overlap --jobid="$jobid" --nodelist="$node" --nodes=1 --ntasks=1 --gres=gpu:1 \
       --gpu-bind=none --cpus-per-task=12 --time=06:00:00 --job-name=rb_${ds}_${tool} \
       bash -c "export CUDA_VISIBLE_DEVICES=$gpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
                       TRITON_CACHE_DIR=/tmp/tr_rb_${ds}_${tool}; cd $REPO; \
         $PYRB $D/scripts/recbole_producer.py --ds $ds --model $model --tool $tool \
             --epochs $EPOCHS --gpu 0 --out_dir $out" \
       > "$D/logs/rb_${ds}_${tool}.log" 2>&1 &
}
sem () {  # ds jobid node gpu
  local ds=$1 jobid=$2 node=$3 gpu=$4
  local out=$D/artifacts/route_cache/$ds; mkdir -p "$out"
  srun --overlap --jobid="$jobid" --nodelist="$node" --nodes=1 --ntasks=1 --gres=gpu:1 \
       --gpu-bind=none --cpus-per-task=12 --time=06:00:00 --job-name=sem_${ds} \
       bash -c "export CUDA_VISIBLE_DEVICES=$gpu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
                       HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} \
                       HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub \
                       TRITON_CACHE_DIR=/tmp/tr_sem_${ds}; cd $REPO; \
         $PYRB $D/scripts/build_semantic_route.py --ds $ds --model $QWEN \
             --tool semantic_qwen3 --gpu 0 --out_dir $out" \
       > "$D/logs/sem_${ds}.log" 2>&1 &
}

launch_ds () {  # ds jobid node gpubase
  local ds=$1 jobid=$2 node=$3 g=$4
  rb  "$ds" "$jobid" "$node" "$g"       NCL      ncl
  rb  "$ds" "$jobid" "$node" "$((g+1))" DiffRec  diffrec
  rb  "$ds" "$jobid" "$node" "$((g+2))" LightGCN lightgcn
  sem "$ds" "$jobid" "$node" "$((g+3))"
}

echo "=== launching route jobs $(date) ==="
launch_ds Adressa_dg     JOBID node01 0
launch_ds DoubanBook_dg  JOBID node01 4
launch_ds DoubanMusic_dg JOBID node02 0
launch_ds KuaiRec_dg     JOBID node02 4
launch_ds MicroLens_dg   JOBID node03 0
echo "=== all 20 route srun steps backgrounded; waiting ==="
wait
echo "=== ALL ROUTE JOBS EXITED $(date) ==="
