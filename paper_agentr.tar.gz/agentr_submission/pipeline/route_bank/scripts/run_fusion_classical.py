#!/usr/bin/env python3
"""Five multi-route fusion baselines (all rank-evidence based, CPU) for ONE dataset:
   RRF, CombMNZ, Val-Weighted, Logistic Fusion, LambdaMART.
Direct LLM Fusion is a separate script (needs the LLM). Protocol: fusion_common.py.

Fitting split = VALID (frozen 'valid' pop, GT = interaction label==1). Val-Weighted / Logistic /
LambdaMART are fit/selected on VALID only; TEST (label==2, frozen 'test' pop) is scored once.
There is no separate TRAIN ranking-label set (train items are the masked history), so VALID is the
sole labeled fitting split -- consistent with "no TEST-driven selection".

Outputs (artifacts/fusion/<ds>/):
  metrics_<ds>.json            aggregate TEST metrics for all 5 methods (+ valid for learned)
  weights_val_weighted.json    frozen non-negative simplex weights
  logistic.pkl / lambdamart.txt fitted models
  preds_<method>.pkl           per-user TEST top-50 lists
"""
from __future__ import annotations
import argparse, json, pickle, time
from itertools import combinations_with_replacement
from pathlib import Path
import numpy as np

import fusion_common as fc


def build_user_data(routes, users):
    """{uid: {cands, feats[n,16], S[n,5], RR[n,5], support[n]}} for users with >=1 candidate."""
    data = {}
    for u in users:
        rm = fc.user_rankmaps(routes, u)
        cands = fc.candidate_union(rm)
        if not cands:
            continue
        feats, S, RR, P, sup = fc.feature_matrix(rm, cands)
        data[u] = {"cands": cands, "feats": feats, "S": S, "RR": RR, "support": sup}
    return data


def gt_index(cands, tmap, u):
    gts = set(tmap.get(u, []))
    for i, c in enumerate(cands):
        if c in gts:
            return i
    return -1


# ---- simplex grid (step 1/den) ------------------------------------------------
def simplex_grid(dim=5, den=5):
    out = []
    for combo in combinations_with_replacement(range(dim), den):
        w = np.zeros(dim)
        for c in combo:
            w[c] += 1.0
        out.append(w / den)
    # dedupe
    uniq = {tuple(np.round(w, 6)) for w in out}
    return [np.array(w) for w in uniq]


def val_weighted_fit(valdata, valpop, tmap):
    """Pick simplex weights maximizing mean VALID NDCG@10 (single-GT fast rank)."""
    grid = simplex_grid(5, 5)
    # precompute per valid user: S matrix and gt idx (only users with gt in union count > 0)
    items = []
    for u in valpop:
        d = valdata.get(u)
        if d is None:
            items.append(None); continue
        gi = gt_index(d["cands"], tmap, u)
        items.append((d["S"], gi))
    N = len(valpop)
    best_w, best_s = grid[0], -1.0
    for w in grid:
        tot = 0.0
        for it in items:
            if it is None:
                continue
            S, gi = it
            if gi < 0:
                continue
            sc = S @ w
            rank = int((sc > sc[gi]).sum()) + 1
            if rank <= 10:
                tot += 1.0 / np.log2(rank + 1)
        s = tot / max(N, 1)
        if s > best_s:
            best_s, best_w = s, w
    return best_w, best_s


def stack_training(valdata, valpop, tmap, neg_cap=None):
    """Build LTR training arrays from VALID users that have GT in their candidate union.

    neg_cap=None -> train on the FULL per-user candidate union (no negative subsampling).
    This is required for the tree ranker (LambdaMART): if training only sees the RRF-top-`neg_cap`
    negatives, at TEST it scores the full union and the trees extrapolate arbitrarily on the unseen
    tail candidates, burying the GT (median GT rank collapses well below random). Both learned
    methods (Logistic + LambdaMART) share this identical full-union training slate, per spec.
    """
    X, y, groups = [], [], []
    for u in valpop:
        d = valdata.get(u)
        if d is None:
            continue
        gi = gt_index(d["cands"], tmap, u)
        if gi < 0:
            continue
        feats = d["feats"]
        n = feats.shape[0]
        if neg_cap is not None and n - 1 > neg_cap:
            rrf = d["RR"].sum(1)
            negs = [i for i in np.argsort(-rrf) if i != gi][:neg_cap]
            keep = [gi] + list(negs)
        else:
            keep = list(range(n))
        lab = np.zeros(len(keep)); lab[0 if keep[0] == gi else keep.index(gi)] = 1.0
        X.append(feats[keep]); y.append(lab); groups.append(len(keep))
    if not X:
        return None
    return np.vstack(X), np.concatenate(y), np.array(groups)


def rank_by_model(testdata, testpop, score_fn):
    out = {}
    for u in testpop:
        d = testdata.get(u)
        if d is None:
            out[u] = []
            continue
        sc = score_fn(d)
        out[u] = fc.topk_from_scores(d["cands"], sc)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    args = ap.parse_args()
    ds = args.ds
    t0 = time.time()

    routes = fc.load_routes(ds)
    blob = fc.rr.gw.load_frozen(ds)
    valpop = list(blob["frozen"]["valid"].keys())
    testpop = list(blob["frozen"]["test"].keys())
    tgt_v = fc.load_targets(ds, 1)
    tgt_t = fc.load_targets(ds, 2)
    print(f"[{ds}] valid_pop={len(valpop)} test_pop={len(testpop)} "
          f"gt_v={len(tgt_v)} gt_t={len(tgt_t)}", flush=True)

    valdata = build_user_data(routes, valpop)
    testdata = build_user_data(routes, testpop)
    print(f"[{ds}] built user data ({time.time()-t0:.0f}s); "
          f"valid_with_cand={len(valdata)} test_with_cand={len(testdata)}", flush=True)

    outd = fc.MRB / "artifacts" / "fusion" / ds
    outd.mkdir(parents=True, exist_ok=True)
    metrics = {"dataset": ds, "n_test_population": len(testpop),
               "n_valid_population": len(valpop), "methods": {}}

    def record(name, preds, valid_metrics=None, extra=None):
        m = fc.eval_pop(preds, testpop, tgt_t)
        metrics["methods"][name] = {**m, **({"valid": valid_metrics} if valid_metrics else {}),
                                    **(extra or {})}
        pickle.dump(preds, open(outd / f"preds_{name}.pkl", "wb"))
        print(f"[{ds}] {name:16s} N@10={m['NDCG@10']:.4f} R@10={m['Recall@10']:.4f} "
              f"N@50={m['NDCG@50']:.4f} R@50={m['Recall@50']:.4f}", flush=True)

    # 1) RRF ---------------------------------------------------------------
    record("RRF", rank_by_model(testdata, testpop, lambda d: d["RR"].sum(1)))

    # 2) CombMNZ -----------------------------------------------------------
    record("CombMNZ", rank_by_model(testdata, testpop, lambda d: d["S"].sum(1) * d["support"]))

    # 3) Val-Weighted (fit on VALID) --------------------------------------
    w, vs = val_weighted_fit(valdata, valpop, tgt_v)
    json.dump({"routes": fc.ROUTES, "weights": [float(x) for x in w],
               "valid_ndcg@10": float(vs)}, open(outd / "weights_val_weighted.json", "w"), indent=2)
    record("Val-Weighted", rank_by_model(testdata, testpop, lambda d: d["S"] @ w),
           extra={"weights": {r: float(x) for r, x in zip(fc.ROUTES, w)}})

    # 4) Logistic Fusion (fit on VALID) -----------------------------------
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    tr = stack_training(valdata, valpop, tgt_v)
    if tr is not None:
        Xtr, ytr, _ = tr
        sc = StandardScaler().fit(Xtr)
        lr = LogisticRegression(max_iter=1000, C=1.0, class_weight="balanced")
        lr.fit(sc.transform(Xtr), ytr)
        pickle.dump({"scaler": sc, "lr": lr, "features": "5*(normrank,recip,presence)+support"},
                    open(outd / "logistic.pkl", "wb"))
        record("Logistic", rank_by_model(testdata, testpop,
                                          lambda d: lr.predict_proba(sc.transform(d["feats"]))[:, 1]))
    else:
        metrics["methods"]["Logistic"] = {"error": "no positive valid examples"}
        print(f"[{ds}] Logistic SKIP (no valid positives)", flush=True)

    # 5) LambdaMART (fit on VALID) ----------------------------------------
    import lightgbm as lgb
    if tr is not None:
        Xtr, ytr, gtr = tr
        ranker = lgb.LGBMRanker(objective="lambdarank", n_estimators=300, learning_rate=0.05,
                                num_leaves=31, min_child_samples=20, subsample=0.9,
                                colsample_bytree=0.9, random_state=42, n_jobs=8,
                                label_gain=[0, 1])
        ranker.fit(Xtr, ytr.astype(int), group=gtr, eval_at=[10])
        ranker.booster_.save_model(str(outd / "lambdamart.txt"))
        record("LambdaMART", rank_by_model(testdata, testpop,
                                           lambda d: ranker.predict(d["feats"])))
    else:
        metrics["methods"]["LambdaMART"] = {"error": "no positive valid examples"}
        print(f"[{ds}] LambdaMART SKIP (no valid positives)", flush=True)

    json.dump(metrics, open(outd / f"metrics_{ds}.json", "w"), indent=2)
    print(f"[{ds}] DONE ({time.time()-t0:.0f}s) -> {outd/f'metrics_{ds}.json'}", flush=True)


if __name__ == "__main__":
    main()
