#!/usr/bin/env python3
"""exp16 -- standalone route evaluation + complementarity analysis for the modern route bank.

Operates on a combined route cache (default the modern one: precomputed_tool_cache_modern.pkl) whose
schema is {route: {uid(str): [item_id str]}}, plus the leave-one-out targets from interaction.csv
(label 1=valid/DEV, 2=test). All metrics use the SAME definition as the repo (single target/user:
Recall@k in {0,1}; NDCG@k = 1/log2(rank+2) if hit).

Outputs (artifacts/):
  routes_standalone_<ds>_<split>.json : per-route N@10/R@10/N@20/R@20/N@50/R@50
  complementarity_<ds>_<split>.json   : pairwise Jaccard@50/@100; per-aux unique base-miss coverage
                                        U_m; oracle union Recall@50/@100 (GT in union of route top-k)
Base route defaults to "graph" (matches pipeline). No TEST selection is done here; TEST split is only
measured, never used to choose anything.

Usage: python eval_routes.py --ds Software_10_80_r811 --split valid [--cache precomputed_tool_cache_modern.pkl]
"""
from __future__ import annotations
import argparse, csv, json, math, itertools
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
ART = Path(__file__).resolve().parents[1] / "artifacts"
SPLIT_LABEL = {"valid": "1", "test": "2"}


def load_targets(ds, split):
    lab = SPLIT_LABEL[split]
    tgt = {}
    with open(REPO / "data" / ds / "interaction.csv") as f:
        for row in csv.DictReader(f):
            if str(row["label"]) == lab:
                tgt[str(row["userid"])] = str(row["itemid"])
    return tgt


def route_metrics(route, tgt, ks=(10, 20, 50)):
    out = {}
    users = list(tgt)
    for k in ks:
        rec = ndcg = 0.0
        for u, g in tgt.items():
            lst = route.get(u, [])[:k]
            if g in lst:
                rec += 1.0
                ndcg += 1.0 / math.log2(lst.index(g) + 2)
        out[f"Recall@{k}"] = rec / len(users)
        out[f"NDCG@{k}"] = ndcg / len(users)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--split", default="valid", choices=["valid", "test"])
    ap.add_argument("--cache", default="precomputed_tool_cache_modern.pkl")
    ap.add_argument("--base_route", default="graph")
    args = ap.parse_args()

    import pickle
    cache = pickle.load(open(REPO / f"outputs/results/{args.ds}/{args.cache}", "rb"))
    tgt = load_targets(args.ds, args.split)
    routes = list(cache.keys())
    users = list(tgt)

    # ---- standalone
    standalone = {r: route_metrics(cache[r], tgt) for r in routes}
    ART.mkdir(parents=True, exist_ok=True)
    json.dump(standalone, open(ART / f"routes_standalone_{args.ds}_{args.split}.json", "w"), indent=2)
    print(f"=== {args.ds} [{args.split}] standalone routes (cache={args.cache}) ===")
    for r in routes:
        m = standalone[r]
        print(f"  {r:11s} N@10={m['NDCG@10']:.4f} R@10={m['Recall@10']:.4f} "
              f"N@50={m['NDCG@50']:.4f} R@50={m['Recall@50']:.4f}")

    # ---- complementarity
    def topset(r, u, k):
        return set(cache[r].get(u, [])[:k])

    jac = {}
    for a, b in itertools.combinations(routes, 2):
        for k in (50, 100):
            js = []
            for u in users:
                sa, sb = topset(a, u, k), topset(b, u, k)
                if sa or sb:
                    js.append(len(sa & sb) / len(sa | sb))
            jac[f"{a}|{b}@{k}"] = sum(js) / max(len(js), 1)

    base = args.base_route
    base_hit50 = {u: (tgt[u] in cache[base].get(u, [])[:50]) for u in users}
    unique_cov = {}   # for each non-base route: fraction of users where base MISSES gt@50 but route HITS gt@50
    base_miss_users = [u for u in users if not base_hit50[u]]
    for r in routes:
        if r == base:
            continue
        hit = sum((tgt[u] in cache[r].get(u, [])[:50]) for u in base_miss_users)
        unique_cov[r] = {"n_base_miss": len(base_miss_users),
                         "route_rescues": hit,
                         "coverage_of_base_miss": hit / max(len(base_miss_users), 1)}

    for k in (50, 100):
        union_hit = 0
        for u in users:
            uni = set().union(*[topset(r, u, k) for r in routes])
            if tgt[u] in uni:
                union_hit += 1
        unique_cov[f"oracle_union_Recall@{k}"] = union_hit / len(users)

    comp = {"pairwise_jaccard": jac, "base_route": base,
            "base_Recall@50": standalone[base]["Recall@50"],
            "unique_base_miss_coverage": unique_cov}
    json.dump(comp, open(ART / f"complementarity_{args.ds}_{args.split}.json", "w"), indent=2)
    print(f"--- complementarity (base={base}) ---")
    print(f"  oracle union R@50={unique_cov['oracle_union_Recall@50']:.4f} "
          f"R@100={unique_cov['oracle_union_Recall@100']:.4f}")
    for r in routes:
        if r == base:
            continue
        c = unique_cov[r]
        print(f"  {r:11s} rescues {c['route_rescues']}/{c['n_base_miss']} base-misses "
              f"({c['coverage_of_base_miss']:.3f})")
    print(f"[write] artifacts/routes_standalone_{args.ds}_{args.split}.json + "
          f"complementarity_{args.ds}_{args.split}.json")


if __name__ == "__main__":
    main()
