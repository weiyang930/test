#!/usr/bin/env python3
"""exp16 -- SAME-INFORMATION fusion baselines over the modern route bank.

These fuse EXACTLY the routes Agent-R consumes (graph, collab, semantic, mem, popularity from the
combined cache) so "Full Agent-R vs strongest fusion" is an apples-to-apples, same-information test.
Implements the fusers that did NOT already exist in baselines/multiroute_fusion.py:
  * rrf                 : reciprocal-rank fusion, score = sum_r 1/(k0 + rank_r)            (k0=60)
  * val_weighted_linear : sum_r w_r * (1/(rank_r+1)), w_r = route's FIT-split VALID Recall@50
  * learned_logreg      : LogisticRegression on per-candidate features [1/(rank_r+1) per route,
                          presence flags], trained on FIT users' VALID target, applied elsewhere
  * zscore_avg          : mean over routes of per-user z-scored reciprocal-rank (rank-based, so it
                          is well-defined for every route incl. the score-less mem/popularity)
(RRF etc. are rank-based -> identical "information" to the ranked lists; no raw model scores needed.)

Protocol (no leakage, matches exp15 discipline): users split FIT(80%)/EVAL(20%) by uid hash. All
learned params (logreg, val weights) are fit on FIT users' VALID targets. DEV numbers are reported on
EVAL users' VALID targets; TEST numbers on EVAL users' TEST targets. Paired bootstrap (pcr_common,
seed 42, 10k) vs the base route. Pass --eval_users_pkl to instead evaluate on an EXTERNAL user set +
target map (used to align with the residual ranker's ranker_dev/test users for the Agent-R comparison).

Usage: python modern_fusion.py --ds Software_10_80_r811 --split valid \
         [--cache precomputed_tool_cache_modern.pkl] [--base graph]
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, pickle, sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[3]
ART = Path(__file__).resolve().parents[1] / "artifacts"
sys.path.insert(0, str(REPO / "pipeline" / "planning" / "scripts"))
from pcr_common import paired_bootstrap  # noqa: E402

FUSE_ROUTES = ["graph", "collab", "semantic", "mem", "popularity"]
SPLIT_LABEL = {"valid": "1", "test": "2"}
DEPTH = 100
FINAL_K = 50


def load_targets(ds, label):
    csv.field_size_limit(sys.maxsize)
    tgt = {}
    with open(REPO / "data" / ds / "interaction.csv") as f:
        for row in csv.DictReader(f):
            if str(row["label"]) == label:
                tgt[str(row["userid"])] = str(row["itemid"])
    return tgt


def uid_in_fit(uid, frac=0.8, seed="exp16fuse"):
    h = int(hashlib.md5(f"{seed}:{uid}".encode()).hexdigest(), 16) % 1000
    return h < int(frac * 1000)


def rr_vectors(cache, routes, uid):
    """{item: {route: reciprocal_rank}} over the top-DEPTH of each route for one user."""
    d = {}
    for r in routes:
        for rank, it in enumerate(cache[r].get(uid, [])[:DEPTH]):
            d.setdefault(it, {})[r] = 1.0 / (rank + 1.0)
    return d


def metrics_user(order, gt, ks=(10, 20, 50)):
    m = {}
    for k in ks:
        hit = gt in order[:k]
        m[f"Recall@{k}"] = 1.0 if hit else 0.0
        m[f"NDCG@{k}"] = (1.0 / math.log2(order.index(gt) + 2)) if hit else 0.0
    return m


def fuse_rrf(rrmap, k0=60):
    # rank_r from reciprocal rank: 1/(rank+1) -> rank = 1/rr - 1
    sc = {it: sum(1.0 / (k0 + (1.0 / v - 1.0)) for v in d.values()) for it, d in rrmap.items()}
    return [i for i, _ in sorted(sc.items(), key=lambda kv: -kv[1])]


def fuse_weighted(rrmap, w):
    sc = {it: sum(w[r] * v for r, v in d.items()) for it, d in rrmap.items()}
    return [i for i, _ in sorted(sc.items(), key=lambda kv: -kv[1])]


def fuse_zscore(rrmap, routes, stats):
    sc = {}
    for it, d in rrmap.items():
        s = 0.0
        for r in routes:
            v = d.get(r, 0.0)
            mu, sd = stats[r]
            s += (v - mu) / sd if sd > 0 else 0.0
        sc[it] = s
    return [i for i, _ in sorted(sc.items(), key=lambda kv: -kv[1])]


def feat(rrmap_item, routes):
    return [rrmap_item.get(r, 0.0) for r in routes] + [1.0 if r in rrmap_item else 0.0 for r in routes]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--split", default="valid", choices=["valid", "test"])
    ap.add_argument("--cache", default="precomputed_tool_cache_modern.pkl")
    ap.add_argument("--base", default="graph")
    ap.add_argument("--routes", nargs="+", default=FUSE_ROUTES)
    ap.add_argument("--eval_users_pkl", default=None)   # optional external {uid:gt} for aligned cmp
    args = ap.parse_args()

    cache = pickle.load(open(REPO / f"outputs/results/{args.ds}/{args.cache}", "rb"))
    routes = [r for r in args.routes if r in cache]
    valid_tgt = load_targets(args.ds, "1")
    eval_tgt = load_targets(args.ds, SPLIT_LABEL[args.split])

    fit_users = [u for u in valid_tgt if uid_in_fit(u)]
    if args.eval_users_pkl:
        ext = pickle.load(open(args.eval_users_pkl, "rb"))
        eval_users = list(ext.keys()); eval_tgt = {u: ext[u] for u in eval_users}
    else:
        eval_users = [u for u in eval_tgt if not uid_in_fit(u)]

    # ---- fit params on FIT users' VALID targets
    # val-weighted: route weight = FIT VALID Recall@50
    w = {}
    for r in routes:
        hit = sum(valid_tgt[u] in cache[r].get(u, [])[:FINAL_K] for u in fit_users)
        w[r] = hit / max(len(fit_users), 1)
    # zscore stats: per-route mean/std of reciprocal-rank over FIT candidates
    zst = {}
    for r in routes:
        vals = []
        for u in fit_users:
            vals.extend(1.0 / (rk + 1.0) for rk in range(min(DEPTH, len(cache[r].get(u, [])))))
        a = np.asarray(vals) if vals else np.zeros(1)
        zst[r] = (float(a.mean()), float(a.std()))
    # learned logreg: features over FIT candidates, label = is valid GT
    from sklearn.linear_model import LogisticRegression
    X, y = [], []
    for u in fit_users:
        rrmap = rr_vectors(cache, routes, u)
        g = valid_tgt[u]
        for it, d in rrmap.items():
            X.append(feat(d, routes)); y.append(1 if it == g else 0)
    lr = LogisticRegression(max_iter=1000, class_weight="balanced")
    if len(set(y)) > 1:
        lr.fit(np.asarray(X), np.asarray(y))

    def fuse_learned(rrmap):
        its = list(rrmap.keys())
        if not its:
            return []
        F = np.asarray([feat(rrmap[it], routes) for it in its])
        s = F @ lr.coef_[0] + lr.intercept_[0]
        return [its[i] for i in np.argsort(-s)]

    methods = ["base", "rrf", "val_weighted_linear", "zscore_avg", "learned_logreg"]
    per_user = {m: {} for m in methods}
    for u in eval_users:
        g = eval_tgt[u]
        rrmap = rr_vectors(cache, routes, u)
        orders = {
            "base": cache[args.base].get(u, []),
            "rrf": fuse_rrf(rrmap),
            "val_weighted_linear": fuse_weighted(rrmap, w),
            "zscore_avg": fuse_zscore(rrmap, routes, zst),
            "learned_logreg": fuse_learned(rrmap),
        }
        for m in methods:
            per_user[m][u] = metrics_user(orders[m], g)

    METR = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
    agg = {m: {k: float(np.mean([per_user[m][u][k] for u in eval_users])) for k in METR} for m in methods}
    # bootstrap each fuser vs base
    boot = {}
    for m in methods:
        if m == "base":
            continue
        boot[m] = {}
        for k in METR:
            d = [per_user[m][u][k] - per_user["base"][u][k] for u in eval_users]
            mean, lo, hi = paired_bootstrap(d)
            boot[m][k] = {"delta": mean, "lo": lo, "hi": hi, "sig": (lo > 0 or hi < 0)}

    out = {"ds": args.ds, "split": args.split, "n_eval_users": len(eval_users),
           "routes": routes, "val_weights": w, "agg": agg, "vs_base_bootstrap": boot,
           "base_route": args.base}
    ART.mkdir(parents=True, exist_ok=True)
    tag = "aligned" if args.eval_users_pkl else "self8020"
    json.dump(out, open(ART / f"fusion_{args.ds}_{args.split}_{tag}.json", "w"), indent=2)
    print(f"=== fusion {args.ds} [{args.split}] n_eval={len(eval_users)} routes={routes} ===")
    print(f"  route val-weights: " + ", ".join(f"{r}={w[r]:.3f}" for r in routes))
    for m in methods:
        a = agg[m]
        b = f" (vs base N@10 {boot[m]['NDCG@10']['delta']:+.4f} sig={boot[m]['NDCG@10']['sig']})" if m != "base" else ""
        print(f"  {m:20s} N@10={a['NDCG@10']:.4f} R@10={a['Recall@10']:.4f} "
              f"N@50={a['NDCG@50']:.4f} R@50={a['Recall@50']:.4f}{b}")
    best = max((m for m in methods if m != "base"), key=lambda m: agg[m]["NDCG@10"])
    print(f"  STRONGEST FUSION (DEV N@10): {best} = {agg[best]['NDCG@10']:.4f}")
    print(f"[write] artifacts/fusion_{args.ds}_{args.split}_{tag}.json")


if __name__ == "__main__":
    main()
