#!/usr/bin/env python3
"""exp14 -- evaluation helpers shared by the CPU plumbing self-test and the GPU inference runner.

Baselines (spec 20): no_ranking (frozen exp10 order) and proposal_only (exp13 SHIPPED calibrated
statistical promotion, reused verbatim from proposal_pi_<ds>_valid.pkl). Metrics via exp12
all_metrics. Diagnostics per spec 11 (GT rank before/after, moved into top5/10, users
improved/damaged/unchanged) and spec 27 (base-target vs rescued-target gain split). Paired bootstrap
per spec 22 (10k, seed42). Recall@50 invariance is asserted for every method.
"""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import gw_common as gw  # noqa: E402
from gw_common import all_metrics, paired_bootstrap, execute_proposals  # noqa: E402

EXP13_ART = HERE.parent.parent / "substrate_common" / "artifacts"
PRIMARY = ["NDCG@10", "Recall@10", "NDCG@5", "Recall@5", "NDCG@50", "Recall@50", "MRR"]


def load_proposal_only_finals(ds, uids, frozen_v):
    """proposal_only final order per user, from exp13's frozen VALID per-user proposals."""
    prop = pickle.load(open(EXP13_ART / f"proposal_pi_{ds}_valid.pkl", "rb"))
    out = {}
    for u in uids:
        pr = prop.get(u)
        out[u] = execute_proposals(frozen_v[u], pr) if pr else list(frozen_v[u]["exp10_order"])
    return out


def no_ranking_finals(uids, frozen_v):
    return {u: list(frozen_v[u]["exp10_order"]) for u in uids}


def per_user_metrics(uids, finals, gt_map):
    return {u: all_metrics(finals[u], [gt_map[u]]) for u in uids}


def agg(pum, uids, keys=PRIMARY):
    return {k: float(np.mean([pum[u][k] for u in uids])) for k in keys}


def assert_r50_invariant(uids, finals, frozen_v):
    bad = 0
    for u in uids:
        if set(finals[u]) != set(frozen_v[u]["exp10_order"]):
            bad += 1
    return bad


def gt_rank(final, gt):
    try:
        return final.index(gt) + 1
    except ValueError:
        return len(final) + 1


def diagnostics(uids, finals, base_finals, gt_map):
    """spec 11: GT-rank movement, into-top-k, user win/loss vs a base method."""
    d_ranks, into5, into10, out5, out10 = [], 0, 0, 0, 0
    imp = dam = same = 0
    for u in uids:
        gt = gt_map[u]
        rb = gt_rank(base_finals[u], gt)
        rn = gt_rank(finals[u], gt)
        d_ranks.append(rb - rn)                       # >0 = GT moved up
        if rb > 5 and rn <= 5: into5 += 1
        if rb <= 5 and rn > 5: out5 += 1
        if rb > 10 and rn <= 10: into10 += 1
        if rb <= 10 and rn > 10: out10 += 1
    return {
        "gt_rank_mean_before": float(np.mean([gt_rank(base_finals[u], gt_map[u]) for u in uids])),
        "gt_rank_mean_after": float(np.mean([gt_rank(finals[u], gt_map[u]) for u in uids])),
        "gt_rank_improve_mean": float(np.mean(d_ranks)),
        "gt_rank_improve_median": float(np.median(d_ranks)),
        "moved_into_top5": into5, "moved_out_top5": out5,
        "moved_into_top10": into10, "moved_out_top10": out10,
    }


def user_winloss(uids, pum_a, pum_b, metric="NDCG@10"):
    imp = dam = same = 0
    for u in uids:
        d = pum_a[u][metric] - pum_b[u][metric]
        if d > 1e-12: imp += 1
        elif d < -1e-12: dam += 1
        else: same += 1
    return {"users_improved": imp, "users_damaged": dam, "users_unchanged": same,
            "net_users": imp - dam}


def bootstrap_cmp(uids, pum_a, pum_b, metrics=("NDCG@10", "Recall@10", "NDCG@50"),
                  n=10000, seed=42):
    """paired bootstrap of delta = A-B; sig = 95% CI excludes 0 (spec 22)."""
    out = {}
    for m in metrics:
        d = np.array([pum_a[u][m] - pum_b[u][m] for u in uids], dtype=np.float64)
        mean, lo, hi = paired_bootstrap(d, seed=seed, n_boot=n)
        out[m] = {"delta": mean, "ci_lo": lo, "ci_hi": hi, "sig": bool(lo > 0 or hi < 0)}
    return out
