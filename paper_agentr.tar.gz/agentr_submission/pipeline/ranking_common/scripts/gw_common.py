#!/usr/bin/env python3
"""exp14 -- Learned Groupwise LLM Ranking for Agent-R: shared lib (CPU, model-agnostic).

PURELY INCREMENTAL. Reads ONLY exp12's frozen_<ds>.pkl (backbone / rescued / resc_info with
calibrated intervention_score + route evidence / exp10_order / keep_slot) and exp13's frozen
proposal artifacts. Nothing in src/, scripts/, configs/, caches, splits, exp10-13 is modified.

Data path (spec 3.3 FAST FALLBACK, forced by the transductive retrievers -- clean train-prefix is
NOT feasible without retraining LightGCN/collab/mem): use the materialized VALID frozen set, keep
only RANKABLE users (held-out target in the frozen final-50), split 80/20 by uid hash into
ranker_train / ranker_dev. NO TEST labels ever touched here. diagnostic_extra_supervision=true.

Groupwise, not pairwise (spec 4). Label-selection objective (spec 5.3): candidates are shown as
[A]..[O]; the model selects/ranks LABELS; we map labels back to ids (avoids id-token noise).
Position debiasing (spec 6) is MANDATORY: candidate->label assignment is permuted (seeded), and we
log the positive-position histogram. Hierarchical groupwise inference (spec 17-19): Round1 = 5
groups x 10 (INTERLEAVED assignment), each -> top-3 => 50->15; Round2 = 15 -> top-10; fill 11..50
with exp10 order => Recall@50 invariant by construction.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
EXP13 = HERE.parent.parent / "substrate_common" / "scripts"
if str(EXP13) not in sys.path:
    sys.path.insert(0, str(EXP13))

# reuse exp13 (which reuses exp12/exp10) verbatim -- frozen substrate + metrics + proposal model
from pv_common import (  # noqa: E402
    load_frozen, target_maps, no_ranking_final,
    ProposalModel, execute_proposals,
    all_metrics, paired_bootstrap,
    DS_SHORT,
)

LABELS = list("ABCDEFGHIJKLMNO")   # up to 15 candidates (Round2 group = 15)
FINAL_K = 50


# --------------------------------------------------------------------- split / population
def uid_bucket(uid, seed_tag="exp14gw"):
    """Deterministic 0..99 bucket for a user id (stable across runs / machines)."""
    h = hashlib.md5(f"{seed_tag}:{uid}".encode()).hexdigest()
    return int(h, 16) % 100


def uid_split(uid, train_frac=0.8, seed_tag="exp14gw"):
    return "train" if uid_bucket(uid, seed_tag) < int(round(train_frac * 100)) else "dev"


def rankable_users(frozen_split, tgt_map, final_k=FINAL_K):
    """Users whose held-out target sits inside the frozen final-50 (isolate ranking from recall)."""
    out = []
    for uid, fr in frozen_split.items():
        ts = set(tgt_map.get(uid, []))
        if ts & set(fr["exp10_order"][:final_k]):
            out.append(uid)
    return out


def gt_in_pool(fr, tgt_map, final_k=FINAL_K):
    """Return the (single) held-out target id that is inside the final-50, else None."""
    ts = set(tgt_map.get(fr["userid"], []))
    for iid in fr["exp10_order"][:final_k]:
        if iid in ts:
            return iid
    return None


# --------------------------------------------------------------------- item / user text
def _clean_set_str(s, k=5):
    """user_meta stores python-set reprs like "{'a', 'b'}"; render a short readable list."""
    if not isinstance(s, str):
        return ""
    toks = re.findall(r"'([^']*)'", s)
    toks = [t for t in toks if t]
    return ", ".join(toks[:k])


def item_line(iid, titles, resc_map=None, max_desc=90):
    t = titles.get(iid, {}) or {}
    title = (t.get("title") or f"item {iid}").strip()
    desc = (t.get("desc") or "").replace("\n", " ").strip()
    if len(desc) > max_desc:
        desc = desc[:max_desc].rstrip() + "..."
    brand = ""
    if resc_map and iid in resc_map:
        b = resc_map[iid].get("brand")
        if b:
            brand = f" (brand: {b})"
    return f"{title}{brand}" + (f" -- {desc}" if desc else "")


def user_profile_text(user_meta_u):
    if not user_meta_u:
        return "No profile available."
    tb = _clean_set_str(user_meta_u.get("top_brands", ""))
    tc = _clean_set_str(user_meta_u.get("top_categories", ""))
    hl = user_meta_u.get("history_len", "?")
    parts = [f"history length: {hl}"]
    if tc:
        parts.append(f"preferred categories: {tc}")
    if tb:
        parts.append(f"preferred brands: {tb}")
    return "; ".join(parts)


# --------------------------------------------------------------------- prompt / parse
SYS_PROMPT = (
    "You are a recommendation ranking expert. Given a user's interaction profile and a small set "
    "of labeled candidate items, rank the candidates from most to least likely to be the user's "
    "next interaction. Reply with ONLY a JSON object of the form "
    '{\"ranking\": [\"<label>\", ...]} listing candidate labels best-first. Output nothing else.'
)


def build_user_prompt(user_meta_u, members, lab2id, titles, resc_map, top_q):
    lines = []
    for lab in LABELS[:len(members)]:
        iid = lab2id[lab]
        lines.append(f"[{lab}] {item_line(iid, titles, resc_map)}")
    cand_block = "\n".join(lines)
    return (
        f"User profile: {user_profile_text(user_meta_u)}\n\n"
        f"Candidate items:\n{cand_block}\n\n"
        f"Rank the candidates best-first and return the top {top_q} as "
        f'{{\"ranking\": [labels]}}.'
    )


def full_user_text(user_meta_u, members, lab2id, titles, resc_map, top_q):
    """Single-turn prompt string: instruction folded into the user turn (verl single-turn SFT wraps
    the prompt column as a user-only message -- so we use the SAME user-only format at inference to
    keep training and serving identical)."""
    return SYS_PROMPT + "\n\n" + build_user_prompt(user_meta_u, members, lab2id,
                                                   titles, resc_map, top_q)


def build_chat(user_meta_u, members, lab2id, titles, resc_map, top_q):
    return [{"role": "user",
             "content": full_user_text(user_meta_u, members, lab2id, titles, resc_map, top_q)}]


_LABEL_RE = re.compile(r"[A-O]")


def parse_ranking(text, valid_labels):
    """Parse model output -> ordered list of unique valid labels. Robust to minor format drift."""
    valid = set(valid_labels)
    order = []
    seen = set()

    def _add(lab):
        if lab in valid and lab not in seen:
            seen.add(lab)
            order.append(lab)

    # primary: JSON {"ranking": [...]}
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            obj = json.loads(m.group(0))
            arr = obj.get("ranking") if isinstance(obj, dict) else None
            if isinstance(arr, list):
                for x in arr:
                    _add(str(x).strip().strip("[]").upper()[:1])
        except Exception:
            pass
    # fallback: scan bracketed / bare labels in first-seen order
    if not order:
        for tok in re.findall(r"\[?([A-O])\]?", text.upper()):
            _add(tok)
    return order


# --------------------------------------------------------------------- group construction
def build_train_group(fr, gt_id, G, rng, n_hard, min_rescued, final_k=FINAL_K):
    """One groupwise TRAINING example: GT + (G-1) hard negatives (spec 7 mixture).

    n_hard nearest competitors around GT (biased to higher exp10 ranks = hardest), then fill the
    rest as a random spread over the final-50; ensure >= min_rescued rescued items when available.
    Returns (members, lab2id, gt_label, positive_position, composition).
    """
    order = fr["exp10_order"][:final_k]
    rescued = set(fr["rescued"])
    pos = {i: k for k, i in enumerate(order)}
    gt_pos = pos[gt_id]
    pool = [i for i in order if i != gt_id]

    # hardest competitors: closest in rank to GT, slight bias toward higher-ranked (harder)
    by_hard = sorted(pool, key=lambda i: (abs(pos[i] - gt_pos), pos[i]))
    hard = by_hard[:n_hard]
    chosen = list(hard)

    # ensure some rescued negatives (they carry the calibrated evidence channels)
    resc_pool = [i for i in pool if i in rescued and i not in chosen]
    rng.shuffle(resc_pool)
    while sum(int(i in rescued) for i in chosen) < min_rescued and resc_pool and len(chosen) < G - 1:
        chosen.append(resc_pool.pop())

    # random spread fill from the remaining pool
    remaining = [i for i in pool if i not in set(chosen)]
    rng.shuffle(remaining)
    while len(chosen) < G - 1 and remaining:
        chosen.append(remaining.pop())

    members = [gt_id] + chosen[:G - 1]
    rng.shuffle(members)
    lab2id = {LABELS[k]: iid for k, iid in enumerate(members)}
    id2lab = {v: k for k, v in lab2id.items()}
    gt_label = id2lab[gt_id]
    comp = {"n_base": sum(int(i not in rescued) for i in members),
            "n_rescued": sum(int(i in rescued) for i in members)}
    return members, lab2id, gt_label, LABELS.index(gt_label), comp


def sft_response(members, lab2id, gt_id, fr, top_q, final_k=FINAL_K):
    """Trustworthy groupwise supervision (spec 5): GT is rank 1; the remaining top_q-1 slots are
    filled by negatives in their EXP10 (base) relative order -- a real, non-fabricated prior, never
    an invented permutation among negatives."""
    order = fr["exp10_order"][:final_k]
    pos = {i: k for k, i in enumerate(order)}
    id2lab = {v: k for k, v in lab2id.items()}
    negs = [i for i in members if i != gt_id]
    negs.sort(key=lambda i: pos.get(i, 10 ** 9))
    ranked_ids = [gt_id] + negs
    ranked_labels = [id2lab[i] for i in ranked_ids[:top_q]]
    return json.dumps({"ranking": ranked_labels})


# --------------------------------------------------------------------- hierarchical inference
def interleaved_groups(order50, n_groups=5):
    """INTERLEAVED / balanced assignment (spec 18): group g = positions g, g+n, g+2n, ...
    (NOT 1-10 / 11-20). With 50 items and 5 groups each group has exactly 10 candidates."""
    groups = [[] for _ in range(n_groups)]
    for idx, iid in enumerate(order50):
        groups[idx % n_groups].append(iid)
    return groups


def make_group_task(members, order50, seed):
    """Deterministic seeded permutation of a group's candidate->label assignment (eval-time
    position debiasing, spec 6). Returns (members_permuted, lab2id)."""
    rng = np.random.RandomState(seed)
    mem = list(members)
    perm = rng.permutation(len(mem))
    mem = [mem[i] for i in perm]
    lab2id = {LABELS[k]: iid for k, iid in enumerate(mem)}
    return mem, lab2id


def assemble_final(order50, top_ids):
    """top_ids at positions 1..len; remaining final-50 items keep exp10 relative order after.
    Set identical to order50 => Recall@50 exactly invariant."""
    chosen = set(top_ids)
    rest = [i for i in order50 if i not in chosen]
    return list(top_ids) + rest


def hierarchical_rank(order50, rank_group, user_meta_u, titles, resc_map,
                      seed_base, round1_top=3, round2_out=10):
    """Full 50->15->10 groupwise re-rank for ONE user, given a `rank_group` callable.

    rank_group(members, lab2id, user_meta_u, titles, resc_map, top_q) -> ordered list of item ids
    (best first, already mapped from labels; caller guarantees a safe fallback on parse failure).

    Returns (final_order_50, debug).
    """
    order50 = list(order50[:FINAL_K])
    # ---- Round 1: 5 x 10 interleaved -> top-3 each => up to 15
    r1_groups = interleaved_groups(order50, n_groups=5)
    selected = []
    for gi, grp in enumerate(r1_groups):
        mem, lab2id = make_group_task(grp, order50, seed_base + 101 + gi)
        ranked = rank_group(mem, lab2id, user_meta_u, titles, resc_map, round1_top)
        selected.extend(ranked[:round1_top])
    # de-dup preserving order, keep exp10 order as a stable secondary
    seen = set(); pool15 = []
    for iid in selected:
        if iid not in seen:
            seen.add(iid); pool15.append(iid)
    # ---- Round 2: single group (<=15) -> top-10
    mem, lab2id = make_group_task(pool15, order50, seed_base + 777)
    ranked = rank_group(mem, lab2id, user_meta_u, titles, resc_map, round2_out)
    top = ranked[:round2_out]
    seen = set(top)
    for iid in pool15:          # backfill from round-1 survivors if model returned <round2_out
        if len(top) >= round2_out:
            break
        if iid not in seen:
            top.append(iid); seen.add(iid)
    final = assemble_final(order50, top)
    return final, {"n_selected15": len(pool15), "n_top": len(top)}
