#!/usr/bin/env python3
"""exp14 -- build groupwise ranking SFT data (Software gate) via the spec-3.3 VALID-80/20 fallback.

Population: frozen VALID set, RANKABLE users only (held-out target in the frozen final-50). Split
80/20 by uid hash -> ranker_train / ranker_dev. NO TEST labels touched. diagnostic_extra_supervision.
For each ranker_train user we emit N_PERM position-randomized groupwise examples (spec 6 debiasing);
each example = GT + (G-1) hard negatives (spec 7 mixture: nearest competitors + rescued + spread),
labeled [A].., response = {"ranking":[top_q labels]} with GT first and negatives in base order
(spec 5: no fabricated negative permutation). Logs positive_position_histogram + composition.

Run from repo ROOT with the recbole venv (has pyarrow). Writes:
  data/<ds>/train_G{G}.parquet         (verl SFT train)
  data/<ds>/dev_probe_G{G}.parquet     (one group / dev user; verl val-loss monitor only)
  data/<ds>/splits.json                (train/dev uid lists + GT id per user)
  data/<ds>/meta_G{G}.json             (population, histograms, composition, config)
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import gw_common as gw  # noqa: E402

ROOT = Path("/path/to/agentr")
DATA_DIR = HERE.parent / "data"


def load_valid_targets(ds):
    """valid held-out items (label==1), from interaction.csv directly (no recbole)."""
    df = pd.read_csv(ROOT / "data" / ds / "interaction.csv",
                     dtype={"userid": str, "itemid": str})
    v = df[df["label"] == 1]
    out = {}
    for u, g in v.groupby("userid"):
        out[u] = [str(x) for x in g["itemid"].tolist()]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="Software_10_80_r811")
    ap.add_argument("--G", type=int, default=10)
    ap.add_argument("--top_q", type=int, default=3)
    ap.add_argument("--n_hard", type=int, default=5)
    ap.add_argument("--min_rescued", type=int, default=1)
    ap.add_argument("--n_perm", type=int, default=2)
    ap.add_argument("--train_frac", type=float, default=0.8)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    outd = DATA_DIR / args.ds
    outd.mkdir(parents=True, exist_ok=True)

    blob = gw.load_frozen(args.ds)
    frozen_v = blob["frozen"]["valid"]
    titles = blob["titles"]
    user_meta = blob["user_meta"]
    vtgt = load_valid_targets(args.ds)

    rankable = gw.rankable_users(frozen_v, vtgt)
    n_all = len(frozen_v)
    print(f"[pop] valid users={n_all}  rankable={len(rankable)} "
          f"({len(rankable)/n_all:.4f})")

    # split + record GT + base/rescued-target tag (spec 27)
    splits = {"train": [], "dev": []}
    gt_map, tag_map = {}, {}
    base_t = resc_t = 0
    for uid in rankable:
        fr = frozen_v[uid]
        gt = gw.gt_in_pool(fr, vtgt)
        if gt is None:
            continue
        gt_map[uid] = gt
        is_resc = gt in set(fr["rescued"])
        tag_map[uid] = "rescued" if is_resc else "base"
        base_t += int(not is_resc); resc_t += int(is_resc)
        splits[gw.uid_split(uid, args.train_frac)].append(uid)
    print(f"[split] train={len(splits['train'])} dev={len(splits['dev'])} "
          f"| base-target={base_t} rescued-target={resc_t}")

    json.dump({"train": splits["train"], "dev": splits["dev"],
               "gt": gt_map, "tag": tag_map,
               "config": vars(args), "diagnostic_extra_supervision": True},
              open(outd / "splits.json", "w"))

    # ---- build train examples (N_PERM randomized groups per user) ----
    pos_hist = Counter()
    comp_base = comp_resc = 0
    rows = []
    for ui, uid in enumerate(splits["train"]):
        fr = frozen_v[uid]
        resc_map = {r["item_id"]: r for r in fr["resc_info"]}
        gt = gt_map[uid]
        um = user_meta.get(uid, {})
        for p in range(args.n_perm):
            rng = np.random.RandomState((args.seed * 1_000_003 + ui) * 17 + p)
            members, lab2id, gt_label, gt_pos, comp = gw.build_train_group(
                fr, gt, args.G, rng, args.n_hard, args.min_rescued)
            pos_hist[gt_pos] += 1
            comp_base += comp["n_base"]; comp_resc += comp["n_rescued"]
            prompt = gw.full_user_text(um, members, lab2id, titles, resc_map, args.top_q)
            resp = gw.sft_response(members, lab2id, gt, fr, args.top_q)
            rows.append({"prompt": prompt, "response": resp})
    train_df = pd.DataFrame(rows)
    train_df.to_parquet(outd / f"train_G{args.G}.parquet", index=False)

    # ---- dev probe (one group per dev user; verl val-loss monitor only) ----
    dev_rows = []
    for ui, uid in enumerate(splits["dev"]):
        fr = frozen_v[uid]
        resc_map = {r["item_id"]: r for r in fr["resc_info"]}
        gt = gt_map[uid]
        um = user_meta.get(uid, {})
        rng = np.random.RandomState(args.seed * 7 + ui)
        members, lab2id, gt_label, gt_pos, comp = gw.build_train_group(
            fr, gt, args.G, rng, args.n_hard, args.min_rescued)
        prompt = gw.full_user_text(um, members, lab2id, titles, resc_map, args.top_q)
        resp = gw.sft_response(members, lab2id, gt, fr, args.top_q)
        dev_rows.append({"prompt": prompt, "response": resp})
    pd.DataFrame(dev_rows).to_parquet(outd / f"dev_probe_G{args.G}.parquet", index=False)

    n_ex = len(rows)
    total_slots = comp_base + comp_resc
    hist = {int(k): int(v) for k, v in sorted(pos_hist.items())}
    frac = {k: round(v / max(n_ex, 1), 4) for k, v in hist.items()}
    meta = {
        "dataset": args.ds, "config": vars(args),
        "population": {"valid_users": n_all, "rankable": len(rankable),
                       "rankable_frac": round(len(rankable) / n_all, 4),
                       "train_users": len(splits["train"]), "dev_users": len(splits["dev"]),
                       "base_target_users": base_t, "rescued_target_users": resc_t},
        "train_examples": n_ex,
        "positive_position_histogram": hist,
        "positive_position_frac": frac,
        "positive_position_frac_max_dev_from_uniform":
            round(max(abs(v - 1.0 / args.G) for v in frac.values()), 4) if frac else None,
        "group_composition": {"mean_base": round(comp_base / max(n_ex, 1), 3),
                              "mean_rescued": round(comp_resc / max(n_ex, 1), 3),
                              "rescued_slot_frac": round(comp_resc / max(total_slots, 1), 4)},
    }
    json.dump(meta, open(outd / f"meta_G{args.G}.json", "w"), indent=2)
    print(json.dumps(meta, indent=2))
    print(f"[write] {outd}/train_G{args.G}.parquet  rows={n_ex}")


if __name__ == "__main__":
    main()
