#!/usr/bin/env python3
"""exp13 -- Calibrated Promotion Proposal + LLM Contrastive Verification: shared lib (CPU).

PURELY INCREMENTAL on exp10 (calibrated evidence) and exp12 (frozen sets + executor).
Nothing in src/, scripts/, configs/, caches, splits, exp10, exp11, or exp12 is modified.
We only READ exp12's frozen_<ds>.pkl (backbone/rescued partition, exp10_order, per-item
calibrated intervention_score + evidence channels).

Pipeline (spec exp13):
    frozen exp10 final set
      -> calibrated STATISTICAL promotion proposal   P_stat(r) -> target rank + incumbent
      -> (Stage B) LLM CONTRASTIVE VERIFICATION       KEEP / ACCEPT per proposal
      -> minimal deterministic promotion              base-order & membership preserving
Recall@50 invariant by construction; target = head quality (NDCG@10 / Recall@10).

The proposal is a SIMPLE, VALIDATION-DERIVED, MONOTONIC map from the single already-validated
exp10 calibrated intervention score to a promotion depth (band). NO new multivariate ranker.
"""
from __future__ import annotations

import json
import pickle
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
EXP12 = HERE.parent.parent / "candidate_adaptation" / "scripts"
if str(EXP12) not in sys.path:
    sys.path.insert(0, str(EXP12))

# reuse exp12 (which reuses exp10) verbatim
from pr_common import (  # noqa: E402
    ROOT, DATASETS, FINAL_K, EVAL_KS,
    load_dataset, load_item_titles,
    all_metrics, recall_at_k, ndcg_at_k, mrr, paired_bootstrap,
)

EXP12_DIR = HERE.parent.parent / "candidate_adaptation"
DS_SHORT = {"Music_10_80_r811": "Music", "Game_10_80_r811": "Game",
            "Software_10_80_r811": "Software", "Industrial_10_80_r811": "Industrial"}


# --------------------------------------------------------------------- load frozen
def load_frozen(ds):
    """exp12 frozen_<ds>.pkl -> dict with frozen[split][uid]=fr, titles, user_meta, meta.

    Substrate is selected by env var AGENTR_FROZEN_SUFFIX. DEFAULT = "_planner"
    (planner_conditioned, the integrated pipeline default as of 2026-09-24 — see
    develop/2026-09-24_planner_conditioned_integration_check.md). To use the deterministic
    prior_only fallback/ablation instead, set AGENTR_FROZEN_SUFFIX="" (empty but present).
    """
    import os
    # default is planner; an explicitly-set empty string selects prior_only.
    suffix = os.environ.get("AGENTR_FROZEN_SUFFIX", "_planner")
    p = EXP12_DIR / "artifacts" / f"frozen_{ds}{suffix}.pkl"
    if not p.exists():
        hint = ""
        if suffix == "_planner":
            hint = (f"\nThe planner_conditioned substrate for '{ds}' has not been built yet. "
                    f"Build it with:\n  python pipeline/candidate_adaptation/scripts/"
                    f"stage1_build_planner.py --dataset {ds} --known-planner-r50 <exp10_R@50>\n"
                    f"or set AGENTR_FROZEN_SUFFIX=\"\" to fall back to the prior_only substrate.")
        raise FileNotFoundError(f"frozen substrate not found: {p}{hint}")
    return pickle.load(open(p, "rb"))


def target_maps(ds):
    """Validation & test target sets (offline label use only)."""
    D = load_dataset(ds)
    vmap = {u: [str(x) for x in v] for u, v in D["dataset"].user_valid_items.items()}
    tmap = {u: [str(x) for x in v] for u, v in D["dataset"].user_test_items.items()}
    return vmap, tmap


# --------------------------------------------------------------------- gap executor
def apply_gap_promotion(fr, gap_map):
    """Deterministic base-order-preserving insertion by explicit backbone gaps.

    gap_map: {item_id -> gap g in [0, keep_slot]} for rescued items; g == keep_slot means
    KEEP (leave at original exp10 slot). Only UPWARD moves are permitted (promotion_only):
    g < keep_slot promotes; g is clamped into [0, keep_slot]. Base-base order never changes;
    candidate membership never changes; Recall@50 stays exactly invariant.
    Within-gap ties broken by descending intervention_score then id (stable, deterministic).
    """
    backbone = fr["backbone"]; m = len(backbone)
    keep_slot = fr["keep_slot"]
    iscore = {r["item_id"]: r["intervention_score"] for r in fr["resc_info"]}
    gap_items = {g: [] for g in range(m + 1)}
    for iid in fr["rescued"]:
        g = int(gap_map.get(iid, keep_slot))
        if g > keep_slot:          # never move a rescued item DOWN past its home slot
            g = keep_slot
        g = min(max(g, 0), m)
        gap_items[g].append(iid)
    for g in gap_items:
        gap_items[g].sort(key=lambda i: (-iscore.get(i, 0.0), i))
    out = []
    for g in range(m + 1):
        out.extend(gap_items[g])
        if g < m:
            out.append(backbone[g])
    return out


def no_ranking_final(fr):
    return list(fr["exp10_order"])


# --------------------------------------------------------------------- proposal model
class ProposalModel:
    """VALIDATION-calibrated, monotonic, one-dimensional promotion proposal.

    Fits an isotonic map pi(s) = P(rescued item is a target | intervention score s) on the
    VALIDATION rescued pool, then discretizes pi into a small number of evidence bands with
    a fixed reference promotion gap per band. Boundaries (band cut quantiles) and per-band
    target gaps are chosen on VALIDATION only (grid search, see stage_a). NO test peeking.

    A "proposal" for a rescued item r is:
      - strength band in {high, upper, lower, keep}
      - reference_target_gap g in [0, keep_slot]   (keep => no promotion)
      - reference_incumbent  = backbone[g] (the base item currently at the boundary)
    """

    def __init__(self, iso, cut_thresholds, band_gaps, band_names):
        self.iso = iso                       # sklearn IsotonicRegression or None
        self.cut_thresholds = list(cut_thresholds)   # descending pi thresholds, len = #promote bands
        self.band_gaps = list(band_gaps)     # gap per promote band (same len, ascending gap)
        self.band_names = list(band_names)   # names per promote band

    # ---- fit ----
    @staticmethod
    def fit_isotonic(scores, y):
        from sklearn.isotonic import IsotonicRegression
        scores = np.asarray(scores, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)
        if len(scores) == 0 or scores.max() == scores.min():
            return None
        ir = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        ir.fit(scores, y)
        return ir

    def pi(self, scores):
        scores = np.asarray(scores, dtype=np.float64)
        if self.iso is None:
            return scores
        return self.iso.predict(scores)

    def band_of(self, pi_val):
        """Return (band_index or None-for-keep, gap). Highest band first."""
        for bi, thr in enumerate(self.cut_thresholds):
            if pi_val >= thr:
                return bi, self.band_gaps[bi]
        return None, None

    def propose_user(self, fr, keep_gap=None):
        """Return {item_id -> proposal dict} for a user's rescued items."""
        keep_slot = fr["keep_slot"]
        kg = keep_slot if keep_gap is None else keep_gap
        backbone = fr["backbone"]
        out = {}
        for r in fr["resc_info"]:
            iid = r["item_id"]
            pv = float(self.pi([r["intervention_score"]])[0])
            bi, gap = self.band_of(pv)
            if bi is None:
                out[iid] = {"pi": pv, "band": "keep", "target_gap": kg,
                            "reference_target_rank": kg + 1, "reference_incumbent": None,
                            "propose_promote": False}
            else:
                g = min(max(int(gap), 0), keep_slot)
                inc = backbone[g] if g < len(backbone) else None
                out[iid] = {"pi": pv, "band": self.band_names[bi], "target_gap": g,
                            "reference_target_rank": g + 1, "reference_incumbent": inc,
                            "propose_promote": True}
        return out

    def to_json(self):
        return {"cut_thresholds": self.cut_thresholds, "band_gaps": self.band_gaps,
                "band_names": self.band_names, "has_iso": self.iso is not None}


# --------------------------------------------------------------------- proposal exec
def execute_proposals(fr, proposals, decisions=None):
    """Turn proposals (+ optional per-item ACCEPT/KEEP decisions) into a final list.

    decisions: {item_id -> "ACCEPT"|"KEEP"} or None (=> proposal_only: execute every
    propose_promote proposal). KEEP / missing -> item stays at its home slot (keep_slot).
    """
    keep_slot = fr["keep_slot"]
    gap_map = {}
    for iid, pr in proposals.items():
        promote = pr["propose_promote"]
        if decisions is not None:
            promote = promote and (decisions.get(iid, "KEEP") == "ACCEPT")
        gap_map[iid] = pr["target_gap"] if promote else keep_slot
    return apply_gap_promotion(fr, gap_map)


# --------------------------------------------------------------------- diagnostics
def promotion_diag(order_users, frozen, tgt, base_finals, new_finals, resc_info_map):
    """Promotion diagnostics vs no_ranking baseline (spec 15)."""
    promoted = 0; n_rescued = 0; dist = []
    into5 = into10 = into20 = 0
    benef = harm = neutral = 0
    p5h = p5n = p10h = p10n = 0
    u_imp = u_dam = u_same = 0
    for u in order_users:
        fr = frozen[u]; ts = set(tgt[u])
        base_final = base_finals[u]; new_final = new_finals[u]
        newpos = {i: k for k, i in enumerate(new_final)}
        oldpos = {i: k for k, i in enumerate(base_final)}
        for r in resc_info_map[u]:
            iid = r["item_id"]; n_rescued += 1
            if newpos[iid] < oldpos[iid]:
                promoted += 1; dist.append(oldpos[iid] - newpos[iid])
                if newpos[iid] < 5: into5 += 1; p5n += 1; p5h += int(iid in ts)
                if newpos[iid] < 10: into10 += 1; p10n += 1; p10h += int(iid in ts)
                if newpos[iid] < 20: into20 += 1
                if iid in ts:
                    benef += 1
                elif any(t in ts for t in base_final[:newpos[iid] + 1]):
                    harm += 1
                else:
                    neutral += 1
    return {
        "n_rescued": n_rescued, "promoted": promoted,
        "promoted_frac": promoted / max(n_rescued, 1),
        "mean_promotion_distance": float(np.mean(dist)) if dist else 0.0,
        "median_promotion_distance": float(np.median(dist)) if dist else 0.0,
        "promoted_into_top5": into5, "promoted_into_top10": into10, "promoted_into_top20": into20,
        "beneficial": benef, "harmful": harm, "neutral": neutral,
        "promotion_precision@5": p5h / max(p5n, 1), "promotion_precision@10": p10h / max(p10n, 1),
    }


def user_delta_counts(order_users, peruser_a, peruser_b, metric="NDCG@10"):
    imp = dam = same = 0
    for u in order_users:
        d = peruser_a[u][metric] - peruser_b[u][metric]
        if d > 1e-12: imp += 1
        elif d < -1e-12: dam += 1
        else: same += 1
    return {"users_improved": imp, "users_damaged": dam, "users_unchanged": same,
            "net_users": imp - dam}


# --------------------------------------------------------------------- oracle
def oracle_full_insertion(fr, tgt_set):
    """Full-insertion oracle: promote every rescued TARGET to gap 0 (top), non-targets KEEP.
    Upper bound of what ANY promotion of the rescued set can achieve on head metrics."""
    keep_slot = fr["keep_slot"]
    gap_map = {r["item_id"]: (0 if r["item_id"] in tgt_set else keep_slot)
               for r in fr["resc_info"]}
    return apply_gap_promotion(fr, gap_map)


def oracle_proposal_conditioned(fr, proposals, tgt_set):
    """Proposal-conditioned verification oracle: among the FIXED deterministic proposals,
    an oracle verifier ACCEPTs iff the proposed item is a target (i.e. keeps only beneficial
    promotions), KEEPs everything else. Upper bound the verifier stage can add ON TOP of the
    frozen proposals -- isolates verifier headroom from proposal headroom (spec 16)."""
    decisions = {r["item_id"]: ("ACCEPT" if r["item_id"] in tgt_set else "KEEP")
                 for r in fr["resc_info"]}
    return execute_proposals(fr, proposals, decisions)


# --------------------------------------------------------------------- sanity
def base_order_ok(final, backbone):
    pos = {i: k for k, i in enumerate(final)}
    seq = [pos[i] for i in backbone if i in pos]
    return seq == sorted(seq)


def sanity_check(final, fr):
    """Return (base_order_violation, candidate_change, recall50_noninvariant vs exp10_order)."""
    v = 0 if base_order_ok(final, fr["backbone"]) else 1
    c = 0 if set(final) == set(fr["exp10_order"]) else 1
    return v, c
