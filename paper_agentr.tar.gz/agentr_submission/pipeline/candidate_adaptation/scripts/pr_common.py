#!/usr/bin/env python3
"""exp12 -- Base-Order-Preserving Promotion Ranker: shared library (offline, CPU).

PURELY INCREMENTAL on exp10 (planning). The exp10 shipped
`prior_only` candidate set is reused BYTE-IDENTICALLY as the frozen input; exp12 only
replaces the final Ranking Agent. Nothing in src/, scripts/, configs/, the caches, the
splits, exp10, or exp11 is modified.

exp10 final list (compose_final, scripts/eval_learned_rescue_controller.py:323):
    final = [graph_items[:keep]]                 # base items, BASE order      ("base")
          + [rescue_ranked[:budget] \ base_top]  # admitted complementary items ("rescued")
          + [graph_items[keep:] fillers to 50]   # base items, BASE order      ("base")

exp12 ranker:
  * base candidates keep their base relative order EXACTLY (never reordered);
  * the LLM decides, per rescued candidate, one anchor-relative PROMOTION action
    (BEFORE_A1 / BETWEEN_Ai_A{i+1} / AFTER_AM / KEEP);
  * a deterministic executor inserts promoted items at the chosen anchor boundary.
Recall@50 is invariant (same 50 items); the target is head quality (NDCG@10 / Recall@10).
"""
from __future__ import annotations

import json
import math
import os
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
EXP10 = HERE.parent.parent / "planning" / "scripts"
if str(EXP10) not in sys.path:
    sys.path.insert(0, str(EXP10))

# reuse exp10 executor + pool/evidence/calibration/metrics verbatim
from pcr_common import (  # noqa: E402
    ROOT, AUX_TOOLS, AUX_K, POOL_LIMIT, FINAL_K, K, DATASETS, REPRO_ANCHOR, CHANNELS,
    load_dataset, build_pool, evidence_matrix, fit_calibrators, apply_calibrators,
    paired_bootstrap, recall_at_k, ndcg_at_k, compose_final,
)

EXP10_DIR = HERE.parent.parent / "planning"
EVAL_KS = [5, 10, 20, 50]


# --------------------------------------------------------------------- item titles
def load_item_titles(dataset_dir: Path) -> dict:
    """itemid -> {'title':..., 'desc':...} (short), for concise LLM presentation."""
    p = Path(dataset_dir) / "item_profile_raw.csv"
    if not p.exists():
        return {}
    df = pd.read_csv(p, usecols=lambda c: c in ("itemid", "title", "description"))
    out = {}
    for row in df.to_dict(orient="records"):
        iid = str(row.get("itemid"))
        title = str(row.get("title", "") or "")[:80]
        desc = str(row.get("description", "") or "")[:160]
        out[iid] = {"title": title, "desc": desc}
    return out


# --------------------------------------------------------------------- prior (exp10)
def load_prior_weights(ds):
    """Validation-selected exp10 prior_only weight vector w_bar (== exp11 BALANCED).
    Honors AGENTR_TOOLCACHE_SUFFIX (mirrors load_dataset): "_modern" -> offline_<ds>_modern.json,
    the calibrators/prior fit on the MODERN route bank. Default "" = original prior_only offline."""
    _sfx = os.environ.get("AGENTR_TOOLCACHE_SUFFIX", "")
    off = json.load(open(EXP10_DIR / "artifacts" / f"offline_{ds}{_sfx}.json"))
    name = off["prior_only_selected"]
    key = "valstr" if "valstr" in name else "equal"
    return np.asarray(off["calibrated_prior_weights"][key], dtype=np.float64), name, off


# --------------------------------------------------------------------- base scores
def load_base_scores(ds):
    """Real base(graph/LightGCN) scores if a scored cache exists, else None.
    Returns {uid(str): {itemid(str): score(float)}}."""
    p = ROOT / f"outputs/results/{ds}/toolcache_graph.pkl"
    if not p.exists():
        return None
    blob = pickle.load(open(p, "rb"))
    users = blob.get("users", {})
    out = {}
    for uid, rec in users.items():
        items = rec.get("items", []); scores = rec.get("scores", [])
        out[str(uid)] = {str(i): float(s) for i, s in zip(items, scores)}
    return out


# --------------------------------------------------------------------- calibrators
def fit_hard_calibrators(cached, valid_users, vmap, item_meta, user_meta, keep0):
    """Identical to exp10: per-channel isotonic on the hard validation pool @ keep0."""
    E_list, y_list = [], []
    for u in valid_users:
        gi, pool, src, rk = build_pool(cached, u, keep0)
        tg = set(vmap.get(u, []))
        if not pool or not tg:
            continue
        E = evidence_matrix(pool, u, gi, src, rk, item_meta, user_meta)
        E_list.append(E)
        y_list.append(np.array([float(i in tg) for i in pool]))
    return fit_calibrators(E_list, y_list)


# --------------------------------------------------------------------- frozen build
def build_user_frozen(cached, uid, keep0, budget0, w_bar, cals, item_meta, user_meta):
    """Recompute the exp10 prior_only frozen candidate set for one user, with the
    base/rescued partition, per-item evidence, and exp10 ranks. Returns None if empty."""
    gi = cached.get("graph", {}).get(uid, [])
    _, pool, sources, ranks = build_pool(cached, uid, keep0)
    if pool:
        E = evidence_matrix(pool, uid, gi, sources, ranks, item_meta, user_meta)
        H = apply_calibrators(E, cals)
        scores = H @ w_bar
        ranked = [i for i, _ in sorted(zip(pool, scores), key=lambda p: (-float(p[1]), p[0]))]
        score_map = {i: float(s) for i, s in zip(pool, scores)}
    else:
        ranked, score_map = [], {}

    final = compose_final(gi, ranked, keep0, budget0, FINAL_K)

    # partition exactly as compose_final built it
    base_top = []
    seen = set()
    for iid in gi[:keep0]:
        if iid not in seen:
            base_top.append(iid); seen.add(iid)
    rescued = []
    for iid in ranked[:budget0]:
        if iid not in seen:
            rescued.append(iid); seen.add(iid)
        if len(base_top) + len(rescued) >= FINAL_K:
            break
    tail = []
    for iid in gi:
        if len(base_top) + len(rescued) + len(tail) >= FINAL_K:
            break
        if iid not in seen:
            tail.append(iid); seen.add(iid)
    backbone = base_top + tail                      # base items in base order
    # sanity: reconstruct exp10 order = base_top + rescued + tail
    exp10_order = base_top + rescued + tail
    exp10_rank = {iid: r for r, iid in enumerate(exp10_order)}

    # rescued evidence for presentation / tie-break
    um = user_meta.get(str(uid), {})
    resc_info = []
    for iid in rescued:
        rk = ranks.get(iid, {})
        srcs = sources.get(iid, [])
        im = item_meta.get(str(iid), {})
        cats = im.get("categories", set()); ucats = um.get("categories", set())
        resc_info.append({
            "item_id": iid,
            "intervention_score": score_map.get(iid, 0.0),
            "current_rank": exp10_rank[iid] + 1,           # 1-indexed
            "source_routes": list(srcs),
            "route_ranks": {m: int(rk[m]) + 1 for m in rk},   # 1-indexed
            "cross_path_support": len(srcs),
            "pref_jaccard": round(len(cats & ucats) / max(len(cats | ucats), 1), 3),
            "brand_match": bool(im.get("brand", "unknown") in um.get("brands", set())
                                and im.get("brand", "unknown") != "unknown"),
            "category": sorted(cats)[:3],
            "brand": im.get("brand", "unknown"),
        })
    return {
        "userid": uid,
        "backbone": backbone,           # base items, base order
        "rescued": rescued,             # admitted complementary items, exp10 rescued order
        "resc_info": resc_info,
        "exp10_order": exp10_order,     # frozen 50 (the exp10 prior_only ranking)
        "n_base": len(backbone), "n_rescued": len(rescued),
        "keep_slot": len(base_top),     # backbone gap where rescued originally sit
    }


# --------------------------------------------------------------------- anchors
def quantile_anchor_idx(m, M):
    """Uniform positional anchors: q_j = ceil(j(m+1)/(M+1)) (1-indexed base rank) -> 0-idx."""
    if m <= 0:
        return []
    idx = []
    for j in range(1, M + 1):
        q = math.ceil(j * (m + 1) / (M + 1)) - 1          # 0-indexed
        idx.append(min(m - 1, max(0, q)))
    return sorted(set(idx))


def gap_anchor_idx(scores, M):
    """Confidence-gap anchors: within-user min-max normalise base scores (already desc),
    anchor at the base item just above each of the M largest adjacent drops.
    Returns (idx_list, used_scores_bool). Falls back (None) if scores unavailable/degenerate."""
    if scores is None or len(scores) < 2 or any(s is None for s in scores):
        return None
    s = np.asarray(scores, dtype=np.float64)
    smin, smax = s.min(), s.max()
    if smax <= smin:
        return None
    sn = (s - smin) / (smax - smin)
    deltas = sn[:-1] - sn[1:]                              # Δ_i between item i and i+1
    if deltas.max() <= 0:
        return None
    order = np.argsort(-deltas)                            # largest gaps first
    chosen = sorted(set(int(i) for i in order[:M]))        # item index above each gap
    return chosen


def build_anchors(fr, anchor_mode, M, base_scores_user):
    """Return anchor descriptor: list of backbone indices (ascending) + mode actually used."""
    m = fr["n_base"]
    used = anchor_mode
    if anchor_mode == "confidence_gap":
        sc = None
        if base_scores_user is not None:
            sc = [base_scores_user.get(iid) for iid in fr["backbone"]]
        idx = gap_anchor_idx(sc, M)
        if idx is None:
            idx = quantile_anchor_idx(m, M); used = "quantile_fallback"
    else:
        idx = quantile_anchor_idx(m, M)
    return {"idx": idx, "used_mode": used}


# --------------------------------------------------------------------- action space
def action_labels(n_anchors):
    """Ordered placement actions for n_anchors anchors (A1..A{n})."""
    labs = ["BEFORE_A1"]
    for j in range(1, n_anchors):
        labs.append(f"BETWEEN_A{j}_A{j+1}")
    labs.append(f"AFTER_A{n_anchors}")
    labs.append("KEEP")
    return labs


def action_to_gap(action, anchor_idx, keep_slot):
    """Map a placement action to a backbone gap g in [0, m] where the rescued item is
    inserted (before backbone[g]); KEEP / unknown -> the item's original exp10 slot."""
    n = len(anchor_idx)
    if action == "BEFORE_A1":
        return anchor_idx[0]
    if action.startswith("BETWEEN_A"):
        try:
            j = int(action.split("_A")[1])                # A_j after this anchor
        except Exception:
            return keep_slot
        if 1 <= j <= n:
            return anchor_idx[j - 1] + 1
        return keep_slot
    if action == f"AFTER_A{n}" or action == "AFTER_AM":
        return anchor_idx[-1] + 1
    return keep_slot                                       # KEEP / parse-fail


# --------------------------------------------------------------------- executors
def apply_promotion(fr, anchor_idx, actions, promotion_only=True):
    """Deterministic base-order-preserving insertion.
    actions: {item_id -> action_label}. Missing/KEEP -> original slot. Returns final list."""
    backbone = fr["backbone"]; m = len(backbone)
    keep_slot = fr["keep_slot"]
    # intervention score (desc) for within-gap ordering / KEEP order
    iscore = {r["item_id"]: r["intervention_score"] for r in fr["resc_info"]}
    gap_items = {g: [] for g in range(m + 1)}
    for iid in fr["rescued"]:
        act = actions.get(iid, "KEEP")
        g = action_to_gap(act, anchor_idx, keep_slot) if anchor_idx else keep_slot
        if promotion_only and g >= keep_slot:
            g = keep_slot                                  # only upward moves allowed
        g = min(max(g, 0), m)
        gap_items[g].append(iid)
    for g in gap_items:
        gap_items[g].sort(key=lambda i: (-iscore.get(i, 0.0), i))
    out = []
    for g in range(m + 1):
        out.extend(gap_items[g])
        if g < m:
            out.append(backbone[g])
    return out


def apply_local_rerank(fr, order_window, freeze_top=5, lo=6, hi=20):
    """Original Agent-R ranker: freeze ranks 1..freeze_top, reorder ranks lo..hi per the LLM
    permutation, tail fixed. Operates on the frozen exp10 order."""
    base = list(fr["exp10_order"])
    lo0, hi0 = lo - 1, hi                                  # slice [lo0:hi0] = ranks lo..hi
    window = base[lo0:hi0]
    wset = set(window)
    perm = [i for i in order_window if i in wset]
    for i in window:                                       # append any omitted, stable
        if i not in perm:
            perm.append(i)
    return base[:lo0] + perm + base[hi0:]


# --------------------------------------------------------------------- metrics
def mrr(preds, targets):
    ts = set(str(t) for t in targets)
    for r, i in enumerate(preds):
        if str(i) in ts:
            return 1.0 / (r + 1)
    return 0.0


def all_metrics(preds, targets):
    tg = [str(t) for t in targets]
    out = {}
    for k in EVAL_KS:
        out[f"Recall@{k}"] = recall_at_k(preds, tg, k)
        out[f"NDCG@{k}"] = ndcg_at_k(preds, tg, k)
    out["MRR"] = mrr(preds, tg)
    return out
