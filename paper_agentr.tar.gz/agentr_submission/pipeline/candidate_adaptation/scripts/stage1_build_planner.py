#!/usr/bin/env python3
"""Integration check: build the FROZEN PLANNER_CONDITIONED candidate substrate.

Identical to stage1_build.py EXCEPT the rescue weights: instead of the fixed validated
w_bar (prior_only), each user gets w_u = Normalize(w_bar (x) expand_delta(delta_u)), with
delta_u the EXISTING exp10 LLM planner policy (planner_delta shards). This is the exact
per-user weighting of stage_planner_eval.py (LEVEL/CH2KEY/expand_delta + L1-renorm to prior
mass) fed into the SAME build_user_frozen executor (same pool, hard agreement gate, hard
calibrators, keep/budget, base-prefix preservation, deterministic composition,
intervention_score). Parse-fail / missing user -> all-neutral == prior_only for that user.

Writes: artifacts/frozen_<ds>_planner.pkl  (same schema as frozen_<ds>.pkl)
Verifies: test R@50 vs the known exp10 planner_conditioned result.
Does NOT touch the prior_only frozen_<ds>.pkl.
"""
from __future__ import annotations
import argparse, glob, json, pickle, sys
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pr_common import (  # noqa: E402
    DATASETS, FINAL_K, CHANNELS, AUX_TOOLS,
    load_dataset, load_item_titles, load_prior_weights,
    fit_hard_calibrators, build_user_frozen, recall_at_k,
)

# ---- per-user planner policy expansion (verbatim from stage_planner_eval.py) ----
LEVEL = {"down": 0.5, "neutral": 1.0, "up": 2.0}
CH2KEY = {f"q_{m}": m for m in AUX_TOOLS}
CH2KEY.update({"agr": "cross_path_support", "pref": "user_preference_match"})


def expand_delta(delta):
    mult = np.ones(len(CHANNELS))
    for ci, ch in enumerate(CHANNELS):
        key = CH2KEY.get(ch)
        if key is not None and key in delta:
            mult[ci] = LEVEL.get(delta[key], 1.0)
    return mult


def load_deltas(ds, exp10_dir, delta_suffix=""):
    """Return {(split, uid): row} from planner_delta shards, keyed by each row's own split field.

    delta_suffix="" (default): the exp10 convention of SEPARATE test/valid delta files.
    delta_suffix="_modern" (exp16): a SINGLE combined-split shard set produced with --split both
    (planner_delta_<ds>_modern.shard*.pkl); every row already carries split in {valid,test}."""
    out = {}
    if delta_suffix:
        globs = [(exp10_dir / "artifacts" / f"planner_delta_{ds}{delta_suffix}.shard*.pkl", None)]
    else:
        globs = [
            (exp10_dir / "artifacts" / f"planner_delta_{ds}.shard*.pkl", "test"),
            (exp10_dir / "artifacts" / f"planner_delta_valid_{ds}.shard*.pkl", "valid"),
        ]
    for g, _ in globs:
        for f in glob.glob(str(g)):
            for r in pickle.load(open(f, "rb")):
                out[(r["split"], r["userid"])] = r
    return out


def user_weight(w_bar, total_mass, drow):
    if drow is None or not drow.get("parse_ok"):
        return w_bar.copy(), False
    mult = expand_delta(drow["delta"])
    w_u = w_bar * mult
    s = w_u.sum()
    if s > 0:
        w_u = w_u * (total_mass / s)   # L1-renorm to fixed prior mass
    return w_u, True


def build_frozen_all(ds, exp10_dir, delta_suffix="", prior_only=False, policy="planner",
                     keep=None, budget=None):
    spec = DATASETS[ds]
    keep0, budget0 = spec["keep"], spec["budget"]
    # RQ2 budget sensitivity / no-candidate-adaptation (keep=50, budget=0) overrides
    if keep is not None:
        keep0 = keep
    if budget is not None:
        budget0 = budget
    D = load_dataset(ds)
    cached, item_meta, user_meta, dataset = D["cached"], D["item_meta"], D["user_meta"], D["dataset"]
    titles = load_item_titles(Path(D["cfg"].dataset.data_dir) / ds)
    w_bar, prior_name, off = load_prior_weights(ds)
    w_bar = np.asarray(w_bar, dtype=float)
    total_mass = float(w_bar.sum())
    valid_users = sorted(dataset.user_valid_items)
    test_users = sorted(dataset.user_test_items)
    vmap = {u: [str(x) for x in v] for u, v in dataset.user_valid_items.items()}
    tmap = {u: [str(x) for x in v] for u, v in dataset.user_test_items.items()}

    print(f"[{ds}] fitting exp10 hard calibrators on validation ...", flush=True)
    cals = fit_hard_calibrators(cached, valid_users, vmap, item_meta, user_meta, keep0)

    # prior_only (RQ2 "w/o Planning"): no planner policy -> every user gets the neutral calibrated w_bar
    # RQ2 planner-replacement policies (all users get the same executor/calibrators, only the allocation differs):
    #   uniform : global equal channel weights, no per-user policy
    #   valstr  : global validation-strength channel weights, no per-user policy
    #   shuffle : the LLM planner's per-user policies randomly permuted across users (same marginal, seed 42)
    if policy in ("uniform", "valstr"):
        w_bar = np.asarray(off["calibrated_prior_weights"]["equal" if policy == "uniform" else "valstr"], float)
        total_mass = float(w_bar.sum())
        prior_only = True
    deltas = {} if prior_only else load_deltas(ds, exp10_dir, delta_suffix)
    if policy == "shuffle":
        rng = np.random.default_rng(42)
        for sp in ("valid", "test"):
            keys = sorted(k for k in deltas if k[0] == sp)
            rows = [deltas[k] for k in keys]
            perm = rng.permutation(len(rows))
            for k, j in zip(keys, perm):
                deltas[k] = rows[j]
    n_test_d = sum(1 for (sp, _) in deltas if sp == "test")
    n_valid_d = sum(1 for (sp, _) in deltas if sp == "valid")
    print(f"[{ds}] loaded planner deltas: test={n_test_d} valid={n_valid_d}", flush=True)

    frozen = {"valid": {}, "test": {}}
    parse_ok = {"valid": 0, "test": 0}
    fallback = {"valid": 0, "test": 0}
    for split, users in (("valid", valid_users), ("test", test_users)):
        tgm = vmap if split == "valid" else tmap
        for u in users:
            if not tgm.get(u):
                continue
            drow = deltas.get((split, str(u)))
            w_u, ok = user_weight(w_bar, total_mass, drow)
            parse_ok[split] += int(ok)
            fallback[split] += int(not ok)
            fr = build_user_frozen(cached, u, keep0, budget0, w_u, cals, item_meta, user_meta)
            if fr is None:
                continue
            frozen[split][u] = fr

    for split in ("valid", "test"):
        tot = parse_ok[split] + fallback[split]
        fr_rate = fallback[split] / max(tot, 1)
        print(f"[{ds}] {split}: parse_ok={parse_ok[split]} fallback={fallback[split]} "
              f"fallback_rate={fr_rate:.4f}", flush=True)

    meta = {"dataset": ds, "keep": keep0, "budget": budget0, "prior_name": prior_name,
            "w_bar": w_bar.tolist(),
            "substrate": policy if policy != "planner" else ("prior_only" if prior_only else "planner_conditioned"),
            "parse_ok": parse_ok, "fallback": fallback,
            "exp10_prior_R50_test": off["test"][prior_name]["R50"]}
    return dict(frozen=frozen, meta=meta, titles=titles, user_meta=user_meta, tmap=tmap)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--exp10-dir",
                    default=str(HERE.parent.parent / "planning"))
    ap.add_argument("--known-planner-r50", type=float, default=None,
                    help="known exp10 planner_conditioned test R@50 for the sanity gate")
    ap.add_argument("--delta-suffix", default="",
                    help="exp16: '_modern' -> read the combined-split planner_delta_<ds>_modern shards")
    ap.add_argument("--frozen-suffix", default="_planner",
                    help="output name suffix: frozen_<ds><frozen_suffix>.pkl (default _planner; "
                         "exp16 modern substrate uses _planner_modern for isolation)")
    ap.add_argument("--prior-only", action="store_true",
                    help="RQ2 w/o Planning: ignore planner deltas, all users use neutral w_bar")
    ap.add_argument("--policy", default="planner", choices=["planner", "uniform", "valstr", "shuffle"],
                    help="RQ2 planner replacement policy")
    ap.add_argument("--keep", type=int, default=None)
    ap.add_argument("--budget", type=int, default=None)
    args = ap.parse_args()
    ds = args.dataset
    exp10_dir = Path(args.exp10_dir)
    out = HERE.parent / "artifacts"
    out.mkdir(parents=True, exist_ok=True)
    frozen_path = out / f"frozen_{ds}{args.frozen_suffix}.pkl"

    built = build_frozen_all(ds, exp10_dir, args.delta_suffix, args.prior_only, args.policy,
                             args.keep, args.budget)
    B = {"frozen": built["frozen"], "meta": built["meta"],
         "titles": built["titles"], "user_meta": built["user_meta"]}
    pickle.dump(B, open(frozen_path, "wb"))
    print(f"[{ds}] wrote {frozen_path}", flush=True)

    # ---- sanity gate: planner_conditioned test R@50 ----
    tmap = built["tmap"]
    r50 = [recall_at_k(fr["exp10_order"], tmap[u], 50) for u, fr in built["frozen"]["test"].items()]
    repro = float(np.mean(r50))
    prior_r50 = built["meta"]["exp10_prior_R50_test"]
    msg = (f"[{ds}] planner_conditioned frozen test R@50={repro:.6f} "
           f"| prior_only(exp10)={prior_r50:.6f}")
    if args.known_planner_r50 is not None:
        err = abs(repro - args.known_planner_r50)
        msg += (f" | known_planner_cond={args.known_planner_r50:.6f} abs_err={err:.2e} "
                f"pass_2e-3={err <= 2e-3}")
    print(msg, flush=True)


if __name__ == "__main__":
    main()
