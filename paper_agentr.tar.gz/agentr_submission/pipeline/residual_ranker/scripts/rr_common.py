#!/usr/bin/env python3
"""exp15 -- Base-Anchored Residual LLM Ranker: shared CPU library (model-agnostic).

Architecture (spec 0-1): Qwen2.5-7B is used as a CROSS-ENCODER, NOT a generator. For each
(user, candidate) pair we build one concise prompt, run a single forward pass, pool the last
non-pad hidden state h_{u,i}, and a trainable scalar head gives q=w.h+b, residual r=tanh(q) in
[-1,1]. Final ranking score s_u(i) = p_u(i) + alpha * r_u(i), where p_u(i) is a frozen recommender
prior that EXACTLY reproduces the exp10/no_ranking order at alpha=0 (safety property). We sort the
SAME frozen final-50 -> Recall@50 invariant by construction.

PURELY INCREMENTAL. Reuses exp12's frozen_<ds>.pkl and exp14's diagnostic split (splits.json:
ranker_train/ranker_dev 80/20 uid-hash, rankable-only, GT id per user, base/rescued tag) VERBATIM
(spec 4). Metrics/baselines/bootstrap are reused from exp14's gw_eval (which reuses exp12/exp13).
Nothing in src/, scripts/, configs/, caches, exp10-14 artifacts is modified.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
EXP14 = HERE.parent.parent / "ranking_common" / "scripts"
if str(EXP14) not in sys.path:
    sys.path.insert(0, str(EXP14))

# reuse exp14 helpers verbatim (which reuse exp12/exp13 substrate + metrics)
import gw_common as gw            # noqa: E402
import gw_eval as ge             # noqa: E402

FINAL_K = 50
# DATA_DIR is env-overridable. DEFAULT = data_planner (the planner_conditioned substrate is the
# integrated-pipeline default as of 2026-09-24). Set AGENTR_DATA_DIR=.../data to use the prior_only
# residual data/splits (the fallback/ablation). Kept env-overridable so either substrate stays
# isolated and never clobbers the other.
DATA_DIR = Path(os.environ.get("AGENTR_DATA_DIR") or str(HERE.parent / "data_planner"))


# --------------------------------------------------------------------- load substrate + split
def load_substrate(ds):
    """Return (frozen_valid, titles, user_meta, split). Reuses exp14's diagnostic split when it
    exists (Software); for domains exp14 never built (Music/Game/Industrial) uses the exp15-local
    splits.json produced by build_splits.py with the SAME logic (rankable valid users, 80/20 uid
    hash seed_tag 'exp14gw'). exp14 artifacts are never written to."""
    blob = gw.load_frozen(ds)
    frozen_v = blob["frozen"]["valid"]
    titles = blob["titles"]
    user_meta = blob["user_meta"]
    local = DATA_DIR / ds / "splits.json"
    exp14_sp = EXP14.parent / "data" / ds / "splits.json"
    # AGENTR_LOCAL_SPLIT forces the local split (rebuilt on the ACTIVE substrate) instead of
    # exp14's prior_only split -- required when the frozen substrate is not prior_only. DEFAULT="1"
    # since the planner_conditioned substrate is now the pipeline default; set AGENTR_LOCAL_SPLIT="0"
    # only when running the prior_only fallback and you want to reuse exp14's diagnostic split.
    if os.environ.get("AGENTR_LOCAL_SPLIT", "1") == "1":
        sp_path = local
    else:
        sp_path = exp14_sp if exp14_sp.exists() else local
    split = json.load(open(sp_path))
    return frozen_v, titles, user_meta, split


# --------------------------------------------------------------------- priors (spec 3)
def base_ranks(fr, final_k=FINAL_K):
    """1-indexed exp10 rank for each of the final-50 candidate ids: {iid: rank}."""
    return {iid: k + 1 for k, iid in enumerate(fr["exp10_order"][:final_k])}


def prior_A(rank, final_k=FINAL_K):
    """Normalized rank prior p = -(r-1)/(K-1) in [-1,0]; exact monotone order, span 1.0 (spec 3.A)."""
    return -(rank - 1) / (final_k - 1)


class PriorB:
    """Empirical calibrated rank prior (spec 3.B): isotonic P(GT | exp10 rank) fit on RANKER-TRAIN
    ONLY, converted to a clipped logit then min-max mapped to [-1, 0] (monotone decreasing, span 1,
    scale-compatible with prior A so alpha sweeps are comparable). Preserves exp10 order exactly."""

    def __init__(self, score_by_rank):
        self.score_by_rank = {int(k): float(v) for k, v in score_by_rank.items()}
        self._max_rank = max(self.score_by_rank)

    @staticmethod
    def fit(train_uids, frozen_v, gt_map, final_k=FINAL_K, clip=(1e-4, 1 - 1e-4)):
        from sklearn.isotonic import IsotonicRegression
        ranks, ys = [], []
        for u in train_uids:
            fr = frozen_v[u]
            br = base_ranks(fr, final_k)
            gt = gt_map[u]
            for iid, r in br.items():
                ranks.append(r)
                ys.append(1.0 if iid == gt else 0.0)
        ranks = np.asarray(ranks, float)
        ys = np.asarray(ys, float)
        iso = IsotonicRegression(increasing=False, out_of_bounds="clip", y_min=0.0, y_max=1.0)
        iso.fit(ranks, ys)
        grid = np.arange(1, final_k + 1, dtype=float)
        p = np.clip(iso.predict(grid), clip[0], clip[1])
        logit = np.log(p / (1 - p))                 # monotone decreasing in rank
        lo, hi = logit.min(), logit.max()
        norm = (logit - lo) / (hi - lo + 1e-12) - 1.0   # -> [-1, 0], highest score at rank 1
        return PriorB({int(r): float(s) for r, s in zip(grid, norm)})

    def score(self, rank):
        r = int(min(max(rank, 1), self._max_rank))
        return self.score_by_rank[r]

    def to_json(self):
        return {"type": "isotonic_calibrated_rank_prior", "score_by_rank": self.score_by_rank}


def prior_vector(fr, which, priorB=None, final_k=FINAL_K):
    """Prior score for each of the final-50 in exp10 order. `which` in {'A','B'}."""
    order = fr["exp10_order"][:final_k]
    if which == "A":
        return np.array([prior_A(k + 1, final_k) for k in range(len(order))], float)
    return np.array([priorB.score(k + 1) for k in range(len(order))], float)


# --------------------------------------------------------------------- LLM Memory Agent (STM/LTM) profile
# The residual ranker's "User profile:" text is a compact render of the LLM Memory Agent's structured
# STM/LTM state (outputs/indexes/<ds>/user_memory_llm_agent_*.json). This is now the DEFAULT
# (AGENTR_USER_MEMORY=llm) as of 2026-09-24: the memory-online experiment
# (develop/2026-09-24_llm_memory_online_experiment.md) showed STM/LTM SIGNIFICANTLY BEATS the
# deterministic user_meta render as ranker input (Software ranker gain +0.0141->+0.0235, Game
# +0.0062 ns -> +0.0403 sig), R@50 invariant. Set AGENTR_USER_MEMORY=det for the prior deterministic
# profile (ablation / datasets without LLM memory auto-fall-back). Candidate set / frozen-50 are
# unchanged either way, so R@50 stays invariant. NOTE: the shipped ranker checkpoint must be trained
# WITH the same profile it serves -- the LLM-memory default pairs with the res_*_planner_mem
# checkpoints (Software res_a_planner_mem/step_236 prior B a=0.5; Game res_game_planner_mem/step_62
# prior B a=0.75), NOT the deterministic res_*_planner checkpoints.
_REPO = HERE.parent.parent.parent          # .../AgentRec-main
_LLM_MEM_CACHE = {}


def _load_llm_memory(ds):
    if ds not in _LLM_MEM_CACHE:
        p = _REPO / "outputs" / "indexes" / ds / "user_memory_llm_agent_qwen2p5_7b_instruct.json"
        # LLM STM/LTM memory has only been built for some datasets (Software/Game). When the file is
        # absent (e.g. Music / Industrial / _dg), fall back gracefully to {} so profile_text_for()
        # reverts to the deterministic user_meta profile instead of crashing. This keeps
        # AGENTR_USER_MEMORY=llm (now the default) safe across every dataset.
        blob = json.load(open(p)) if p.exists() else {}
        _LLM_MEM_CACHE[ds] = blob.get("users", blob) if isinstance(blob, dict) else blob
    return _LLM_MEM_CACHE[ds]


def llm_profile_text(st):
    """Compact render of an LLM STM/LTM memory record into the ranker prompt profile line."""
    if not st:
        return "No profile available."
    def j(x, n=5):
        return ", ".join(str(v) for v in x[:n]) if isinstance(x, list) else ""
    parts = []
    stm = j(st.get("short_term_intents", []))
    ltc = j(st.get("long_term_categories", []))
    ltb = j(st.get("long_term_brands", []))
    stab = j(st.get("stable_preferences", []))
    if stm:
        parts.append(f"recent intents: {stm}")
    if ltc:
        parts.append(f"long-term categories: {ltc}")
    if ltb:
        parts.append(f"preferred brands: {ltb}")
    if stab:
        parts.append(f"stable preferences: {stab}")
    return "; ".join(parts) if parts else "No profile available."


def profile_text_for(uid, um, ds=None):
    """Select the ranker prompt profile: LLM STM/LTM memory (DEFAULT as of 2026-09-24, after the
    memory-online experiment showed STM/LTM beats the deterministic profile as ranker input on
    Software+Game) or the deterministic user_meta render. Set AGENTR_USER_MEMORY=det to force the
    deterministic profile (the prior default / ablation). Falls back to deterministic automatically
    when a dataset has no LLM memory built (see _load_llm_memory)."""
    mode = os.environ.get("AGENTR_USER_MEMORY", "llm")
    if mode == "llm" and ds is not None:
        st = _load_llm_memory(ds).get(str(uid))
        if st is not None:
            return llm_profile_text(st)
    if mode == "det_full":
        return det_full_profile_text(um)
    return gw.user_profile_text(um)


def det_full_profile_text(um, k=5):
    """RQ2 w/o-Memory profile: the documented deterministic user_meta render (history length +
    top categories + top brands). gw.user_profile_text only parses set-repr STRINGS, but the modern
    frozen user_meta stores these as LISTS, so under 'det' they were silently dropped (history length
    only). 'det' is kept byte-identical for reproducibility; 'det_full' renders lists correctly."""
    if not um:
        return "No profile available."
    def lst(x):
        if isinstance(x, str):
            return gw._clean_set_str(x, k)
        return ", ".join(str(v) for v in list(x)[:k] if v) if x else ""
    parts = [f"history length: {um.get('history_len', '?')}"]
    tc, tb = lst(um.get("top_categories", "")), lst(um.get("top_brands", ""))
    if tc:
        parts.append(f"preferred categories: {tc}")
    if tb:
        parts.append(f"preferred brands: {tb}")
    return "; ".join(parts)


# --------------------------------------------------------------------- shipped ranker resolver
# So the pipeline never runs with a checkpoint that MISMATCHES the active memory/substrate mode (and
# so a serving/TEST run cannot silently forget which ckpt/prior/alpha to use), the DEV-selected,
# TEST-confirmed "shipped recipe" for each (memory_mode, substrate_suffix, dataset) is registered
# here. eval_residual.py resolves it automatically when --ckpt is omitted. If the required checkpoint
# has not been trained yet, the resolver FAILS LOUD with the exact training command instead of
# running a wrong/empty ranker.
CKPT_ROOT = HERE.parent / "checkpoints"

# key = (AGENTR_USER_MEMORY, AGENTR_FROZEN_SUFFIX, ds) -> pinned dev-selected config.
# train_epochs/save = the recipe that produced `step`, surfaced in the fail-loud hint below.
SHIPPED_RANKER = {
    # all-LLM default (2026-09-24): LLM STM/LTM memory profile + planner_conditioned substrate.
    ("llm", "_planner", "Software_10_80_r811"):
        dict(tag="res_a_planner_mem",    step=236, prior="B", alpha=0.5,  obj="A", train_prior="A", epochs=2),
    ("llm", "_planner", "Game_10_80_r811"):
        dict(tag="res_game_planner_mem", step=62,  prior="B", alpha=0.75, obj="A", train_prior="A", epochs=8),
    # deterministic-memory + planner substrate (prior default; ablation).
    ("det", "_planner", "Software_10_80_r811"):
        dict(tag="res_a_planner",        step=118, prior="A", alpha=1.0,  obj="A", train_prior="A", epochs=2),
    ("det", "_planner", "Game_10_80_r811"):
        dict(tag="res_game_planner",     step=124, prior="B", alpha=1.0,  obj="A", train_prior="A", epochs=8),
}


def _active_modes():
    return (os.environ.get("AGENTR_USER_MEMORY", "llm"),
            os.environ.get("AGENTR_FROZEN_SUFFIX", "_planner"))


def resolve_shipped_ranker(ds):
    """Return (ckpt_path, prior, alpha, tag) for the DEV-selected shipped ranker matching the active
    memory/substrate mode. Raises SystemExit with a ready-to-run training command if the config is
    unregistered or its checkpoint is missing (fail-loud, never silent)."""
    mem, suffix = _active_modes()
    key = (mem, suffix, ds)
    cfg = SHIPPED_RANKER.get(key)
    if cfg is None:
        known = "\n".join(f"    {k}" for k in sorted(SHIPPED_RANKER))
        raise SystemExit(
            f"[resolve_shipped_ranker] no shipped ranker registered for "
            f"(memory={mem}, substrate={suffix}, ds={ds}).\n"
            f"  Registered configs:\n{known}\n"
            f"  Either dev-select this combination and add it to rr_common.SHIPPED_RANKER, or pass "
            f"--ckpt/--fixed_prior/--fixed_alpha explicitly.")
    ckpt = CKPT_ROOT / cfg["tag"] / f"step_{cfg['step']}"
    if not ckpt.exists():
        node = "<free P5 node of job JOBID>"
        raise SystemExit(
            f"[resolve_shipped_ranker] shipped checkpoint MISSING for "
            f"(memory={mem}, substrate={suffix}, ds={ds}):\n    {ckpt}\n"
            f"  This ranker has not been trained for this mode yet — refusing to run so the pipeline "
            f"does not serve a mismatched/empty checkpoint. Train it first:\n"
            f"    AGENTR_USER_MEMORY={mem} JOBID=JOBID TAG={cfg['tag']} OBJ={cfg['obj']} "
            f"PRIOR={cfg['train_prior']} DS={ds} EPOCHS={cfg['epochs']} NODE={node} bash launch_train.sh\n"
            f"  (build its residual data first if data_planner{'_mem' if mem == 'llm' else ''}/{ds} "
            f"is absent), then dev-select and confirm step={cfg['step']}.")
    return ckpt, cfg["prior"], cfg["alpha"], cfg["tag"]


# --------------------------------------------------------------------- cross-encoder prompt (spec 14)
def _fmt_routes(route_ranks):
    if not isinstance(route_ranks, dict) or not route_ranks:
        return ""
    return ", ".join(f"{k}#{v}" for k, v in route_ranks.items())


def candidate_prompt(um, iid, rank, fr, titles, resc_map, final_k=FINAL_K, prof_text=None):
    """Concise cross-encoder text for ONE (user, candidate) pair. Legal Agent-R info only: user
    memory profile, candidate title/brand/category/desc, and recommender evidence (normalized rank
    bucket, base/rescued provenance, retrieval routes+ranks, cross-route support, calibrated
    intervention score, brand match). No GT label, no future interactions. `prof_text` overrides the
    default deterministic profile (used by the AGENTR_USER_MEMORY=llm STM/LTM experiment)."""
    prof = prof_text if prof_text is not None else gw.user_profile_text(um)
    t = titles.get(iid, {}) or {}
    title = (t.get("title") or f"item {iid}").strip()
    desc = (t.get("desc") or "").replace("\n", " ").strip()
    if len(desc) > 120:
        desc = desc[:120].rstrip() + "..."
    ri = resc_map.get(iid)
    brand = (ri or {}).get("brand", "") or ""
    cand = f"{title}" + (f" (brand: {brand})" if brand else "") + (f" -- {desc}" if desc else "")
    # recommender evidence
    nb = (rank - 1) / (final_k - 1)                      # 0=head, 1=tail
    ev = [f"base rank {rank}/{final_k} (normalized {nb:.2f})"]
    if ri is not None:                                   # rescued item -> rich evidence
        ev.append("provenance: rescued/complementary candidate")
        rr = _fmt_routes(ri.get("route_ranks"))
        if rr:
            ev.append(f"retrieval routes (rank per source): {rr}")
        ev.append(f"cross-route support: {ri.get('cross_path_support', 0)}")
        ev.append(f"calibrated intervention score: {float(ri.get('intervention_score', 0.0)):.3f}")
        ev.append("brand matches user history: " + ("yes" if ri.get("brand_match") else "no"))
    else:
        ev.append("provenance: base recommender candidate")
    evidence = "; ".join(ev)
    return (
        "You are a recommendation ranking expert judging one candidate for a user.\n"
        f"User profile: {prof}\n"
        f"Candidate item: {cand}\n"
        f"Recommender evidence: {evidence}\n"
        "Assess how likely this candidate is the user's next interaction."
    )


def user_record(uid, fr, um, titles, gt_map, tag_map, final_k=FINAL_K, ds=None):
    """Everything the trainer/eval needs for one user's full-50 ranking problem. `ds` enables the
    LLM STM/LTM memory profile when AGENTR_USER_MEMORY=llm (else deterministic user_meta)."""
    order = fr["exp10_order"][:final_k]
    resc_map = {r["item_id"]: r for r in fr["resc_info"]}
    br = base_ranks(fr, final_k)
    gt = gt_map[uid]
    prof_text = profile_text_for(uid, um, ds)
    prompts = [candidate_prompt(um, iid, br[iid], fr, titles, resc_map, final_k, prof_text)
               for iid in order]
    gt_idx = order.index(gt) if gt in order else -1
    return {
        "uid": uid,
        "cand_ids": order,
        "base_rank": [br[iid] for iid in order],
        "gt_id": gt,
        "gt_idx": gt_idx,
        "tag": tag_map.get(uid, "base"),
        "prompts": prompts,
    }


# --------------------------------------------------------------------- fused scoring / ranking
def fused_order(cand_ids, prior_vec, residual_vec, alpha):
    """Sort candidates by s = prior + alpha*residual (desc). Stable: ties keep exp10 order.
    Returns the reordered id list (same set -> Recall@50 invariant)."""
    s = prior_vec + alpha * np.asarray(residual_vec, float)
    idx = sorted(range(len(cand_ids)), key=lambda k: (-s[k], k))   # -s desc, k = exp10 tiebreak
    return [cand_ids[k] for k in idx]


ALPHA_GRID = [0.0, 0.01, 0.02, 0.05, 0.10, 0.20, 0.30, 0.50, 0.75, 1.0]
