#!/usr/bin/env python3
"""exp15 -- build the exp14-style diagnostic split for a domain exp14 never processed
(Music/Game/Industrial). Reproduces pipeline/ranking_common/scripts/build_data.py
lines 62-93 VERBATIM (the split portion only -- no groupwise SFT data): rankable valid users
(GT=interaction.csv label==1 inside the frozen final-50), 80/20 by uid hash (gw.uid_split, seed_tag
'exp14gw'), GT id + base/rescued tag per user. Writes to the exp15-LOCAL data dir so exp14 artifacts
are never touched (rr.load_substrate prefers exp14's splits.json when present -> Software unaffected).
Writes: data/<ds>/splits.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402
from build_data import load_valid_targets  # exp14's loader (label==1), reused verbatim  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--train_frac", type=float, default=0.8)
    args = ap.parse_args()

    blob = rr.gw.load_frozen(args.ds)
    frozen_v = blob["frozen"]["valid"]
    vtgt = load_valid_targets(args.ds)
    rankable = rr.gw.rankable_users(frozen_v, vtgt)
    n_all = len(frozen_v)
    print(f"[pop] valid users={n_all} rankable={len(rankable)} ({len(rankable)/n_all:.4f})")

    splits = {"train": [], "dev": []}
    gt_map, tag_map = {}, {}
    base_t = resc_t = 0
    for uid in rankable:
        fr = frozen_v[uid]
        gt = rr.gw.gt_in_pool(fr, vtgt)
        if gt is None:
            continue
        gt_map[uid] = gt
        is_resc = gt in set(fr["rescued"])
        tag_map[uid] = "rescued" if is_resc else "base"
        base_t += int(not is_resc); resc_t += int(is_resc)
        splits[rr.gw.uid_split(uid, args.train_frac)].append(uid)
    print(f"[split] train={len(splits['train'])} dev={len(splits['dev'])} "
          f"| base-target={base_t} rescued-target={resc_t}")

    outd = rr.DATA_DIR / args.ds
    outd.mkdir(parents=True, exist_ok=True)
    json.dump({"train": splits["train"], "dev": splits["dev"],
               "gt": gt_map, "tag": tag_map,
               "config": {"ds": args.ds, "train_frac": args.train_frac,
                          "source": "exp15 build_splits (exp14 build_data.py split logic verbatim)"},
               "diagnostic_extra_supervision": True},
              open(outd / "splits.json", "w"))
    print(f"[write] {outd}/splits.json")


if __name__ == "__main__":
    main()
