#!/usr/bin/env python3
"""exp15 -- evaluate a residual-ranker checkpoint (spec 13, 17-32).

Key efficiency property (spec 2): the residual r_u(i)=tanh(head(h_{u,i})) is PRIOR- and ALPHA-
independent, so we run the 50-candidate cross-encoder forward pass ONCE per dev user, cache the
residuals, then sweep prior in {A,B} x alpha in ALPHA_GRID purely on CPU. For each (prior,alpha) we
re-sort the SAME frozen final-50 by s = prior + alpha*residual (Recall@50 invariant by construction;
alpha=0 reproduces no_ranking EXACTLY -- asserted). Full metrics/diagnostics/bootstrap reuse exp14's
gw_eval (which reuses exp12/exp13). Baselines: no_ranking + proposal_only (exp13, shipped).

Selection is on DEV NDCG@10 only, alpha>0 required to count as a win (spec 25/29). Writes:
  artifacts/<tag>/alpha_sweep.csv, residual_cache.pkl, residual_stats.json,
  rank_change_stats.json, per_user_results.csv, eval.json
Single-GPU (the forward pass is cheap: ~50*n_dev short sequences).
"""
from __future__ import annotations

import argparse
import csv
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402
from train_residual import Ranker  # reuse the exact module/pooling  # noqa: E402


def load_ckpt(ckpt_dir, device):
    from transformers import AutoModel, AutoTokenizer
    cfg = json.load(open(Path(ckpt_dir) / "config.json"))
    base_model = cfg["base_model"]
    tok = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"
    try:
        base = AutoModel.from_pretrained(base_model, torch_dtype=torch.bfloat16,
                                         attn_implementation="flash_attention_2",
                                         trust_remote_code=True)
    except Exception as e:
        print(f"[warn] flash_attention_2 unavailable ({e}); falling back to sdpa")
        base = AutoModel.from_pretrained(base_model, torch_dtype=torch.bfloat16,
                                         attn_implementation="sdpa", trust_remote_code=True)
    adapter = Path(ckpt_dir) / "adapter"
    if adapter.exists():
        from peft import PeftModel
        base = PeftModel.from_pretrained(base, adapter)
        base = base.merge_and_unload()          # fold LoRA for fast inference
    model = Ranker(base).to(device).eval()
    head_sd = torch.load(Path(ckpt_dir) / "head.pt", map_location=device)
    model.head.load_state_dict(head_sd)
    model.head.to(device)
    return model, tok, cfg


@torch.no_grad()
def compute_residuals(model, tok, dev, device, max_len, batch=128):
    """Return {uid: np.array(50) residuals}. One forward per (user,candidate)."""
    flat, index = [], []           # index[k] = (uid, pos)
    for rec in dev:
        for pos, p in enumerate(rec["prompts"]):
            flat.append(tok.apply_chat_template([{"role": "user", "content": p}],
                                                add_generation_prompt=True, tokenize=False))
            index.append((rec["uid"], pos))
    res = {rec["uid"]: np.zeros(len(rec["prompts"]), np.float32) for rec in dev}
    t0 = time.time()
    for i in range(0, len(flat), batch):
        chunk = flat[i:i + batch]
        enc = tok(chunk, return_tensors="pt", padding=True, truncation=True, max_length=max_len)
        r, _ = model(enc["input_ids"].to(device), enc["attention_mask"].to(device))
        r = r.float().cpu().numpy()
        for j, val in enumerate(r):
            uid, pos = index[i + j]
            res[uid][pos] = val
        if (i // batch) % 50 == 0:
            print(f"  residuals {i}/{len(flat)} ({(time.time()-t0):.0f}s)", flush=True)
    return res


def prior_vec_for(rec, which, priorB):
    if which == "A":
        return np.array([rr.prior_A(rk) for rk in rec["base_rank"]], float)
    return np.array([priorB.score(rk) for rk in rec["base_rank"]], float)


def build_finals(dev, residuals, which, priorB, alpha):
    out = {}
    for rec in dev:
        pv = prior_vec_for(rec, which, priorB)
        out[rec["uid"]] = rr.fused_order(rec["cand_ids"], pv, residuals[rec["uid"]], alpha)
    return out


def main():
    import gw_eval as ge
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="Software_10_80_r811")
    # --ckpt optional: when omitted, resolve the DEV-selected SHIPPED ranker for the active
    # memory/substrate mode (rr.resolve_shipped_ranker) and PIN its prior/alpha — so a serving/TEST
    # run can never forget the ckpt or run one that mismatches AGENTR_USER_MEMORY. Pass --ckpt
    # explicitly for manual / dev-sweep runs (unchanged behaviour).
    ap.add_argument("--ckpt", default=None)           # .../checkpoints/<tag>/step_N (auto if omitted)
    ap.add_argument("--tag", default=None)            # label for artifacts/<tag> (auto if omitted)
    ap.add_argument("--split", default="dev", choices=["dev", "test"])
    ap.add_argument("--priors", nargs="+", default=["A", "B"])
    # TEST protocol: fix the DEV-selected config, do NOT re-select on test.
    ap.add_argument("--fixed_prior", default=None, choices=[None, "A", "B"])
    ap.add_argument("--fixed_alpha", type=float, default=None)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--limit_users", type=int, default=0)   # >0 = smoke
    ap.add_argument("--reuse_cache", action="store_true")
    args = ap.parse_args()

    if args.ckpt is None:
        ckpt, r_prior, r_alpha, r_tag = rr.resolve_shipped_ranker(args.ds)
        args.ckpt = str(ckpt)
        # pin the shipped prior/alpha (unless the caller overrode them) and default the artifact tag.
        if args.fixed_prior is None:
            args.fixed_prior = r_prior
        if args.fixed_alpha is None:
            args.fixed_alpha = r_alpha
        if args.tag is None:
            args.tag = f"{r_tag}_s{ckpt.name.split('_')[-1]}" + ("_TEST" if args.split == "test" else "")
        print(f"[resolve] shipped ranker: ckpt={args.ckpt} prior={args.fixed_prior} "
              f"alpha={args.fixed_alpha} tag={args.tag}")
    elif args.tag is None:
        raise SystemExit("--tag is required when --ckpt is given explicitly")

    device = torch.device("cuda", 0)
    frozen_v, titles, user_meta, split = rr.load_substrate(args.ds)
    recs = pickle.load(open(rr.DATA_DIR / args.ds / "residual_users.pkl", "rb"))
    dev = recs[args.split] if args.split in recs else recs["dev"]
    if args.limit_users > 0:
        dev = dev[:args.limit_users]
    uids = [r["uid"] for r in dev]
    if args.split == "test":
        # held-out TEST: use the test frozen substrate + GT carried in the records (built by
        # build_test_data.py). splits.json["gt"] only covers valid; do NOT touch it here.
        frozen_v = rr.gw.load_frozen(args.ds)["frozen"]["test"]
        gt_map = {r["uid"]: r["gt_id"] for r in dev}
    else:
        gt_map = split["gt"]
    priorB = rr.PriorB(json.load(open(rr.DATA_DIR / args.ds / "priorB.json"))["score_by_rank"])

    outd = HERE.parent / "artifacts" / args.tag
    outd.mkdir(parents=True, exist_ok=True)
    cache_f = outd / f"residual_cache_{args.split}.pkl"

    cfg = json.load(open(Path(args.ckpt) / "config.json"))
    if args.reuse_cache and cache_f.exists():
        residuals = pickle.load(open(cache_f, "rb"))
        print(f"[cache] reused {cache_f}")
    else:
        model, tok, cfg = load_ckpt(args.ckpt, device)
        residuals = compute_residuals(model, tok, dev, device, cfg["max_len"], args.batch)
        pickle.dump(residuals, open(cache_f, "wb"))
        del model
        torch.cuda.empty_cache()

    # ---- baselines
    base_finals = ge.no_ranking_finals(uids, frozen_v)
    pum_base = ge.per_user_metrics(uids, base_finals, gt_map)
    if args.split == "test":
        # exp13 proposal_pi is a VALID-only artifact; no honest proposal_only exists for test users.
        pum_prop = None
    else:
        try:
            prop_finals = ge.load_proposal_only_finals(args.ds, uids, frozen_v)
            pum_prop = ge.per_user_metrics(uids, prop_finals, gt_map)
        except Exception as e:
            print(f"[warn] proposal_only unavailable: {e}")
            pum_prop = None

    base_tags = {r["uid"]: r["tag"] for r in dev}
    seg = {"base": [u for u in uids if base_tags[u] == "base"],
           "rescued": [u for u in uids if base_tags[u] == "rescued"]}

    # ---- alpha x prior sweep. On DEV: select best by NDCG@10 (alpha>0 required, spec 25/29).
    # On TEST: --fixed_prior/--fixed_alpha pin the DEV-selected config; we do NOT re-select on test
    # (that would be TEST tuning). The full sweep is still logged for the record/diagnostics.
    fixed = args.fixed_prior is not None and args.fixed_alpha is not None
    sweep_rows = []
    best = None
    for which in args.priors:
        for alpha in rr.ALPHA_GRID:
            finals = build_finals(dev, residuals, which, priorB, alpha)
            if alpha == 0.0:
                bad = sum(finals[u] != base_finals[u] for u in uids)
                assert bad == 0, f"alpha=0 must equal no_ranking exactly, got {bad} diffs"
            r50_bad = ge.assert_r50_invariant(uids, finals, frozen_v)
            assert r50_bad == 0, f"R@50 broken: {r50_bad}"
            pum = ge.per_user_metrics(uids, finals, gt_map)
            a = ge.agg(pum, uids)
            row = {"prior": which, "alpha": alpha, **{k: a[k] for k in ge.PRIMARY}}
            sweep_rows.append(row)
            print(f"  prior={which} alpha={alpha:<5} N@10={a['NDCG@10']:.4f} "
                  f"R@10={a['Recall@10']:.4f} N@5={a['NDCG@5']:.4f} R@50={a['Recall@50']:.4f}")
            if fixed:
                if which == args.fixed_prior and abs(alpha - args.fixed_alpha) < 1e-9:
                    best = {"prior": which, "alpha": alpha, "agg": a, "pum": pum, "finals": finals}
            elif alpha > 0 and (best is None or a["NDCG@10"] > best["agg"]["NDCG@10"]):
                best = {"prior": which, "alpha": alpha, "agg": a, "pum": pum, "finals": finals}
    assert best is not None, (f"fixed config prior={args.fixed_prior} alpha={args.fixed_alpha} "
                              f"not found in sweep" if fixed else "no alpha>0 config found")

    with open(outd / "alpha_sweep.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["prior", "alpha"] + ge.PRIMARY)
        w.writeheader()
        w.writerows(sweep_rows)

    # ---- selected config: diagnostics + significance
    sel = best
    finals = sel["finals"]
    pum = sel["pum"]
    diag = ge.diagnostics(uids, finals, base_finals, gt_map)
    bs_no = ge.bootstrap_cmp(uids, pum, pum_base, metrics=ge.PRIMARY)
    wl_no = ge.user_winloss(uids, pum, pum_base)
    bs_prop = ge.bootstrap_cmp(uids, pum, pum_prop, metrics=ge.PRIMARY) if pum_prop else None
    wl_prop = ge.user_winloss(uids, pum, pum_prop) if pum_prop else None

    seg_stats = {}
    for name, sub in seg.items():
        if not sub:
            continue
        seg_stats[name] = {
            "n": len(sub),
            "sel": ge.agg(pum, sub),
            "no_ranking": ge.agg(pum_base, sub),
            "diag": ge.diagnostics(sub, finals, base_finals, gt_map),
        }

    # ---- residual statistics + rank-change stratified by original GT rank (spec 28)
    all_res = np.concatenate([residuals[u] for u in uids])
    base_rank_flat = np.concatenate([np.asarray(r["base_rank"], float) for r in dev])
    interv = []
    for r in dev:
        fr = frozen_v[r["uid"]]
        rescmap = {ri["item_id"]: float(ri.get("intervention_score", 0.0)) for ri in fr["resc_info"]}
        interv.extend([rescmap.get(iid, 0.0) for iid in r["cand_ids"]])
    interv = np.asarray(interv, float)
    frac_changed = float(np.mean([finals[u] != base_finals[u] for u in uids]))
    res_stats = {
        "abs_mean": float(np.mean(np.abs(all_res))),
        "abs_median": float(np.median(np.abs(all_res))),
        "abs_p90": float(np.percentile(np.abs(all_res), 90)),
        "mean": float(np.mean(all_res)), "std": float(np.std(all_res)),
        "corr_with_base_rank": float(np.corrcoef(all_res, base_rank_flat)[0, 1]),
        "corr_with_intervention": (float(np.corrcoef(all_res, interv)[0, 1])
                                   if interv.std() > 0 else None),
        "frac_users_order_changed": frac_changed,
        "selected_prior": sel["prior"], "selected_alpha": sel["alpha"],
    }

    strata = [("1-5", 1, 5), ("6-10", 6, 10), ("11-20", 11, 20),
              ("21-35", 21, 35), ("36-50", 36, 50)]
    rank_change = {}
    for name, lo, hi in strata:
        sub = [r["uid"] for r in dev if lo <= (r["gt_idx"] + 1) <= hi]
        if not sub:
            continue
        d = [ge.gt_rank(base_finals[u], gt_map[u]) - ge.gt_rank(finals[u], gt_map[u]) for u in sub]
        rank_change[name] = {"n": len(sub), "gt_rank_improve_mean": float(np.mean(d)),
                             "n_up": int(sum(x > 0 for x in d)), "n_down": int(sum(x < 0 for x in d))}

    # ---- write per-user CSV for selected config
    with open(outd / "per_user_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["uid", "tag", "gt_base_rank", "gt_rank_sel", "N@10_sel", "N@10_base", "N@10_prop"])
        for r in dev:
            u = r["uid"]
            w.writerow([u, r["tag"], r["gt_idx"] + 1, ge.gt_rank(finals[u], gt_map[u]),
                        f"{pum[u]['NDCG@10']:.4f}", f"{pum_base[u]['NDCG@10']:.4f}",
                        f"{pum_prop[u]['NDCG@10']:.4f}" if pum_prop else ""])

    summary = {
        "tag": args.tag, "ckpt": args.ckpt, "split": args.split, "n_users": len(uids),
        "config": cfg,
        "selected": {"prior": sel["prior"], "alpha": sel["alpha"], "agg": sel["agg"]},
        "no_ranking": ge.agg(pum_base, uids),
        "proposal_only": ge.agg(pum_prop, uids) if pum_prop else None,
        "vs_no_ranking": {"bootstrap": bs_no, "winloss": wl_no},
        "vs_proposal_only": ({"bootstrap": bs_prop, "winloss": wl_prop} if pum_prop else None),
        "diagnostics": diag, "segments": seg_stats,
        "residual_stats": res_stats, "rank_change_by_gt_rank": rank_change,
    }
    json.dump(summary, open(outd / "eval.json", "w"), indent=2)
    json.dump(res_stats, open(outd / "residual_stats.json", "w"), indent=2)
    json.dump(rank_change, open(outd / "rank_change_stats.json", "w"), indent=2)

    print(f"\n===== {'FIXED (dev-selected, applied to '+args.split+')' if fixed else 'SELECTED (dev N@10, alpha>0)'} =====")
    print(f"tag={args.tag} prior={sel['prior']} alpha={sel['alpha']}")
    print(f"  selected     N@10={sel['agg']['NDCG@10']:.4f} R@10={sel['agg']['Recall@10']:.4f} "
          f"N@5={sel['agg']['NDCG@5']:.4f} N@50={sel['agg']['NDCG@50']:.4f} "
          f"R@50={sel['agg']['Recall@50']:.4f}")
    print(f"  no_ranking   N@10={summary['no_ranking']['NDCG@10']:.4f} "
          f"R@10={summary['no_ranking']['Recall@10']:.4f}")
    if pum_prop:
        print(f"  proposal_only N@10={summary['proposal_only']['NDCG@10']:.4f} "
              f"R@10={summary['proposal_only']['Recall@10']:.4f}")
    print(f"  vs_no N@10 delta={bs_no['NDCG@10']['delta']:+.4f} sig={bs_no['NDCG@10']['sig']} "
          f"| winloss {wl_no}")
    if bs_prop:
        print(f"  vs_prop N@10 delta={bs_prop['NDCG@10']['delta']:+.4f} sig={bs_prop['NDCG@10']['sig']}")
    print(f"  GT rank {diag['gt_rank_mean_before']:.2f}->{diag['gt_rank_mean_after']:.2f} "
          f"| residual |mean|={res_stats['abs_mean']:.3f} corr(base_rank)="
          f"{res_stats['corr_with_base_rank']:.3f} frac_changed={frac_changed:.3f}")
    print(f"[write] {outd}")


if __name__ == "__main__":
    main()
