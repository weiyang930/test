#!/usr/bin/env bash
# exp15 -- evaluate ONE residual-ranker checkpoint on 1 GPU (alpha x prior sweep + metrics).
# Runs on a spare node (default: idle P6 dev node 132-139 of job JOBID) so it does not collide
# with the P5 training runs. flash-attn falls back to sdpa inside eval_residual.py if needed.
#
# Usage: CKPT=../checkpoints/res_a/step_119 TAG=res_a_s119 [NODE=node01] [JOBID=...] \
#        [SPLIT=dev] [GPU=0] bash launch_eval.sh
set -uo pipefail
D=/path/to/agentr/pipeline/residual_ranker
PY=${PY_LLM:-python}
# CKPT/TAG optional: if unset, eval_residual.py auto-resolves the SHIPPED ranker for the active
# memory/substrate mode (rr.resolve_shipped_ranker) and pins its prior/alpha. Set them for manual runs.
CKPT="${CKPT:-}"
TAG="${TAG:-}"
DS="${DS:-Software_10_80_r811}"
NODE="${NODE:-node01}"
SPLIT="${SPLIT:-dev}"
GPU="${GPU:-0}"
# For the frozen TEST run: PRIORS="A" FIXED_PRIOR=A FIXED_ALPHA=1.0 pin the DEV-selected config.
# When CKPT/TAG are unset, they are NOT passed -> eval_residual.py auto-resolves the shipped ranker.
EXTRA=""
[ -n "$CKPT" ] && EXTRA="$EXTRA --ckpt $CKPT"
[ -n "$TAG" ] && EXTRA="$EXTRA --tag $TAG"
[ -n "${PRIORS:-}" ] && EXTRA="$EXTRA --priors $PRIORS"
[ -n "${FIXED_PRIOR:-}" ] && EXTRA="$EXTRA --fixed_prior $FIXED_PRIOR"
[ -n "${FIXED_ALPHA:-}" ] && EXTRA="$EXTRA --fixed_alpha $FIXED_ALPHA"
LABEL="${TAG:-auto_${DS}_${SPLIT}}"     # logging/job-name label (TAG may be auto-resolved in python)
JOBID="${JOBID:-$(squeue -u $USER -h -o '%i' -w $NODE 2>/dev/null | head -1)}"
mkdir -p "$D/logs"
echo "=== eval label=$LABEL ckpt=${CKPT:-<auto>} split=$SPLIT node=$NODE gpu=$GPU jobid=$JOBID ==="

srun --overlap --jobid="$JOBID" --nodelist="$NODE" --nodes=1 --ntasks=1 --gres=gpu:1 \
     --gpu-bind=none --cpus-per-task=16 --time=01:00:00 --job-name=eval_${LABEL} \
     bash -c '
       export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
       export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
       export AGENTR_USER_MEMORY='"${AGENTR_USER_MEMORY-llm}"'
       export AGENTR_FROZEN_SUFFIX='"${AGENTR_FROZEN_SUFFIX-_planner}"'
       export AGENTR_DATA_DIR='"${AGENTR_DATA_DIR-}"'
       export AGENTR_LOCAL_SPLIT='"${AGENTR_LOCAL_SPLIT-1}"'
       export CUDA_VISIBLE_DEVICES='"$GPU"' TRITON_CACHE_DIR=/tmp/tr_eval_'"$LABEL"'
       cd '"$D"'/scripts
       '"$PY"' eval_residual.py --ds '"$DS"' --split '"$SPLIT"' --batch 128'"$EXTRA"'
     ' 2>&1 | tee "$D/logs/eval_${LABEL}.log"
echo "=== eval srun exit=$? label=$LABEL ==="
