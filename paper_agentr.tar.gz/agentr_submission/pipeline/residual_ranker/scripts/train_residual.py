#!/usr/bin/env python3
"""exp15 -- train the Base-Anchored Residual LLM Ranker (spec 6-13).

Qwen2.5-7B as a CROSS-ENCODER: one forward per (user,candidate), pool the last non-pad hidden
state, scalar head -> q=w.h+b, residual r=tanh(q) in [-1,1]. Fused score s_i = p_i + alpha_train*r_i
where p_i is the frozen exp10-rank prior (A: normalized rank). The LOSS OPERATES ON THE FUSED SCORE
(spec 6), so the LLM learns the residual CORRECTION given a strong prior, not a ranking from scratch.

Training unit = the FULL final-50 user problem (spec 5) so train == eval ranking problem (fixes the
exp14 local-to-global mismatch). Two objectives:
  A (fused listwise):  L = -log softmax(s/tau)[gt] + beta*mean(r^2)
  B (base-anchored):   L = L_up + lambda_p*L_preserve + beta*mean(r^2)
      L_up       = sum_{j: rank_j<rank_gt} w_gt,j * softplus(-(s_gt - s_j)),  NDCG-sensitive weight
      L_preserve = sum over adjacent non-GT base-order pairs (i<j) softplus(-(s_i - s_j))
Method = LoRA (q/k/v/o/gate/up/down) + trainable scalar head, bf16, grad-ckpt. --freeze_base gives
the spec-11 frozen-head diagnostic (head-only, no LoRA). Saves LoRA adapter + head + config each
checkpoint; eval_residual.py does the alpha sweep. DDP via torchrun (users sharded across ranks).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, DistributedSampler

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402


# --------------------------------------------------------------------- data
class UserDataset(Dataset):
    def __init__(self, recs, prior_which, priorB):
        self.recs = recs
        self.prior_which = prior_which
        self.priorB = priorB

    def __len__(self):
        return len(self.recs)

    def __getitem__(self, i):
        r = self.recs[i]
        if self.prior_which == "A":
            prior = np.array([rr.prior_A(rk) for rk in r["base_rank"]], np.float32)
        else:
            prior = np.array([self.priorB.score(rk) for rk in r["base_rank"]], np.float32)
        return {"prompts": r["prompts"], "prior": prior, "gt_idx": r["gt_idx"],
                "base_rank": np.asarray(r["base_rank"], np.int64), "tag": r["tag"]}


def make_collate(tok, max_len):
    def collate(batch):
        # flatten all users' candidates; remember per-user slice
        texts, slices, priors, gts, ranks = [], [], [], [], []
        off = 0
        for b in batch:
            msgs = [[{"role": "user", "content": p}] for p in b["prompts"]]
            rendered = [tok.apply_chat_template(m, add_generation_prompt=True, tokenize=False)
                        for m in msgs]
            texts.extend(rendered)
            n = len(rendered)
            slices.append((off, off + n))
            off += n
            priors.append(torch.tensor(b["prior"]))
            gts.append(int(b["gt_idx"]))
            ranks.append(torch.tensor(b["base_rank"]))
        enc = tok(texts, return_tensors="pt", padding=True, truncation=True, max_length=max_len)
        return {"input_ids": enc["input_ids"], "attention_mask": enc["attention_mask"],
                "slices": slices, "priors": priors, "gts": gts, "ranks": ranks}
    return collate


# --------------------------------------------------------------------- losses
def listwise_loss(s, gt_idx, tau):
    return -torch.log_softmax(s / tau, dim=0)[gt_idx]


def base_anchored_loss(s, gt_idx, base_rank, lambda_p):
    rank = base_rank.float()
    gain = 1.0 / torch.log2(rank + 1.0)
    gt_gain = gain[gt_idx]
    # L_up: candidates ranked ABOVE gt (smaller rank) should be outranked by gt
    above = base_rank < base_rank[gt_idx]
    if above.any():
        w = (gain[above] - gt_gain).abs()
        margin = s[gt_idx] - s[above]
        l_up = (w * torch.nn.functional.softplus(-margin)).sum()
    else:
        l_up = s.sum() * 0.0
    # L_preserve: adjacent non-GT base-order pairs (k, k+1) keep s_k >= s_{k+1}
    order = torch.argsort(base_rank)                       # positions in ascending base rank
    a, b = order[:-1], order[1:]
    keep = (a != gt_idx) & (b != gt_idx)
    if keep.any():
        l_pre = torch.nn.functional.softplus(-(s[a][keep] - s[b][keep])).sum()
    else:
        l_pre = s.sum() * 0.0
    return l_up + lambda_p * l_pre


# --------------------------------------------------------------------- model
class Ranker(nn.Module):
    def __init__(self, base):
        super().__init__()
        self.base = base
        h = base.config.hidden_size
        # LayerNorm is ESSENTIAL: Qwen2 hidden states have massive-activation outlier dims (O(1e2-1e3));
        # a raw linear head over them saturates tanh to a constant -> zero per-candidate signal. LN
        # conditions the features so the head can learn per-candidate variation (fp32 for stability).
        self.head = nn.Sequential(nn.LayerNorm(h), nn.Linear(h, 1))
        nn.init.normal_(self.head[1].weight, std=0.01)
        nn.init.zeros_(self.head[1].bias)

    def forward(self, input_ids, attention_mask):
        out = self.base(input_ids=input_ids, attention_mask=attention_mask,
                        output_hidden_states=False, use_cache=False)
        hs = out.last_hidden_state                          # [B,T,H]
        last = attention_mask.sum(1) - 1                    # last non-pad index (right padded)
        pooled = hs[torch.arange(hs.size(0), device=hs.device), last]
        q = self.head(pooled.float()).squeeze(-1)               # pre-activation
        r = torch.tanh(q)                                       # [B] in [-1,1]
        return r, q


def is_main():
    return (not dist.is_initialized()) or dist.get_rank() == 0


def log(*a):
    if is_main():
        print(*a, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="Software_10_80_r811")
    ap.add_argument("--tag", required=True)
    ap.add_argument("--objective", choices=["A", "B"], required=True)
    ap.add_argument("--prior", choices=["A", "B"], default="A")
    ap.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--alpha_train", type=float, default=0.2)
    ap.add_argument("--tau", type=float, default=1.0)
    ap.add_argument("--beta", type=float, default=0.05)      # trust-region L2 on pre-activation q
    ap.add_argument("--lambda_p", type=float, default=0.5)   # base-order preservation (obj B)
    ap.add_argument("--lora_rank", type=int, default=16)
    ap.add_argument("--lora_alpha", type=int, default=32)
    ap.add_argument("--freeze_base", action="store_true")    # spec 11 frozen-head diagnostic
    ap.add_argument("--users_per_step", type=int, default=2)
    ap.add_argument("--accum", type=int, default=4)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--head_lr", type=float, default=1e-3)
    ap.add_argument("--epochs", type=float, default=2.0)
    ap.add_argument("--max_len", type=int, default=256)
    ap.add_argument("--save_frac", type=float, nargs="+", default=[0.5, 1.0, 2.0])
    ap.add_argument("--limit_users", type=int, default=0)   # >0 = smoke on a subset
    ap.add_argument("--seed", type=int, default=42)
    # RQ2 "w/o Prior Anchor" ablation: drop the recommendation prior from the score; the LLM is a
    # direct preference scorer s = q (raw head logit). Same data/prompts/LoRA/loss/regularizer.
    ap.add_argument("--no_prior", action="store_true")
    args = ap.parse_args()

    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    world = int(os.environ.get("WORLD_SIZE", 1))
    if world > 1:
        dist.init_process_group("nccl")
        torch.cuda.set_device(local_rank)
    device = torch.device("cuda", local_rank)
    torch.manual_seed(args.seed)

    from transformers import AutoModel, AutoTokenizer
    from peft import LoraConfig, get_peft_model, TaskType

    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"

    base = AutoModel.from_pretrained(args.model, torch_dtype=torch.bfloat16,
                                     attn_implementation="flash_attention_2", trust_remote_code=True)
    base.gradient_checkpointing_enable()
    base.config.use_cache = False
    if not args.freeze_base:
        lcfg = LoraConfig(task_type=TaskType.FEATURE_EXTRACTION, r=args.lora_rank,
                          lora_alpha=args.lora_alpha, lora_dropout=0.05,
                          target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                                          "gate_proj", "up_proj", "down_proj"])
        base = get_peft_model(base, lcfg)
    else:
        for p in base.parameters():
            p.requires_grad_(False)

    model = Ranker(base).to(device)
    if world > 1:
        model = nn.parallel.DistributedDataParallel(
            model, device_ids=[local_rank], find_unused_parameters=False,
            gradient_as_bucket_view=True)
    core = model.module if world > 1 else model

    # data
    recs = pickle.load(open(rr.DATA_DIR / args.ds / "residual_users.pkl", "rb"))["train"]
    if args.limit_users > 0:
        recs = recs[:args.limit_users]
    priorB = None
    if args.prior == "B":
        pj = json.load(open(rr.DATA_DIR / args.ds / "priorB.json"))
        priorB = rr.PriorB(pj["score_by_rank"])
    ds = UserDataset(recs, args.prior, priorB)
    sampler = DistributedSampler(ds, shuffle=True, seed=args.seed) if world > 1 else None
    dl = DataLoader(ds, batch_size=args.users_per_step, sampler=sampler,
                    shuffle=(sampler is None), collate_fn=make_collate(tok, args.max_len),
                    num_workers=4, drop_last=True, pin_memory=True)

    # optimizer: separate lr for LoRA vs head
    head_params = list(core.head.parameters())
    head_ids = {id(p) for p in head_params}
    lora_params = [p for p in core.parameters() if p.requires_grad and id(p) not in head_ids]
    opt = torch.optim.AdamW([{"params": lora_params, "lr": args.lr},
                             {"params": head_params, "lr": args.head_lr}],
                            weight_decay=0.0, betas=(0.9, 0.95))
    n_train = len(lora_params) + len(head_params)
    log(f"[trainable] lora_tensors={len(lora_params)} head_tensors={len(head_params)} "
        f"freeze_base={args.freeze_base}")

    steps_per_epoch = math.ceil(len(dl) / args.accum)
    total_steps = int(steps_per_epoch * args.epochs)
    save_steps = sorted({min(int(f * steps_per_epoch), total_steps) for f in args.save_frac})
    log(f"[plan] world={world} users={len(recs)} dl_batches={len(dl)} accum={args.accum} "
        f"steps/epoch={steps_per_epoch} total_steps={total_steps} save@{save_steps}")

    ckpt_dir = HERE.parent / "checkpoints" / args.tag
    if is_main():
        ckpt_dir.mkdir(parents=True, exist_ok=True)

    def save_ckpt(step):
        if not is_main():
            return
        d = ckpt_dir / f"step_{step}"
        d.mkdir(parents=True, exist_ok=True)
        if not args.freeze_base:
            core.base.save_pretrained(d / "adapter")
        torch.save(core.head.state_dict(), d / "head.pt")
        json.dump({"tag": args.tag, "objective": args.objective, "prior": args.prior,
                   "alpha_train": args.alpha_train, "freeze_base": args.freeze_base,
                   "base_model": args.model, "max_len": args.max_len, "step": step,
                   "lora_rank": args.lora_rank, "lora_alpha": args.lora_alpha,
                   "no_prior": args.no_prior},
                  open(d / "config.json", "w"), indent=1)
        log(f"[save] {d}")

    model.train()
    gstep = 0
    t0 = time.time()
    micro = 0
    running = 0.0
    done = False
    epoch = 0
    while not done:
        if sampler is not None:
            sampler.set_epoch(epoch)
        for batch in dl:
            ids = batch["input_ids"].to(device)
            am = batch["attention_mask"].to(device)
            r_all, q_all = model(ids, am)                # [sum_n] residuals + pre-activations
            loss = 0.0
            for k, (a, b) in enumerate(batch["slices"]):
                r = r_all[a:b]
                prior = batch["priors"][k].to(device)
                s = q_all[a:b] if args.no_prior else prior + args.alpha_train * r
                gt = batch["gts"][k]
                if args.objective == "A":
                    lu = listwise_loss(s, gt, args.tau)
                else:
                    lu = base_anchored_loss(s, gt, batch["ranks"][k].to(device), args.lambda_p)
                # trust region on the PRE-activation q (not r): penalizing r vanishes at tanh
                # saturation and cannot pull a saturated unit back; penalizing q keeps tanh responsive.
                lu = lu + args.beta * (q_all[a:b] ** 2).mean()
                loss = loss + lu
            loss = loss / len(batch["slices"]) / args.accum
            loss.backward()
            running += loss.item() * args.accum
            micro += 1
            if micro % args.accum == 0:
                torch.nn.utils.clip_grad_norm_(
                    [p for p in core.parameters() if p.requires_grad], 1.0)
                opt.step()
                opt.zero_grad(set_to_none=True)
                gstep += 1
                if gstep % 20 == 0:
                    log(f"[step {gstep}/{total_steps}] loss={running/20/args.accum:.4f} "
                        f"({(time.time()-t0)/max(gstep,1):.1f}s/step)")
                    running = 0.0
                if gstep in save_steps:
                    save_ckpt(gstep)
                if gstep >= total_steps:
                    done = True
                    break
        epoch += 1
        if epoch > args.epochs + 1:
            done = True
    if total_steps not in save_steps:
        save_ckpt(gstep)
    log(f"[done] {args.tag} in {(time.time()-t0)/60:.1f} min, {gstep} steps")
    if world > 1:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
