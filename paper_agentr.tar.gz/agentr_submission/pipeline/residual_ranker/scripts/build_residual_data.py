#!/usr/bin/env python3
"""exp15 -- build the full-50 residual-ranking dataset (spec 4-5). Reuses exp14's diagnostic split
VERBATIM (ranker_train/ranker_dev, rankable-only, GT per user, base/rescued tag). For every user we
materialize the FULL final-50 ranking problem: 50 cross-encoder prompts (one per candidate), the
1-indexed exp10 base ranks, and the GT index. Fits Prior B (isotonic P(GT|rank)) on RANKER-TRAIN
ONLY. No TEST labels touched. Writes:
  data/<ds>/residual_users.pkl   {"train":[rec...], "dev":[rec...]}   (rec = rr_common.user_record)
  data/<ds>/priorB.json
  data/<ds>/meta_residual.json

Run with the LLM venv (has sklearn/pyarrow); pure CPU.
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="Software_10_80_r811")
    args = ap.parse_args()

    frozen_v, titles, user_meta, split = rr.load_substrate(args.ds)
    train_uids = split["train"]
    dev_uids = split["dev"]
    gt_map = split["gt"]
    tag_map = split["tag"]
    print(f"[split] train={len(train_uids)} dev={len(dev_uids)} "
          f"(reused exp14 splits.json, diagnostic_extra_supervision="
          f"{split.get('diagnostic_extra_supervision')})")

    # ---- Prior B fit on TRAIN ONLY ----
    priorB = rr.PriorB.fit(train_uids, frozen_v, gt_map)
    outd = rr.DATA_DIR / args.ds
    outd.mkdir(parents=True, exist_ok=True)
    json.dump(priorB.to_json(), open(outd / "priorB.json", "w"), indent=1)
    sb = priorB.score_by_rank
    print(f"[priorB] rank1={sb[1]:.3f} rank5={sb[5]:.3f} rank10={sb[10]:.3f} "
          f"rank25={sb[25]:.3f} rank50={sb[50]:.3f} (monotone decr, [-1,0])")

    # ---- per-user full-50 records ----
    recs = {"train": [], "dev": []}
    n_gt_missing = 0
    base_t = resc_t = 0
    plens = []
    for spl, uids in [("train", train_uids), ("dev", dev_uids)]:
        for uid in uids:
            fr = frozen_v[uid]
            um = user_meta.get(uid, {})
            rec = rr.user_record(uid, fr, um, titles, gt_map, tag_map, ds=args.ds)
            if rec["gt_idx"] < 0:
                n_gt_missing += 1
                continue
            recs[spl].append(rec)
            if spl == "dev":
                pass
            base_t += int(rec["tag"] == "base")
            resc_t += int(rec["tag"] == "rescued")
            if uid == uids[0]:
                plens.append(len(rec["prompts"][0]))
    print(f"[recs] train={len(recs['train'])} dev={len(recs['dev'])} gt_missing={n_gt_missing} "
          f"base_tag={base_t} resc_tag={resc_t}")

    pickle.dump(recs, open(outd / "residual_users.pkl", "wb"))

    # sanity: all recs have GT in the 50, exp10 order preserved
    for spl in ("train", "dev"):
        for rec in recs[spl][:50]:
            assert rec["cand_ids"][rec["gt_idx"]] == rec["gt_id"]
            assert len(rec["cand_ids"]) == rr.FINAL_K
            assert rec["base_rank"] == list(range(1, rr.FINAL_K + 1))

    gt_base_ranks = [r["gt_idx"] + 1 for r in recs["dev"]]
    meta = {
        "dataset": args.ds,
        "n_train_users": len(recs["train"]),
        "n_dev_users": len(recs["dev"]),
        "dev_base_target": sum(int(r["tag"] == "base") for r in recs["dev"]),
        "dev_rescued_target": sum(int(r["tag"] == "rescued") for r in recs["dev"]),
        "final_k": rr.FINAL_K,
        "priorB_span": [min(sb.values()), max(sb.values())],
        "dev_gt_base_rank_mean": float(np.mean(gt_base_ranks)),
        "dev_gt_base_rank_hist": {
            "1-5": int(sum(1 <= r <= 5 for r in gt_base_ranks)),
            "6-10": int(sum(6 <= r <= 10 for r in gt_base_ranks)),
            "11-20": int(sum(11 <= r <= 20 for r in gt_base_ranks)),
            "21-35": int(sum(21 <= r <= 35 for r in gt_base_ranks)),
            "36-50": int(sum(36 <= r <= 50 for r in gt_base_ranks)),
        },
        "example_prompt": recs["train"][0]["prompts"][recs["train"][0]["gt_idx"]],
    }
    json.dump(meta, open(outd / "meta_residual.json", "w"), indent=2)
    print(json.dumps({k: v for k, v in meta.items() if k != "example_prompt"}, indent=2))
    print("\n[example GT prompt]\n" + meta["example_prompt"])
    print(f"\n[write] {outd}/residual_users.pkl")


if __name__ == "__main__":
    main()
