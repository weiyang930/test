#!/usr/bin/env python3
"""exp15 -- build the full-50 TEST-split residual-ranking dataset (spec 26).

Run ONCE, only after the DEV gate has passed and the recipe is frozen. Mirrors the dev protocol
EXACTLY but on the held-out TEST split:
  - substrate = exp12 frozen "test" split (blob["frozen"]["test"])
  - TEST GT    = interaction.csv label==2 (valid uses label==1; build_data.load_valid_targets),
                 rankable-only (GT must sit inside the frozen final-50, gw.rankable_users/gt_in_pool)
  - base/rescued tag derived the same way as exp14: is_resc = gt in fr["rescued"]
  - Prior B is NOT refit -- we keep the TRAIN-only priorB.json (no TEST leakage into the prior)
Appends recs["test"] into data/<ds>/residual_users.pkl (train/dev preserved untouched). No dev/train
labels touched; no re-selection -- eval applies the DEV-selected (prior A, alpha=1.0) config.
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rr_common as rr  # noqa: E402


def load_test_targets(ds):
    """held-out TEST items (label==2), from interaction.csv directly (mirror load_valid_targets)."""
    import pandas as pd
    root = rr.gw.ROOT if hasattr(rr.gw, "ROOT") else None
    csv = (root / "data" / ds / "interaction.csv") if root else \
        (rr.EXP14.parent.parent.parent / "data" / ds / "interaction.csv")
    df = pd.read_csv(csv, dtype={"userid": str, "itemid": str})
    v = df[df["label"] == 2]
    out = {}
    for u, g in v.groupby("userid"):
        out[u] = [str(x) for x in g["itemid"].tolist()]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="Software_10_80_r811")
    args = ap.parse_args()

    blob = rr.gw.load_frozen(args.ds)
    frozen_t = blob["frozen"]["test"]
    titles = blob["titles"]
    user_meta = blob["user_meta"]

    tgt = load_test_targets(args.ds)
    print(f"[test targets] users_with_label2={len(tgt)} frozen_test_users={len(frozen_t)}")

    rankable = rr.gw.rankable_users(frozen_t, tgt)
    print(f"[rankable] test users with GT in final-50 = {len(rankable)}")

    gt_map, tag_map = {}, {}
    for uid in rankable:
        fr = frozen_t[uid]
        gt = rr.gw.gt_in_pool(fr, tgt)
        gt_map[uid] = gt
        tag_map[uid] = "rescued" if gt in set(fr["rescued"]) else "base"

    recs_test = []
    n_gt_missing = 0
    for uid in rankable:
        fr = frozen_t[uid]
        um = user_meta.get(uid, {})
        rec = rr.user_record(uid, fr, um, titles, gt_map, tag_map, ds=args.ds)
        if rec["gt_idx"] < 0:
            n_gt_missing += 1
            continue
        recs_test.append(rec)

    base_t = sum(int(r["tag"] == "base") for r in recs_test)
    resc_t = sum(int(r["tag"] == "rescued") for r in recs_test)
    gt_ranks = [r["gt_idx"] + 1 for r in recs_test]
    print(f"[recs] test={len(recs_test)} gt_missing={n_gt_missing} "
          f"base-target={base_t} rescued-target={resc_t} gt_base_rank_mean={np.mean(gt_ranks):.2f}")

    # sanity mirror of build_residual_data
    for rec in recs_test[:50]:
        assert rec["cand_ids"][rec["gt_idx"]] == rec["gt_id"]
        assert len(rec["cand_ids"]) == rr.FINAL_K
        assert rec["base_rank"] == list(range(1, rr.FINAL_K + 1))

    outd = rr.DATA_DIR / args.ds
    pkl = outd / "residual_users.pkl"
    recs = pickle.load(open(pkl, "rb"))
    recs["test"] = recs_test
    pickle.dump(recs, open(pkl, "wb"))
    print(f"[write] added recs['test']={len(recs_test)} to {pkl} "
          f"(train={len(recs['train'])} dev={len(recs['dev'])} preserved)")

    meta = {
        "dataset": args.ds, "split": "test",
        "n_test_users": len(recs_test), "gt_missing": n_gt_missing,
        "test_base_target": base_t, "test_rescued_target": resc_t,
        "test_gt_base_rank_mean": float(np.mean(gt_ranks)),
        "test_gt_base_rank_hist": {
            "1-5": int(sum(1 <= r <= 5 for r in gt_ranks)),
            "6-10": int(sum(6 <= r <= 10 for r in gt_ranks)),
            "11-20": int(sum(11 <= r <= 20 for r in gt_ranks)),
            "21-35": int(sum(21 <= r <= 35 for r in gt_ranks)),
            "36-50": int(sum(36 <= r <= 50 for r in gt_ranks)),
        },
    }
    json.dump(meta, open(outd / "meta_residual_test.json", "w"), indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
