#!/usr/bin/env bash
# exp15 -- train the Base-Anchored Residual LLM Ranker on ONE p5 node (8xH100) of job JOBID.
# NO verl: plain PyTorch DDP (torch.distributed.run) + Transformers + PEFT (spec 10). Reuses the
# venv_verl_megatron interpreter (torch 2.7 / transformers 4.53 / peft 0.18 / flash_attn 2.8).
#
# Usage: JOBID=JOBID TAG=res_a OBJ=A PRIOR=A NODE=node03 [EPOCHS=2] [FREEZE=0] bash launch_train.sh
set -uo pipefail
REPO=/path/to/agentr
D=$REPO/pipeline/residual_ranker
PY=${PY_LLM:-python}
JOBID="${JOBID:-JOBID}"
TAG="${TAG:?set TAG}"
OBJ="${OBJ:?set OBJ (A|B)}"
PRIOR="${PRIOR:-A}"
DS="${DS:-Software_10_80_r811}"
NODE="${NODE:?set NODE}"
EPOCHS="${EPOCHS:-2}"
FREEZE="${FREEZE:-0}"
EXTRA=""
[ "$FREEZE" = "1" ] && EXTRA="--freeze_base"
# XARGS = arbitrary extra passthrough to train_residual.py (e.g. "--save_frac 2 4 6 8 --alpha_train 0.5")
EXTRA="$EXTRA ${XARGS:-}"
mkdir -p "$D/logs" "$D/checkpoints/$TAG"
echo "=== residual $TAG: obj=$OBJ prior=$PRIOR epochs=$EPOCHS freeze=$FREEZE node=$NODE ==="

srun --overlap --jobid="$JOBID" --nodelist="$NODE" --nodes=1 --ntasks=1 --gres=gpu:8 \
     --gpu-bind=none --cpus-per-task=80 --time=06:00:00 --job-name=res_${TAG} \
     bash -c '
       export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface}
       export HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
       export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1
       export TOKENIZERS_PARALLELISM=false
       export AGENTR_FROZEN_SUFFIX='"${AGENTR_FROZEN_SUFFIX-_planner}"'
       export AGENTR_DATA_DIR='"${AGENTR_DATA_DIR-}"'
       export AGENTR_LOCAL_SPLIT='"${AGENTR_LOCAL_SPLIT-1}"'
       export TRITON_CACHE_DIR=/tmp/tr_res_'"$TAG"'
       cd '"$D"'/scripts
       '"$PY"' -m torch.distributed.run --standalone --nnodes=1 --nproc_per_node=8 \
         train_residual.py --ds '"$DS"' --tag '"$TAG"' --objective '"$OBJ"' --prior '"$PRIOR"' \
         --epochs '"$EPOCHS"' '"$EXTRA"'
     ' 2>&1 | tee "$D/logs/train_${TAG}.log"
echo "=== srun exit=$? tag=$TAG ==="
ls -1d "$D"/checkpoints/"$TAG"/step_* 2>/dev/null
