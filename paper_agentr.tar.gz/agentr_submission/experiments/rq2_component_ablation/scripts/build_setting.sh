#!/usr/bin/env bash
# RQ2 follow-up slate + TEST-only residual records. Usage: DS=<ds> SET=baseonly|<pol>_b<budget> bash build_setting.sh
set -uo pipefail
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker; PROM=$REPO/pipeline/candidate_adaptation
PY=${PY_RECBOLE:-python}
if [ "$SET" = baseonly ]; then POL=uniform; B=0; else POL=${SET%_b*}; B=${SET##*_b}; fi
K=$((50-B))
export AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1 AGENTR_USER_MEMORY=llm
export AGENTR_FROZEN_SUFFIX=_${SET}_modern AGENTR_DATA_DIR=$RES/data_rq2set_modern_mem/$SET
( cd $REPO && $PY $PROM/scripts/stage1_build_planner.py --dataset $DS --policy $POL --keep $K --budget $B \
    --delta-suffix _modern --frozen-suffix _${SET}_modern ) || exit 1
mkdir -p $AGENTR_DATA_DIR/$DS
$PY -c "import pickle;pickle.dump({'train':[],'dev':[]},open('$AGENTR_DATA_DIR/$DS/residual_users.pkl','wb'))"
cd $RES/scripts && $PY build_test_data.py --ds $DS > /dev/null || exit 1
touch $AGENTR_DATA_DIR/$DS/READY; echo "DONE $DS $SET keep=$K budget=$B"
