#!/usr/bin/env bash
# RQ2 -- one (dataset, variant) end-to-end on ONE 8-GPU node:
#   train (same recipe/epochs/save points as the Full run) -> DEV eval every ckpt (1 GPU each, parallel)
#   -> DEV select (select.py, same rule as the Full run) -> TEST once (pinned) -> full-pop eval (rq2_fulltest.py)
# Usage: DS=<ds> VAR=nomem|noplan|noprior JOBID=<j> NODE=<n> bash run_variant.sh
set -uo pipefail
DS="${DS:?}"; VAR="${VAR:?}"; JOBID="${JOBID:?}"; NODE="${NODE:?}"
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker
RQ=$REPO/experiments/rq2_component_ablation
PYG=${PY_LLM:-python}
PYC=${PY_RECBOLE:-python}
TAG=rq2_${DS}_${VAR}
say () { echo "[$(date +%H:%M:%S)] [$TAG] $*" | tee -a $RQ/logs/run_${DS}_${VAR}.log; }

export AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1
case $VAR in
  nomem)   export AGENTR_FROZEN_SUFFIX=_planner_modern   AGENTR_USER_MEMORY=det_full AGENTR_DATA_DIR=$RES/data_planner_modern_det ;;
  noplan)  export AGENTR_FROZEN_SUFFIX=_prioronly_modern AGENTR_USER_MEMORY=llm AGENTR_DATA_DIR=$RES/data_prioronly_modern_mem ;;
  noprior) export AGENTR_FROZEN_SUFFIX=_planner_modern   AGENTR_USER_MEMORY=llm AGENTR_DATA_DIR=$RES/data_planner_modern_mem ;;
esac
# identical per-dataset training schedule to the Full Agent-R run
case $DS in
  Software_10_80_r811)   EPOCHS=2;  SAVE="0.5 1 2" ;;
  Industrial_10_80_r811) EPOCHS=30; SAVE="8 16 24 30" ;;
  KuaiRec_dg)            EPOCHS=8;  SAVE="0.5 1 2 3 4 6 8" ;;
  MicroLens_dg)          EPOCHS=4;  SAVE="0.5 1 2 3 4" ;;
esac
EXTRA="--save_frac $SAVE"; [ "$VAR" = noprior ] && EXTRA="$EXTRA --no_prior"

# wait for data
if [ "$VAR" != noprior ]; then
  while [ ! -e $AGENTR_DATA_DIR/$DS/READY ]; do sleep 30; done
fi
say "data ready: $AGENTR_DATA_DIR/$DS"

# ---- train
CK=$RES/checkpoints/$TAG
if [ -e $CK/TRAIN_DONE ]; then say "train skip"; else
  say "train epochs=$EPOCHS $EXTRA"
  ( cd $RES/scripts && JOBID=$JOBID NODE=$NODE DS=$DS TAG=$TAG OBJ=A PRIOR=A EPOCHS=$EPOCHS \
      XARGS="$EXTRA" bash launch_train.sh > $RQ/logs/train_${TAG}.log 2>&1 )
  grep -q "\[done\]" $RES/logs/train_${TAG}.log || { say "TRAIN FAILED"; exit 1; }
  touch $CK/TRAIN_DONE
fi
STEPS=$(ls -d $CK/step_* | sed 's#.*/step_##' | sort -n | tr '\n' ' ')
say "ckpts: $STEPS"

# ---- DEV eval all ckpts in parallel (1 GPU each)
EVAL=eval_residual.py; [ "$VAR" = noprior ] && EVAL=$RQ/scripts/eval_direct.py
srun --overlap --jobid=$JOBID --nodelist=$NODE --nodes=1 --ntasks=1 --gres=gpu:8 --gpu-bind=none \
     --cpus-per-task=80 --time=02:00:00 --job-name=dev_$TAG bash -c "
  export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
  export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
  cd $RES/scripts; g=0
  for st in $STEPS; do
    if [ ! -e $RES/artifacts/${TAG}_s\${st}_dev/eval.json ]; then
      CUDA_VISIBLE_DEVICES=\$g TRITON_CACHE_DIR=/tmp/tr_${TAG}_\$st $PYG $EVAL --ds $DS --split dev \
        --ckpt $CK/step_\$st --tag ${TAG}_s\${st}_dev > $RQ/logs/dev_${TAG}_s\${st}.log 2>&1 &
      g=\$(( (g+1) % 8 ))
    fi
  done; wait"
say "dev evals done"

# ---- DEV select
read SSTEP SPRIOR SALPHA < <($PYC $RQ/scripts/select.py --ds $DS --tag $TAG --var $VAR --steps $STEPS | tail -1)
say "SELECTED step=$SSTEP prior=$SPRIOR alpha=$SALPHA"
[ -n "$SSTEP" ] || { say "SELECT FAILED"; exit 1; }

# ---- TEST once (pinned)
TT=${TAG}_TEST
if [ -e $RES/artifacts/$TT/residual_cache_test.pkl ]; then say "TEST skip"; else
  if [ "$VAR" = noprior ]; then PIN=""; else PIN="--fixed_prior $SPRIOR --fixed_alpha $SALPHA"; fi
  srun --overlap --jobid=$JOBID --nodelist=$NODE --nodes=1 --ntasks=1 --gres=gpu:1 --gpu-bind=none \
       --cpus-per-task=12 --time=02:00:00 --job-name=te_$TAG bash -c "
    export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
    export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false TRITON_CACHE_DIR=/tmp/tr_te_$TAG
    cd $RES/scripts; $PYG $EVAL --ds $DS --split test --ckpt $CK/step_$SSTEP --tag $TT $PIN" \
    > $RQ/logs/test_${TAG}.log 2>&1 || { say "TEST FAILED"; exit 1; }
fi

# ---- full-population eval
MODE=residual; [ "$VAR" = noprior ] && MODE=direct
$PYC $RQ/scripts/rq2_fulltest.py --ds $DS --variant $VAR --mode $MODE --tag $TT \
     --prior $SPRIOR --alpha $SALPHA --ckpt_step $SSTEP > $RQ/logs/fulltest_${TAG}.log 2>&1 \
  || { say "FULLTEST FAILED"; exit 1; }
tail -4 $RQ/logs/fulltest_${TAG}.log
say "DONE"
