#!/usr/bin/env python3
"""RQ2 inference-only ablation: score one shard of the TEST residual records (rr.DATA_DIR) with the
FULL Agent-R ranker checkpoint (no retraining). Writes {uid: residual[50]} for the shard."""
import argparse, pickle, sys
from pathlib import Path
import torch
RES = Path("/path/to/agentr/pipeline/residual_ranker")
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                                   # noqa: E402
from eval_residual import load_ckpt, compute_residuals   # noqa: E402
ap = argparse.ArgumentParser()
ap.add_argument("--ds", required=True); ap.add_argument("--ckpt", required=True)
ap.add_argument("--shard", type=int, required=True); ap.add_argument("--nshard", type=int, required=True)
ap.add_argument("--out", required=True)
a = ap.parse_args()
recs = pickle.load(open(rr.DATA_DIR / a.ds / "residual_users.pkl", "rb"))["test"][a.shard::a.nshard]
model, tok, cfg = load_ckpt(a.ckpt, torch.device("cuda", 0))
res = compute_residuals(model, tok, recs, torch.device("cuda", 0), cfg["max_len"], 128)
pickle.dump(res, open(a.out, "wb"))
print(f"[shard {a.shard}/{a.nshard}] {len(res)} users -> {a.out}")
