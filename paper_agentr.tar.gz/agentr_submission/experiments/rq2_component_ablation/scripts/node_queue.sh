#!/usr/bin/env bash
# run a list of "DS:VAR" sequentially on one node. Usage: JOBID=.. NODE=.. bash node_queue.sh DS:VAR ...
RQ=/path/to/agentr/experiments/rq2_component_ablation
for it in "$@"; do
  DS=${it%%:*} VAR=${it##*:} JOBID=$JOBID NODE=$NODE bash $RQ/scripts/run_variant.sh \
    > $RQ/logs/run_${DS}_${VAR##*:}.log 2>&1
  echo "[$(date +%H:%M:%S)] finished $it rc=$?"
done
echo "QUEUE DONE $NODE"
