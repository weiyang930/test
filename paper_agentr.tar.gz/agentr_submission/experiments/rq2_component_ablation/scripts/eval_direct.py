#!/usr/bin/env python3
"""RQ2 w/o Prior Anchor -- evaluate a --no_prior (direct preference scorer) checkpoint.
Score = raw head logit q (the quantity trained with the listwise loss); NO prior, NO alpha.
Re-sorts the SAME frozen final-50 by q (desc; exp10 index only as an exact-tie break), so R@50 is
still invariant. Writes the same artifact layout as eval_residual.py (score cache under the
residual_cache_<split>.pkl name so rq2_fulltest.py can read it; eval.json with selected prior='none').
"""
from __future__ import annotations
import argparse, csv, json, pickle, sys, time
from pathlib import Path
import numpy as np
import torch

RES = Path("/path/to/agentr/pipeline/residual_ranker")
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                      # noqa: E402
from eval_residual import load_ckpt         # noqa: E402


@torch.no_grad()
def compute_scores(model, tok, recs, device, max_len, batch=128):
    flat, index = [], []
    for rec in recs:
        for pos, p in enumerate(rec["prompts"]):
            flat.append(tok.apply_chat_template([{"role": "user", "content": p}],
                                                add_generation_prompt=True, tokenize=False))
            index.append((rec["uid"], pos))
    out = {rec["uid"]: np.zeros(len(rec["prompts"]), np.float32) for rec in recs}
    t0 = time.time()
    for i in range(0, len(flat), batch):
        enc = tok(flat[i:i + batch], return_tensors="pt", padding=True, truncation=True, max_length=max_len)
        _, q = model(enc["input_ids"].to(device), enc["attention_mask"].to(device))
        for j, val in enumerate(q.float().cpu().numpy()):
            uid, pos = index[i + j]
            out[uid][pos] = val
        if (i // batch) % 50 == 0:
            print(f"  scores {i}/{len(flat)} ({time.time()-t0:.0f}s)", flush=True)
    return out


def direct_order(cand_ids, q):
    idx = sorted(range(len(cand_ids)), key=lambda k: (-float(q[k]), k))
    return [cand_ids[k] for k in idx]


def main():
    import gw_eval as ge
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--split", default="dev", choices=["dev", "test"])
    ap.add_argument("--batch", type=int, default=128)
    args = ap.parse_args()
    device = torch.device("cuda", 0)
    frozen_v, titles, user_meta, split = rr.load_substrate(args.ds)
    recs = pickle.load(open(rr.DATA_DIR / args.ds / "residual_users.pkl", "rb"))[args.split]
    uids = [r["uid"] for r in recs]
    if args.split == "test":
        frozen_v = rr.gw.load_frozen(args.ds)["frozen"]["test"]
        gt_map = {r["uid"]: r["gt_id"] for r in recs}
    else:
        gt_map = split["gt"]
    cfg = json.load(open(Path(args.ckpt) / "config.json"))
    assert cfg.get("no_prior"), "eval_direct.py is only for --no_prior checkpoints"
    outd = RES / "artifacts" / args.tag
    outd.mkdir(parents=True, exist_ok=True)
    model, tok, cfg = load_ckpt(args.ckpt, device)
    scores = compute_scores(model, tok, recs, device, cfg["max_len"], args.batch)
    pickle.dump(scores, open(outd / f"residual_cache_{args.split}.pkl", "wb"))

    base = ge.no_ranking_finals(uids, frozen_v)
    finals = {r["uid"]: direct_order(r["cand_ids"], scores[r["uid"]]) for r in recs}
    assert ge.assert_r50_invariant(uids, finals, frozen_v) == 0
    pum, pum_b = ge.per_user_metrics(uids, finals, gt_map), ge.per_user_metrics(uids, base, gt_map)
    a, ab = ge.agg(pum, uids), ge.agg(pum_b, uids)
    bs = ge.bootstrap_cmp(uids, pum, pum_b, metrics=ge.PRIMARY)
    allq = np.concatenate([scores[u] for u in uids])
    br = np.concatenate([np.asarray(r["base_rank"], float) for r in recs])
    stats = {"q_mean": float(allq.mean()), "q_std": float(allq.std()),
             "corr_with_base_rank": float(np.corrcoef(allq, br)[0, 1]),
             "frac_users_order_changed": float(np.mean([finals[u] != base[u] for u in uids]))}
    with open(outd / "per_user_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["uid", "tag", "gt_base_rank", "gt_rank_sel", "N@10_sel", "N@10_base"])
        for r in recs:
            u = r["uid"]
            w.writerow([u, r["tag"], r["gt_idx"] + 1, ge.gt_rank(finals[u], gt_map[u]),
                        f"{pum[u]['NDCG@10']:.4f}", f"{pum_b[u]['NDCG@10']:.4f}"])
    json.dump({"tag": args.tag, "ckpt": args.ckpt, "split": args.split, "n_users": len(uids),
               "config": cfg, "selected": {"prior": "none", "alpha": 0.0, "agg": a},
               "no_ranking": ab, "vs_no_ranking": {"bootstrap": bs}, "score_stats": stats},
              open(outd / "eval.json", "w"), indent=2)
    print(f"[{args.tag}] direct N@10={a['NDCG@10']:.4f} R@10={a['Recall@10']:.4f} | no_ranking "
          f"N@10={ab['NDCG@10']:.4f} | d={bs['NDCG@10']['delta']:+.4f} sig={bs['NDCG@10']['sig']} | {stats}")


if __name__ == "__main__":
    main()
