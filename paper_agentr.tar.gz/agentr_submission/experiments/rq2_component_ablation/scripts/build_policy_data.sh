#!/usr/bin/env bash
# RQ2 planner-replacement slate + residual data (CPU). Usage: DS=<ds> POL=uniform|valstr|shuffle bash build_policy_data.sh
set -uo pipefail
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker; PROM=$REPO/pipeline/candidate_adaptation
PY=${PY_RECBOLE:-python}
export AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1 AGENTR_USER_MEMORY=llm
export AGENTR_FROZEN_SUFFIX=_${POL}_modern AGENTR_DATA_DIR=$RES/data_${POL}_modern_mem
( cd $REPO && $PY $PROM/scripts/stage1_build_planner.py --dataset $DS --policy $POL \
    --delta-suffix _modern --frozen-suffix _${POL}_modern ) || exit 1
cd $RES/scripts
$PY build_splits.py --ds $DS > /dev/null || exit 1
$PY build_residual_data.py --ds $DS > /dev/null || exit 1
$PY build_test_data.py --ds $DS > /dev/null || exit 1
touch $AGENTR_DATA_DIR/$DS/READY; echo "DONE $DS $POL"
