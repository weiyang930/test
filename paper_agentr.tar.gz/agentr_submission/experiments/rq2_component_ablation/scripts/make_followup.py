#!/usr/bin/env python3
"""§7 tables: (A) w/o Candidate Adaptation; (B) planner vs allocation policies across rescue budgets."""
import json
from pathlib import Path
A = Path(__file__).resolve().parent.parent / "artifacts"
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"),
      ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
K = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
SAME = {"Software_10_80_r811": "uniform", "KuaiRec_dg": "uniform", "Industrial_10_80_r811": "valstr", "MicroLens_dg": "valstr"}
def load(ds, name):
    f = A / ds / f"{name}.json"
    return json.load(open(f)) if f.exists() else None
def fmt(d): return " | ".join(f"{d['fulltest'][k]:.4f}" for k in K) if d else " | ".join("–" * 4)
def sig(d, k):
    b = (d or {}).get("vs_full_agentr_bootstrap") or {}
    if k not in b: return "–"
    return f"{b[k]['delta']:+.4f}{'*' if b[k]['sig'] and abs(b[k]['delta']) > 1e-9 else ''}"
print("### (A) w/o Candidate Adaptation (keep=50, budget=0: base-route top-50 only, same Full ranker)\n")
print("| Dataset | Variant | N@10 | R@10 | N@50 | R@50 | ΔN@10 | ΔR@50 |"); print("|---|---|---:|---:|---:|---:|---:|---:|")
for ds, dn in DS:
    f, b = load(ds, "full"), load(ds, "set_baseonly")
    print(f"| {dn} | Full Agent-R | {fmt(f)} | – | – |")
    print(f"| {dn} | w/o Candidate Adaptation | {fmt(b)} | {sig(b,'NDCG@10')} | {sig(b,'Recall@50')} |")
print("\n### (B) Rescue-budget sensitivity: LLM planner vs replacement allocation policies\n")
print("Δ columns are vs the budget-10 Full Agent-R (paired bootstrap). Within a budget, compare rows to the LLM-planner row.\n")
print("| Dataset | keep/budget | Policy | N@10 | R@10 | N@50 | R@50 |"); print("|---|---|---|---:|---:|---:|---:|")
POL = [("planner", "LLM planner"), ("uniform", "Uniform"), ("valstr", "Validation-strength"), ("shuffle", "Random per-user")]
for ds, dn in DS:
    for b in (10, 20, 30):
        for p, pn in POL:
            if b == 10:
                name = "full" if p == "planner" else ("noplan_inf" if p == SAME[ds] else f"{p}_inf")
            else:
                name = f"set_{p}_b{b}"
            print(f"| {dn} | {50-b}/{b} | {pn} | {fmt(load(ds, name))} |")
