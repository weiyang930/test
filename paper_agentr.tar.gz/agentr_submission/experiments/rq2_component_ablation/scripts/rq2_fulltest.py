#!/usr/bin/env python3
"""RQ2 full-test-population evaluator -- the canonical fulltest_eval.py protocol, generalized to the
ablation variants and writing to the RQ2 workspace (never overwrites fulltest_<ds>.json).
Population = every official TEST user (frozen[test] keys of the ACTIVE substrate), GT = official
label==2 set, metrics = gw.all_metrics verbatim, missing GT -> 0, plain mean over the full population.
  --mode residual : rankable users re-sorted by prior + alpha*r (saved residual_cache_test.pkl)
  --mode direct   : rankable users re-sorted by the direct score q (w/o Prior Anchor)
  --mode none     : frozen order (w/o Ranking)
Also writes per-user metrics CSV + per-user final top-50 lists (pkl), and a paired bootstrap vs the
Full Agent-R per-user file when the population matches."""
import argparse, csv, json, os, pickle, sys
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr")
RES = REPO / "pipeline/residual_ranker"
MRB = REPO / "pipeline/route_bank"
RQ = REPO / "experiments/rq2_component_ablation"
sys.path.insert(0, str(RES / "scripts")); sys.path.insert(0, str(MRB / "scripts"))
import rr_common as rr                              # noqa: E402
import gw_eval as ge                                # noqa: E402
from build_test_data import load_test_targets       # noqa: E402
from fulltest_eval import build_finals, agg_over, MAIN_KS   # noqa: E402  (canonical helpers)
all_metrics = ge.gw.all_metrics

ap = argparse.ArgumentParser()
ap.add_argument("--ds", required=True); ap.add_argument("--variant", required=True)
ap.add_argument("--mode", required=True, choices=["residual", "direct", "none"])
ap.add_argument("--tag", default=None); ap.add_argument("--prior", default="none")
ap.add_argument("--alpha", type=float, default=0.0); ap.add_argument("--ckpt_step", default="")
# pin the Full ranker's prior-B table when scoring a different substrate with the Full ckpt
ap.add_argument("--priorB_json", default=None)
a = ap.parse_args()

frozen_t = rr.gw.load_frozen(a.ds)["frozen"]["test"]
pop = list(frozen_t.keys())
tmap = load_test_targets(a.ds)
finals = {}
if a.mode != "none":
    recs = pickle.load(open(rr.DATA_DIR / a.ds / "residual_users.pkl", "rb"))["test"]
    sc = pickle.load(open(RES / "artifacts" / a.tag / "residual_cache_test.pkl", "rb"))
    if a.mode == "residual":
        pB = rr.PriorB(json.load(open(a.priorB_json or (rr.DATA_DIR / a.ds / "priorB.json")))["score_by_rank"])
        finals = build_finals(recs, sc, a.prior, pB, a.alpha)
    else:
        finals = {r["uid"]: [r["cand_ids"][k] for k in sorted(range(len(r["cand_ids"])),
                  key=lambda k: (-float(sc[r["uid"]][k]), k))] for r in recs}
final_list = lambda u: finals[u] if u in finals else list(frozen_t[u]["exp10_order"])
pum = {u: all_metrics(final_list(u), tmap.get(u, [])) for u in pop}
res = agg_over(pop, pum)
pum_nr = {u: all_metrics(list(frozen_t[u]["exp10_order"]), tmap.get(u, [])) for u in pop}
nr = agg_over(pop, pum_nr)
bs_nr = ge.bootstrap_cmp(pop, pum, pum_nr, metrics=MAIN_KS) if a.mode != "none" else None

# paired bootstrap vs Full Agent-R on the same full population (unrounded per-user metrics of the
# 'full' variant, which reproduces fulltest_<ds>.json exactly)
outd = RQ / "artifacts" / a.ds; outd.mkdir(parents=True, exist_ok=True)
pickle.dump(pum, open(outd / f"{a.variant}_pum.pkl", "wb"))
full_pkl = outd / "full_pum.pkl"
bs_full = None
if a.variant != "full" and full_pkl.exists():
    pum_full = pickle.load(open(full_pkl, "rb"))
    assert set(pum_full) == set(pop), "population mismatch vs Full"
    bs_full = ge.bootstrap_cmp(pop, pum, pum_full, metrics=MAIN_KS)

outd = RQ / "artifacts" / a.ds; outd.mkdir(parents=True, exist_ok=True)
out = {"dataset": a.ds, "variant": a.variant, "mode": a.mode, "tag": a.tag, "ckpt_step": a.ckpt_step,
       "prior": a.prior, "alpha": a.alpha,
       "env": {k: os.environ.get(k) for k in ("AGENTR_FROZEN_SUFFIX", "AGENTR_DATA_DIR", "AGENTR_USER_MEMORY")},
       "n_test_population": len(pop), "n_rankable": len(finals) if finals else None,
       "coverage_gt_in_top50": float(np.mean([bool(set(frozen_t[u]["exp10_order"][:50]) & set(tmap.get(u, []))) for u in pop])),
       "fulltest": res, "fulltest_no_ranking_same_substrate": nr,
       "vs_no_ranking_bootstrap": bs_nr, "vs_full_agentr_bootstrap": bs_full}
json.dump(out, open(outd / f"{a.variant}.json", "w"), indent=2)
with open(outd / f"{a.variant}_per_user.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["uid", "reordered"] + MAIN_KS)
    for u in pop:
        w.writerow([u, int(u in finals)] + [f"{pum[u][k]:.6f}" for k in MAIN_KS])
pickle.dump({u: final_list(u)[:50] for u in pop}, open(outd / f"{a.variant}_final_top50.pkl", "wb"))
print(f"[{a.ds}/{a.variant}] n_pop={len(pop)} " + " ".join(f"{k}={res[k]:.4f}" for k in MAIN_KS))
if bs_full:
    print("  vs Full: " + " ".join(f"{k} d={bs_full[k]['delta']:+.4f} sig={bs_full[k]['sig']}" for k in MAIN_KS))
