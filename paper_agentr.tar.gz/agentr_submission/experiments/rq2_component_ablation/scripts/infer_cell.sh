#!/usr/bin/env bash
# RQ2 inference-only cell: DS VAR(nomem|noplan) JOBID NODE GPUS="0 1 2 ..."
set -uo pipefail
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker; RQ=$REPO/experiments/rq2_component_ablation
PYG=${PY_LLM:-python}; PYC=${PY_RECBOLE:-python}
case $DS in
  Software_10_80_r811)   CK=$RES/checkpoints/res_software_modern/step_254;  PR=A; AL=0.75 ;;
  Industrial_10_80_r811) CK=$RES/checkpoints/res_industrial_modern/step_72; PR=A; AL=0.2 ;;
  KuaiRec_dg)            CK=$RES/checkpoints/res_KuaiRec_dg_modern/step_128; PR=B; AL=1.0 ;;
  MicroLens_dg)          CK=$RES/checkpoints/res_MicroLens_dg_modern/step_234; PR=A; AL=0.75 ;;
esac
case $VAR in
  nomem)  FS=_planner_modern;   MEM=det_full; DD=$RES/data_planner_modern_det ;;
  noplan) FS=_prioronly_modern; MEM=llm;      DD=$RES/data_prioronly_modern_mem ;;
  uniform|valstr|shuffle) FS=_${VAR}_modern; MEM=llm; DD=$RES/data_${VAR}_modern_mem ;;
esac
TT=rq2inf_${DS}_${VAR}_TEST; OUT=$RES/artifacts/$TT; mkdir -p $OUT/shards
N=$(echo $GPUS | wc -w)
echo "[$(date +%T)] $DS/$VAR ckpt=$CK prior=$PR alpha=$AL gpus=[$GPUS]"
srun --overlap --jobid=$JOBID --nodelist=$NODE --nodes=1 --ntasks=1 --gres=gpu:$N --gpu-bind=none \
     --cpus-per-task=$((N*8)) --time=01:00:00 --job-name=inf_${DS}_${VAR} bash -c "
  export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
  export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
  export AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1 AGENTR_FROZEN_SUFFIX=$FS AGENTR_USER_MEMORY=$MEM AGENTR_DATA_DIR=$DD
  cd $RES/scripts; i=0
  for g in $GPUS; do
    CUDA_VISIBLE_DEVICES=\$g TRITON_CACHE_DIR=/tmp/tr_inf_${DS}_${VAR}_\$i $PYG $RQ/scripts/shard_score.py \
      --ds $DS --ckpt $CK --shard \$i --nshard $N --out $OUT/shards/s\$i.pkl > $RQ/logs/inf_${DS}_${VAR}_s\$i.log 2>&1 &
    i=\$((i+1))
  done; wait"
$PYC - <<PY
import pickle, glob
m = {}
for f in sorted(glob.glob("$OUT/shards/s*.pkl")): m.update(pickle.load(open(f, "rb")))
recs = pickle.load(open("$DD/$DS/residual_users.pkl", "rb"))["test"]
assert set(m) == {r["uid"] for r in recs}, ("missing users", len(m), len(recs))
pickle.dump(m, open("$OUT/residual_cache_test.pkl", "wb")); print("merged", len(m))
PY
[ $? -eq 0 ] || { echo "MERGE FAILED $DS/$VAR"; exit 1; }
AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1 AGENTR_FROZEN_SUFFIX=$FS AGENTR_USER_MEMORY=$MEM AGENTR_DATA_DIR=$DD \
  $PYC $RQ/scripts/rq2_fulltest.py --ds $DS --variant ${VAR}_inf --mode residual --tag $TT --prior $PR --alpha $AL \
  --ckpt_step "$(basename $CK) (Full ckpt, no retrain)" --priorB_json $RES/data_planner_modern_mem/$DS/priorB.json
echo "[$(date +%T)] DONE $DS/$VAR"
