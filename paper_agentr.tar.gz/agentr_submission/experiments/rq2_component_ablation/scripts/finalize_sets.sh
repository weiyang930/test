#!/usr/bin/env bash
# merge shards + full-pop eval for every (ds, setting) cell whose shards are all present
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker; RQ=$REPO/experiments/rq2_component_ablation
PYC=${PY_RECBOLE:-python}
declare -A NSH=([Software_10_80_r811]=16 [MicroLens_dg]=8 [KuaiRec_dg]=2 [Industrial_10_80_r811]=1)
declare -A PR=([Software_10_80_r811]=A [MicroLens_dg]=A [KuaiRec_dg]=B [Industrial_10_80_r811]=A)
declare -A AL=([Software_10_80_r811]=0.75 [MicroLens_dg]=0.75 [KuaiRec_dg]=1.0 [Industrial_10_80_r811]=0.2)
for ds in Software_10_80_r811 Industrial_10_80_r811 KuaiRec_dg MicroLens_dg; do
 for st in baseonly planner_b20 uniform_b20 valstr_b20 shuffle_b20 planner_b30 uniform_b30 valstr_b30 shuffle_b30; do
  [ -e $RQ/artifacts/$ds/set_${st}.json ] && continue
  D=$RES/artifacts/rq2set_${st}_${ds}_TEST; DD=$RES/data_rq2set_modern_mem/$st
  [ $(ls $D/shards/s*.pkl 2>/dev/null | wc -l) -eq ${NSH[$ds]} ] || continue
  $PYC - <<PY || continue
import pickle, glob
m = {}
for f in glob.glob("$D/shards/s*.pkl"): m.update(pickle.load(open(f, "rb")))
recs = pickle.load(open("$DD/$ds/residual_users.pkl", "rb"))["test"]
assert set(m) == {r["uid"] for r in recs}
pickle.dump(m, open("$D/residual_cache_test.pkl", "wb"))
PY
  AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1 AGENTR_FROZEN_SUFFIX=_${st}_modern AGENTR_USER_MEMORY=llm AGENTR_DATA_DIR=$DD \
   $PYC $RQ/scripts/rq2_fulltest.py --ds $ds --variant set_${st} --mode residual --tag rq2set_${st}_${ds}_TEST \
   --prior ${PR[$ds]} --alpha ${AL[$ds]} --ckpt_step "Full ckpt, no retrain" \
   --priorB_json $RES/data_planner_modern_mem/$ds/priorB.json | head -1
 done
done
