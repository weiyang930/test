#!/usr/bin/env python3
"""RQ2 DEV selection (DEV only, TEST untouched). Same rule as each dataset's Full Agent-R run:
  residual variants: argmax DEV N@10 over (ckpt, prior in {A,B}, alpha>0 in rr.ALPHA_GRID);
    Software/Industrial (exp16 rule) additionally apply grid-edge->1-SE: if the argmax alpha == 1.0,
    take the smallest alpha (same ckpt/prior) with mean >= best - SE (SE = std(per-user N@10)/sqrt(n)).
    KuaiRec/MicroLens Full runs used plain argmax (stage8_10_one_ds.sh) -> plain argmax here too.
  noprior: argmax DEV N@10 over ckpt (no prior/alpha exist).
Prints the selection on the last line: "<step> <prior> <alpha>" and writes artifacts/select_<tag>.json."""
import argparse, json, pickle, sys
from pathlib import Path
import numpy as np
RES = Path("/path/to/agentr/pipeline/residual_ranker")
RQ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr   # noqa: E402
import gw_eval as ge     # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--ds", required=True); ap.add_argument("--tag", required=True)
ap.add_argument("--var", required=True); ap.add_argument("--steps", nargs="+", type=int, required=True)
a = ap.parse_args()
EDGE_1SE = a.ds in ("Software_10_80_r811", "Industrial_10_80_r811")
rows = []
if a.var == "noprior":
    for st in a.steps:
        e = json.load(open(RES / "artifacts" / f"{a.tag}_s{st}_dev" / "eval.json"))
        rows.append({"step": st, "prior": "none", "alpha": 0.0, "N@10": e["selected"]["agg"]["NDCG@10"]})
    best = max(rows, key=lambda r: r["N@10"]); sel = dict(best, rule="argmax ckpt")
else:
    _, _, _, split = rr.load_substrate(a.ds)
    gt = split["gt"]
    dev = pickle.load(open(rr.DATA_DIR / a.ds / "residual_users.pkl", "rb"))["dev"]
    uids = [r["uid"] for r in dev]
    pB = rr.PriorB(json.load(open(rr.DATA_DIR / a.ds / "priorB.json"))["score_by_rank"])
    per = {}
    for st in a.steps:
        res = pickle.load(open(RES / "artifacts" / f"{a.tag}_s{st}_dev" / "residual_cache_dev.pkl", "rb"))
        for pr in ("A", "B"):
            for al in rr.ALPHA_GRID:
                if al == 0: continue
                fin = {}
                for rec in dev:
                    pv = (np.array([rr.prior_A(k) for k in rec["base_rank"]], float) if pr == "A"
                          else np.array([pB.score(k) for k in rec["base_rank"]], float))
                    fin[rec["uid"]] = rr.fused_order(rec["cand_ids"], pv, res[rec["uid"]], al)
                pum = ge.per_user_metrics(uids, fin, gt)
                v = np.array([pum[u]["NDCG@10"] for u in uids])
                per[(st, pr, al)] = v
                rows.append({"step": st, "prior": pr, "alpha": al, "N@10": float(v.mean())})
    best = max(rows, key=lambda r: r["N@10"]); sel = dict(best, rule="argmax")
    if EDGE_1SE and best["alpha"] == 1.0:
        v = per[(best["step"], best["prior"], 1.0)]; se = v.std() / np.sqrt(len(v)); thr = v.mean() - se
        for al in [x for x in rr.ALPHA_GRID if x > 0]:
            if per[(best["step"], best["prior"], al)].mean() >= thr:
                sel = {"step": best["step"], "prior": best["prior"], "alpha": al,
                       "N@10": float(per[(best["step"], best["prior"], al)].mean()),
                       "rule": f"grid-edge->1-SE (SE={se:.4f}, thr={thr:.4f})"}
                break
json.dump({"ds": a.ds, "tag": a.tag, "var": a.var, "selected": sel, "argmax": best, "sweep": rows},
          open(RQ / "artifacts" / f"select_{a.tag}.json", "w"), indent=1)
print(json.dumps(sel))
print(sel["step"], sel["prior"], sel["alpha"])
