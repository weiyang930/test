#!/usr/bin/env python3
"""Collect RQ2 artifacts -> markdown tables (main table + Δ-vs-Full with paired-bootstrap sig)."""
import json
from pathlib import Path
A = Path(__file__).resolve().parent.parent / "artifacts"
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"),
      ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
import sys
# main protocol = inference-time removal (no retraining); "retrain" = supplementary retrained w/o Prior Anchor
VAR = [("full", "Full Agent-R"), ("nomem_inf", "w/o Memory"), ("noplan_inf", "w/o Planning"),
       ("norank", "w/o Ranking"), ("noprior_inf", "w/o Prior Anchor")]
if len(sys.argv) > 1 and sys.argv[1] == "retrain":
    VAR = [("full", "Full Agent-R"), ("noprior", "w/o Prior Anchor (retrained direct scorer)")]
K = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
main = ["| Dataset | Variant | N@10 | R@10 | N@50 | R@50 |", "|---|---|---:|---:|---:|---:|"]
delta = ["| Dataset | Variant | ΔN@10 | ΔR@10 | ΔN@50 | ΔR@50 | ckpt / prior / α |", "|---|---|---:|---:|---:|---:|---|"]
for ds, dn in DS:
    for v, vn in VAR:
        f = A / ds / f"{v}.json"
        if not f.exists():
            main.append(f"| {dn} | {vn} | – | – | – | – |"); continue
        d = json.load(open(f)); r = d["fulltest"]
        main.append(f"| {dn} | {vn} | " + " | ".join(f"{r[k]:.4f}" for k in K) + " |")
        if v != "full":
            b = d.get("vs_full_agentr_bootstrap") or {}
            cells = []
            for k in K:
                if k in b:
                    x = b[k]; cells.append(f"{x['delta']:+.4f}{'*' if x['sig'] and abs(x['delta'])>1e-9 else ''}")
                else:
                    cells.append("–")
            cfg = "frozen order" if v == "norank" else f"{d.get('ckpt_step')} / {d.get('prior')} / {d.get('alpha')}"
            delta.append(f"| {dn} | {vn} | " + " | ".join(cells) + f" | {cfg} |")
print("\n".join(delta)); print(); print("\n".join(main))
