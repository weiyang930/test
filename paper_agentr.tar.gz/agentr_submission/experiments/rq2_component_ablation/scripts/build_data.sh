#!/usr/bin/env bash
# RQ2 -- build residual data for the two ablations that change the ranker INPUT (CPU only).
#   nomem : same planner_modern frozen slate + SAME splits.json, profile = deterministic user_meta
#           -> data_planner_modern_det/<ds>
#   noplan: prior_only frozen slate on the modern cache (no planner deltas; all users neutral w_bar)
#           -> promotion_ranker/artifacts/frozen_<ds>_prioronly_modern.pkl
#           -> data_prioronly_modern_mem/<ds> (LLM STM/LTM memory, fresh rankable split on this substrate)
# Usage: DS=<ds> VAR=nomem|noplan bash build_data.sh
set -uo pipefail
DS="${DS:?}"; VAR="${VAR:?}"
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker
PROM=$REPO/pipeline/candidate_adaptation
PY=${PY_RECBOLE:-python}
say () { echo "[$(date +%H:%M:%S)] [$DS/$VAR] $*"; }
export AGENTR_TOOLCACHE_SUFFIX=_modern AGENTR_LOCAL_SPLIT=1
cd $RES/scripts
if [ "$VAR" = nomem ]; then
  export AGENTR_FROZEN_SUFFIX=_planner_modern AGENTR_USER_MEMORY=det_full
  export AGENTR_DATA_DIR=$RES/data_planner_modern_det
  mkdir -p $AGENTR_DATA_DIR/$DS
  cp $RES/data_planner_modern_mem/$DS/splits.json $AGENTR_DATA_DIR/$DS/splits.json   # identical split
else
  export AGENTR_FROZEN_SUFFIX=_prioronly_modern AGENTR_USER_MEMORY=llm
  export AGENTR_DATA_DIR=$RES/data_prioronly_modern_mem
  if [ ! -e $PROM/artifacts/frozen_${DS}_prioronly_modern.pkl ]; then
    say "build prior_only frozen slate"
    ( cd $REPO && $PY $PROM/scripts/stage1_build_planner.py --dataset $DS --prior-only --frozen-suffix _prioronly_modern ) || exit 1
  fi
  say "build_splits"; $PY build_splits.py --ds $DS || exit 1
fi
say "build_residual_data"; $PY build_residual_data.py --ds $DS > /dev/null || exit 1
say "build_test_data";     $PY build_test_data.py --ds $DS > /dev/null || exit 1
touch $AGENTR_DATA_DIR/$DS/READY
say "DONE -> $AGENTR_DATA_DIR/$DS"
