#!/usr/bin/env python3
"""RQ3 two-panel figure: (a) mean Jaccard@50 heatmap, (b) standalone strength vs base-miss recovery.
Values are the RQ3 results (develop/2026-09-25_06_RQ3_route_complementarity.md), not modified."""
import numpy as np, pandas as pd, matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from pathlib import Path
OUT = Path(__file__).resolve().parent

mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman", "Times"],
                     "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8, "xtick.labelsize": 7.5,
                     "ytick.labelsize": 7.5, "legend.fontsize": 7, "axes.linewidth": 0.6,
                     "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 400})
INK, INK2 = "#1a1a1a", "#555555"
ROUTES = ["NCL", "DiffRec", "Qwen3-Emb", "Mem-Ret", "Popularity"]
# validated all-pairs: worst CVD dE 10.7, worst normal-vision dE 18.7 (OKLab x100)
COLOR = {"NCL": "#6fa8dc", "DiffRec": "#1a3d73", "Qwen3-Emb": "#a445b2", "Mem-Ret": "#e8702a", "Popularity": "#6b6b6b"}
MARK = {"Software": "o", "Industrial": "s", "KuaiRec": "^", "MicroLens": "D"}

J = np.array([[1.0000, 0.2834, 0.0176, 0.0186, 0.1434],
              [0.2834, 1.0000, 0.0156, 0.0182, 0.1488],
              [0.0176, 0.0156, 1.0000, 0.0739, 0.0039],
              [0.0186, 0.0182, 0.0739, 1.0000, 0.0040],
              [0.1434, 0.1488, 0.0039, 0.0040, 1.0000]])
jdf = pd.DataFrame(J, index=ROUTES, columns=ROUTES)
S = pd.DataFrame([
    ("Software", "NCL", 0.2865, 8.47), ("Software", "Qwen3-Emb", 0.0439, 3.68), ("Software", "Mem-Ret", 0.0732, 5.17), ("Software", "Popularity", 0.1818, 6.99),
    ("Industrial", "DiffRec", 0.0726, 2.73), ("Industrial", "Qwen3-Emb", 0.0365, 2.80), ("Industrial", "Mem-Ret", 0.0395, 3.03), ("Industrial", "Popularity", 0.0509, 1.90),
    ("KuaiRec", "NCL", 0.1185, 3.54), ("KuaiRec", "Qwen3-Emb", 0.0178, 1.90), ("KuaiRec", "Mem-Ret", 0.0093, 1.03), ("KuaiRec", "Popularity", 0.1032, 3.65),
    ("MicroLens", "DiffRec", 0.0704, 2.81), ("MicroLens", "Qwen3-Emb", 0.0569, 3.72), ("MicroLens", "Mem-Ret", 0.0442, 2.74), ("MicroLens", "Popularity", 0.0088, 0.20)],
    columns=["dataset", "route", "standalone_recall@50", "base_miss_recovery@50_pct"])
jdf.to_csv(OUT / "rq3_overlap_mean.csv", float_format="%.4f"); S.to_csv(OUT / "rq3_strength_complementarity.csv", index=False)

fig = plt.figure(figsize=(7.0, 3.3))
gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.25], wspace=0.42, left=0.115, right=0.985, bottom=0.17, top=0.90)

# ---------------- (a) heatmap
ax = fig.add_subplot(gs[0])
off = np.ma.masked_array(J, mask=np.eye(5, dtype=bool))
im = ax.imshow(off, cmap="Blues", vmin=0, vmax=0.30)
ax.imshow(np.ma.masked_array(np.ones_like(J), mask=~np.eye(5, dtype=bool)), cmap=mpl.colors.ListedColormap(["#efefed"]))
for i in range(5):
    for j in range(5):
        v = J[i, j]
        if i == j:
            ax.text(j, i, "—", ha="center", va="center", color="#9a9a9a", fontsize=7.5)
        else:
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=7.5,
                    color="white" if v > 0.18 else INK, fontweight="bold" if {i, j} == {0, 1} else "normal")
ax.set_xticks(range(5)); ax.set_yticks(range(5))
ax.set_xticklabels(["NCL", "DiffRec", "Qwen3\nEmb", "Mem\nRet", "Pop."])
ax.set_yticklabels(ROUTES)
ax.tick_params(length=0)
for s in ax.spines.values(): s.set_visible(False)
ax.set_xticks(np.arange(-.5, 5), minor=True); ax.set_yticks(np.arange(-.5, 5), minor=True)
ax.grid(which="minor", color="white", linewidth=1.5); ax.tick_params(which="minor", length=0)
ax.set_title("Cross-Route Overlap", pad=6)
cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
cb.set_label("Mean Jaccard@50", fontsize=7.5); cb.ax.tick_params(labelsize=6.5, length=2); cb.outline.set_linewidth(0.4)
ax.text(0.5, -0.215, "Mean off-diagonal overlap = 0.073", ha="center", va="top", fontsize=7, color=INK2,
        transform=ax.transAxes)
fig.text(0.008, 0.93, "(a)", fontsize=10, fontweight="bold")

# ---------------- (b) scatter
bx = fig.add_subplot(gs[1])
for _, r in S.iterrows():
    bx.scatter(r["standalone_recall@50"], r["base_miss_recovery@50_pct"], s=34, marker=MARK[r["dataset"]],
               color=COLOR[r["route"]], edgecolor="#222222", linewidth=0.5, zorder=3)
bx.set_xlim(-0.005, 0.305); bx.set_ylim(0, 9.6)
bx.set_xlabel("Standalone Recall@50"); bx.set_ylabel("Base-Miss Recovery@50 (%)")
bx.set_title("Strength vs. Complementarity", pad=6)
for s in ("top", "right"): bx.spines[s].set_visible(False)
bx.grid(axis="y", color="#e6e6e3", linewidth=0.5, zorder=0); bx.tick_params(length=2.5)
ann = dict(fontsize=6.8, color=INK, arrowprops=dict(arrowstyle="-", color="#777777", lw=0.6, shrinkA=1, shrinkB=3))
bx.annotate("Strong + complementary", (0.2865, 8.47), xytext=(0.170, 8.95), ha="left", va="center", **ann)
bx.annotate("Weak, yet complementary\n(Industrial Mem-Ret)", (0.0395, 3.03), xytext=(0.060, 0.85), ha="left", va="center", **ann)
bx.annotate("Highest recovery on MicroLens\n(Qwen3-Emb)", (0.0569, 3.72), xytext=(0.062, 6.25), ha="left", va="center", **ann)
bx.text(0.012, 9.05, "Standalone strength ≠\ncomplementary utility", fontsize=7.2, style="italic", color=INK2, va="top")
lr = bx.legend(handles=[Patch(facecolor=COLOR[r], edgecolor="#222222", linewidth=0.5, label=r) for r in ROUTES],
               title="Route", loc="lower right", bbox_to_anchor=(1.02, 0.0), frameon=False, handlelength=1.0,
               handleheight=0.9, borderaxespad=0.2, title_fontsize=7, labelspacing=0.25)
bx.add_artist(lr)
bx.legend(handles=[Line2D([], [], marker=MARK[d], linestyle="", color="white", markeredgecolor="#222222",
                          markeredgewidth=0.7, markersize=5, label=d) for d in MARK],
          title="Dataset", loc="upper right", bbox_to_anchor=(1.02, 0.64), frameon=False, handletextpad=0.3,
          borderaxespad=0.2, title_fontsize=7, labelspacing=0.25)
bx.text(-0.16, 1.06, "(b)", transform=bx.transAxes, fontsize=10, fontweight="bold")

fig.savefig(OUT / "rq3_route_complementarity.pdf")
fig.savefig(OUT / "rq3_route_complementarity.png", dpi=400)
print(jdf.round(4)); print(S)
