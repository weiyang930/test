#!/usr/bin/env python3
"""RQ3 main-paper figure (v2 redesign; same data as v1 / develop/2026-09-25_06_RQ3_route_complementarity.md).
(a) Route Diversity: lower-triangle mean Jaccard@50 over 4 datasets, routes tagged by type.
(b) Complementary Utility Beyond Standalone Strength: non-base route x dataset points."""
import json
import numpy as np, pandas as pd, matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from pathlib import Path
OUT = Path(__file__).resolve().parent

mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman", "Times"],
                     "mathtext.fontset": "dejavuserif", "font.size": 8, "axes.titlesize": 9,
                     "axes.labelsize": 8, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
                     "legend.fontsize": 7, "axes.linewidth": 0.6, "pdf.fonttype": 42, "ps.fonttype": 42})
INK, INK2, INK3 = "#1a1a1a", "#555555", "#8a8a8a"
ROUTES = ["NCL", "DiffRec", "Qwen3-Emb", "Mem-Ret", "Popularity"]
TYPE = {"NCL": "collaborative", "DiffRec": "collaborative", "Qwen3-Emb": "semantic", "Mem-Ret": "memory", "Popularity": "prior"}
# validated all-pairs (Machado sev-1 CVD, OKLab x100): worst CVD dE 10.7, worst normal dE 18.7
COLOR = {"NCL": "#6fa8dc", "DiffRec": "#1a3d73", "Qwen3-Emb": "#a445b2", "Mem-Ret": "#e8702a", "Popularity": "#6b6b6b"}
ABBR = {"collaborative": "CF", "semantic": "sem.", "memory": "mem.", "prior": "prior"}
MARK = {"Software": "o", "Industrial": "s", "KuaiRec": "^", "MicroLens": "D"}

J = pd.read_csv(OUT / "rq3_overlap_mean.csv", index_col=0).loc[ROUTES, ROUTES].values
S = pd.read_csv(OUT / "rq3_strength_complementarity.csv")
off = J[~np.eye(5, dtype=bool)].mean()
WEAK_X = 0.08
weak = S[(S["standalone_recall@50"] < WEAK_X) & (S["base_miss_recovery@50_pct"] >= 2.5)]

fig = plt.figure(figsize=(7.8, 2.75))
gs = fig.add_gridspec(1, 3, width_ratios=[0.95, 1.45, 0.62], wspace=0.28,
                      left=0.095, right=0.995, bottom=0.17, top=0.86)

# ================= (a) Route Diversity: lower triangle =================
ax = fig.add_subplot(gs[0])
rows, cols = ROUTES[1:], ROUTES[:-1]              # 4x4 lower triangle incl. all 10 pairs
cmap = mpl.colormaps["Blues"]; norm = mpl.colors.Normalize(0, 0.30)
for i, r in enumerate(rows):
    for j, c in enumerate(cols):
        if j > i:
            continue
        v = J[ROUTES.index(r), ROUTES.index(c)]
        ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor=cmap(norm(v)), edgecolor="white", lw=1.6))
        ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=7.5,
                color="white" if v > 0.18 else INK, fontweight="bold" if (r, c) == ("DiffRec", "NCL") else "normal")
ax.set_xlim(-0.5, 3.5); ax.set_ylim(3.5, -0.5); ax.set_aspect("equal")
ax.set_xticks(range(4)); ax.set_yticks(range(4))
ax.set_xticklabels([c.replace("Qwen3-Emb", "Qwen3-\nEmb").replace("Mem-Ret", "Mem-\nRet") for c in cols])
ax.set_yticklabels(rows)
ax.tick_params(length=0, pad=2)
for s in ax.spines.values(): s.set_visible(False)
# route-type tags (muted), under x labels / left of y labels
# summary in the empty upper-right triangle
ax.text(3.45, -0.38, f"mean off-diagonal\noverlap = {off:.3f}", ha="right", va="top", fontsize=7.2, color=INK2)
cax = ax.inset_axes([0.58, 0.64, 0.38, 0.045])
cb = fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation="horizontal", ticks=[0, 0.15, 0.30])
cb.ax.tick_params(labelsize=6, length=1.5, pad=1); cb.outline.set_linewidth(0.3)
cb.set_label("Jaccard@50", fontsize=6.3, labelpad=1.5)
ax.set_title("Route Diversity", pad=5, loc="left", x=-0.02)

# ================= (b) Complementary utility =================
bx = fig.add_subplot(gs[1])
bx.add_patch(Rectangle((0, 2.5), WEAK_X, 3.1, facecolor="#f3efe6", edgecolor="none", zorder=0))
bx.text(0.001, 6.15, f"weak standalone (R@50 < {WEAK_X:.2f}),\nyet {weak['base_miss_recovery@50_pct'].min():.1f}–"
        f"{weak['base_miss_recovery@50_pct'].max():.1f}% recovery ({len(weak)} routes)",
        fontsize=6.5, color=INK2, va="bottom", ha="left", zorder=1)
for _, r in S.iterrows():
    bx.scatter(r["standalone_recall@50"], r["base_miss_recovery@50_pct"], s=30, marker=MARK[r["dataset"]],
               color=COLOR[r["route"]], edgecolor="#222222", linewidth=0.45, zorder=3)
bx.set_xlim(-0.004, 0.30); bx.set_ylim(0, 9.3)
bx.set_xlabel("Standalone Recall@50"); bx.set_ylabel("Base-miss recovery@50 (%)")
bx.set_title("Complementary Utility Beyond Standalone Strength", pad=5, loc="left", x=-0.02)
for s in ("top", "right"): bx.spines[s].set_visible(False)
bx.grid(axis="y", color="#ebebe8", linewidth=0.5, zorder=0); bx.tick_params(length=2.5)
ann = dict(fontsize=6.6, color=INK, arrowprops=dict(arrowstyle="-", color="#888888", lw=0.55, shrinkA=1, shrinkB=3))
bx.annotate("Software NCL: strong\nand complementary", (0.2865, 8.47), xytext=(0.262, 8.47), ha="right", va="center", **ann)
bx.annotate("Industrial: Mem-Ret recovers more\nthan stronger DiffRec (3.03% vs 2.73%)", (0.0395, 3.03),
            xytext=(0.115, 1.35), ha="left", va="center", **ann)

# ================= legends in a narrow right column =================
lx = fig.add_subplot(gs[2]); lx.axis("off")
lr = lx.legend(handles=[Line2D([], [], marker="o", ls="", markersize=5.2, markerfacecolor=COLOR[r],
                               markeredgecolor="#222222", markeredgewidth=0.45,
                               label=f"{r} ({ABBR[TYPE[r]]})") for r in ROUTES],
               title="Route (type)", loc="upper left", bbox_to_anchor=(-0.08, 1.02), frameon=False, handletextpad=0.2,
               labelspacing=0.35, title_fontsize=7, alignment="left", borderaxespad=0)
lx.add_artist(lr)
lx.legend(handles=[Line2D([], [], marker=MARK[d], ls="", markersize=4.6, markerfacecolor="white",
                          markeredgecolor="#222222", markeredgewidth=0.6, label=d) for d in MARK],
          title="Dataset", loc="lower left", bbox_to_anchor=(-0.08, 0.02), frameon=False, handletextpad=0.2,
          labelspacing=0.35, title_fontsize=7, alignment="left", borderaxespad=0)

fig.text(0.008, 0.93, "(a)", fontsize=9.5, fontweight="bold")
fig.text(0.375, 0.93, "(b)", fontsize=9.5, fontweight="bold")
fig.savefig(OUT / "rq3_route_complementarity_v2.pdf")
fig.savefig(OUT / "rq3_route_complementarity_v2.png", dpi=400)

# exact plotted data, easy to read
md = ["# RQ3 figure v2 — exact plotted data", "", "Source: develop/2026-09-25_06_RQ3_route_complementarity.md (unchanged).", "",
      "## (a) Mean Jaccard@50 over Software/Industrial/KuaiRec/MicroLens (lower triangle plotted)", "",
      "| | " + " | ".join(ROUTES) + " |", "|---|" + "---:|" * 5]
md += [f"| {a} | " + " | ".join(f"{J[i, j]:.4f}" for j in range(5)) + " |" for i, a in enumerate(ROUTES)]
md += ["", f"Mean off-diagonal overlap = {off:.4f}", "", "Route types: " + ", ".join(f"{k}={v}" for k, v in TYPE.items()), "",
       "## (b) Non-base route × dataset", "", "| Dataset | Route | Standalone R@50 | Base-miss recovery@50 (%) | In shaded 'weak' region |",
       "|---|---|---:|---:|---|"]
md += [f"| {r.dataset} | {r.route} | {r['standalone_recall@50']:.4f} | {r['base_miss_recovery@50_pct']:.2f} | "
       f"{'yes' if i in weak.index else ''} |" for i, r in S.iterrows()]
md += ["", f"Shaded region: standalone R@50 < {WEAK_X} and recovery >= 2.5% ({len(weak)} points).",
       f"Pooled Spearman rho(strength, recovery) = {S['standalone_recall@50'].corr(S['base_miss_recovery@50_pct'], method='spearman'):.3f} "
       "(strength correlates with, but does not fully determine, complementary utility)."]
(OUT / "rq3_figure_v2_data.md").write_text("\n".join(md) + "\n")
json.dump({"jaccard50_mean": {a: dict(zip(ROUTES, map(float, J[i]))) for i, a in enumerate(ROUTES)},
           "mean_offdiag": float(off), "route_type": TYPE, "scatter": S.to_dict(orient="records"),
           "weak_region": {"x_max": WEAK_X, "y_min": 2.5, "n": int(len(weak))}},
          open(OUT / "rq3_figure_v2_data.json", "w"), indent=1)
print("ok")
