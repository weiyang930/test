#!/usr/bin/env python3
"""RQ3 heterogeneous route complementarity (saved route caches only, no retraining).
Population = full official TEST population (frozen_planner_modern[test] keys), GT = label==2 set,
exactly as the canonical full-pop evaluator. Routes: NCL, DiffRec, Qwen3-Embedding (semantic_qwen3)
from route_cache toolcaches (depth 200); Mem-Ret, Popularity from precomputed_tool_cache_modern (depth 100).
Definitions (k in {10,50,100}):
  Jaccard@k(u)      = |A_k ∩ B_k| / |A_k ∪ B_k|, averaged over users where both routes return a list.
  base-miss pair    = (u, i), i in GT(u), i not in base top-k.  recovered by r: i in r top-k.
  exclusive         = recovered by r and by no other non-base route.
  base-miss user    = user with GT, no GT item in base top-k. conditional recovery = frac of those with
                      >=1 GT item in r top-k.
  Recall@k          = |GT ∩ list_k| / |GT| (gw.all_metrics def), union = all 5 routes' top-k.
"""
import json, os, pickle, sys
from pathlib import Path
import numpy as np
os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern")
REPO = Path("/path/to/agentr")
RES = REPO / "pipeline/residual_ranker"; MRB = REPO / "pipeline/route_bank"
OUT = REPO / "experiments/rq3_route_complementarity/artifacts"
sys.path.insert(0, str(RES / "scripts"))
import rr_common as rr                                  # noqa: E402
import gw_eval as ge                                    # noqa: E402
from build_test_data import load_test_targets           # noqa: E402
allm = ge.gw.all_metrics
ROUTES = ["NCL", "DiffRec", "Qwen3-Emb", "Mem-Ret", "Popularity"]
KS = [10, 50, 100]
res = {}
for ds in sys.argv[1:]:
    pop = list(rr.gw.load_frozen(ds)["frozen"]["test"].keys())
    tmap = load_test_targets(ds)
    base = {"NCL": "NCL", "DiffRec": "DiffRec"}[json.load(open(MRB / f"artifacts/base_selection_{ds}.json"))["base_route_model"]]
    rc = MRB / "artifacts/route_cache" / ds
    L = {}
    for name, tc in [("NCL", "ncl"), ("DiffRec", "diffrec"), ("Qwen3-Emb", "semantic_qwen3")]:
        us = pickle.load(open(rc / f"toolcache_{tc}.pkl", "rb"))["users"]
        L[name] = {u: [str(x) for x in us[u]["items"]] for u in pop if u in us}
    mc = pickle.load(open(REPO / f"outputs/results/{ds}/precomputed_tool_cache_modern.pkl", "rb"))
    L["Mem-Ret"] = {u: [str(x) for x in mc["mem"].get(u, [])] for u in pop if mc["mem"].get(u)}
    L["Popularity"] = {u: [str(x) for x in mc["popularity"].get(u, [])] for u in pop if mc["popularity"].get(u)}
    depth = {r: int(np.median([len(v) for v in L[r].values()])) for r in ROUTES}
    gtu = [u for u in pop if tmap.get(u)]
    R = {"dataset": ds, "base_route": base, "n_pop": len(pop), "n_users_with_gt": len(gtu),
         "n_gt_pairs": int(sum(len(tmap[u]) for u in gtu)), "list_depth_median": depth}
    # standalone (full pop, missing -> 0)
    zero = {"NDCG@10": 0.0, "Recall@10": 0.0, "NDCG@50": 0.0, "Recall@50": 0.0}
    st = {}
    for r in ROUTES:
        pum = [allm(L[r].get(u, [])[:50], tmap.get(u, [])) if L[r].get(u) else zero for u in pop]
        st[r] = {k: float(np.mean([p[k] for p in pum])) for k in zero}
        st[r]["Recall@100"] = float(np.mean([len(set(L[r].get(u, [])[:100]) & set(tmap[u])) / len(tmap[u]) for u in gtu])) * len(gtu) / len(pop)
    R["standalone"] = st
    # Jaccard
    J = {}
    for k in KS:
        M = {}
        for a in ROUTES:
            M[a] = {}
            for b in ROUTES:
                vals = []
                for u in pop:
                    la, lb = L[a].get(u), L[b].get(u)
                    if la and lb:
                        A, B = set(la[:k]), set(lb[:k]); vals.append(len(A & B) / len(A | B))
                M[a][b] = float(np.mean(vals)) if vals else None
        J[k] = M
    R["jaccard"] = J
    # base-miss recovery + union
    rec, uni = {}, {}
    for k in (50, 100):
        topk = {r: {u: set(L[r].get(u, [])[:k]) for u in gtu} for r in ROUTES}
        miss_pairs = [(u, i) for u in gtu for i in tmap[u] if i not in topk[base][u]]
        miss_users = [u for u in gtu if not (topk[base][u] & set(tmap[u]))]
        others = [r for r in ROUTES if r != base]
        d = {"n_base_miss_pairs": len(miss_pairs), "n_base_miss_users": len(miss_users), "routes": {}}
        for r in others:
            hit = [(u, i) for (u, i) in miss_pairs if i in topk[r][u]]
            excl = [(u, i) for (u, i) in hit if not any(i in topk[o][u] for o in others if o != r)]
            cu = sum(1 for u in miss_users if topk[r][u] & set(tmap[u]))
            d["routes"][r] = {"recovered_pairs": len(hit), "recovered_pct_of_base_miss": 100 * len(hit) / max(len(miss_pairs), 1),
                              "exclusive_pairs": len(excl), "exclusive_pct_of_base_miss": 100 * len(excl) / max(len(miss_pairs), 1),
                              "conditional_user_recovery": cu / max(len(miss_users), 1), "recovered_users": cu}
        allrec = [(u, i) for (u, i) in miss_pairs if any(i in topk[o][u] for o in others)]
        d["any_other_route_pairs"] = len(allrec); d["any_other_route_pct"] = 100 * len(allrec) / max(len(miss_pairs), 1)
        rec[k] = d
        bR = float(np.sum([len(topk[base][u] & set(tmap[u])) / len(tmap[u]) for u in gtu]) / len(pop))
        U = {u: set().union(*[topk[r][u] for r in ROUTES]) for u in gtu}
        uR = float(np.sum([len(U[u] & set(tmap[u])) / len(tmap[u]) for u in gtu]) / len(pop))
        uni[k] = {"base_recall": bR, "union_recall": uR, "abs_gain": uR - bR, "rel_gain_pct": 100 * (uR - bR) / bR,
                  "mean_union_size": float(np.mean([len(U[u]) for u in gtu]))}
    R["base_miss_recovery"] = rec; R["oracle_union"] = uni
    res[ds] = R
    json.dump(R, open(OUT / f"rq3_{ds}.json", "w"), indent=1)
    print(ds, "base", base, "depth", depth, "union", {k: round(v["union_recall"], 4) for k, v in uni.items()}, flush=True)
