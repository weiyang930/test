import json, csv
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"), ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
R = ["NCL", "DiffRec", "Qwen3-Emb", "Mem-Ret", "Popularity"]
D = {ds: json.load(open(f"artifacts/rq3_{ds}.json")) for ds, _ in DS}
o = []
def P(s=""): o.append(s)
def mj(d, r):  # mean Jaccard@50 with the other 4 routes
    return sum(d["jaccard"]["50"][r][x] for x in R if x != r) / 4
# 1 standalone
P("### A. Standalone route strength (full test population)\n")
P("| Dataset | Route | Role | N@10 | R@10 | N@50 | R@50 | R@100 |"); P("|---|---|---|---:|---:|---:|---:|---:|")
for ds, dn in DS:
    d = D[ds]
    for r in R:
        s = d["standalone"][r]; role = "**base**" if r == d["base_route"] else "aux"
        P(f"| {dn} | {r} | {role} | {s['NDCG@10']:.4f} | {s['Recall@10']:.4f} | {s['NDCG@50']:.4f} | {s['Recall@50']:.4f} | {s['Recall@100']:.4f} |")
# 2 jaccard
P("\n### B. Pairwise per-user Jaccard overlap (5×5, mean over users where both routes return a list)\n")
for ds, dn in DS:
    for k in ("10", "50", "100"):
        P(f"**{dn} — Jaccard@{k}**\n"); P("| | " + " | ".join(R) + " |"); P("|---|" + "---:|" * 5)
        for a in R:
            P(f"| {a} | " + " | ".join(f"{D[ds]['jaccard'][k][a][b]:.4f}" for b in R) + " |")
        P()
# 3 recovery
P("### C. Base-miss recovery (relevant (user,item) pairs missed by the base route's top-k)\n")
P("Recovered = in that route's top-k; Exclusive = recovered by that route and by no other non-base route; "
  "Cond. user recovery = fraction of base-miss users (no GT in base top-k) with ≥1 GT item in the route's top-k.\n")
P("| Dataset | k | Route | #base-miss pairs | Recovered | Recovered % | Exclusive | Exclusive % | #base-miss users | Cond. user recovery |")
P("|---|---:|---|---:|---:|---:|---:|---:|---:|---:|")
for ds, dn in DS:
    for k in ("50", "100"):
        rk = D[ds]["base_miss_recovery"][k]
        for r, v in rk["routes"].items():
            P(f"| {dn} | {k} | {r} | {rk['n_base_miss_pairs']} | {v['recovered_pairs']} | {v['recovered_pct_of_base_miss']:.2f} | {v['exclusive_pairs']} | {v['exclusive_pct_of_base_miss']:.2f} | {rk['n_base_miss_users']} | {v['conditional_user_recovery']:.4f} |")
        P(f"| {dn} | {k} | *any non-base route* | {rk['n_base_miss_pairs']} | {rk['any_other_route_pairs']} | {rk['any_other_route_pct']:.2f} | – | – | {rk['n_base_miss_users']} | – |")
# 4 union
P("\n### D. Oracle union coverage (union of all 5 routes' top-k vs base top-k)\n")
P("| Dataset | Base | Base R@50 | Union R@50 | Abs gain @50 | Rel gain @50 | Mean union size @50 | Base R@100 | Union R@100 | Abs gain @100 | Rel gain @100 | Mean union size @100 |")
P("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
for ds, dn in DS:
    u = D[ds]["oracle_union"]; a, b = u["50"], u["100"]
    P(f"| {dn} | {D[ds]['base_route']} | {a['base_recall']:.4f} | {a['union_recall']:.4f} | +{a['abs_gain']:.4f} | +{a['rel_gain_pct']:.1f}% | {a['mean_union_size']:.1f} | {b['base_recall']:.4f} | {b['union_recall']:.4f} | +{b['abs_gain']:.4f} | +{b['rel_gain_pct']:.1f}% | {b['mean_union_size']:.1f} |")
# 5 plot table
P("\n### E. Plot-ready: strength vs complementarity (one row per dataset × route)\n")
P("Recovery columns are empty for the base route itself (it cannot recover its own misses).\n")
hdr = ["dataset", "route", "is_base", "standalone_N@10", "standalone_R@50", "base_miss_recovered@50", "base_miss_recovered_pct@50",
       "exclusive_recovered@50", "exclusive_pct@50", "cond_user_recovery@50", "mean_jaccard@50_vs_others"]
P("| " + " | ".join(hdr) + " |"); P("|" + "---|" * len(hdr))
rows = []
for ds, dn in DS:
    d = D[ds]
    for r in R:
        s = d["standalone"][r]; ib = r == d["base_route"]
        v = None if ib else d["base_miss_recovery"]["50"]["routes"][r]
        row = [dn, r, int(ib), f"{s['NDCG@10']:.4f}", f"{s['Recall@50']:.4f}",
               "" if ib else v["recovered_pairs"], "" if ib else f"{v['recovered_pct_of_base_miss']:.2f}",
               "" if ib else v["exclusive_pairs"], "" if ib else f"{v['exclusive_pct_of_base_miss']:.2f}",
               "" if ib else f"{v['conditional_user_recovery']:.4f}", f"{mj(d, r):.4f}"]
        rows.append(row); P("| " + " | ".join(str(x) for x in row) + " |")
with open("artifacts/rq3_plot_table.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(hdr); w.writerows(rows)
meta = "\n".join(f"- {dn}: base={D[ds]['base_route']}, test population={D[ds]['n_pop']}, users with GT={D[ds]['n_users_with_gt']}, GT pairs={D[ds]['n_gt_pairs']}" for ds, dn in DS)
open("artifacts/tables.md", "w").write(meta + "\n\n" + "\n".join(o))
print(meta); print("\n".join(o))
