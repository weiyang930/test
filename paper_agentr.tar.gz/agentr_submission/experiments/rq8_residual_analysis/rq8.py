#!/usr/bin/env python3
"""RQ8 residual ranking behavior (Full Agent-R TEST residuals, rankable users; no model runs).
p = pinned prior (A|B) over frozen base rank, r = saved residual, s = p + alpha*r, final order = rr.fused_order."""
import json, os, pickle, sys
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"
PROM = REPO / "pipeline/candidate_adaptation/artifacts"; H = Path(__file__).resolve().parent
os.environ["AGENTR_DATA_DIR"] = str(RES / "data_planner_modern_mem"); os.environ["AGENTR_FROZEN_SUFFIX"] = "_planner_modern"
sys.path.insert(0, str(RES / "scripts")); import rr_common as rr   # noqa
STRATA = [("1-5", 1, 5), ("6-10", 6, 10), ("11-20", 11, 20), ("21-35", 21, 35), ("36-50", 36, 50)]
ROUTES = ["semantic", "mem", "collab", "popularity"]
out = {}
for ds in ["Software_10_80_r811", "Industrial_10_80_r811", "KuaiRec_dg", "MicroLens_dg"]:
    ft = json.load(open(REPO / f"pipeline/route_bank/artifacts/fulltest_{ds}.json"))
    pr, al = ft["prior"], ft["alpha"]
    recs = pickle.load(open(RES / "data_planner_modern_mem" / ds / "residual_users.pkl", "rb"))["test"]
    res = pickle.load(open(RES / "artifacts" / ft["tag"] / "residual_cache_test.pkl", "rb"))
    pB = rr.PriorB(json.load(open(RES / "data_planner_modern_mem" / ds / "priorB.json"))["score_by_rank"])
    frozen = pickle.load(open(PROM / f"frozen_{ds}_planner_modern.pkl", "rb"))["frozen"]["test"]
    P, Rr, S, C, disp, br, prov, isgt, sup, routes_l, iscore = [], [], [], [], [], [], [], [], [], [], []
    rho_pr, rho_ps, rho_rs = [], [], []
    gt_before, gt_after = [], []; enter10 = exit10 = 0
    for rec in recs:
        n = len(rec["cand_ids"])
        p = np.array([rr.prior_A(k) if pr == "A" else pB.score(k) for k in rec["base_rank"]])
        r = np.asarray(res[rec["uid"]], float); s = p + al * r
        fin = rr.fused_order(rec["cand_ids"], p, r, al)
        pos = {iid: i + 1 for i, iid in enumerate(fin)}
        after = np.array([pos[i] for i in rec["cand_ids"]]); before = np.asarray(rec["base_rank"])
        rmap = {x["item_id"]: x for x in frozen[rec["uid"]]["resc_info"]}
        P.append(p); Rr.append(r); S.append(s); C.append(r - r.mean()); disp.append(before - after); br.append(before)
        prov.append(np.array([i in rmap for i in rec["cand_ids"]]))
        isgt.append(np.array([i == rec["gt_id"] for i in rec["cand_ids"]]))
        sup.append(np.array([rmap[i]["cross_path_support"] if i in rmap else np.nan for i in rec["cand_ids"]], float))
        iscore.append(np.array([rmap[i]["intervention_score"] if i in rmap else np.nan for i in rec["cand_ids"]], float))
        routes_l.append([rmap[i]["source_routes"] if i in rmap else [] for i in rec["cand_ids"]])
        rho_pr.append(spearmanr(p, r)[0]); rho_ps.append(spearmanr(p, s)[0]); rho_rs.append(spearmanr(r, s)[0])
        g = rec["gt_idx"]; gb, ga = g + 1, pos[rec["gt_id"]]; gt_before.append(gb); gt_after.append(ga)
        top_b = set(rec["cand_ids"][:10]); top_a = set(fin[:10]); enter10 += len(top_a - top_b); exit10 += len(top_b - top_a)
    P, Rr, S, C, D, BR, PV, GT, SUP, IS = map(np.concatenate, (P, Rr, S, C, disp, br, prov, isgt, sup, iscore))
    RT = [x for u in routes_l for x in u]
    gb, ga = np.array(gt_before), np.array(gt_after); gch = gb - ga; nU = len(recs)
    A = np.abs(Rr)
    d = {"n_users": nU, "n_candidates": int(len(Rr)), "prior": pr, "alpha": al,
         "residual": {"abs_r_mean": float(A.mean()), "abs_r_std": float(A.std()), "r_mean": float(Rr.mean()), "r_std": float(Rr.std()),
                      "raw_frac_pos": float((Rr > 0).mean()), "raw_frac_neg": float((Rr < 0).mean()),
                      "centered_frac_pos": float((C > 0).mean()), "centered_frac_neg": float((C < 0).mean()),
                      "centered_skewness": float(((C - C.mean()) ** 3).mean() / C.std() ** 3),
                      "abs_alpha_r_mean": float(al * A.mean()), "prior_adjacent_gap_mean": float(np.mean(np.abs(np.diff(np.sort(P.reshape(nU, 50), 1), axis=1)))),
                      "within_user_r_std_mean": float(np.mean([np.std(x) for x in np.split(Rr, nU)]))},
         "movement_all_candidates": {"mean_abs_displacement": float(np.abs(D).mean()), "median_abs_displacement": float(np.median(np.abs(D))),
                                     "frac_promoted": float((D > 0).mean()), "frac_demoted": float((D < 0).mean()), "frac_unchanged": float((D == 0).mean()),
                                     "top10_entries_per_user": enter10 / nU, "top10_exits_per_user": exit10 / nU},
         "movement_gt": {"frac_promoted": float((gch > 0).mean()), "frac_demoted": float((gch < 0).mean()), "frac_unchanged": float((gch == 0).mean()),
                         "mean_rank_change(+=up)": float(gch.mean()), "median_rank_change": float(np.median(gch)),
                         "gt_rank_before_mean": float(gb.mean()), "gt_rank_after_mean": float(ga.mean()),
                         "gt_entered_top10": int(((gb > 10) & (ga <= 10)).sum()), "gt_exited_top10": int(((gb <= 10) & (ga > 10)).sum())},
         "spearman": {"per_user_mean": {"p_r": float(np.nanmean(rho_pr)), "p_s": float(np.nanmean(rho_ps)), "r_s": float(np.nanmean(rho_rs))},
                      "pooled": {"p_r": float(spearmanr(P, Rr)[0]), "p_s": float(spearmanr(P, S)[0]), "r_s": float(spearmanr(Rr, S)[0])}}}
    # promoted vs demoted items: per-user top / bottom decile (5 of 50) of centered residual
    Cu = C.reshape(nU, 50); order = np.argsort(-Cu, axis=1)
    top = np.zeros_like(Cu, bool); bot = np.zeros_like(Cu, bool)
    for u in range(nU):
        top[u, order[u, :5]] = True; bot[u, order[u, -5:]] = True
    top, bot = top.ravel(), bot.ravel()
    def prof(m):
        rsc = m & PV
        rc = {r_: float(np.mean([r_ in RT[i] for i in np.where(rsc)[0]])) if rsc.any() else None for r_ in ROUTES}
        return {"n": int(m.sum()), "base_rank_mean": float(BR[m].mean()),
                **{f"base_rank_{a}": float(((BR[m] >= lo) & (BR[m] <= hi)).mean()) for a, lo, hi in STRATA},
                "frac_rescued": float(PV[m].mean()), "gt_hit_rate": float(GT[m].mean()),
                "rescued_support_mean": float(np.nanmean(SUP[rsc])) if rsc.any() else None, "rescued_route_membership": rc,
                "mean_displacement": float(D[m].mean())}
    d["promoted_vs_demoted_deciles"] = {"top_decile(most promoted)": prof(top), "bottom_decile(most demoted)": prof(bot), "all": prof(np.ones_like(top))}
    d["residual_by_stratum"] = {a: {"n": int(((BR >= lo) & (BR <= hi)).sum()), "centered_r_mean": float(C[(BR >= lo) & (BR <= hi)].mean()),
                                    "gt_rate": float(GT[(BR >= lo) & (BR <= hi)].mean()), "mean_displacement": float(D[(BR >= lo) & (BR <= hi)].mean())} for a, lo, hi in STRATA}
    d["residual_by_provenance"] = {k: {"n": int(m.sum()), "centered_r_mean": float(C[m].mean()), "gt_rate": float(GT[m].mean()),
                                       "mean_displacement": float(D[m].mean()), "frac_in_top_decile": float(top[m].mean())}
                                   for k, m in (("base", ~PV), ("rescued", PV))}
    d["gt_vs_nongt"] = {"gt_centered_r_mean": float(C[GT].mean()), "nongt_centered_r_mean": float(C[~GT].mean()),
                        "gt_in_top_decile": float(top[GT].mean()), "gt_in_bottom_decile": float(bot[GT].mean())}
    ok = PV & ~np.isnan(IS)
    d["rescued_intervention_score_corr"] = {"n": int(ok.sum()), "spearman_centered_r_vs_intervention": float(spearmanr(C[ok], IS[ok])[0]) if ok.sum() > 2 else None,
                                            "spearman_centered_r_vs_support": float(spearmanr(C[ok], SUP[ok])[0]) if ok.sum() > 2 else None}
    out[ds] = d
    print(ds, "done", nU)
# consistency with RQ4
rq4 = json.load(open(REPO / "experiments/rq4_agency_allocation/artifacts/decomposition_stats.json"))
for ds, d in out.items():
    assert abs(rq4[ds]["abs_r_mean"] - d["residual"]["abs_r_mean"]) < 1e-9 and abs(rq4[ds]["spearman_per_user_mean"]["p_vs_r"] - d["spearman"]["per_user_mean"]["p_r"]) < 1e-9
json.dump(out, open(H / "artifacts" / "rq8_results.json", "w"), indent=1)
print("consistent with RQ4")
