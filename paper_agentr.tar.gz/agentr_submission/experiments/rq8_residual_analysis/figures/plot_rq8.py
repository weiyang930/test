#!/usr/bin/env python3
"""RQ8 figure: (a) rho(p,r) vs rho(p,s); (b) % GT items in the per-user top residual decile vs 10% random.
Values from artifacts/rq8_summary.csv (unchanged). Colors match the RQ4 figure (ochre = residual, navy = final)."""
import csv
import numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from pathlib import Path
OUT = Path(__file__).resolve().parent
S = {r["dataset"]: r for r in csv.DictReader(open(OUT.parent / "artifacts" / "rq8_summary.csv"))}
DS = ["Software", "Industrial", "KuaiRec", "MicroLens"]
rpr = [float(S[d]["rho_pr"]) for d in DS]; rps = [float(S[d]["rho_ps"]) for d in DS]
gtd = [float(S[d]["gt_in_top_decile"]) * 100 for d in DS]
with open(OUT / "rq8_residual_behavior_plot_data.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["dataset", "rho_p_r", "rho_p_s", "gt_in_top_residual_decile_pct", "random_baseline_pct"])
    for d, a, b, g in zip(DS, rpr, rps, gtd): w.writerow([d, f"{a:.3f}", f"{b:.3f}", f"{g:.1f}", "10.0"])
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "mathtext.fontset": "dejavuserif",
                     "font.size": 8, "axes.linewidth": 0.6, "xtick.labelsize": 7.5, "ytick.labelsize": 7.2,
                     "axes.labelsize": 8, "legend.fontsize": 7.2, "pdf.fonttype": 42, "ps.fonttype": 42})
INK = "#000000"; OCHRE, NAVY = "#e6b04c", "#284c78"   # validated pair (RQ4): CVD dE >= 15
EDGE = "#5a5f66"
fig = plt.figure(figsize=(7.2, 2.65))
gs = fig.add_gridspec(1, 2, width_ratios=[1.25, 1.0], wspace=0.28, left=0.075, right=0.99, top=0.83, bottom=0.12)
x = np.arange(4); w = 0.36
# (a)
ax = fig.add_subplot(gs[0])
ax.bar(x - w / 2, rpr, w, color=OCHRE, edgecolor=EDGE, linewidth=0.4, label=r"$\rho(p, r)$  prior vs. residual")
ax.bar(x + w / 2, rps, w, color=NAVY, edgecolor=EDGE, linewidth=0.4, label=r"$\rho(p, s)$  prior vs. final score")
for xi, a, b in zip(x, rpr, rps):
    ax.text(xi - w / 2, a + (0.03 if a >= 0 else -0.03), f"{a:.2f}", ha="center", va="bottom" if a >= 0 else "top", fontsize=6.6, color=INK)
    ax.text(xi + w / 2, b + 0.03, f"{b:.2f}", ha="center", va="bottom", fontsize=6.6, color=INK)
ax.axhline(0, color=INK, lw=0.7)
ax.set_ylim(-0.45, 1.1); ax.set_xticks(x); ax.set_xticklabels(DS); ax.tick_params(axis="x", length=0)
ax.set_ylabel("Spearman correlation")
for s in ("top", "right", "bottom"): ax.spines[s].set_visible(False)
ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, frameon=False, handlelength=1.0, columnspacing=1.2)
ax.text(3.45, 1.02, "Final ranking\nremains anchored", ha="right", va="top", fontsize=6.8, style="italic", color=INK)
ax.text(3.45, -0.33, "Residual ≈ new signal", ha="right", va="top", fontsize=6.8, style="italic", color=INK)
# (b)
bx = fig.add_subplot(gs[1])
bx.bar(x, gtd, 0.58, color=OCHRE, edgecolor=EDGE, linewidth=0.4)
for xi, g in zip(x, gtd):
    bx.text(xi, g + 1.2, f"{g:.1f}%", ha="center", va="bottom", fontsize=7, color=INK)
bx.axhline(10, color=INK, lw=0.8, ls=(0, (4, 3)), zorder=3)
from matplotlib.lines import Line2D
bx.legend(handles=[Line2D([], [], color=INK, lw=0.8, ls=(0, (4, 3)))], labels=["random baseline (10%)"],
          loc="lower right", bbox_to_anchor=(1.02, 1.0), frameon=False, handlelength=2.0)
bx.text(-0.35, 55.5, "Correction, not replacement", ha="left", va="top", fontsize=6.5, fontweight="bold", color=INK)
bx.set_ylim(0, 72); bx.set_xticks(x); bx.set_xticklabels(DS); bx.tick_params(axis="x", length=0)
bx.set_ylabel("GT in top residual decile (%)")
for s in ("top", "right"): bx.spines[s].set_visible(False)
bx.text(-0.35, 68, "Residual promotes relevant\npreference signals", ha="left", va="top", fontsize=6.8, style="italic", color=INK)
fig.text(0.008, 0.975, "(a)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.038, 0.975, "Residual Adds New Signals While Preserving the Prior", fontsize=8.6, va="top")
fig.text(0.575, 0.975, "(b)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.605, 0.975, "Residual Aligns with Relevant Items", fontsize=8.6, va="top")
fig.savefig(OUT / "rq8_residual_behavior.pdf"); fig.savefig(OUT / "rq8_residual_behavior.png", dpi=400)
print("ok")
