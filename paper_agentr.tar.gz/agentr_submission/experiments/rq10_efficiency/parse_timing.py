#!/usr/bin/env python3
"""RQ10: parse existing logs for throughput/latency (no new runs)."""
import glob, json, os, re, datetime as dt
from pathlib import Path
A = Path("/path/to/agentr/analysis"); OUT = A / "rq10_efficiency/artifacts"
def txt(f): return open(f, errors="ignore").read().replace("\r", "\n")
T = {}
# ---- planner: vLLM "Processed prompts: 100% N/N [mm:ss" per shard (8 shards, 1 GPU each)
P6 = {"Software_10_80_r811", "KuaiRec_dg"}   # exp16/expansion node assignment (P6=B200); others on P5=H100 (see logs/launchers)
for ds in ["Software_10_80_r811", "Industrial_10_80_r811", "KuaiRec_dg", "MicroLens_dg"]:
    s = txt(A / f"route_bank/logs/planner_{ds}_modern.log")
    rows = set(re.findall(r"Processed prompts: 100%\|[^|]*\| (\d+)/\d+ \[(\d+):(\d+)<[^,]*, [\d.]+it/s, est. speed input: ([\d.]+) toks/s, output: ([\d.]+) toks/s", s))
    sh = [(int(n), int(m) * 60 + int(sec), float(i), float(o)) for n, m, sec, i, o in rows]
    ts = re.findall(r"INFO (\d\d-\d\d \d\d:\d\d:\d\d)", s); te = re.findall(r"\[W9(\d\d) (\d\d:\d\d:\d\d)", s)
    n = sum(x[0] for x in sh[:8]) if len(sh) >= 8 else None
    T.setdefault(ds, {})["planner"] = {
        "shards_parsed": len(sh), "gen_seconds_per_shard_max": max(x[1] for x in sh), "prompts_per_shard": sorted({x[0] for x in sh}),
        "est_input_tok_per_prompt_from_log": sum(x[2] * x[1] for x in sh) / sum(x[0] for x in sh),
        "est_output_tok_per_prompt_from_log": sum(x[3] * x[1] for x in sh) / sum(x[0] for x in sh),
        "per_gpu_prompts_per_s": sum(x[0] for x in sh) / sum(x[1] for x in sh),
        "wall_first_INFO": ts[0] if ts else None, "wall_last_exit": te[-1][1] if te else None}
# ---- memory: launched 01:07:19 (launch_all_memory_expansion.out), end = log mtime; TP=2 on 2xH100 each
for ds in ["KuaiRec_dg", "MicroLens_dg"]:
    f = A / f"route_bank/logs/mem_{ds}.log"
    end = dt.datetime.fromtimestamp(os.path.getmtime(f), dt.timezone.utc)
    start = end.replace(hour=1, minute=7, second=19)
    users = int(re.findall(r"processed=(\d+)/(\d+)", txt(f))[-1][1])
    T[ds]["memory"] = {"users": users, "wall_seconds_incl_model_load": (end - start).total_seconds(), "gpus": "2xH100 (TP=2)",
                       "users_per_s_wall": users / (end - start).total_seconds()}
# ---- ranker: 'residuals i/n (Xs)' progress (last line) from TEST scoring logs
def rres(f):
    m = re.findall(r"residuals (\d+)/(\d+) \((\d+)s\)", txt(f))
    if not m: return None
    i, n, s = map(int, m[-1]); return {"prompts_done": i, "prompts_total": n, "seconds": s, "prompts_per_s": i / max(s, 1)}
L = A / "residual_ranker/logs"; M = A / "route_bank/logs"; Q = A / "rq2_component_ablation/logs"
cands = {"Software_10_80_r811": [(L / "eval_res_software_modern_TEST.log", "1xB200 (P6)")],
         "Industrial_10_80_r811": [(L / "eval_res_industrial_modern_TEST.log", "1xH100 (P5)")],
         "KuaiRec_dg": [(M / "s9_test_KuaiRec_dg.log", "1xB200 (P6)")], "MicroLens_dg": [(M / "s9_test_MicroLens_dg.log", "1 GPU (node not recorded)")]}
for ds, lst in cands.items():
    out = []
    for f, g in lst:
        if f.exists():
            r = rres(f)
            if r: out.append({"log": f.name, "gpu": g, **r})
    # sharded Full-ckpt inference (RQ2 inference-only cells): per-shard rate
    for f in sorted(glob.glob(str(Q / f"inf_{ds}_*_s*.log"))):
        r = rres(f)
        if r: out.append({"log": Path(f).name, "gpu": "1xB200 (P6)" if ds == "Software_10_80_r811" else "1xH100 (P5)", **r})
    T[ds]["ranker"] = out
# ---- Direct LLM fusion strict (RQ4): chunk completion stamps per worker (20k prompts/chunk, 1 output token)
R4 = A / "rq4_agency_allocation/logs"; gaps = []
for f in glob.glob(str(R4 / "score_*.log")):
    st = re.findall(r"\[(\d\d:\d\d:\d\d)\] (\S+) chunk (\d+) n=(\d+)", txt(f))
    for (t0, *_), (t1, d1, c1, n1) in zip(st, st[1:]):
        dtm = (dt.datetime.strptime(t1, "%H:%M:%S") - dt.datetime.strptime(t0, "%H:%M:%S")).total_seconds()
        if dtm > 0: gaps.append((int(n1), dtm, "B200" if ("132-139" in f or "129-223" in f) else "H100"))
T["direct_fusion_strict_chunks"] = {g: {"n_chunk_pairs": sum(1 for x in gaps if x[2] == g), "prompts_per_s_per_gpu": sum(x[0] for x in gaps if x[2] == g) / max(1, sum(x[1] for x in gaps if x[2] == g))} for g in ("B200", "H100")}
# ---- Direct LLM fusion listwise (_04): vLLM 100% lines per shard
for ds in ["Software_10_80_r811", "Industrial_10_80_r811", "KuaiRec_dg", "MicroLens_dg"]:
    sh = []
    for f in glob.glob(str(M / f"llm_fusion/{ds}_shard*.log")):
        rows = set(re.findall(r"Processed prompts: 100%\|[^|]*\| (\d+)/\d+ \[(\d+):(\d+)<[^,]*, [\d.]+it/s, est. speed input: ([\d.]+) toks/s, output: ([\d.]+) toks/s", txt(f)))
        rr = [(int(n), int(m) * 60 + int(sec), float(i), float(o)) for n, m, sec, i, o in rows]
        if rr: sh.append(max(rr, key=lambda x: x[1]))          # one final row per shard log
    if sh:
        T[ds]["direct_fusion_listwise"] = {"shards": len(sh), "prompts": sum(x[0] for x in sh), "gen_seconds_sum": sum(x[1] for x in sh),
                                           "per_gpu_prompts_per_s": sum(x[0] for x in sh) / sum(x[1] for x in sh),
                                           "est_input_tok_per_prompt": sum(x[2] * x[1] for x in sh) / sum(x[0] for x in sh),
                                           "est_output_tok_per_prompt": sum(x[3] * x[1] for x in sh) / sum(x[0] for x in sh)}
json.dump(T, open(OUT / "timing.json", "w"), indent=1)
print(json.dumps(T, indent=1)[:6000])
