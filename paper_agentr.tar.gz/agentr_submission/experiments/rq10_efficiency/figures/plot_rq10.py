#!/usr/bin/env python3
"""RQ10 figure: (a) GPU-s/user per component (offline hatched; memory 'n/m' where no timing logs survive;
GPU type labelled), (b) LLM invocations per user (Agent-R stacked: memory 1 + planner 1 offline + ranker 50 forwards).
Values from artifacts/rq10_per_user_cost.csv (unchanged)."""
import csv, re
import numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Patch
from pathlib import Path
OUT = Path(__file__).resolve().parent
rows = list(csv.DictReader(open(OUT.parent / "artifacts" / "rq10_per_user_cost.csv")))
C = {(r["dataset"], r["component"].split(" (")[0]): r for r in rows}
DS = ["Software", "Industrial", "KuaiRec", "MicroLens"]
num = lambda s: float(re.match(r"[\d.]+", s).group()) if re.match(r"[\d.]+", s) else None
gpu = {d: re.search(r"\((B200|H100)\)", C[(d, "Ranking Agent")]["gpu_s_per_user"]).group(1) for d in DS}
mem = {d: num(C[(d, "Memory Agent")]["gpu_s_per_user"]) for d in DS}
pla = {d: num(C[(d, "Planning Agent")]["gpu_s_per_user"]) for d in DS}
ran = {d: num(C[(d, "Ranking Agent")]["gpu_s_per_user"]) for d in DS}
dlf = {d: float(next(r for r in rows if r["dataset"] == d and r["component"].startswith("Direct LLM Fusion (strict"))["llm_calls_per_user"]) for d in DS}
with open(OUT / "rq10_efficiency_plot_data.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["panel", "dataset", "memory_gpu_s (offline)", "planning_gpu_s (offline)", "ranking_gpu_s (online)", "ranking_gpu",
                "classical_llm_calls", "direct_llm_fusion_strict_calls", "agentr_memory_calls", "agentr_planner_calls", "agentr_ranker_forwards"])
    for d in DS:
        w.writerow(["a+b", d, "not measured" if mem[d] is None else mem[d], pla[d], ran[d], gpu[d], 0, dlf[d], 1, 1, 50])
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "font.size": 7.8,
                     "axes.linewidth": 0.6, "xtick.labelsize": 7.3, "ytick.labelsize": 7, "legend.fontsize": 6.9,
                     "pdf.fonttype": 42, "ps.fonttype": 42, "hatch.linewidth": 0.6})
INK = "#000000"; MEM, PLA, RAN, DLF = "#8fbbe3", "#8a63c2", "#1f3b63", "#c0765f"   # validated all-pairs CVD dE >= 18.4
EDGE = "#3a3f46"
fig = plt.figure(figsize=(7.4, 2.75))
gs = fig.add_gridspec(1, 2, width_ratios=[1.45, 1.0], wspace=0.26, left=0.07, right=0.99, top=0.80, bottom=0.17)
# (a)
ax = fig.add_subplot(gs[0]); x = np.arange(4); w = 0.26
for i, (vals, col, hat) in enumerate(((mem, MEM, "////"), (pla, PLA, "////"), (ran, RAN, None))):
    for xi, d in zip(x, DS):
        v = vals[d]; xx = xi + (i - 1) * w
        if v is None:
            ax.text(xx, 0.008, "n/m", ha="center", va="bottom", fontsize=6.2, color=INK, rotation=90); continue
        ax.bar(xx, v, w, color=col, edgecolor=EDGE, linewidth=0.4, hatch=hat)
        ax.text(xx, v + 0.008, f"{v:.3f}" if v < 0.01 else f"{v:.2f}", ha="center", va="bottom", fontsize=6.2, color=INK, rotation=90 if v < 0.01 else 0)
ax.set_xticks(x); ax.set_xticklabels([f"{d}\n({gpu[d]})" for d in DS]); ax.tick_params(axis="x", length=0)
ax.set_ylabel("GPU seconds per user"); ax.set_ylim(0, 0.54)
for s in ("top", "right"): ax.spines[s].set_visible(False)
ax.legend(handles=[Patch(facecolor=MEM, edgecolor=EDGE, hatch="////", lw=0.4), Patch(facecolor=PLA, edgecolor=EDGE, hatch="////", lw=0.4),
                   Patch(facecolor=RAN, edgecolor=EDGE, lw=0.4)],
          labels=["Memory (offline, cached)", "Planning (offline, cached)", "Ranking (online)"],
          loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, frameon=False, handlelength=1.1, columnspacing=0.9)
ax.text(-0.18, 0.535, "Ranking dominates online cost", fontsize=6.9, style="italic", va="top", color=INK)
ax.text(-0.18, 0.495, "n/m = not measured (no timing logs)", fontsize=6.0, va="top", color=INK)
# (b)
bx = fig.add_subplot(gs[1]); xb = np.arange(3); names = ["Classical\nfusion", "Direct LLM\nFusion (strict)", "Agent-R"]
lo, hi = min(dlf.values()), max(dlf.values()); mid = float(np.mean(list(dlf.values())))
bx.text(0, 1.2, "0", ha="center", va="bottom", fontsize=7, color=INK)
bx.bar(1, mid, 0.55, color=DLF, edgecolor=EDGE, linewidth=0.4)
bx.errorbar(1, mid, yerr=[[mid - lo], [hi - mid]], color=INK, lw=0.8, capsize=3)
bx.text(1, hi + 1.5, f"{lo:.0f}–{hi:.0f}\n1-token calls", ha="center", va="bottom", fontsize=6.3, color=INK)
bottom = 0
for v, col, hat, lab in ((1, MEM, "////", "memory"), (1, PLA, "////", "planner"), (50, RAN, None, "ranker")):
    bx.bar(2, v, 0.55, bottom=bottom, color=col, edgecolor=EDGE, linewidth=0.4, hatch=hat); bottom += v
bx.text(2, 26, "50\nforward\npasses", ha="center", va="center", fontsize=6.3, color="white")
bx.text(2, 53.5, "+1 memory\n+1 planner\n(offline)", ha="center", va="bottom", fontsize=6.1, color=INK)
bx.set_xticks(xb); bx.set_xticklabels(names); bx.tick_params(axis="x", length=0)
bx.set_ylabel("LLM invocations per user"); bx.set_ylim(0, 80); bx.set_xlim(-0.55, 2.55)
for s in ("top", "right"): bx.spines[s].set_visible(False)
bx.text(-0.35, 79, "Comparable LLM budget,\nallocated differently", fontsize=6.9, style="italic", va="top", color=INK)
fig.text(0.008, 0.975, "(a)", fontsize=9.5, fontweight="bold", va="top"); fig.text(0.038, 0.975, "Cost Allocation Across Components", fontsize=8.6, va="top")
fig.text(0.615, 0.975, "(b)", fontsize=9.5, fontweight="bold", va="top"); fig.text(0.645, 0.975, "LLM Reasoning Allocation", fontsize=8.6, va="top")
fig.text(0.5, 0.012, "Memory and planning are cacheable; ranking operates on a bounded 50-item candidate slate.",
         ha="center", fontsize=6.8, style="italic", color=INK)
fig.savefig(OUT / "rq10_efficiency.pdf"); fig.savefig(OUT / "rq10_efficiency.png", dpi=400)
print("ok")
