#!/usr/bin/env python3
"""RQ10: prompt/output token counts per LLM component (Qwen2.5-7B-Instruct tokenizer, CPU only; no inference).
Samples up to N users per dataset (seed 0). Chat template applied exactly as each component does."""
import json, os, pickle, random, sys
from pathlib import Path
import numpy as np
os.environ.setdefault("HF_HUB_OFFLINE", "1"); os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
REPO = Path("/path/to/agentr"); sys.path.insert(0, str(REPO)); sys.path.insert(0, str(REPO / "scripts"))
OUT = REPO / "experiments/rq10_efficiency/artifacts"
MODEL = "Qwen/Qwen2.5-7B-Instruct"
from transformers import AutoTokenizer
tok = AutoTokenizer.from_pretrained(MODEL)
N = 2000; ds = sys.argv[1]
CFG = {"Software_10_80_r811": "configs/software_10_80_r811_tool_only.yaml", "Industrial_10_80_r811": "configs/industrial_10_80_r811_tool_only.yaml",
       "KuaiRec_dg": "configs/kuairec_dg_tool_only.yaml", "MicroLens_dg": "configs/microlens_dg_tool_only.yaml"}[ds]
ntok = lambda s: len(tok(s, add_special_tokens=False)["input_ids"])
chat = lambda msgs: ntok(tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True))
stat = lambda a: {"n": int(len(a)), "mean": float(np.mean(a)), "median": float(np.median(a)), "p95": float(np.percentile(a, 95)), "max": int(np.max(a))}
R = {"dataset": ds}
rng = random.Random(0)

# ---- Memory Agent: rebuild prompts with the builder's own functions
os.chdir(REPO)
from src.common.config import load_config
from src.common.artifacts import ArtifactManager
from src.data.dataset import DatasetLoader
import build_llm_user_memory as B
from src.agents.user_memory_agent import UserMemoryLLMAgent, USER_MEMORY_SYSTEM_PROMPT
cfg = load_config(CFG)
data = DatasetLoader(cfg.dataset, ArtifactManager(project_root=B.PROJECT_ROOT, dataset_name=ds)).load()
item_meta = B.load_raw_item_meta(Path(cfg.dataset.data_dir) / ds)
hist = B.build_user_histories(data); users = sorted(hist); samp = rng.sample(users, min(N, len(users)))
mem = json.load(open(REPO / f"outputs/indexes/{ds}/user_memory_llm_agent_qwen2p5_7b_instruct.json"))["users"]
pin, pout = [], []
for u in samp:
    p = UserMemoryLLMAgent.render_prompt(u, B.build_evidence(u, hist[u], item_meta))
    pin.append(chat([{"role": "system", "content": USER_MEMORY_SYSTEM_PROMPT}, {"role": "user", "content": p["user"]}]))
    if str(u) in mem: pout.append(ntok(json.dumps(mem[str(u)], ensure_ascii=False)))
R["memory"] = {"n_users_total": len(users), "calls_per_user": 1, "prompt_tokens": stat(pin), "output_tokens_stored_json": stat(pout),
               "max_new_tokens": int(cfg.llm.max_new_tokens)}

# ---- Planning Agent: exact prompts from saved contexts
sys.path.insert(0, str(REPO / "pipeline/planning/scripts"))
import importlib.util
spec = importlib.util.spec_from_file_location("spl", REPO / "pipeline/planning/scripts/stage_planner_llm.py")
src = open(spec.origin).read(); SYS = src.split('SYS = (')[1].split('\n)\n')[0]; SYS = eval("(" + SYS + "\n)")
ctx = pickle.load(open(REPO / f"pipeline/planning/artifacts/planner_ctx_{ds}_modern.pkl", "rb"))
te = [r for r in ctx if r["split"] == "test"]; cs = rng.sample(te, min(N, len(te)))
qin = [chat([{"role": "system", "content": SYS}, {"role": "user", "content": "User coordination diagnostics:\n" + json.dumps(r["ctx"], ensure_ascii=False) + "\n\nReturn the intervention policy JSON only."}]) for r in cs]
# output: the policy JSON in the requested schema, rebuilt from parsed deltas (raw text not stored)
import glob, ast
dl = [r for f in glob.glob(str(REPO / f"pipeline/planning/artifacts/planner_delta_{ds}_modern.shard*.pkl")) for r in pickle.load(open(f, "rb"))]
ds_s = rng.sample(dl, min(N, len(dl))); qout = []
for r in ds_s:
    d = r["delta"] if isinstance(r["delta"], dict) else ast.literal_eval(r["delta"])
    qout.append(ntok(json.dumps({"source_trust": {k: d[k] for k in ["semantic", "mem", "collab", "popularity"]},
                                 "evidence_weights": {k: d[k] for k in ["cross_path_support", "user_preference_match"]}})))
R["planner"] = {"n_calls_offline_run(valid+test)": len(ctx), "n_test_users": len(te), "calls_per_user_serving": 1,
                "prompt_tokens": stat(qin), "output_tokens_policy_json": stat(qout), "max_new_tokens": 160}

# ---- Ranking Agent: 50 cross-encoder forwards/user (max_len 256 truncation), 0 generated tokens
RES = REPO / "pipeline/residual_ranker"
recs = pickle.load(open(RES / "data_planner_modern_mem" / ds / "residual_users.pkl", "rb"))["test"]
rs = rng.sample(recs, min(200, len(recs)))       # 200 users x 50 prompts = 10k prompts
rin = [min(256, chat([{"role": "user", "content": p}])) for r in rs for p in r["prompts"]]
R["ranker"] = {"n_rankable_test_users": len(recs), "forwards_per_user": 50, "prompt_tokens_per_forward(trunc256)": stat(rin),
               "prompt_tokens_per_user": float(np.mean(rin) * 50), "output_tokens": 0, "sampled_users": len(rs)}

# ---- Direct LLM Fusion (strict, RQ4): pointwise, 1 output token
df = pickle.load(open(REPO / f"experiments/rq4_agency_allocation/artifacts/df_build_{ds}.pkl", "rb"))
ps = rng.sample([p for r in df["recs"] for p in r["prompts"]], min(N, df["meta"]["n_prompts"]))
din = [chat([{"role": "user", "content": p}]) for p in ps]
R["direct_fusion_strict"] = {"calls_per_user": df["meta"]["mean_pool"], "prompt_tokens": stat(din), "output_tokens": 1,
                             "prompt_tokens_per_user": float(np.mean(din) * df["meta"]["mean_pool"])}
json.dump(R, open(OUT / f"tokens_{ds}.json", "w"), indent=1)
print(json.dumps({k: (v.get("prompt_tokens", v.get("prompt_tokens_per_forward(trunc256)", {})).get("mean") if isinstance(v, dict) else v) for k, v in R.items()}))
