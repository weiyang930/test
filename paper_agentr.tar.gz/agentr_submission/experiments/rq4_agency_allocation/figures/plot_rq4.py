#!/usr/bin/env python3
"""RQ4 figure: (a) agency allocation comparison (N@10, per-dataset small multiples, y from 0),
(b) Spearman rho(p,r) vs rho(p,s). Values from develop/2026-09-25_07_RQ4_agency_allocation.md (unchanged)."""
import json
import numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Patch
from pathlib import Path
OUT = Path(__file__).resolve().parent
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "mathtext.fontset": "dejavuserif",
                     "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8, "xtick.labelsize": 7.3, "ytick.labelsize": 6.8,
                     "legend.fontsize": 7, "axes.linewidth": 0.6, "pdf.fonttype": 42, "ps.fonttype": 42})
INK, INK2 = "#000000", "#000000"
DS = ["Software", "Industrial", "KuaiRec", "MicroLens"]
METHODS = ["Prior Only", "Direct LLM Fusion", "Residual Only", "Agent-R"]
N10 = {"Software": [0.0762, 0.0433, 0.0824, 0.0845], "Industrial": [0.0187, 0.0156, 0.0148, 0.0198],
       "KuaiRec": [0.0147, 0.0060, 0.0648, 0.0604], "MicroLens": [0.0103, 0.0127, 0.0192, 0.0176]}
RHO_PR = {"Software": 0.123, "Industrial": -0.217, "KuaiRec": -0.241, "MicroLens": -0.150}
RHO_PS = {"Software": 0.788, "Industrial": 0.946, "KuaiRec": 0.636, "MicroLens": 0.684}
# validated all-pairs: worst CVD dE 15.8 / normal 18.9 (Machado sev-1, OKLab x100)
MC = ["#e1e4e8", "#b0645a", "#e6b04c", "#284c78"]; HATCH = ["", "", "", ""]
EDGE = "#5a5f66"
C_PR, C_PS = MC[2], MC[3]   # residual <-> ochre, final score / Agent-R <-> navy
json.dump({"N@10": N10, "methods": METHODS, "rho_p_r": RHO_PR, "rho_p_s": RHO_PS}, open(OUT / "rq4_figure_data.json", "w"), indent=1)
with open(OUT / "rq4_figure_data.csv", "w") as f:
    f.write("dataset," + ",".join(f"N@10_{m.replace(' ', '_')}" for m in METHODS) + ",rho_p_r,rho_p_s\n")
    for d in DS:
        f.write(f"{d}," + ",".join(f"{v:.4f}" for v in N10[d]) + f",{RHO_PR[d]:.3f},{RHO_PS[d]:.3f}\n")

fig = plt.figure(figsize=(7.4, 2.7))
outer = fig.add_gridspec(1, 2, width_ratios=[1.95, 1.1], wspace=0.22, left=0.055, right=0.99, bottom=0.13, top=0.80)
ga = outer[0].subgridspec(1, 4, wspace=0.42)
x = np.arange(4)
for k, d in enumerate(DS):
    ax = fig.add_subplot(ga[k]); v = N10[d]
    bars = ax.bar(x, v, width=0.74, color=MC, edgecolor=EDGE, linewidth=0.4)
    for b, h in zip(bars, HATCH):
        if h: b.set_hatch(h)
    top = max(v) * 1.30
    ax.set_ylim(0, top)
    for xi, vi in zip(x, v):
        ax.text(xi, vi + top * 0.015, f"{vi:.4f}", rotation=90, ha="center", va="bottom", fontsize=5.6,
                color=INK if xi == 3 else INK2, fontweight="bold" if xi == 3 else "normal")
    ax.set_xticks([]); ax.set_title(d, pad=2)
    ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(3)); ax.tick_params(axis="y", length=2, pad=1)
    ax.yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter("%.2f"))
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    if k == 0: ax.set_ylabel("NDCG@10", labelpad=2)
    if k == 0: a0 = ax
hatch_patch = Patch(facecolor=MC[1], edgecolor=EDGE, linewidth=0.4)
fig.legend(handles=[Patch(facecolor=MC[0], edgecolor=EDGE, linewidth=0.4), hatch_patch,
                    Patch(facecolor=MC[2], edgecolor=EDGE, linewidth=0.4), Patch(facecolor=MC[3], edgecolor=EDGE, linewidth=0.4)],
           labels=["Prior Only", "Direct LLM Fusion", "Residual Only", "Agent-R (prior + residual)"],
           loc="upper left", bbox_to_anchor=(0.04, 0.945), ncol=4, frameon=False, handlelength=1.1, handletextpad=0.35, columnspacing=1.0)
fig.text(0.008, 0.995, "(a)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.040, 0.995, "Agency Allocation Comparison", fontsize=8.8, va="top")
fig.text(0.335, 0.025, "Direct LLM control is insufficient: Direct LLM Fusion is below Agent-R on all four datasets",
         fontsize=6.8, style="italic", color=INK2, va="bottom", ha="center")

# (b)
bx = fig.add_subplot(outer[1]); w = 0.36; xs = np.arange(4)
b1 = bx.bar(xs - w / 2, [RHO_PR[d] for d in DS], w, color=C_PR, edgecolor=EDGE, linewidth=0.4, label=r"$\rho(p, r)$  prior vs. residual")
b2 = bx.bar(xs + w / 2, [RHO_PS[d] for d in DS], w, color=C_PS, edgecolor=EDGE, linewidth=0.4, label=r"$\rho(p, s)$  prior vs. final score")
for xi, d in enumerate(DS):
    for off, v in ((-w / 2, RHO_PR[d]), (w / 2, RHO_PS[d])):
        bx.text(xi + off, v + (0.025 if v >= 0 else -0.025), f"{v:.2f}", ha="center", va="bottom" if v >= 0 else "top", fontsize=5.8, color=INK2)
bx.axhline(0, color="#333333", lw=0.6)
bx.set_ylim(-0.52, 1.38); bx.set_xticks(xs); bx.set_xticklabels(DS, fontsize=6.8)
bx.set_ylabel("Spearman correlation", labelpad=2); bx.tick_params(length=2)
for s in ("top", "right", "bottom"): bx.spines[s].set_visible(False)
bx.tick_params(axis="x", length=0)
bx.legend(loc="upper left", bbox_to_anchor=(0.0, 1.0), frameon=False, ncol=1, handlelength=1.0, handletextpad=0.4, labelspacing=0.2, fontsize=6.6)
bx.text(3.55, 1.02, "Final ranking\nremains anchored", ha="right", va="top", fontsize=6.4, style="italic", color=INK2)
bx.text(3.55, -0.38, "Residual introduces new preference signals", ha="right", va="top", fontsize=6.4, style="italic", color=INK2)
fig.text(0.612, 0.995, "(b)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.642, 0.995, "Residual as Correction, Not Replacement", fontsize=8.8, va="top")
fig.savefig(OUT / "rq4_agency_allocation.pdf"); fig.savefig(OUT / "rq4_agency_allocation.png", dpi=400)
print("ok")
