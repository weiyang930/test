#!/usr/bin/env bash
H=/path/to/agentr/experiments/rq4_agency_allocation
PYG=${PY_LLM:-python}
srun --overlap --jobid=$JOBID --nodelist=$NODE --nodes=1 --ntasks=1 --gres=gpu:8 --gpu-bind=none \
     --cpus-per-task=64 --time=02:00:00 --job-name=rq4df bash -c "
  export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
  cd /path/to/agentr/pipeline/residual_ranker/scripts
  for g in 0 1 2 3 4 5 6 7; do
    CUDA_VISIBLE_DEVICES=\$g TRITON_CACHE_DIR=/tmp/tr_rq4_\$g VLLM_PORT=\$((29500+g*10)) $PYG $H/direct_fusion.py score \
      Software_10_80_r811,MicroLens_dg,KuaiRec_dg,Industrial_10_80_r811 > $H/logs/score_${NODE}_g\$g.log 2>&1 &
    sleep 3
  done; wait"
