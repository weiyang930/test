#!/usr/bin/env python3
"""RQ4 Direct LLM Fusion (strict): same evidence -> direct LLM decision.
Candidates = union of the 5 routes' top-10 (<=50; no fused ordering, no prior, no planner, no rescue,
no residual). The LLM (Qwen2.5-7B-Instruct, same backbone as Agent-R, zero-shot) scores every candidate
pointwise from: user memory profile (LLM STM/LTM, same as Agent-R), item title/desc, per-route rank for all
5 routes, and route support. Score = E[digit] over the 0-9 answer-token distribution. Final list = candidates
sorted by LLM score only (ties -> item id string). Only users whose GT is in the pool are scored: every
other user scores 0 on all @k<=50 regardless of order (exact, not an approximation).
  build : python direct_fusion.py build <ds>
  score : python direct_fusion.py score <ds,...>     (queue worker; one GPU)
  eval  : python direct_fusion.py eval <ds>
"""
import json, os, pickle, sys, time
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / "pipeline/route_bank/scripts"))
os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern"); os.environ.setdefault("AGENTR_USER_MEMORY", "llm")
TOPK = 10
MODEL = "Qwen/Qwen2.5-7B-Instruct"
CHUNK = 20000   # prompts per queue task


def prompt(profile, iid, titles, rm):
    import gw_common as gwc
    ev = []; sup = 0
    for r, m, _ in rm:
        rk = m.get(iid)
        if rk is None:
            ev.append(f"{r}: not retrieved")
        else:
            ev.append(f"{r}: rank {rk}"); sup += 1
    return ("You are a recommendation expert. Five independent retrieval routes (NCL graph model, DiffRec "
            "diffusion model, Qwen3-Emb semantic embedding, Mem-Ret memory retrieval, Popularity) proposed "
            "candidate items for a user; for each route you see the rank it gave this item (lower = stronger).\n"
            f"User profile: {profile}\n"
            f"Candidate item: {gwc.item_line(iid, titles, max_desc=120)}\n"
            f"Route evidence: {'; '.join(ev)} (retrieved by {sup}/5 routes)\n"
            "How likely is this candidate to be the user's next interaction? Answer with a single digit "
            "from 0 (very unlikely) to 9 (very likely).")


def build(ds):
    import fusion_common as fc
    from build_test_data import load_test_targets
    routes = fc.load_routes(ds)
    blob = fc.rr.gw.load_frozen(ds)
    pop = list(blob["frozen"]["test"].keys()); titles = blob["titles"]; um = blob["user_meta"]
    tmap = load_test_targets(ds)
    recs = []; n_pool = []
    for u in pop:
        rm = fc.user_rankmaps(routes, u)
        cands = []
        for _, m, _ in rm:
            for it, rk in sorted(m.items(), key=lambda x: x[1]):
                if rk > TOPK: break
                if it not in cands: cands.append(it)
        n_pool.append(len(cands))
        if not (set(cands) & set(tmap.get(u, []))):
            continue
        prof = fc.rr.profile_text_for(u, um.get(u), ds)
        recs.append({"uid": u, "cands": cands, "prompts": [prompt(prof, i, titles, rm) for i in cands]})
    meta = {"ds": ds, "n_pop": len(pop), "n_scored_users": len(recs), "mean_pool": float(np.mean(n_pool)),
            "n_prompts": int(sum(len(r["cands"]) for r in recs))}
    pickle.dump({"meta": meta, "recs": recs}, open(HERE / "artifacts" / f"df_build_{ds}.pkl", "wb"))
    print(json.dumps(meta)); print(recs[0]["prompts"][0])


def score(dss):
    from vllm import LLM, SamplingParams
    llm = LLM(model=MODEL, dtype="bfloat16", max_model_len=1024, gpu_memory_utilization=0.88, enable_prefix_caching=True)
    tok = llm.get_tokenizer()
    dig = {tok.convert_tokens_to_ids(str(d)): d for d in range(10)}
    sp = SamplingParams(temperature=0.0, max_tokens=1, logprobs=20)
    tasks = []
    for ds in dss:
        b = pickle.load(open(HERE / "artifacts" / f"df_build_{ds}.pkl", "rb"))
        flat = [(r["uid"], j, p) for r in b["recs"] for j, p in enumerate(r["prompts"])]
        tasks += [(ds, i, flat[i * CHUNK:(i + 1) * CHUNK]) for i in range((len(flat) + CHUNK - 1) // CHUNK)]
    for ds, i, chunk in tasks:
        d = HERE / "shards" / ds; d.mkdir(parents=True, exist_ok=True)
        try:
            os.mkdir(d / f"claim_{i}")
        except FileExistsError:
            continue
        texts = [tok.apply_chat_template([{"role": "user", "content": p}], add_generation_prompt=True, tokenize=False)
                 for _, _, p in chunk]
        outs = llm.generate(texts, sp, use_tqdm=False)
        res = []; nfail = 0
        for (u, j, _), o in zip(chunk, outs):
            lp = o.outputs[0].logprobs[0]
            ps = {dig[t]: np.exp(v.logprob) for t, v in lp.items() if t in dig}
            if not ps:
                nfail += 1; res.append((u, j, 0.0)); continue
            z = sum(ps.values()); res.append((u, j, sum(k * v for k, v in ps.items()) / z))
        pickle.dump({"res": res, "nfail": nfail}, open(d / f"s{i}.pkl.tmp", "wb")); os.rename(d / f"s{i}.pkl.tmp", d / f"s{i}.pkl")
        print(f"[{time.strftime('%T')}] {ds} chunk {i} n={len(chunk)} digit-fail={nfail}", flush=True)
    print("WORKER EXIT", flush=True)


def evaluate(ds):
    b = pickle.load(open(HERE / "artifacts" / f"df_build_{ds}.pkl", "rb"))
    nt = (b["meta"]["n_prompts"] + CHUNK - 1) // CHUNK
    files = sorted((HERE / "shards" / ds).glob("s*.pkl"))
    assert len(files) == nt, (len(files), nt)
    sc = {}; nfail = 0
    for f in files:
        x = pickle.load(open(f, "rb")); nfail += x["nfail"]
        for u, j, s in x["res"]:
            sc[(u, j)] = s
    preds = {}
    for r in b["recs"]:
        s = [sc[(r["uid"], j)] for j in range(len(r["cands"]))]
        preds[r["uid"]] = [r["cands"][k] for k in sorted(range(len(s)), key=lambda k: (-s[k], r["cands"][k]))]
    pickle.dump({"preds": preds, "digit_fail": nfail, "meta": b["meta"]}, open(HERE / "artifacts" / f"df_preds_{ds}.pkl", "wb"))
    print(ds, "users", len(preds), "digit-fail", nfail)


if __name__ == "__main__":
    {"build": lambda: build(sys.argv[2]), "score": lambda: score(sys.argv[2].split(",")),
     "eval": lambda: evaluate(sys.argv[2])}[sys.argv[1]]()
