#!/usr/bin/env python3
"""RQ4 §4: prior/residual/final rank correlation + residual magnitude, from Full Agent-R's saved TEST
residual cache (rankable test users, i.e. GT in the frozen depth-50 slate; the only users a reorder can affect).
p = Full's pinned prior (A or B) over base rank; r = tanh(head) residual; s = p + alpha*r."""
import json, os, pickle, sys
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"
os.environ["AGENTR_DATA_DIR"] = str(RES / "data_planner_modern_mem"); os.environ["AGENTR_FROZEN_SUFFIX"] = "_planner_modern"
sys.path.insert(0, str(RES / "scripts")); import rr_common as rr   # noqa
out = {}
for ds in ["Software_10_80_r811", "Industrial_10_80_r811", "KuaiRec_dg", "MicroLens_dg"]:
    ft = json.load(open(REPO / f"pipeline/route_bank/artifacts/fulltest_{ds}.json"))
    pr, al = ft["prior"], ft["alpha"]
    recs = pickle.load(open(RES / "data_planner_modern_mem" / ds / "residual_users.pkl", "rb"))["test"]
    res = pickle.load(open(RES / "artifacts" / ft["tag"] / "residual_cache_test.pkl", "rb"))
    pB = rr.PriorB(json.load(open(RES / "data_planner_modern_mem" / ds / "priorB.json"))["score_by_rank"])
    rho_pr, rho_ps, rho_rs, P, R, S = [], [], [], [], [], []
    disp, top10_changed, gt_up, gt_down = [], 0, 0, 0
    for rec in recs:
        p = np.array([rr.prior_A(k) if pr == "A" else pB.score(k) for k in rec["base_rank"]])
        r = np.asarray(res[rec["uid"]], float); s = p + al * r
        rho_pr.append(spearmanr(p, r)[0]); rho_ps.append(spearmanr(p, s)[0]); rho_rs.append(spearmanr(r, s)[0])
        P.append(p); R.append(r); S.append(s)
        new_rank = np.empty(50, int); new_rank[np.lexsort((np.arange(50), -s))] = np.arange(50)
        disp.append(np.abs(new_rank - np.arange(50)).mean())
        top10_changed += set(np.argsort(-s, kind="stable")[:10]) != set(range(10))
        g = rec["gt_idx"]; gt_up += new_rank[g] < g; gt_down += new_rank[g] > g
    P, R, S = map(np.concatenate, (P, R, S)); n = len(recs)
    A = np.abs(R)
    out[ds] = {"n_rankable_test_users": n, "n_candidates": int(len(R)), "prior": pr, "alpha": al,
               "spearman_per_user_mean": {"p_vs_r": float(np.nanmean(rho_pr)), "p_vs_s": float(np.nanmean(rho_ps)), "r_vs_s": float(np.nanmean(rho_rs))},
               "spearman_pooled": {"p_vs_r": float(spearmanr(P, R)[0]), "p_vs_s": float(spearmanr(P, S)[0]), "r_vs_s": float(spearmanr(R, S)[0])},
               "abs_r_mean": float(A.mean()), "abs_r_std": float(A.std()), "r_mean": float(R.mean()), "r_std": float(R.std()),
               "frac_r_pos": float((R > 0).mean()), "frac_r_neg": float((R < 0).mean()),
               "abs_alpha_r_mean": float(al * A.mean()),
               "prior_adjacent_gap_mean": float(np.mean(np.abs(np.diff(np.sort(P.reshape(n, 50), 1)[:, ::-1], axis=1)))),
               "mean_abs_rank_displacement": float(np.mean(disp)), "frac_users_top10_set_changed": top10_changed / n,
               "frac_gt_moved_up": gt_up / n, "frac_gt_moved_down": gt_down / n}
    print(ds, json.dumps(out[ds]["spearman_per_user_mean"]), "|r|", round(out[ds]["abs_r_mean"], 3), "disp", round(out[ds]["mean_abs_rank_displacement"], 2))
json.dump(out, open(Path(__file__).parent / "artifacts" / "decomposition_stats.json", "w"), indent=1)
