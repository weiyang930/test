#!/usr/bin/env python3
"""RQ4 final table: all methods on the canonical full test population, paired bootstrap vs Full Agent-R."""
import json, os, pickle, sys
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"
H = Path(__file__).resolve().parent; RQ2 = REPO / "experiments/rq2_component_ablation/artifacts"
os.environ["AGENTR_FROZEN_SUFFIX"] = "_planner_modern"
sys.path.insert(0, str(RES / "scripts")); import rr_common as rr, gw_eval as ge   # noqa
from build_test_data import load_test_targets   # noqa
K = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]; zero = {k: 0.0 for k in K}
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"), ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
out = {}; main = []; delta = []
for ds, dn in DS:
    pop = list(rr.gw.load_frozen(ds)["frozen"]["test"].keys()); tmap = load_test_targets(ds)
    def from_preds(p):
        return {u: (ge.gw.all_metrics(p[u][:50], tmap.get(u, [])) if p.get(u) else zero) for u in pop}
    M = {"Prior only": pickle.load(open(RQ2 / ds / "norank_pum.pkl", "rb")),
         "Residual only": pickle.load(open(RQ2 / ds / "noprior_inf_pum.pkl", "rb")),
         "Residual only (retrained direct scorer)": pickle.load(open(RQ2 / ds / "noprior_pum.pkl", "rb")),
         "Direct LLM Fusion": from_preds(pickle.load(open(H / "artifacts" / f"df_preds_{ds}.pkl", "rb"))["preds"]),
         "Direct LLM Fusion (listwise, RRF head)": from_preds(pickle.load(open(REPO / f"pipeline/route_bank/artifacts/fusion/{ds}/preds_Direct-LLM-Fusion.pkl", "rb"))),
         "Full Agent-R": pickle.load(open(RQ2 / ds / "full_pum.pkl", "rb"))}
    full = M["Full Agent-R"]; out[ds] = {}
    for m, pum in M.items():
        agg = {k: float(np.mean([pum[u][k] for u in pop])) for k in K}
        bs = None if m == "Full Agent-R" else ge.bootstrap_cmp(pop, pum, full, metrics=K)
        out[ds][m] = {"metrics": agg, "vs_full": bs}
        main.append(f"| {dn} | {m} | " + " | ".join(f"{agg[k]:.4f}" for k in K) + " |")
        if bs:
            delta.append(f"| {dn} | {m} | " + " | ".join(f"{bs[k]['delta']:+.4f}{'*' if bs[k]['sig'] and abs(bs[k]['delta'])>1e-9 else ''}" for k in K) + " |")
json.dump(out, open(H / "artifacts" / "rq4_results.json", "w"), indent=1)
print("| Dataset | Method | N@10 | R@10 | N@50 | R@50 |\n|---|---|---:|---:|---:|---:|"); print("\n".join(main)); print()
print("| Dataset | Method | ΔN@10 | ΔR@10 | ΔN@50 | ΔR@50 |\n|---|---|---:|---:|---:|---:|"); print("\n".join(delta))
