#!/usr/bin/env python3
"""RQ6: memory contribution by user history length. Reuses RQ2 per-user metrics (full_pum / nomem_inf_pum)."""
import json, os, pickle, sys, csv
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"
RQ2 = REPO / "experiments/rq2_component_ablation/artifacts"; PROM = REPO / "pipeline/candidate_adaptation/artifacts"
H = Path(__file__).resolve().parent
sys.path.insert(0, str(RES / "scripts")); import rr_common as rr; import gw_eval as ge   # noqa
K = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"), ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
out = {}; rows = []
def is_unknown(v):
    if v is None: return True
    if isinstance(v, list): return len(v) == 0 or all(str(x).strip().lower() in ("unknown", "", "none", "n/a") for x in v)
    return str(v).strip().lower() in ("unknown", "", "none", "n/a")
for ds, dn in DS:
    F = pickle.load(open(RQ2 / ds / "full_pum.pkl", "rb")); M = pickle.load(open(RQ2 / ds / "nomem_inf_pum.pkl", "rb"))
    pop = list(F); assert set(pop) == set(M)
    blob = pickle.load(open(PROM / f"frozen_{ds}_planner_modern.pkl", "rb"))
    um = blob["user_meta"]; frozen_t = blob["frozen"]["test"]
    hl = {u: (um.get(u) or um.get(str(u)) or {}).get("history_len") for u in pop}
    miss = [u for u in pop if hl[u] is None]
    src = "user_meta.history_len"
    if miss:
        import pandas as pd
        df = pd.read_csv(REPO / "data" / ds / "interaction.csv", dtype={"userid": str, "itemid": str})
        cnt = df[df["label"] == 0].groupby("userid").size().to_dict()
        for u in miss: hl[u] = int(cnt.get(str(u), 0))
        src += f" (+{len(miss)} users from interaction.csv label==0 count)"
    rankable = set(r["uid"] for r in pickle.load(open(RES / "data_planner_modern_mem" / ds / "residual_users.pkl", "rb"))["test"])
    mem = json.load(open(REPO / f"outputs/indexes/{ds}/user_memory_llm_agent_qwen2p5_7b_instruct.json"))
    mem = mem.get("users", mem) if isinstance(mem, dict) else mem
    fields = ["short_term_intents", "long_term_categories", "long_term_brands", "stable_preferences"]
    def unk_frac(users):
        n = [sum(is_unknown((mem.get(str(u)) or {}).get(f)) for f in fields) / len(fields) for u in users]
        return float(np.mean(n))
    h = np.array([hl[u] for u in pop], float)
    q1, q2 = np.quantile(h, [1 / 3, 2 / 3])
    def bucket(x): return "short" if x <= q1 else ("medium" if x <= q2 else "long")
    B = {b: [u for u in pop if bucket(hl[u]) == b] for b in ("short", "medium", "long")}
    agg = lambda P, us: {k: float(np.mean([P[u][k] for u in us])) for k in K}
    res = {"history_len_source": src, "cuts_tertile": [float(q1), float(q2)], "n_pop": len(pop),
           "overall": {"full": agg(F, pop), "nomem": agg(M, pop), "bootstrap": ge.bootstrap_cmp(pop, F, M, metrics=K)}, "buckets": {}}
    for b, us in B.items():
        ur = [u for u in us if u in rankable]
        e = {"n": len(us), "hist_len_range": [float(min(hl[u] for u in us)), float(max(hl[u] for u in us))],
             "hist_len_median": float(np.median([hl[u] for u in us])), "n_rankable": len(ur),
             "full": agg(F, us), "nomem": agg(M, us), "bootstrap": ge.bootstrap_cmp(us, F, M, metrics=K),
             "rankable_full": agg(F, ur) if ur else None, "rankable_nomem": agg(M, ur) if ur else None,
             "rankable_bootstrap": ge.bootstrap_cmp(ur, F, M, metrics=K) if len(ur) > 1 else None,
             "llm_memory_unknown_field_frac": unk_frac(us)}
        res["buckets"][b] = e
        rows.append({"dataset": dn, "bucket": b, "n": e["n"], "hist_min": e["hist_len_range"][0], "hist_max": e["hist_len_range"][1],
                     "n_rankable": e["n_rankable"], **{f"full_{k}": round(e["full"][k], 6) for k in K},
                     **{f"nomem_{k}": round(e["nomem"][k], 6) for k in K},
                     **{f"delta_{k}": round(e["bootstrap"][k]["delta"], 6) for k in K},
                     **{f"sig_{k}": e["bootstrap"][k]["sig"] for k in K}, "llm_unknown_frac": round(e["llm_memory_unknown_field_frac"], 4)})
    out[ds] = res
    print(dn, src, "cuts", (q1, q2), {b: (len(v), res["buckets"][b]["n_rankable"], round(res["buckets"][b]["bootstrap"]["NDCG@10"]["delta"], 4), res["buckets"][b]["bootstrap"]["NDCG@10"]["sig"]) for b, v in B.items()})
json.dump(out, open(H / "rq6_results.json", "w"), indent=1)
with open(H / "rq6_buckets.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
