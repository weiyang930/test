#!/usr/bin/env python3
"""RQ6 figure: Delta N@10 (Full STM/LTM - w/o Memory) across history buckets, Software & Industrial.
Values from rq6_buckets.csv (unchanged). Filled marker = paired-bootstrap significant, hollow = not significant.
Also writes the complete all-dataset CSV for the appendix."""
import csv
import matplotlib as mpl, matplotlib.pyplot as plt
from pathlib import Path
OUT = Path(__file__).resolve().parent
rows = list(csv.DictReader(open(OUT.parent / "rq6_buckets.csv")))
with open(OUT / "rq6_memory_history_data.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Dataset", "Bucket", "History range", "Full N@10", "w/o Memory N@10", "Delta N@10", "Significant"])
    for r in rows:
        w.writerow([r["dataset"], r["bucket"].capitalize(), f"{int(float(r['hist_min']))}-{int(float(r['hist_max']))}",
                    f"{float(r['full_NDCG@10']):.4f}", f"{float(r['nomem_NDCG@10']):.4f}", f"{float(r['delta_NDCG@10']):+.4f}", r["sig_NDCG@10"]])
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "font.size": 8,
                     "axes.labelsize": 8.5, "xtick.labelsize": 8, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
                     "axes.linewidth": 0.6, "pdf.fonttype": 42, "ps.fonttype": 42})
COL = {"Software": "#284c78", "Industrial": "#c0765f"}     # navy / terracotta, validated: CVD dE 21.0, normal 28.8
B = ["short", "medium", "long"]
fig, ax = plt.subplots(figsize=(5.4, 2.45))
for ds, c in COL.items():
    rr = {r["bucket"]: r for r in rows if r["dataset"] == ds}
    y = [float(rr[b]["delta_NDCG@10"]) for b in B]; sig = [rr[b]["sig_NDCG@10"] == "True" for b in B]
    ax.plot(range(3), y, color=c, lw=1.6, zorder=2, label=ds)
    for i, (v, s) in enumerate(zip(y, sig)):
        ax.scatter(i, v, s=34, zorder=3, color=c if s else "white", edgecolor=c, linewidth=1.4)
        below = ds == "Industrial" and i != 1
        ax.text(i, v + (-0.00015 if below else 0.00013), f"+{v:.4f}", ha="center", va="top" if below else "bottom",
                fontsize=6.6, color="#000000")
ax.axhline(0, color="#000000", lw=0.7, zorder=1)
ax.set_xticks(range(3)); ax.set_xticklabels(["Short", "Medium", "Long"])
ax.set_xlim(-0.25, 2.25); ax.set_ylim(-0.0003, 0.0037)
ax.set_xlabel("User history length"); ax.set_ylabel(r"$\Delta$N@10 (Full $-$ w/o Memory)")
ax.yaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda v, _: f"{v:+.3f}" if v else "0"))
ax.yaxis.set_major_locator(mpl.ticker.MultipleLocator(0.001))
for s in ("top", "right"): ax.spines[s].set_visible(False)
ax.tick_params(length=2.5)
from matplotlib.lines import Line2D
h = [Line2D([], [], color=COL[d], lw=1.6, marker="o", markersize=5, label=d) for d in COL]
h += [Line2D([], [], lw=0, marker="o", markersize=5, color="#000000", label="significant"),
      Line2D([], [], lw=0, marker="o", markersize=5, markerfacecolor="white", markeredgecolor="#000000", label="n.s.")]
ax.legend(handles=h, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=4, frameon=False, handlelength=1.4, columnspacing=0.9, handletextpad=0.4)
ax.text(-0.2, 0.0036, "Memory provides additional contextual preference signals", fontsize=6.8, style="italic", va="top")
fig.tight_layout(pad=0.3)
fig.savefig(OUT / "rq6_memory_history.pdf"); fig.savefig(OUT / "rq6_memory_history.png", dpi=400)
print("ok")
