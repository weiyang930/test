#!/usr/bin/env python3
"""RQ7 figure: (a) policy diversity (distinct policies; entropy normalized by log2(729)),
(b) per-channel down/neutral/up shares (TEST split). Data from rq7_results.json (unchanged)."""
import csv, json, math
import numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Patch
from pathlib import Path
OUT = Path(__file__).resolve().parent
R = json.load(open(OUT.parent / "rq7_results.json"))
DS = ["Software", "Industrial", "KuaiRec", "MicroLens"]
CH = [("collab", "Collaborative"), ("semantic", "Semantic"), ("mem", "Memory"), ("popularity", "Popularity"),
      ("cross_path_support", "Cross-path support"), ("user_preference_match", "Preference match")]
T = {d: R[d]["test"] for d in DS}
with open(OUT / "rq7_planner_behavior_plot_data.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["panel", "dataset", "item", "down", "neutral", "up", "distinct_policies", "entropy_bits", "entropy_norm_log2_729", "top1_share"])
    for d in DS:
        t = T[d]
        w.writerow(["a", d, "policy", "", "", "", t["n_distinct_policies"], f"{t['policy_entropy_bits']:.3f}",
                    f"{t['policy_entropy_norm_by_log2(729)']:.3f}", f"{t['top1_share']:.4f}"])
        for k, n in CH:
            c = t["channel_dist"][k]; w.writerow(["b", d, n, f"{c['down']:.4f}", f"{c['neutral']:.4f}", f"{c['up']:.4f}", "", "", "", ""])
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "font.size": 7.5,
                     "axes.linewidth": 0.6, "pdf.fonttype": 42, "ps.fonttype": 42, "xtick.labelsize": 7, "ytick.labelsize": 7})
INK = "#000000"
DOWN, NEU, UP = "#c0765f", "#e4e6ea", "#284c78"      # diverging, validated: CVD dE 21.0, normal 28.8
BAR = "#8d96a3"                                      # neutral single color for (a): not a performance chart
fig = plt.figure(figsize=(7.4, 2.75))
outer = fig.add_gridspec(1, 2, width_ratios=[1.0, 3.1], wspace=0.62, left=0.075, right=0.982, top=0.80, bottom=0.14)
ga = outer[0].subgridspec(2, 1, hspace=0.55)
x = np.arange(4); short = ["SW", "Ind.", "Kuai.", "Micro."]
for i, (key, lab, fmt, top) in enumerate([("n_distinct_policies", "Distinct policies\n(of 729)", "{:.0f}", 125),
                                          ("policy_entropy_norm_by_log2(729)", "Norm. entropy", "{:.2f}", 0.62)]):
    ax = fig.add_subplot(ga[i]); v = [T[d][key] for d in DS]
    ax.bar(x, v, 0.62, color=BAR, edgecolor="none")
    for xi, vi in zip(x, v):
        ax.text(xi, vi + top * 0.03, fmt.format(vi), ha="center", va="bottom", fontsize=6.6, color=INK)
    ax.set_ylim(0, top); ax.set_xticks(x); ax.set_xticklabels(short if i == 1 else [])
    ax.set_ylabel(lab, fontsize=7, labelpad=2); ax.tick_params(length=2, pad=1.5)
    ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(3))
    for s in ("top", "right"): ax.spines[s].set_visible(False)
fig.text(0.008, 0.975, "(a)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.038, 0.975, "Policy Diversity", fontsize=8.6, va="top")
fig.text(0.038, 0.90, "Adaptive policies instead of fixed fusion", fontsize=6.6, style="italic", va="top")

gb = outer[1].subgridspec(1, 4, wspace=0.14)
y = np.arange(len(CH))[::-1]
for j, d in enumerate(DS):
    ax = fig.add_subplot(gb[j])
    for yi, (k, n) in zip(y, CH):
        c = T[d]["channel_dist"][k]; left = 0
        for part, col in (("down", DOWN), ("neutral", NEU), ("up", UP)):
            w_ = c[part] * 100
            ax.barh(yi, w_, left=left, height=0.72, color=col, edgecolor="white", linewidth=0.5)
            if w_ >= 18:
                ax.text(left + w_ / 2, yi, f"{w_:.0f}", ha="center", va="center", fontsize=6.2,
                        color="white" if part != "neutral" else INK)
            left += w_
    ax.set_xlim(0, 100); ax.set_ylim(-0.6, len(CH) - 0.4)
    ax.set_yticks(y); ax.set_yticklabels([n for _, n in CH] if j == 0 else [], fontsize=7)
    ax.set_xticks([0, 50, 100] if j == 3 else [0, 50]); ax.set_xticklabels(["0", "50", "100"][: 3 if j == 3 else 2], fontsize=6.5)
    if j == 0: gb_first = ax
    ax.tick_params(length=0, pad=2)
    for s in ("top", "right", "left"): ax.spines[s].set_visible(False)
    ax.set_title(d, fontsize=8, pad=3)
fig.text(0.358, 0.975, "(b)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.388, 0.975, "Evidence Channel Adjustment", fontsize=8.6, va="top")
fig.text(0.388, 0.90, "Evidence-specific coordination", fontsize=6.6, style="italic", va="top")
fig.legend(handles=[Patch(color=DOWN), Patch(color=NEU), Patch(color=UP)], labels=["down-weight (×0.5)", "neutral", "up-weight (×2)"],
           loc="upper right", bbox_to_anchor=(0.995, 0.925), ncol=3, frameon=False, fontsize=6.8, handlelength=1.0, columnspacing=1.0)
fig.text(0.72, 0.03, "% of users (TEST)", ha="center", fontsize=7.2)
fig.savefig(OUT / "rq7_planner_behavior.pdf"); fig.savefig(OUT / "rq7_planner_behavior.png", dpi=400)
print("ok")
