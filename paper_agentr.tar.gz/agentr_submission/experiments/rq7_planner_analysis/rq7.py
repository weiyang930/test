#!/usr/bin/env python3
"""RQ7 planner behavior analysis from saved planner outputs (no LLM calls)."""
import glob, json, pickle, math, csv
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
A = Path("/path/to/agentr/analysis")
P10 = A / "planning/artifacts"; PROM = A / "candidate_adaptation/artifacts"
H = Path(__file__).resolve().parent
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"), ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
CH = ["collab", "semantic", "mem", "popularity", "cross_path_support", "user_preference_match"]
LV = ["down", "neutral", "up"]
def ent(cnt):
    n = sum(cnt.values()); p = np.array([v / n for v in cnt.values()]); return float(-(p * np.log2(p)).sum())
def mi(xs, ys):
    n = len(xs); cx, cy, cxy = Counter(xs), Counter(ys), Counter(zip(xs, ys))
    return sum(v / n * math.log2((v / n) / (cx[a] / n * cy[b] / n)) for (a, b), v in cxy.items())
out = {}
for ds, dn in DS:
    bs = json.load(open(A / f"route_bank/artifacts/base_selection_{ds}.json"))
    rows = [r for f in glob.glob(str(P10 / f"planner_delta_{ds}_modern.shard*.pkl")) for r in pickle.load(open(f, "rb"))]
    ctx = {(c["split"], str(c["userid"])): c["ctx"] for c in pickle.load(open(P10 / f"planner_ctx_{ds}_modern.pkl", "rb"))}
    res = {"slot_map": {"graph(base, not planner-controlled)": bs["base_route_model"], "collab": bs["aux_collab_model"],
                        "semantic": "Qwen3-Emb", "mem": "Mem-Ret", "popularity": "Popularity"}}
    for sp in ("test", "valid"):
        R = [r for r in rows if r["split"] == sp]
        ok = [r for r in R if str(r["parse_ok"]) == "True"]
        D = [eval(r["delta"]) if isinstance(r["delta"], str) else r["delta"] for r in ok]
        pol = [tuple(d.get(c, "neutral") for c in CH) for d in D]
        pc = Counter(pol); n = len(pol)
        chan = {c: {l: sum(d.get(c, "neutral") == l for d in D) / n for l in LV} for c in CH}
        chan_ent = {c: ent(Counter(d.get(c, "neutral") for d in D)) / math.log2(3) for c in CH}
        top = pc.most_common(10)
        r_ = {"n_rows": len(R), "parse_ok_rate": len(ok) / len(R), "n_distinct_policies": len(pc), "max_possible": 3 ** 6,
              "top1_share": top[0][1] / n, "top5_share": sum(v for _, v in pc.most_common(5)) / n,
              "policy_entropy_bits": ent(pc), "policy_entropy_norm_by_log2(n_distinct)": ent(pc) / math.log2(len(pc)) if len(pc) > 1 else 0,
              "policy_entropy_norm_by_log2(729)": ent(pc) / math.log2(729),
              "all_neutral_frac": pc.get(tuple(["neutral"] * 6), 0) / n,
              "n_channels_changed_mean": float(np.mean([sum(x != "neutral" for x in p) for p in pol])),
              "channel_dist": chan, "channel_entropy_norm": chan_ent,
              "top10": [{"policy": dict(zip(CH, p)), "share": v / n, "count": v} for p, v in top]}
        if sp == "test":
            # association with user context features (tertiles)
            feats = {}
            uids = [str(r["userid"]) for r in ok]
            for fk in ("history_len", "pool_size", "cross_path_support_ge3_frac", "base_slate_category_coherence"):
                vals = np.array([ctx.get(("test", u), {}).get(fk, np.nan) for u in uids], float)
                if np.isnan(vals).all(): continue
                q = np.nanquantile(vals, [1 / 3, 2 / 3]); t = np.digitize(vals, q)
                m = mi([str(p) for p in pol], list(t))
                # shuffle baseline (finite-sample MI bias)
                rng = np.random.default_rng(0); mb = np.mean([mi([str(p) for p in pol], list(rng.permutation(t))) for _ in range(5)])
                by = {int(k): Counter([p for p, tt in zip(pol, t) if tt == k]).most_common(1)[0] for k in range(3) if any(tt == k for tt in t)}
                feats[fk] = {"tertile_cuts": q.tolist(), "MI_bits": m, "MI_shuffled_baseline_bits": float(mb),
                             "MI_over_H(policy)": m / ent(pc), "top_policy_per_tertile": {k: {"policy": dict(zip(CH, v[0])), "count": v[1]} for k, v in by.items()}}
                # per-channel 'up' rate by tertile
                feats[fk]["tertile_sizes"] = [int((t == k).sum()) for k in range(3)]
                feats[fk]["up_rate_by_tertile"] = {c: [float(np.mean([d.get(c) == "up" for d, tt in zip(D, t) if tt == k])) if (t == k).any() else None for k in range(3)] for c in CH}
            r_["context_association"] = feats
            # effect: slate items differing planner vs prior_only
            Fp = pickle.load(open(PROM / f"frozen_{ds}_planner_modern.pkl", "rb"))["frozen"]["test"]
            F0 = pickle.load(open(PROM / f"frozen_{ds}_prioronly_modern.pkl", "rb"))["frozen"]["test"]
            polmap = dict(zip(uids, pol))
            diff = {u: len(set(Fp[u]["exp10_order"][:50]) - set(F0[u]["exp10_order"][:50])) for u in Fp if u in F0}
            neu = [diff[u] for u in diff if polmap.get(u) == tuple(["neutral"] * 6)]
            non = [diff[u] for u in diff if u in polmap and polmap[u] != tuple(["neutral"] * 6)]
            nch = defaultdict(list)
            for u in diff:
                if u in polmap: nch[sum(x != "neutral" for x in polmap[u])].append(diff[u])
            r_["slate_effect_vs_prior_only"] = {"mean_items_changed_all": float(np.mean(list(diff.values()))),
                "frac_users_any_change": float(np.mean([v > 0 for v in diff.values()])),
                "mean_items_changed_all_neutral_policy": float(np.mean(neu)) if neu else None, "n_all_neutral": len(neu),
                "mean_items_changed_non_neutral_policy": float(np.mean(non)) if non else None, "n_non_neutral": len(non),
                "mean_items_changed_by_n_channels_changed": {k: [float(np.mean(v)), len(v)] for k, v in sorted(nch.items())}}
        res[sp] = r_
    out[dn] = res
    print(dn, "test distinct", res["test"]["n_distinct_policies"], "top1", round(res["test"]["top1_share"], 3), "allneutral", round(res["test"]["all_neutral_frac"], 3))
json.dump(out, open(H / "rq7_results.json", "w"), indent=1, default=str)
with open(H / "rq7_channel_distribution.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["dataset", "split", "channel", "down", "neutral", "up", "norm_entropy"])
    for dn, r in out.items():
        for sp in ("test", "valid"):
            for c in CH:
                d = r[sp]["channel_dist"][c]; w.writerow([dn, sp, c, f"{d['down']:.4f}", f"{d['neutral']:.4f}", f"{d['up']:.4f}", f"{r[sp]['channel_entropy_norm'][c]:.4f}"])
with open(H / "rq7_top_policies.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["dataset", "split", "rank"] + CH + ["share", "count"])
    for dn, r in out.items():
        for sp in ("test", "valid"):
            for i, t in enumerate(r[sp]["top10"]):
                w.writerow([dn, sp, i + 1] + [t["policy"][c] for c in CH] + [f"{t['share']:.4f}", t["count"]])
