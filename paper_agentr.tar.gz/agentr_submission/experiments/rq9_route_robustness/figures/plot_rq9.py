#!/usr/bin/env python3
"""RQ9 figure: leave-one-route-out Delta R@50 (remove route - Full Agent-R), per dataset.
Values: artifacts/rq9_final_table.csv; significance: artifacts/<ds>/rq9no<R>.json paired bootstrap vs Full.
Hatched = base route removed (the other CF model is promoted into the base slot; not a pure removal)."""
import csv, json
import numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Patch
from pathlib import Path
OUT = Path(__file__).resolve().parent; A = OUT.parent / "artifacts"
DS = [("Software", "Software_10_80_r811", "DiffRec"), ("Industrial", "Industrial_10_80_r811", "NCL"),
      ("KuaiRec", "KuaiRec_dg", "DiffRec"), ("MicroLens", "MicroLens_dg", "NCL")]
ROUTES = [("NCL", "NCL"), ("DiffRec", "DiffRec"), ("Qwen3-Emb", "Qwen3"), ("Mem-Ret", "MemRet"), ("Popularity", "Pop")]
COLOR = {"NCL": "#6fa8dc", "DiffRec": "#1a3d73", "Qwen3-Emb": "#a445b2", "Mem-Ret": "#e8702a", "Popularity": "#6b6b6b"}  # = RQ3 palette (validated)
T = {(r["dataset"], r["variant"]): r for r in csv.DictReader(open(A / "rq9_final_table.csv"))}
rows = []
for dn, dk, base in DS:
    for rn, tag in ROUTES:
        v = float(T[(dn, f"-{rn}")]["d_Recall@50"])
        sig = json.load(open(A / dk / f"rq9no{tag}.json"))["vs_full_agentr_bootstrap"]["Recall@50"]["sig"]
        rows.append({"Dataset": dn, "Route": rn, "Delta_R50": v, "significant": bool(sig) and v != 0, "base_route": rn == base})
with open(OUT / "rq9_route_importance_plot_data.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["Dataset", "Route", "Delta_R50", "significant", "base_route"]); w.writeheader()
    for r in rows: w.writerow({**r, "Delta_R50": f"{r['Delta_R50']:+.4f}"})
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "font.size": 7.5,
                     "axes.linewidth": 0.6, "xtick.labelsize": 6.6, "ytick.labelsize": 7.5, "pdf.fonttype": 42, "ps.fonttype": 42})
INK = "#000000"
fig, axes = plt.subplots(1, 4, figsize=(7.4, 2.35), gridspec_kw=dict(wspace=0.14, left=0.105, right=0.985, top=0.76, bottom=0.17))
y = np.arange(5)[::-1]
for ax, (dn, dk, base) in zip(axes, DS):
    rs = [r for r in rows if r["Dataset"] == dn]; v = np.array([r["Delta_R50"] for r in rs])
    lo = min(v.min(), 0); span = max(abs(lo), 0.004)
    for yi, r in zip(y, rs):
        ax.barh(yi, r["Delta_R50"], height=0.66, color=COLOR[r["Route"]], edgecolor="#3a3a3a", linewidth=0.4,
                hatch="////" if r["base_route"] else None, zorder=2)
        lab = f"{r['Delta_R50']:+.4f}" + ("*" if r["significant"] else "")
        x = r["Delta_R50"]
        ax.text(x - span * 0.03 if x < 0 else x + span * 0.03, yi, lab, ha="right" if x < 0 else "left", va="center", fontsize=6.1, color=INK)
    ax.axvline(0, color=INK, lw=0.7, zorder=3)
    ax.set_xlim(-span * 1.75, span * 0.85)
    ax.set_yticks(y); ax.set_yticklabels([rn for rn, _ in ROUTES] if ax is axes[0] else [])
    ax.xaxis.set_major_locator(mpl.ticker.MaxNLocator(3)); ax.tick_params(axis="y", length=0); ax.tick_params(axis="x", length=2)
    ax.xaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda t, _: "0" if t == 0 else f"{t:.3f}"))
    for s in ("top", "right", "left"): ax.spines[s].set_visible(False)
    ax.set_title(dn, fontsize=8.2, pad=3)
fig.text(0.54, 0.03, r"$\Delta$R@50 (remove route $-$ Full Agent-R)", ha="center", fontsize=7.8)
fig.text(0.105, 0.975, "Collaborative routes form the backbone; auxiliary routes provide complementary, dataset-dependent gains",
         fontsize=7.4, style="italic", va="top", color=INK)
fig.legend(handles=[Patch(facecolor="white", edgecolor="#3a3a3a", hatch="////", linewidth=0.5)],
           labels=["base route removed (other CF model promoted to base)"], loc="upper left", bbox_to_anchor=(0.10, 0.915),
           frameon=False, fontsize=6.6, handlelength=1.4)
fig.text(0.99, 0.895, "* significant (paired bootstrap)", ha="right", fontsize=6.6, va="top")
fig.savefig(OUT / "rq9_route_robustness.pdf"); fig.savefig(OUT / "rq9_route_robustness.png", dpi=400)
print("ok")
