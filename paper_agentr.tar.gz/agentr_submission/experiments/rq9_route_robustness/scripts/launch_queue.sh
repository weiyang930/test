#!/usr/bin/env bash
# JOBID NODE SETS -> 8 queue workers on one node
RQ=/path/to/agentr/experiments/rq9_route_robustness
PYG=${PY_LLM:-python}
srun --overlap --jobid=$JOBID --nodelist=$NODE --nodes=1 --ntasks=1 --gres=gpu:8 --gpu-bind=none \
     --cpus-per-task=64 --time=02:00:00 --job-name=rq9q bash -c "
  export HF_HOME=${HF_HOME:-$HOME/.cache/huggingface} HUGGINGFACE_HUB_CACHE=${HF_HOME:-$HOME/.cache/huggingface}/hub
  export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
  for g in 0 1 2 3 4 5 6 7; do
    CUDA_VISIBLE_DEVICES=\$g TRITON_CACHE_DIR=/tmp/tr_rq9q_\$g $PYG $RQ/scripts/queue_worker.py $SETS \
      > $RQ/logs/qw_${NODE}_g\$g.log 2>&1 &
  done; wait"
