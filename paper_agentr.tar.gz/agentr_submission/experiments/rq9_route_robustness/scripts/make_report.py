import json, csv
from pathlib import Path
A = Path(__file__).resolve().parent.parent / "artifacts"
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"), ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]
RN = [("NCL", "NCL", "NCL"), ("DiffRec", "DiffRec", "DiffRec"), ("Qwen3", "Qwen3-Emb", "Qwen3-Emb"), ("MemRet", "Mem-Ret", "Mem-Ret"), ("Pop", "Popularity", "Popularity")]
K = ["NDCG@10", "Recall@10", "NDCG@50", "Recall@50"]
SS = json.load(open(A / "slate_stats.json")); o = []; P = o.append; rows = []
def sg(b, k):
    x = b[k]; return f"{x['delta']:+.4f}{'*' if x['sig'] and abs(x['delta']) > 1e-9 else ''}"
P("## A-i. Oracle route-union coverage with one route removed (candidate level, no executor)\n")
P("| Dataset | all 5 R@50 | " + " | ".join(f"−{n} R@50" for _, n, _ in RN) + " | all 5 R@100 | " + " | ".join(f"−{n} R@100" for _, n, _ in RN) + " |")
P("|---|" + "---:|" * 12)
for ds, dn in DS:
    c = json.load(open(A / f"candidate_level_{ds}.json"))
    P(f"| {dn} | {c['all5']['50']:.4f} | " + " | ".join(f"{c['no_'+k]['50']:.4f}" for _, _, k in RN) + f" | {c['all5']['100']:.4f} | " + " | ".join(f"{c['no_'+k]['100']:.4f}" for _, _, k in RN) + " |")
P("\n## A-ii. Agent-R adapted slate with one route removed from the executor (same planner deltas, same calibrated weights)\n")
P("| Dataset | Removed route | role | slate R@50 | Δ vs Full slate (R@50) | mean items changed (of 50) | % users with changed slate |"); P("|---|---|---|---:|---:|---:|---:|")
BASE = {"Software_10_80_r811": "DiffRec", "KuaiRec_dg": "DiffRec", "Industrial_10_80_r811": "NCL", "MicroLens_dg": "NCL"}
for ds, dn in DS:
    s = SS[ds]
    for r, n, _ in RN:
        role = "base (other CF promoted to base)" if n == BASE[ds] else ("aux CF" if n in ("NCL", "DiffRec") else "aux")
        P(f"| {dn} | {n} | {role} | {s[r]['slate_R@50']:.4f} | {s[r]['slate_R@50'] - s['full_slate_R@50']:+.4f} | {s[r]['mean_items_changed_of_50']:.2f} | {100*s[r]['frac_users_changed']:.1f}% |")
P("\n## B. Final recommendation with one route removed (Full ranker pinned, inference-only, full test population)\n")
P("| Dataset | Variant | N@10 | R@10 | N@50 | R@50 | ΔN@10 | ΔR@10 | ΔN@50 | ΔR@50 |"); P("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|")
for ds, dn in DS:
    f = json.load(open(A / ds / "full.json"))["fulltest"]
    P(f"| {dn} | Full Agent-R | " + " | ".join(f"{f[k]:.4f}" for k in K) + " | – | – | – | – |")
    rows.append([dn, "Full Agent-R"] + [f"{f[k]:.4f}" for k in K] + [""] * 4)
    for r, n, _ in RN:
        p = A / ds / f"rq9no{r}.json"
        if not p.exists(): P(f"| {dn} | − {n} | – | – | – | – | | | | |"); continue
        d = json.load(open(p)); m = d["fulltest"]; b = d["vs_full_agentr_bootstrap"]
        P(f"| {dn} | − {n} | " + " | ".join(f"{m[k]:.4f}" for k in K) + " | " + " | ".join(sg(b, k) for k in K) + " |")
        rows.append([dn, f"-{n}"] + [f"{m[k]:.4f}" for k in K] + [f"{b[k]['delta']:+.4f}" for k in K])
with open(A / "rq9_final_table.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["dataset", "variant"] + K + [f"d_{k}" for k in K]); w.writerows(rows)
P("\n## C. Old (legacy) vs modern route bank — same slots, same full-pop/GT (candidate level)\n")
P("| Dataset | Slot | modern model | old R@50 | modern R@50 | Δ |"); P("|---|---|---|---:|---:|---:|")
for ds, dn in DS:
    c = json.load(open(A / f"candidate_level_{ds}.json")); cm = c["old_vs_modern"]; mm = c["modern_slot_models"]
    for sl in ["graph", "collab", "semantic", "mem", "popularity", "union5"]:
        v = cm[sl]; P(f"| {dn} | {sl} | {mm.get(sl, 'union of 5 slots')} | {v['old_R@50']:.4f} | {v['modern_R@50']:.4f} | {v['modern_R@50'] - v['old_R@50']:+.4f} |")
open(A / "rq9_tables.md", "w").write("\n".join(o)); print("\n".join(o))
