#!/usr/bin/env python3
"""RQ9 candidate level (CPU): (i) oracle union R@50/@100 with each route left out; (C) old vs modern route bank.
Population/GT/Recall exactly as the canonical evaluator (full TEST pop, label==2, gw.all_metrics Recall)."""
import json, os, pickle, sys
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"
os.environ.setdefault("AGENTR_FROZEN_SUFFIX", "_planner_modern")
sys.path.insert(0, str(RES / "scripts")); import rr_common as rr, gw_eval as ge   # noqa
from build_test_data import load_test_targets   # noqa
OUT = Path(__file__).resolve().parent.parent / "artifacts"
ROUTES = ["NCL", "DiffRec", "Qwen3-Emb", "Mem-Ret", "Popularity"]
def rec(lst, g):   # canonical Recall (duplicates in GT list count, as all_metrics)
    s = set(lst); return sum(1 for x in g if x in s) / len(g)
res = {}
for ds in sys.argv[1:]:
    pop = list(rr.gw.load_frozen(ds)["frozen"]["test"].keys()); tmap = load_test_targets(ds)
    rc = REPO / "pipeline/route_bank/artifacts/route_cache" / ds
    L = {}
    for n, tc in [("NCL", "ncl"), ("DiffRec", "diffrec"), ("Qwen3-Emb", "semantic_qwen3")]:
        us = pickle.load(open(rc / f"toolcache_{tc}.pkl", "rb"))["users"]; L[n] = {u: [str(x) for x in us[u]["items"]] for u in pop if u in us}
    mc = pickle.load(open(REPO / f"outputs/results/{ds}/precomputed_tool_cache_modern.pkl", "rb"))
    L["Mem-Ret"] = {u: [str(x) for x in mc["mem"].get(u, [])] for u in pop}; L["Popularity"] = {u: [str(x) for x in mc["popularity"].get(u, [])] for u in pop}
    def union_recall(routes, k):
        return float(np.sum([rec(set().union(*[set(L[r].get(u, [])[:k]) for r in routes]), tmap[u]) for u in pop]) / len(pop))
    R = {"all5": {k: union_recall(ROUTES, k) for k in (50, 100)}}
    for r in ROUTES:
        rest = [x for x in ROUTES if x != r]
        R["no_" + r] = {k: union_recall(rest, k) for k in (50, 100)}
    # C: old vs modern bank, single routes + union of the 5 fused slots (keyword excluded in both)
    old = pickle.load(open(REPO / f"outputs/results/{ds}/precomputed_tool_cache.pkl", "rb"))
    OLDSLOTS = ["graph", "collab", "semantic", "mem", "popularity"]
    O = {s: {u: [str(x) for x in old.get(s, {}).get(u, [])] for u in pop} for s in OLDSLOTS}
    M = {"graph": None, "collab": None}
    base = json.load(open(REPO / f"pipeline/route_bank/artifacts/base_selection_{ds}.json"))
    mod = {"graph": L[base["base_route_model"]], "collab": L[base["aux_collab_model"]], "semantic": L["Qwen3-Emb"], "mem": L["Mem-Ret"], "popularity": L["Popularity"]}
    comp = {}
    for s in OLDSLOTS:
        comp[s] = {"old_R@50": float(np.mean([rec(O[s][u][:50], tmap[u]) for u in pop])), "modern_R@50": float(np.mean([rec(mod[s].get(u, [])[:50], tmap[u]) for u in pop])),
                   "old_depth_median": int(np.median([len(v) for v in O[s].values()]))}
    comp["union5"] = {"old_R@50": float(np.mean([rec(set().union(*[set(O[s][u][:50]) for s in OLDSLOTS]), tmap[u]) for u in pop])),
                      "modern_R@50": float(np.mean([rec(set().union(*[set(mod[s].get(u, [])[:50]) for s in OLDSLOTS]), tmap[u]) for u in pop]))}
    R["old_vs_modern"] = comp; R["modern_slot_models"] = {"graph": base["base_route_model"], "collab": base["aux_collab_model"], "semantic": "Qwen3-Emb", "mem": "Mem-Ret", "popularity": "Popularity"}
    res[ds] = R; json.dump(R, open(OUT / f"candidate_level_{ds}.json", "w"), indent=1)
    print(ds, json.dumps({k: (round(v[50], 4) if isinstance(v, dict) and 50 in v else None) for k, v in R.items() if k.startswith(("all", "no_"))}), flush=True)
