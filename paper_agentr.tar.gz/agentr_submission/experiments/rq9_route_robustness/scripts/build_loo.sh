#!/usr/bin/env bash
# RQ9 leave-one-route-out slate + TEST-only residual records (CPU). Usage: DS=<ds> R=<NCL|DiffRec|Qwen3|MemRet|Pop> bash build_loo.sh
set -uo pipefail
REPO=/path/to/agentr
RES=$REPO/pipeline/residual_ranker; PROM=$REPO/pipeline/candidate_adaptation
EXP10=$REPO/pipeline/planning/artifacts
PY=${PY_RECBOLE:-python}
SFX=_modern_rq9no${R}
# 1) modified combined cache (new file; original untouched)
$PY - <<PY || exit 1
import json, pickle
ds, R = "$DS", "$R"
base = json.load(open("$REPO/pipeline/route_bank/artifacts/base_selection_%s.json" % ds))["base_route_model"]
c = pickle.load(open("$REPO/outputs/results/%s/precomputed_tool_cache_modern.pkl" % ds, "rb"))
slot = {"Qwen3": "semantic", "MemRet": "mem", "Pop": "popularity"}.get(R)
if slot is None:                                   # a CF route
    if R == base:                                  # removing the BASE route: other CF model becomes base
        c["graph"] = c["collab"]; c["collab"] = {}; note = "base removed -> collab promoted to base"
    else:
        c["collab"] = {}; note = "aux CF removed"
else:
    c[slot] = {}; note = f"{slot} removed"
pickle.dump(c, open("$REPO/outputs/results/%s/precomputed_tool_cache$SFX.pkl" % ds, "wb"))
print(ds, R, "base=", base, "|", note)
PY
# 2) same calibrated prior weights / offline file (no re-tuning): symlink
ln -sf $EXP10/offline_${DS}_modern.json $EXP10/offline_${DS}${SFX}.json
# 3) planner-conditioned frozen slate with the SAME planner deltas
( cd $REPO && AGENTR_TOOLCACHE_SUFFIX=$SFX $PY $PROM/scripts/stage1_build_planner.py --dataset $DS \
    --delta-suffix _modern --frozen-suffix _rq9no${R}_modern ) || exit 1
# 4) TEST-only residual records (LLM STM/LTM profile)
export AGENTR_FROZEN_SUFFIX=_rq9no${R}_modern AGENTR_DATA_DIR=$RES/data_rq9_modern_mem/$R AGENTR_USER_MEMORY=llm AGENTR_LOCAL_SPLIT=1
mkdir -p $AGENTR_DATA_DIR/$DS
$PY -c "import pickle;pickle.dump({'train':[],'dev':[]},open('$AGENTR_DATA_DIR/$DS/residual_users.pkl','wb'))"
cd $RES/scripts && $PY build_test_data.py --ds $DS > /dev/null || exit 1
touch $AGENTR_DATA_DIR/$DS/READY; echo "DONE $DS $R"
