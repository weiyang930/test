import json, os, pickle, sys
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"; PROM = REPO / "pipeline/candidate_adaptation/artifacts"
sys.path.insert(0, str(RES / "scripts")); os.environ["AGENTR_FROZEN_SUFFIX"] = "_planner_modern"
import rr_common as rr, gw_eval as ge   # noqa
from build_test_data import load_test_targets   # noqa
allm = ge.gw.all_metrics; out = {}
for ds in ["Software_10_80_r811", "Industrial_10_80_r811", "KuaiRec_dg", "MicroLens_dg"]:
    tmap = load_test_targets(ds); F = pickle.load(open(PROM / f"frozen_{ds}_planner_modern.pkl", "rb"))["frozen"]["test"]; pop = list(F)
    out[ds] = {"full_slate_R@50": float(np.mean([allm(F[u]["exp10_order"][:50], tmap[u])["Recall@50"] for u in pop]))}
    for R in ["NCL", "DiffRec", "Qwen3", "MemRet", "Pop"]:
        G = pickle.load(open(PROM / f"frozen_{ds}_rq9no{R}_modern.pkl", "rb"))["frozen"]["test"]
        diff = [len(set(F[u]["exp10_order"][:50]) - set(G.get(u, {"exp10_order": []})["exp10_order"][:50])) for u in pop]
        out[ds][R] = {"slate_R@50": float(np.mean([allm(G[u]["exp10_order"][:50], tmap[u])["Recall@50"] if u in G else 0.0 for u in pop])),
                      "mean_items_changed_of_50": float(np.mean(diff)), "frac_users_changed": float(np.mean([d > 0 for d in diff])),
                      "n_rescued_mean": float(np.mean([len(G[u]["rescued"]) for u in G]))}
    print(ds, {k: (round(v["slate_R@50"], 4), round(v["mean_items_changed_of_50"], 2)) if isinstance(v, dict) else round(v, 4) for k, v in out[ds].items()}, flush=True)
json.dump(out, open(Path(__file__).resolve().parent.parent / "artifacts" / "slate_stats.json", "w"), indent=1)
