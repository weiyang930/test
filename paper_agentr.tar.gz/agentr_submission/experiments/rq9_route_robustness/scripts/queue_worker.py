#!/usr/bin/env python3
"""RQ2 follow-up: one GPU worker pulling (dataset, setting, shard) scoring tasks from a shared file-lock
queue. Scores TEST residual records of each setting's slate with the FULL ranker ckpt (no retraining)."""
import os, pickle, sys, time
from pathlib import Path
import torch
RES = Path("/path/to/agentr/pipeline/residual_ranker")
sys.path.insert(0, str(RES / "scripts"))
from eval_residual import load_ckpt, compute_residuals   # noqa: E402
CK = {"Software_10_80_r811": "res_software_modern/step_254", "Industrial_10_80_r811": "res_industrial_modern/step_72",
      "KuaiRec_dg": "res_KuaiRec_dg_modern/step_128", "MicroLens_dg": "res_MicroLens_dg_modern/step_234"}
NSH = {"Software_10_80_r811": 16, "MicroLens_dg": 8, "KuaiRec_dg": 2, "Industrial_10_80_r811": 1}
SETS = sys.argv[1].split(",")
tasks = [(ds, st, i) for ds in NSH for st in SETS for i in range(NSH[ds])]
dev = torch.device("cuda", 0); cur = None; model = tok = cfg = None
def out_dir(ds, st): return RES / "artifacts" / f"rq9_{st}_{ds}_TEST" / "shards"
while True:
    pending = [t for t in tasks if not (out_dir(t[0], t[1]) / f"claim_{t[2]}").exists()]
    if not pending:
        break
    ready = [t for t in pending if (RES / "data_rq9_modern_mem" / t[1] / t[0] / "READY").exists()]
    ready.sort(key=lambda t: (t[0] != cur,))
    got = None
    for t in ready:
        od = out_dir(t[0], t[1]); od.mkdir(parents=True, exist_ok=True)
        try:
            os.mkdir(od / f"claim_{t[2]}"); got = t; break
        except FileExistsError:
            continue
    if got is None:
        time.sleep(5); continue
    ds, st, i = got
    if ds != cur:
        del model; torch.cuda.empty_cache()
        model, tok, cfg = load_ckpt(RES / "checkpoints" / CK[ds], dev); cur = ds
    recs = pickle.load(open(RES / "data_rq9_modern_mem" / st / ds / "residual_users.pkl", "rb"))["test"][i::NSH[ds]]
    res = compute_residuals(model, tok, recs, dev, cfg["max_len"], 128)
    pickle.dump(res, open(out_dir(ds, st) / f"s{i}.pkl.tmp", "wb"))
    os.rename(out_dir(ds, st) / f"s{i}.pkl.tmp", out_dir(ds, st) / f"s{i}.pkl")
    print(f"[{time.strftime('%T')}] done {ds} {st} shard {i}/{NSH[ds]} ({len(res)} users)", flush=True)
print("WORKER EXIT", flush=True)
