#!/usr/bin/env python3
"""RQ5 failure analysis from saved artifacts only (no model runs).
C0 = base-route top-50 (frozen_<ds>_baseonly_modern: keep=50, budget=0 -> exactly the base route's top-50).
C  = Agent-R adapted slate (frozen_<ds>_planner_modern exp10_order[:50]).
Ranking before = C's frozen order; after = Full Agent-R final order (saved residual_cache_test + pinned prior/alpha).
Population = full official TEST population; GT = label==2 set. User-level success = any GT item in the set.
Prioritization/preservation use each rankable user's canonical held-out GT (residual_users['test'].gt_id)."""
import json, os, pickle, sys
from pathlib import Path
import numpy as np
REPO = Path("/path/to/agentr"); RES = REPO / "pipeline/residual_ranker"
PROM = REPO / "pipeline/candidate_adaptation/artifacts"; H = Path(__file__).resolve().parent
os.environ["AGENTR_DATA_DIR"] = str(RES / "data_planner_modern_mem"); os.environ["AGENTR_FROZEN_SUFFIX"] = "_planner_modern"
sys.path.insert(0, str(RES / "scripts")); import rr_common as rr   # noqa
from build_test_data import load_test_targets   # noqa
import gw_eval as ge   # noqa
allm = ge.gw.all_metrics
BUCKETS = [(1, 10), (11, 20), (21, 30), (31, 40), (41, 50)]
bname = lambda r: next(f"{a}-{b}" for a, b in BUCKETS if a <= r <= b)
R = {}
for ds in ["Software_10_80_r811", "Industrial_10_80_r811", "KuaiRec_dg", "MicroLens_dg"]:
    C = pickle.load(open(PROM / f"frozen_{ds}_planner_modern.pkl", "rb"))["frozen"]["test"]
    C0 = pickle.load(open(PROM / f"frozen_{ds}_baseonly_modern.pkl", "rb"))["frozen"]["test"]
    tmap = load_test_targets(ds); pop = list(C.keys()); assert set(pop) == set(C0)
    # sanity: C's top-40 == C0's top-40 (base prefix preserved)
    assert all(C[u]["exp10_order"][:40] == C0[u]["exp10_order"][:40] for u in pop)
    # ---- 1. consideration (user level + item-pair level)
    miss_u = resc_u = 0; miss_p = resc_p = 0; r0 = []; r1 = []
    rescued_users = set()
    for u in pop:
        g = set(tmap.get(u, [])); s0 = set(C0[u]["exp10_order"][:50]); s1 = set(C[u]["exp10_order"][:50])
        # R@50 via the canonical evaluator's metric (duplicate GT entries count, exactly as fulltest_eval)
        r0.append(allm(C0[u]["exp10_order"][:50], tmap.get(u, []))["Recall@50"]); r1.append(allm(C[u]["exp10_order"][:50], tmap.get(u, []))["Recall@50"])
        miss_p += len(g - s0); resc_p += len((g - s0) & s1)
        if not (g & s0):
            miss_u += 1
            if g & s1: resc_u += 1; rescued_users.add(u)
    lost_u = sum(1 for u in pop if (set(tmap[u]) & set(C0[u]["exp10_order"][:50])) and not (set(tmap[u]) & set(C[u]["exp10_order"][:50])))
    cons = {"n_pop": len(pop), "base_missed_users": miss_u, "rescued_users": resc_u, "rescue_rate": resc_u / miss_u,
            "users_lost_by_adaptation": lost_u, "net_users_gained": resc_u - lost_u,
            "base_missed_pairs": miss_p, "rescued_pairs": resc_p, "pair_rescue_rate": resc_p / miss_p,
            "base_R@50": float(np.mean(r0)), "adapted_R@50": float(np.mean(r1)), "R@50_abs_gain": float(np.mean(r1) - np.mean(r0))}
    # ---- 2/3. prioritization + preservation (Full Agent-R reorder)
    ft = json.load(open(REPO / f"pipeline/route_bank/artifacts/fulltest_{ds}.json"))
    recs = pickle.load(open(RES / "data_planner_modern_mem" / ds / "residual_users.pkl", "rb"))["test"]
    res = pickle.load(open(RES / "artifacts" / ft["tag"] / "residual_cache_test.pkl", "rb"))
    pB = rr.PriorB(json.load(open(RES / "data_planner_modern_mem" / ds / "priorB.json"))["score_by_rank"])
    before, after, is_resc = [], [], []
    for rec in recs:
        p = np.array([rr.prior_A(k) if ft["prior"] == "A" else pB.score(k) for k in rec["base_rank"]])
        fin = rr.fused_order(rec["cand_ids"], p, res[rec["uid"]], ft["alpha"])
        before.append(rec["gt_idx"] + 1); after.append(fin.index(rec["gt_id"]) + 1); is_resc.append(rec["uid"] in rescued_users)
    before, after, is_resc = map(np.array, (before, after, is_resc)); imp = before - after
    lo = before > 10; hi = before <= 10
    prio = {"n_rankable": int(len(before)), "n_failure_users(rank>10)": int(lo.sum()),
            "promoted_into_top10": int((after[lo] <= 10).sum()), "promotion_rate": float((after[lo] <= 10).mean()),
            "rank_improvement_mean": float(imp[lo].mean()), "rank_improvement_median": float(np.median(imp[lo])),
            "frac_moved_up": float((imp[lo] > 0).mean()), "frac_moved_down": float((imp[lo] < 0).mean()), "frac_unchanged": float((imp[lo] == 0).mean())}
    pres = {"n_base_success(top10)": int(hi.sum()), "remain_top10": int((after[hi] <= 10).sum()), "preservation_rate": float((after[hi] <= 10).mean()),
            "rank_change_mean(after-before)": float((after[hi] - before[hi]).mean()), "rank_change_median": float(np.median(after[hi] - before[hi])),
            "frac_moved_down": float((after[hi] > before[hi]).mean())}
    # rescued users' downstream fate (consideration -> prioritization flow). Rescued items sit at slots 41-50.
    rr_m = is_resc
    flow = {"rescued_users_rankable": int(rr_m.sum()), "rescued_then_top10": int((after[rr_m] <= 10).sum()),
            "rescued_then_top10_rate": float((after[rr_m] <= 10).mean()) if rr_m.any() else None,
            "rescued_rank_before_mean": float(before[rr_m].mean()) if rr_m.any() else None,
            "rescued_rank_after_mean": float(after[rr_m].mean()) if rr_m.any() else None}
    trans = {b1: {b2: int(((np.vectorize(bname)(before) == b1) & (np.vectorize(bname)(after) == b2)).sum()) for b2 in map(lambda x: f"{x[0]}-{x[1]}", BUCKETS)}
             for b1 in map(lambda x: f"{x[0]}-{x[1]}", BUCKETS)}
    dist = {"before": {k: int(sum(v.values())) for k, v in trans.items()},
            "after": {b2: int(sum(trans[b1][b2] for b1 in trans)) for b2 in trans}}
    R[ds] = {"consideration": cons, "prioritization": prio, "preservation": pres, "rescue_to_ranking_flow": flow,
             "rank_bucket_transition(before->after)": trans, "rank_bucket_distribution": dist,
             "config": {"prior": ft["prior"], "alpha": ft["alpha"], "tag": ft["tag"]}}
    print(ds, json.dumps({"rescue": round(cons["rescue_rate"], 4), "promo": round(prio["promotion_rate"], 4), "pres": round(pres["preservation_rate"], 4),
                          "R50": (round(cons["base_R@50"], 4), round(cons["adapted_R@50"], 4))}))
json.dump(R, open(H / "artifacts" / "rq5_results.json", "w"), indent=1)
