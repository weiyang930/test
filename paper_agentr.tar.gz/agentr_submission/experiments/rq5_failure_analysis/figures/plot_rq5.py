#!/usr/bin/env python3
"""RQ5 figure: per-dataset failure-resolution flow (base state -> after candidate adaptation -> final)
+ companion bar chart of rescue / promotion / preservation rates. Visualizes artifacts/rq5_results.json only.
Flow decomposition (mutually exclusive, sums to the full test population; derived from existing counts):
  A  base top-10              = preservation n           -> final top-10 (preserved) | 11-50
  B  base 11-50, kept in C    = prio_failure - rescued   -> final top-10 (promoted - rescued_top10) | 11-50
  L  base 41-50, displaced    = users_lost_by_adaptation -> outside top-50
  R  missing, rescued into C  = rescued                  -> final top-10 (rescued_then_top10) | 11-50
  U  missing, not rescued     = base_missed - rescued    -> outside top-50  (drawn as a truncated band)"""
import json
import numpy as np, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch, Rectangle, Patch
import matplotlib.patheffects as pe
from pathlib import Path
OUT = Path(__file__).resolve().parent
R = json.load(open(OUT.parent / "artifacts" / "rq5_results.json"))
mpl.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif", "Times New Roman"], "font.size": 7.5,
                     "axes.linewidth": 0.6, "pdf.fonttype": 42, "ps.fonttype": 42})
# validated all-pairs: worst CVD dE 9.5, worst normal dE 17.2 (lavender vs slate separated by lightness)
BLUE, PURP, CHAR, LG = "#2f6fb0", "#a47fd4", "#2e3844", "#e4e6ea"
INK = "#000000"
DS = [("Software_10_80_r811", "Software"), ("Industrial_10_80_r811", "Industrial"), ("KuaiRec_dg", "KuaiRec"), ("MicroLens_dg", "MicroLens")]

def decompose(v):
    c, p, s, f = v["consideration"], v["prioritization"], v["preservation"], v["rescue_to_ranking_flow"]
    A, A10 = s["n_base_success(top10)"], s["remain_top10"]
    Rr, R10 = c["rescued_users"], f["rescued_then_top10"]
    Bin = p["n_failure_users(rank>10)"] - Rr; B10 = p["promoted_into_top10"] - R10
    L = c["users_lost_by_adaptation"]; U = c["base_missed_users"] - Rr
    d = dict(A=A, A10=A10, Bin=Bin, B10=B10, L=L, R=Rr, R10=R10, U=U)
    assert A + Bin + L + Rr + U == c["n_pop"], (d, c["n_pop"])
    return d
FLOWS = {ds: decompose(R[ds]) for ds, _ in DS}
json.dump({n: FLOWS[d] for d, n in DS}, open(OUT / "rq5_flow_decomposition.json", "w"), indent=1)

def band(ax, x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.92):
    xm = (x0 + x1) / 2
    verts = [(x0, y0a), (xm, y0a), (xm, y1a), (x1, y1a), (x1, y1b), (xm, y1b), (xm, y0b), (x0, y0b), (x0, y0a)]
    codes = [MPath.MOVETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4, MPath.LINETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4, MPath.CLOSEPOLY]
    ax.add_patch(PathPatch(MPath(verts, codes), facecolor=color, edgecolor="none", alpha=alpha, zorder=1))

def sankey(ax, d, name, left_labels, right_labels, notes):
    W, G, T = 0.06, 0.05, 0.17                       # node width, node gap, truncated-band height
    lin = d["A"] + d["Bin"] + d["L"] + d["R"]; s = (1 - 2 * G - T) / lin
    X = [0.0, 1.0, 2.0]
    def stack(hs):                                   # top-down node extents
        ys, y = [], 1.0
        for h in hs:
            ys.append((y, y - h)); y -= h + G
        return ys
    col0 = stack([d["A"] * s, (d["Bin"] + d["L"]) * s, d["R"] * s + T])
    col1 = stack([d["A"] * s, (d["Bin"] + d["R"]) * s, d["L"] * s + T])
    col2 = stack([(d["A10"] + d["B10"] + d["R10"]) * s, (d["A"] - d["A10"] + d["Bin"] - d["B10"] + d["R"] - d["R10"]) * s, d["L"] * s + T])
    for x, col in zip(X, (col0, col1, col2)):
        for (t, b) in col:
            ax.add_patch(Rectangle((x - W / 2, b), W, t - b, facecolor="#2b2b2b", edgecolor="none", zorder=3))
    xa, xb, xc = X[0] + W / 2, X[1] - W / 2, X[1] + W / 2; xd = X[2] - W / 2
    # stage 1: candidate adaptation
    band(ax, xa, *col0[0], xb, *col1[0], LG)                                              # A pass-through
    t0, t1 = col0[1][0], col1[1][0]
    band(ax, xa, t0, t0 - d["Bin"] * s, xb, t1, t1 - d["Bin"] * s, LG)                    # B kept
    band(ax, xa, t0 - d["Bin"] * s, col0[1][1], xb, col1[2][0], col1[2][0] - d["L"] * s, LG)   # B displaced
    m0 = col0[2][0]; mb = t1 - d["Bin"] * s
    band(ax, xa, m0, m0 - d["R"] * s, xb, mb, mb - d["R"] * s, BLUE)                     # rescued
    band(ax, xa, m0 - d["R"] * s, col0[2][1], xb, col1[2][0] - d["L"] * s, col1[2][1], LG, 0.55)   # not rescued (truncated)
    # stage 2: residual ranking
    a0 = col1[0][0]; f0 = col2[0][0]; g0 = col2[1][0]
    band(ax, xc, a0, a0 - d["A10"] * s, xd, f0, f0 - d["A10"] * s, CHAR)                 # preserved
    band(ax, xc, a0 - d["A10"] * s, col1[0][1], xd, g0, g0 - (d["A"] - d["A10"]) * s, LG) # demoted from top-10
    p10 = d["B10"] + d["R10"]; mt = col1[1][0]
    band(ax, xc, mt, mt - p10 * s, xd, f0 - d["A10"] * s, col2[0][1], PURP)              # promoted
    band(ax, xc, mt - p10 * s, col1[1][1], xd, g0 - (d["A"] - d["A10"]) * s, col2[1][1], LG)
    band(ax, xc, *col1[2], xd, *col2[2], LG, 0.55)                                       # outside -> outside
    # truncation marks on the not-retrieved mass
    yb = col0[2][1] + T * 0.45
    for dx in (-0.03, 0.03):
        ax.plot([0.22 + dx - 0.025, 0.22 + dx + 0.025], [yb - 0.04, yb + 0.04], color="white", lw=1.5, zorder=2)
    ax.text(1.5, col1[2][1] + T * 0.45, f"{d['U'] + d['L']:,}", ha="center", va="center", fontsize=6.6, color=INK, zorder=4)
    # key counts
    ax.text(0.55, (m0 - d["R"] * s / 2 + mb - d["R"] * s / 2) / 2, f"{d['R']:,}", ha="center", va="center", fontsize=6.8, color=INK,
            fontweight="bold", zorder=5, path_effects=[pe.withStroke(linewidth=1.8, foreground="white")])
    ax.text(1.5, (mt - p10 * s / 2 + f0 - d["A10"] * s - p10 * s / 2) / 2, f"{p10:,}", ha="center", va="center", fontsize=6.8, color=INK, fontweight="bold", zorder=5, path_effects=[pe.withStroke(linewidth=1.8, foreground="white")])
    ax.text(1.5, (a0 - d["A10"] * s / 2 + f0 - d["A10"] * s / 2) / 2, f"{d['A10']:,}", ha="center", va="center", fontsize=6.8, color="white", zorder=4)
    lab = dict(fontsize=7.2, color=INK, va="center")
    if left_labels:
        for (t, b), txt in zip(col0, ["base top-10", "base 11–50", "not retrieved"]):
            ax.text(-0.07, (t + b) / 2, txt, ha="right", **lab)
    if right_labels:
        for (t, b), txt in zip(col2, ["top-10", "rank 11–50", "outside top-50"]):
            ax.text(2.07, (t + b) / 2, txt, ha="left", **lab)
    ax.text(1.0, -0.075, name, ha="center", va="top", fontsize=8.4, fontweight="bold")
    ax.set_xlim(-0.05, 2.05); ax.set_ylim(-0.02, 1.0); ax.axis("off")

fig = plt.figure(figsize=(7.4, 3.55))
outer = fig.add_gridspec(1, 2, width_ratios=[2.3, 0.95], wspace=0.30, left=0.105, right=0.99, top=0.815, bottom=0.135)
gs = outer[0].subgridspec(2, 2, wspace=0.36, hspace=0.36)
for k, (ds, dn) in enumerate(DS):
    ax = fig.add_subplot(gs[k // 2, k % 2])
    sankey(ax, FLOWS[ds], dn, left_labels=(k % 2 == 0), right_labels=(k % 2 == 1), notes=(k == 0))
    if k < 2:
        for xc, head, sub, col in ((0.5, "Candidate\nAdaptation", "rescues\nmissing items", BLUE),
                                   (1.5, "Residual\nRanking", "promotes\navailable items", "#6b46a6")):
            ax.text(xc, 1.19, head, ha="center", va="bottom", fontsize=7.2, color=col, fontweight="bold", linespacing=1.0)
            ax.text(xc, 1.175, sub, ha="center", va="top", fontsize=6.4, color=INK, style="italic", linespacing=1.0)
from matplotlib.lines import Line2D
fig.legend(handles=[Patch(color=BLUE), Patch(color=PURP), Patch(color=CHAR), Patch(color=LG),
                    Line2D([], [], color="#9aa0a8", lw=0, marker="$//$", markersize=7, markerfacecolor=INK, markeredgecolor=INK)],
           labels=["rescued into candidates", "promoted into top-10", "preserved in top-10", "unchanged", "not to scale"],
           loc="lower center", bbox_to_anchor=(0.365, -0.01), ncol=5, frameon=False, fontsize=6.7, handlelength=1.0, columnspacing=0.9)
fig.text(0.008, 0.985, "(a)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.038, 0.985, "Failure Resolution Flow  (base → after adaptation → final)", fontsize=8.6, va="top")

# (b) rates
bx = fig.add_subplot(outer[1])
names = [n for _, n in DS]; x = np.arange(4); w = 0.26
rates = {"Rescue": [R[d]["consideration"]["rescue_rate"] * 100 for d, _ in DS],
         "Promotion": [R[d]["prioritization"]["promotion_rate"] * 100 for d, _ in DS],
         "Preservation": [R[d]["preservation"]["preservation_rate"] * 100 for d, _ in DS]}
for i, (k, c) in enumerate(zip(rates, (BLUE, PURP, CHAR))):
    bb = bx.bar(x + (i - 1) * w, rates[k], w, color=c, label=k, edgecolor="none")
    for xi, v in zip(x, rates[k]):
        bx.text(xi + (i - 1) * w, v + 1.2, f"{v:.1f}", ha="center", va="bottom", fontsize=6.3, rotation=90, color=INK)
bx.set_xticks(x); bx.set_xticklabels(names, fontsize=7.2, rotation=30, ha="right", rotation_mode="anchor"); bx.set_ylim(0, 106); bx.set_ylabel("Rate (%)", fontsize=8)
bx.tick_params(axis="y", labelsize=7, length=2); bx.tick_params(axis="x", length=0)
for s_ in ("top", "right"): bx.spines[s_].set_visible(False)
bx.legend(loc="lower center", bbox_to_anchor=(0.45, 1.0), ncol=3, frameon=False, fontsize=6.6, handlelength=0.8, handletextpad=0.3, columnspacing=0.5)
fig.text(0.735, 0.985, "(b)", fontsize=9.5, fontweight="bold", va="top")
fig.text(0.765, 0.985, "Resolution Rates", fontsize=8.6, va="top")
fig.savefig(OUT / "rq5_failure_resolution.pdf"); fig.savefig(OUT / "rq5_failure_resolution.png", dpi=400)
print(json.dumps({n: FLOWS[d] for d, n in DS}))
