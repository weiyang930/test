from __future__ import annotations

import pickle
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set

import pandas as pd

from src.common.artifacts import ArtifactManager
from src.common.config import DatasetConfig
from src.common.schemas import DatasetSplit, Interaction

# Split-label convention produced by Data/raw_data/build_data_variants.py:
#   0 -> train, 1 -> valid, 2 -> test
LABEL_TRAIN = 0
LABEL_VALID = 1
LABEL_TEST = 2


@dataclass
class DatasetBundle:
    """In-memory view of one processed dataset consumed by tools/agents/evaluators."""

    split: DatasetSplit
    item_profiles: Dict[str, str]
    user_profiles: Dict[str, str]
    user_train_items: Dict[str, Set[str]]
    user_valid_items: Dict[str, List[str]]
    user_test_items: Dict[str, List[str]]
    dataset_name: str = ""
    data_dir: str = ""


class DatasetLoader:
    """Loads a processed dataset from ``{data_dir}/{dataset_name}/`` into a DatasetBundle.

    Expected files (produced by Data/raw_data/build_data_variants.py):
      - interaction.csv   : userid, itemid, timestamp, label (0/1/2)
      - item_profile.csv  : itemid, item_profile
    IDs are treated as strings everywhere downstream.
    """

    def __init__(self, cfg: DatasetConfig, artifacts: ArtifactManager) -> None:
        self.cfg = cfg
        self.artifacts = artifacts
        self.dataset_dir = Path(cfg.data_dir) / cfg.dataset_name

    def _cache_path(self) -> Path:
        return self.artifacts.split_cache_dir / "dataset_bundle.pkl"

    def load(self, force_rebuild: bool = False) -> DatasetBundle:
        cache_path = self._cache_path()
        if (
            getattr(self.cfg, "prefer_split_cache", True)
            and not force_rebuild
            and cache_path.exists()
        ):
            try:
                with cache_path.open("rb") as handle:
                    bundle = pickle.load(handle)
                if isinstance(bundle, DatasetBundle):
                    return bundle
            except Exception:
                pass  # fall through to rebuild on any cache issue

        bundle = self._build()

        if getattr(self.cfg, "save_split_cache", True):
            try:
                with cache_path.open("wb") as handle:
                    pickle.dump(bundle, handle)
            except Exception:
                pass

        return bundle

    def _build(self) -> DatasetBundle:
        interaction_path = self.dataset_dir / "interaction.csv"
        profile_path = self.dataset_dir / "item_profile.csv"
        if not interaction_path.exists():
            raise FileNotFoundError(f"interaction.csv not found at {interaction_path}")
        if not profile_path.exists():
            raise FileNotFoundError(f"item_profile.csv not found at {profile_path}")

        # --- item profiles ---
        profile_df = pd.read_csv(profile_path, dtype={"itemid": str})
        item_profiles: Dict[str, str] = {}
        for row in profile_df.itertuples(index=False):
            item_id = str(row.itemid)
            profile = getattr(row, "item_profile", "")
            item_profiles[item_id] = "" if pd.isna(profile) else str(profile)

        # --- interactions ---
        inter_df = pd.read_csv(
            interaction_path,
            dtype={"userid": str, "itemid": str},
        )
        inter_df = inter_df.sort_values(["userid", "timestamp", "itemid"]).reset_index(drop=True)

        train: List[Interaction] = []
        valid: List[Interaction] = []
        test: List[Interaction] = []
        user_train_items: Dict[str, Set[str]] = {}
        user_valid_items: Dict[str, List[str]] = {}
        user_test_items: Dict[str, List[str]] = {}

        for row in inter_df.itertuples(index=False):
            user_id = str(row.userid)
            item_id = str(row.itemid)
            timestamp = int(row.timestamp)
            label = int(row.label)
            interaction = Interaction(
                userid=user_id,
                itemid=item_id,
                timestamp=timestamp,
                label=label,
            )
            if label == LABEL_TRAIN:
                train.append(interaction)
                user_train_items.setdefault(user_id, set()).add(item_id)
            elif label == LABEL_VALID:
                valid.append(interaction)
                user_valid_items.setdefault(user_id, []).append(item_id)
            elif label == LABEL_TEST:
                test.append(interaction)
                user_test_items.setdefault(user_id, []).append(item_id)

        split = DatasetSplit(train=train, valid=valid, test=test)

        return DatasetBundle(
            split=split,
            item_profiles=item_profiles,
            user_profiles={},
            user_train_items=user_train_items,
            user_valid_items=user_valid_items,
            user_test_items=user_test_items,
            dataset_name=self.cfg.dataset_name,
            data_dir=self.cfg.data_dir,
        )
