from __future__ import annotations

import json
from collections import Counter
from typing import Any, Dict, List, Sequence

from src.agents.llm_backend import LLMBackend


USER_MEMORY_SYSTEM_PROMPT = (
    "You are a user memory agent for a recommender system. "
    "Convert compact interaction evidence into stable short-term and long-term user memory. "
    "Use only the provided evidence. Return one compact valid JSON object only. "
    "Do not use markdown fences or explanatory text."
)


class UserMemoryLLMAgent:
    """Batch LLM generator for schema-stable STM/LTM user memories."""

    def __init__(self, llm_backend: LLMBackend, batch_size: int = 256) -> None:
        self.llm_backend = llm_backend
        self.batch_size = max(1, int(batch_size))

    @staticmethod
    def fallback(user_id: str, evidence: Dict[str, Any]) -> Dict[str, Any]:
        recent_items = []
        for row in evidence.get("recent_items", [])[:3]:
            title = str(row.get("title", "")).strip()
            brand = str(row.get("brand", "")).strip()
            category = str(row.get("leaf_category", "") or row.get("categories", "")).strip()
            recent_items.append(" | ".join([part for part in [title, brand, category] if part])[:180])
        return {
            "memory_mode": "llm_agent_fallback",
            "short_term_recent_items": recent_items,
            "short_term_intents": [
                value for value, _ in Counter(
                    row.get("leaf_category", "") for row in evidence.get("recent_items", [])
                    if row.get("leaf_category")
                ).most_common(3)
            ],
            "long_term_categories": [value for value, _ in evidence.get("top_categories", [])[:4]],
            "long_term_brands": [value for value, _ in evidence.get("top_brands", [])[:5]],
            "stable_preferences": [value for value, _ in evidence.get("top_categories", [])[:3]],
            "representative_items": [row.get("title", "")[:160] for row in evidence.get("representative_items", [])[:4]],
            "avoid_or_low_interest": [],
            "rationale": "fallback_from_structured_history",
        }

    @staticmethod
    def render_prompt(user_id: str, evidence: Dict[str, Any]) -> Dict[str, str]:
        payload = {
            "task": (
                "Build compact recommendation memory for this user. "
                "Prefer stable, reusable phrases over long descriptions. "
                "Do not invent categories, brands, or products."
            ),
            "constraints": {
                "schema_must_match": True,
                "be_concise": True,
                "no_markdown": True,
                "max_words_per_phrase": 8,
                "max_short_term_intents": 4,
                "max_stable_preferences": 5,
                "max_long_term_categories": 5,
                "max_long_term_brands": 5,
                "max_representative_items": 5,
            },
            "user_id": str(user_id),
            "evidence": evidence,
            "output_schema": {
                "memory_mode": "llm_agent",
                "short_term_recent_items": ["title | brand | leaf_category"],
                "short_term_intents": ["compact current intent"],
                "long_term_categories": ["stable category"],
                "long_term_brands": ["stable brand"],
                "stable_preferences": ["compact stable preference"],
                "representative_items": ["representative item title"],
                "avoid_or_low_interest": [],
                "rationale": "one short sentence",
            },
        }
        return {
            "system": USER_MEMORY_SYSTEM_PROMPT,
            "user": json.dumps(payload, ensure_ascii=False),
        }

    @staticmethod
    def normalize(raw: Dict[str, Any], fallback: Dict[str, Any]) -> Dict[str, Any]:
        def norm_list(name: str, limit: int, char_limit: int) -> List[str]:
            value = raw.get(name, fallback.get(name, []))
            if not isinstance(value, list):
                value = fallback.get(name, [])
            out: List[str] = []
            seen = set()
            for item in value:
                text = " ".join(str(item).split())[:char_limit].strip()
                key = text.lower()
                if text and key not in seen:
                    out.append(text)
                    seen.add(key)
                if len(out) >= limit:
                    break
            return out

        return {
            "memory_mode": "llm_agent",
            "short_term_recent_items": norm_list("short_term_recent_items", 5, 180),
            "short_term_intents": norm_list("short_term_intents", 4, 120),
            "long_term_categories": norm_list("long_term_categories", 5, 160),
            "long_term_brands": norm_list("long_term_brands", 5, 80),
            "stable_preferences": norm_list("stable_preferences", 5, 140),
            "representative_items": norm_list("representative_items", 5, 160),
            "avoid_or_low_interest": norm_list("avoid_or_low_interest", 3, 120),
            "rationale": str(raw.get("rationale", fallback.get("rationale", "")))[:300],
        }

    def generate_batch(self, records: Sequence[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        outputs: Dict[str, Dict[str, Any]] = {}
        for start in range(0, len(records), self.batch_size):
            batch = list(records[start : start + self.batch_size])
            prompts = [row["prompt"]["user"] for row in batch]
            fallbacks = [row["fallback"] for row in batch]
            raws = self.llm_backend.generate_json_batch_with_system(
                user_prompts=prompts,
                system_prompt=USER_MEMORY_SYSTEM_PROMPT,
                fallbacks=fallbacks,
            )
            for row, raw, fallback in zip(batch, raws, fallbacks):
                outputs[str(row["user_id"])] = self.normalize(raw, fallback)
            print(
                f"[user_memory_agent] processed={min(start + len(batch), len(records))}/{len(records)}",
                flush=True,
            )
        return outputs
