from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Sequence

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from src.common.config import LLMConfig


class LLMBackend:
    def __init__(self, cfg: LLMConfig) -> None:
        self.cfg = cfg
        self._hf_tokenizer = None
        self._hf_model = None
        self._hf_device = None
        self._vllm_model = None
        # Optional cost accounting (opt-in via reset_cost_stats). When enabled,
        # every vLLM generation records exact prompt/completion token counts and
        # wall-clock time so callers can report per-call ranking cost.
        self._cost_enabled = False
        self._cost_stats: Dict[str, float] = {}

    def reset_cost_stats(self) -> None:
        """Enable and zero the token/time cost accumulator (vLLM backend only)."""
        self._cost_enabled = True
        self._cost_stats = {
            "n_prompts": 0,
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "generate_seconds": 0.0,
        }

    def get_cost_stats(self) -> Dict[str, float]:
        return dict(self._cost_stats)

    def generate_json(self, prompt: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
        if self.cfg.backend == "mock":
            return fallback
        text = self.generate_text(
            prompt,
            system_prompt="You are a precise retrieval-planning assistant. Return valid JSON only.",
            fallback=json.dumps(fallback, ensure_ascii=False),
        )
        return self._safe_json_loads(text, fallback)

    def generate_json_with_system(self, user_prompt: str, system_prompt: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
        if self.cfg.backend == "mock":
            return fallback
        text = self.generate_text(
            user_prompt,
            system_prompt=system_prompt,
            fallback=json.dumps(fallback, ensure_ascii=False),
        )
        return self._safe_json_loads(text, fallback)

    def generate_json_batch_with_system(
        self,
        user_prompts: Sequence[str],
        system_prompt: str,
        fallbacks: Sequence[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        if self.cfg.backend == "mock":
            return list(fallbacks)
        fallback_texts = [json.dumps(fallback, ensure_ascii=False) for fallback in fallbacks]
        texts = self.generate_texts(user_prompts, system_prompt=system_prompt, fallbacks=fallback_texts)
        return [self._safe_json_loads(text, fallback) for text, fallback in zip(texts, fallbacks)]

    def generate_text(self, prompt: str, system_prompt: Optional[str] = None, fallback: str = "") -> str:
        return self.generate_texts([prompt], system_prompt=system_prompt, fallbacks=[fallback])[0]

    def generate_texts(
        self,
        prompts: Sequence[str],
        system_prompt: Optional[str] = None,
        fallbacks: Optional[Sequence[str]] = None,
    ) -> List[str]:
        prompt_list = list(prompts)
        if not prompt_list:
            return []
        fallback_list = list(fallbacks) if fallbacks is not None else [""] * len(prompt_list)
        if self.cfg.backend == "mock":
            return fallback_list
        if self.cfg.backend == "openai":
            return [
                self._generate_openai(prompt, system_prompt=system_prompt, fallback=fallback)
                for prompt, fallback in zip(prompt_list, fallback_list)
            ]
        if self.cfg.backend == "huggingface":
            texts = self._generate_hf_batch(prompt_list, system_prompt=system_prompt)
            return [text or fallback for text, fallback in zip(texts, fallback_list)]
        if self.cfg.backend == "vllm":
            texts = self._generate_vllm_batch(prompt_list, system_prompt=system_prompt)
            return [text or fallback for text, fallback in zip(texts, fallback_list)]
        return fallback_list

    def _generate_openai(self, prompt: str, system_prompt: Optional[str], fallback: str) -> str:
        from openai import OpenAI

        client = OpenAI(api_key=os.getenv(self.cfg.api_key_env), base_url=self.cfg.api_base)
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        response = client.chat.completions.create(
            model=self.cfg.model_name,
            temperature=self.cfg.temperature,
            max_tokens=self.cfg.max_new_tokens,
            messages=messages,
        )
        return (response.choices[0].message.content or "").strip() or fallback

    def _generate_hf_batch(self, prompts: Sequence[str], system_prompt: Optional[str] = None) -> List[str]:
        tokenizer, model = self._load_hf_model()
        rendered_prompts: List[str] = []
        for prompt in prompts:
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            rendered_prompts.append(tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True))

        inputs = tokenizer(rendered_prompts, return_tensors="pt", padding=True)
        inputs = {k: v.to(self._hf_device) for k, v in inputs.items()}
        with torch.no_grad():
            generated_ids = model.generate(
                **inputs,
                max_new_tokens=self.cfg.max_new_tokens,
                temperature=self.cfg.temperature,
                do_sample=self.cfg.temperature > 0,
                pad_token_id=tokenizer.eos_token_id,
            )

        input_lengths = inputs["attention_mask"].sum(dim=1).tolist()
        outputs: List[str] = []
        for idx, input_len in enumerate(input_lengths):
            output_ids = generated_ids[idx][int(input_len) :]
            outputs.append(tokenizer.decode(output_ids, skip_special_tokens=True).strip())
        return outputs

    def _load_hf_model(self):
        if self._hf_model is not None and self._hf_tokenizer is not None:
            return self._hf_tokenizer, self._hf_model
        model_name = self.cfg.model_name
        self._hf_tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        if self._hf_tokenizer.pad_token is None:
            self._hf_tokenizer.pad_token = self._hf_tokenizer.eos_token
        device_map: str = "auto"
        max_memory = None
        if int(getattr(self.cfg, "tensor_parallel_size", 1) or 1) > 1 and torch.cuda.is_available():
            device_map = "balanced"
            n_devices = min(int(self.cfg.tensor_parallel_size), torch.cuda.device_count())
            max_memory = {idx: "70GiB" for idx in range(n_devices)}
        self._hf_model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype="auto",
            device_map=device_map,
            max_memory=max_memory,
            trust_remote_code=True,
        )
        if hasattr(self._hf_model, "device"):
            self._hf_device = self._hf_model.device
        else:
            self._hf_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        return self._hf_tokenizer, self._hf_model

    def _generate_vllm_batch(self, prompts: Sequence[str], system_prompt: Optional[str] = None) -> List[str]:
        llm = self._load_vllm_model()
        from vllm import SamplingParams
        sampling_params = SamplingParams(
            temperature=self.cfg.temperature,
            max_tokens=self.cfg.max_new_tokens,
        )
        conversations = []
        for prompt in prompts:
            messages: List[Dict[str, str]] = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            conversations.append(messages)
        if self._cost_enabled:
            import time
            t0 = time.time()
            outputs = llm.chat(conversations, sampling_params=sampling_params, use_tqdm=False)
            self._cost_stats["generate_seconds"] += time.time() - t0
            self._cost_stats["n_prompts"] += len(outputs)
            for output in outputs:
                self._cost_stats["prompt_tokens"] += len(getattr(output, "prompt_token_ids", []) or [])
                gen = output.outputs[0]
                self._cost_stats["completion_tokens"] += len(getattr(gen, "token_ids", []) or [])
            return [output.outputs[0].text.strip() for output in outputs]
        outputs = llm.chat(conversations, sampling_params=sampling_params, use_tqdm=False)
        return [output.outputs[0].text.strip() for output in outputs]

    def free_vllm_model(self, wait_free_gb: float = 15.0, timeout: float = 120.0) -> None:
        """Destroy the vLLM engine and poll until GPU memory is actually released.

        vLLM spawns worker subprocesses that own CUDA contexts; deleting the
        Python object only sends a shutdown signal.  We poll nvidia-smi (or
        pynvml) until every GPU shows ≥ wait_free_gb GB free, so retrieval
        tools don't OOM when they try to load onto the same cards.
        """
        if self._vllm_model is None:
            return
        import gc
        import subprocess
        import time

        import torch

        del self._vllm_model
        self._vllm_model = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

        # Poll until every GPU reports >= wait_free_gb GB free memory.
        deadline = time.time() + timeout
        wait_free_mib = int(wait_free_gb * 1024)
        while time.time() < deadline:
            try:
                out = subprocess.check_output(
                    ["nvidia-smi", "--query-gpu=memory.free",
                     "--format=csv,noheader,nounits"],
                    timeout=5,
                ).decode()
                free_values = [int(v.strip()) for v in out.strip().splitlines() if v.strip()]
                if all(v >= wait_free_mib for v in free_values):
                    break
            except Exception:
                pass
            time.sleep(2)

        # Final barrier to make sure torch sees the released memory too.
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    def _load_vllm_model(self):
        if self._vllm_model is not None:
            return self._vllm_model
        try:
            from vllm import LLM
        except ImportError as exc:
            raise ImportError(
                "vLLM is not installed. Run: pip install vllm"
            ) from exc
        self._vllm_model = LLM(
            model=self.cfg.model_name,
            tensor_parallel_size=self.cfg.tensor_parallel_size,
            enable_prefix_caching=self.cfg.enable_prefix_caching,
            gpu_memory_utilization=float(getattr(self.cfg, "gpu_memory_utilization", 0.9)),
            max_model_len=int(getattr(self.cfg, "max_model_len", 4096) or 4096),
            trust_remote_code=True,
            dtype="auto",
        )
        return self._vllm_model

    @staticmethod
    def _safe_json_loads(text: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
        try:
            return json.loads(text)
        except Exception:
            start = text.find("{")
            end = text.rfind("}")
            if start >= 0 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except Exception:
                    return fallback
            return fallback
