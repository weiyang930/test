from __future__ import annotations

import math
from typing import Dict, Iterable, List, Sequence


def recall_at_k(preds: Sequence[str], targets: Iterable[str], k: int) -> float:
    targets = list(targets)
    if not targets:
        return 0.0
    hits = len(set(preds[:k]) & set(targets))
    return hits / len(targets)


def ndcg_at_k(preds: Sequence[str], targets: Iterable[str], k: int) -> float:
    target_set = set(targets)
    dcg = 0.0
    for idx, item_id in enumerate(preds[:k]):
        if item_id in target_set:
            dcg += 1.0 / math.log2(idx + 2)
    ideal_hits = min(len(target_set), k)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_hits))
    return dcg / idcg if idcg > 0 else 0.0


def evaluate_user(preds: Sequence[str], targets: Iterable[str], ks=(5, 10, 20, 50)) -> Dict[str, float]:
    metrics = {}
    for k in ks:
        metrics[f"Recall@{k}"] = recall_at_k(preds, targets, k)
        metrics[f"NDCG@{k}"] = ndcg_at_k(preds, targets, k)
    return metrics


def average_metrics(metric_list: List[Dict[str, float]]) -> Dict[str, float]:
    if not metric_list:
        return {}
    keys = metric_list[0].keys()
    return {key: sum(item[key] for item in metric_list) / len(metric_list) for key in keys}
