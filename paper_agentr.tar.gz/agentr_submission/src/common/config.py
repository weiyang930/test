from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclass
class DatasetConfig:
    dataset_name: str
    data_dir: str
    save_split_cache: bool = True
    prefer_split_cache: bool = True


@dataclass
class LLMConfig:
    backend: str = "mock"
    model_name: str = "mock-llm"
    api_base: Optional[str] = None
    api_key_env: str = "OPENAI_API_KEY"
    lora_path: Optional[str] = None
    max_new_tokens: int = 256
    temperature: float = 0.1
    tensor_parallel_size: int = 1
    enable_prefix_caching: bool = True
    gpu_memory_utilization: float = 0.9
    max_model_len: int = 4096


@dataclass
class TextEncoderConfig:
    encoder_name: str = "tfidf"
    model_name: str = "tfidf"
    device: str = "cpu"
    max_features: int = 20000


@dataclass
class ToolConfig:
    tool_name: str
    type: str
    description: str
    requires_training: bool
    model_params: Dict[str, Any] = field(default_factory=dict)
    train_params: Dict[str, Any] = field(default_factory=dict)
    index_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MultiAgentConfig:
    memory_window_size: int = 3
    memory_topk: int = 3
    recall_budget: int = 50
    verifier_topk: int = 20
    force_rebuild_memory: bool = False
    cache_intermediate: bool = True


@dataclass
class RuntimeConfig:
    mode: str = "tool_only"
    seed: int = 42
    device: str = "cpu"
    num_workers: int = 0


@dataclass
class AppConfig:
    dataset: DatasetConfig
    llm: LLMConfig
    text_encoder: TextEncoderConfig
    tools: List[ToolConfig]
    multi_agent: MultiAgentConfig
    runtime: RuntimeConfig


def load_config(path: str) -> AppConfig:
    cfg_path = Path(path)
    raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    return AppConfig(
        dataset=DatasetConfig(**raw["dataset"]),
        llm=LLMConfig(**raw["llm"]),
        text_encoder=TextEncoderConfig(**raw["text_encoder"]),
        tools=[ToolConfig(**tool) for tool in raw["tools"]],
        multi_agent=MultiAgentConfig(**raw["multi_agent"]),
        runtime=RuntimeConfig(**raw["runtime"]),
    )
