"""Common utilities and schemas."""
