from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Interaction:
    userid: str
    itemid: str
    timestamp: int
    label: int
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DatasetSplit:
    train: List[Interaction]
    valid: List[Interaction]
    test: List[Interaction]


@dataclass
class MemoryUnit:
    unit_id: int
    text: str
    embedding: Optional[List[float]]
    related_item_ids: List[str]


@dataclass
class UserMemoryState:
    userid: str
    short_term_memory_id: str
    short_term_memory_text: str
    short_term_source_item_ids: List[str]
    long_term_units: List[MemoryUnit]
    overall_long_term_mem: str


@dataclass
class RetrievalPlan:
    short_term_query: str
    long_term_query: str
    semantic_query_text: str
    collaborative_anchor_hint: str
    sparse_terms: List[str]
    facet_constraints: Dict[str, Any]
    route_preference: List[str]
    confidence: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolExecutionSpec:
    tool_name: str
    query_type: str
    query_payload: Dict[str, Any]
    budget: int


@dataclass
class ExecutionPlan:
    selected_tools: List[ToolExecutionSpec]
    merge_strategy: str
    fallback_trigger: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "selected_tools": [asdict(spec) for spec in self.selected_tools],
            "merge_strategy": self.merge_strategy,
            "fallback_trigger": self.fallback_trigger,
        }


@dataclass
class CandidateItem:
    item_id: str
    item_profile: str
    source_tools: List[str] = field(default_factory=list)
    source_ranks: Dict[str, int] = field(default_factory=dict)
    retrieval_scores: Dict[str, float] = field(default_factory=dict)


@dataclass
class VerificationResult:
    final_item_ids: List[str]
    dropped_item_ids: List[str]
    confidence: float
