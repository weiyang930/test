from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class ArtifactManager:
    project_root: Path
    dataset_name: str

    def __post_init__(self) -> None:
        self.outputs_root = self.project_root / "outputs"
        self.checkpoints_dir = self.outputs_root / "checkpoints" / self.dataset_name
        self.indexes_dir = self.outputs_root / "indexes" / self.dataset_name
        self.memory_cache_dir = self.outputs_root / "memory_cache" / self.dataset_name
        self.results_dir = self.outputs_root / "results" / self.dataset_name
        self.split_cache_dir = self.outputs_root / "split_cache" / self.dataset_name
        for path in [
            self.outputs_root,
            self.checkpoints_dir,
            self.indexes_dir,
            self.memory_cache_dir,
            self.results_dir,
            self.split_cache_dir,
        ]:
            path.mkdir(parents=True, exist_ok=True)

    def checkpoint_path(self, tool_name: str) -> Path:
        return self.checkpoints_dir / f"{tool_name}.pt"

    def index_path(self, tool_name: str) -> Path:
        return self.indexes_dir / f"{tool_name}.pkl"

    def memory_cache_path(self) -> Path:
        return self.memory_cache_dir / "memory_cache.pkl"

    def result_path(self, mode: str) -> Path:
        return self.results_dir / f"{mode}_results.json"
