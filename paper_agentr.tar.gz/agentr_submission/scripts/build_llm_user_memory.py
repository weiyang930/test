#!/usr/bin/env python3
"""Build schema-stable LLM user memories for ranking prompts."""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import pandas as pd

os.environ.setdefault("HF_HOME", "/tmp/hf_home")
os.environ.setdefault("HUGGINGFACE_HUB_CACHE", "/tmp/hf_home/hub")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.agents.llm_backend import LLMBackend
from src.agents.user_memory_agent import UserMemoryLLMAgent
from src.common.artifacts import ArtifactManager
from src.common.config import load_config
from src.data.dataset import DatasetLoader


def clean_text(value: Any, max_chars: int = 160) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    text = " ".join(str(value).split())
    if text.lower() == "nan":
        return ""
    return text[:max_chars]


def leaf_category(categories: str) -> str:
    text = clean_text(categories, 240)
    if not text:
        return ""
    for sep in [">", "|", "/", ","]:
        if sep in text:
            parts = [part.strip(" []'\"") for part in text.split(sep) if part.strip(" []'\"")]
            return parts[-1][:120] if parts else text[:120]
    return text[:120]


def load_raw_item_meta(dataset_dir: Path) -> Dict[str, Dict[str, str]]:
    raw_path = dataset_dir / "item_profile_raw.csv"
    if not raw_path.exists():
        return {}
    df = pd.read_csv(raw_path)
    out: Dict[str, Dict[str, str]] = {}
    for row in df.to_dict(orient="records"):
        iid = str(row.get("itemid"))
        categories = clean_text(row.get("categories"), 220)
        out[iid] = {
            "item_id": iid,
            "title": clean_text(row.get("title"), 180),
            "brand": clean_text(row.get("brand"), 80),
            "categories": categories,
            "leaf_category": leaf_category(categories),
            "description": clean_text(row.get("description"), 180),
        }
    return out


def compact_item(item_id: str, item_meta: Dict[str, Dict[str, str]]) -> Dict[str, str]:
    row = item_meta.get(str(item_id), {})
    return {
        "item_id": str(item_id),
        "title": row.get("title", ""),
        "brand": row.get("brand", ""),
        "categories": row.get("categories", ""),
        "leaf_category": row.get("leaf_category", ""),
    }


def build_user_histories(dataset) -> Dict[str, List[str]]:
    rows: Dict[str, List[Tuple[int, str]]] = defaultdict(list)
    for interaction in dataset.split.train:
        rows[str(interaction.userid)].append((int(interaction.timestamp), str(interaction.itemid)))
    out: Dict[str, List[str]] = {}
    for uid, values in rows.items():
        values.sort(key=lambda x: x[0])
        out[uid] = [iid for _, iid in values]
    return out


def build_evidence(user_id: str, history: Sequence[str], item_meta: Dict[str, Dict[str, str]]) -> Dict[str, Any]:
    category_counter: Counter[str] = Counter()
    brand_counter: Counter[str] = Counter()
    title_counter: Counter[str] = Counter()
    for iid in history:
        row = item_meta.get(str(iid), {})
        leaf = row.get("leaf_category") or row.get("categories", "")
        brand = row.get("brand", "")
        title = row.get("title", "")
        if leaf:
            category_counter[leaf] += 1
        if brand:
            brand_counter[brand] += 1
        if title:
            title_counter[title] += 1

    recent_ids = list(history[-6:])[::-1]
    representative_ids: List[str] = []
    seen = set()
    for iid in list(history[-12:])[::-1]:
        title = item_meta.get(str(iid), {}).get("title", "")
        key = title.lower() if title else str(iid)
        if key not in seen:
            representative_ids.append(str(iid))
            seen.add(key)
        if len(representative_ids) >= 6:
            break

    return {
        "history_len": len(history),
        "recent_items": [compact_item(iid, item_meta) for iid in recent_ids],
        "top_categories": category_counter.most_common(8),
        "top_brands": brand_counter.most_common(8),
        "representative_items": [compact_item(iid, item_meta) for iid in representative_ids],
        "title_repeats": title_counter.most_common(5),
    }


def default_output_path(artifacts: ArtifactManager, model_name: str) -> Path:
    model_tag = model_name.split("/")[-1].replace(".", "p").replace("-", "_").lower()
    return artifacts.indexes_dir / f"user_memory_llm_agent_{model_tag}.json"


def main() -> None:
    parser = argparse.ArgumentParser(description="Build LLM-generated user memory cache.")
    parser.add_argument("--dataset-config", default="configs/industrial_10_80_r811_tool_only.yaml")
    parser.add_argument("--output-path", default="")
    parser.add_argument("--llm-backend", default="")
    parser.add_argument("--llm-model-name", default="")
    parser.add_argument("--tensor-parallel-size", type=int, default=0)
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.0)
    parser.add_argument("--max-model-len", type=int, default=0)
    parser.add_argument("--llm-max-new-tokens", type=int, default=0)
    parser.add_argument("--llm-temperature", type=float, default=-1.0)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--user-limit", type=int, default=0)
    args = parser.parse_args()

    cfg = load_config(args.dataset_config)
    if args.llm_backend:
        cfg.llm.backend = args.llm_backend
    if args.llm_model_name:
        cfg.llm.model_name = args.llm_model_name
    if args.tensor_parallel_size > 0:
        cfg.llm.tensor_parallel_size = args.tensor_parallel_size
    if args.gpu_memory_utilization > 0:
        cfg.llm.gpu_memory_utilization = args.gpu_memory_utilization
    if args.max_model_len > 0:
        cfg.llm.max_model_len = args.max_model_len
    if args.llm_max_new_tokens > 0:
        cfg.llm.max_new_tokens = args.llm_max_new_tokens
    if args.llm_temperature >= 0:
        cfg.llm.temperature = args.llm_temperature

    dataset_name = cfg.dataset.dataset_name
    artifacts = ArtifactManager(project_root=PROJECT_ROOT, dataset_name=dataset_name)
    dataset = DatasetLoader(cfg.dataset, artifacts).load()
    item_meta = load_raw_item_meta(Path(cfg.dataset.data_dir) / dataset_name)
    histories = build_user_histories(dataset)
    user_ids = sorted(histories)
    if args.user_limit > 0:
        user_ids = user_ids[: args.user_limit]

    llm_backend = LLMBackend(cfg.llm)
    agent = UserMemoryLLMAgent(llm_backend=llm_backend, batch_size=args.batch_size)
    records = []
    for uid in user_ids:
        evidence = build_evidence(uid, histories[uid], item_meta)
        records.append({
            "user_id": uid,
            "evidence": evidence,
            "prompt": agent.render_prompt(uid, evidence),
            "fallback": agent.fallback(uid, evidence),
        })
    users = agent.generate_batch(records)
    if cfg.llm.backend == "vllm":
        llm_backend.free_vllm_model(wait_free_gb=50.0, timeout=90.0)

    out_path = Path(args.output_path) if args.output_path else default_output_path(artifacts, cfg.llm.model_name)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "dataset": dataset_name,
        "model": cfg.llm.model_name,
        "backend": cfg.llm.backend,
        "memory_schema": "llm_agent_v1",
        "n_users": len(users),
        "users": users,
    }
    with open(out_path, "w") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
    print(f"[build_llm_user_memory] dataset={dataset_name} users={len(users)} backend={cfg.llm.backend}")
    print(f"[build_llm_user_memory] saved -> {out_path}")


if __name__ == "__main__":
    main()
