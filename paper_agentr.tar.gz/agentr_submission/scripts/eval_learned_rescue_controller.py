#!/usr/bin/env python3
"""
Learned graph-first rescue controller.

The controller policy is still explicit:
  - keep graph top-N
  - choose auxiliary tool pool
  - choose rescue budget

This script learns only the candidate-level rescue scorer from valid labels and
evaluates the same policy on test labels. It uses precomputed tool candidates
from eval_oracle_rule_route.py.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import pickle
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

os.environ.setdefault("HF_HOME", "/tmp/hf_home")
os.environ.setdefault("HUGGINGFACE_HUB_CACHE", "/tmp/hf_home/hub")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.common.artifacts import ArtifactManager
from src.common.config import load_config
from src.data.dataset import DatasetLoader
from src.pipelines.metrics import ndcg_at_k, recall_at_k

TOOLSETS: Dict[str, List[str]] = {
    "semantic": ["semantic"],
    "mem": ["mem"],
    "collab": ["collab"],
    "popularity": ["popularity"],
    "collab_pop": ["collab", "popularity"],
    "semantic_mem": ["semantic", "mem"],
    "semantic_collab": ["semantic", "collab"],
    "all_no_keyword": ["semantic", "mem", "collab", "popularity"],
    "all": ["semantic", "mem", "collab", "popularity", "keyword"],
}
TOOLS = ["semantic", "mem", "collab", "popularity", "keyword"]
EVAL_KS = [5, 10, 20, 50]
FEATURE_NAMES = [
    "n_aux_sources",
    "aux_sources_ge2",
    "aux_sources_ge3",
    "graph_present",
    "graph_inv_rank",
    "graph_norm_rank",
    "graph_tail_present",
]
for _tool in TOOLS:
    FEATURE_NAMES.extend([
        f"{_tool}_present",
        f"{_tool}_inv_rank",
        f"{_tool}_norm_rank",
    ])
FEATURE_NAMES.extend([
    "best_aux_inv_rank",
    "mean_aux_inv_rank",
    "log_history_len",
    "brand_overlap",
    "top_brand_overlap",
    "category_overlap",
    "top_category_overlap",
    "category_jaccard",
])


def _targets(targets_map: Dict[str, Iterable[str]], uid: str) -> List[str]:
    values = targets_map.get(uid, [])
    return list(values) if values is not None else []


def _safe_rank_features(rank0: int | None, limit: int) -> Tuple[float, float, float]:
    if rank0 is None:
        return 0.0, 0.0, 0.0
    rank = rank0 + 1
    return 1.0, 1.0 / rank, 1.0 - min(rank, limit) / max(limit, 1)


def load_item_meta(dataset_dir: Path) -> Dict[str, Dict[str, Any]]:
    raw_path = dataset_dir / "item_profile_raw.csv"
    if not raw_path.exists():
        return {}
    df = pd.read_csv(raw_path)
    out: Dict[str, Dict[str, Any]] = {}
    for row in df.to_dict(orient="records"):
        iid = str(row.get("itemid"))
        brand = str(row.get("brand", "unknown")).strip().lower()
        cats = str(row.get("categories", "")).lower().split("|")
        cat_tokens = {c.strip() for c in cats if c.strip() and c.strip() != "unknown"}
        out[iid] = {"brand": brand, "categories": cat_tokens}
    return out


def build_user_meta(dataset, item_meta: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for uid, items in dataset.user_train_items.items():
        brands: Counter[str] = Counter()
        cats: Counter[str] = Counter()
        for iid in items:
            meta = item_meta.get(str(iid), {})
            brand = meta.get("brand", "unknown")
            if brand and brand != "unknown":
                brands[brand] += 1
            for cat in meta.get("categories", set()):
                cats[cat] += 1
        out[str(uid)] = {
            "brands": set(brands.keys()),
            "top_brands": {b for b, _ in brands.most_common(5)},
            "categories": set(cats.keys()),
            "top_categories": {c for c, _ in cats.most_common(8)},
            "history_len": len(items),
        }
    return out


def candidate_sources(
    cached: Dict[str, Dict[str, List[str]]],
    uid: str,
    graph_items: Sequence[str],
    graph_keep: int,
    aux_tools: Sequence[str],
    aux_k: int,
    min_aux_sources: int,
) -> Tuple[List[str], Dict[str, List[str]], Dict[str, Dict[str, int]]]:
    base_set = set(graph_items[:graph_keep])
    sources: Dict[str, List[str]] = defaultdict(list)
    ranks: Dict[str, Dict[str, int]] = defaultdict(dict)
    for tool in aux_tools:
        for rank0, iid in enumerate(cached.get(tool, {}).get(uid, [])[:aux_k]):
            if iid in base_set:
                continue
            if tool not in sources[iid]:
                sources[iid].append(tool)
            ranks[iid][tool] = rank0
    kept = []
    for iid, srcs in sources.items():
        if len(srcs) >= min_aux_sources:
            kept.append(iid)
    return kept, sources, ranks


def feature_vector(
    iid: str,
    uid: str,
    graph_items: Sequence[str],
    sources: Dict[str, List[str]],
    ranks: Dict[str, Dict[str, int]],
    aux_tools: Sequence[str],
    aux_k: int,
    graph_keep: int,
    item_meta: Dict[str, Dict[str, Any]],
    user_meta: Dict[str, Dict[str, Any]],
) -> List[float]:
    graph_rank = None
    try:
        graph_rank = list(graph_items).index(iid)
    except ValueError:
        graph_rank = None
    g_present, g_inv, g_norm = _safe_rank_features(graph_rank, max(len(graph_items), 1))

    srcs = sources.get(iid, [])
    n_src = len(srcs)
    vals: List[float] = [
        float(n_src),
        float(n_src >= 2),
        float(n_src >= 3),
        g_present,
        g_inv,
        g_norm,
        float(graph_rank is not None and graph_rank >= graph_keep),
    ]
    best_inv = 0.0
    mean_inv = 0.0
    invs = []
    for tool in TOOLS:
        present = tool in srcs
        rank0 = ranks.get(iid, {}).get(tool)
        p, inv, norm = _safe_rank_features(rank0, aux_k)
        vals.extend([p, inv, norm])
        if present:
            invs.append(inv)
            best_inv = max(best_inv, inv)
    mean_inv = float(sum(invs) / len(invs)) if invs else 0.0
    vals.extend([best_inv, mean_inv])

    im = item_meta.get(str(iid), {})
    um = user_meta.get(str(uid), {})
    brand = im.get("brand", "unknown")
    cats = im.get("categories", set())
    user_cats = um.get("categories", set())
    user_top_cats = um.get("top_categories", set())
    cat_overlap = len(cats & user_cats)
    cat_top_overlap = len(cats & user_top_cats)
    cat_jaccard = cat_overlap / max(len(cats | user_cats), 1)
    vals.extend([
        math.log1p(float(um.get("history_len", 0))),
        float(brand in um.get("brands", set()) and brand != "unknown"),
        float(brand in um.get("top_brands", set()) and brand != "unknown"),
        float(cat_overlap),
        float(cat_top_overlap),
        float(cat_jaccard),
    ])
    return vals


def build_examples(
    cached: Dict[str, Dict[str, List[str]]],
    user_ids: Sequence[str],
    targets_map: Dict[str, Iterable[str]],
    aux_tools: Sequence[str],
    graph_keep: int,
    aux_k: int,
    min_aux_sources: int,
    item_meta: Dict[str, Dict[str, Any]],
    user_meta: Dict[str, Dict[str, Any]],
    pool_limit: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    X: List[List[float]] = []
    y: List[int] = []
    positives = 0
    negatives = 0
    users_with_pos = 0
    for uid in user_ids:
        targets = set(_targets(targets_map, uid))
        if not targets:
            continue
        graph_items = cached.get("graph", {}).get(uid, [])
        cands, sources, ranks = candidate_sources(
            cached, uid, graph_items, graph_keep, aux_tools, aux_k, min_aux_sources
        )
        # Deterministic coarse ordering for negative sampling.
        cands = sorted(
            cands,
            key=lambda iid: (
                -len(sources.get(iid, [])),
                min(ranks.get(iid, {}).values(), default=10**9),
                iid,
            ),
        )
        selected = cands[:pool_limit]
        for iid in cands[pool_limit:]:
            if iid in targets:
                selected.append(iid)
        user_pos = 0
        for iid in selected:
            label = int(iid in targets)
            X.append(feature_vector(
                iid, uid, graph_items, sources, ranks, aux_tools, aux_k,
                graph_keep, item_meta, user_meta,
            ))
            y.append(label)
            positives += label
            negatives += 1 - label
            user_pos += label
        users_with_pos += int(user_pos > 0)
    info = {
        "examples": len(y),
        "positives": positives,
        "negatives": negatives,
        "users_with_positive_candidate": users_with_pos,
    }
    return np.asarray(X, dtype=np.float32), np.asarray(y, dtype=np.int32), info


def train_model(X: np.ndarray, y: np.ndarray, model_type: str):
    if model_type == "hgb":
        model = HistGradientBoostingClassifier(
            max_iter=160,
            learning_rate=0.05,
            max_leaf_nodes=31,
            l2_regularization=0.02,
            random_state=42,
        )
    else:
        model = LogisticRegression(
            max_iter=500,
            class_weight="balanced",
            solver="lbfgs",
            n_jobs=1,
            random_state=42,
        )
    model.fit(X, y)
    return model


def inspect_model(model, feature_names: Sequence[str], top_n: int = 12) -> Dict[str, Any]:
    if not hasattr(model, "coef_"):
        return {}
    coefs = model.coef_[0].tolist()
    pairs = list(zip(feature_names, coefs))
    positive = sorted(pairs, key=lambda p: -p[1])[:top_n]
    negative = sorted(pairs, key=lambda p: p[1])[:top_n]
    return {
        "intercept": float(model.intercept_[0]) if hasattr(model, "intercept_") else None,
        "top_positive_coefficients": [
            {"feature": name, "coefficient": round(float(value), 6)}
            for name, value in positive
        ],
        "top_negative_coefficients": [
            {"feature": name, "coefficient": round(float(value), 6)}
            for name, value in negative
        ],
    }


def compose_final(graph_items: Sequence[str], rescue_ranked: Sequence[str], graph_keep: int, rescue_budget: int, final_k: int):
    final: List[str] = []
    seen: set[str] = set()
    for iid in graph_items[:graph_keep]:
        if iid not in seen:
            final.append(iid)
            seen.add(iid)
    for iid in rescue_ranked[:rescue_budget]:
        if iid not in seen:
            final.append(iid)
            seen.add(iid)
        if len(final) >= final_k:
            return final[:final_k]
    for iid in graph_items:
        if iid not in seen:
            final.append(iid)
            seen.add(iid)
        if len(final) >= final_k:
            break
    return final[:final_k]


def evaluate_model(
    model,
    cached: Dict[str, Dict[str, List[str]]],
    user_ids: Sequence[str],
    targets_map: Dict[str, Iterable[str]],
    aux_tools: Sequence[str],
    graph_keep: int,
    rescue_budget: int,
    aux_k: int,
    min_aux_sources: int,
    final_k: int,
    item_meta: Dict[str, Dict[str, Any]],
    user_meta: Dict[str, Dict[str, Any]],
    pool_limit: int,
) -> Dict[str, Any]:
    rows: Dict[str, List[float]] = {f"{m}@{k}": [] for k in EVAL_KS for m in ("Recall", "NDCG")}
    source_hits: Counter[str] = Counter()
    source_selected: Counter[str] = Counter()
    for uid in user_ids:
        targets = _targets(targets_map, uid)
        if not targets:
            continue
        target_set = set(targets)
        graph_items = cached.get("graph", {}).get(uid, [])
        cands, sources, ranks = candidate_sources(
            cached, uid, graph_items, graph_keep, aux_tools, aux_k, min_aux_sources
        )
        cands = sorted(
            cands,
            key=lambda iid: (
                -len(sources.get(iid, [])),
                min(ranks.get(iid, {}).values(), default=10**9),
                iid,
            ),
        )[:pool_limit]
        if cands:
            X = np.asarray([
                feature_vector(iid, uid, graph_items, sources, ranks, aux_tools, aux_k,
                               graph_keep, item_meta, user_meta)
                for iid in cands
            ], dtype=np.float32)
            if hasattr(model, "predict_proba"):
                scores = model.predict_proba(X)[:, 1]
            else:
                scores = model.decision_function(X)
            ranked = [iid for iid, _ in sorted(zip(cands, scores), key=lambda p: (-float(p[1]), p[0]))]
        else:
            ranked = []
        selected = ranked[:rescue_budget]
        for iid in selected:
            key = "+".join(sources.get(iid, [])) or "unknown"
            source_selected[key] += 1
            if iid in target_set:
                source_hits[key] += 1
        preds = compose_final(graph_items, ranked, graph_keep, rescue_budget, final_k)
        for k in EVAL_KS:
            rows[f"Recall@{k}"].append(recall_at_k(preds, targets, k))
            rows[f"NDCG@{k}"].append(ndcg_at_k(preds, targets, k))
    return {
        "metrics": {key: round(sum(vals) / max(len(vals), 1), 6) for key, vals in rows.items()},
        "selected_source_counts": dict(source_selected.most_common(20)),
        "hit_source_counts": dict(source_hits.most_common(20)),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Train/evaluate learned rescue scorer.")
    parser.add_argument("--dataset-config", default="configs/industrial_10_80_r811_tool_only.yaml")
    parser.add_argument("--cache-path", default="")
    parser.add_argument("--toolset", default="all_no_keyword", choices=sorted(TOOLSETS))
    parser.add_argument("--graph-keep", type=int, default=35)
    parser.add_argument("--rescue-budget", type=int, default=15)
    parser.add_argument("--aux-k", type=int, default=100)
    parser.add_argument("--min-aux-sources", type=int, default=1)
    parser.add_argument("--final-k", type=int, default=50)
    parser.add_argument("--pool-limit", type=int, default=160)
    parser.add_argument("--model-type", choices=["logreg", "hgb"], default="hgb")
    parser.add_argument("--save-model", action="store_true")
    parser.add_argument("--user-limit", type=int, default=0)
    args = parser.parse_args()

    cfg = load_config(args.dataset_config)
    dataset_name = cfg.dataset.dataset_name
    artifacts = ArtifactManager(project_root=PROJECT_ROOT, dataset_name=dataset_name)
    dataset = DatasetLoader(cfg.dataset, artifacts).load()
    cache_path = Path(args.cache_path) if args.cache_path else artifacts.results_dir / "precomputed_tool_cache.pkl"
    with open(cache_path, "rb") as fh:
        cached = pickle.load(fh)

    aux_tools = [t for t in TOOLSETS[args.toolset] if t in cached]
    item_meta = load_item_meta(Path(cfg.dataset.data_dir) / cfg.dataset.dataset_name)
    user_meta = build_user_meta(dataset, item_meta)

    valid_users = sorted(dataset.user_valid_items.keys())
    test_users = sorted(dataset.user_test_items.keys())
    if args.user_limit > 0:
        valid_users = valid_users[: args.user_limit]
        test_users = test_users[: args.user_limit]

    print(
        f"[learned_rescue] dataset={dataset_name} toolset={args.toolset} tools={aux_tools} "
        f"keep={args.graph_keep} rescue={args.rescue_budget} minsrc={args.min_aux_sources}",
        flush=True,
    )
    X, y, train_info = build_examples(
        cached, valid_users, dataset.user_valid_items, aux_tools,
        graph_keep=args.graph_keep,
        aux_k=args.aux_k,
        min_aux_sources=args.min_aux_sources,
        item_meta=item_meta,
        user_meta=user_meta,
        pool_limit=args.pool_limit,
    )
    print(f"[learned_rescue] train_info={train_info}", flush=True)
    model = train_model(X, y, args.model_type)
    train_auc = None
    try:
        p = model.predict_proba(X)[:, 1]
        train_auc = float(roc_auc_score(y, p)) if len(set(y.tolist())) > 1 else None
    except Exception:
        train_auc = None

    valid_eval = evaluate_model(
        model, cached, valid_users, dataset.user_valid_items, aux_tools,
        graph_keep=args.graph_keep,
        rescue_budget=args.rescue_budget,
        aux_k=args.aux_k,
        min_aux_sources=args.min_aux_sources,
        final_k=args.final_k,
        item_meta=item_meta,
        user_meta=user_meta,
        pool_limit=args.pool_limit,
    )
    test_eval = evaluate_model(
        model, cached, test_users, dataset.user_test_items, aux_tools,
        graph_keep=args.graph_keep,
        rescue_budget=args.rescue_budget,
        aux_k=args.aux_k,
        min_aux_sources=args.min_aux_sources,
        final_k=args.final_k,
        item_meta=item_meta,
        user_meta=user_meta,
        pool_limit=args.pool_limit,
    )

    result = {
        "dataset": dataset_name,
        "config": vars(args),
        "aux_tools": aux_tools,
        "feature_names": FEATURE_NAMES,
        "model_inspection": inspect_model(model, FEATURE_NAMES),
        "train_info": train_info,
        "train_auc": train_auc,
        "valid_eval": valid_eval,
        "test_eval": test_eval,
    }
    out_path = artifacts.results_dir / (
        f"learned_rescue_{args.toolset}_keep{args.graph_keep}_"
        f"rescue{args.rescue_budget}_minsrc{args.min_aux_sources}_{args.model_type}.json"
    )
    with open(out_path, "w") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2)

    model_path = None
    if args.save_model:
        import pickle as model_pickle

        model_path = out_path.with_suffix(".pkl")
        with open(model_path, "wb") as fh:
            model_pickle.dump({
                "model": model,
                "feature_names": FEATURE_NAMES,
                "config": vars(args),
                "aux_tools": aux_tools,
            }, fh)

    print(f"[learned_rescue] train_auc={train_auc}")
    print(f"[learned_rescue] VALID {valid_eval['metrics']}")
    print(f"[learned_rescue] TEST  {test_eval['metrics']}")
    print(f"[learned_rescue] saved -> {out_path}")
    if model_path is not None:
        print(f"[learned_rescue] model -> {model_path}")


if __name__ == "__main__":
    main()
