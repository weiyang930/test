# RERUN_1030 回传：Lean DAPO 基线（`barrier_dapo`，50 步，H100，10-30 05:08 → 09:09 UTC）

| 路径 | 内容 |
|---|---|
| `2026-10-30_rerun1030_lean_dapo.MD` | 过程记录：拿代码、冒烟检查、manifest 状态、吞吐/评测表、发现的两个 bug（run_ec_arm.sh 第 77 行、eval_ckpt.sh Lean 不删 checkpoint） |
| `stage2d_summaries_1030.txt` | RERUN_1030 要贴的三样：`summarize_run.py`、`stage2_summary.py`、`eval/eval_curve.json` |
| `eval_curve/h100_lean_barrier_dapo.json` | `eval/eval_curve.json` |
| `logs/stage2d_lean.log` | 正式 50 步 + 评测的链日志 |
| `logs/smoke_lean_dapo.log` | 冒烟（2 步）日志 |
| `runs/` | outbox `h100_lean_barrier_dapo.tgz` 展开：`h100_lean_barrier_dapo/`（manifest、eval/）+ `lean_barrier_dapo/`（train output，含 tensorboard、stdout.log） |

说明：stdout.log 中节点内网 IP 已替换为 `<node-ip>`，其余内容未改动。
