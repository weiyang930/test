# SynCo: Synthesizer–Reasoner Co-Training

SynCo trains a math **Reasoner** on problems written online by a **Synthesizer** that is
trained at the same time. Both are Qwen3-8B policies optimized with GRPO. In every step the
Synthesizer writes a batch of problems, verified problems are solved several times by the
Reasoner, the Reasoner is rewarded for correct answers, and the Synthesizer is rewarded for
valid problems at the right difficulty for the current Reasoner. A report on the recent
problems and the Reasoner's performance is fed back to the Synthesizer every few steps.

This repository contains the full training and evaluation code, the training framework
(UnityMAS-O, bundled in `third_party/`), and the evaluation benchmarks.

## Method

Each training step has 32 task slots. For each slot
(`src/synth_reasoner/unitymas_adapter/workflow_adapter.py`):

1. **Synthesizer** reads the current report and writes one JSON task card (`problem`,
   `solution`, `final_answer`, `teaching_intent`, … — 9 fields).
2. **TaskVerifier** checks the card. A task is valid if the JSON parses, all fields are present,
   the problem and answer checks pass (scores ≥ 0.5) and it is not a near-duplicate of recent
   problems.
3. **Reasoner** solves each valid task K = 4 times; **AnswerChecker** (exact → numeric → sympy →
   set/tuple) grades each answer; `sr` is the fraction of correct rollouts.
4. **Rewards**

   | role | reward |
   |---|---|
   | Reasoner (per rollout) | 1.0 correct with `\boxed{}`, 0.9 correct without, 0.0 wrong |
   | Synthesizer (per task) | `gate(quality) · gate(reliability) · peak(sr)` for a valid task, −0.5 for an invalid one |

   `gate(x) = clip((x − 0.5) / 0.5, 0, 1)` and `peak(sr) = 1 − |2·sr − 1|`, i.e. 0 / 0.5 / 1 /
   0.5 / 0 for sr = 0 / ¼ / ½ / ¾ / 1: the Synthesizer is rewarded most for problems the Reasoner
   solves about half of the time. quality and reliability are the verifier's overall score and
   answer/solution-consistency score. Each non-empty output additionally gets a +0.1 format reward.
5. **GRPO**: Reasoner groups are the K rollouts of a task; the Synthesizer's group is all of its
   samples in the step. Every task is stored in the run's pool (`runs/<run_id>/pool/`), from which
   the Synthesizer's report is rebuilt every 5 steps.

Default training setting: 100 steps, learning rate 1e-6 (10 warm-up steps, weight decay 0.1),
no KL, up to 2,048 prompt + 6,144 response tokens, sampling temperature 1.0 (Synthesizer) /
0.9 (Reasoner), top-p 0.95. The two policies run on separate 8-GPU nodes (FSDP2 + vLLM, TP=8).
All settings are in `configs/synco_trainer.yaml`.

## Installation

Requirements: Python 3.10, CUDA 12.x; 2 nodes × 8 GPUs for training, any GPU for evaluation.

```bash
VENV=.venv bash scripts/setup_env.sh
```

This installs the pinned packages (`requirements-lock.txt`: torch 2.8.0, vLLM 0.10.2,
transformers 4.56.2, Ray 2.55.1), the bundled UnityMAS-O and this package.

Download [Qwen3-8B](https://huggingface.co/Qwen/Qwen3-8B) and point `BASE_MODEL_PATH` to it.

## Training

```bash
BASE_MODEL_PATH=/path/to/Qwen3-8B \
WORKER_NODE_IP=<ip of the second node> WORKER_SLURM_JOBID=<SLURM job holding the second node> \
bash scripts/train.sh
```

The script starts a Ray cluster with the current host as head and joins the second node via
SLURM. Alternatively use `WORKER_SSH=user@node2` (ssh), or set `RAY_ADDRESS=<head>:<port>` to
use an existing Ray cluster with ≥ 16 GPUs.

Outputs are written to `runs/<RUN_ID>/`: `pool/` (all generated tasks with verification,
rollouts and rewards; `valid_tasks.jsonl` is the synthesized dataset), `ckpts/` (every 10
steps) and `tensorboard_log/`.

Options (environment variables):

| variable | default | description |
|---|---|---|
| `SYNTH_REWARD_MODE` | `gated` | Synthesizer reward; `additive` = weighted sum of quality, reliability, difficulty band, novelty and report alignment |
| `TOTAL_EPOCHS` | 100 | number of training steps |
| `REASONER_ROLLOUTS_PER_TASK` | 4 | rollouts per task (K) |
| `TRAIN_QUERIES` | `data/train/initial_queries.json` | initial Synthesizer queries; `BUILD_QUERIES=1` builds them from an empty pool |
| `ROLLOUT_GPU_MEMORY_UTILIZATION` | 0.3 | vLLM GPU memory fraction |
| `RUN_ID`, `CKPTS_DIR` | auto | run name / checkpoint directory |
| `RESUME_MODE` | `disable` | `auto` resumes from the latest checkpoint |

Hydra overrides can be appended, e.g. `bash scripts/train.sh trainer.save_freq=20`.

On GPUs with less memory than B200, lower `ROLLOUT_GPU_MEMORY_UTILIZATION` and
`ACTOR_PPO_MAX_TOKEN_LEN_PER_GPU`, or give each policy more nodes (`SYNTHESIZER_NNODES`,
`REASONER_NNODES`).

## Evaluation

```bash
# merge the Reasoner checkpoint into a Hugging Face model
bash scripts/merge_checkpoint.sh runs/<RUN_ID>/ckpts/global_step_100 eval_results/<RUN_ID>/model
# evaluate with all GPUs of the node and aggregate
bash scripts/eval_checkpoint.sh eval_results/<RUN_ID>/model eval_results/<RUN_ID>
cat eval_results/<RUN_ID>/accuracy.json
```

Default benchmarks: GSM8K, SVAMP, ASDiv, GSM-Hard, MATH-500, AIME24, AIME25, Minerva (AMC23,
OlympiadBench and Gaokao2023-En are also available via `--benchmarks`). Decoding: Qwen3 chat
template, temperature 0.6, top-p 0.95, one sample per problem; the last `\boxed{}` answer is
graded with the AnswerChecker.

The benchmarks are included in `data/eval/`. To download them again from Hugging Face:

```bash
python scripts/download_eval_data.py          # gsm8k math500 amc23 aime24 aime25 olympiad
python scripts/fetch_hf_math_benchmarks.py    # minerva gsm_hard gaokao2023en svamp asdiv
```

## Repository layout

```
configs/synco_trainer.yaml        training configuration
scripts/train.sh                  training launcher
scripts/merge_checkpoint.sh       FSDP checkpoint -> Hugging Face model
scripts/evaluate.py               evaluation (eval_checkpoint.sh runs it on one node)
scripts/download_eval_data.py     benchmark download
scripts/fetch_hf_math_benchmarks.py
scripts/setup_env.sh              environment setup
src/synth_reasoner/
  unitymas_adapter/               per-task workflow and reward allocation
  agents/prompts.py               Synthesizer / Reasoner prompts
  verification/                   TaskVerifier, AnswerChecker
  rewards/                        Synthesizer and Reasoner rewards
  pool/, reports/                 task pool and Synthesizer report
  parsing/                        task-card parsing, answer extraction
  cli/prepare_train_jsonl.py      build initial Synthesizer queries
  evaluation/benchmark_loader.py
data/eval/                        evaluation benchmarks
data/train/initial_queries.json   initial Synthesizer queries
third_party/UnityMAS-O/           training framework
```

## License

`third_party/UnityMAS-O` is [UnityMAS-O](https://github.com/chenyiqun/UnityMAS-O) (Apache-2.0,
commit `7f1616a`) with small modifications for multi-agent GRPO, listed in
`third_party/UnityMAS-O/SYNCO_MODIFICATIONS.md`.
