"""Command-line entrypoints for the dry-debug and generate-only modes."""
